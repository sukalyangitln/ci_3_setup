<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-27 00:00:34 --> Total execution time: 1.4431
DEBUG - 2022-04-27 00:00:44 --> Total execution time: 0.1420
DEBUG - 2022-04-27 00:01:17 --> Total execution time: 0.1368
DEBUG - 2022-04-27 00:01:42 --> Total execution time: 0.0985
DEBUG - 2022-04-27 00:01:48 --> Total execution time: 0.1411
DEBUG - 2022-04-27 00:02:15 --> Total execution time: 0.1008
DEBUG - 2022-04-27 00:02:26 --> Total execution time: 0.1023
DEBUG - 2022-04-27 00:02:30 --> Total execution time: 0.1127
DEBUG - 2022-04-27 00:02:39 --> Total execution time: 0.1518
DEBUG - 2022-04-27 00:02:41 --> Total execution time: 0.1131
DEBUG - 2022-04-27 00:02:43 --> Total execution time: 0.1146
DEBUG - 2022-04-27 00:02:52 --> Total execution time: 0.0964
DEBUG - 2022-04-27 00:02:54 --> Total execution time: 0.1125
DEBUG - 2022-04-27 00:03:31 --> Total execution time: 0.1081
DEBUG - 2022-04-27 00:04:09 --> Total execution time: 0.0996
DEBUG - 2022-04-27 00:04:18 --> Total execution time: 0.0939
DEBUG - 2022-04-27 00:04:28 --> Total execution time: 0.1427
ERROR - 2022-04-27 00:05:12 --> Severity: Notice --> Undefined variable: list C:\xampp\htdocs\esalestrix\application\views\Admin\users\user_profile.php 40
ERROR - 2022-04-27 00:05:12 --> Severity: Notice --> Trying to get property 'ul_id' of non-object C:\xampp\htdocs\esalestrix\application\views\Admin\users\user_profile.php 40
DEBUG - 2022-04-27 00:05:12 --> Total execution time: 0.1670
DEBUG - 2022-04-27 00:05:20 --> Total execution time: 0.1271
DEBUG - 2022-04-27 00:07:13 --> Total execution time: 0.0997
DEBUG - 2022-04-27 00:07:21 --> Total execution time: 0.0988
DEBUG - 2022-04-27 00:07:56 --> Total execution time: 0.1446
DEBUG - 2022-04-27 00:08:49 --> Total execution time: 0.0991
DEBUG - 2022-04-27 00:11:03 --> Total execution time: 0.1057
DEBUG - 2022-04-27 00:14:41 --> Total execution time: 0.1293
DEBUG - 2022-04-27 00:17:02 --> Total execution time: 0.1688
DEBUG - 2022-04-27 00:17:41 --> Total execution time: 0.1409
DEBUG - 2022-04-27 00:17:59 --> Total execution time: 0.1499
DEBUG - 2022-04-27 00:19:24 --> Total execution time: 0.1008
DEBUG - 2022-04-27 00:19:49 --> Total execution time: 0.1027
DEBUG - 2022-04-27 01:49:56 --> Total execution time: 0.1573
DEBUG - 2022-04-27 01:50:44 --> Total execution time: 0.1441
DEBUG - 2022-04-27 01:51:48 --> Total execution time: 0.1684
DEBUG - 2022-04-27 01:53:45 --> Total execution time: 0.1051
DEBUG - 2022-04-27 01:54:22 --> Total execution time: 0.1800
DEBUG - 2022-04-27 01:54:26 --> Total execution time: 0.0803
DEBUG - 2022-04-27 01:57:51 --> Total execution time: 0.1528
DEBUG - 2022-04-27 01:57:53 --> Total execution time: 0.0891
DEBUG - 2022-04-27 01:57:55 --> Total execution time: 0.0950
DEBUG - 2022-04-27 01:57:57 --> Total execution time: 0.0786
DEBUG - 2022-04-27 01:57:58 --> Total execution time: 0.0998
DEBUG - 2022-04-27 01:58:41 --> Total execution time: 0.1423
DEBUG - 2022-04-27 01:58:42 --> Total execution time: 0.1205
ERROR - 2022-04-27 01:58:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\esalestrix\application\controllers\User\Auth\UserAuth.php 47
DEBUG - 2022-04-27 01:58:48 --> Total execution time: 0.2867
DEBUG - 2022-04-27 01:58:52 --> Total execution time: 0.2385
DEBUG - 2022-04-27 01:59:17 --> Total execution time: 0.1232
DEBUG - 2022-04-27 01:59:22 --> Total execution time: 0.1650
DEBUG - 2022-04-27 01:59:27 --> Total execution time: 0.1704
DEBUG - 2022-04-27 01:59:37 --> Total execution time: 0.1360
DEBUG - 2022-04-27 01:59:47 --> Total execution time: 0.1611
DEBUG - 2022-04-27 01:59:49 --> Total execution time: 0.1095
DEBUG - 2022-04-27 01:59:51 --> Total execution time: 0.1126
DEBUG - 2022-04-27 02:04:08 --> Total execution time: 0.1532
DEBUG - 2022-04-27 02:04:13 --> Total execution time: 0.1014
ERROR - 2022-04-27 02:04:15 --> Severity: error --> Exception: Too few arguments to function flash(), 1 passed in C:\xampp\htdocs\esalestrix\application\controllers\Admin\User_crud_controller.php on line 31 and exactly 2 expected C:\xampp\htdocs\esalestrix\application\helpers\core_helper.php 204
DEBUG - 2022-04-27 02:04:40 --> Total execution time: 0.1089
DEBUG - 2022-04-27 02:04:45 --> Total execution time: 0.1794
DEBUG - 2022-04-27 02:04:48 --> Total execution time: 0.1205
DEBUG - 2022-04-27 02:04:52 --> Total execution time: 0.1129
DEBUG - 2022-04-27 02:05:10 --> Total execution time: 0.1042
ERROR - 2022-04-27 02:05:53 --> Severity: Notice --> Undefined property: stdClass::$country_name C:\xampp\htdocs\esalestrix\application\views\Admin\users\user_profile.php 131
ERROR - 2022-04-27 02:05:53 --> Severity: Notice --> Undefined property: stdClass::$state_name C:\xampp\htdocs\esalestrix\application\views\Admin\users\user_profile.php 135
ERROR - 2022-04-27 02:05:53 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\esalestrix\application\views\Admin\users\user_profile.php 139
DEBUG - 2022-04-27 02:05:53 --> Total execution time: 0.1509
ERROR - 2022-04-27 02:07:40 --> Severity: Notice --> Undefined property: stdClass::$state_name C:\xampp\htdocs\esalestrix\application\views\Admin\users\user_profile.php 138
ERROR - 2022-04-27 02:07:40 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\esalestrix\application\views\Admin\users\user_profile.php 142
DEBUG - 2022-04-27 02:07:40 --> Total execution time: 0.1306
DEBUG - 2022-04-27 02:07:49 --> Total execution time: 0.1499
ERROR - 2022-04-27 02:07:51 --> Severity: Notice --> Undefined property: stdClass::$state_name C:\xampp\htdocs\esalestrix\application\views\Admin\users\user_profile.php 138
ERROR - 2022-04-27 02:07:51 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\esalestrix\application\views\Admin\users\user_profile.php 142
DEBUG - 2022-04-27 02:07:51 --> Total execution time: 0.1041
ERROR - 2022-04-27 02:09:08 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\esalestrix\application\views\Admin\users\user_profile.php 149
DEBUG - 2022-04-27 02:09:08 --> Total execution time: 0.1495
DEBUG - 2022-04-27 02:09:55 --> Total execution time: 0.1338
DEBUG - 2022-04-27 02:09:59 --> Total execution time: 0.1039
DEBUG - 2022-04-27 02:10:01 --> Total execution time: 0.1164
DEBUG - 2022-04-27 02:10:03 --> Total execution time: 0.1078
DEBUG - 2022-04-27 02:10:05 --> Total execution time: 0.1055
DEBUG - 2022-04-27 02:10:09 --> Total execution time: 0.0794
DEBUG - 2022-04-27 02:10:10 --> Total execution time: 0.0977
DEBUG - 2022-04-27 02:10:12 --> Total execution time: 0.0807
DEBUG - 2022-04-27 02:10:13 --> Total execution time: 0.0928
DEBUG - 2022-04-27 02:11:04 --> Total execution time: 0.1869
DEBUG - 2022-04-27 02:11:13 --> Total execution time: 0.1425
DEBUG - 2022-04-27 02:11:46 --> Total execution time: 0.1230
DEBUG - 2022-04-27 02:12:24 --> Total execution time: 0.1006
DEBUG - 2022-04-27 02:15:16 --> Total execution time: 0.1197
DEBUG - 2022-04-27 02:15:57 --> Total execution time: 0.1580
DEBUG - 2022-04-27 02:17:43 --> Total execution time: 0.4492
DEBUG - 2022-04-27 02:18:19 --> Total execution time: 0.0978
DEBUG - 2022-04-27 02:18:44 --> Total execution time: 0.0972
DEBUG - 2022-04-27 02:18:47 --> Total execution time: 0.1818
DEBUG - 2022-04-27 02:18:50 --> Total execution time: 0.1484
DEBUG - 2022-04-27 02:19:01 --> Total execution time: 0.1154
DEBUG - 2022-04-27 02:23:53 --> Total execution time: 0.2093
DEBUG - 2022-04-27 02:24:07 --> Total execution time: 0.1653
DEBUG - 2022-04-27 02:28:46 --> Total execution time: 0.1309
DEBUG - 2022-04-27 02:30:32 --> Total execution time: 0.1135
DEBUG - 2022-04-27 02:31:19 --> Total execution time: 0.1019
DEBUG - 2022-04-27 02:33:03 --> Total execution time: 0.1688
DEBUG - 2022-04-27 02:33:23 --> Total execution time: 0.1040
DEBUG - 2022-04-27 02:34:51 --> Total execution time: 0.1518
DEBUG - 2022-04-27 02:35:24 --> Total execution time: 0.1766
DEBUG - 2022-04-27 02:36:59 --> Total execution time: 0.1546
DEBUG - 2022-04-27 02:39:49 --> Total execution time: 0.1709
DEBUG - 2022-04-27 02:40:38 --> Total execution time: 0.1679
DEBUG - 2022-04-27 02:40:44 --> Total execution time: 0.1021
DEBUG - 2022-04-27 02:42:42 --> Total execution time: 0.1547
DEBUG - 2022-04-27 02:42:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 02:42:48 --> Total execution time: 0.1446
DEBUG - 2022-04-27 02:44:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 02:44:27 --> Total execution time: 0.1244
DEBUG - 2022-04-27 02:45:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 02:45:42 --> Total execution time: 0.0936
DEBUG - 2022-04-27 02:45:55 --> Total execution time: 0.1858
DEBUG - 2022-04-27 02:48:30 --> Total execution time: 0.1886
DEBUG - 2022-04-27 02:48:36 --> Total execution time: 0.1471
DEBUG - 2022-04-27 02:48:45 --> Total execution time: 0.1309
DEBUG - 2022-04-27 02:52:05 --> Total execution time: 0.1130
DEBUG - 2022-04-27 02:52:25 --> Total execution time: 0.1538
ERROR - 2022-04-27 02:53:13 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\esalestrix\application\views\User\profile\kyc-details.php 88
DEBUG - 2022-04-27 02:53:20 --> Total execution time: 0.1187
DEBUG - 2022-04-27 02:55:31 --> Total execution time: 0.1462
DEBUG - 2022-04-27 02:57:16 --> Total execution time: 0.1351
DEBUG - 2022-04-27 02:57:54 --> Total execution time: 0.1471
DEBUG - 2022-04-27 02:58:16 --> Total execution time: 0.0910
DEBUG - 2022-04-27 02:58:51 --> Total execution time: 0.1417
DEBUG - 2022-04-27 02:59:38 --> Total execution time: 0.1498
DEBUG - 2022-04-27 03:00:02 --> Total execution time: 0.1572
DEBUG - 2022-04-27 03:00:14 --> Total execution time: 0.1462
DEBUG - 2022-04-27 03:00:34 --> Total execution time: 0.1628
DEBUG - 2022-04-27 03:00:58 --> Total execution time: 0.1369
DEBUG - 2022-04-27 03:01:35 --> Total execution time: 0.1774
DEBUG - 2022-04-27 03:01:39 --> Total execution time: 0.1239
DEBUG - 2022-04-27 03:02:54 --> Total execution time: 0.1542
DEBUG - 2022-04-27 03:03:00 --> Total execution time: 0.1154
DEBUG - 2022-04-27 03:05:46 --> Total execution time: 0.0983
DEBUG - 2022-04-27 03:06:01 --> Total execution time: 0.0987
DEBUG - 2022-04-27 03:06:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 03:06:12 --> Total execution time: 0.0883
DEBUG - 2022-04-27 03:06:54 --> Total execution time: 0.2013
DEBUG - 2022-04-27 03:06:59 --> Total execution time: 0.0881
DEBUG - 2022-04-27 03:07:00 --> Total execution time: 0.1264
DEBUG - 2022-04-27 03:07:05 --> Total execution time: 0.1439
DEBUG - 2022-04-27 03:07:10 --> Total execution time: 0.1128
DEBUG - 2022-04-27 03:07:26 --> Total execution time: 0.1179
DEBUG - 2022-04-27 03:08:51 --> Total execution time: 0.1838
DEBUG - 2022-04-27 03:11:05 --> Total execution time: 0.1404
DEBUG - 2022-04-27 03:12:38 --> Total execution time: 0.1162
DEBUG - 2022-04-27 03:12:45 --> Total execution time: 0.1482
DEBUG - 2022-04-27 03:14:14 --> Total execution time: 0.1444
DEBUG - 2022-04-27 03:15:23 --> Total execution time: 0.1417
DEBUG - 2022-04-27 03:15:49 --> Total execution time: 0.1279
DEBUG - 2022-04-27 03:15:58 --> Total execution time: 0.1388
DEBUG - 2022-04-27 03:16:12 --> Total execution time: 0.1364
DEBUG - 2022-04-27 03:16:29 --> Total execution time: 0.0916
DEBUG - 2022-04-27 03:19:16 --> Total execution time: 0.1109
DEBUG - 2022-04-27 00:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 00:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 00:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:26:02 --> Total execution time: 0.1630
DEBUG - 2022-04-27 00:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 00:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 00:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:26:48 --> Total execution time: 0.1546
DEBUG - 2022-04-27 00:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 00:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 00:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:28:15 --> Total execution time: 0.1224
DEBUG - 2022-04-27 00:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 00:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 00:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:29:03 --> Total execution time: 0.2862
DEBUG - 2022-04-27 01:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:30:01 --> Total execution time: 0.1364
DEBUG - 2022-04-27 01:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:30:08 --> Total execution time: 0.1477
DEBUG - 2022-04-27 01:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:30:18 --> Total execution time: 0.1333
DEBUG - 2022-04-27 01:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:33:18 --> Total execution time: 0.1230
DEBUG - 2022-04-27 01:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:03:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:03:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:03:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:03:21 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:03:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:03:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:33:25 --> Total execution time: 0.2663
DEBUG - 2022-04-27 01:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:03:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:03:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:03:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:03:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:03:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:03:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:03:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:03:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:03:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:33:29 --> Total execution time: 0.0981
DEBUG - 2022-04-27 01:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:33:30 --> Total execution time: 0.0815
DEBUG - 2022-04-27 01:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:33:38 --> Total execution time: 0.1321
DEBUG - 2022-04-27 01:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:33:40 --> Total execution time: 0.0824
DEBUG - 2022-04-27 01:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:33:40 --> Total execution time: 0.0899
DEBUG - 2022-04-27 01:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:35:38 --> Total execution time: 0.1269
DEBUG - 2022-04-27 01:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:05:39 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:05:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:05:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:05:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:05:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:05:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:05:39 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:05:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:05:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:05:39 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:05:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:05:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:05:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:05:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:05:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 04:35:47 --> Query error: Unknown column 'ul_id' in 'where clause' - Invalid query: UPDATE `user_kyc_details` SET `ukd_status` = 'p', `ukd_accepted_datetime` = NULL
WHERE `ul_id` IS NULL
DEBUG - 2022-04-27 01:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:05:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 04:35:55 --> Query error: Unknown column 'ul_id' in 'where clause' - Invalid query: UPDATE `user_kyc_details` SET `ukd_status` = 'a', `ukd_accepted_datetime` = '2022-04-27 04:35:55'
WHERE `ul_id` IS NULL
DEBUG - 2022-04-27 01:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:05:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:05:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:05:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:05:58 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:05:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:05:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:05:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:05:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:05:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:05:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:05:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:05:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:36:28 --> Total execution time: 0.1042
DEBUG - 2022-04-27 01:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:06:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:06:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:06:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:06:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:06:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:06:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:06:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:06:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:06:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:06:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:06:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 04:36:32 --> Query error: Unknown column 'ul_id' in 'where clause' - Invalid query: UPDATE `user_kyc_details` SET `ukd_status` = 'p', `ukd_accepted_datetime` = NULL
WHERE `ul_id` IS NULL
DEBUG - 2022-04-27 01:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:06:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 04:36:42 --> Query error: Unknown column 'ul_id' in 'where clause' - Invalid query: UPDATE `user_kyc_details` SET `ukd_status` = 'p', `ukd_accepted_datetime` = NULL
WHERE `ul_id` IS NULL
DEBUG - 2022-04-27 01:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:36:53 --> Total execution time: 0.0981
DEBUG - 2022-04-27 01:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:36:55 --> Total execution time: 0.1110
DEBUG - 2022-04-27 01:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:06:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:06:56 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:06:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:06:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:06:56 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:06:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:06:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:06:56 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:06:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:06:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:37:01 --> Total execution time: 0.1540
DEBUG - 2022-04-27 01:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:07:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:07:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:07:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:07:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:07:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:07:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:07:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:07:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:37:04 --> Total execution time: 0.0940
DEBUG - 2022-04-27 01:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:37:05 --> Total execution time: 0.0926
DEBUG - 2022-04-27 01:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:37:07 --> Total execution time: 0.0850
DEBUG - 2022-04-27 01:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:37:12 --> Total execution time: 0.1012
DEBUG - 2022-04-27 01:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:37:14 --> Total execution time: 0.0834
DEBUG - 2022-04-27 01:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:37:16 --> Total execution time: 0.0962
DEBUG - 2022-04-27 01:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:37:18 --> Total execution time: 0.0831
DEBUG - 2022-04-27 01:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:37:23 --> Total execution time: 0.0873
DEBUG - 2022-04-27 01:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:37:29 --> Total execution time: 0.1068
DEBUG - 2022-04-27 01:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:37:35 --> Total execution time: 0.1456
DEBUG - 2022-04-27 01:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:37:36 --> Total execution time: 0.0921
DEBUG - 2022-04-27 01:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:38:45 --> Total execution time: 0.1510
DEBUG - 2022-04-27 01:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:38:53 --> Total execution time: 0.0928
DEBUG - 2022-04-27 01:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:40:42 --> Total execution time: 0.1275
DEBUG - 2022-04-27 01:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:40:45 --> Total execution time: 0.0833
DEBUG - 2022-04-27 01:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:40:47 --> Total execution time: 0.1104
DEBUG - 2022-04-27 01:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:40:49 --> Total execution time: 0.0921
DEBUG - 2022-04-27 01:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:40:51 --> Total execution time: 0.0957
DEBUG - 2022-04-27 01:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:12:24 --> Total execution time: 0.1339
DEBUG - 2022-04-27 01:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:12:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 01:12:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\esalestrix\application\core\DB_Controller.php 52
DEBUG - 2022-04-27 01:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:42:47 --> Total execution time: 0.0806
DEBUG - 2022-04-27 01:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:42:48 --> Total execution time: 0.1254
DEBUG - 2022-04-27 01:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:12:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 04:42:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\esalestrix\application\controllers\User\Auth\UserAuth.php 47
DEBUG - 2022-04-27 01:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:42:55 --> Total execution time: 0.1251
DEBUG - 2022-04-27 01:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:43:09 --> Total execution time: 0.0945
DEBUG - 2022-04-27 01:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:43:10 --> Total execution time: 0.1337
DEBUG - 2022-04-27 01:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:13:11 --> Total execution time: 0.2336
DEBUG - 2022-04-27 01:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:13:12 --> Total execution time: 0.1584
DEBUG - 2022-04-27 01:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:13:27 --> Total execution time: 0.1902
DEBUG - 2022-04-27 01:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:13:43 --> No URI present. Default controller set.
DEBUG - 2022-04-27 01:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:13:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 01:13:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\esalestrix\application\core\DB_Controller.php 28
DEBUG - 2022-04-27 01:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:13:47 --> Total execution time: 0.0797
DEBUG - 2022-04-27 01:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:43:49 --> Total execution time: 0.1232
DEBUG - 2022-04-27 01:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:43:52 --> Total execution time: 0.1855
DEBUG - 2022-04-27 01:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:14:03 --> Total execution time: 0.1636
DEBUG - 2022-04-27 01:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:14:04 --> Total execution time: 0.1342
DEBUG - 2022-04-27 01:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:14:07 --> Total execution time: 0.1506
DEBUG - 2022-04-27 01:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:14:14 --> Total execution time: 0.2444
DEBUG - 2022-04-27 01:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:14:14 --> Total execution time: 0.1370
DEBUG - 2022-04-27 01:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:15:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:15:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:15:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:15:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:15:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:15:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:15:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:15:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:15:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:15:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:15:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:15:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:16:22 --> Total execution time: 0.1327
DEBUG - 2022-04-27 01:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:16:23 --> Total execution time: 0.1757
DEBUG - 2022-04-27 01:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:16:26 --> Total execution time: 0.1266
DEBUG - 2022-04-27 01:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:16:26 --> Total execution time: 0.1166
DEBUG - 2022-04-27 01:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:31 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:16:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:16:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:16:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:16:39 --> Total execution time: 0.1218
DEBUG - 2022-04-27 01:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:40 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:16:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:16:40 --> Total execution time: 0.1250
DEBUG - 2022-04-27 01:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:16:45 --> Total execution time: 0.1039
DEBUG - 2022-04-27 01:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:16:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:16:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:16:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:16:47 --> Total execution time: 0.1630
DEBUG - 2022-04-27 01:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:16:50 --> Total execution time: 0.1101
DEBUG - 2022-04-27 01:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:16:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:16:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:16:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:16:51 --> Total execution time: 0.1800
DEBUG - 2022-04-27 01:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:17:23 --> Total execution time: 0.1182
DEBUG - 2022-04-27 01:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:17:24 --> Total execution time: 0.1168
DEBUG - 2022-04-27 01:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:17:35 --> Total execution time: 0.1339
DEBUG - 2022-04-27 01:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:17:35 --> Total execution time: 0.1162
DEBUG - 2022-04-27 01:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:17:37 --> Total execution time: 0.1355
DEBUG - 2022-04-27 01:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:17:37 --> Total execution time: 0.1357
DEBUG - 2022-04-27 01:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:18:06 --> Total execution time: 0.1529
DEBUG - 2022-04-27 01:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:18:07 --> Total execution time: 0.1472
DEBUG - 2022-04-27 01:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:18:08 --> Total execution time: 0.1262
DEBUG - 2022-04-27 01:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:18:08 --> Total execution time: 0.1152
DEBUG - 2022-04-27 01:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:18:31 --> Total execution time: 0.1453
DEBUG - 2022-04-27 01:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:18:31 --> Total execution time: 0.1190
DEBUG - 2022-04-27 01:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:18:33 --> Total execution time: 0.1782
DEBUG - 2022-04-27 01:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:18:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:18:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:18:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:18:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:18:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:18:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:19:15 --> Total execution time: 0.1931
DEBUG - 2022-04-27 01:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:19:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:19:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:19:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:19:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:19:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:19:16 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:19:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:19:16 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:19:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:19:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:19:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:19:16 --> Total execution time: 0.1823
DEBUG - 2022-04-27 01:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:19:28 --> Total execution time: 0.1370
DEBUG - 2022-04-27 01:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:19:28 --> Total execution time: 0.1412
DEBUG - 2022-04-27 01:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:20:28 --> Total execution time: 0.1633
DEBUG - 2022-04-27 01:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:20:29 --> Total execution time: 0.1594
DEBUG - 2022-04-27 01:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:20:33 --> Total execution time: 0.1287
DEBUG - 2022-04-27 01:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:20:33 --> Total execution time: 0.1025
DEBUG - 2022-04-27 01:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:52:37 --> Total execution time: 0.1164
DEBUG - 2022-04-27 01:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:52:38 --> Total execution time: 0.1399
DEBUG - 2022-04-27 01:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:22:41 --> Total execution time: 0.1358
DEBUG - 2022-04-27 01:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:22:41 --> Total execution time: 0.1749
DEBUG - 2022-04-27 01:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:52:44 --> Total execution time: 0.1207
DEBUG - 2022-04-27 01:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:52:45 --> Total execution time: 0.1125
DEBUG - 2022-04-27 01:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:22:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 04:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\esalestrix\application\controllers\User\Auth\UserAuth.php 47
DEBUG - 2022-04-27 01:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:52:52 --> Total execution time: 0.1316
DEBUG - 2022-04-27 01:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:52:56 --> Total execution time: 0.2190
DEBUG - 2022-04-27 01:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:53:11 --> Total execution time: 0.2979
DEBUG - 2022-04-27 01:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:55:47 --> Total execution time: 0.2345
DEBUG - 2022-04-27 01:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:55:52 --> Total execution time: 0.1605
DEBUG - 2022-04-27 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:26:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:26:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:26:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:56:07 --> Total execution time: 0.1946
DEBUG - 2022-04-27 01:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:08 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:26:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:56:29 --> Total execution time: 0.2378
DEBUG - 2022-04-27 01:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:26:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:26:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:56:35 --> Total execution time: 0.1834
DEBUG - 2022-04-27 01:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:26:35 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:26:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:26:36 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:26:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:26:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:26:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:26:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:56:37 --> Total execution time: 0.0952
DEBUG - 2022-04-27 01:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:57:00 --> Total execution time: 0.1007
DEBUG - 2022-04-27 01:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:59:30 --> Total execution time: 0.1291
DEBUG - 2022-04-27 01:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:59:38 --> Total execution time: 0.1120
DEBUG - 2022-04-27 01:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:59:46 --> Total execution time: 0.1441
DEBUG - 2022-04-27 01:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:00:10 --> Total execution time: 0.0955
DEBUG - 2022-04-27 01:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:00:12 --> Total execution time: 0.1443
DEBUG - 2022-04-27 01:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:00:42 --> Total execution time: 0.2005
DEBUG - 2022-04-27 01:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:00:56 --> Total execution time: 0.1071
DEBUG - 2022-04-27 01:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:01:13 --> Total execution time: 0.0947
DEBUG - 2022-04-27 01:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:01:16 --> Total execution time: 0.1234
DEBUG - 2022-04-27 01:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:02:04 --> Total execution time: 0.1326
DEBUG - 2022-04-27 01:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:02:07 --> Total execution time: 0.1036
DEBUG - 2022-04-27 01:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:03:38 --> Total execution time: 0.1723
DEBUG - 2022-04-27 01:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:04:00 --> Total execution time: 0.0970
DEBUG - 2022-04-27 01:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:04:26 --> Total execution time: 0.1337
DEBUG - 2022-04-27 01:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:35:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:35:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:35:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:35:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:35:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:35:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:35:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:35:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:05:48 --> Total execution time: 0.1697
DEBUG - 2022-04-27 01:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:35:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:35:49 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:35:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:35:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:35:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:35:49 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:35:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:35:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:35:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:35:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:06:40 --> Total execution time: 0.1541
DEBUG - 2022-04-27 01:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:36:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:41 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:36:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:36:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:36:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:42 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:36:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:36:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:36:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:36:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:06:53 --> Total execution time: 0.0980
DEBUG - 2022-04-27 01:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:36:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:36:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:36:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:54 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:36:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:36:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:36:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:36:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:36:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:06:57 --> Total execution time: 0.0899
DEBUG - 2022-04-27 01:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:36:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:36:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:36:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:36:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:36:58 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:36:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:36:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:06:58 --> Total execution time: 0.1614
DEBUG - 2022-04-27 01:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:07:04 --> Total execution time: 0.1073
DEBUG - 2022-04-27 01:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:07:04 --> Total execution time: 0.1269
DEBUG - 2022-04-27 01:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:37:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 05:07:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\esalestrix\application\controllers\User\Auth\UserAuth.php 47
DEBUG - 2022-04-27 01:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:07:21 --> Total execution time: 0.1297
DEBUG - 2022-04-27 01:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:07:24 --> Total execution time: 0.0985
DEBUG - 2022-04-27 01:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:07:34 --> Total execution time: 0.0945
DEBUG - 2022-04-27 01:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:08:17 --> Total execution time: 0.0957
DEBUG - 2022-04-27 01:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:08:26 --> Total execution time: 0.1345
DEBUG - 2022-04-27 01:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:08:33 --> Total execution time: 0.0944
DEBUG - 2022-04-27 01:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:08:33 --> Total execution time: 0.1310
DEBUG - 2022-04-27 01:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:38:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 05:08:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\esalestrix\application\controllers\User\Auth\UserAuth.php 47
DEBUG - 2022-04-27 01:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:08:39 --> Total execution time: 0.1145
DEBUG - 2022-04-27 01:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:08:43 --> Total execution time: 0.1077
DEBUG - 2022-04-27 01:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:08:52 --> Total execution time: 0.0919
DEBUG - 2022-04-27 01:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:09:01 --> Total execution time: 0.0931
DEBUG - 2022-04-27 01:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:09:05 --> Total execution time: 0.0964
DEBUG - 2022-04-27 01:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:09:18 --> Total execution time: 0.0985
DEBUG - 2022-04-27 01:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:09:21 --> Total execution time: 0.0940
DEBUG - 2022-04-27 01:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:09:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 01:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:09:28 --> Total execution time: 0.0868
DEBUG - 2022-04-27 01:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:09:32 --> Total execution time: 0.1389
DEBUG - 2022-04-27 01:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:09:49 --> Total execution time: 0.0974
DEBUG - 2022-04-27 01:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:09:50 --> Total execution time: 0.1205
DEBUG - 2022-04-27 01:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:09:51 --> Total execution time: 0.1663
DEBUG - 2022-04-27 01:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:09:52 --> Total execution time: 0.1840
DEBUG - 2022-04-27 01:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:40:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 05:10:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\esalestrix\application\controllers\User\Auth\UserAuth.php 47
DEBUG - 2022-04-27 01:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:10:11 --> Total execution time: 0.1231
DEBUG - 2022-04-27 01:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:40:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:10:15 --> Total execution time: 0.1916
DEBUG - 2022-04-27 01:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:10:49 --> Total execution time: 0.0932
DEBUG - 2022-04-27 01:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:40:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:40:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:40:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:40:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:40:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:40:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:40:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:40:50 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:40:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:10:50 --> Total execution time: 0.2202
DEBUG - 2022-04-27 01:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:40:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:40:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:40:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:40:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:40:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:40:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:40:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:40:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:11:08 --> Total execution time: 0.2459
DEBUG - 2022-04-27 01:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:41:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:41:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:41:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:41:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:41:09 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:41:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:41:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:41:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:11:09 --> Total execution time: 0.2026
DEBUG - 2022-04-27 01:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:11:10 --> Total execution time: 0.1448
DEBUG - 2022-04-27 01:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:41:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:41:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:41:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:41:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:41:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:41:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:41:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:11:11 --> Total execution time: 0.1649
DEBUG - 2022-04-27 01:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:41:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:11:18 --> Total execution time: 0.1254
DEBUG - 2022-04-27 01:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:18 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:41:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:41:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:41:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:41:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:41:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:41:19 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:41:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:11:19 --> Total execution time: 0.1551
DEBUG - 2022-04-27 01:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:12:09 --> Total execution time: 0.1628
DEBUG - 2022-04-27 01:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:42:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:42:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:42:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:42:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:42:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:42:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:42:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:12:10 --> Total execution time: 0.2175
DEBUG - 2022-04-27 01:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:12:14 --> Total execution time: 0.1385
DEBUG - 2022-04-27 01:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:12:15 --> Total execution time: 0.1222
DEBUG - 2022-04-27 01:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:12:21 --> Total execution time: 0.1268
DEBUG - 2022-04-27 01:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:12:21 --> Total execution time: 0.1175
DEBUG - 2022-04-27 01:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 05:12:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\esalestrix\application\controllers\User\Auth\UserAuth.php 47
DEBUG - 2022-04-27 01:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:12:35 --> Total execution time: 0.1226
DEBUG - 2022-04-27 01:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:12:40 --> Total execution time: 0.0996
DEBUG - 2022-04-27 01:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:12:41 --> Total execution time: 0.1613
DEBUG - 2022-04-27 01:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:42:42 --> Total execution time: 0.1408
DEBUG - 2022-04-27 01:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:42:43 --> Total execution time: 0.1405
DEBUG - 2022-04-27 01:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:43:37 --> UTF-8 Support Enabled
ERROR - 2022-04-27 01:43:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:43:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:43:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:43:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:43:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-27 01:43:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:45:27 --> Total execution time: 0.1968
DEBUG - 2022-04-27 01:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:45:28 --> Total execution time: 0.1343
DEBUG - 2022-04-27 01:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:45:49 --> Total execution time: 0.1833
DEBUG - 2022-04-27 01:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:45:50 --> Total execution time: 0.1065
DEBUG - 2022-04-27 01:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:16:07 --> Total execution time: 0.1247
DEBUG - 2022-04-27 01:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:48:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:48:43 --> 404 Page Not Found: User-login/index
DEBUG - 2022-04-27 01:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:18:47 --> Total execution time: 0.7212
DEBUG - 2022-04-27 01:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:18:49 --> Total execution time: 0.0281
DEBUG - 2022-04-27 01:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:48:59 --> Total execution time: 0.0324
DEBUG - 2022-04-27 01:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:19:08 --> Total execution time: 0.0855
DEBUG - 2022-04-27 01:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:19:17 --> Total execution time: 0.0365
DEBUG - 2022-04-27 01:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:19:18 --> Total execution time: 0.0283
DEBUG - 2022-04-27 01:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:19:19 --> Total execution time: 0.0591
DEBUG - 2022-04-27 01:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:19:37 --> Total execution time: 0.0314
DEBUG - 2022-04-27 01:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:19:37 --> Total execution time: 0.0280
DEBUG - 2022-04-27 01:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 01:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:19:55 --> Total execution time: 0.0848
DEBUG - 2022-04-27 01:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:50:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:50:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:50:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:50:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:50:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:50:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:50:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 01:50:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 01:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 01:50:18 --> No URI present. Default controller set.
DEBUG - 2022-04-27 01:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 01:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 02:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 02:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:30:41 --> Total execution time: 0.0631
DEBUG - 2022-04-27 02:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:00:53 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 02:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 02:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:30:59 --> Total execution time: 0.0327
DEBUG - 2022-04-27 02:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 02:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:31:10 --> Total execution time: 0.0288
DEBUG - 2022-04-27 02:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:31:11 --> Total execution time: 0.0293
DEBUG - 2022-04-27 02:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:31:13 --> Total execution time: 0.0284
DEBUG - 2022-04-27 02:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 02:01:14 --> 404 Page Not Found: Dummy/assets
DEBUG - 2022-04-27 02:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 02:01:15 --> 404 Page Not Found: Dummy/assets
DEBUG - 2022-04-27 02:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 02:01:15 --> 404 Page Not Found: Dummy/assets
DEBUG - 2022-04-27 02:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 02:01:15 --> 404 Page Not Found: Dummy/assets
DEBUG - 2022-04-27 02:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 02:01:15 --> 404 Page Not Found: Dummy/assets
DEBUG - 2022-04-27 02:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 02:01:15 --> 404 Page Not Found: Dummy/assets
DEBUG - 2022-04-27 02:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 02:01:16 --> 404 Page Not Found: Dummy/assets
DEBUG - 2022-04-27 02:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 02:01:16 --> 404 Page Not Found: Dummy/assets
DEBUG - 2022-04-27 02:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 02:01:17 --> 404 Page Not Found: Dummy/assets
DEBUG - 2022-04-27 02:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 02:01:17 --> 404 Page Not Found: Dummy/assets
DEBUG - 2022-04-27 02:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 02:01:17 --> 404 Page Not Found: Dummy/assets
DEBUG - 2022-04-27 02:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 02:01:17 --> 404 Page Not Found: Dummy/assets
DEBUG - 2022-04-27 02:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 02:01:17 --> 404 Page Not Found: Dummy/assets
DEBUG - 2022-04-27 02:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:01:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 02:01:18 --> 404 Page Not Found: Dummy/assets
DEBUG - 2022-04-27 02:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:35:32 --> Total execution time: 0.7794
DEBUG - 2022-04-27 02:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:39:39 --> Total execution time: 0.8221
DEBUG - 2022-04-27 02:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:40:09 --> Total execution time: 0.8329
DEBUG - 2022-04-27 02:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:41:12 --> Total execution time: 0.1257
DEBUG - 2022-04-27 02:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:41:39 --> Total execution time: 0.0277
DEBUG - 2022-04-27 02:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:42:28 --> Total execution time: 0.7748
DEBUG - 2022-04-27 02:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:44:07 --> Total execution time: 0.7791
DEBUG - 2022-04-27 02:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:49:01 --> Total execution time: 1.0943
DEBUG - 2022-04-27 02:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:50:57 --> Total execution time: 0.8087
DEBUG - 2022-04-27 02:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:51:21 --> Total execution time: 0.0295
DEBUG - 2022-04-27 02:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:52:00 --> Total execution time: 0.7789
DEBUG - 2022-04-27 02:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 07:54:39 --> Total execution time: 0.8291
DEBUG - 2022-04-27 02:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:31:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 02:31:59 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 02:31:59 --> Total execution time: 1.0531
DEBUG - 2022-04-27 02:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 08:02:16 --> Total execution time: 0.0441
DEBUG - 2022-04-27 02:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:32:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 02:32:18 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 02:32:19 --> Total execution time: 0.0300
DEBUG - 2022-04-27 02:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:32:29 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 02:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 08:03:38 --> Total execution time: 0.7971
DEBUG - 2022-04-27 02:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:33:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 02:33:49 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 02:33:49 --> Total execution time: 0.3060
DEBUG - 2022-04-27 02:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 02:34:08 --> Total execution time: 0.7931
DEBUG - 2022-04-27 02:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:34:17 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 08:04:18 --> Total execution time: 0.7976
DEBUG - 2022-04-27 02:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:36:27 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:36:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:06:28 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:06:28 --> Total execution time: 1.0971
DEBUG - 2022-04-27 02:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 02:37:50 --> Total execution time: 0.1824
DEBUG - 2022-04-27 02:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:37:53 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:37:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:07:53 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:07:53 --> Total execution time: 0.0349
DEBUG - 2022-04-27 02:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:39:00 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:39:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:09:00 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:09:00 --> Total execution time: 0.1349
DEBUG - 2022-04-27 02:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:41:15 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:41:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:11:16 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:11:16 --> Total execution time: 0.8052
DEBUG - 2022-04-27 02:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:42:35 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:42:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:12:36 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:12:36 --> Total execution time: 0.8061
DEBUG - 2022-04-27 02:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:42:53 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:42:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:12:54 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:12:54 --> Total execution time: 0.5244
DEBUG - 2022-04-27 02:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:43:50 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:43:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:13:50 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:13:50 --> Total execution time: 0.6542
DEBUG - 2022-04-27 02:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:44:16 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:44:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:14:16 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:14:16 --> Total execution time: 0.2858
DEBUG - 2022-04-27 02:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:44:43 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:44:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:14:43 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:14:43 --> Total execution time: 0.0298
DEBUG - 2022-04-27 02:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:45:41 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:45:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:15:41 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:15:41 --> Total execution time: 0.8291
DEBUG - 2022-04-27 02:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:45:54 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:45:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:15:54 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:15:54 --> Total execution time: 0.0413
DEBUG - 2022-04-27 02:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:48:26 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:48:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:18:26 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:18:26 --> Total execution time: 0.7971
DEBUG - 2022-04-27 02:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:51:45 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:51:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:21:46 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:21:46 --> Total execution time: 0.8011
DEBUG - 2022-04-27 02:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:52:05 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:52:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:22:05 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:22:05 --> Total execution time: 0.0340
DEBUG - 2022-04-27 02:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:52:29 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:52:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:22:29 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:22:29 --> Total execution time: 0.0303
DEBUG - 2022-04-27 02:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:53:09 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:53:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:23:09 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:23:09 --> Total execution time: 0.0325
DEBUG - 2022-04-27 02:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:54:44 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:54:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:24:44 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:24:44 --> Total execution time: 0.0325
DEBUG - 2022-04-27 02:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:55:54 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:55:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:25:54 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:25:54 --> Total execution time: 0.0300
DEBUG - 2022-04-27 02:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:56:46 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:56:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:26:46 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:26:46 --> Total execution time: 0.0316
DEBUG - 2022-04-27 02:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 02:58:04 --> Total execution time: 0.0357
DEBUG - 2022-04-27 02:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 02:59:26 --> No URI present. Default controller set.
DEBUG - 2022-04-27 02:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 02:59:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:29:26 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:29:26 --> Total execution time: 0.0333
DEBUG - 2022-04-27 03:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:00:38 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:00:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:30:39 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:30:39 --> Total execution time: 0.8279
DEBUG - 2022-04-27 03:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:03:25 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:03:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:33:25 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:33:25 --> Total execution time: 0.0298
DEBUG - 2022-04-27 03:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:08:24 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:08:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:38:25 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:38:25 --> Total execution time: 0.8051
DEBUG - 2022-04-27 03:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:09:24 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:09:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:39:24 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:39:24 --> Total execution time: 0.0283
DEBUG - 2022-04-27 03:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:10:10 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:10:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:40:10 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:40:10 --> Total execution time: 0.0466
DEBUG - 2022-04-27 03:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:14:47 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:14:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:44:48 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:44:48 --> Total execution time: 0.8132
DEBUG - 2022-04-27 03:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:15:14 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:15:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:45:14 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:45:14 --> Total execution time: 0.0278
DEBUG - 2022-04-27 03:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:15:31 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:15:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:45:31 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:45:31 --> Total execution time: 0.0290
DEBUG - 2022-04-27 03:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:15:57 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:15:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:45:58 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:45:58 --> Total execution time: 0.0275
DEBUG - 2022-04-27 03:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:18:43 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:18:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:48:44 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:48:44 --> Total execution time: 0.5481
DEBUG - 2022-04-27 03:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:19:17 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:19:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:49:17 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:49:17 --> Total execution time: 0.0276
DEBUG - 2022-04-27 03:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:22:56 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:22:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:52:57 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:52:57 --> Total execution time: 0.8132
DEBUG - 2022-04-27 03:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:23:50 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:23:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:53:50 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:53:50 --> Total execution time: 0.0288
DEBUG - 2022-04-27 03:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:24:23 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:24:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:54:23 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:54:23 --> Total execution time: 0.0372
DEBUG - 2022-04-27 03:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:26:16 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:26:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:56:16 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:56:16 --> Total execution time: 0.0297
DEBUG - 2022-04-27 03:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:26:39 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:26:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:56:39 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:56:39 --> Total execution time: 0.0300
DEBUG - 2022-04-27 03:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:27:47 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:27:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 08:57:47 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 08:57:47 --> Total execution time: 0.0305
DEBUG - 2022-04-27 03:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:33:14 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:33:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 09:03:14 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 09:03:14 --> Total execution time: 0.0332
DEBUG - 2022-04-27 03:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:36:17 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:36:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 09:06:17 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 09:06:17 --> Total execution time: 0.2932
DEBUG - 2022-04-27 04:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:00:31 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:00:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 09:30:32 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 09:30:32 --> Total execution time: 0.8011
DEBUG - 2022-04-27 04:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:02:03 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:02:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 09:32:03 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 09:32:03 --> Total execution time: 0.0303
DEBUG - 2022-04-27 04:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:02:39 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:02:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 09:32:39 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 09:32:39 --> Total execution time: 0.0298
DEBUG - 2022-04-27 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:03:23 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:03:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 09:33:23 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 09:33:23 --> Total execution time: 0.0322
DEBUG - 2022-04-27 04:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:03:42 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:03:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 09:33:42 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 09:33:42 --> Total execution time: 0.0328
DEBUG - 2022-04-27 04:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:06:27 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:06:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 09:36:27 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 09:36:27 --> Total execution time: 0.0312
DEBUG - 2022-04-27 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:07:16 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:07:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 09:37:16 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 09:37:16 --> Total execution time: 0.0300
DEBUG - 2022-04-27 04:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:08:24 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:08:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 09:38:24 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 09:38:24 --> Total execution time: 0.0286
DEBUG - 2022-04-27 04:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:09:11 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 09:39:11 --> Total execution time: 0.0288
DEBUG - 2022-04-27 04:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:09:26 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 09:39:26 --> Total execution time: 0.0283
DEBUG - 2022-04-27 04:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:14:21 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 09:44:21 --> Total execution time: 0.2793
DEBUG - 2022-04-27 04:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:14:58 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 09:44:58 --> Total execution time: 0.0283
DEBUG - 2022-04-27 04:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:15:42 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 09:45:42 --> Total execution time: 0.0272
DEBUG - 2022-04-27 04:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:16:10 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 09:46:10 --> Total execution time: 0.0283
DEBUG - 2022-04-27 04:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:17:04 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 09:47:04 --> Total execution time: 0.0278
DEBUG - 2022-04-27 04:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:17:59 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 09:47:59 --> Total execution time: 0.0289
DEBUG - 2022-04-27 04:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:22:30 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 09:52:30 --> Total execution time: 0.8471
DEBUG - 2022-04-27 04:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:23:49 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 09:53:49 --> Total execution time: 0.0293
DEBUG - 2022-04-27 04:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:31:08 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:01:09 --> Total execution time: 0.7891
DEBUG - 2022-04-27 04:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:32:23 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:02:23 --> Total execution time: 0.0299
DEBUG - 2022-04-27 04:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:32:48 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:02:48 --> Total execution time: 0.0276
DEBUG - 2022-04-27 04:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:33:06 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:03:06 --> Total execution time: 0.0304
DEBUG - 2022-04-27 04:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:33:20 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:03:20 --> Total execution time: 0.0274
DEBUG - 2022-04-27 04:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:33:44 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:03:45 --> Total execution time: 0.0289
DEBUG - 2022-04-27 04:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:40:07 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:10:07 --> Total execution time: 0.7891
DEBUG - 2022-04-27 04:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:40:33 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:10:33 --> Total execution time: 0.0282
DEBUG - 2022-04-27 04:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:42:27 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:12:27 --> Total execution time: 0.0279
DEBUG - 2022-04-27 04:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:43:19 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:13:19 --> Total execution time: 0.0284
DEBUG - 2022-04-27 04:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:43:25 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:13:25 --> Total execution time: 0.0294
DEBUG - 2022-04-27 04:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:44:00 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:14:00 --> Total execution time: 0.0402
DEBUG - 2022-04-27 04:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:44:22 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:14:22 --> Total execution time: 0.0292
DEBUG - 2022-04-27 04:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:44:27 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:14:28 --> Total execution time: 0.0298
DEBUG - 2022-04-27 04:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:58:36 --> No URI present. Default controller set.
DEBUG - 2022-04-27 04:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:28:37 --> Total execution time: 0.8321
DEBUG - 2022-04-27 04:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 04:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:28:39 --> Total execution time: 0.2351
DEBUG - 2022-04-27 04:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:28:39 --> Total execution time: 0.0299
DEBUG - 2022-04-27 04:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:28:44 --> Total execution time: 0.0653
DEBUG - 2022-04-27 05:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:00:01 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:30:02 --> Total execution time: 1.1532
DEBUG - 2022-04-27 05:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:33:03 --> Upload class already loaded. Second attempt ignored.
ERROR - 2022-04-27 10:33:03 --> Query error: Unknown column 'product_created' in 'field list' - Invalid query: INSERT INTO `products` (`product_name`, `product_price`, `product_discount`, `product_status`, `product_overview`, `product_details`, `product_imgage`, `product_imgage_path`, `product_slug`, `product_created`) VALUES ('BASIC PACKAGE', '1580', '0', '1', '<ul>\r\n<li><i class=\"ri-check-line\"></i> BASIC PACKAGE</li>\r\n<li><i class=\"ri-check-line\"></i> LEAD GENERATION COURSE ACCESS</li>\r\n<li><i class=\"ri-check-line\"></i> SELL COURSE ACCESS</li>\r\n<li><i class=\"ri-check-line\"></i> FIRST TIER COMMISSION IS 1000</li>\r\n<li><i class=\"ri-check-line\"></i> SECOND TIER COMMISSION IS 170</li>\r\n</ul>', '<p>no</p>', 'rheboj9p071651035783.jpeg', 'assets/course_feature_images/rheboj9p071651035783.jpeg', 'basic-package', '2022-04-27 10:33:03')
DEBUG - 2022-04-27 05:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:34:53 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 05:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:34:54 --> Total execution time: 0.0568
DEBUG - 2022-04-27 05:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:34:57 --> Total execution time: 0.0370
DEBUG - 2022-04-27 05:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:35:16 --> Total execution time: 0.0296
DEBUG - 2022-04-27 05:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:37:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 05:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:37:18 --> Total execution time: 0.0550
DEBUG - 2022-04-27 05:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:38:46 --> Total execution time: 0.0516
DEBUG - 2022-04-27 05:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:40:32 --> Total execution time: 0.0780
DEBUG - 2022-04-27 05:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:41:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 05:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:41:08 --> Total execution time: 0.0829
DEBUG - 2022-04-27 05:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:41:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 05:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:41:50 --> Total execution time: 0.0530
DEBUG - 2022-04-27 05:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:41:51 --> Total execution time: 0.0290
DEBUG - 2022-04-27 05:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:13:12 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:43:13 --> Total execution time: 0.8144
DEBUG - 2022-04-27 05:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:16:07 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:46:07 --> Total execution time: 0.7911
DEBUG - 2022-04-27 05:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:20:54 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:50:55 --> Total execution time: 0.8120
DEBUG - 2022-04-27 05:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:21:33 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:51:33 --> Total execution time: 0.8321
DEBUG - 2022-04-27 05:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:23:18 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:53:19 --> Total execution time: 0.8251
DEBUG - 2022-04-27 05:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:24:13 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:54:14 --> Total execution time: 0.9681
DEBUG - 2022-04-27 05:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:24:35 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:54:36 --> Total execution time: 0.7931
DEBUG - 2022-04-27 05:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:25:59 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:56:00 --> Total execution time: 0.7921
DEBUG - 2022-04-27 05:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:57:03 --> Total execution time: 1.2496
DEBUG - 2022-04-27 05:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:57:04 --> Total execution time: 0.0335
DEBUG - 2022-04-27 05:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:57:08 --> Total execution time: 0.0303
DEBUG - 2022-04-27 05:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 10:59:36 --> Total execution time: 1.0051
DEBUG - 2022-04-27 05:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:00:14 --> Total execution time: 0.0319
DEBUG - 2022-04-27 05:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:01:09 --> Total execution time: 0.0301
DEBUG - 2022-04-27 05:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:31:13 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:01:13 --> Total execution time: 0.0399
DEBUG - 2022-04-27 05:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:02:06 --> Total execution time: 0.0443
DEBUG - 2022-04-27 05:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:02:13 --> Total execution time: 0.0397
DEBUG - 2022-04-27 05:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:02:33 --> Total execution time: 0.0309
DEBUG - 2022-04-27 05:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:32:38 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:02:38 --> Total execution time: 0.0295
DEBUG - 2022-04-27 05:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:32:46 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:02:46 --> Total execution time: 0.0389
DEBUG - 2022-04-27 05:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:03:05 --> Total execution time: 0.0323
DEBUG - 2022-04-27 05:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:33:08 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:03:08 --> Total execution time: 0.0285
DEBUG - 2022-04-27 05:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:33:30 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:03:30 --> Total execution time: 0.0301
DEBUG - 2022-04-27 05:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:33:38 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:03:38 --> Total execution time: 0.0282
DEBUG - 2022-04-27 05:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:33:41 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:03:41 --> Total execution time: 0.0335
DEBUG - 2022-04-27 05:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:34:01 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:04:01 --> Total execution time: 0.0313
DEBUG - 2022-04-27 05:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:38:43 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:08:43 --> Total execution time: 0.0324
DEBUG - 2022-04-27 05:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:39:58 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:09:58 --> Total execution time: 0.0301
DEBUG - 2022-04-27 05:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 05:40:35 --> Total execution time: 0.0298
DEBUG - 2022-04-27 05:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 05:40:36 --> No URI present. Default controller set.
DEBUG - 2022-04-27 05:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 05:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:10:36 --> Total execution time: 0.0345
DEBUG - 2022-04-27 07:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:28:22 --> No URI present. Default controller set.
DEBUG - 2022-04-27 07:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:58:23 --> Total execution time: 1.0351
DEBUG - 2022-04-27 11:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:05:53 --> No URI present. Default controller set.
DEBUG - 2022-04-27 11:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:35:54 --> Total execution time: 1.0392
DEBUG - 2022-04-27 11:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:37:43 --> Total execution time: 0.0531
DEBUG - 2022-04-27 11:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:37:48 --> Total execution time: 0.0299
DEBUG - 2022-04-27 11:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:39:18 --> Total execution time: 0.0321
DEBUG - 2022-04-27 11:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:11:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 16:41:02 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 16:41:02 --> Total execution time: 0.3554
DEBUG - 2022-04-27 11:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:11:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 16:41:19 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 16:41:19 --> Total execution time: 0.0299
DEBUG - 2022-04-27 11:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:11:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 16:41:39 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 16:41:39 --> Total execution time: 0.0296
DEBUG - 2022-04-27 11:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:11:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 16:41:43 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 16:41:43 --> Total execution time: 0.0284
DEBUG - 2022-04-27 11:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:11:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 16:41:49 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 16:41:49 --> Total execution time: 0.0305
DEBUG - 2022-04-27 11:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:11:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 16:41:53 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 16:41:53 --> Total execution time: 0.0328
DEBUG - 2022-04-27 11:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:12:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 16:42:04 --> Severity: Notice --> Undefined variable: pageTitle /home/gvprods/public_html/v1/gvv3/application/views/Front/inc/stylesheet.php 5
DEBUG - 2022-04-27 16:42:04 --> Total execution time: 0.0316
DEBUG - 2022-04-27 11:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:42:49 --> Total execution time: 0.0297
DEBUG - 2022-04-27 11:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:43:07 --> Total execution time: 0.0309
DEBUG - 2022-04-27 11:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:44:22 --> Total execution time: 0.0308
DEBUG - 2022-04-27 11:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:46:14 --> Total execution time: 0.0303
DEBUG - 2022-04-27 11:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:46:49 --> Total execution time: 0.7931
DEBUG - 2022-04-27 11:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 11:16:56 --> 404 Page Not Found: User/assets
DEBUG - 2022-04-27 11:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 11:16:57 --> 404 Page Not Found: User/assets
DEBUG - 2022-04-27 11:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:17:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 11:17:04 --> 404 Page Not Found: User/assets
DEBUG - 2022-04-27 11:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:47:28 --> Total execution time: 0.0283
DEBUG - 2022-04-27 11:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:17:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 11:17:38 --> 404 Page Not Found: User/assets
DEBUG - 2022-04-27 11:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 11:17:45 --> 404 Page Not Found: User/assets
DEBUG - 2022-04-27 11:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:48:15 --> Total execution time: 0.0297
DEBUG - 2022-04-27 11:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:48:23 --> Total execution time: 0.0308
DEBUG - 2022-04-27 11:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:48:36 --> Total execution time: 0.0829
DEBUG - 2022-04-27 11:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:48:43 --> Total execution time: 0.0295
DEBUG - 2022-04-27 11:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:49:42 --> Total execution time: 0.0286
DEBUG - 2022-04-27 11:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:50:15 --> Total execution time: 0.3568
DEBUG - 2022-04-27 11:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:50:40 --> Total execution time: 0.0281
DEBUG - 2022-04-27 11:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:50:49 --> Total execution time: 0.0290
DEBUG - 2022-04-27 11:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:50:57 --> Total execution time: 0.0289
DEBUG - 2022-04-27 11:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:21:00 --> Total execution time: 0.0519
DEBUG - 2022-04-27 11:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:21:01 --> Total execution time: 0.0391
DEBUG - 2022-04-27 11:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:25:16 --> No URI present. Default controller set.
DEBUG - 2022-04-27 11:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:55:16 --> Total execution time: 0.0779
DEBUG - 2022-04-27 11:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:26:34 --> No URI present. Default controller set.
DEBUG - 2022-04-27 11:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:56:34 --> Total execution time: 0.2343
DEBUG - 2022-04-27 11:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:30:17 --> No URI present. Default controller set.
DEBUG - 2022-04-27 11:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:00:17 --> Total execution time: 0.5235
DEBUG - 2022-04-27 11:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:31:01 --> No URI present. Default controller set.
DEBUG - 2022-04-27 11:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:01:01 --> Total execution time: 0.0290
DEBUG - 2022-04-27 11:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:31:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 11:31:12 --> 404 Page Not Found: Registration-with-package/index
DEBUG - 2022-04-27 11:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:32:25 --> No URI present. Default controller set.
DEBUG - 2022-04-27 11:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:02:25 --> Total execution time: 0.0291
DEBUG - 2022-04-27 11:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:32:42 --> No URI present. Default controller set.
DEBUG - 2022-04-27 11:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:02:42 --> Total execution time: 0.0293
DEBUG - 2022-04-27 11:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:34:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 11:34:52 --> Severity: Notice --> Undefined property: RegistrationController::$Products /home/gvprods/public_html/v1/gvv3/application/controllers/User/RegistrationController.php 55
ERROR - 2022-04-27 11:34:52 --> Severity: error --> Exception: Call to a member function check() on null /home/gvprods/public_html/v1/gvv3/application/controllers/User/RegistrationController.php 55
ERROR - 2022-04-27 11:34:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/core/Common.php 564
DEBUG - 2022-04-27 11:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:35:07 --> Total execution time: 0.0280
DEBUG - 2022-04-27 11:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:36:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 11:36:54 --> Severity: Notice --> Undefined variable: Affilator_Data /home/gvprods/public_html/v1/gvv3/application/views/User/registration.php 67
ERROR - 2022-04-27 11:36:54 --> Severity: Notice --> Trying to get property 'ul_generate_id' of non-object /home/gvprods/public_html/v1/gvv3/application/views/User/registration.php 67
ERROR - 2022-04-27 11:36:54 --> Severity: Notice --> Undefined variable: Affilator_Data /home/gvprods/public_html/v1/gvv3/application/views/User/registration.php 68
ERROR - 2022-04-27 11:36:54 --> Severity: Notice --> Trying to get property 'ul_generate_id' of non-object /home/gvprods/public_html/v1/gvv3/application/views/User/registration.php 68
DEBUG - 2022-04-27 11:36:54 --> Total execution time: 0.0292
DEBUG - 2022-04-27 11:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:36:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 11:36:55 --> Severity: Notice --> Undefined variable: Affilator_Data /home/gvprods/public_html/v1/gvv3/application/views/User/registration.php 67
ERROR - 2022-04-27 11:36:55 --> Severity: Notice --> Trying to get property 'ul_generate_id' of non-object /home/gvprods/public_html/v1/gvv3/application/views/User/registration.php 67
ERROR - 2022-04-27 11:36:55 --> Severity: Notice --> Undefined variable: Affilator_Data /home/gvprods/public_html/v1/gvv3/application/views/User/registration.php 68
ERROR - 2022-04-27 11:36:55 --> Severity: Notice --> Trying to get property 'ul_generate_id' of non-object /home/gvprods/public_html/v1/gvv3/application/views/User/registration.php 68
DEBUG - 2022-04-27 11:36:55 --> Total execution time: 0.0295
DEBUG - 2022-04-27 11:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:37:38 --> Total execution time: 0.0537
DEBUG - 2022-04-27 11:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:38:10 --> Total execution time: 0.0282
DEBUG - 2022-04-27 11:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:42:22 --> Total execution time: 0.8051
DEBUG - 2022-04-27 11:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:42:51 --> Total execution time: 0.0294
DEBUG - 2022-04-27 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:43:48 --> Total execution time: 0.0297
DEBUG - 2022-04-27 11:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:45:37 --> Total execution time: 0.0361
DEBUG - 2022-04-27 11:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:48:52 --> Total execution time: 0.0318
DEBUG - 2022-04-27 11:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:49:19 --> Total execution time: 0.0328
DEBUG - 2022-04-27 11:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:50:04 --> Total execution time: 0.0334
DEBUG - 2022-04-27 11:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:51:00 --> Total execution time: 0.7436
DEBUG - 2022-04-27 11:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:51:04 --> Total execution time: 0.0292
DEBUG - 2022-04-27 11:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:51:13 --> Total execution time: 0.0344
DEBUG - 2022-04-27 11:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:51:23 --> Total execution time: 0.0287
DEBUG - 2022-04-27 11:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:51:28 --> Total execution time: 0.0287
DEBUG - 2022-04-27 11:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:52:23 --> Total execution time: 0.0284
DEBUG - 2022-04-27 11:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:52:26 --> Total execution time: 0.0291
DEBUG - 2022-04-27 11:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:53:00 --> Total execution time: 0.0293
DEBUG - 2022-04-27 11:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:53:02 --> Total execution time: 0.0311
DEBUG - 2022-04-27 11:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:53:38 --> Total execution time: 0.0286
DEBUG - 2022-04-27 11:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:53:41 --> Total execution time: 0.0300
DEBUG - 2022-04-27 11:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:53:51 --> Total execution time: 0.0355
DEBUG - 2022-04-27 11:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 11:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 11:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 11:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:00:51 --> Total execution time: 0.0284
DEBUG - 2022-04-27 12:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:00:52 --> Total execution time: 0.0320
DEBUG - 2022-04-27 12:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:31:13 --> Total execution time: 0.0557
DEBUG - 2022-04-27 12:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:31:21 --> Total execution time: 0.0438
DEBUG - 2022-04-27 12:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:01:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 12:01:32 --> 404 Page Not Found: User/signup.html
DEBUG - 2022-04-27 12:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:31:35 --> Total execution time: 0.0284
DEBUG - 2022-04-27 12:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:01:39 --> No URI present. Default controller set.
DEBUG - 2022-04-27 12:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:31:39 --> Total execution time: 0.0370
DEBUG - 2022-04-27 12:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:01:59 --> Total execution time: 0.0387
DEBUG - 2022-04-27 12:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:02:36 --> Total execution time: 0.0282
DEBUG - 2022-04-27 12:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:02:37 --> Total execution time: 0.0284
DEBUG - 2022-04-27 12:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:32:49 --> Total execution time: 0.0312
DEBUG - 2022-04-27 12:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:32:55 --> Total execution time: 0.0300
DEBUG - 2022-04-27 12:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:33:20 --> Total execution time: 0.0420
DEBUG - 2022-04-27 12:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:33:24 --> Total execution time: 0.0358
DEBUG - 2022-04-27 12:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:03:56 --> No URI present. Default controller set.
DEBUG - 2022-04-27 12:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:33:56 --> Total execution time: 0.0295
DEBUG - 2022-04-27 12:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:34:00 --> Total execution time: 0.0284
DEBUG - 2022-04-27 12:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:04:13 --> Total execution time: 0.0289
DEBUG - 2022-04-27 12:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:04:34 --> Total execution time: 0.0291
DEBUG - 2022-04-27 12:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:04:36 --> Total execution time: 0.0293
DEBUG - 2022-04-27 12:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:34:56 --> Total execution time: 0.0294
DEBUG - 2022-04-27 12:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:35:37 --> Total execution time: 0.0317
DEBUG - 2022-04-27 12:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:05:44 --> No URI present. Default controller set.
DEBUG - 2022-04-27 12:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:35:44 --> Total execution time: 0.0291
DEBUG - 2022-04-27 12:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:05:52 --> Total execution time: 0.0302
DEBUG - 2022-04-27 12:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:07:21 --> Total execution time: 0.0289
DEBUG - 2022-04-27 12:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:07:23 --> Total execution time: 0.0297
DEBUG - 2022-04-27 12:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:37:39 --> Total execution time: 0.0304
DEBUG - 2022-04-27 12:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:37:43 --> Total execution time: 0.0292
DEBUG - 2022-04-27 12:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 12:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:37:53 --> Total execution time: 0.0292
DEBUG - 2022-04-27 12:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 12:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 12:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:37:56 --> Total execution time: 0.0304
DEBUG - 2022-04-27 13:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:39:48 --> No URI present. Default controller set.
DEBUG - 2022-04-27 13:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:09:49 --> Total execution time: 1.1212
DEBUG - 2022-04-27 13:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:41:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 13:41:16 --> 404 Page Not Found: Signuphtml/index
DEBUG - 2022-04-27 13:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:41:18 --> No URI present. Default controller set.
DEBUG - 2022-04-27 13:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:11:18 --> Total execution time: 0.3226
DEBUG - 2022-04-27 13:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:41:36 --> No URI present. Default controller set.
DEBUG - 2022-04-27 13:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:11:36 --> Total execution time: 0.0338
DEBUG - 2022-04-27 13:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 13:41:42 --> Total execution time: 0.0381
DEBUG - 2022-04-27 13:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 13:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:11:54 --> Total execution time: 0.0841
DEBUG - 2022-04-27 13:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:11:58 --> Total execution time: 0.0677
DEBUG - 2022-04-27 13:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:12:26 --> Total execution time: 0.0306
DEBUG - 2022-04-27 13:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:12:34 --> Total execution time: 0.0323
DEBUG - 2022-04-27 13:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 13:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:12:41 --> Total execution time: 0.0881
DEBUG - 2022-04-27 13:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 13:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:43:00 --> No URI present. Default controller set.
DEBUG - 2022-04-27 13:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:13:00 --> Total execution time: 0.0289
DEBUG - 2022-04-27 13:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 13:43:12 --> Total execution time: 0.0344
DEBUG - 2022-04-27 13:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 13:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:43:42 --> No URI present. Default controller set.
DEBUG - 2022-04-27 13:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:13:42 --> Total execution time: 0.0352
DEBUG - 2022-04-27 13:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 13:43:47 --> Total execution time: 0.0315
DEBUG - 2022-04-27 13:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 13:48:22 --> Total execution time: 0.8211
DEBUG - 2022-04-27 13:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 13:48:35 --> No URI present. Default controller set.
DEBUG - 2022-04-27 13:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 13:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:18:35 --> Total execution time: 0.0297
DEBUG - 2022-04-27 14:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 14:12:08 --> Total execution time: 0.7971
DEBUG - 2022-04-27 14:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 14:12:43 --> Total execution time: 0.0314
DEBUG - 2022-04-27 14:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 14:12:54 --> Total execution time: 0.0325
DEBUG - 2022-04-27 14:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:12:59 --> No URI present. Default controller set.
DEBUG - 2022-04-27 14:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:42:59 --> Total execution time: 0.0379
DEBUG - 2022-04-27 14:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 14:13:06 --> Total execution time: 0.0298
DEBUG - 2022-04-27 14:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:16:53 --> No URI present. Default controller set.
DEBUG - 2022-04-27 14:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:46:53 --> Total execution time: 0.8039
DEBUG - 2022-04-27 14:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:17:53 --> No URI present. Default controller set.
DEBUG - 2022-04-27 14:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:47:53 --> Total execution time: 0.0279
DEBUG - 2022-04-27 14:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:18:00 --> No URI present. Default controller set.
DEBUG - 2022-04-27 14:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 19:48:00 --> Total execution time: 0.0349
DEBUG - 2022-04-27 14:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 14:18:29 --> Total execution time: 0.0345
DEBUG - 2022-04-27 14:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 14:20:30 --> Total execution time: 0.7468
DEBUG - 2022-04-27 14:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 14:34:03 --> Total execution time: 0.7901
DEBUG - 2022-04-27 14:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 14:35:01 --> Total execution time: 0.0293
DEBUG - 2022-04-27 14:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 14:35:02 --> Total execution time: 0.0285
DEBUG - 2022-04-27 14:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 14:35:18 --> Total execution time: 0.0314
DEBUG - 2022-04-27 14:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 14:35:20 --> Total execution time: 0.0283
DEBUG - 2022-04-27 14:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 14:38:13 --> Total execution time: 0.7552
DEBUG - 2022-04-27 14:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 14:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 14:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 14:38:15 --> Total execution time: 0.0285
DEBUG - 2022-04-27 15:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:06:04 --> Total execution time: 0.8511
DEBUG - 2022-04-27 15:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:06:05 --> Total execution time: 0.0297
DEBUG - 2022-04-27 15:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:06:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 15:06:06 --> Severity: Notice --> Trying to get property 'setting_gst' of non-object /home/gvprods/public_html/v1/gvv3/application/helpers/project_helper.php 86
DEBUG - 2022-04-27 15:06:06 --> Total execution time: 0.0786
DEBUG - 2022-04-27 15:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:07:41 --> Total execution time: 0.8987
DEBUG - 2022-04-27 15:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:07:42 --> Total execution time: 0.0848
DEBUG - 2022-04-27 15:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:07:42 --> Total execution time: 0.0620
DEBUG - 2022-04-27 15:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:08:23 --> Total execution time: 0.0325
DEBUG - 2022-04-27 15:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:08:24 --> Total execution time: 0.0377
DEBUG - 2022-04-27 15:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:08:25 --> Total execution time: 0.0314
DEBUG - 2022-04-27 15:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:13:52 --> Total execution time: 0.7861
DEBUG - 2022-04-27 15:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:13:53 --> Total execution time: 0.0932
DEBUG - 2022-04-27 15:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:13:53 --> Total execution time: 0.0385
DEBUG - 2022-04-27 15:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:15:04 --> Total execution time: 0.0463
DEBUG - 2022-04-27 15:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:15:05 --> Total execution time: 0.0285
DEBUG - 2022-04-27 15:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:15:05 --> Total execution time: 0.0309
DEBUG - 2022-04-27 15:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:16:27 --> Total execution time: 0.0299
DEBUG - 2022-04-27 15:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:16:28 --> Total execution time: 0.0310
DEBUG - 2022-04-27 15:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:16:28 --> Total execution time: 0.0313
DEBUG - 2022-04-27 15:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:17:18 --> Total execution time: 0.0312
DEBUG - 2022-04-27 15:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:17:18 --> Total execution time: 0.0305
DEBUG - 2022-04-27 15:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:17:19 --> Total execution time: 0.0791
DEBUG - 2022-04-27 15:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:17:28 --> Total execution time: 0.0319
DEBUG - 2022-04-27 15:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:17:56 --> Total execution time: 0.0293
DEBUG - 2022-04-27 15:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:17:57 --> Total execution time: 0.0287
DEBUG - 2022-04-27 15:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 15:19:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 15:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 15:19:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 15:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 15:19:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 15:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 15:19:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 15:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 15:19:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 15:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 15:19:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-27 15:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 20:50:07 --> Total execution time: 0.0577
DEBUG - 2022-04-27 15:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 20:50:10 --> Total execution time: 0.0290
DEBUG - 2022-04-27 15:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 20:50:33 --> Total execution time: 0.0293
DEBUG - 2022-04-27 15:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 20:50:36 --> Total execution time: 0.0298
DEBUG - 2022-04-27 15:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 20:51:03 --> Total execution time: 0.0367
DEBUG - 2022-04-27 15:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:21:09 --> Total execution time: 0.0339
DEBUG - 2022-04-27 15:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 15:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 15:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 15:21:09 --> Total execution time: 0.0302
DEBUG - 2022-04-27 16:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 21:43:30 --> Total execution time: 0.0952
DEBUG - 2022-04-27 16:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 21:43:47 --> Total execution time: 0.0791
DEBUG - 2022-04-27 16:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 21:44:08 --> Total execution time: 0.0391
DEBUG - 2022-04-27 16:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:14:12 --> Total execution time: 0.0309
DEBUG - 2022-04-27 16:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:14:13 --> Total execution time: 0.0287
DEBUG - 2022-04-27 16:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 21:45:00 --> Total execution time: 0.0383
DEBUG - 2022-04-27 16:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 21:45:04 --> Total execution time: 0.0464
DEBUG - 2022-04-27 16:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 21:46:08 --> Total execution time: 0.0427
DEBUG - 2022-04-27 16:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:16:11 --> Total execution time: 0.0297
DEBUG - 2022-04-27 16:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:16:12 --> Total execution time: 0.0286
DEBUG - 2022-04-27 16:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:16:30 --> Total execution time: 0.0296
DEBUG - 2022-04-27 16:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:16:31 --> Total execution time: 0.0277
DEBUG - 2022-04-27 16:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 21:51:56 --> Total execution time: 0.0560
DEBUG - 2022-04-27 16:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 21:52:10 --> Total execution time: 0.0453
DEBUG - 2022-04-27 16:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 21:52:21 --> Total execution time: 0.0278
DEBUG - 2022-04-27 16:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:22:53 --> Total execution time: 0.0303
DEBUG - 2022-04-27 16:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:22:54 --> Total execution time: 0.0318
DEBUG - 2022-04-27 16:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 16:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 21:53:12 --> Total execution time: 0.0299
DEBUG - 2022-04-27 16:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 21:56:51 --> Total execution time: 0.7744
DEBUG - 2022-04-27 16:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 21:58:48 --> Total execution time: 0.0448
DEBUG - 2022-04-27 16:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:50:30 --> No URI present. Default controller set.
DEBUG - 2022-04-27 16:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 22:20:30 --> Total execution time: 0.8241
DEBUG - 2022-04-27 16:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 16:53:36 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) /home/gvprods/public_html/v1/gvv3/application/controllers/User/Course_Buy_Controller.php 25
DEBUG - 2022-04-27 16:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:54:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 22:24:46 --> Severity: Notice --> Constant PREFIX_ORDER_ID already defined /home/gvprods/public_html/v1/gvv3/application/controllers/User/Course_Buy_Controller.php 9
ERROR - 2022-04-27 22:24:46 --> Query error: Unknown column 'p_id' in 'order clause' - Invalid query: SELECT *
FROM `orders`
ORDER BY `p_id` DESC
 LIMIT 1
ERROR - 2022-04-27 22:24:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/core/Common.php 564
DEBUG - 2022-04-27 16:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:55:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 22:25:35 --> Severity: Notice --> Constant PREFIX_ORDER_ID already defined /home/gvprods/public_html/v1/gvv3/application/controllers/User/Course_Buy_Controller.php 9
ERROR - 2022-04-27 22:25:35 --> Severity: Warning --> Use of undefined constant RAZOR_KEY - assumed 'RAZOR_KEY' (this will throw an Error in a future version of PHP) /home/gvprods/public_html/v1/gvv3/application/controllers/User/Course_Buy_Controller.php 43
ERROR - 2022-04-27 22:25:35 --> Severity: Warning --> Use of undefined constant RAZOR_SECRET_KEY - assumed 'RAZOR_SECRET_KEY' (this will throw an Error in a future version of PHP) /home/gvprods/public_html/v1/gvv3/application/controllers/User/Course_Buy_Controller.php 43
ERROR - 2022-04-27 22:25:36 --> Severity: error --> Exception: The api key provided is invalid /home/gvprods/public_html/v1/gvv3/application/libraries/razorpay/razorpay-php/src/Request.php 123
ERROR - 2022-04-27 22:25:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/core/Common.php 564
DEBUG - 2022-04-27 16:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:56:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 22:26:32 --> Severity: Warning --> A non-numeric value encountered /home/gvprods/public_html/v1/gvv3/application/controllers/User/Course_Buy_Controller.php 123
ERROR - 2022-04-27 22:26:32 --> Severity: Warning --> Use of undefined constant RAZOR_KEY - assumed 'RAZOR_KEY' (this will throw an Error in a future version of PHP) /home/gvprods/public_html/v1/gvv3/application/controllers/User/Course_Buy_Controller.php 42
ERROR - 2022-04-27 22:26:32 --> Severity: Warning --> Use of undefined constant RAZOR_SECRET_KEY - assumed 'RAZOR_SECRET_KEY' (this will throw an Error in a future version of PHP) /home/gvprods/public_html/v1/gvv3/application/controllers/User/Course_Buy_Controller.php 42
ERROR - 2022-04-27 22:26:34 --> Severity: error --> Exception: The api key provided is invalid /home/gvprods/public_html/v1/gvv3/application/libraries/razorpay/razorpay-php/src/Request.php 123
ERROR - 2022-04-27 22:26:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/core/Common.php 564
DEBUG - 2022-04-27 16:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:57:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 22:27:02 --> Severity: Warning --> Use of undefined constant RAZOR_KEY - assumed 'RAZOR_KEY' (this will throw an Error in a future version of PHP) /home/gvprods/public_html/v1/gvv3/application/controllers/User/Course_Buy_Controller.php 42
ERROR - 2022-04-27 22:27:02 --> Severity: Warning --> Use of undefined constant RAZOR_SECRET_KEY - assumed 'RAZOR_SECRET_KEY' (this will throw an Error in a future version of PHP) /home/gvprods/public_html/v1/gvv3/application/controllers/User/Course_Buy_Controller.php 42
ERROR - 2022-04-27 22:27:03 --> Severity: error --> Exception: The api key provided is invalid /home/gvprods/public_html/v1/gvv3/application/libraries/razorpay/razorpay-php/src/Request.php 123
ERROR - 2022-04-27 22:27:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/core/Common.php 564
DEBUG - 2022-04-27 16:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:57:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 22:27:40 --> Severity: Warning --> Use of undefined constant RAZOR_KEY - assumed 'RAZOR_KEY' (this will throw an Error in a future version of PHP) /home/gvprods/public_html/v1/gvv3/application/controllers/User/Course_Buy_Controller.php 42
ERROR - 2022-04-27 22:27:40 --> Severity: Warning --> Use of undefined constant RAZOR_SECRET_KEY - assumed 'RAZOR_SECRET_KEY' (this will throw an Error in a future version of PHP) /home/gvprods/public_html/v1/gvv3/application/controllers/User/Course_Buy_Controller.php 42
ERROR - 2022-04-27 22:27:42 --> Severity: error --> Exception: The api key provided is invalid /home/gvprods/public_html/v1/gvv3/application/libraries/razorpay/razorpay-php/src/Request.php 123
ERROR - 2022-04-27 22:27:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/core/Common.php 564
DEBUG - 2022-04-27 16:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:57:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 22:27:48 --> Severity: Notice --> Undefined index: p_orderid /home/gvprods/public_html/v1/gvv3/application/controllers/User/Course_Buy_Controller.php 77
DEBUG - 2022-04-27 22:27:48 --> Total execution time: 1.5309
DEBUG - 2022-04-27 16:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 22:28:18 --> Total execution time: 1.5232
DEBUG - 2022-04-27 16:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:58:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 22:28:56 --> 404 Page Not Found: 
DEBUG - 2022-04-27 16:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 16:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 16:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 22:29:14 --> Total execution time: 0.0294
DEBUG - 2022-04-27 17:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 22:46:05 --> Total execution time: 0.0287
DEBUG - 2022-04-27 17:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 22:48:07 --> Total execution time: 0.0293
DEBUG - 2022-04-27 17:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 22:57:40 --> Total execution time: 0.8750
DEBUG - 2022-04-27 17:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:27:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 17:27:41 --> 404 Page Not Found: Assets/frontend
DEBUG - 2022-04-27 17:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 22:58:18 --> Total execution time: 0.0386
DEBUG - 2022-04-27 17:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 22:59:29 --> Total execution time: 0.0342
DEBUG - 2022-04-27 17:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:00:39 --> Total execution time: 0.0367
DEBUG - 2022-04-27 17:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:01:28 --> Total execution time: 0.0310
DEBUG - 2022-04-27 17:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:01:44 --> Total execution time: 0.0291
DEBUG - 2022-04-27 17:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:03:07 --> Total execution time: 0.8320
DEBUG - 2022-04-27 17:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:03:07 --> Total execution time: 0.3750
DEBUG - 2022-04-27 17:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:03:08 --> Total execution time: 0.0341
DEBUG - 2022-04-27 17:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:33:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 23:03:15 --> Query error: Illegal mix of collations (utf8mb4_general_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `orders`
WHERE `ord_order_id` = 'E93508808��z�'
DEBUG - 2022-04-27 17:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:03:21 --> Total execution time: 0.0310
DEBUG - 2022-04-27 17:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:33:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-27 23:03:29 --> Query error: Illegal mix of collations (utf8mb4_general_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `orders`
WHERE `ord_order_id` = 'E93508808��z�'
DEBUG - 2022-04-27 17:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:03:31 --> Total execution time: 0.0318
DEBUG - 2022-04-27 17:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:03:39 --> Total execution time: 0.0717
DEBUG - 2022-04-27 17:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:33:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 17:33:59 --> 404 Page Not Found: User/my-account
DEBUG - 2022-04-27 17:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:04:02 --> Total execution time: 0.0287
DEBUG - 2022-04-27 17:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:36:01 --> No URI present. Default controller set.
DEBUG - 2022-04-27 17:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:06:01 --> Total execution time: 0.0305
DEBUG - 2022-04-27 17:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:42:08 --> No URI present. Default controller set.
DEBUG - 2022-04-27 17:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:12:08 --> Total execution time: 0.0306
DEBUG - 2022-04-27 17:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:42:31 --> No URI present. Default controller set.
DEBUG - 2022-04-27 17:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:12:31 --> Total execution time: 0.0292
DEBUG - 2022-04-27 17:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:12:47 --> Total execution time: 0.0293
DEBUG - 2022-04-27 17:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:12:52 --> Total execution time: 0.0300
DEBUG - 2022-04-27 17:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:12:55 --> Total execution time: 0.4898
DEBUG - 2022-04-27 17:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:13:02 --> Total execution time: 0.0300
DEBUG - 2022-04-27 17:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:16:09 --> Total execution time: 0.0310
DEBUG - 2022-04-27 17:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:16:14 --> Total execution time: 0.0278
DEBUG - 2022-04-27 17:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:46:54 --> Total execution time: 0.0303
DEBUG - 2022-04-27 17:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:47:00 --> Total execution time: 0.0355
DEBUG - 2022-04-27 17:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:47:00 --> Total execution time: 0.0317
DEBUG - 2022-04-27 17:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 17:47:05 --> Total execution time: 0.0292
DEBUG - 2022-04-27 17:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:17:24 --> Total execution time: 0.0284
DEBUG - 2022-04-27 17:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:18:04 --> Total execution time: 0.0284
DEBUG - 2022-04-27 17:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:18:05 --> Total execution time: 0.0285
DEBUG - 2022-04-27 17:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:18:06 --> Total execution time: 0.0291
DEBUG - 2022-04-27 17:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:48:15 --> No URI present. Default controller set.
DEBUG - 2022-04-27 17:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:18:15 --> Total execution time: 0.0365
DEBUG - 2022-04-27 17:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:50:53 --> No URI present. Default controller set.
DEBUG - 2022-04-27 17:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:20:54 --> Total execution time: 0.7519
DEBUG - 2022-04-27 17:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:55:15 --> No URI present. Default controller set.
DEBUG - 2022-04-27 17:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:25:16 --> Total execution time: 0.7861
DEBUG - 2022-04-27 17:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:56:19 --> No URI present. Default controller set.
DEBUG - 2022-04-27 17:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:26:19 --> Total execution time: 0.0300
DEBUG - 2022-04-27 17:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 17:58:00 --> No URI present. Default controller set.
DEBUG - 2022-04-27 17:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 17:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:28:00 --> Total execution time: 0.0299
DEBUG - 2022-04-27 18:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 18:16:29 --> No URI present. Default controller set.
DEBUG - 2022-04-27 18:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 18:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-27 23:46:29 --> Total execution time: 0.8121
