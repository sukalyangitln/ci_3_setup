<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-04 12:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:01:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-01-04 12:01:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\personal\jaal\application\core\DB_Controller.php 28
DEBUG - 2022-01-04 12:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:01:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-01-04 12:01:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\personal\jaal\application\core\DB_Controller.php 28
DEBUG - 2022-01-04 12:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 12:01:01 --> Total execution time: 0.0775
DEBUG - 2022-01-04 12:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 12:01:01 --> Total execution time: 0.0517
DEBUG - 2022-01-04 12:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 12:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:31:03 --> Total execution time: 0.0922
DEBUG - 2022-01-04 12:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:31:08 --> Total execution time: 0.0744
DEBUG - 2022-01-04 12:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:35:55 --> Total execution time: 0.0691
DEBUG - 2022-01-04 12:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:35:57 --> Total execution time: 0.0454
DEBUG - 2022-01-04 12:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:37:42 --> Total execution time: 0.0732
DEBUG - 2022-01-04 12:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:08:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-01-04 16:38:54 --> Query error: Unknown column 'Admin_Id' in 'where clause' - Invalid query: SELECT *
FROM `rents`
WHERE `Admin_Id` = '1'
DEBUG - 2022-01-04 12:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:09:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-01-04 16:39:04 --> Severity: Notice --> Undefined variable: lists C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 46
ERROR - 2022-01-04 16:39:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 46
DEBUG - 2022-01-04 16:39:04 --> Total execution time: 0.0733
DEBUG - 2022-01-04 12:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:39:18 --> Total execution time: 0.0718
DEBUG - 2022-01-04 12:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:39:50 --> Total execution time: 0.0648
DEBUG - 2022-01-04 12:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:40:55 --> Total execution time: 0.0605
DEBUG - 2022-01-04 12:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:42:26 --> Total execution time: 0.0580
DEBUG - 2022-01-04 12:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:42:31 --> Total execution time: 0.0460
DEBUG - 2022-01-04 12:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:42:58 --> Total execution time: 0.0507
DEBUG - 2022-01-04 12:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:42:59 --> Total execution time: 0.0618
DEBUG - 2022-01-04 12:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:43:16 --> Total execution time: 0.0483
DEBUG - 2022-01-04 12:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:43:20 --> Total execution time: 0.0573
DEBUG - 2022-01-04 12:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:43:38 --> Total execution time: 0.0669
DEBUG - 2022-01-04 12:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:44:21 --> Total execution time: 0.0479
DEBUG - 2022-01-04 12:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:44:28 --> Total execution time: 0.0450
DEBUG - 2022-01-04 12:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:44:40 --> Total execution time: 0.0647
DEBUG - 2022-01-04 12:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:16:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-01-04 16:46:47 --> Severity: Notice --> Undefined variable: lists C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 46
ERROR - 2022-01-04 16:46:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 46
DEBUG - 2022-01-04 16:46:47 --> Total execution time: 0.0679
DEBUG - 2022-01-04 12:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:46:59 --> Total execution time: 0.0465
DEBUG - 2022-01-04 12:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:47:41 --> Total execution time: 0.0782
DEBUG - 2022-01-04 12:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:47:51 --> Total execution time: 0.0682
DEBUG - 2022-01-04 12:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:48:43 --> Total execution time: 0.0690
DEBUG - 2022-01-04 12:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:48:53 --> Total execution time: 0.0744
DEBUG - 2022-01-04 12:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:49:42 --> Total execution time: 0.0474
DEBUG - 2022-01-04 12:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:57:36 --> Total execution time: 0.0510
DEBUG - 2022-01-04 12:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:28:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-01-04 16:58:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 56
ERROR - 2022-01-04 16:58:25 --> Severity: Notice --> Trying to get property 'user_group_created_date_time' of non-object C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 56
DEBUG - 2022-01-04 16:58:25 --> Total execution time: 0.0503
DEBUG - 2022-01-04 12:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 16:58:45 --> Total execution time: 0.0484
DEBUG - 2022-01-04 12:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:32:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-01-04 17:02:33 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 40
ERROR - 2022-01-04 17:02:33 --> Severity: Notice --> Trying to get property 'Admin_Email' of non-object C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 40
ERROR - 2022-01-04 17:02:33 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 46
ERROR - 2022-01-04 17:02:33 --> Severity: Notice --> Trying to get property 'Admin_Phone' of non-object C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 46
ERROR - 2022-01-04 17:02:33 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 52
ERROR - 2022-01-04 17:02:33 --> Severity: Notice --> Trying to get property 'Admin_Whatsapp' of non-object C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 52
DEBUG - 2022-01-04 17:02:33 --> Total execution time: 0.0776
DEBUG - 2022-01-04 12:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:02:55 --> Total execution time: 0.0723
DEBUG - 2022-01-04 12:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:33:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:33:15 --> UTF-8 Support Enabled
ERROR - 2022-01-04 12:33:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:33:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:33:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:33:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:33:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:33:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:33:15 --> 404 Page Not Found: Assets/backend
ERROR - 2022-01-04 12:33:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:33:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:33:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:03:46 --> Total execution time: 0.0766
DEBUG - 2022-01-04 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:33:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-01-04 12:33:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-01-04 12:33:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:33:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:33:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:33:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:33:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:33:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:03:58 --> Total execution time: 0.0530
DEBUG - 2022-01-04 12:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:04:05 --> Total execution time: 0.0650
DEBUG - 2022-01-04 12:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:04:30 --> Total execution time: 0.0517
DEBUG - 2022-01-04 12:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:35:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-01-04 17:05:00 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 51
ERROR - 2022-01-04 17:05:00 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 51
ERROR - 2022-01-04 17:05:00 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 52
ERROR - 2022-01-04 17:05:00 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 52
ERROR - 2022-01-04 17:05:00 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 52
ERROR - 2022-01-04 17:05:00 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 52
DEBUG - 2022-01-04 17:05:00 --> Total execution time: 0.0533
DEBUG - 2022-01-04 12:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:35:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:12 --> 404 Page Not Found: Assets/backend
ERROR - 2022-01-04 12:35:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:35:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-01-04 17:05:33 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 51
ERROR - 2022-01-04 17:05:33 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\personal\jaal\application\views\Admin\admin-client-list.php 51
DEBUG - 2022-01-04 17:05:33 --> Total execution time: 0.0673
DEBUG - 2022-01-04 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:35:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-01-04 12:35:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:35:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-01-04 12:35:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:35:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-01-04 12:35:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:05:41 --> Total execution time: 0.0553
DEBUG - 2022-01-04 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:35:41 --> UTF-8 Support Enabled
ERROR - 2022-01-04 12:35:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:35:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-01-04 12:35:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:35:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:35:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 12:35:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-01-04 12:35:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-01-04 12:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:08:01 --> Total execution time: 0.0623
DEBUG - 2022-01-04 12:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:08:09 --> Total execution time: 0.0546
DEBUG - 2022-01-04 12:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:08:52 --> Total execution time: 0.0616
DEBUG - 2022-01-04 12:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:09:04 --> Total execution time: 0.0672
DEBUG - 2022-01-04 12:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:09:29 --> Total execution time: 0.0542
DEBUG - 2022-01-04 12:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:10:35 --> Total execution time: 0.0544
DEBUG - 2022-01-04 12:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:10:45 --> Total execution time: 0.0632
DEBUG - 2022-01-04 12:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:11:01 --> Total execution time: 0.0480
DEBUG - 2022-01-04 12:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:11:03 --> Total execution time: 0.0472
DEBUG - 2022-01-04 12:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:11:04 --> Total execution time: 0.0629
DEBUG - 2022-01-04 12:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:11:53 --> Total execution time: 0.0856
DEBUG - 2022-01-04 12:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:12:04 --> Total execution time: 0.0807
DEBUG - 2022-01-04 12:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:12:22 --> Total execution time: 0.0430
DEBUG - 2022-01-04 12:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:12:28 --> Total execution time: 0.0738
DEBUG - 2022-01-04 12:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:12:50 --> Total execution time: 0.0818
DEBUG - 2022-01-04 12:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:13:15 --> Total execution time: 0.0473
DEBUG - 2022-01-04 12:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:16:07 --> Total execution time: 0.0556
DEBUG - 2022-01-04 12:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:16:30 --> Total execution time: 0.0444
DEBUG - 2022-01-04 12:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:16:52 --> Total execution time: 0.0557
DEBUG - 2022-01-04 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:17:33 --> Total execution time: 0.0803
DEBUG - 2022-01-04 12:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:17:47 --> Total execution time: 0.0916
DEBUG - 2022-01-04 12:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:18:44 --> Total execution time: 0.0549
DEBUG - 2022-01-04 12:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:18:46 --> Total execution time: 0.0440
DEBUG - 2022-01-04 12:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:18:47 --> Total execution time: 0.0490
DEBUG - 2022-01-04 12:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:20:14 --> Total execution time: 0.0637
DEBUG - 2022-01-04 12:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:20:19 --> Total execution time: 0.0683
DEBUG - 2022-01-04 12:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:21:00 --> Total execution time: 0.0589
DEBUG - 2022-01-04 12:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:21:02 --> Total execution time: 0.0534
DEBUG - 2022-01-04 12:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:21:38 --> Total execution time: 0.0734
DEBUG - 2022-01-04 12:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:22:02 --> Total execution time: 0.0673
DEBUG - 2022-01-04 12:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:22:09 --> Total execution time: 0.0433
DEBUG - 2022-01-04 12:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:22:22 --> Total execution time: 0.1092
DEBUG - 2022-01-04 12:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:22:31 --> Total execution time: 0.0760
DEBUG - 2022-01-04 12:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:22:52 --> Total execution time: 0.0562
DEBUG - 2022-01-04 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:23:03 --> Total execution time: 0.0483
DEBUG - 2022-01-04 12:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 12:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 12:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-01-04 17:23:36 --> Total execution time: 0.0541
