<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-04-22 16:56:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:53 --> No URI present. Default controller set.
DEBUG - 2023-04-22 16:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:53 --> Severity: 8192 --> Required parameter $bank_name follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 478
ERROR - 2023-04-22 16:56:53 --> Severity: 8192 --> Required parameter $bank_acc_no follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 0
ERROR - 2023-04-22 16:56:53 --> Severity: 8192 --> Required parameter $branch_code follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 0
ERROR - 2023-04-22 16:56:53 --> Severity: 8192 --> Required parameter $acc_holder_name follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 0
ERROR - 2023-04-22 16:56:53 --> Severity: 8192 --> Required parameter $bank_acc_phone follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 0
ERROR - 2023-04-22 16:56:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent E:\xampp\htdocs\gopal\railway\system\libraries\Session\Session.php 282
ERROR - 2023-04-22 16:56:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent E:\xampp\htdocs\gopal\railway\system\libraries\Session\Session.php 294
ERROR - 2023-04-22 16:56:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent E:\xampp\htdocs\gopal\railway\system\libraries\Session\Session.php 304
ERROR - 2023-04-22 16:56:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent E:\xampp\htdocs\gopal\railway\system\libraries\Session\Session.php 314
ERROR - 2023-04-22 16:56:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent E:\xampp\htdocs\gopal\railway\system\libraries\Session\Session.php 315
ERROR - 2023-04-22 16:56:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent E:\xampp\htdocs\gopal\railway\system\libraries\Session\Session.php 316
ERROR - 2023-04-22 16:56:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent E:\xampp\htdocs\gopal\railway\system\libraries\Session\Session.php 317
ERROR - 2023-04-22 16:56:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent E:\xampp\htdocs\gopal\railway\system\libraries\Session\Session.php 375
DEBUG - 2023-04-22 16:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2023-04-22 16:56:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent E:\xampp\htdocs\gopal\railway\system\libraries\Session\Session.php 110
ERROR - 2023-04-22 16:56:53 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent E:\xampp\htdocs\gopal\railway\system\libraries\Session\Session.php 143
DEBUG - 2023-04-22 16:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 20:26:53 --> Total execution time: 0.1987
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/uploads
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/uploads
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/uploads
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 16:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
ERROR - 2023-04-22 16:56:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-22 16:56:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:59 --> Severity: 8192 --> Required parameter $bank_name follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 478
ERROR - 2023-04-22 16:56:59 --> Severity: 8192 --> Required parameter $bank_acc_no follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 0
ERROR - 2023-04-22 16:56:59 --> Severity: 8192 --> Required parameter $branch_code follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 0
ERROR - 2023-04-22 16:56:59 --> Severity: 8192 --> Required parameter $acc_holder_name follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 0
ERROR - 2023-04-22 16:56:59 --> Severity: 8192 --> Required parameter $bank_acc_phone follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 0
DEBUG - 2023-04-22 16:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 16:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 16:56:59 --> Total execution time: 0.0405
DEBUG - 2023-04-22 16:56:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:56:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:56:59 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 16:59:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:59:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:59:41 --> Severity: 8192 --> Required parameter $bank_name follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 462
ERROR - 2023-04-22 16:59:41 --> Severity: 8192 --> Required parameter $bank_acc_no follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 0
ERROR - 2023-04-22 16:59:41 --> Severity: 8192 --> Required parameter $branch_code follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 0
ERROR - 2023-04-22 16:59:41 --> Severity: 8192 --> Required parameter $acc_holder_name follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 0
ERROR - 2023-04-22 16:59:41 --> Severity: 8192 --> Required parameter $bank_acc_phone follows optional parameter $note E:\xampp\htdocs\gopal\railway\application\helpers\project_helper.php 0
DEBUG - 2023-04-22 16:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 16:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 16:59:41 --> Total execution time: 0.0790
DEBUG - 2023-04-22 16:59:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 16:59:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 16:59:41 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 17:00:03 --> Total execution time: 0.0506
DEBUG - 2023-04-22 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:00:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:00:03 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:15:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 17:15:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:15:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-22 20:45:45 --> Query error: Table 'railway.posts' doesn't exist - Invalid query: SELECT *
FROM `posts`
WHERE `p_running` = 1
AND `p_status` = 1
AND `p_approve_status` = 1
DEBUG - 2023-04-22 17:15:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:15:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:15:45 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:15:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:15:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:15:45 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:15:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:15:46 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:19:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:19:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-22 20:49:07 --> Severity: error --> Exception: Call to undefined function count_unread_contact_message() E:\xampp\htdocs\gopal\railway\application\views\Admin\inc\sidebar.php 73
DEBUG - 2023-04-22 17:19:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:19:07 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:19:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:19:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-22 20:49:20 --> Severity: error --> Exception: Call to undefined function count_unread_contact_message() E:\xampp\htdocs\gopal\railway\application\views\Admin\inc\sidebar.php 73
DEBUG - 2023-04-22 17:19:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:19:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-22 20:49:54 --> Severity: error --> Exception: Call to undefined function count_unread_contact_message() E:\xampp\htdocs\gopal\railway\application\views\Admin\inc\sidebar.php 34
DEBUG - 2023-04-22 17:19:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:19:54 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 20:50:01 --> Total execution time: 0.0738
DEBUG - 2023-04-22 17:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:20:01 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:20:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 20:50:28 --> Total execution time: 0.0589
DEBUG - 2023-04-22 17:20:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:20:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:20:28 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:27:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 20:57:19 --> Total execution time: 0.0760
DEBUG - 2023-04-22 17:27:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:27:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:27:19 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:27:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:27:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:27:19 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:27:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 20:57:21 --> Total execution time: 0.0445
DEBUG - 2023-04-22 17:27:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:27:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:27:21 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:27:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 20:57:22 --> Total execution time: 0.0392
DEBUG - 2023-04-22 17:27:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:27:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:27:22 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:31:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:01:51 --> Total execution time: 0.0593
DEBUG - 2023-04-22 17:31:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:31:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:31:51 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:31:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:31:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:31:51 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:31:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:01:53 --> Total execution time: 0.0394
DEBUG - 2023-04-22 17:31:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:31:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:31:53 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:33:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:03:15 --> Total execution time: 0.0739
DEBUG - 2023-04-22 17:33:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:33:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:33:15 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:35:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:05:09 --> Total execution time: 0.0529
DEBUG - 2023-04-22 17:35:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:35:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:35:09 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:49:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:19:45 --> Total execution time: 0.0524
DEBUG - 2023-04-22 17:49:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:49:45 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:50:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:20:15 --> Total execution time: 0.0514
DEBUG - 2023-04-22 17:50:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:50:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:50:15 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:51:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:21:10 --> Total execution time: 0.0531
DEBUG - 2023-04-22 17:51:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:51:10 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:52:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:22:42 --> Total execution time: 0.0379
DEBUG - 2023-04-22 17:52:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:52:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:52:43 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:53:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:23:39 --> Total execution time: 0.0412
DEBUG - 2023-04-22 17:53:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:53:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:53:39 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:53:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:23:53 --> Total execution time: 0.0514
DEBUG - 2023-04-22 17:53:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:53:53 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:24:41 --> Total execution time: 0.0369
DEBUG - 2023-04-22 17:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:54:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:54:41 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 17:54:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 17:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 17:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:24:53 --> Total execution time: 0.0383
DEBUG - 2023-04-22 17:54:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 17:54:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 17:54:53 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:04:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:34:13 --> Total execution time: 0.0456
DEBUG - 2023-04-22 18:04:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:04:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:04:13 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:04:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:34:22 --> Total execution time: 0.0547
DEBUG - 2023-04-22 18:04:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:04:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:04:23 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:04:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:34:49 --> Total execution time: 0.0646
DEBUG - 2023-04-22 18:04:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:04:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:04:49 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:07:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:08:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:38:07 --> Total execution time: 0.0757
DEBUG - 2023-04-22 18:08:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:08:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:08:07 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:12:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:42:18 --> Total execution time: 0.0500
DEBUG - 2023-04-22 18:12:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:12:18 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:13:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:43:47 --> Total execution time: 0.0488
DEBUG - 2023-04-22 18:13:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:13:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:13:47 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:23:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:53:09 --> Total execution time: 0.0561
DEBUG - 2023-04-22 18:23:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:23:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:23:09 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:25:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:55:06 --> Total execution time: 0.0700
DEBUG - 2023-04-22 18:25:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:25:07 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:25:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:55:23 --> Total execution time: 0.0665
DEBUG - 2023-04-22 18:25:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:25:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:25:23 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:25:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-22 18:25:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:25:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:25:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:25:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:25:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:25:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-22 18:25:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:57:02 --> Total execution time: 0.0586
DEBUG - 2023-04-22 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:27:02 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:27:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:27:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:27:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:27:02 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:27:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-22 18:27:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:27:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:27:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:27:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:58:07 --> Total execution time: 0.0361
DEBUG - 2023-04-22 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:28:07 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:28:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:28:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:28:07 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:28:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:28:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-22 18:28:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:28:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:28:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:28:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-22 18:29:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:59:50 --> Total execution time: 0.0545
DEBUG - 2023-04-22 18:29:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:29:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:29:50 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:29:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 21:59:58 --> Total execution time: 0.0651
DEBUG - 2023-04-22 18:29:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:29:58 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:30:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 22:00:11 --> Total execution time: 0.0504
DEBUG - 2023-04-22 18:30:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:30:11 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:32:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 22:02:53 --> Total execution time: 0.0611
DEBUG - 2023-04-22 18:32:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:32:53 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:32:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:32:53 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:34:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 22:04:38 --> Total execution time: 0.0518
DEBUG - 2023-04-22 18:34:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:34:38 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 22:04:46 --> Total execution time: 0.0675
DEBUG - 2023-04-22 18:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:34:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:34:46 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:35:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 22:05:14 --> Total execution time: 0.0658
DEBUG - 2023-04-22 18:35:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:35:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:35:14 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:37:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:37:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:37:38 --> 404 Page Not Found: Admin/User_Controller/store
DEBUG - 2023-04-22 18:38:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:38:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 22:08:11 --> Total execution time: 0.0621
DEBUG - 2023-04-22 18:38:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 22:08:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-22 22:08:15 --> You did not select a file to upload.
DEBUG - 2023-04-22 18:38:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 22:08:15 --> Total execution time: 0.0523
DEBUG - 2023-04-22 18:38:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:38:15 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 18:41:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 18:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 18:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 22:11:24 --> Total execution time: 0.0823
DEBUG - 2023-04-22 18:41:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 18:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 18:41:24 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 19:42:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 19:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 19:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 23:12:54 --> Total execution time: 0.0830
DEBUG - 2023-04-22 19:42:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 19:42:54 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 19:42:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 19:42:54 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 19:42:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 19:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 19:42:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-22 23:12:55 --> Severity: Warning --> Undefined variable $type E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 40
ERROR - 2023-04-22 23:12:55 --> Severity: Warning --> Undefined variable $type E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 41
ERROR - 2023-04-22 23:12:55 --> Severity: Warning --> Undefined variable $type E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 42
ERROR - 2023-04-22 23:12:55 --> Severity: Warning --> Undefined variable $from_date E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 49
ERROR - 2023-04-22 23:12:55 --> Severity: Warning --> Undefined variable $to_date E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 55
ERROR - 2023-04-22 23:12:55 --> Severity: Warning --> Undefined variable $lists E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 92
ERROR - 2023-04-22 23:12:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 92
DEBUG - 2023-04-22 23:12:55 --> Total execution time: 0.0582
DEBUG - 2023-04-22 19:42:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:42:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 19:42:55 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 19:44:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 19:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 19:44:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-22 23:14:04 --> Severity: Warning --> Undefined variable $lists E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 59
ERROR - 2023-04-22 23:14:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 59
DEBUG - 2023-04-22 23:14:04 --> Total execution time: 0.0403
DEBUG - 2023-04-22 19:44:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:44:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 19:44:04 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 19:45:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 19:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 19:45:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$ul_type E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 65
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$ul_type E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 67
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$kyc_status E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 77
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$ul_type E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 65
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$ul_type E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 67
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$kyc_status E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 77
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$ul_type E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 65
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$ul_type E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 67
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$kyc_status E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 77
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$ul_type E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 65
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$ul_type E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 67
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$kyc_status E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 77
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$ul_type E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 65
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$ul_type E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 67
ERROR - 2023-04-22 23:15:12 --> Severity: Warning --> Undefined property: stdClass::$kyc_status E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 77
DEBUG - 2023-04-22 23:15:12 --> Total execution time: 0.0636
DEBUG - 2023-04-22 19:45:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 19:45:12 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 19:46:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 19:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 19:46:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-22 23:16:13 --> Severity: Warning --> Undefined property: stdClass::$lists E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 61
ERROR - 2023-04-22 23:16:13 --> Severity: Warning --> Undefined property: stdClass::$lists E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 61
ERROR - 2023-04-22 23:16:13 --> Severity: Warning --> Undefined property: stdClass::$lists E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 61
ERROR - 2023-04-22 23:16:13 --> Severity: Warning --> Undefined property: stdClass::$lists E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 61
ERROR - 2023-04-22 23:16:13 --> Severity: Warning --> Undefined property: stdClass::$lists E:\xampp\htdocs\gopal\railway\application\views\Admin\user\list-user.php 61
DEBUG - 2023-04-22 23:16:13 --> Total execution time: 0.0543
DEBUG - 2023-04-22 19:46:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:46:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 19:46:13 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 19:46:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 19:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 19:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 23:16:32 --> Total execution time: 0.0616
DEBUG - 2023-04-22 19:46:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:46:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 19:46:32 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-22 19:46:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-22 19:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-22 19:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-22 23:16:38 --> Total execution time: 0.0517
DEBUG - 2023-04-22 19:46:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-22 19:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-22 19:46:38 --> 404 Page Not Found: Assets/uploads
