<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-24 20:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:57:05 --> No URI present. Default controller set.
DEBUG - 2022-04-24 20:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-24 20:57:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'leadsark' C:\xampp\htdocs\leadsark\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-24 20:57:05 --> Unable to connect to the database
DEBUG - 2022-04-24 20:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:57:45 --> No URI present. Default controller set.
DEBUG - 2022-04-24 20:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:58:14 --> Total execution time: 0.0897
DEBUG - 2022-04-24 20:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:58:18 --> Total execution time: 0.1592
DEBUG - 2022-04-24 20:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:58:34 --> Total execution time: 0.1083
DEBUG - 2022-04-24 20:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:58:37 --> Total execution time: 0.0943
DEBUG - 2022-04-24 20:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:58:40 --> Total execution time: 0.1394
DEBUG - 2022-04-24 20:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:58:57 --> Total execution time: 0.0862
DEBUG - 2022-04-24 20:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 20:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 20:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-24 20:59:58 --> Total execution time: 0.1523
