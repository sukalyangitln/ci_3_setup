<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-15 17:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-15 17:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-15 17:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-15 23:02:07 --> Total execution time: 1.3481
DEBUG - 2022-05-15 17:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-15 17:33:20 --> No URI present. Default controller set.
DEBUG - 2022-05-15 17:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-15 17:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-15 23:03:20 --> Total execution time: 0.2014
DEBUG - 2022-05-15 17:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-15 17:34:40 --> No URI present. Default controller set.
DEBUG - 2022-05-15 17:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-15 17:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-15 23:04:40 --> Total execution time: 0.0316
DEBUG - 2022-05-15 20:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-15 20:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-15 20:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-15 20:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-15 20:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-15 20:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-15 20:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-15 20:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-15 20:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-15 20:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-15 20:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-15 20:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-15 20:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-15 20:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-15 20:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-15 20:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-15 20:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-15 20:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-15 20:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-15 20:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-15 20:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-15 20:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-15 20:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-15 20:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-15 20:14:47 --> Total execution time: 0.0398
DEBUG - 2022-05-15 20:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-15 20:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-15 20:56:06 --> Encryption: Auto-configured driver 'openssl'.
