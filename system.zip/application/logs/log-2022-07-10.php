<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-10 00:00:21 --> Total execution time: 0.0643
DEBUG - 2022-07-10 00:00:29 --> Total execution time: 0.0471
DEBUG - 2022-07-10 00:00:41 --> Total execution time: 0.0564
DEBUG - 2022-07-10 00:11:34 --> Total execution time: 0.2719
DEBUG - 2022-07-10 00:11:34 --> Total execution time: 0.1756
DEBUG - 2022-07-10 00:11:39 --> Total execution time: 0.0575
DEBUG - 2022-07-10 00:11:44 --> Total execution time: 0.0851
DEBUG - 2022-07-10 00:11:52 --> Total execution time: 0.0581
DEBUG - 2022-07-10 00:14:56 --> Total execution time: 0.1074
DEBUG - 2022-07-10 00:15:11 --> Total execution time: 0.1312
DEBUG - 2022-07-10 00:19:12 --> Total execution time: 0.1827
DEBUG - 2022-07-10 00:21:21 --> Total execution time: 0.0490
DEBUG - 2022-07-10 00:26:29 --> Total execution time: 0.0534
DEBUG - 2022-07-10 00:26:37 --> Total execution time: 0.0621
DEBUG - 2022-07-10 00:26:50 --> Total execution time: 0.0573
DEBUG - 2022-07-10 00:26:53 --> Total execution time: 0.0627
DEBUG - 2022-07-10 00:29:54 --> Total execution time: 0.0520
DEBUG - 2022-07-10 00:30:02 --> Total execution time: 0.1772
DEBUG - 2022-07-10 00:31:02 --> Total execution time: 0.0695
DEBUG - 2022-07-10 00:36:18 --> Total execution time: 0.1920
DEBUG - 2022-07-10 00:42:03 --> Total execution time: 0.1276
DEBUG - 2022-07-10 00:42:38 --> Total execution time: 0.0377
DEBUG - 2022-07-10 00:44:03 --> Total execution time: 0.1341
DEBUG - 2022-07-10 00:44:05 --> Total execution time: 0.0797
DEBUG - 2022-07-10 00:44:57 --> Total execution time: 0.0445
DEBUG - 2022-07-10 00:49:28 --> Total execution time: 0.0544
DEBUG - 2022-07-10 01:02:43 --> Total execution time: 0.1076
DEBUG - 2022-07-10 01:30:02 --> Total execution time: 0.3664
DEBUG - 2022-07-10 01:49:16 --> Total execution time: 0.1266
DEBUG - 2022-07-10 02:30:03 --> Total execution time: 0.4299
DEBUG - 2022-07-10 02:48:27 --> Total execution time: 0.2286
DEBUG - 2022-07-10 02:59:55 --> Total execution time: 0.1178
DEBUG - 2022-07-10 02:59:59 --> Total execution time: 0.0380
DEBUG - 2022-07-10 03:00:22 --> Total execution time: 0.0928
DEBUG - 2022-07-10 03:00:23 --> Total execution time: 0.0717
DEBUG - 2022-07-10 03:00:31 --> Total execution time: 0.1082
DEBUG - 2022-07-10 03:00:35 --> Total execution time: 0.0810
DEBUG - 2022-07-10 03:00:39 --> Total execution time: 0.0886
DEBUG - 2022-07-10 03:19:16 --> Total execution time: 0.1004
DEBUG - 2022-07-10 03:22:08 --> Total execution time: 0.0408
DEBUG - 2022-07-10 03:25:36 --> Total execution time: 0.1182
DEBUG - 2022-07-10 03:29:52 --> Total execution time: 0.1015
DEBUG - 2022-07-10 03:30:03 --> Total execution time: 0.0501
DEBUG - 2022-07-10 03:30:10 --> Total execution time: 0.0395
DEBUG - 2022-07-10 03:32:58 --> Total execution time: 0.0895
DEBUG - 2022-07-10 03:35:27 --> Total execution time: 0.0402
DEBUG - 2022-07-10 03:45:27 --> Total execution time: 0.0581
DEBUG - 2022-07-10 03:52:25 --> Total execution time: 0.1210
DEBUG - 2022-07-10 04:30:03 --> Total execution time: 0.2739
DEBUG - 2022-07-10 05:30:03 --> Total execution time: 0.2912
DEBUG - 2022-07-10 05:46:49 --> Total execution time: 0.1287
DEBUG - 2022-07-10 05:57:48 --> Total execution time: 0.1028
DEBUG - 2022-07-10 05:58:01 --> Total execution time: 0.0570
DEBUG - 2022-07-10 05:58:26 --> Total execution time: 0.0562
DEBUG - 2022-07-10 05:58:32 --> Total execution time: 0.0614
DEBUG - 2022-07-10 05:58:58 --> Total execution time: 0.0806
DEBUG - 2022-07-10 05:59:08 --> Total execution time: 0.0708
DEBUG - 2022-07-10 06:21:32 --> Total execution time: 0.0544
DEBUG - 2022-07-10 06:30:02 --> Total execution time: 0.1218
DEBUG - 2022-07-10 06:38:12 --> Total execution time: 0.0560
DEBUG - 2022-07-10 06:38:23 --> Total execution time: 0.0552
DEBUG - 2022-07-10 06:38:37 --> Total execution time: 0.0531
DEBUG - 2022-07-10 06:38:40 --> Total execution time: 0.0450
DEBUG - 2022-07-10 06:38:46 --> Total execution time: 0.0744
DEBUG - 2022-07-10 06:39:04 --> Total execution time: 0.0939
DEBUG - 2022-07-10 06:39:14 --> Total execution time: 0.0634
DEBUG - 2022-07-10 06:39:17 --> Total execution time: 0.0742
DEBUG - 2022-07-10 06:39:24 --> Total execution time: 0.0505
DEBUG - 2022-07-10 06:46:47 --> Total execution time: 0.1127
DEBUG - 2022-07-10 06:46:49 --> Total execution time: 0.0520
DEBUG - 2022-07-10 06:46:55 --> Total execution time: 0.0377
DEBUG - 2022-07-10 06:48:27 --> Total execution time: 0.0597
DEBUG - 2022-07-10 06:48:51 --> Total execution time: 0.0500
DEBUG - 2022-07-10 06:49:04 --> Total execution time: 0.0550
DEBUG - 2022-07-10 06:49:08 --> Total execution time: 0.0519
DEBUG - 2022-07-10 06:49:33 --> Total execution time: 0.1075
DEBUG - 2022-07-10 06:49:44 --> Total execution time: 0.0556
DEBUG - 2022-07-10 06:51:14 --> Total execution time: 0.0523
DEBUG - 2022-07-10 06:51:51 --> Total execution time: 0.0378
DEBUG - 2022-07-10 06:56:24 --> Total execution time: 0.1052
DEBUG - 2022-07-10 06:56:40 --> Total execution time: 0.0515
DEBUG - 2022-07-10 06:56:53 --> Total execution time: 0.1406
DEBUG - 2022-07-10 06:57:10 --> Total execution time: 0.0829
DEBUG - 2022-07-10 06:57:23 --> Total execution time: 0.0619
DEBUG - 2022-07-10 06:57:28 --> Total execution time: 0.0916
DEBUG - 2022-07-10 06:58:07 --> Total execution time: 0.0789
DEBUG - 2022-07-10 06:59:02 --> Total execution time: 0.1351
DEBUG - 2022-07-10 06:59:11 --> Total execution time: 0.0899
DEBUG - 2022-07-10 06:59:56 --> Total execution time: 0.1101
DEBUG - 2022-07-10 07:00:01 --> Total execution time: 0.0691
DEBUG - 2022-07-10 07:06:17 --> Total execution time: 0.0644
DEBUG - 2022-07-10 07:09:23 --> Total execution time: 0.1101
DEBUG - 2022-07-10 07:15:55 --> Total execution time: 0.0926
DEBUG - 2022-07-10 07:16:21 --> Total execution time: 0.0639
DEBUG - 2022-07-10 07:16:30 --> Total execution time: 0.0625
DEBUG - 2022-07-10 07:16:36 --> Total execution time: 0.0638
DEBUG - 2022-07-10 07:17:18 --> Total execution time: 0.0601
DEBUG - 2022-07-10 07:17:23 --> Total execution time: 0.0556
DEBUG - 2022-07-10 07:17:31 --> Total execution time: 0.0577
DEBUG - 2022-07-10 07:18:07 --> Total execution time: 0.0600
DEBUG - 2022-07-10 07:21:47 --> Total execution time: 0.0572
DEBUG - 2022-07-10 07:22:16 --> Total execution time: 0.0557
DEBUG - 2022-07-10 07:22:34 --> Total execution time: 0.1057
DEBUG - 2022-07-10 07:22:38 --> Total execution time: 0.0587
DEBUG - 2022-07-10 07:22:44 --> Total execution time: 0.0669
DEBUG - 2022-07-10 07:23:42 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 07:23:43 --> Total execution time: 0.0604
DEBUG - 2022-07-10 07:23:53 --> Total execution time: 0.0615
DEBUG - 2022-07-10 07:23:58 --> Total execution time: 0.0586
DEBUG - 2022-07-10 07:24:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 07:24:18 --> Total execution time: 0.0804
DEBUG - 2022-07-10 07:24:31 --> Total execution time: 0.0673
DEBUG - 2022-07-10 07:24:50 --> Total execution time: 0.0861
DEBUG - 2022-07-10 07:25:38 --> Total execution time: 0.0640
DEBUG - 2022-07-10 07:25:59 --> Total execution time: 0.0555
DEBUG - 2022-07-10 07:26:08 --> Total execution time: 0.0567
DEBUG - 2022-07-10 07:27:07 --> Total execution time: 0.0493
DEBUG - 2022-07-10 07:28:13 --> Total execution time: 0.0581
DEBUG - 2022-07-10 07:29:18 --> Total execution time: 0.0517
DEBUG - 2022-07-10 07:30:04 --> Total execution time: 0.0635
DEBUG - 2022-07-10 07:30:40 --> Total execution time: 0.0562
DEBUG - 2022-07-10 07:32:46 --> Total execution time: 0.1268
DEBUG - 2022-07-10 07:33:06 --> Total execution time: 0.0425
DEBUG - 2022-07-10 07:33:38 --> Total execution time: 0.0878
DEBUG - 2022-07-10 07:34:08 --> Total execution time: 0.0511
DEBUG - 2022-07-10 07:34:31 --> Total execution time: 0.0494
DEBUG - 2022-07-10 07:34:34 --> Total execution time: 0.0564
DEBUG - 2022-07-10 07:34:45 --> Total execution time: 0.0866
DEBUG - 2022-07-10 07:34:57 --> Total execution time: 0.0552
DEBUG - 2022-07-10 07:35:07 --> Total execution time: 0.0579
DEBUG - 2022-07-10 07:35:13 --> Total execution time: 0.0543
DEBUG - 2022-07-10 07:35:15 --> Total execution time: 0.0746
DEBUG - 2022-07-10 07:35:30 --> Total execution time: 0.0546
DEBUG - 2022-07-10 07:37:08 --> Total execution time: 0.0430
DEBUG - 2022-07-10 07:39:28 --> Total execution time: 0.1295
DEBUG - 2022-07-10 07:39:39 --> Total execution time: 0.0528
DEBUG - 2022-07-10 07:39:41 --> Total execution time: 0.0393
DEBUG - 2022-07-10 07:39:48 --> Total execution time: 0.0535
DEBUG - 2022-07-10 07:40:11 --> Total execution time: 0.0659
DEBUG - 2022-07-10 07:40:15 --> Total execution time: 0.0556
DEBUG - 2022-07-10 07:40:18 --> Total execution time: 0.0665
DEBUG - 2022-07-10 07:40:23 --> Total execution time: 0.0584
DEBUG - 2022-07-10 07:41:26 --> Total execution time: 0.0571
DEBUG - 2022-07-10 07:41:43 --> Total execution time: 0.0507
DEBUG - 2022-07-10 07:41:45 --> Total execution time: 0.0564
DEBUG - 2022-07-10 07:41:48 --> Total execution time: 0.0531
DEBUG - 2022-07-10 07:42:01 --> Total execution time: 0.0571
DEBUG - 2022-07-10 07:42:04 --> Total execution time: 0.0549
DEBUG - 2022-07-10 07:42:16 --> Total execution time: 0.0609
DEBUG - 2022-07-10 07:42:23 --> Total execution time: 0.0567
DEBUG - 2022-07-10 07:42:31 --> Total execution time: 0.0595
DEBUG - 2022-07-10 07:42:35 --> Total execution time: 0.0560
DEBUG - 2022-07-10 07:43:03 --> Total execution time: 0.0506
DEBUG - 2022-07-10 07:43:33 --> Total execution time: 0.0716
DEBUG - 2022-07-10 07:43:57 --> Total execution time: 0.0576
DEBUG - 2022-07-10 07:45:11 --> Total execution time: 0.1358
DEBUG - 2022-07-10 07:45:14 --> Total execution time: 0.0572
DEBUG - 2022-07-10 07:45:32 --> Total execution time: 0.0545
DEBUG - 2022-07-10 07:45:40 --> Total execution time: 0.0367
DEBUG - 2022-07-10 07:45:40 --> Total execution time: 0.0365
DEBUG - 2022-07-10 07:45:58 --> Total execution time: 0.0403
DEBUG - 2022-07-10 07:46:11 --> Total execution time: 0.0570
DEBUG - 2022-07-10 07:46:33 --> Total execution time: 0.0504
DEBUG - 2022-07-10 07:48:09 --> Total execution time: 0.0529
DEBUG - 2022-07-10 07:49:11 --> Total execution time: 0.0629
DEBUG - 2022-07-10 07:49:23 --> Total execution time: 0.0590
DEBUG - 2022-07-10 07:49:34 --> Total execution time: 0.0671
DEBUG - 2022-07-10 07:49:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 07:49:35 --> Total execution time: 0.0490
DEBUG - 2022-07-10 07:50:38 --> Total execution time: 0.1286
DEBUG - 2022-07-10 07:50:44 --> Total execution time: 0.0524
DEBUG - 2022-07-10 07:51:02 --> Total execution time: 0.0483
DEBUG - 2022-07-10 07:51:03 --> Total execution time: 0.0458
DEBUG - 2022-07-10 07:51:15 --> Total execution time: 0.1245
DEBUG - 2022-07-10 07:51:16 --> Total execution time: 0.0870
DEBUG - 2022-07-10 07:51:27 --> Total execution time: 0.0605
DEBUG - 2022-07-10 07:51:29 --> Total execution time: 0.0512
DEBUG - 2022-07-10 07:51:32 --> Total execution time: 0.0747
DEBUG - 2022-07-10 07:51:36 --> Total execution time: 0.0532
DEBUG - 2022-07-10 07:51:45 --> Total execution time: 0.0585
DEBUG - 2022-07-10 07:52:03 --> Total execution time: 0.0499
DEBUG - 2022-07-10 07:52:12 --> Total execution time: 0.0610
DEBUG - 2022-07-10 07:52:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 07:52:13 --> Total execution time: 0.0506
DEBUG - 2022-07-10 07:52:18 --> Total execution time: 0.0500
DEBUG - 2022-07-10 07:54:53 --> Total execution time: 0.1244
DEBUG - 2022-07-10 07:54:55 --> Total execution time: 0.0366
DEBUG - 2022-07-10 07:56:33 --> Total execution time: 0.0566
DEBUG - 2022-07-10 07:56:58 --> Total execution time: 0.0360
DEBUG - 2022-07-10 07:57:11 --> Total execution time: 0.0776
DEBUG - 2022-07-10 07:57:26 --> Total execution time: 0.0599
DEBUG - 2022-07-10 07:57:29 --> Total execution time: 0.0624
DEBUG - 2022-07-10 07:58:01 --> Total execution time: 0.0979
DEBUG - 2022-07-10 07:58:22 --> Total execution time: 0.0665
DEBUG - 2022-07-10 07:58:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 07:58:23 --> Total execution time: 0.0506
DEBUG - 2022-07-10 07:59:04 --> Total execution time: 0.0593
DEBUG - 2022-07-10 07:59:17 --> Total execution time: 0.0529
DEBUG - 2022-07-10 07:59:30 --> Total execution time: 0.0938
DEBUG - 2022-07-10 07:59:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 07:59:31 --> Total execution time: 0.0602
DEBUG - 2022-07-10 07:59:43 --> Total execution time: 0.0518
DEBUG - 2022-07-10 07:59:44 --> Total execution time: 0.0496
DEBUG - 2022-07-10 07:59:45 --> Total execution time: 0.0943
DEBUG - 2022-07-10 08:01:12 --> Total execution time: 0.0646
DEBUG - 2022-07-10 08:01:30 --> Total execution time: 0.0423
DEBUG - 2022-07-10 08:02:39 --> Total execution time: 0.0565
DEBUG - 2022-07-10 08:03:23 --> Total execution time: 0.0537
DEBUG - 2022-07-10 08:04:42 --> Total execution time: 0.1318
DEBUG - 2022-07-10 08:04:50 --> Total execution time: 0.0496
DEBUG - 2022-07-10 08:05:24 --> Total execution time: 0.0340
DEBUG - 2022-07-10 08:07:17 --> Total execution time: 0.0367
DEBUG - 2022-07-10 08:07:18 --> Total execution time: 0.0455
DEBUG - 2022-07-10 08:07:22 --> Total execution time: 0.0453
DEBUG - 2022-07-10 08:07:32 --> Total execution time: 0.0555
DEBUG - 2022-07-10 08:07:41 --> Total execution time: 0.0980
DEBUG - 2022-07-10 08:07:57 --> Total execution time: 0.1148
DEBUG - 2022-07-10 08:08:04 --> Total execution time: 0.0735
DEBUG - 2022-07-10 08:08:35 --> Total execution time: 0.0983
DEBUG - 2022-07-10 08:08:40 --> Total execution time: 0.0511
DEBUG - 2022-07-10 08:08:47 --> Total execution time: 0.0504
DEBUG - 2022-07-10 08:09:32 --> Total execution time: 0.0600
DEBUG - 2022-07-10 08:09:40 --> Total execution time: 0.0499
DEBUG - 2022-07-10 08:09:52 --> Total execution time: 0.0546
DEBUG - 2022-07-10 08:10:08 --> Total execution time: 0.0561
DEBUG - 2022-07-10 08:10:20 --> Total execution time: 0.0640
DEBUG - 2022-07-10 08:10:29 --> Total execution time: 0.0488
DEBUG - 2022-07-10 08:10:36 --> Total execution time: 0.0649
DEBUG - 2022-07-10 08:10:39 --> Total execution time: 0.0516
DEBUG - 2022-07-10 08:10:49 --> Total execution time: 0.0516
DEBUG - 2022-07-10 08:10:53 --> Total execution time: 0.0523
DEBUG - 2022-07-10 08:11:05 --> Total execution time: 0.0577
DEBUG - 2022-07-10 08:12:41 --> Total execution time: 0.0519
DEBUG - 2022-07-10 08:15:18 --> Total execution time: 0.1146
DEBUG - 2022-07-10 08:15:52 --> Total execution time: 0.0399
DEBUG - 2022-07-10 08:17:22 --> Total execution time: 0.1254
DEBUG - 2022-07-10 08:17:49 --> Total execution time: 0.0546
DEBUG - 2022-07-10 08:20:28 --> Total execution time: 0.2903
DEBUG - 2022-07-10 08:20:58 --> Total execution time: 0.0650
DEBUG - 2022-07-10 08:21:01 --> Total execution time: 0.1471
DEBUG - 2022-07-10 08:21:02 --> Total execution time: 0.0636
DEBUG - 2022-07-10 08:21:02 --> Total execution time: 0.0797
DEBUG - 2022-07-10 08:25:09 --> Total execution time: 0.0520
DEBUG - 2022-07-10 08:25:22 --> Total execution time: 0.0607
DEBUG - 2022-07-10 08:26:44 --> Total execution time: 0.0664
DEBUG - 2022-07-10 08:27:21 --> Total execution time: 0.0608
DEBUG - 2022-07-10 08:27:37 --> Total execution time: 0.0365
DEBUG - 2022-07-10 08:27:42 --> Total execution time: 0.0647
DEBUG - 2022-07-10 08:28:09 --> Total execution time: 0.0656
DEBUG - 2022-07-10 08:28:21 --> Total execution time: 0.0841
DEBUG - 2022-07-10 08:28:25 --> Total execution time: 0.1436
DEBUG - 2022-07-10 08:28:30 --> Total execution time: 0.0843
DEBUG - 2022-07-10 08:28:41 --> Total execution time: 0.0497
DEBUG - 2022-07-10 08:28:42 --> Total execution time: 0.0522
DEBUG - 2022-07-10 08:29:12 --> Total execution time: 0.0831
DEBUG - 2022-07-10 08:29:18 --> Total execution time: 0.0544
DEBUG - 2022-07-10 08:29:28 --> Total execution time: 0.0698
DEBUG - 2022-07-10 08:29:34 --> Total execution time: 0.0557
DEBUG - 2022-07-10 08:29:35 --> Total execution time: 0.0556
DEBUG - 2022-07-10 08:29:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 08:29:37 --> Total execution time: 0.0581
DEBUG - 2022-07-10 08:29:39 --> Total execution time: 0.0521
DEBUG - 2022-07-10 08:30:02 --> Total execution time: 0.0561
DEBUG - 2022-07-10 08:30:32 --> Total execution time: 0.0496
DEBUG - 2022-07-10 08:30:52 --> Total execution time: 0.0756
DEBUG - 2022-07-10 08:31:11 --> Total execution time: 0.0733
DEBUG - 2022-07-10 08:33:07 --> Total execution time: 0.0662
DEBUG - 2022-07-10 08:34:08 --> Total execution time: 0.0574
DEBUG - 2022-07-10 08:34:36 --> Total execution time: 0.0530
DEBUG - 2022-07-10 08:38:02 --> Total execution time: 0.1753
DEBUG - 2022-07-10 08:38:17 --> Total execution time: 0.0748
DEBUG - 2022-07-10 08:42:02 --> Total execution time: 0.0653
DEBUG - 2022-07-10 08:42:23 --> Total execution time: 0.0600
DEBUG - 2022-07-10 08:43:56 --> Total execution time: 0.0526
DEBUG - 2022-07-10 08:44:21 --> Total execution time: 0.0608
DEBUG - 2022-07-10 08:44:34 --> Total execution time: 0.0571
DEBUG - 2022-07-10 08:44:37 --> Total execution time: 0.0617
DEBUG - 2022-07-10 08:44:43 --> Total execution time: 0.0739
DEBUG - 2022-07-10 08:44:53 --> Total execution time: 0.0664
DEBUG - 2022-07-10 08:46:10 --> Total execution time: 0.1379
DEBUG - 2022-07-10 08:46:28 --> Total execution time: 0.0517
DEBUG - 2022-07-10 08:49:21 --> Total execution time: 0.2043
DEBUG - 2022-07-10 08:50:10 --> Total execution time: 0.0743
DEBUG - 2022-07-10 08:50:31 --> Total execution time: 0.0594
DEBUG - 2022-07-10 08:50:54 --> Total execution time: 0.0560
DEBUG - 2022-07-10 08:51:14 --> Total execution time: 0.0682
DEBUG - 2022-07-10 08:52:17 --> Total execution time: 0.0528
DEBUG - 2022-07-10 08:52:26 --> Total execution time: 0.0527
DEBUG - 2022-07-10 08:57:20 --> Total execution time: 0.1197
DEBUG - 2022-07-10 08:57:22 --> Total execution time: 0.0522
DEBUG - 2022-07-10 08:59:04 --> Total execution time: 0.1496
DEBUG - 2022-07-10 09:00:06 --> Total execution time: 0.1814
DEBUG - 2022-07-10 09:00:06 --> Total execution time: 0.0591
DEBUG - 2022-07-10 09:00:13 --> Total execution time: 0.0665
DEBUG - 2022-07-10 09:00:17 --> Total execution time: 0.0590
DEBUG - 2022-07-10 09:00:21 --> Total execution time: 0.0633
DEBUG - 2022-07-10 09:00:34 --> Total execution time: 0.0735
DEBUG - 2022-07-10 09:01:00 --> Total execution time: 0.0538
DEBUG - 2022-07-10 09:08:44 --> Total execution time: 0.2239
DEBUG - 2022-07-10 09:09:42 --> Total execution time: 0.0410
DEBUG - 2022-07-10 09:10:02 --> Total execution time: 0.0746
DEBUG - 2022-07-10 09:10:43 --> Total execution time: 0.0813
DEBUG - 2022-07-10 09:10:50 --> Total execution time: 0.0555
DEBUG - 2022-07-10 09:10:51 --> Total execution time: 0.0556
DEBUG - 2022-07-10 09:12:53 --> Total execution time: 0.0561
DEBUG - 2022-07-10 09:16:23 --> Total execution time: 0.2282
DEBUG - 2022-07-10 09:17:15 --> Total execution time: 0.1437
DEBUG - 2022-07-10 09:17:18 --> Total execution time: 0.0441
DEBUG - 2022-07-10 09:17:40 --> Total execution time: 0.0709
DEBUG - 2022-07-10 09:19:25 --> Total execution time: 0.0429
DEBUG - 2022-07-10 09:21:22 --> Total execution time: 1.9634
DEBUG - 2022-07-10 09:23:25 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 09:23:26 --> Total execution time: 0.0626
DEBUG - 2022-07-10 09:23:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 09:23:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 09:23:28 --> Total execution time: 0.1760
DEBUG - 2022-07-10 09:23:32 --> Total execution time: 0.0548
DEBUG - 2022-07-10 09:23:36 --> Total execution time: 0.0742
DEBUG - 2022-07-10 09:24:37 --> Total execution time: 0.0382
DEBUG - 2022-07-10 09:25:14 --> Total execution time: 0.0397
DEBUG - 2022-07-10 09:28:53 --> Total execution time: 0.0538
DEBUG - 2022-07-10 09:28:56 --> Total execution time: 0.0444
DEBUG - 2022-07-10 09:29:45 --> Total execution time: 0.0440
DEBUG - 2022-07-10 09:30:02 --> Total execution time: 0.0804
DEBUG - 2022-07-10 09:31:15 --> Total execution time: 2.6203
DEBUG - 2022-07-10 09:31:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 09:32:00 --> Total execution time: 0.0827
DEBUG - 2022-07-10 09:32:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 09:32:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 09:32:01 --> Total execution time: 0.2119
DEBUG - 2022-07-10 09:32:03 --> Total execution time: 0.0854
DEBUG - 2022-07-10 09:32:08 --> Total execution time: 0.0741
DEBUG - 2022-07-10 09:36:19 --> Total execution time: 0.0605
DEBUG - 2022-07-10 09:36:24 --> Total execution time: 0.0432
DEBUG - 2022-07-10 09:37:06 --> Total execution time: 0.0426
DEBUG - 2022-07-10 09:37:07 --> Total execution time: 0.0405
DEBUG - 2022-07-10 09:37:13 --> Total execution time: 0.0332
DEBUG - 2022-07-10 09:37:26 --> Total execution time: 0.0524
DEBUG - 2022-07-10 09:37:28 --> Total execution time: 0.0491
DEBUG - 2022-07-10 09:37:40 --> Total execution time: 0.0633
DEBUG - 2022-07-10 09:37:44 --> Total execution time: 0.0964
DEBUG - 2022-07-10 09:37:52 --> Total execution time: 0.0497
DEBUG - 2022-07-10 09:38:20 --> Total execution time: 0.0357
DEBUG - 2022-07-10 09:38:45 --> Total execution time: 0.1369
DEBUG - 2022-07-10 09:39:45 --> Total execution time: 0.0652
DEBUG - 2022-07-10 09:43:36 --> Total execution time: 0.1853
DEBUG - 2022-07-10 09:44:16 --> Total execution time: 0.1418
DEBUG - 2022-07-10 09:44:20 --> Total execution time: 0.1365
DEBUG - 2022-07-10 09:44:29 --> Total execution time: 0.0650
DEBUG - 2022-07-10 09:44:31 --> Total execution time: 0.0734
DEBUG - 2022-07-10 09:44:47 --> Total execution time: 0.0549
DEBUG - 2022-07-10 09:44:58 --> Total execution time: 0.0634
DEBUG - 2022-07-10 09:44:59 --> Total execution time: 0.0694
DEBUG - 2022-07-10 09:45:29 --> Total execution time: 0.0370
DEBUG - 2022-07-10 09:45:44 --> Total execution time: 0.0590
DEBUG - 2022-07-10 09:47:05 --> Total execution time: 1.8912
DEBUG - 2022-07-10 09:52:24 --> Total execution time: 0.0530
DEBUG - 2022-07-10 09:58:19 --> Total execution time: 0.1403
DEBUG - 2022-07-10 09:58:43 --> Total execution time: 0.0627
DEBUG - 2022-07-10 09:59:05 --> Total execution time: 0.0593
DEBUG - 2022-07-10 09:59:09 --> Total execution time: 0.1735
DEBUG - 2022-07-10 09:59:17 --> Total execution time: 0.0650
DEBUG - 2022-07-10 09:59:37 --> Total execution time: 0.0530
DEBUG - 2022-07-10 10:00:22 --> Total execution time: 0.1536
DEBUG - 2022-07-10 10:00:38 --> Total execution time: 0.0894
DEBUG - 2022-07-10 10:00:41 --> Total execution time: 0.0568
DEBUG - 2022-07-10 10:00:46 --> Total execution time: 0.0615
DEBUG - 2022-07-10 10:01:08 --> Total execution time: 0.1407
DEBUG - 2022-07-10 10:01:36 --> Total execution time: 0.0620
DEBUG - 2022-07-10 10:02:11 --> Total execution time: 0.0530
DEBUG - 2022-07-10 10:03:39 --> Total execution time: 0.0715
DEBUG - 2022-07-10 10:06:04 --> Total execution time: 0.0480
DEBUG - 2022-07-10 10:06:04 --> Total execution time: 0.0550
DEBUG - 2022-07-10 10:08:50 --> Total execution time: 0.0355
DEBUG - 2022-07-10 10:08:59 --> Total execution time: 0.0557
DEBUG - 2022-07-10 10:09:08 --> Total execution time: 0.0789
DEBUG - 2022-07-10 10:10:17 --> Total execution time: 0.0546
DEBUG - 2022-07-10 10:20:34 --> Total execution time: 0.1057
DEBUG - 2022-07-10 10:20:44 --> Total execution time: 0.0360
DEBUG - 2022-07-10 10:21:49 --> Total execution time: 0.0615
DEBUG - 2022-07-10 10:22:02 --> Total execution time: 0.1867
DEBUG - 2022-07-10 10:22:41 --> Total execution time: 0.0914
DEBUG - 2022-07-10 10:22:42 --> Total execution time: 0.0877
DEBUG - 2022-07-10 10:23:00 --> Total execution time: 0.0861
DEBUG - 2022-07-10 10:23:29 --> Total execution time: 0.0620
DEBUG - 2022-07-10 10:24:22 --> Total execution time: 0.0659
DEBUG - 2022-07-10 10:25:05 --> Total execution time: 0.1122
DEBUG - 2022-07-10 10:25:06 --> Total execution time: 0.0769
DEBUG - 2022-07-10 10:25:09 --> Total execution time: 0.0839
DEBUG - 2022-07-10 10:25:19 --> Total execution time: 0.0558
DEBUG - 2022-07-10 10:25:23 --> Total execution time: 0.0623
DEBUG - 2022-07-10 10:25:28 --> Total execution time: 0.0414
DEBUG - 2022-07-10 10:25:38 --> Total execution time: 0.0464
DEBUG - 2022-07-10 10:26:16 --> Total execution time: 0.0429
DEBUG - 2022-07-10 10:26:39 --> Total execution time: 0.0708
DEBUG - 2022-07-10 10:27:42 --> Total execution time: 0.0397
DEBUG - 2022-07-10 10:27:44 --> Total execution time: 0.0532
DEBUG - 2022-07-10 10:29:08 --> Total execution time: 0.0628
DEBUG - 2022-07-10 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:30:02 --> Total execution time: 0.0516
DEBUG - 2022-07-10 00:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:30:46 --> Total execution time: 0.0346
DEBUG - 2022-07-10 00:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:01:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 00:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:31:18 --> Total execution time: 1.9871
DEBUG - 2022-07-10 00:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:01:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 00:01:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 00:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 00:01:50 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-10 00:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:03:23 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:33:23 --> Total execution time: 0.0717
DEBUG - 2022-07-10 00:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:03:23 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:33:23 --> Total execution time: 0.0384
DEBUG - 2022-07-10 00:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:33:27 --> Total execution time: 0.0477
DEBUG - 2022-07-10 00:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:33:32 --> Total execution time: 0.0658
DEBUG - 2022-07-10 00:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:33:38 --> Total execution time: 0.0696
DEBUG - 2022-07-10 00:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:33:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 00:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:33:39 --> Total execution time: 0.0653
DEBUG - 2022-07-10 00:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:04:09 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:34:09 --> Total execution time: 0.0372
DEBUG - 2022-07-10 00:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:04:42 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:34:42 --> Total execution time: 0.0538
DEBUG - 2022-07-10 00:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:04:52 --> Total execution time: 0.0695
DEBUG - 2022-07-10 00:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:04:54 --> Total execution time: 0.0610
DEBUG - 2022-07-10 00:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:04:54 --> Total execution time: 0.0805
DEBUG - 2022-07-10 00:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:04:56 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:34:56 --> Total execution time: 0.0585
DEBUG - 2022-07-10 00:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:34:58 --> Total execution time: 0.0525
DEBUG - 2022-07-10 00:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:34:59 --> Total execution time: 0.0588
DEBUG - 2022-07-10 00:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:05:01 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:35:01 --> Total execution time: 0.0578
DEBUG - 2022-07-10 00:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:35:03 --> Total execution time: 0.0527
DEBUG - 2022-07-10 00:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:35:24 --> Total execution time: 0.0605
DEBUG - 2022-07-10 00:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:38:01 --> Total execution time: 0.2685
DEBUG - 2022-07-10 00:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:38:09 --> Total execution time: 0.0538
DEBUG - 2022-07-10 00:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:08:17 --> Total execution time: 0.0384
DEBUG - 2022-07-10 00:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:38:30 --> Total execution time: 0.0627
DEBUG - 2022-07-10 00:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:38:35 --> Total execution time: 0.0534
DEBUG - 2022-07-10 00:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:38:42 --> Total execution time: 0.0542
DEBUG - 2022-07-10 00:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:08:47 --> Total execution time: 0.0535
DEBUG - 2022-07-10 00:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:13:25 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:43:26 --> Total execution time: 0.1353
DEBUG - 2022-07-10 00:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:43:31 --> Total execution time: 0.0503
DEBUG - 2022-07-10 00:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:44:08 --> Total execution time: 0.1765
DEBUG - 2022-07-10 00:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:44:10 --> Total execution time: 0.0632
DEBUG - 2022-07-10 00:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:44:48 --> Total execution time: 0.0659
DEBUG - 2022-07-10 00:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:14:50 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:44:50 --> Total execution time: 0.0409
DEBUG - 2022-07-10 00:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:44:55 --> Total execution time: 0.0399
DEBUG - 2022-07-10 00:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:44:56 --> Total execution time: 0.0562
DEBUG - 2022-07-10 00:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:45:04 --> Total execution time: 0.0612
DEBUG - 2022-07-10 00:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:45:07 --> Total execution time: 0.0349
DEBUG - 2022-07-10 00:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:45:09 --> Total execution time: 0.0474
DEBUG - 2022-07-10 00:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:45:10 --> Total execution time: 0.0581
DEBUG - 2022-07-10 00:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:45:14 --> Total execution time: 0.0815
DEBUG - 2022-07-10 00:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:45:29 --> Total execution time: 0.0525
DEBUG - 2022-07-10 00:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:17:53 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:47:54 --> Total execution time: 0.1084
DEBUG - 2022-07-10 00:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:18:01 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:48:01 --> Total execution time: 0.0541
DEBUG - 2022-07-10 00:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:48:16 --> Total execution time: 0.0363
DEBUG - 2022-07-10 00:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:48:46 --> Total execution time: 0.0646
DEBUG - 2022-07-10 00:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:18:49 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:48:49 --> Total execution time: 0.0515
DEBUG - 2022-07-10 00:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:48:53 --> Total execution time: 0.0795
DEBUG - 2022-07-10 00:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:50:34 --> Total execution time: 0.1420
DEBUG - 2022-07-10 00:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:50:37 --> Total execution time: 0.1055
DEBUG - 2022-07-10 00:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:50:45 --> Total execution time: 0.0665
DEBUG - 2022-07-10 00:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:51:32 --> Total execution time: 0.1820
DEBUG - 2022-07-10 00:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:51:39 --> Total execution time: 0.0646
DEBUG - 2022-07-10 00:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:23:53 --> Total execution time: 0.1401
DEBUG - 2022-07-10 00:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:53:57 --> Total execution time: 0.0609
DEBUG - 2022-07-10 00:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:24:05 --> Total execution time: 0.0764
DEBUG - 2022-07-10 00:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:54:20 --> Total execution time: 0.0614
DEBUG - 2022-07-10 00:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:54:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 00:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:54:21 --> Total execution time: 0.0518
DEBUG - 2022-07-10 00:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:55:57 --> Total execution time: 0.0960
DEBUG - 2022-07-10 00:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:56:08 --> Total execution time: 0.0499
DEBUG - 2022-07-10 00:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:56:16 --> Total execution time: 0.0851
DEBUG - 2022-07-10 00:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:56:27 --> Total execution time: 0.0920
DEBUG - 2022-07-10 00:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:56:31 --> Total execution time: 0.1112
DEBUG - 2022-07-10 00:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:26:41 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:56:41 --> Total execution time: 0.0655
DEBUG - 2022-07-10 00:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:26:42 --> Total execution time: 0.0557
DEBUG - 2022-07-10 00:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:26:53 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:56:53 --> Total execution time: 0.0392
DEBUG - 2022-07-10 00:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:26:58 --> Total execution time: 0.0498
DEBUG - 2022-07-10 00:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:57:00 --> Total execution time: 0.0406
DEBUG - 2022-07-10 00:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:27:03 --> Total execution time: 0.0532
DEBUG - 2022-07-10 00:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:57:10 --> Total execution time: 0.0507
DEBUG - 2022-07-10 00:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:27:12 --> Total execution time: 0.0489
DEBUG - 2022-07-10 00:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:27:12 --> Total execution time: 0.0583
DEBUG - 2022-07-10 00:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:27:12 --> Total execution time: 0.1231
DEBUG - 2022-07-10 00:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:27:14 --> Total execution time: 0.0921
DEBUG - 2022-07-10 00:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:27:16 --> Total execution time: 0.0613
DEBUG - 2022-07-10 00:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:57:18 --> Total execution time: 0.1086
DEBUG - 2022-07-10 00:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:57:21 --> Total execution time: 0.0595
DEBUG - 2022-07-10 00:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:57:22 --> Total execution time: 0.0580
DEBUG - 2022-07-10 00:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:57:27 --> Total execution time: 0.0601
DEBUG - 2022-07-10 00:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:57:27 --> Total execution time: 0.0564
DEBUG - 2022-07-10 00:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:57:38 --> Total execution time: 0.0680
DEBUG - 2022-07-10 00:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:57:42 --> Total execution time: 0.0546
DEBUG - 2022-07-10 00:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:57:50 --> Total execution time: 0.1204
DEBUG - 2022-07-10 00:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:57:50 --> Total execution time: 0.0498
DEBUG - 2022-07-10 00:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:57:59 --> Total execution time: 0.0631
DEBUG - 2022-07-10 00:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:58:04 --> Total execution time: 0.1412
DEBUG - 2022-07-10 00:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:28:06 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:58:06 --> Total execution time: 0.0344
DEBUG - 2022-07-10 00:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:58:10 --> Total execution time: 0.0557
DEBUG - 2022-07-10 00:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:58:16 --> Total execution time: 0.0515
DEBUG - 2022-07-10 00:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:58:22 --> Total execution time: 0.0507
DEBUG - 2022-07-10 00:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:58:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 00:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:58:23 --> Total execution time: 0.0479
DEBUG - 2022-07-10 00:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:58:28 --> Total execution time: 0.0957
DEBUG - 2022-07-10 00:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:58:46 --> Total execution time: 0.0796
DEBUG - 2022-07-10 00:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:29:20 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:59:20 --> Total execution time: 0.0485
DEBUG - 2022-07-10 00:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:00:55 --> Total execution time: 0.0724
DEBUG - 2022-07-10 00:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:01:22 --> Total execution time: 0.0582
DEBUG - 2022-07-10 00:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:01:32 --> Total execution time: 0.0705
DEBUG - 2022-07-10 00:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:01:34 --> Total execution time: 0.0529
DEBUG - 2022-07-10 00:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:01:39 --> Total execution time: 0.0554
DEBUG - 2022-07-10 00:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:01:42 --> Total execution time: 0.0541
DEBUG - 2022-07-10 00:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:02:26 --> Total execution time: 0.0609
DEBUG - 2022-07-10 00:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:02:32 --> Total execution time: 0.0644
DEBUG - 2022-07-10 00:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:02:36 --> Total execution time: 0.0562
DEBUG - 2022-07-10 00:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:02:45 --> Total execution time: 0.0631
DEBUG - 2022-07-10 00:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:02:51 --> Total execution time: 0.0555
DEBUG - 2022-07-10 00:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:04:11 --> Total execution time: 0.0611
DEBUG - 2022-07-10 00:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:04:59 --> Total execution time: 0.0510
DEBUG - 2022-07-10 00:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:05:04 --> Total execution time: 0.0626
DEBUG - 2022-07-10 00:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:05:14 --> Total execution time: 0.0577
DEBUG - 2022-07-10 00:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:05:27 --> Total execution time: 0.0897
DEBUG - 2022-07-10 00:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:05:35 --> Total execution time: 0.0611
DEBUG - 2022-07-10 00:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:36:16 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:06:16 --> Total execution time: 0.1365
DEBUG - 2022-07-10 00:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:36:23 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:06:23 --> Total execution time: 0.0717
DEBUG - 2022-07-10 00:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:06:26 --> Total execution time: 0.0575
DEBUG - 2022-07-10 00:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:06:59 --> Total execution time: 0.0683
DEBUG - 2022-07-10 00:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:07:35 --> Total execution time: 0.0696
DEBUG - 2022-07-10 00:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:07:56 --> Total execution time: 0.0601
DEBUG - 2022-07-10 00:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:11:20 --> Total execution time: 0.1367
DEBUG - 2022-07-10 00:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:12:55 --> Total execution time: 0.0495
DEBUG - 2022-07-10 00:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:16:47 --> Total execution time: 0.1318
DEBUG - 2022-07-10 00:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:47:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:17:45 --> Total execution time: 0.0449
DEBUG - 2022-07-10 00:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:17:51 --> Total execution time: 0.0402
DEBUG - 2022-07-10 00:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:17:56 --> Total execution time: 0.0718
DEBUG - 2022-07-10 00:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:18:03 --> Total execution time: 0.0907
DEBUG - 2022-07-10 00:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:18:11 --> Total execution time: 0.1012
DEBUG - 2022-07-10 00:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:19:39 --> Total execution time: 0.0650
DEBUG - 2022-07-10 00:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:19:40 --> Total execution time: 0.0579
DEBUG - 2022-07-10 00:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:20:20 --> Total execution time: 0.1519
DEBUG - 2022-07-10 00:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:21:39 --> Total execution time: 0.1394
DEBUG - 2022-07-10 00:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:51:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 00:51:41 --> 404 Page Not Found: Personal-branding-course/index
DEBUG - 2022-07-10 00:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:21:45 --> Total execution time: 0.0543
DEBUG - 2022-07-10 00:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:21:49 --> Total execution time: 0.0525
DEBUG - 2022-07-10 00:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:21:57 --> Total execution time: 0.0712
DEBUG - 2022-07-10 00:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:21:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 00:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:21:58 --> Total execution time: 0.0624
DEBUG - 2022-07-10 00:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:22:23 --> Total execution time: 0.0520
DEBUG - 2022-07-10 00:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:24:00 --> Total execution time: 0.0587
DEBUG - 2022-07-10 00:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:24:07 --> Total execution time: 0.0651
DEBUG - 2022-07-10 00:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:24:12 --> Total execution time: 0.0799
DEBUG - 2022-07-10 00:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:24:15 --> Total execution time: 0.0587
DEBUG - 2022-07-10 00:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:24:18 --> Total execution time: 0.0597
DEBUG - 2022-07-10 00:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:25:16 --> Total execution time: 0.0591
DEBUG - 2022-07-10 00:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:58:46 --> No URI present. Default controller set.
DEBUG - 2022-07-10 00:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:28:46 --> Total execution time: 0.1188
DEBUG - 2022-07-10 00:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:29:05 --> Total execution time: 0.0550
DEBUG - 2022-07-10 00:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:29:07 --> Total execution time: 0.0565
DEBUG - 2022-07-10 00:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:29:18 --> Total execution time: 0.0610
DEBUG - 2022-07-10 00:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:29:23 --> Total execution time: 0.0580
DEBUG - 2022-07-10 00:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 00:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:29:36 --> Total execution time: 0.0580
DEBUG - 2022-07-10 00:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:29:37 --> Total execution time: 0.0569
DEBUG - 2022-07-10 00:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:29:43 --> Total execution time: 0.0701
DEBUG - 2022-07-10 00:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:29:51 --> Total execution time: 0.1106
DEBUG - 2022-07-10 00:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 00:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 00:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:29:56 --> Total execution time: 0.0551
DEBUG - 2022-07-10 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:30:02 --> Total execution time: 0.0710
DEBUG - 2022-07-10 01:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:30:04 --> Total execution time: 0.0963
DEBUG - 2022-07-10 01:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:30:25 --> Total execution time: 0.0868
DEBUG - 2022-07-10 01:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:30:27 --> Total execution time: 0.0638
DEBUG - 2022-07-10 01:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:30:30 --> Total execution time: 0.0705
DEBUG - 2022-07-10 01:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:30:45 --> Total execution time: 0.0578
DEBUG - 2022-07-10 01:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:30:55 --> Total execution time: 0.0638
DEBUG - 2022-07-10 01:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:31:09 --> Total execution time: 0.0507
DEBUG - 2022-07-10 01:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:01:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:31:45 --> Total execution time: 0.0442
DEBUG - 2022-07-10 01:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:01:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:31:45 --> Total execution time: 0.0358
DEBUG - 2022-07-10 01:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:31:52 --> Total execution time: 0.0345
DEBUG - 2022-07-10 01:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:32:05 --> Total execution time: 0.0535
DEBUG - 2022-07-10 01:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:32:12 --> Total execution time: 0.0979
DEBUG - 2022-07-10 01:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:32:45 --> Total execution time: 0.0651
DEBUG - 2022-07-10 01:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:32:59 --> Total execution time: 0.0697
DEBUG - 2022-07-10 01:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:33:12 --> Total execution time: 0.0555
DEBUG - 2022-07-10 01:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:33:15 --> Total execution time: 0.0700
DEBUG - 2022-07-10 01:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:33:24 --> Total execution time: 0.0715
DEBUG - 2022-07-10 01:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:33:32 --> Total execution time: 0.1454
DEBUG - 2022-07-10 01:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:33:38 --> Total execution time: 0.1165
DEBUG - 2022-07-10 01:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:03:50 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:33:50 --> Total execution time: 0.0351
DEBUG - 2022-07-10 01:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:33:54 --> Total execution time: 0.0282
DEBUG - 2022-07-10 01:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:34:00 --> Total execution time: 0.0517
DEBUG - 2022-07-10 01:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:34:11 --> Total execution time: 0.0895
DEBUG - 2022-07-10 01:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:34:12 --> Total execution time: 0.0520
DEBUG - 2022-07-10 01:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:34:33 --> Total execution time: 0.0947
DEBUG - 2022-07-10 01:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:34:39 --> Total execution time: 0.0692
DEBUG - 2022-07-10 01:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:35:14 --> Total execution time: 0.0601
DEBUG - 2022-07-10 01:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:35:18 --> Total execution time: 0.0797
DEBUG - 2022-07-10 01:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:38:45 --> Total execution time: 0.2486
DEBUG - 2022-07-10 01:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:42:08 --> Total execution time: 0.2563
DEBUG - 2022-07-10 01:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:42:14 --> Total execution time: 0.1538
DEBUG - 2022-07-10 01:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:42:17 --> Total execution time: 0.0533
DEBUG - 2022-07-10 01:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:42:21 --> Total execution time: 0.0424
DEBUG - 2022-07-10 01:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:12:28 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:42:28 --> Total execution time: 0.0394
DEBUG - 2022-07-10 01:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:42:46 --> Total execution time: 0.0553
DEBUG - 2022-07-10 01:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:43:26 --> Total execution time: 0.0858
DEBUG - 2022-07-10 01:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:43:36 --> Total execution time: 0.0648
DEBUG - 2022-07-10 01:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:13:56 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:43:56 --> Total execution time: 0.1397
DEBUG - 2022-07-10 01:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:44:05 --> Total execution time: 0.0549
DEBUG - 2022-07-10 01:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:44:07 --> Total execution time: 0.0512
DEBUG - 2022-07-10 01:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:44:14 --> Total execution time: 0.0587
DEBUG - 2022-07-10 01:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:14:16 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:44:16 --> Total execution time: 0.0431
DEBUG - 2022-07-10 01:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:44:18 --> Total execution time: 0.0647
DEBUG - 2022-07-10 01:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:14:20 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:44:20 --> Total execution time: 0.0319
DEBUG - 2022-07-10 01:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:44:49 --> Total execution time: 0.0497
DEBUG - 2022-07-10 01:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:44:51 --> Total execution time: 0.0478
DEBUG - 2022-07-10 01:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:44:57 --> Total execution time: 0.0684
DEBUG - 2022-07-10 01:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:15:04 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:45:04 --> Total execution time: 0.0325
DEBUG - 2022-07-10 01:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:45:13 --> Total execution time: 0.0526
DEBUG - 2022-07-10 01:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:45:18 --> Total execution time: 0.0452
DEBUG - 2022-07-10 01:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:45:19 --> Total execution time: 0.0864
DEBUG - 2022-07-10 01:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:45:25 --> Total execution time: 0.0801
DEBUG - 2022-07-10 01:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:45:29 --> Total execution time: 0.0507
DEBUG - 2022-07-10 01:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:45:35 --> Total execution time: 0.0529
DEBUG - 2022-07-10 01:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 01:15:47 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-10 01:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:46:08 --> Total execution time: 0.0607
DEBUG - 2022-07-10 01:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:46:14 --> Total execution time: 0.0610
DEBUG - 2022-07-10 01:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:47:28 --> Total execution time: 0.0565
DEBUG - 2022-07-10 01:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:47:37 --> Total execution time: 0.0683
DEBUG - 2022-07-10 01:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:47:42 --> Total execution time: 0.0576
DEBUG - 2022-07-10 01:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:47:58 --> Total execution time: 0.0605
DEBUG - 2022-07-10 01:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:48:00 --> Total execution time: 0.0670
DEBUG - 2022-07-10 01:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:48:13 --> Total execution time: 0.1378
DEBUG - 2022-07-10 01:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:18:13 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:48:13 --> Total execution time: 0.0537
DEBUG - 2022-07-10 01:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:18:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 01:18:30 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 01:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:49:00 --> Total execution time: 0.0653
DEBUG - 2022-07-10 01:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:49:03 --> Total execution time: 0.0514
DEBUG - 2022-07-10 01:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:20:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 01:20:44 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-10 01:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:21:47 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:51:47 --> Total execution time: 0.0399
DEBUG - 2022-07-10 01:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:51:53 --> Total execution time: 0.0667
DEBUG - 2022-07-10 01:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:21:58 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:51:58 --> Total execution time: 0.0489
DEBUG - 2022-07-10 01:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:51:58 --> Total execution time: 0.0585
DEBUG - 2022-07-10 01:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:52:00 --> Total execution time: 0.0517
DEBUG - 2022-07-10 01:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:52:05 --> Total execution time: 0.0560
DEBUG - 2022-07-10 01:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:22:12 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:52:12 --> Total execution time: 0.0353
DEBUG - 2022-07-10 01:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:52:17 --> Total execution time: 0.0589
DEBUG - 2022-07-10 01:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:52:23 --> Total execution time: 0.0347
DEBUG - 2022-07-10 01:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:52:24 --> Total execution time: 0.0540
DEBUG - 2022-07-10 01:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:52:28 --> Total execution time: 0.0575
DEBUG - 2022-07-10 01:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:52:33 --> Total execution time: 0.0744
DEBUG - 2022-07-10 01:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:52:42 --> Total execution time: 0.0534
DEBUG - 2022-07-10 01:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:53:03 --> Total execution time: 0.0555
DEBUG - 2022-07-10 01:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:53:13 --> Total execution time: 0.0708
DEBUG - 2022-07-10 01:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:53:17 --> Total execution time: 0.0577
DEBUG - 2022-07-10 01:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:53:19 --> Total execution time: 0.0799
DEBUG - 2022-07-10 01:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:53:29 --> Total execution time: 0.0704
DEBUG - 2022-07-10 01:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:53:33 --> Total execution time: 0.0555
DEBUG - 2022-07-10 01:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:53:38 --> Total execution time: 0.0678
DEBUG - 2022-07-10 01:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:53:58 --> Total execution time: 0.0535
DEBUG - 2022-07-10 01:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:55:28 --> Total execution time: 0.0553
DEBUG - 2022-07-10 01:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:56:40 --> Total execution time: 0.0829
DEBUG - 2022-07-10 01:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:57:37 --> Total execution time: 0.0596
DEBUG - 2022-07-10 01:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:59:05 --> Total execution time: 0.1516
DEBUG - 2022-07-10 01:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:59:48 --> Total execution time: 0.0536
DEBUG - 2022-07-10 01:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:59:52 --> Total execution time: 0.0506
DEBUG - 2022-07-10 01:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:00:12 --> Total execution time: 0.0609
DEBUG - 2022-07-10 01:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:30:19 --> Total execution time: 0.0738
DEBUG - 2022-07-10 01:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:30:40 --> Total execution time: 0.0512
DEBUG - 2022-07-10 01:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:31:04 --> Total execution time: 0.0519
DEBUG - 2022-07-10 01:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:31:10 --> Total execution time: 0.0615
DEBUG - 2022-07-10 01:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:31:12 --> Total execution time: 0.0484
DEBUG - 2022-07-10 01:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:31:19 --> Total execution time: 0.0499
DEBUG - 2022-07-10 01:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:31:32 --> Total execution time: 0.0691
DEBUG - 2022-07-10 01:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:31:33 --> Total execution time: 0.0543
DEBUG - 2022-07-10 01:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:31:36 --> Total execution time: 0.0517
DEBUG - 2022-07-10 01:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:31:38 --> Total execution time: 0.0823
DEBUG - 2022-07-10 01:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:01:57 --> Total execution time: 0.0709
DEBUG - 2022-07-10 01:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:32:14 --> Total execution time: 0.0475
DEBUG - 2022-07-10 01:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:32:22 --> Total execution time: 0.0570
DEBUG - 2022-07-10 01:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:32:22 --> Total execution time: 0.1009
DEBUG - 2022-07-10 01:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:07:05 --> Total execution time: 0.2416
DEBUG - 2022-07-10 01:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:07:08 --> Total execution time: 0.0697
DEBUG - 2022-07-10 01:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:07:14 --> Total execution time: 0.0681
DEBUG - 2022-07-10 01:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:37:17 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:07:17 --> Total execution time: 0.0407
DEBUG - 2022-07-10 01:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:07:20 --> Total execution time: 0.0368
DEBUG - 2022-07-10 01:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:07:29 --> Total execution time: 0.0563
DEBUG - 2022-07-10 01:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:07:33 --> Total execution time: 0.0830
DEBUG - 2022-07-10 01:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:07:51 --> Total execution time: 0.0628
DEBUG - 2022-07-10 01:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:09:27 --> Total execution time: 0.0382
DEBUG - 2022-07-10 01:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:10:03 --> Total execution time: 0.0656
DEBUG - 2022-07-10 01:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:10:14 --> Total execution time: 0.0724
DEBUG - 2022-07-10 01:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:10:27 --> Total execution time: 0.0719
DEBUG - 2022-07-10 01:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:10:32 --> Total execution time: 0.1600
DEBUG - 2022-07-10 01:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:10:36 --> Total execution time: 0.0903
DEBUG - 2022-07-10 01:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:10:50 --> Total execution time: 0.0954
DEBUG - 2022-07-10 01:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:41:49 --> Total execution time: 0.0679
DEBUG - 2022-07-10 01:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:42:04 --> Total execution time: 0.0557
DEBUG - 2022-07-10 01:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:42:11 --> Total execution time: 0.0493
DEBUG - 2022-07-10 01:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:12:14 --> Total execution time: 0.0611
DEBUG - 2022-07-10 01:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:12:25 --> Total execution time: 0.1326
DEBUG - 2022-07-10 01:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:12:54 --> Total execution time: 0.0533
DEBUG - 2022-07-10 01:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:13:57 --> Total execution time: 0.0496
DEBUG - 2022-07-10 01:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:14:23 --> Total execution time: 0.0533
DEBUG - 2022-07-10 01:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:14:25 --> Total execution time: 0.0603
DEBUG - 2022-07-10 01:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:14:28 --> Total execution time: 0.0501
DEBUG - 2022-07-10 01:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:45:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 01:45:36 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-10 01:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:15:37 --> Total execution time: 0.0561
DEBUG - 2022-07-10 01:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:47:32 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:17:32 --> Total execution time: 0.0889
DEBUG - 2022-07-10 01:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:49:14 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:19:15 --> Total execution time: 0.1482
DEBUG - 2022-07-10 01:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:49:17 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:19:17 --> Total execution time: 0.0546
DEBUG - 2022-07-10 01:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:49:18 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:19:18 --> Total execution time: 0.0359
DEBUG - 2022-07-10 01:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:19:23 --> Total execution time: 0.0588
DEBUG - 2022-07-10 01:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:19:28 --> Total execution time: 0.2459
DEBUG - 2022-07-10 01:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:19:36 --> Total execution time: 0.0526
DEBUG - 2022-07-10 01:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:49:47 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:19:47 --> Total execution time: 0.0366
DEBUG - 2022-07-10 01:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:50:12 --> Total execution time: 0.0540
DEBUG - 2022-07-10 01:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:50:23 --> Total execution time: 0.0534
DEBUG - 2022-07-10 01:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:50:23 --> Total execution time: 0.1307
DEBUG - 2022-07-10 01:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:50:54 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:20:54 --> Total execution time: 0.0444
DEBUG - 2022-07-10 01:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:51:28 --> Total execution time: 0.0519
DEBUG - 2022-07-10 01:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:51:30 --> Total execution time: 0.0594
DEBUG - 2022-07-10 01:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:51:30 --> Total execution time: 0.0651
DEBUG - 2022-07-10 01:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:21:40 --> Total execution time: 0.0495
DEBUG - 2022-07-10 01:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:21:48 --> Total execution time: 0.0617
DEBUG - 2022-07-10 01:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:21:51 --> Total execution time: 0.0555
DEBUG - 2022-07-10 01:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:22:02 --> Total execution time: 0.1180
DEBUG - 2022-07-10 01:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:22:17 --> Total execution time: 0.0522
DEBUG - 2022-07-10 01:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:52:25 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 01:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:52:26 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:22:26 --> Total execution time: 0.0370
DEBUG - 2022-07-10 01:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:52:26 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:22:26 --> Total execution time: 0.0380
DEBUG - 2022-07-10 12:22:28 --> Total execution time: 1.9128
DEBUG - 2022-07-10 01:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:52:32 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:22:32 --> Total execution time: 0.0364
DEBUG - 2022-07-10 01:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:52:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 01:52:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 01:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:24:06 --> Total execution time: 0.1693
DEBUG - 2022-07-10 01:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:24:24 --> Total execution time: 0.0592
DEBUG - 2022-07-10 01:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:24:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 01:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:24:27 --> Total execution time: 0.0590
DEBUG - 2022-07-10 01:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:24:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 12:24:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 12:24:29 --> Total execution time: 0.1876
DEBUG - 2022-07-10 01:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:24:51 --> Total execution time: 0.1328
DEBUG - 2022-07-10 01:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:25:29 --> Total execution time: 0.0534
DEBUG - 2022-07-10 01:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:25:38 --> Total execution time: 0.0584
DEBUG - 2022-07-10 01:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:25:42 --> Total execution time: 0.0779
DEBUG - 2022-07-10 01:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:26:06 --> Total execution time: 0.0633
DEBUG - 2022-07-10 01:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:26:38 --> Total execution time: 0.0585
DEBUG - 2022-07-10 01:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:26:47 --> Total execution time: 0.0566
DEBUG - 2022-07-10 01:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:26:53 --> Total execution time: 0.0558
DEBUG - 2022-07-10 01:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:57:36 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:27:36 --> Total execution time: 0.0506
DEBUG - 2022-07-10 01:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:57:39 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:27:39 --> Total execution time: 0.0392
DEBUG - 2022-07-10 01:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:57:39 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:27:39 --> Total execution time: 0.0323
DEBUG - 2022-07-10 01:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:27:44 --> Total execution time: 0.0486
DEBUG - 2022-07-10 01:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:28:01 --> Total execution time: 0.0536
DEBUG - 2022-07-10 01:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:58:09 --> Total execution time: 0.0549
DEBUG - 2022-07-10 01:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:58:10 --> Total execution time: 0.0520
DEBUG - 2022-07-10 01:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:58:10 --> Total execution time: 0.1145
DEBUG - 2022-07-10 01:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:58:14 --> Total execution time: 0.0499
DEBUG - 2022-07-10 01:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:28:21 --> Total execution time: 0.0555
DEBUG - 2022-07-10 01:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 01:58:26 --> Total execution time: 0.0503
DEBUG - 2022-07-10 01:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:28:30 --> Total execution time: 0.0616
DEBUG - 2022-07-10 01:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:58:36 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:28:36 --> Total execution time: 0.0563
DEBUG - 2022-07-10 01:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 01:58:44 --> No URI present. Default controller set.
DEBUG - 2022-07-10 01:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 01:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:28:44 --> Total execution time: 0.0351
DEBUG - 2022-07-10 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:30:03 --> Total execution time: 0.0409
DEBUG - 2022-07-10 02:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:00:15 --> Total execution time: 0.0592
DEBUG - 2022-07-10 02:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:00:24 --> Total execution time: 0.1122
DEBUG - 2022-07-10 02:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:00:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:30:45 --> Total execution time: 0.1293
DEBUG - 2022-07-10 02:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:31:00 --> Total execution time: 0.0854
DEBUG - 2022-07-10 02:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:31:06 --> Total execution time: 0.0721
DEBUG - 2022-07-10 02:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:31:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 02:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:31:20 --> Total execution time: 0.0783
DEBUG - 2022-07-10 02:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:31:20 --> Total execution time: 0.0545
DEBUG - 2022-07-10 02:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:31:27 --> Total execution time: 0.0753
DEBUG - 2022-07-10 02:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:31:30 --> Total execution time: 0.0700
DEBUG - 2022-07-10 02:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:31:37 --> Total execution time: 0.0799
DEBUG - 2022-07-10 02:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:31:53 --> Total execution time: 0.0568
DEBUG - 2022-07-10 12:31:53 --> Total execution time: 0.1476
DEBUG - 2022-07-10 02:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:32:05 --> Total execution time: 0.0537
DEBUG - 2022-07-10 02:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:32:57 --> Total execution time: 0.2649
DEBUG - 2022-07-10 02:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:37:32 --> Total execution time: 0.0568
DEBUG - 2022-07-10 02:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:37:44 --> Total execution time: 0.0594
DEBUG - 2022-07-10 02:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:07:49 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:37:50 --> Total execution time: 0.0563
DEBUG - 2022-07-10 02:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:37:58 --> Total execution time: 0.0303
DEBUG - 2022-07-10 02:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:38:22 --> Total execution time: 0.0588
DEBUG - 2022-07-10 02:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:38:35 --> Total execution time: 0.0548
DEBUG - 2022-07-10 02:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:08:40 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:38:40 --> Total execution time: 0.0362
DEBUG - 2022-07-10 02:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:38:46 --> Total execution time: 0.0539
DEBUG - 2022-07-10 02:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:38:56 --> Total execution time: 0.0736
DEBUG - 2022-07-10 02:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:41:53 --> Total execution time: 0.0609
DEBUG - 2022-07-10 02:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:42:22 --> Total execution time: 0.0589
DEBUG - 2022-07-10 02:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:42:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 02:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:42:38 --> Total execution time: 0.0526
DEBUG - 2022-07-10 02:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:42:53 --> Total execution time: 0.0933
DEBUG - 2022-07-10 02:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:43:01 --> Total execution time: 0.0876
DEBUG - 2022-07-10 02:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:13:30 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:43:30 --> Total execution time: 0.0425
DEBUG - 2022-07-10 02:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:13:34 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:43:34 --> Total execution time: 0.0514
DEBUG - 2022-07-10 02:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:43:43 --> Total execution time: 1.8916
DEBUG - 2022-07-10 02:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:13:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 02:13:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 02:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:14:12 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:44:12 --> Total execution time: 0.0527
DEBUG - 2022-07-10 02:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:44:34 --> Total execution time: 2.4765
DEBUG - 2022-07-10 02:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:15:13 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:45:13 --> Total execution time: 0.0390
DEBUG - 2022-07-10 02:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:16:52 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:46:52 --> Total execution time: 0.0581
DEBUG - 2022-07-10 02:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:18:11 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:48:11 --> Total execution time: 0.0429
DEBUG - 2022-07-10 02:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:54:23 --> Total execution time: 0.0553
DEBUG - 2022-07-10 02:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:27:52 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:57:52 --> Total execution time: 0.2517
DEBUG - 2022-07-10 02:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:27:54 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:57:55 --> Total execution time: 0.0549
DEBUG - 2022-07-10 02:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:27:55 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:57:55 --> Total execution time: 0.0345
DEBUG - 2022-07-10 02:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:58:00 --> Total execution time: 0.0578
DEBUG - 2022-07-10 02:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:28:02 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:58:02 --> Total execution time: 0.0506
DEBUG - 2022-07-10 02:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:28:02 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:58:02 --> Total execution time: 0.0580
DEBUG - 2022-07-10 02:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:58:03 --> Total execution time: 0.0271
DEBUG - 2022-07-10 02:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:28:04 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:58:04 --> Total execution time: 0.0479
DEBUG - 2022-07-10 02:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:58:10 --> Total execution time: 0.0580
DEBUG - 2022-07-10 02:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:28:16 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:58:16 --> Total execution time: 0.0530
DEBUG - 2022-07-10 02:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:58:21 --> Total execution time: 0.0507
DEBUG - 2022-07-10 02:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:58:41 --> Total execution time: 0.0544
DEBUG - 2022-07-10 02:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:58:50 --> Total execution time: 0.0687
DEBUG - 2022-07-10 02:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:58:53 --> Total execution time: 0.0690
DEBUG - 2022-07-10 02:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:29:16 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:59:17 --> Total execution time: 0.0623
DEBUG - 2022-07-10 02:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:59:26 --> Total execution time: 0.0374
DEBUG - 2022-07-10 02:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:59:39 --> Total execution time: 0.0797
DEBUG - 2022-07-10 02:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:59:55 --> Total execution time: 0.0535
DEBUG - 2022-07-10 02:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:59:58 --> Total execution time: 0.0538
DEBUG - 2022-07-10 02:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:30:20 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:00:20 --> Total execution time: 0.0356
DEBUG - 2022-07-10 02:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:00:29 --> Total execution time: 0.0772
DEBUG - 2022-07-10 02:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:00:42 --> Total execution time: 0.0768
DEBUG - 2022-07-10 02:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:00:51 --> Total execution time: 0.0586
DEBUG - 2022-07-10 02:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:00:59 --> Total execution time: 0.0553
DEBUG - 2022-07-10 02:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:01:02 --> Total execution time: 0.0619
DEBUG - 2022-07-10 02:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:32:27 --> Total execution time: 0.0526
DEBUG - 2022-07-10 02:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:32:32 --> Total execution time: 0.0541
DEBUG - 2022-07-10 02:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:32:32 --> Total execution time: 0.1056
DEBUG - 2022-07-10 02:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:05:00 --> Total execution time: 0.2071
DEBUG - 2022-07-10 02:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:35:20 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:05:20 --> Total execution time: 0.0400
DEBUG - 2022-07-10 02:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:35:20 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:05:20 --> Total execution time: 0.0375
DEBUG - 2022-07-10 02:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:09:41 --> Total execution time: 0.1932
DEBUG - 2022-07-10 02:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:15:23 --> Total execution time: 0.2112
DEBUG - 2022-07-10 02:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:15:26 --> Total execution time: 0.0627
DEBUG - 2022-07-10 02:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:15:26 --> Total execution time: 0.0580
DEBUG - 2022-07-10 02:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:45:27 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:15:27 --> Total execution time: 0.1318
DEBUG - 2022-07-10 02:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:45:57 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:15:57 --> Total execution time: 0.0409
DEBUG - 2022-07-10 02:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:16:10 --> Total execution time: 0.1520
DEBUG - 2022-07-10 02:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:16:12 --> Total execution time: 0.0439
DEBUG - 2022-07-10 02:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:16:33 --> Total execution time: 0.0612
DEBUG - 2022-07-10 02:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:46:46 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:16:46 --> Total execution time: 0.0582
DEBUG - 2022-07-10 02:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:16:52 --> Total execution time: 0.0579
DEBUG - 2022-07-10 02:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:16:55 --> Total execution time: 0.0345
DEBUG - 2022-07-10 02:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:01 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:01 --> Total execution time: 0.0511
DEBUG - 2022-07-10 02:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:08 --> Total execution time: 0.0511
DEBUG - 2022-07-10 02:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:10 --> Total execution time: 0.0642
DEBUG - 2022-07-10 02:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:11 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:11 --> Total execution time: 0.0613
DEBUG - 2022-07-10 02:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:13 --> Total execution time: 0.0584
DEBUG - 2022-07-10 02:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:19 --> Total execution time: 0.0493
DEBUG - 2022-07-10 02:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:23 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:23 --> Total execution time: 0.0551
DEBUG - 2022-07-10 02:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:24 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:24 --> Total execution time: 0.0513
DEBUG - 2022-07-10 02:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:37 --> Total execution time: 0.0399
DEBUG - 2022-07-10 02:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:37 --> Total execution time: 0.0572
DEBUG - 2022-07-10 02:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:47 --> Total execution time: 0.0607
DEBUG - 2022-07-10 02:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:51 --> Total execution time: 0.0576
DEBUG - 2022-07-10 02:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:53 --> Total execution time: 0.0808
DEBUG - 2022-07-10 02:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:53 --> Total execution time: 0.0564
DEBUG - 2022-07-10 02:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:54 --> Total execution time: 0.0601
DEBUG - 2022-07-10 02:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:54 --> Total execution time: 0.0617
DEBUG - 2022-07-10 02:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:54 --> Total execution time: 0.0722
DEBUG - 2022-07-10 02:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:55 --> Total execution time: 0.0660
DEBUG - 2022-07-10 02:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:55 --> Total execution time: 0.0588
DEBUG - 2022-07-10 02:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:55 --> Total execution time: 0.0611
DEBUG - 2022-07-10 02:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:55 --> Total execution time: 0.0788
DEBUG - 2022-07-10 02:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:18:05 --> Total execution time: 0.0582
DEBUG - 2022-07-10 02:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:48:09 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:18:09 --> Total execution time: 0.0727
DEBUG - 2022-07-10 02:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:18:28 --> Total execution time: 0.0502
DEBUG - 2022-07-10 02:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:18:35 --> Total execution time: 0.0498
DEBUG - 2022-07-10 02:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:19:17 --> Total execution time: 0.0679
DEBUG - 2022-07-10 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:19:20 --> Total execution time: 0.0548
DEBUG - 2022-07-10 02:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:19:24 --> Total execution time: 0.0556
DEBUG - 2022-07-10 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:19:25 --> Total execution time: 0.0590
DEBUG - 2022-07-10 02:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:19:29 --> Total execution time: 0.0609
DEBUG - 2022-07-10 02:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:19:29 --> Total execution time: 0.0563
DEBUG - 2022-07-10 02:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:19:31 --> Total execution time: 0.0686
DEBUG - 2022-07-10 02:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:49:35 --> Total execution time: 0.0518
DEBUG - 2022-07-10 02:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:49:49 --> Total execution time: 0.0502
DEBUG - 2022-07-10 02:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:50:05 --> Total execution time: 0.0537
DEBUG - 2022-07-10 02:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:50:08 --> Total execution time: 0.0497
DEBUG - 2022-07-10 02:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:50:19 --> Total execution time: 0.0498
DEBUG - 2022-07-10 02:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:20:19 --> Total execution time: 0.0599
DEBUG - 2022-07-10 02:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:20:27 --> Total execution time: 0.0847
DEBUG - 2022-07-10 02:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:50:35 --> Total execution time: 0.0513
DEBUG - 2022-07-10 02:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:50:38 --> Total execution time: 0.0495
DEBUG - 2022-07-10 02:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:50:38 --> Total execution time: 0.0492
DEBUG - 2022-07-10 02:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:50:39 --> Total execution time: 0.0496
DEBUG - 2022-07-10 02:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:20:39 --> Total execution time: 0.0556
DEBUG - 2022-07-10 02:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:20:39 --> Total execution time: 0.0552
DEBUG - 2022-07-10 02:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:20:46 --> Total execution time: 0.0572
DEBUG - 2022-07-10 02:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:20:53 --> Total execution time: 0.0550
DEBUG - 2022-07-10 02:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:20:56 --> Total execution time: 0.1326
DEBUG - 2022-07-10 02:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:51:00 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:21:00 --> Total execution time: 0.1243
DEBUG - 2022-07-10 02:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:21:04 --> Total execution time: 0.0562
DEBUG - 2022-07-10 02:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:21:09 --> Total execution time: 0.0665
DEBUG - 2022-07-10 02:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:21:11 --> Total execution time: 0.0699
DEBUG - 2022-07-10 02:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:21:39 --> Total execution time: 0.0585
DEBUG - 2022-07-10 02:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:21:39 --> Total execution time: 0.1649
DEBUG - 2022-07-10 02:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:21:41 --> Total execution time: 0.0564
DEBUG - 2022-07-10 02:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:21:50 --> Total execution time: 0.0500
DEBUG - 2022-07-10 02:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:51:56 --> Total execution time: 0.0514
DEBUG - 2022-07-10 02:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:51:57 --> Total execution time: 0.0618
DEBUG - 2022-07-10 02:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:51:57 --> Total execution time: 0.1090
DEBUG - 2022-07-10 02:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:22:52 --> Total execution time: 0.0486
DEBUG - 2022-07-10 02:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:52:59 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:22:59 --> Total execution time: 0.0665
DEBUG - 2022-07-10 02:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:53:04 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:23:04 --> Total execution time: 0.0585
DEBUG - 2022-07-10 02:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:53:19 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:23:19 --> Total execution time: 0.0621
DEBUG - 2022-07-10 02:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:53:39 --> Total execution time: 0.0927
DEBUG - 2022-07-10 02:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:53:43 --> Total execution time: 0.0952
DEBUG - 2022-07-10 02:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:53:43 --> Total execution time: 0.1367
DEBUG - 2022-07-10 02:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:24:25 --> Total execution time: 0.1360
DEBUG - 2022-07-10 02:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:24:29 --> Total execution time: 0.0552
DEBUG - 2022-07-10 02:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:24:42 --> Total execution time: 0.0520
DEBUG - 2022-07-10 02:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:54:44 --> Total execution time: 0.0601
DEBUG - 2022-07-10 02:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:54:46 --> Total execution time: 0.0545
DEBUG - 2022-07-10 02:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:54:46 --> Total execution time: 0.1311
DEBUG - 2022-07-10 02:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:24:58 --> Total execution time: 0.0533
DEBUG - 2022-07-10 02:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:55:05 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:25:05 --> Total execution time: 0.0405
DEBUG - 2022-07-10 02:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:55:10 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:25:10 --> Total execution time: 0.0557
DEBUG - 2022-07-10 02:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:56:41 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:26:41 --> Total execution time: 0.0583
DEBUG - 2022-07-10 02:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:26:46 --> Total execution time: 0.0404
DEBUG - 2022-07-10 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:56:49 --> Total execution time: 0.0548
DEBUG - 2022-07-10 02:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:56:51 --> Total execution time: 0.0617
DEBUG - 2022-07-10 02:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:56:51 --> Total execution time: 0.0768
DEBUG - 2022-07-10 02:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:27:14 --> Total execution time: 0.0700
DEBUG - 2022-07-10 02:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:27:15 --> Total execution time: 0.0345
DEBUG - 2022-07-10 02:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:57:54 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:27:55 --> Total execution time: 0.1285
DEBUG - 2022-07-10 02:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:58:05 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:28:06 --> Total execution time: 0.0357
DEBUG - 2022-07-10 02:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:28:18 --> Total execution time: 0.0614
DEBUG - 2022-07-10 02:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:28:21 --> Total execution time: 0.0561
DEBUG - 2022-07-10 02:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:28:24 --> Total execution time: 0.0602
DEBUG - 2022-07-10 02:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 02:58:44 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-10 02:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:58:58 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:28:58 --> Total execution time: 0.0531
DEBUG - 2022-07-10 02:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:59:03 --> Total execution time: 0.0518
DEBUG - 2022-07-10 02:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:59:04 --> Total execution time: 0.0587
DEBUG - 2022-07-10 02:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:59:04 --> Total execution time: 0.1018
DEBUG - 2022-07-10 02:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:59:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:29:45 --> Total execution time: 0.0814
DEBUG - 2022-07-10 02:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:29:51 --> Total execution time: 0.0619
DEBUG - 2022-07-10 02:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 02:59:53 --> Total execution time: 0.0567
DEBUG - 2022-07-10 02:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:29:54 --> Total execution time: 0.0565
DEBUG - 2022-07-10 02:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:29:56 --> Total execution time: 0.0699
DEBUG - 2022-07-10 02:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 02:59:58 --> No URI present. Default controller set.
DEBUG - 2022-07-10 02:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 02:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:29:58 --> Total execution time: 0.0632
DEBUG - 2022-07-10 03:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:30:00 --> Total execution time: 0.1303
DEBUG - 2022-07-10 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:30:02 --> Total execution time: 0.0773
DEBUG - 2022-07-10 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:30:02 --> Total execution time: 0.0832
DEBUG - 2022-07-10 03:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:00:04 --> Total execution time: 0.0606
DEBUG - 2022-07-10 03:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:00:06 --> Total execution time: 0.0622
DEBUG - 2022-07-10 03:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:00:06 --> Total execution time: 0.1393
DEBUG - 2022-07-10 03:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:30:11 --> Total execution time: 0.1132
DEBUG - 2022-07-10 03:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:00:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 03:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:30:59 --> Total execution time: 2.9287
DEBUG - 2022-07-10 03:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:01:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:01:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 03:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:01:25 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 03:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:01:53 --> Total execution time: 0.0431
DEBUG - 2022-07-10 03:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:31:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 03:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:31:59 --> Total execution time: 0.0625
DEBUG - 2022-07-10 03:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:32:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 13:32:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 13:32:02 --> Total execution time: 0.1828
DEBUG - 2022-07-10 03:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:02:04 --> Total execution time: 0.0484
DEBUG - 2022-07-10 03:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:02:11 --> Total execution time: 0.0599
DEBUG - 2022-07-10 03:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:32:11 --> Total execution time: 0.0685
DEBUG - 2022-07-10 03:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:02:14 --> Total execution time: 0.0550
DEBUG - 2022-07-10 03:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:32:15 --> Total execution time: 0.0533
DEBUG - 2022-07-10 03:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:02:17 --> Total execution time: 0.0438
DEBUG - 2022-07-10 03:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:32:19 --> Total execution time: 0.0692
DEBUG - 2022-07-10 03:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:32:28 --> Total execution time: 0.0783
DEBUG - 2022-07-10 03:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:02:33 --> Total execution time: 0.0572
DEBUG - 2022-07-10 03:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:32:35 --> Total execution time: 0.0569
DEBUG - 2022-07-10 03:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:02:35 --> Total execution time: 0.0530
DEBUG - 2022-07-10 03:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:02:37 --> Total execution time: 0.0561
DEBUG - 2022-07-10 03:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:32:44 --> Total execution time: 0.0842
DEBUG - 2022-07-10 03:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:32:44 --> Total execution time: 0.0547
DEBUG - 2022-07-10 03:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:02:48 --> 404 Page Not Found: Apple-app-site-association/index
DEBUG - 2022-07-10 03:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:32:56 --> Total execution time: 0.1513
DEBUG - 2022-07-10 03:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:33:00 --> Total execution time: 0.0550
DEBUG - 2022-07-10 03:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:33:05 --> Total execution time: 0.0542
DEBUG - 2022-07-10 03:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:33:13 --> Total execution time: 0.0558
DEBUG - 2022-07-10 03:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:03:20 --> Total execution time: 0.0492
DEBUG - 2022-07-10 03:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:03:29 --> Total execution time: 0.0500
DEBUG - 2022-07-10 03:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:03:36 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-10 03:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:33:42 --> Total execution time: 0.0604
DEBUG - 2022-07-10 03:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:33:43 --> Total execution time: 0.0554
DEBUG - 2022-07-10 03:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:33:44 --> Total execution time: 0.0502
DEBUG - 2022-07-10 03:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:03:44 --> Total execution time: 0.0497
DEBUG - 2022-07-10 03:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:03:50 --> Total execution time: 0.0514
DEBUG - 2022-07-10 03:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:33:50 --> Total execution time: 0.0735
DEBUG - 2022-07-10 03:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:03:52 --> Total execution time: 0.0526
DEBUG - 2022-07-10 03:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:33:55 --> Total execution time: 0.0782
DEBUG - 2022-07-10 03:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:33:57 --> Total execution time: 0.0567
DEBUG - 2022-07-10 03:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:34:02 --> Total execution time: 0.0508
DEBUG - 2022-07-10 03:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:04:25 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:34:25 --> Total execution time: 0.0692
DEBUG - 2022-07-10 03:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:34:33 --> Total execution time: 0.0525
DEBUG - 2022-07-10 03:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:34:36 --> Total execution time: 0.1384
DEBUG - 2022-07-10 03:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:34:38 --> Total execution time: 0.0550
DEBUG - 2022-07-10 03:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:34:44 --> Total execution time: 0.0541
DEBUG - 2022-07-10 03:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:34:51 --> Total execution time: 0.0563
DEBUG - 2022-07-10 03:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:35:01 --> Total execution time: 0.0828
DEBUG - 2022-07-10 03:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:35:25 --> Total execution time: 0.0504
DEBUG - 2022-07-10 03:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:35:26 --> Total execution time: 0.0565
DEBUG - 2022-07-10 03:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:05:49 --> Total execution time: 0.0447
DEBUG - 2022-07-10 03:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:05:54 --> Total execution time: 0.0560
DEBUG - 2022-07-10 03:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:06:10 --> Total execution time: 0.0491
DEBUG - 2022-07-10 03:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:06:11 --> Total execution time: 0.0489
DEBUG - 2022-07-10 03:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:06:16 --> Total execution time: 0.0554
DEBUG - 2022-07-10 03:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:06:42 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:36:42 --> Total execution time: 0.1398
DEBUG - 2022-07-10 03:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:06:45 --> Total execution time: 0.0611
DEBUG - 2022-07-10 03:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:06:51 --> Total execution time: 0.0502
DEBUG - 2022-07-10 03:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:06:59 --> Total execution time: 0.0638
DEBUG - 2022-07-10 03:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:07:00 --> Total execution time: 0.0721
DEBUG - 2022-07-10 03:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:07:31 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:37:31 --> Total execution time: 0.0528
DEBUG - 2022-07-10 03:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:37:34 --> Total execution time: 0.0490
DEBUG - 2022-07-10 03:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:37:37 --> Total execution time: 0.0499
DEBUG - 2022-07-10 03:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:37:41 --> Total execution time: 0.0549
DEBUG - 2022-07-10 03:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:37:45 --> Total execution time: 0.0443
DEBUG - 2022-07-10 03:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:37:48 --> Total execution time: 0.0480
DEBUG - 2022-07-10 03:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:00 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:38:00 --> Total execution time: 0.0421
DEBUG - 2022-07-10 03:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:02 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:38:02 --> Total execution time: 0.0452
DEBUG - 2022-07-10 03:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:03 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:38:03 --> Total execution time: 0.0630
DEBUG - 2022-07-10 03:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:03 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:38:03 --> Total execution time: 0.0518
DEBUG - 2022-07-10 03:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:38:06 --> Total execution time: 0.0464
DEBUG - 2022-07-10 03:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:19 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:38:19 --> Total execution time: 0.1394
DEBUG - 2022-07-10 03:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:29 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:38:29 --> Total execution time: 0.0298
DEBUG - 2022-07-10 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:08:35 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-10 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:08:35 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-07-10 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:08:35 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-10 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:08:35 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-07-10 03:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:08:36 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-07-10 03:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:08:36 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-10 03:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:08:37 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-10 03:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:08:37 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-07-10 03:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:08:41 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:38:41 --> Total execution time: 0.0461
DEBUG - 2022-07-10 03:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:09:03 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:39:03 --> Total execution time: 0.0372
DEBUG - 2022-07-10 03:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:09:05 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:39:05 --> Total execution time: 0.0572
DEBUG - 2022-07-10 03:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:09:10 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:39:10 --> Total execution time: 0.0608
DEBUG - 2022-07-10 03:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:39:21 --> Total execution time: 0.0548
DEBUG - 2022-07-10 03:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:39:38 --> Total execution time: 0.0593
DEBUG - 2022-07-10 03:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:39:41 --> Total execution time: 0.0641
DEBUG - 2022-07-10 03:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:39:53 --> Total execution time: 0.0553
DEBUG - 2022-07-10 03:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:09:58 --> Total execution time: 0.0551
DEBUG - 2022-07-10 03:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:10:12 --> Total execution time: 0.0494
DEBUG - 2022-07-10 03:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:10:17 --> Total execution time: 0.0501
DEBUG - 2022-07-10 03:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:10:45 --> Total execution time: 0.0498
DEBUG - 2022-07-10 03:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:10:56 --> Total execution time: 0.0522
DEBUG - 2022-07-10 03:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:10:56 --> Total execution time: 0.0521
DEBUG - 2022-07-10 03:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:11:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:41:08 --> Total execution time: 0.0517
DEBUG - 2022-07-10 03:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:11:31 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:41:31 --> Total execution time: 0.0538
DEBUG - 2022-07-10 03:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:41:35 --> Total execution time: 0.0518
DEBUG - 2022-07-10 03:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:41:44 --> Total execution time: 0.0662
DEBUG - 2022-07-10 03:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:41:52 --> Total execution time: 0.0630
DEBUG - 2022-07-10 03:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:42:44 --> Total execution time: 0.1310
DEBUG - 2022-07-10 03:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:42:45 --> Total execution time: 0.0577
DEBUG - 2022-07-10 03:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:12:52 --> Total execution time: 0.0564
DEBUG - 2022-07-10 03:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:42:55 --> Total execution time: 0.1620
DEBUG - 2022-07-10 03:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:12:56 --> Total execution time: 0.0555
DEBUG - 2022-07-10 03:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:42:58 --> Total execution time: 0.0548
DEBUG - 2022-07-10 03:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:12:59 --> Total execution time: 0.0492
DEBUG - 2022-07-10 03:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:43:00 --> Total execution time: 0.0593
DEBUG - 2022-07-10 03:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:43:04 --> Total execution time: 0.0562
DEBUG - 2022-07-10 03:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:13:07 --> Total execution time: 0.0508
DEBUG - 2022-07-10 03:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:13:09 --> Total execution time: 0.0543
DEBUG - 2022-07-10 03:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:43:14 --> Total execution time: 0.0504
DEBUG - 2022-07-10 03:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:43:17 --> Total execution time: 0.0622
DEBUG - 2022-07-10 03:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:13:18 --> Total execution time: 0.0491
DEBUG - 2022-07-10 03:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:13:23 --> Total execution time: 0.0496
DEBUG - 2022-07-10 03:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:43:24 --> Total execution time: 0.0536
DEBUG - 2022-07-10 03:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:34 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:43:34 --> Total execution time: 0.0535
DEBUG - 2022-07-10 03:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:43:35 --> Total execution time: 0.0604
DEBUG - 2022-07-10 03:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:43:39 --> Total execution time: 0.0582
DEBUG - 2022-07-10 03:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:41 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:43:41 --> Total execution time: 0.1253
DEBUG - 2022-07-10 03:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:43:42 --> Total execution time: 0.0551
DEBUG - 2022-07-10 03:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:43:46 --> Total execution time: 0.0815
DEBUG - 2022-07-10 03:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:13:53 --> Total execution time: 0.0505
DEBUG - 2022-07-10 03:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:44:03 --> Total execution time: 0.0492
DEBUG - 2022-07-10 03:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:44:09 --> Total execution time: 0.0691
DEBUG - 2022-07-10 03:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:44:11 --> Total execution time: 0.0581
DEBUG - 2022-07-10 03:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:44:39 --> Total execution time: 0.1322
DEBUG - 2022-07-10 03:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:14:39 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:44:39 --> Total execution time: 0.1880
DEBUG - 2022-07-10 03:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:44:41 --> Total execution time: 0.0573
DEBUG - 2022-07-10 03:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:44:45 --> Total execution time: 0.0603
DEBUG - 2022-07-10 03:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:44:46 --> Total execution time: 0.0490
DEBUG - 2022-07-10 03:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:45:23 --> Total execution time: 0.0593
DEBUG - 2022-07-10 03:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:45:32 --> Total execution time: 0.0559
DEBUG - 2022-07-10 03:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:16:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:16:04 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-07-10 03:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:46:10 --> Total execution time: 0.0589
DEBUG - 2022-07-10 03:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:46:25 --> Total execution time: 0.0784
DEBUG - 2022-07-10 03:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:46:29 --> Total execution time: 0.0859
DEBUG - 2022-07-10 03:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:46:44 --> Total execution time: 0.0543
DEBUG - 2022-07-10 03:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:47:29 --> Total execution time: 0.0555
DEBUG - 2022-07-10 03:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:17:35 --> Total execution time: 0.0631
DEBUG - 2022-07-10 03:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:47:37 --> Total execution time: 0.0557
DEBUG - 2022-07-10 03:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:47:40 --> Total execution time: 0.0576
DEBUG - 2022-07-10 03:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:48:01 --> Total execution time: 0.0597
DEBUG - 2022-07-10 03:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:48:14 --> Total execution time: 0.0574
DEBUG - 2022-07-10 03:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:48:21 --> Total execution time: 0.1350
DEBUG - 2022-07-10 03:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:48:28 --> Total execution time: 0.1003
DEBUG - 2022-07-10 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:48:59 --> Total execution time: 0.0533
DEBUG - 2022-07-10 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:49:09 --> Total execution time: 0.0523
DEBUG - 2022-07-10 03:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:49:26 --> Total execution time: 0.1435
DEBUG - 2022-07-10 13:49:26 --> Total execution time: 0.1480
DEBUG - 2022-07-10 03:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:19:26 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:49:26 --> Total execution time: 0.1316
DEBUG - 2022-07-10 03:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:49:58 --> Total execution time: 0.0645
DEBUG - 2022-07-10 03:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:50:22 --> Total execution time: 0.1373
DEBUG - 2022-07-10 03:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:51:15 --> Total execution time: 0.0663
DEBUG - 2022-07-10 03:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:51:15 --> Total execution time: 0.0588
DEBUG - 2022-07-10 03:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:51:26 --> Total execution time: 0.0451
DEBUG - 2022-07-10 03:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:23:38 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:53:38 --> Total execution time: 0.0368
DEBUG - 2022-07-10 03:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:54:31 --> Total execution time: 0.0369
DEBUG - 2022-07-10 03:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:24:35 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:54:35 --> Total execution time: 0.0527
DEBUG - 2022-07-10 03:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:54:53 --> Total execution time: 0.2232
DEBUG - 2022-07-10 03:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:55:01 --> Total execution time: 0.0402
DEBUG - 2022-07-10 03:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:55:19 --> Total execution time: 0.0506
DEBUG - 2022-07-10 03:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:25:24 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:55:24 --> Total execution time: 0.1404
DEBUG - 2022-07-10 03:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:55:28 --> Total execution time: 0.0642
DEBUG - 2022-07-10 03:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:55:38 --> Total execution time: 0.0621
DEBUG - 2022-07-10 03:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:55:53 --> Total execution time: 0.0611
DEBUG - 2022-07-10 03:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:56:11 --> Total execution time: 0.0583
DEBUG - 2022-07-10 03:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:56:20 --> Total execution time: 0.0601
DEBUG - 2022-07-10 03:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:56:20 --> Total execution time: 0.0533
DEBUG - 2022-07-10 03:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:56:28 --> Total execution time: 0.0572
DEBUG - 2022-07-10 03:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:56:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 03:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:56:29 --> Total execution time: 0.0608
DEBUG - 2022-07-10 03:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:56:53 --> Total execution time: 0.0735
DEBUG - 2022-07-10 03:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:57:34 --> Total execution time: 0.0681
DEBUG - 2022-07-10 03:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:57:35 --> Total execution time: 0.0629
DEBUG - 2022-07-10 03:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:27:39 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:57:39 --> Total execution time: 0.0607
DEBUG - 2022-07-10 03:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:27:47 --> Total execution time: 0.0737
DEBUG - 2022-07-10 03:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:57:55 --> Total execution time: 0.0538
DEBUG - 2022-07-10 03:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:27:57 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:57:57 --> Total execution time: 0.0716
DEBUG - 2022-07-10 03:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:27:57 --> Total execution time: 0.1069
DEBUG - 2022-07-10 03:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:58:05 --> Total execution time: 0.0561
DEBUG - 2022-07-10 03:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:28:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:28:20 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-10 03:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:58:22 --> Total execution time: 0.0692
DEBUG - 2022-07-10 03:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:58:25 --> Total execution time: 0.0800
DEBUG - 2022-07-10 03:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:58:36 --> Total execution time: 0.0587
DEBUG - 2022-07-10 03:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:58:39 --> Total execution time: 0.0783
DEBUG - 2022-07-10 03:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:59:04 --> Total execution time: 0.0601
DEBUG - 2022-07-10 03:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:59:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 13:59:20 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-07-10 03:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:59:21 --> Total execution time: 0.0753
DEBUG - 2022-07-10 03:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:59:22 --> Total execution time: 0.0551
DEBUG - 2022-07-10 03:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:59:34 --> Total execution time: 0.0641
DEBUG - 2022-07-10 03:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:59:36 --> Total execution time: 0.0933
DEBUG - 2022-07-10 03:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:59:45 --> Total execution time: 0.0561
DEBUG - 2022-07-10 03:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:59:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 03:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:59:46 --> Total execution time: 0.0690
DEBUG - 2022-07-10 03:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:59:50 --> Total execution time: 0.0520
DEBUG - 2022-07-10 03:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:59:51 --> Total execution time: 0.0781
DEBUG - 2022-07-10 03:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:59:55 --> Total execution time: 0.0715
DEBUG - 2022-07-10 03:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:00:02 --> Total execution time: 0.0831
DEBUG - 2022-07-10 03:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:00:46 --> Total execution time: 0.1351
DEBUG - 2022-07-10 03:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:30:52 --> Total execution time: 0.1439
DEBUG - 2022-07-10 03:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:00:54 --> Total execution time: 0.0632
DEBUG - 2022-07-10 03:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:30:57 --> Total execution time: 0.0502
DEBUG - 2022-07-10 03:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:30:57 --> Total execution time: 0.1095
DEBUG - 2022-07-10 03:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:01:57 --> Total execution time: 0.1436
DEBUG - 2022-07-10 03:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:32:02 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:02:02 --> Total execution time: 0.0578
DEBUG - 2022-07-10 03:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:32:19 --> Total execution time: 0.0705
DEBUG - 2022-07-10 03:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:32:20 --> Total execution time: 0.0600
DEBUG - 2022-07-10 03:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:32:20 --> Total execution time: 0.1115
DEBUG - 2022-07-10 03:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:32:26 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:02:26 --> Total execution time: 0.0568
DEBUG - 2022-07-10 03:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:02:39 --> Total execution time: 0.0518
DEBUG - 2022-07-10 03:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:02:40 --> Total execution time: 0.0525
DEBUG - 2022-07-10 03:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:03:11 --> Total execution time: 0.0564
DEBUG - 2022-07-10 03:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:40:51 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:10:51 --> Total execution time: 0.1178
DEBUG - 2022-07-10 03:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:10:53 --> Total execution time: 0.0424
DEBUG - 2022-07-10 03:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:11:00 --> Total execution time: 0.0676
DEBUG - 2022-07-10 03:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:11:04 --> Total execution time: 0.0834
DEBUG - 2022-07-10 03:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:11:08 --> Total execution time: 0.0568
DEBUG - 2022-07-10 03:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:11:18 --> Total execution time: 0.0928
DEBUG - 2022-07-10 03:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:11:30 --> Total execution time: 0.0553
DEBUG - 2022-07-10 03:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:11:31 --> Total execution time: 0.0573
DEBUG - 2022-07-10 03:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:43:55 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:13:55 --> Total execution time: 0.1020
DEBUG - 2022-07-10 03:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:14:50 --> Total execution time: 0.1543
DEBUG - 2022-07-10 03:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:14:51 --> Total execution time: 0.0691
DEBUG - 2022-07-10 03:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:14:58 --> Total execution time: 0.0825
DEBUG - 2022-07-10 03:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:15:10 --> Total execution time: 0.0953
DEBUG - 2022-07-10 03:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:15:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 14:15:31 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-07-10 03:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:15:32 --> Total execution time: 0.0909
DEBUG - 2022-07-10 03:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:15:37 --> Total execution time: 0.0928
DEBUG - 2022-07-10 03:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:46:52 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:16:52 --> Total execution time: 0.0378
DEBUG - 2022-07-10 03:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:49:58 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:19:58 --> Total execution time: 0.0364
DEBUG - 2022-07-10 03:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:49:59 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:19:59 --> Total execution time: 0.0352
DEBUG - 2022-07-10 03:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:50:57 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:20:57 --> Total execution time: 0.0478
DEBUG - 2022-07-10 03:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:51:15 --> Total execution time: 0.0538
DEBUG - 2022-07-10 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:51:16 --> Total execution time: 0.0501
DEBUG - 2022-07-10 03:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:51:16 --> Total execution time: 0.0881
DEBUG - 2022-07-10 03:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:51:47 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:21:47 --> Total execution time: 0.0550
DEBUG - 2022-07-10 03:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:52:03 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:22:03 --> Total execution time: 0.0519
DEBUG - 2022-07-10 03:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:22:38 --> Total execution time: 0.0544
DEBUG - 2022-07-10 03:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:22:51 --> Total execution time: 0.0505
DEBUG - 2022-07-10 03:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:22:57 --> Total execution time: 0.0332
DEBUG - 2022-07-10 03:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:23:06 --> Total execution time: 0.0550
DEBUG - 2022-07-10 03:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:23:16 --> Total execution time: 0.0727
DEBUG - 2022-07-10 03:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:53:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:53:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 03:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:53:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:53:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 03:53:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:53:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 03:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:53:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:53:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 03:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:53:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:53:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 03:53:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:53:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 03:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:53:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:53:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 03:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:23:31 --> Total execution time: 0.0930
DEBUG - 2022-07-10 03:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:53:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:53:32 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 03:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:56:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:56:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-07-10 03:56:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-07-10 03:56:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 03:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:56:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:56:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-07-10 03:56:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 03:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:56:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:56:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 03:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:56:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:56:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 03:56:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 03:56:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 03:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:57:04 --> No URI present. Default controller set.
DEBUG - 2022-07-10 03:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:27:04 --> Total execution time: 0.0464
DEBUG - 2022-07-10 03:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:27:07 --> Total execution time: 0.0602
DEBUG - 2022-07-10 03:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 03:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:27:15 --> Total execution time: 0.0577
DEBUG - 2022-07-10 03:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:27:19 --> Total execution time: 0.0685
DEBUG - 2022-07-10 03:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:27:22 --> Total execution time: 0.0650
DEBUG - 2022-07-10 03:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:27:35 --> Total execution time: 0.0570
DEBUG - 2022-07-10 03:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 03:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 03:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:27:47 --> Total execution time: 0.0569
DEBUG - 2022-07-10 04:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:30:03 --> Total execution time: 0.1646
DEBUG - 2022-07-10 04:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:00:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:00:29 --> 404 Page Not Found: Become-an-affiliate/index
DEBUG - 2022-07-10 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:00:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-07-10 04:00:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:00:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:00:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:00:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:00:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:00:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:00:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:01:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:01:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:01:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:01:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:01:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:01:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:01:14 --> UTF-8 Support Enabled
ERROR - 2022-07-10 04:01:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:01:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:02:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:02:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:02:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:02:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:02:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:02:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:02:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:02:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-07-10 04:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:34:24 --> Total execution time: 0.1715
DEBUG - 2022-07-10 04:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:34:33 --> Total execution time: 0.0590
DEBUG - 2022-07-10 04:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:34:37 --> Total execution time: 0.0768
DEBUG - 2022-07-10 04:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:34:54 --> Total execution time: 0.0524
DEBUG - 2022-07-10 04:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:35:02 --> Total execution time: 0.0601
DEBUG - 2022-07-10 04:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:06:04 --> No URI present. Default controller set.
DEBUG - 2022-07-10 04:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:36:04 --> Total execution time: 0.0579
DEBUG - 2022-07-10 04:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:37:52 --> Total execution time: 0.0470
DEBUG - 2022-07-10 04:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:09:28 --> No URI present. Default controller set.
DEBUG - 2022-07-10 04:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:39:28 --> Total execution time: 0.0385
DEBUG - 2022-07-10 04:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:44:09 --> Total execution time: 0.2946
DEBUG - 2022-07-10 04:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:45:03 --> Total execution time: 0.0934
DEBUG - 2022-07-10 04:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:45:16 --> Total execution time: 0.0741
DEBUG - 2022-07-10 04:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:45:41 --> Total execution time: 0.0602
DEBUG - 2022-07-10 04:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:45:48 --> Total execution time: 0.0562
DEBUG - 2022-07-10 04:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:45:52 --> Total execution time: 0.0908
DEBUG - 2022-07-10 04:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:46:18 --> Total execution time: 0.0588
DEBUG - 2022-07-10 04:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:46:34 --> Total execution time: 0.0859
DEBUG - 2022-07-10 04:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:46:37 --> Total execution time: 0.0606
DEBUG - 2022-07-10 04:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:46:42 --> Total execution time: 0.0525
DEBUG - 2022-07-10 04:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:21:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:21:15 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-10 04:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:52:02 --> Total execution time: 0.0870
DEBUG - 2022-07-10 04:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:52:23 --> Total execution time: 0.0522
DEBUG - 2022-07-10 04:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:52:29 --> Total execution time: 0.0865
DEBUG - 2022-07-10 04:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:52:39 --> Total execution time: 0.0743
DEBUG - 2022-07-10 04:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:52:46 --> Total execution time: 0.0589
DEBUG - 2022-07-10 04:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:24:18 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-07-10 04:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:24:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 04:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:25:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:25:31 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-07-10 04:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:28:46 --> No URI present. Default controller set.
DEBUG - 2022-07-10 04:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:58:47 --> Total execution time: 0.1354
DEBUG - 2022-07-10 04:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:59:27 --> Total execution time: 0.1430
DEBUG - 2022-07-10 04:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:29:29 --> Total execution time: 0.0562
DEBUG - 2022-07-10 04:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:29:47 --> Total execution time: 0.0504
DEBUG - 2022-07-10 04:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:29:58 --> Total execution time: 0.0491
DEBUG - 2022-07-10 04:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:30:12 --> Total execution time: 0.0467
DEBUG - 2022-07-10 04:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:30:17 --> Total execution time: 0.0494
DEBUG - 2022-07-10 04:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:00:19 --> Total execution time: 0.0534
DEBUG - 2022-07-10 04:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:01:59 --> Total execution time: 0.0603
DEBUG - 2022-07-10 04:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:32:03 --> No URI present. Default controller set.
DEBUG - 2022-07-10 04:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:02:03 --> Total execution time: 0.0361
DEBUG - 2022-07-10 04:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:02:08 --> Total execution time: 0.0526
DEBUG - 2022-07-10 04:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:02:10 --> Total execution time: 0.0530
DEBUG - 2022-07-10 04:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:02:23 --> Total execution time: 0.0905
DEBUG - 2022-07-10 04:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:02:27 --> Total execution time: 0.1065
DEBUG - 2022-07-10 04:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:02:33 --> Total execution time: 0.0585
DEBUG - 2022-07-10 04:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:02:40 --> Total execution time: 0.0608
DEBUG - 2022-07-10 04:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:03:01 --> Total execution time: 0.1599
DEBUG - 2022-07-10 04:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:03:41 --> Total execution time: 0.0539
DEBUG - 2022-07-10 04:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:03:41 --> Total execution time: 0.0579
DEBUG - 2022-07-10 04:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:33:42 --> No URI present. Default controller set.
DEBUG - 2022-07-10 04:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:03:42 --> Total execution time: 0.0458
DEBUG - 2022-07-10 04:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:33:44 --> No URI present. Default controller set.
DEBUG - 2022-07-10 04:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:03:44 --> Total execution time: 0.0543
DEBUG - 2022-07-10 04:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:34:02 --> No URI present. Default controller set.
DEBUG - 2022-07-10 04:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:04:02 --> Total execution time: 0.0535
DEBUG - 2022-07-10 04:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:34:22 --> No URI present. Default controller set.
DEBUG - 2022-07-10 04:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:04:22 --> Total execution time: 0.0510
DEBUG - 2022-07-10 04:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:04:25 --> Total execution time: 0.0548
DEBUG - 2022-07-10 04:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:04:42 --> Total execution time: 0.0563
DEBUG - 2022-07-10 04:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:04:47 --> Total execution time: 0.0941
DEBUG - 2022-07-10 04:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:04:56 --> Total execution time: 0.0604
DEBUG - 2022-07-10 04:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:04:56 --> Total execution time: 0.0554
DEBUG - 2022-07-10 04:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:34:57 --> No URI present. Default controller set.
DEBUG - 2022-07-10 04:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:04:57 --> Total execution time: 0.0566
DEBUG - 2022-07-10 04:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:35:59 --> No URI present. Default controller set.
DEBUG - 2022-07-10 04:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:05:59 --> Total execution time: 0.0554
DEBUG - 2022-07-10 04:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:06:04 --> Total execution time: 0.0538
DEBUG - 2022-07-10 04:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:06:11 --> Total execution time: 0.0496
DEBUG - 2022-07-10 04:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:06:35 --> Total execution time: 0.0598
DEBUG - 2022-07-10 04:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:06:57 --> Total execution time: 0.0513
DEBUG - 2022-07-10 04:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:07:00 --> Total execution time: 0.0531
DEBUG - 2022-07-10 04:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:07:03 --> Total execution time: 0.0562
DEBUG - 2022-07-10 04:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:07:07 --> Total execution time: 0.0573
DEBUG - 2022-07-10 04:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:07:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 04:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:07:08 --> Total execution time: 0.0610
DEBUG - 2022-07-10 04:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:08:25 --> Total execution time: 0.0499
DEBUG - 2022-07-10 04:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:08:29 --> Total execution time: 0.0496
DEBUG - 2022-07-10 04:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:08:37 --> Total execution time: 0.0533
DEBUG - 2022-07-10 04:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:08:42 --> Total execution time: 0.0596
DEBUG - 2022-07-10 04:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:08:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 04:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:08:43 --> Total execution time: 0.0507
DEBUG - 2022-07-10 04:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:38:57 --> No URI present. Default controller set.
DEBUG - 2022-07-10 04:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:08:57 --> Total execution time: 0.0740
DEBUG - 2022-07-10 04:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:09:31 --> Total execution time: 0.0499
DEBUG - 2022-07-10 04:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:09:38 --> Total execution time: 0.0540
DEBUG - 2022-07-10 04:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:11:05 --> Total execution time: 0.0585
DEBUG - 2022-07-10 04:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:11:07 --> Total execution time: 0.0639
DEBUG - 2022-07-10 04:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:11:08 --> Total execution time: 0.1291
DEBUG - 2022-07-10 04:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:11:31 --> Total execution time: 0.0542
DEBUG - 2022-07-10 04:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:11:54 --> Total execution time: 0.0618
DEBUG - 2022-07-10 04:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:12:04 --> Total execution time: 0.0745
DEBUG - 2022-07-10 04:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:42:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:42:14 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-10 04:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:12:20 --> Total execution time: 0.0937
DEBUG - 2022-07-10 04:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:13:05 --> Total execution time: 0.0570
DEBUG - 2022-07-10 04:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:13:11 --> Total execution time: 0.0585
DEBUG - 2022-07-10 04:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:13:45 --> Total execution time: 0.0604
DEBUG - 2022-07-10 04:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:13:50 --> Total execution time: 0.1564
DEBUG - 2022-07-10 04:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:13:52 --> Total execution time: 0.0436
DEBUG - 2022-07-10 04:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:14:11 --> Total execution time: 0.0487
DEBUG - 2022-07-10 04:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:14:22 --> Total execution time: 0.0605
DEBUG - 2022-07-10 04:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:14:38 --> Total execution time: 0.0657
DEBUG - 2022-07-10 04:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:44:40 --> No URI present. Default controller set.
DEBUG - 2022-07-10 04:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:14:40 --> Total execution time: 0.0373
DEBUG - 2022-07-10 04:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:14:57 --> Total execution time: 0.0350
DEBUG - 2022-07-10 04:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:45:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:45:05 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:15:56 --> Total execution time: 0.0503
DEBUG - 2022-07-10 04:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:16:02 --> Total execution time: 0.1273
DEBUG - 2022-07-10 04:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:16:35 --> Total execution time: 0.1459
DEBUG - 2022-07-10 04:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:16:47 --> Total execution time: 0.0750
DEBUG - 2022-07-10 04:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:17:01 --> Total execution time: 0.0572
DEBUG - 2022-07-10 04:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:17:06 --> Total execution time: 0.0572
DEBUG - 2022-07-10 04:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:17:13 --> Total execution time: 0.0775
DEBUG - 2022-07-10 04:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:17:18 --> Total execution time: 0.1195
DEBUG - 2022-07-10 04:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 04:47:23 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-10 04:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:17:36 --> Total execution time: 0.1001
DEBUG - 2022-07-10 04:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:17:47 --> Total execution time: 0.0812
DEBUG - 2022-07-10 04:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:18:02 --> Total execution time: 0.0599
DEBUG - 2022-07-10 04:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:18:37 --> Total execution time: 0.0554
DEBUG - 2022-07-10 04:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:18:41 --> Total execution time: 0.0701
DEBUG - 2022-07-10 04:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:19:12 --> Total execution time: 0.0724
DEBUG - 2022-07-10 04:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:50:27 --> No URI present. Default controller set.
DEBUG - 2022-07-10 04:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:20:27 --> Total execution time: 0.0370
DEBUG - 2022-07-10 04:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:20:34 --> Total execution time: 0.0513
DEBUG - 2022-07-10 04:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:51:13 --> Total execution time: 0.0537
DEBUG - 2022-07-10 04:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:51:15 --> Total execution time: 0.0557
DEBUG - 2022-07-10 04:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 04:51:15 --> Total execution time: 0.1013
DEBUG - 2022-07-10 04:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:51:18 --> No URI present. Default controller set.
DEBUG - 2022-07-10 04:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:21:18 --> Total execution time: 0.0564
DEBUG - 2022-07-10 04:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 04:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 04:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:29:54 --> Total execution time: 0.1024
DEBUG - 2022-07-10 05:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:30:01 --> Total execution time: 0.0795
DEBUG - 2022-07-10 05:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:30:47 --> Total execution time: 0.0335
DEBUG - 2022-07-10 05:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:31:00 --> Total execution time: 0.0997
DEBUG - 2022-07-10 05:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:31:10 --> Total execution time: 0.0697
DEBUG - 2022-07-10 05:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:31:18 --> Total execution time: 0.0538
DEBUG - 2022-07-10 05:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:35:48 --> Total execution time: 0.2815
DEBUG - 2022-07-10 05:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:06:13 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:36:13 --> Total execution time: 0.0725
DEBUG - 2022-07-10 05:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:36:21 --> Total execution time: 0.0637
DEBUG - 2022-07-10 05:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:06:45 --> Total execution time: 0.0569
DEBUG - 2022-07-10 05:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:36:48 --> Total execution time: 0.0991
DEBUG - 2022-07-10 05:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:36:48 --> Total execution time: 0.0603
DEBUG - 2022-07-10 05:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:37:02 --> Total execution time: 0.0601
DEBUG - 2022-07-10 05:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:07:05 --> Total execution time: 0.0695
DEBUG - 2022-07-10 05:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:07:05 --> Total execution time: 0.1142
DEBUG - 2022-07-10 05:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:11:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 05:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:41:05 --> Total execution time: 1.9428
DEBUG - 2022-07-10 05:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 05:11:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 05:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:42:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 05:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:42:28 --> Total execution time: 0.0526
DEBUG - 2022-07-10 05:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:42:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 15:42:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 15:42:30 --> Total execution time: 0.1816
DEBUG - 2022-07-10 05:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:12:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 05:12:54 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-10 05:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:43:34 --> Total execution time: 0.0561
DEBUG - 2022-07-10 05:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:15:22 --> Total execution time: 0.1348
DEBUG - 2022-07-10 05:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:15:24 --> Total execution time: 0.0510
DEBUG - 2022-07-10 05:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:15:24 --> Total execution time: 0.1266
DEBUG - 2022-07-10 05:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:47:34 --> Total execution time: 0.0686
DEBUG - 2022-07-10 05:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:47:44 --> Total execution time: 0.0592
DEBUG - 2022-07-10 05:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:47:53 --> Total execution time: 0.0653
DEBUG - 2022-07-10 05:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:47:56 --> Total execution time: 0.0793
DEBUG - 2022-07-10 05:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:48:07 --> Total execution time: 0.0497
DEBUG - 2022-07-10 05:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:48:45 --> Total execution time: 0.0522
DEBUG - 2022-07-10 05:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:18:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 05:18:46 --> 404 Page Not Found: Personal-branding-course/index
DEBUG - 2022-07-10 05:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:53:33 --> Total execution time: 0.1056
DEBUG - 2022-07-10 05:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:25:21 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:55:21 --> Total execution time: 0.0469
DEBUG - 2022-07-10 05:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:25:28 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:55:28 --> Total execution time: 0.0437
DEBUG - 2022-07-10 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:25:52 --> Total execution time: 0.0539
DEBUG - 2022-07-10 05:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:25:54 --> Total execution time: 0.0765
DEBUG - 2022-07-10 05:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:25:54 --> Total execution time: 0.1361
DEBUG - 2022-07-10 05:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:27:25 --> Total execution time: 0.0698
DEBUG - 2022-07-10 05:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:27:27 --> Total execution time: 0.0564
DEBUG - 2022-07-10 05:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:27:27 --> Total execution time: 0.1273
DEBUG - 2022-07-10 05:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:27:53 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:57:53 --> Total execution time: 0.0562
DEBUG - 2022-07-10 05:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:28:12 --> Total execution time: 0.0527
DEBUG - 2022-07-10 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:28:13 --> Total execution time: 0.0581
DEBUG - 2022-07-10 05:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:28:14 --> Total execution time: 0.1319
DEBUG - 2022-07-10 05:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:29:11 --> Total execution time: 0.0603
DEBUG - 2022-07-10 05:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:29:12 --> Total execution time: 0.0554
DEBUG - 2022-07-10 05:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:29:12 --> Total execution time: 0.1179
DEBUG - 2022-07-10 05:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:29:19 --> Total execution time: 0.0527
DEBUG - 2022-07-10 05:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:29:21 --> Total execution time: 0.0528
DEBUG - 2022-07-10 05:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:29:21 --> Total execution time: 0.1380
DEBUG - 2022-07-10 05:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:24 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:59:24 --> Total execution time: 0.0739
DEBUG - 2022-07-10 05:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:29:28 --> Total execution time: 0.0505
DEBUG - 2022-07-10 05:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:29:29 --> Total execution time: 0.0561
DEBUG - 2022-07-10 05:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:29:30 --> Total execution time: 0.1154
DEBUG - 2022-07-10 05:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:29:31 --> Total execution time: 0.0504
DEBUG - 2022-07-10 05:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:29:33 --> Total execution time: 0.0532
DEBUG - 2022-07-10 05:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:33 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:29:33 --> Total execution time: 0.0806
DEBUG - 2022-07-10 05:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:59:33 --> Total execution time: 0.1059
DEBUG - 2022-07-10 05:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:59:52 --> Total execution time: 0.0486
DEBUG - 2022-07-10 05:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:00:02 --> Total execution time: 0.1245
DEBUG - 2022-07-10 05:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:00:06 --> Total execution time: 0.0574
DEBUG - 2022-07-10 05:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:00:12 --> Total execution time: 0.0853
DEBUG - 2022-07-10 05:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:32:07 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:02:07 --> Total execution time: 0.1299
DEBUG - 2022-07-10 05:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:02:13 --> Total execution time: 0.0700
DEBUG - 2022-07-10 05:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:32:22 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:02:23 --> Total execution time: 0.0656
DEBUG - 2022-07-10 05:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:32:30 --> Total execution time: 0.0703
DEBUG - 2022-07-10 05:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:32:31 --> Total execution time: 0.0599
DEBUG - 2022-07-10 05:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:32:32 --> Total execution time: 0.1003
DEBUG - 2022-07-10 05:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:33:50 --> Total execution time: 0.0448
DEBUG - 2022-07-10 05:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:33:51 --> Total execution time: 0.0603
DEBUG - 2022-07-10 05:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:33:51 --> Total execution time: 0.1037
DEBUG - 2022-07-10 05:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:34:02 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:04:02 --> Total execution time: 0.0630
DEBUG - 2022-07-10 05:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:04:11 --> Total execution time: 0.0498
DEBUG - 2022-07-10 05:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:34:37 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:04:37 --> Total execution time: 0.0608
DEBUG - 2022-07-10 05:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:04:59 --> Total execution time: 0.0595
DEBUG - 2022-07-10 05:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:05:07 --> Total execution time: 0.0558
DEBUG - 2022-07-10 05:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:36:25 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:06:25 --> Total execution time: 0.0382
DEBUG - 2022-07-10 05:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:06:30 --> Total execution time: 0.0516
DEBUG - 2022-07-10 05:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:06:41 --> Total execution time: 0.0571
DEBUG - 2022-07-10 05:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:08:47 --> Total execution time: 0.2355
DEBUG - 2022-07-10 05:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:38:54 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:08:54 --> Total execution time: 0.0542
DEBUG - 2022-07-10 05:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:08:54 --> Total execution time: 0.0640
DEBUG - 2022-07-10 05:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:09:03 --> Total execution time: 0.0500
DEBUG - 2022-07-10 05:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:09:05 --> Total execution time: 0.0544
DEBUG - 2022-07-10 05:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:09:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 05:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:09:06 --> Total execution time: 0.0528
DEBUG - 2022-07-10 05:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:09:28 --> Total execution time: 0.0590
DEBUG - 2022-07-10 05:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:09:30 --> Total execution time: 0.0507
DEBUG - 2022-07-10 05:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:09:57 --> Total execution time: 0.0534
DEBUG - 2022-07-10 05:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:10:09 --> Total execution time: 0.0571
DEBUG - 2022-07-10 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:10:15 --> Total execution time: 0.0520
DEBUG - 2022-07-10 05:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:10:15 --> Total execution time: 0.0634
DEBUG - 2022-07-10 05:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:10:19 --> Total execution time: 0.0507
DEBUG - 2022-07-10 05:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:41:13 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:11:13 --> Total execution time: 0.0374
DEBUG - 2022-07-10 05:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:41:19 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:11:19 --> Total execution time: 0.0386
DEBUG - 2022-07-10 05:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:11:42 --> Total execution time: 0.0585
DEBUG - 2022-07-10 05:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:11:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 05:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:11:43 --> Total execution time: 0.0531
DEBUG - 2022-07-10 05:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:43:47 --> Total execution time: 0.1041
DEBUG - 2022-07-10 05:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:43:49 --> Total execution time: 0.0642
DEBUG - 2022-07-10 05:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:43:49 --> Total execution time: 0.0774
DEBUG - 2022-07-10 05:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:13:53 --> Total execution time: 0.0524
DEBUG - 2022-07-10 05:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:14:00 --> Total execution time: 0.0572
DEBUG - 2022-07-10 05:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:18:30 --> Total execution time: 0.0877
DEBUG - 2022-07-10 05:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:18:58 --> Total execution time: 0.1329
DEBUG - 2022-07-10 05:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:19:05 --> Total execution time: 0.0536
DEBUG - 2022-07-10 05:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:49:09 --> Total execution time: 0.0513
DEBUG - 2022-07-10 05:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:49:10 --> Total execution time: 0.0553
DEBUG - 2022-07-10 05:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:49:10 --> Total execution time: 0.1011
DEBUG - 2022-07-10 05:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:19:31 --> Total execution time: 0.0659
DEBUG - 2022-07-10 05:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:19:37 --> Total execution time: 0.0622
DEBUG - 2022-07-10 05:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:51:35 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:21:35 --> Total execution time: 0.0405
DEBUG - 2022-07-10 05:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:52:16 --> Total execution time: 0.0349
DEBUG - 2022-07-10 05:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:52:17 --> Total execution time: 0.0691
DEBUG - 2022-07-10 05:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:52:17 --> Total execution time: 0.1181
DEBUG - 2022-07-10 05:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:52:46 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:22:46 --> Total execution time: 0.0606
DEBUG - 2022-07-10 05:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:53:12 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:23:13 --> Total execution time: 0.1286
DEBUG - 2022-07-10 05:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:53:16 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:23:16 --> Total execution time: 0.0358
DEBUG - 2022-07-10 05:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:23:19 --> Total execution time: 0.0382
DEBUG - 2022-07-10 05:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:23:19 --> Total execution time: 0.0417
DEBUG - 2022-07-10 05:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:23:29 --> Total execution time: 0.0667
DEBUG - 2022-07-10 05:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:23:36 --> Total execution time: 0.0952
DEBUG - 2022-07-10 05:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:23:43 --> Total execution time: 0.0557
DEBUG - 2022-07-10 05:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:23:45 --> Total execution time: 0.0538
DEBUG - 2022-07-10 05:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:23:48 --> Total execution time: 0.0608
DEBUG - 2022-07-10 05:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:23:53 --> Total execution time: 0.0625
DEBUG - 2022-07-10 05:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:23:53 --> Total execution time: 0.1096
DEBUG - 2022-07-10 05:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:23:57 --> Total execution time: 0.0639
DEBUG - 2022-07-10 05:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:24:04 --> Total execution time: 0.0632
DEBUG - 2022-07-10 05:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:24:13 --> Total execution time: 0.0574
DEBUG - 2022-07-10 05:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:54:18 --> Total execution time: 0.0513
DEBUG - 2022-07-10 05:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:24:27 --> Total execution time: 0.0495
DEBUG - 2022-07-10 05:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:54:28 --> Total execution time: 0.0499
DEBUG - 2022-07-10 05:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:54:37 --> Total execution time: 0.0513
DEBUG - 2022-07-10 05:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:54:41 --> Total execution time: 0.0615
DEBUG - 2022-07-10 05:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:54:44 --> Total execution time: 0.0575
DEBUG - 2022-07-10 05:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:24:48 --> Total execution time: 0.0554
DEBUG - 2022-07-10 05:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:49 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:24:49 --> Total execution time: 0.1307
DEBUG - 2022-07-10 05:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:24:53 --> Total execution time: 0.0742
DEBUG - 2022-07-10 05:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:24:54 --> Total execution time: 0.0622
DEBUG - 2022-07-10 05:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:25:41 --> Total execution time: 0.0492
DEBUG - 2022-07-10 05:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:25:41 --> Total execution time: 0.0538
DEBUG - 2022-07-10 05:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:25:54 --> Total execution time: 0.0992
DEBUG - 2022-07-10 05:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:26:55 --> Total execution time: 0.0494
DEBUG - 2022-07-10 05:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:27:01 --> Total execution time: 0.0634
DEBUG - 2022-07-10 05:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:57:05 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:27:05 --> Total execution time: 0.0365
DEBUG - 2022-07-10 05:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:27:10 --> Total execution time: 0.0591
DEBUG - 2022-07-10 05:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:27:15 --> Total execution time: 0.0515
DEBUG - 2022-07-10 05:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:27:20 --> Total execution time: 0.0598
DEBUG - 2022-07-10 05:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:27:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 05:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:27:21 --> Total execution time: 0.0528
DEBUG - 2022-07-10 05:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:29:16 --> Total execution time: 0.0497
DEBUG - 2022-07-10 05:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:59:17 --> No URI present. Default controller set.
DEBUG - 2022-07-10 05:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:29:17 --> Total execution time: 0.0321
DEBUG - 2022-07-10 05:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:59:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 05:59:17 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-10 05:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:29:19 --> Total execution time: 0.0432
DEBUG - 2022-07-10 05:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:29:34 --> Total execution time: 0.0578
DEBUG - 2022-07-10 05:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:29:35 --> Total execution time: 0.0618
DEBUG - 2022-07-10 05:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:29:36 --> Total execution time: 0.0275
DEBUG - 2022-07-10 05:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:29:38 --> Total execution time: 0.0502
DEBUG - 2022-07-10 05:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:29:44 --> Total execution time: 0.0808
DEBUG - 2022-07-10 05:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 05:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:29:53 --> Total execution time: 0.0498
DEBUG - 2022-07-10 05:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 05:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 05:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:29:56 --> Total execution time: 0.0551
DEBUG - 2022-07-10 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:30:02 --> Total execution time: 0.0766
DEBUG - 2022-07-10 06:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:30:05 --> Total execution time: 0.0803
DEBUG - 2022-07-10 06:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:30:08 --> Total execution time: 0.1330
DEBUG - 2022-07-10 06:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:30:13 --> Total execution time: 0.0574
DEBUG - 2022-07-10 06:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:30:17 --> Total execution time: 0.0519
DEBUG - 2022-07-10 06:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:30:19 --> Total execution time: 0.0614
DEBUG - 2022-07-10 06:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:30:23 --> Total execution time: 0.1111
DEBUG - 2022-07-10 06:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:30:46 --> Total execution time: 0.0470
DEBUG - 2022-07-10 06:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:30:48 --> Total execution time: 0.0340
DEBUG - 2022-07-10 06:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:30:53 --> Total execution time: 0.0544
DEBUG - 2022-07-10 06:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:01:20 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:31:20 --> Total execution time: 0.0391
DEBUG - 2022-07-10 06:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:31:30 --> Total execution time: 0.0565
DEBUG - 2022-07-10 06:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:01:31 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:31:31 --> Total execution time: 0.0527
DEBUG - 2022-07-10 06:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:02:35 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:32:35 --> Total execution time: 0.0522
DEBUG - 2022-07-10 06:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 06:02:40 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 06:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:02:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 06:02:42 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 06:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 06:02:44 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 06:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:32:47 --> Total execution time: 0.1297
DEBUG - 2022-07-10 06:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:33:27 --> Total execution time: 0.0535
DEBUG - 2022-07-10 06:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:03:42 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:33:42 --> Total execution time: 0.0366
DEBUG - 2022-07-10 06:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:33:47 --> Total execution time: 0.0520
DEBUG - 2022-07-10 06:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:33:55 --> Total execution time: 0.0557
DEBUG - 2022-07-10 06:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:33:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 06:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:33:56 --> Total execution time: 0.0609
DEBUG - 2022-07-10 06:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:04:10 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:34:10 --> Total execution time: 0.0357
DEBUG - 2022-07-10 06:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:34:21 --> Total execution time: 0.0502
DEBUG - 2022-07-10 06:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:04:29 --> Total execution time: 0.1119
DEBUG - 2022-07-10 06:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:04:31 --> Total execution time: 0.0525
DEBUG - 2022-07-10 06:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:04:31 --> Total execution time: 0.0767
DEBUG - 2022-07-10 06:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:34:36 --> Total execution time: 0.1249
DEBUG - 2022-07-10 06:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:04:56 --> Total execution time: 0.0571
DEBUG - 2022-07-10 06:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:05:03 --> Total execution time: 0.0612
DEBUG - 2022-07-10 06:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:35:34 --> Total execution time: 0.0778
DEBUG - 2022-07-10 06:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:36:27 --> Total execution time: 0.0686
DEBUG - 2022-07-10 06:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:36:54 --> Total execution time: 0.0605
DEBUG - 2022-07-10 06:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:36:57 --> Total execution time: 0.0554
DEBUG - 2022-07-10 06:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:07:07 --> Total execution time: 0.0556
DEBUG - 2022-07-10 06:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:37:16 --> Total execution time: 0.0580
DEBUG - 2022-07-10 06:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:37:34 --> Total execution time: 0.0773
DEBUG - 2022-07-10 06:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:37:43 --> Total execution time: 0.0560
DEBUG - 2022-07-10 06:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:40:10 --> Total execution time: 0.2443
DEBUG - 2022-07-10 06:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:41:33 --> Total execution time: 0.0606
DEBUG - 2022-07-10 06:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:42:43 --> Total execution time: 0.1303
DEBUG - 2022-07-10 06:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:43:23 --> Total execution time: 0.0538
DEBUG - 2022-07-10 06:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:43:57 --> Total execution time: 0.0580
DEBUG - 2022-07-10 06:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:44:39 --> Total execution time: 0.0591
DEBUG - 2022-07-10 06:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:14:50 --> Total execution time: 0.0505
DEBUG - 2022-07-10 06:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:45:11 --> Total execution time: 0.1381
DEBUG - 2022-07-10 06:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:45:27 --> Total execution time: 0.0619
DEBUG - 2022-07-10 06:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:16:19 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:46:19 --> Total execution time: 0.0398
DEBUG - 2022-07-10 06:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:47:25 --> Total execution time: 0.1370
DEBUG - 2022-07-10 06:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:47:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 06:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:47:47 --> Total execution time: 0.0985
DEBUG - 2022-07-10 06:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:48:05 --> Total execution time: 0.1296
DEBUG - 2022-07-10 06:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:48:09 --> Total execution time: 0.0763
DEBUG - 2022-07-10 06:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:48:37 --> Total execution time: 0.0843
DEBUG - 2022-07-10 06:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:48:43 --> Total execution time: 0.0632
DEBUG - 2022-07-10 06:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:20:51 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:50:51 --> Total execution time: 0.1427
DEBUG - 2022-07-10 06:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:50:56 --> Total execution time: 0.0567
DEBUG - 2022-07-10 06:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:51:00 --> Total execution time: 0.0610
DEBUG - 2022-07-10 06:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:51:22 --> Total execution time: 0.0551
DEBUG - 2022-07-10 06:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:51:25 --> Total execution time: 0.0786
DEBUG - 2022-07-10 06:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:51:31 --> Total execution time: 0.0524
DEBUG - 2022-07-10 06:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:26:22 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:56:22 --> Total execution time: 0.1261
DEBUG - 2022-07-10 06:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:26:43 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 16:56:43 --> Total execution time: 0.1551
DEBUG - 2022-07-10 06:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:56:43 --> Total execution time: 0.1301
DEBUG - 2022-07-10 06:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:56:47 --> Total execution time: 0.0712
DEBUG - 2022-07-10 06:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:56:52 --> Total execution time: 0.0604
DEBUG - 2022-07-10 06:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:56:59 --> Total execution time: 0.0608
DEBUG - 2022-07-10 06:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:27:05 --> Total execution time: 0.0784
DEBUG - 2022-07-10 06:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:57:06 --> Total execution time: 0.0524
DEBUG - 2022-07-10 06:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:27:19 --> Total execution time: 0.0879
DEBUG - 2022-07-10 06:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:27:19 --> Total execution time: 0.1538
DEBUG - 2022-07-10 06:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:27:22 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:57:22 --> Total execution time: 0.0627
DEBUG - 2022-07-10 06:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:58:15 --> Total execution time: 0.0790
DEBUG - 2022-07-10 06:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:58:26 --> Total execution time: 0.0575
DEBUG - 2022-07-10 06:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:58:31 --> Total execution time: 0.2416
DEBUG - 2022-07-10 06:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:58:38 --> Total execution time: 0.0503
DEBUG - 2022-07-10 06:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:28:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 06:28:42 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-10 06:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:28:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:58:45 --> Total execution time: 0.0426
DEBUG - 2022-07-10 06:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:28:56 --> Total execution time: 0.0589
DEBUG - 2022-07-10 06:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:29:35 --> Total execution time: 0.0695
DEBUG - 2022-07-10 06:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:29:35 --> Total execution time: 0.1373
DEBUG - 2022-07-10 06:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:29:39 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:59:39 --> Total execution time: 0.0421
DEBUG - 2022-07-10 06:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:59:45 --> Total execution time: 0.0349
DEBUG - 2022-07-10 06:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:59:59 --> Total execution time: 0.0611
DEBUG - 2022-07-10 06:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:00:06 --> Total execution time: 0.0829
DEBUG - 2022-07-10 06:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:00:20 --> Total execution time: 0.0873
DEBUG - 2022-07-10 06:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:00:24 --> Total execution time: 0.0570
DEBUG - 2022-07-10 06:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:00:25 --> Total execution time: 0.0402
DEBUG - 2022-07-10 06:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:00:27 --> Total execution time: 0.0928
DEBUG - 2022-07-10 06:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:00:32 --> Total execution time: 0.0782
DEBUG - 2022-07-10 06:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:30:44 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:00:44 --> Total execution time: 0.0580
DEBUG - 2022-07-10 06:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:00:49 --> Total execution time: 0.0573
DEBUG - 2022-07-10 06:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:30:58 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:00:58 --> Total execution time: 0.0588
DEBUG - 2022-07-10 06:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:31:04 --> Total execution time: 0.0570
DEBUG - 2022-07-10 06:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:31:07 --> Total execution time: 0.0547
DEBUG - 2022-07-10 06:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:31:07 --> Total execution time: 0.1030
DEBUG - 2022-07-10 06:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:31:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 06:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:01:12 --> Total execution time: 2.9245
DEBUG - 2022-07-10 06:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:31:21 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:01:21 --> Total execution time: 0.0409
DEBUG - 2022-07-10 06:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:31:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 06:31:28 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 06:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:32:50 --> Total execution time: 0.0533
DEBUG - 2022-07-10 06:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:32:51 --> Total execution time: 0.0672
DEBUG - 2022-07-10 06:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:32:51 --> Total execution time: 0.1031
DEBUG - 2022-07-10 06:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:33:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 06:33:52 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-10 06:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:34:00 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:04:00 --> Total execution time: 0.0416
DEBUG - 2022-07-10 06:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:34:00 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:04:00 --> Total execution time: 0.0405
DEBUG - 2022-07-10 06:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:04:43 --> Total execution time: 0.0433
DEBUG - 2022-07-10 06:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:34:49 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:04:49 --> Total execution time: 0.0585
DEBUG - 2022-07-10 06:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:05:02 --> Total execution time: 0.0753
DEBUG - 2022-07-10 06:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:35:04 --> Total execution time: 0.0500
DEBUG - 2022-07-10 06:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:35:05 --> Total execution time: 0.0573
DEBUG - 2022-07-10 06:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:35:06 --> Total execution time: 0.1126
DEBUG - 2022-07-10 06:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:35:25 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:05:25 --> Total execution time: 0.0513
DEBUG - 2022-07-10 06:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:05:28 --> Total execution time: 0.0491
DEBUG - 2022-07-10 06:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:05:58 --> Total execution time: 0.0587
DEBUG - 2022-07-10 06:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:06:12 --> Total execution time: 0.0569
DEBUG - 2022-07-10 06:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:06:18 --> Total execution time: 0.0703
DEBUG - 2022-07-10 06:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:06:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 06:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:06:28 --> Total execution time: 0.0764
DEBUG - 2022-07-10 06:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:06:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 17:06:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 17:06:29 --> Total execution time: 0.2414
DEBUG - 2022-07-10 06:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:06:30 --> Total execution time: 0.0764
DEBUG - 2022-07-10 06:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:06:51 --> Total execution time: 0.0745
DEBUG - 2022-07-10 06:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:07:07 --> Total execution time: 0.0599
DEBUG - 2022-07-10 06:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:07:17 --> Total execution time: 0.0754
DEBUG - 2022-07-10 06:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:07:24 --> Total execution time: 0.0715
DEBUG - 2022-07-10 06:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:08:15 --> Total execution time: 0.0551
DEBUG - 2022-07-10 06:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:08:29 --> Total execution time: 0.1802
DEBUG - 2022-07-10 06:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:08:29 --> Total execution time: 0.0539
DEBUG - 2022-07-10 06:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:38:32 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:08:32 --> Total execution time: 0.1296
DEBUG - 2022-07-10 06:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:42:40 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:12:40 --> Total execution time: 0.1095
DEBUG - 2022-07-10 06:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:42:50 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:12:50 --> Total execution time: 0.0415
DEBUG - 2022-07-10 06:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:12:55 --> Total execution time: 0.0353
DEBUG - 2022-07-10 06:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:13:02 --> Total execution time: 0.0628
DEBUG - 2022-07-10 06:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:13:10 --> Total execution time: 0.0635
DEBUG - 2022-07-10 06:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:13:12 --> Total execution time: 0.0580
DEBUG - 2022-07-10 06:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:43:12 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:13:12 --> Total execution time: 0.0448
DEBUG - 2022-07-10 06:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:13:13 --> Total execution time: 0.0652
DEBUG - 2022-07-10 06:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:13:21 --> Total execution time: 0.0579
DEBUG - 2022-07-10 06:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:13:24 --> Total execution time: 0.0496
DEBUG - 2022-07-10 06:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:13:33 --> Total execution time: 0.0540
DEBUG - 2022-07-10 06:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:13:42 --> Total execution time: 0.0794
DEBUG - 2022-07-10 06:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:14:19 --> Total execution time: 0.0846
DEBUG - 2022-07-10 06:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:45:06 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:15:06 --> Total execution time: 0.1554
DEBUG - 2022-07-10 06:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:15:11 --> Total execution time: 0.1333
DEBUG - 2022-07-10 06:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:15:21 --> Total execution time: 0.0633
DEBUG - 2022-07-10 06:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:15:28 --> Total execution time: 0.0806
DEBUG - 2022-07-10 06:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:45:32 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:15:32 --> Total execution time: 0.0539
DEBUG - 2022-07-10 06:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:46:17 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:16:18 --> Total execution time: 0.0670
DEBUG - 2022-07-10 06:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:46:29 --> Total execution time: 0.0736
DEBUG - 2022-07-10 06:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:46:31 --> Total execution time: 0.0583
DEBUG - 2022-07-10 06:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:46:31 --> Total execution time: 0.1041
DEBUG - 2022-07-10 06:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:46:50 --> Total execution time: 0.0520
DEBUG - 2022-07-10 06:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:46:52 --> Total execution time: 0.0553
DEBUG - 2022-07-10 06:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:46:52 --> Total execution time: 0.1036
DEBUG - 2022-07-10 06:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:47:15 --> Total execution time: 0.0620
DEBUG - 2022-07-10 06:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:47:16 --> Total execution time: 0.0595
DEBUG - 2022-07-10 06:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:47:16 --> Total execution time: 0.1146
DEBUG - 2022-07-10 06:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:47:35 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:17:35 --> Total execution time: 0.0527
DEBUG - 2022-07-10 06:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:17:40 --> Total execution time: 0.0505
DEBUG - 2022-07-10 06:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:17:54 --> Total execution time: 0.0498
DEBUG - 2022-07-10 06:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:18:11 --> Total execution time: 0.0820
DEBUG - 2022-07-10 06:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:18:20 --> Total execution time: 0.0914
DEBUG - 2022-07-10 06:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:18:31 --> Total execution time: 0.0952
DEBUG - 2022-07-10 06:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:49:27 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:19:27 --> Total execution time: 0.0359
DEBUG - 2022-07-10 06:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:51:37 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:21:38 --> Total execution time: 0.0577
DEBUG - 2022-07-10 06:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:21:49 --> Total execution time: 0.0505
DEBUG - 2022-07-10 06:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:52:07 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:22:07 --> Total execution time: 0.0533
DEBUG - 2022-07-10 06:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:56:05 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:26:05 --> Total execution time: 0.1116
DEBUG - 2022-07-10 06:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:57:42 --> No URI present. Default controller set.
DEBUG - 2022-07-10 06:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:27:42 --> Total execution time: 0.3836
DEBUG - 2022-07-10 06:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:27:50 --> Total execution time: 0.0391
DEBUG - 2022-07-10 06:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 06:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:28:05 --> Total execution time: 0.0709
DEBUG - 2022-07-10 06:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:28:18 --> Total execution time: 0.0770
DEBUG - 2022-07-10 06:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 06:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:28:21 --> Total execution time: 0.2932
DEBUG - 2022-07-10 06:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 06:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 06:59:39 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-10 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:30:03 --> Total execution time: 0.2383
DEBUG - 2022-07-10 07:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:01:18 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:31:18 --> Total execution time: 0.0746
DEBUG - 2022-07-10 07:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:32:34 --> Total execution time: 0.1497
DEBUG - 2022-07-10 07:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:32:52 --> Total execution time: 0.1810
DEBUG - 2022-07-10 07:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:32:54 --> Total execution time: 0.0755
DEBUG - 2022-07-10 07:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:32:59 --> Total execution time: 0.0771
DEBUG - 2022-07-10 07:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:33:05 --> Total execution time: 0.0791
DEBUG - 2022-07-10 07:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:03:15 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:33:15 --> Total execution time: 0.0393
DEBUG - 2022-07-10 07:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:33:21 --> Total execution time: 0.0616
DEBUG - 2022-07-10 07:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:33:25 --> Total execution time: 0.0621
DEBUG - 2022-07-10 07:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:06:46 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:36:46 --> Total execution time: 0.1503
DEBUG - 2022-07-10 07:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:37:41 --> Total execution time: 0.1898
DEBUG - 2022-07-10 07:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:39:27 --> Total execution time: 0.0524
DEBUG - 2022-07-10 07:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:10:55 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:40:55 --> Total execution time: 0.1414
DEBUG - 2022-07-10 07:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:11:30 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:41:30 --> Total execution time: 0.0545
DEBUG - 2022-07-10 07:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:11:41 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:11:41 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:11:41 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:41:41 --> Total execution time: 0.0365
DEBUG - 2022-07-10 07:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:41:41 --> Total execution time: 0.0368
DEBUG - 2022-07-10 07:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:41:42 --> Total execution time: 0.0752
DEBUG - 2022-07-10 07:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:11:42 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:41:42 --> Total execution time: 0.0376
DEBUG - 2022-07-10 07:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:44:35 --> Total execution time: 0.0542
DEBUG - 2022-07-10 07:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:45:17 --> Total execution time: 0.0573
DEBUG - 2022-07-10 07:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:45:27 --> Total execution time: 0.0675
DEBUG - 2022-07-10 07:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:45:38 --> Total execution time: 0.0932
DEBUG - 2022-07-10 07:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:46:44 --> Total execution time: 0.0591
DEBUG - 2022-07-10 07:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:16:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 07:16:52 --> 404 Page Not Found: Accesson0php/index
DEBUG - 2022-07-10 07:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:46:57 --> Total execution time: 0.0736
DEBUG - 2022-07-10 07:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:48:00 --> Total execution time: 0.0627
DEBUG - 2022-07-10 07:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:48:24 --> Total execution time: 0.0512
DEBUG - 2022-07-10 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:49:46 --> Total execution time: 0.0586
DEBUG - 2022-07-10 07:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:20:02 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:50:02 --> Total execution time: 0.0469
DEBUG - 2022-07-10 07:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:50:20 --> Total execution time: 0.0578
DEBUG - 2022-07-10 07:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:20:44 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:50:44 --> Total execution time: 0.0419
DEBUG - 2022-07-10 07:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:20:44 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:50:44 --> Total execution time: 0.0330
DEBUG - 2022-07-10 07:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:50:55 --> Total execution time: 0.0411
DEBUG - 2022-07-10 07:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:51:08 --> Total execution time: 0.0858
DEBUG - 2022-07-10 07:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:11 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:51:11 --> Total execution time: 0.1285
DEBUG - 2022-07-10 07:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:51:18 --> Total execution time: 0.0652
DEBUG - 2022-07-10 07:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:51:22 --> Total execution time: 0.0659
DEBUG - 2022-07-10 07:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:51:29 --> Total execution time: 0.0658
DEBUG - 2022-07-10 07:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:51:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 07:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:51:29 --> Total execution time: 0.0511
DEBUG - 2022-07-10 07:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:51:33 --> Total execution time: 1.9100
DEBUG - 2022-07-10 07:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:51:36 --> Total execution time: 0.0502
DEBUG - 2022-07-10 07:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 07:21:37 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 07:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:51:38 --> Total execution time: 0.0498
DEBUG - 2022-07-10 07:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:51:43 --> Total execution time: 0.0588
DEBUG - 2022-07-10 07:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:51:43 --> Total execution time: 0.0552
DEBUG - 2022-07-10 07:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:51:48 --> Total execution time: 0.0711
DEBUG - 2022-07-10 07:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:22:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:52:08 --> Total execution time: 0.1330
DEBUG - 2022-07-10 07:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:52:20 --> Total execution time: 0.0569
DEBUG - 2022-07-10 07:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:52:23 --> Total execution time: 0.0757
DEBUG - 2022-07-10 07:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:52:38 --> Total execution time: 0.0355
DEBUG - 2022-07-10 07:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:52:43 --> Total execution time: 0.0628
DEBUG - 2022-07-10 07:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:52:44 --> Total execution time: 0.0529
DEBUG - 2022-07-10 07:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:52:44 --> Total execution time: 0.0492
DEBUG - 2022-07-10 07:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:53:00 --> Total execution time: 0.0440
DEBUG - 2022-07-10 07:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:53:10 --> Total execution time: 0.0547
DEBUG - 2022-07-10 07:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:25:35 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:55:35 --> Total execution time: 0.2025
DEBUG - 2022-07-10 07:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:55:35 --> Total execution time: 0.2566
DEBUG - 2022-07-10 07:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:55:35 --> Total execution time: 0.0572
DEBUG - 2022-07-10 07:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:55:35 --> Total execution time: 0.0699
DEBUG - 2022-07-10 07:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:57:19 --> Total execution time: 0.0612
DEBUG - 2022-07-10 07:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:28:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:58:45 --> Total execution time: 0.0461
DEBUG - 2022-07-10 07:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:58:48 --> Total execution time: 0.0608
DEBUG - 2022-07-10 07:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:58:56 --> Total execution time: 0.0567
DEBUG - 2022-07-10 07:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:59:04 --> Total execution time: 0.0618
DEBUG - 2022-07-10 07:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:59:11 --> Total execution time: 0.0739
DEBUG - 2022-07-10 07:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:59:13 --> Total execution time: 0.0572
DEBUG - 2022-07-10 07:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:59:20 --> Total execution time: 0.1753
DEBUG - 2022-07-10 07:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:59:25 --> Total execution time: 0.0516
DEBUG - 2022-07-10 07:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:29:30 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:59:30 --> Total execution time: 0.0546
DEBUG - 2022-07-10 07:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:29:59 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:59:59 --> Total execution time: 0.0371
DEBUG - 2022-07-10 07:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:59:59 --> Total execution time: 0.0614
DEBUG - 2022-07-10 07:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:08 --> Total execution time: 0.0389
DEBUG - 2022-07-10 07:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:12 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:12 --> Total execution time: 0.0433
DEBUG - 2022-07-10 07:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:17 --> Total execution time: 0.0553
DEBUG - 2022-07-10 07:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:22 --> Total execution time: 0.0515
DEBUG - 2022-07-10 07:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:23 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:23 --> Total execution time: 0.0546
DEBUG - 2022-07-10 07:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:32 --> Total execution time: 0.0507
DEBUG - 2022-07-10 07:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:33 --> Total execution time: 0.0864
DEBUG - 2022-07-10 07:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:38 --> Total execution time: 0.0585
DEBUG - 2022-07-10 07:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:42 --> Total execution time: 0.0491
DEBUG - 2022-07-10 07:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:45 --> Total execution time: 0.0363
DEBUG - 2022-07-10 07:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:49 --> Total execution time: 0.0511
DEBUG - 2022-07-10 07:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:51 --> Total execution time: 0.0592
DEBUG - 2022-07-10 07:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:55 --> Total execution time: 0.0533
DEBUG - 2022-07-10 07:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:01:04 --> Total execution time: 0.0745
DEBUG - 2022-07-10 07:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:01:10 --> Total execution time: 0.0691
DEBUG - 2022-07-10 07:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:01:21 --> Total execution time: 0.0553
DEBUG - 2022-07-10 07:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:01:25 --> Total execution time: 0.0435
DEBUG - 2022-07-10 07:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:02:05 --> Total execution time: 0.0689
DEBUG - 2022-07-10 07:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:02:09 --> Total execution time: 0.0564
DEBUG - 2022-07-10 07:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:02:23 --> Total execution time: 0.0620
DEBUG - 2022-07-10 07:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:02:23 --> Total execution time: 0.0694
DEBUG - 2022-07-10 07:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:02:24 --> Total execution time: 0.0508
DEBUG - 2022-07-10 07:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:02:29 --> Total execution time: 0.0509
DEBUG - 2022-07-10 07:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:02:32 --> Total execution time: 0.0537
DEBUG - 2022-07-10 07:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:02:34 --> Total execution time: 0.0559
DEBUG - 2022-07-10 07:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:32:38 --> Total execution time: 0.0513
DEBUG - 2022-07-10 07:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:32:40 --> Total execution time: 0.0673
DEBUG - 2022-07-10 07:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:32:40 --> Total execution time: 0.1204
DEBUG - 2022-07-10 07:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:02:52 --> Total execution time: 0.1222
DEBUG - 2022-07-10 07:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:02:55 --> Total execution time: 0.0554
DEBUG - 2022-07-10 07:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:02:55 --> Total execution time: 0.0549
DEBUG - 2022-07-10 07:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:02:55 --> Total execution time: 0.0624
DEBUG - 2022-07-10 07:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:02:56 --> Total execution time: 0.0619
DEBUG - 2022-07-10 07:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:02:56 --> Total execution time: 0.0504
DEBUG - 2022-07-10 07:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:06 --> Total execution time: 0.0894
DEBUG - 2022-07-10 07:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:13 --> Total execution time: 0.0582
DEBUG - 2022-07-10 07:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:14 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:14 --> Total execution time: 0.0609
DEBUG - 2022-07-10 07:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:14 --> Total execution time: 0.0882
DEBUG - 2022-07-10 07:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:21 --> Total execution time: 0.0557
DEBUG - 2022-07-10 07:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:22 --> Total execution time: 0.0850
DEBUG - 2022-07-10 07:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:25 --> Total execution time: 0.0548
DEBUG - 2022-07-10 07:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:27 --> Total execution time: 0.0788
DEBUG - 2022-07-10 07:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:38 --> Total execution time: 0.0624
DEBUG - 2022-07-10 07:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:40 --> Total execution time: 0.0521
DEBUG - 2022-07-10 07:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:42 --> Total execution time: 0.0531
DEBUG - 2022-07-10 07:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:43 --> Total execution time: 0.0527
DEBUG - 2022-07-10 07:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:44 --> Total execution time: 0.0509
DEBUG - 2022-07-10 07:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:45 --> Total execution time: 0.0553
DEBUG - 2022-07-10 07:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:45 --> Total execution time: 0.0580
DEBUG - 2022-07-10 07:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:46 --> Total execution time: 0.0500
DEBUG - 2022-07-10 07:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:48 --> Total execution time: 0.0592
DEBUG - 2022-07-10 07:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:49 --> Total execution time: 0.0619
DEBUG - 2022-07-10 07:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:51 --> Total execution time: 0.0500
DEBUG - 2022-07-10 07:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:52 --> Total execution time: 0.0499
DEBUG - 2022-07-10 07:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:55 --> Total execution time: 0.0511
DEBUG - 2022-07-10 07:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:55 --> Total execution time: 0.0569
DEBUG - 2022-07-10 07:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:57 --> Total execution time: 0.0505
DEBUG - 2022-07-10 07:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:59 --> Total execution time: 0.0581
DEBUG - 2022-07-10 07:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:00 --> Total execution time: 0.0530
DEBUG - 2022-07-10 07:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:02 --> Total execution time: 0.0532
DEBUG - 2022-07-10 07:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:05 --> Total execution time: 0.0639
DEBUG - 2022-07-10 07:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:08 --> Total execution time: 0.0499
DEBUG - 2022-07-10 07:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:15 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:15 --> Total execution time: 0.0454
DEBUG - 2022-07-10 07:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:16 --> Total execution time: 0.0525
DEBUG - 2022-07-10 07:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:18 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:18 --> Total execution time: 0.0487
DEBUG - 2022-07-10 07:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:23 --> Total execution time: 0.0503
DEBUG - 2022-07-10 07:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:28 --> Total execution time: 0.0518
DEBUG - 2022-07-10 07:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:29 --> Total execution time: 0.0556
DEBUG - 2022-07-10 07:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:30 --> Total execution time: 0.0592
DEBUG - 2022-07-10 07:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:31 --> Total execution time: 0.0531
DEBUG - 2022-07-10 07:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:34 --> Total execution time: 0.0520
DEBUG - 2022-07-10 07:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:34:34 --> Total execution time: 0.0533
DEBUG - 2022-07-10 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:34:35 --> Total execution time: 0.0559
DEBUG - 2022-07-10 07:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:34:35 --> Total execution time: 0.1234
DEBUG - 2022-07-10 07:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:52 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:52 --> Total execution time: 0.0582
DEBUG - 2022-07-10 07:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:54 --> Total execution time: 0.0528
DEBUG - 2022-07-10 07:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:57 --> Total execution time: 0.0556
DEBUG - 2022-07-10 07:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:04:57 --> Total execution time: 0.0728
DEBUG - 2022-07-10 07:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:05:02 --> Total execution time: 0.0746
DEBUG - 2022-07-10 07:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:05:08 --> Total execution time: 0.0625
DEBUG - 2022-07-10 07:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:05:17 --> Total execution time: 0.0743
DEBUG - 2022-07-10 07:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:35:30 --> Total execution time: 0.0658
DEBUG - 2022-07-10 07:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:35:31 --> Total execution time: 0.0800
DEBUG - 2022-07-10 07:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:35:31 --> Total execution time: 0.0876
DEBUG - 2022-07-10 07:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:06:34 --> Total execution time: 0.1351
DEBUG - 2022-07-10 07:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:06:39 --> Total execution time: 0.0827
DEBUG - 2022-07-10 07:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:06:42 --> Total execution time: 0.0961
DEBUG - 2022-07-10 07:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:06:42 --> Total execution time: 0.0966
DEBUG - 2022-07-10 07:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:36:49 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:06:49 --> Total execution time: 0.0555
DEBUG - 2022-07-10 07:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:06:58 --> Total execution time: 0.0678
DEBUG - 2022-07-10 07:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:37:14 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:07:14 --> Total execution time: 0.0366
DEBUG - 2022-07-10 07:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:07:14 --> Total execution time: 0.0502
DEBUG - 2022-07-10 07:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:37:15 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:07:15 --> Total execution time: 0.0566
DEBUG - 2022-07-10 07:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:37:21 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:07:21 --> Total execution time: 0.0588
DEBUG - 2022-07-10 07:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:37:23 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:07:23 --> Total execution time: 0.0739
DEBUG - 2022-07-10 07:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:07:24 --> Total execution time: 0.0553
DEBUG - 2022-07-10 07:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:07:26 --> Total execution time: 0.0280
DEBUG - 2022-07-10 07:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:07:36 --> Total execution time: 0.0452
DEBUG - 2022-07-10 07:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:07:40 --> Total execution time: 0.1289
DEBUG - 2022-07-10 07:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:07:45 --> Total execution time: 0.0648
DEBUG - 2022-07-10 07:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:07:46 --> Total execution time: 0.0635
DEBUG - 2022-07-10 07:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:37:59 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:07:59 --> Total execution time: 0.0548
DEBUG - 2022-07-10 07:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:01 --> Total execution time: 0.0630
DEBUG - 2022-07-10 07:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:10 --> Total execution time: 0.0663
DEBUG - 2022-07-10 07:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 07:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:11 --> Total execution time: 0.0661
DEBUG - 2022-07-10 07:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:11 --> Total execution time: 0.0558
DEBUG - 2022-07-10 07:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:13 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:13 --> Total execution time: 0.0527
DEBUG - 2022-07-10 07:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:14 --> Total execution time: 0.0782
DEBUG - 2022-07-10 07:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:20 --> Total execution time: 0.0663
DEBUG - 2022-07-10 07:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:22 --> Total execution time: 0.0580
DEBUG - 2022-07-10 07:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:24 --> Total execution time: 0.0765
DEBUG - 2022-07-10 07:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:25 --> Total execution time: 0.0776
DEBUG - 2022-07-10 07:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:29 --> Total execution time: 0.0609
DEBUG - 2022-07-10 07:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:29 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:29 --> Total execution time: 0.0537
DEBUG - 2022-07-10 07:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:30 --> Total execution time: 0.0532
DEBUG - 2022-07-10 07:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:30 --> Total execution time: 0.0877
DEBUG - 2022-07-10 07:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:44 --> Total execution time: 0.0560
DEBUG - 2022-07-10 07:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:08:48 --> Total execution time: 0.2856
DEBUG - 2022-07-10 07:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:09:02 --> Total execution time: 0.0865
DEBUG - 2022-07-10 07:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:09:05 --> Total execution time: 0.0725
DEBUG - 2022-07-10 07:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:09:25 --> Total execution time: 0.0651
DEBUG - 2022-07-10 07:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:10:48 --> Total execution time: 0.0825
DEBUG - 2022-07-10 07:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:11:22 --> Total execution time: 0.0554
DEBUG - 2022-07-10 07:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:13:06 --> Total execution time: 0.1412
DEBUG - 2022-07-10 07:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:13:16 --> Total execution time: 0.0999
DEBUG - 2022-07-10 07:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:13:41 --> Total execution time: 0.0564
DEBUG - 2022-07-10 07:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:13:42 --> Total execution time: 0.0822
DEBUG - 2022-07-10 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:44:12 --> Total execution time: 0.0532
DEBUG - 2022-07-10 07:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:44:20 --> Total execution time: 0.0537
DEBUG - 2022-07-10 07:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:44:46 --> Total execution time: 0.0834
DEBUG - 2022-07-10 07:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:44:57 --> Total execution time: 0.0446
DEBUG - 2022-07-10 07:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:45:04 --> Total execution time: 0.0729
DEBUG - 2022-07-10 07:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:45:12 --> Total execution time: 0.0470
DEBUG - 2022-07-10 07:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:45:17 --> Total execution time: 0.0839
DEBUG - 2022-07-10 07:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:45:19 --> Total execution time: 0.0601
DEBUG - 2022-07-10 07:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:45:20 --> Total execution time: 0.0641
DEBUG - 2022-07-10 07:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:15:21 --> Total execution time: 0.0892
DEBUG - 2022-07-10 07:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:15:21 --> Total execution time: 0.0584
DEBUG - 2022-07-10 07:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:15:21 --> Total execution time: 0.0541
DEBUG - 2022-07-10 07:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:45:21 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:15:21 --> Total execution time: 0.0662
DEBUG - 2022-07-10 07:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:15:52 --> Total execution time: 1.8849
DEBUG - 2022-07-10 07:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:45:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 07:45:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 07:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:46:43 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:16:43 --> Total execution time: 0.0606
DEBUG - 2022-07-10 07:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:47:33 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:17:33 --> Total execution time: 0.0568
DEBUG - 2022-07-10 07:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:22:01 --> Total execution time: 0.1201
DEBUG - 2022-07-10 07:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 07:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:23:27 --> Total execution time: 0.0493
DEBUG - 2022-07-10 07:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 07:55:22 --> No URI present. Default controller set.
DEBUG - 2022-07-10 07:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 07:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:25:22 --> Total execution time: 0.0400
DEBUG - 2022-07-10 08:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:30:03 --> Total execution time: 0.1429
DEBUG - 2022-07-10 08:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:31:06 --> Total execution time: 0.0542
DEBUG - 2022-07-10 08:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:31:10 --> Total execution time: 0.0575
DEBUG - 2022-07-10 08:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:31:15 --> Total execution time: 0.0853
DEBUG - 2022-07-10 08:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:02:10 --> Total execution time: 0.0471
DEBUG - 2022-07-10 08:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:02:12 --> Total execution time: 0.0471
DEBUG - 2022-07-10 08:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:02:12 --> Total execution time: 0.0815
DEBUG - 2022-07-10 08:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:37:06 --> Total execution time: 0.0856
DEBUG - 2022-07-10 08:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:07:54 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:37:54 --> Total execution time: 0.1368
DEBUG - 2022-07-10 08:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:08:32 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:38:32 --> Total execution time: 0.0357
DEBUG - 2022-07-10 08:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:08:52 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:38:52 --> Total execution time: 0.0416
DEBUG - 2022-07-10 08:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:08:54 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:38:54 --> Total execution time: 0.0564
DEBUG - 2022-07-10 08:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:09:13 --> Total execution time: 0.1625
DEBUG - 2022-07-10 08:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:09:15 --> Total execution time: 0.0670
DEBUG - 2022-07-10 08:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:09:15 --> Total execution time: 0.1207
DEBUG - 2022-07-10 08:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:09:22 --> Total execution time: 0.0513
DEBUG - 2022-07-10 08:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:10:16 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:40:16 --> Total execution time: 0.1314
DEBUG - 2022-07-10 08:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:10:30 --> Total execution time: 0.0616
DEBUG - 2022-07-10 08:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:40:31 --> Total execution time: 0.0748
DEBUG - 2022-07-10 08:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:10:35 --> Total execution time: 0.0562
DEBUG - 2022-07-10 08:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:10:37 --> Total execution time: 0.0540
DEBUG - 2022-07-10 08:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:10:37 --> Total execution time: 0.0840
DEBUG - 2022-07-10 08:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:40:41 --> Total execution time: 0.2448
DEBUG - 2022-07-10 08:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:40:44 --> Total execution time: 0.0723
DEBUG - 2022-07-10 08:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:11:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 08:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:41:37 --> Total execution time: 1.8612
DEBUG - 2022-07-10 08:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:11:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 08:11:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 08:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:42:45 --> Total execution time: 0.0726
DEBUG - 2022-07-10 08:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:42:57 --> Total execution time: 0.0610
DEBUG - 2022-07-10 08:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:43:40 --> Total execution time: 0.0638
DEBUG - 2022-07-10 08:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:44:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 08:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:44:12 --> Total execution time: 0.0614
DEBUG - 2022-07-10 08:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:15:32 --> Total execution time: 0.0620
DEBUG - 2022-07-10 08:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:15:48 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:45:48 --> Total execution time: 0.0597
DEBUG - 2022-07-10 08:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:15:48 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:45:48 --> Total execution time: 0.0373
DEBUG - 2022-07-10 08:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:45:53 --> Total execution time: 0.0553
DEBUG - 2022-07-10 08:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:15:56 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:45:56 --> Total execution time: 0.0641
DEBUG - 2022-07-10 08:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:08 --> Total execution time: 0.2014
DEBUG - 2022-07-10 08:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:08 --> Total execution time: 0.0514
DEBUG - 2022-07-10 08:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:09 --> Total execution time: 0.0608
DEBUG - 2022-07-10 08:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:12 --> Total execution time: 0.0578
DEBUG - 2022-07-10 08:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:14 --> Total execution time: 0.0626
DEBUG - 2022-07-10 08:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:18 --> Total execution time: 0.0587
DEBUG - 2022-07-10 08:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:19 --> Total execution time: 0.0746
DEBUG - 2022-07-10 08:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 08:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:20 --> Total execution time: 0.0649
DEBUG - 2022-07-10 08:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:21 --> Total execution time: 0.0646
DEBUG - 2022-07-10 08:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:28 --> Total execution time: 0.0510
DEBUG - 2022-07-10 08:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:39 --> Total execution time: 0.1491
DEBUG - 2022-07-10 08:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:40 --> Total execution time: 0.0598
DEBUG - 2022-07-10 08:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:40 --> Total execution time: 0.0544
DEBUG - 2022-07-10 08:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:46:48 --> Total execution time: 0.0800
DEBUG - 2022-07-10 08:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:47:28 --> Total execution time: 0.0749
DEBUG - 2022-07-10 08:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:17:34 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:47:34 --> Total execution time: 0.1268
DEBUG - 2022-07-10 08:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:47:41 --> Total execution time: 0.0751
DEBUG - 2022-07-10 08:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:18:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 08:18:28 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-10 08:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:49:07 --> Total execution time: 0.0706
DEBUG - 2022-07-10 08:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:49:12 --> Total execution time: 0.0530
DEBUG - 2022-07-10 08:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:19:12 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:49:12 --> Total execution time: 0.0522
DEBUG - 2022-07-10 08:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:49:20 --> Total execution time: 0.0555
DEBUG - 2022-07-10 08:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:49:26 --> Total execution time: 0.0564
DEBUG - 2022-07-10 08:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:49:29 --> Total execution time: 0.0601
DEBUG - 2022-07-10 08:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:49:39 --> Total execution time: 0.0530
DEBUG - 2022-07-10 08:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:20:06 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:50:06 --> Total execution time: 0.0400
DEBUG - 2022-07-10 08:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:20:06 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:50:06 --> Total execution time: 0.0560
DEBUG - 2022-07-10 08:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:50:11 --> Total execution time: 0.0479
DEBUG - 2022-07-10 08:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:50:16 --> Total execution time: 0.0501
DEBUG - 2022-07-10 08:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:50:57 --> Total execution time: 0.0435
DEBUG - 2022-07-10 08:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:21:02 --> Total execution time: 0.0650
DEBUG - 2022-07-10 08:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:21:04 --> Total execution time: 0.0503
DEBUG - 2022-07-10 08:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:21:04 --> Total execution time: 0.0927
DEBUG - 2022-07-10 08:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:51:06 --> Total execution time: 0.0455
DEBUG - 2022-07-10 08:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 08:21:18 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 08:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:22:10 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:52:10 --> Total execution time: 0.0437
DEBUG - 2022-07-10 08:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:53:20 --> Total execution time: 0.1274
DEBUG - 2022-07-10 08:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:35 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:53:35 --> Total execution time: 0.0625
DEBUG - 2022-07-10 08:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:23:39 --> Total execution time: 0.0529
DEBUG - 2022-07-10 08:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:23:40 --> Total execution time: 0.0538
DEBUG - 2022-07-10 08:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:23:40 --> Total execution time: 0.1163
DEBUG - 2022-07-10 08:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:53:40 --> Total execution time: 0.1354
DEBUG - 2022-07-10 08:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 08:23:42 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-10 08:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:53:45 --> Total execution time: 0.0546
DEBUG - 2022-07-10 08:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:46 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:53:46 --> Total execution time: 0.1284
DEBUG - 2022-07-10 08:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:53:50 --> Total execution time: 0.0611
DEBUG - 2022-07-10 08:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:53:54 --> Total execution time: 0.0858
DEBUG - 2022-07-10 08:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:23:55 --> Total execution time: 0.0538
DEBUG - 2022-07-10 08:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:53:56 --> Total execution time: 0.0562
DEBUG - 2022-07-10 08:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:54:04 --> Total execution time: 0.0692
DEBUG - 2022-07-10 08:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:54:35 --> Total execution time: 0.1595
DEBUG - 2022-07-10 08:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:24:35 --> Total execution time: 0.0498
DEBUG - 2022-07-10 08:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:24:37 --> Total execution time: 0.0769
DEBUG - 2022-07-10 08:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:24:37 --> Total execution time: 0.1309
DEBUG - 2022-07-10 08:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:24:44 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:54:44 --> Total execution time: 0.0619
DEBUG - 2022-07-10 08:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:54:46 --> Total execution time: 0.0518
DEBUG - 2022-07-10 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:54:49 --> Total execution time: 0.0514
DEBUG - 2022-07-10 08:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:54:54 --> Total execution time: 0.0813
DEBUG - 2022-07-10 08:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:54:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 08:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:54:55 --> Total execution time: 0.0557
DEBUG - 2022-07-10 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:55:16 --> Total execution time: 2.4690
DEBUG - 2022-07-10 08:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:25:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 08:25:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 08:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:26:17 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:56:17 --> Total execution time: 0.1401
DEBUG - 2022-07-10 08:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:26:36 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:56:36 --> Total execution time: 0.0536
DEBUG - 2022-07-10 08:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:56:42 --> Total execution time: 0.0596
DEBUG - 2022-07-10 08:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:26:46 --> Total execution time: 0.0664
DEBUG - 2022-07-10 08:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:26:48 --> Total execution time: 0.0550
DEBUG - 2022-07-10 08:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:26:48 --> Total execution time: 0.1176
DEBUG - 2022-07-10 08:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:27:01 --> Total execution time: 0.0797
DEBUG - 2022-07-10 08:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:27:06 --> Total execution time: 0.0522
DEBUG - 2022-07-10 18:57:06 --> Total execution time: 1.4813
DEBUG - 2022-07-10 08:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:27:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 08:27:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 08:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:57:10 --> Total execution time: 0.0662
DEBUG - 2022-07-10 08:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:27:10 --> Total execution time: 0.0506
DEBUG - 2022-07-10 08:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:27:14 --> Total execution time: 0.0682
DEBUG - 2022-07-10 08:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:27:16 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:57:16 --> Total execution time: 0.0507
DEBUG - 2022-07-10 08:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:27:17 --> Total execution time: 0.0498
DEBUG - 2022-07-10 08:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:27:28 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:57:28 --> Total execution time: 0.0521
DEBUG - 2022-07-10 08:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:57:33 --> Total execution time: 0.0614
DEBUG - 2022-07-10 08:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:28:29 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:58:29 --> Total execution time: 0.0533
DEBUG - 2022-07-10 08:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:58:45 --> Total execution time: 0.0550
DEBUG - 2022-07-10 08:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:28:53 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:58:53 --> Total execution time: 0.0518
DEBUG - 2022-07-10 08:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:59:15 --> Total execution time: 0.0521
DEBUG - 2022-07-10 08:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:29:24 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:59:24 --> Total execution time: 0.0611
DEBUG - 2022-07-10 08:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:29:32 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:59:32 --> Total execution time: 0.0533
DEBUG - 2022-07-10 08:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:29:44 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:59:44 --> Total execution time: 0.0358
DEBUG - 2022-07-10 08:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:29:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:59:45 --> Total execution time: 0.0389
DEBUG - 2022-07-10 08:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:59:56 --> Total execution time: 0.0540
DEBUG - 2022-07-10 08:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:00:06 --> Total execution time: 0.0562
DEBUG - 2022-07-10 08:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:30:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 08:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:00:55 --> Total execution time: 1.8057
DEBUG - 2022-07-10 08:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:31:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 08:31:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 08:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:01:12 --> Total execution time: 0.0571
DEBUG - 2022-07-10 08:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:01:31 --> Total execution time: 0.1399
DEBUG - 2022-07-10 08:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:01:38 --> Total execution time: 0.0658
DEBUG - 2022-07-10 08:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:01:45 --> Total execution time: 0.0600
DEBUG - 2022-07-10 08:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:01:48 --> Total execution time: 0.0782
DEBUG - 2022-07-10 08:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:01:56 --> Total execution time: 1.5342
DEBUG - 2022-07-10 08:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:01:58 --> Total execution time: 0.0770
DEBUG - 2022-07-10 08:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:02:00 --> Total execution time: 0.0745
DEBUG - 2022-07-10 08:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:02:03 --> Total execution time: 0.0636
DEBUG - 2022-07-10 08:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:02:05 --> Total execution time: 0.0803
DEBUG - 2022-07-10 08:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:02:06 --> Total execution time: 0.0680
DEBUG - 2022-07-10 08:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:02:17 --> Total execution time: 0.0688
DEBUG - 2022-07-10 08:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:02:19 --> Total execution time: 0.0591
DEBUG - 2022-07-10 08:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:02:29 --> Total execution time: 0.0561
DEBUG - 2022-07-10 08:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:02:39 --> Total execution time: 0.0576
DEBUG - 2022-07-10 08:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:02:45 --> Total execution time: 0.0641
DEBUG - 2022-07-10 08:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:02:51 --> Total execution time: 0.1132
DEBUG - 2022-07-10 08:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:02:59 --> Total execution time: 0.0694
DEBUG - 2022-07-10 08:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:03:04 --> Total execution time: 0.0583
DEBUG - 2022-07-10 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:03:07 --> Total execution time: 0.0561
DEBUG - 2022-07-10 08:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:03:10 --> Total execution time: 0.0747
DEBUG - 2022-07-10 08:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:33:22 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:03:22 --> Total execution time: 0.0580
DEBUG - 2022-07-10 08:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:03:31 --> Total execution time: 1.4965
DEBUG - 2022-07-10 08:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:03:35 --> Total execution time: 0.0662
DEBUG - 2022-07-10 08:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:33:37 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:03:37 --> Total execution time: 0.0639
DEBUG - 2022-07-10 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:33:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:03:45 --> Total execution time: 0.0349
DEBUG - 2022-07-10 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:03:46 --> Total execution time: 0.0592
DEBUG - 2022-07-10 08:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:33:52 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:03:52 --> Total execution time: 0.0652
DEBUG - 2022-07-10 08:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:03:54 --> Total execution time: 0.0561
DEBUG - 2022-07-10 08:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:35:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:05:45 --> Total execution time: 0.1326
DEBUG - 2022-07-10 08:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:35:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:05:45 --> Total execution time: 0.0460
DEBUG - 2022-07-10 08:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:05:49 --> Total execution time: 0.0635
DEBUG - 2022-07-10 08:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:05:53 --> Total execution time: 0.0555
DEBUG - 2022-07-10 08:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:05:55 --> Total execution time: 0.0572
DEBUG - 2022-07-10 08:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:06:13 --> Total execution time: 0.1529
DEBUG - 2022-07-10 08:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:06:22 --> Total execution time: 0.0543
DEBUG - 2022-07-10 08:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:06:25 --> Total execution time: 0.0557
DEBUG - 2022-07-10 08:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:36:29 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:06:29 --> Total execution time: 0.0607
DEBUG - 2022-07-10 08:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:06:34 --> Total execution time: 0.0535
DEBUG - 2022-07-10 08:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:36:36 --> Total execution time: 0.0486
DEBUG - 2022-07-10 08:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:06:48 --> Total execution time: 0.0693
DEBUG - 2022-07-10 08:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:08:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 08:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:08:08 --> Total execution time: 0.0556
DEBUG - 2022-07-10 08:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:08:14 --> Total execution time: 0.0546
DEBUG - 2022-07-10 08:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:08:20 --> Total execution time: 0.0613
DEBUG - 2022-07-10 08:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:10:00 --> Total execution time: 0.1302
DEBUG - 2022-07-10 08:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:10:03 --> Total execution time: 0.0516
DEBUG - 2022-07-10 08:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:10:05 --> Total execution time: 0.0626
DEBUG - 2022-07-10 08:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:10:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 08:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:10:06 --> Total execution time: 0.0656
DEBUG - 2022-07-10 08:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:40:08 --> Total execution time: 0.0912
DEBUG - 2022-07-10 08:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:40:15 --> Total execution time: 0.1397
DEBUG - 2022-07-10 08:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:11:18 --> Total execution time: 0.0496
DEBUG - 2022-07-10 08:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:11:23 --> Total execution time: 0.0623
DEBUG - 2022-07-10 08:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:11:38 --> Total execution time: 0.1023
DEBUG - 2022-07-10 08:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:12:03 --> Total execution time: 0.0702
DEBUG - 2022-07-10 08:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:12:06 --> Total execution time: 0.0917
DEBUG - 2022-07-10 08:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:12:18 --> Total execution time: 0.0854
DEBUG - 2022-07-10 08:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:12:20 --> Total execution time: 0.0749
DEBUG - 2022-07-10 08:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:13:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 08:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:13:03 --> Total execution time: 0.0721
DEBUG - 2022-07-10 08:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:13:08 --> Total execution time: 0.0625
DEBUG - 2022-07-10 08:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:13:11 --> Total execution time: 0.0671
DEBUG - 2022-07-10 08:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:13:23 --> Total execution time: 0.0607
DEBUG - 2022-07-10 08:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:13:34 --> Total execution time: 0.0498
DEBUG - 2022-07-10 08:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:13:37 --> Total execution time: 0.0840
DEBUG - 2022-07-10 08:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:14:11 --> Total execution time: 0.0630
DEBUG - 2022-07-10 08:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:14:18 --> Total execution time: 0.0640
DEBUG - 2022-07-10 08:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:14:29 --> Total execution time: 0.0515
DEBUG - 2022-07-10 08:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:14:31 --> Total execution time: 0.0531
DEBUG - 2022-07-10 08:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:15:31 --> Total execution time: 0.0778
DEBUG - 2022-07-10 08:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:15:36 --> Total execution time: 0.0781
DEBUG - 2022-07-10 08:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:15:40 --> Total execution time: 0.0750
DEBUG - 2022-07-10 08:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:16:37 --> Total execution time: 0.0758
DEBUG - 2022-07-10 08:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:17:31 --> Total execution time: 0.1520
DEBUG - 2022-07-10 08:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:18:59 --> Total execution time: 0.1578
DEBUG - 2022-07-10 08:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 08:49:58 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-10 08:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:20:13 --> Total execution time: 0.1322
DEBUG - 2022-07-10 08:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:20:18 --> Total execution time: 0.0565
DEBUG - 2022-07-10 08:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:50:18 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:20:19 --> Total execution time: 0.1289
DEBUG - 2022-07-10 08:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:20:27 --> Total execution time: 0.0568
DEBUG - 2022-07-10 08:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:20:30 --> Total execution time: 0.0617
DEBUG - 2022-07-10 08:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:20:42 --> Total execution time: 0.0544
DEBUG - 2022-07-10 08:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:50:42 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:20:42 --> Total execution time: 0.0575
DEBUG - 2022-07-10 08:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:20:53 --> Total execution time: 0.0595
DEBUG - 2022-07-10 08:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:20:57 --> Total execution time: 0.0624
DEBUG - 2022-07-10 08:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:21:04 --> Total execution time: 0.0885
DEBUG - 2022-07-10 08:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:23:07 --> Total execution time: 0.2433
DEBUG - 2022-07-10 08:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:23:22 --> Total execution time: 0.0773
DEBUG - 2022-07-10 08:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:23:54 --> Total execution time: 0.0660
DEBUG - 2022-07-10 08:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:25:40 --> Total execution time: 0.1583
DEBUG - 2022-07-10 08:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 08:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:25:41 --> Total execution time: 0.0552
DEBUG - 2022-07-10 08:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:27:03 --> Total execution time: 0.0705
DEBUG - 2022-07-10 08:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:57:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 08:57:59 --> 404 Page Not Found: Contact/index
DEBUG - 2022-07-10 08:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 08:59:44 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-07-10 08:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:59:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 08:59:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 08:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:59:58 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:29:58 --> Total execution time: 0.0442
DEBUG - 2022-07-10 08:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 08:59:59 --> No URI present. Default controller set.
DEBUG - 2022-07-10 08:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 08:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:29:59 --> Total execution time: 0.0779
DEBUG - 2022-07-10 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:30:02 --> Total execution time: 0.0607
DEBUG - 2022-07-10 09:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:30:09 --> Total execution time: 0.0450
DEBUG - 2022-07-10 09:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:30:32 --> Total execution time: 0.0477
DEBUG - 2022-07-10 09:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:30:32 --> Total execution time: 0.0485
DEBUG - 2022-07-10 09:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:30:54 --> Total execution time: 0.0584
DEBUG - 2022-07-10 09:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:31:11 --> Total execution time: 0.0516
DEBUG - 2022-07-10 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:01:27 --> No URI present. Default controller set.
DEBUG - 2022-07-10 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:31:27 --> Total execution time: 0.0352
DEBUG - 2022-07-10 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:31:27 --> Total execution time: 0.0587
DEBUG - 2022-07-10 09:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:31:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 09:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:31:28 --> Total execution time: 0.0508
DEBUG - 2022-07-10 09:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:31:35 --> Total execution time: 0.0517
DEBUG - 2022-07-10 09:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:33:25 --> Total execution time: 0.0670
DEBUG - 2022-07-10 09:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:33:30 --> Total execution time: 0.0714
DEBUG - 2022-07-10 09:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:33:36 --> Total execution time: 0.0573
DEBUG - 2022-07-10 09:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:33:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 09:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:33:37 --> Total execution time: 0.0702
DEBUG - 2022-07-10 09:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:33:51 --> Total execution time: 0.0634
DEBUG - 2022-07-10 09:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:33:52 --> Total execution time: 0.0533
DEBUG - 2022-07-10 09:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:34:21 --> Total execution time: 0.0950
DEBUG - 2022-07-10 09:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:34:30 --> Total execution time: 0.1921
DEBUG - 2022-07-10 09:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:34:37 --> Total execution time: 0.0534
DEBUG - 2022-07-10 09:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:34:46 --> Total execution time: 0.0626
DEBUG - 2022-07-10 09:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:34:56 --> Total execution time: 0.0553
DEBUG - 2022-07-10 09:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:35:03 --> Total execution time: 0.0493
DEBUG - 2022-07-10 09:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:35:15 --> Total execution time: 0.1313
DEBUG - 2022-07-10 09:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:36:55 --> Total execution time: 0.1305
DEBUG - 2022-07-10 09:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:37:13 --> Total execution time: 0.0550
DEBUG - 2022-07-10 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:37:25 --> Total execution time: 0.1133
DEBUG - 2022-07-10 09:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:37:27 --> Total execution time: 0.0577
DEBUG - 2022-07-10 09:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:37:32 --> Total execution time: 0.0445
DEBUG - 2022-07-10 09:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:37:44 --> Total execution time: 0.0559
DEBUG - 2022-07-10 09:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:37:52 --> Total execution time: 0.0544
DEBUG - 2022-07-10 09:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:37:55 --> Total execution time: 0.0638
DEBUG - 2022-07-10 09:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:38:02 --> Total execution time: 0.0890
DEBUG - 2022-07-10 09:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:43:55 --> Total execution time: 0.0666
DEBUG - 2022-07-10 09:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:43:56 --> Total execution time: 0.0548
DEBUG - 2022-07-10 09:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:44:34 --> Total execution time: 0.0517
DEBUG - 2022-07-10 09:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:44:47 --> Total execution time: 0.0695
DEBUG - 2022-07-10 09:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:45:01 --> Total execution time: 0.0920
DEBUG - 2022-07-10 09:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:45:21 --> Total execution time: 0.0611
DEBUG - 2022-07-10 09:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:45:29 --> Total execution time: 0.0741
DEBUG - 2022-07-10 09:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:46:03 --> Total execution time: 0.0564
DEBUG - 2022-07-10 09:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:46:05 --> Total execution time: 0.0492
DEBUG - 2022-07-10 09:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:46:17 --> Total execution time: 0.0558
DEBUG - 2022-07-10 09:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:46:40 --> Total execution time: 0.0584
DEBUG - 2022-07-10 09:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:48:15 --> Total execution time: 0.0572
DEBUG - 2022-07-10 09:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:48:23 --> Total execution time: 0.0547
DEBUG - 2022-07-10 09:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:48:49 --> Total execution time: 0.0572
DEBUG - 2022-07-10 09:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:50:34 --> Total execution time: 0.0620
DEBUG - 2022-07-10 09:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:50:46 --> Total execution time: 0.0595
DEBUG - 2022-07-10 09:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:50:47 --> Total execution time: 0.0836
DEBUG - 2022-07-10 09:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:51:44 --> Total execution time: 0.0623
DEBUG - 2022-07-10 09:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:54:10 --> Total execution time: 0.1993
DEBUG - 2022-07-10 09:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:32:20 --> No URI present. Default controller set.
DEBUG - 2022-07-10 09:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:02:20 --> Total execution time: 0.0902
DEBUG - 2022-07-10 09:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:04:09 --> Total execution time: 0.0351
DEBUG - 2022-07-10 09:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:37:17 --> Total execution time: 0.2107
DEBUG - 2022-07-10 09:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:09:25 --> Total execution time: 0.0572
DEBUG - 2022-07-10 09:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:09:34 --> Total execution time: 0.0838
DEBUG - 2022-07-10 09:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:09:47 --> Total execution time: 0.0583
DEBUG - 2022-07-10 09:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:09:52 --> Total execution time: 0.0831
DEBUG - 2022-07-10 09:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:10:03 --> Total execution time: 0.0731
DEBUG - 2022-07-10 09:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:10:06 --> Total execution time: 0.0776
DEBUG - 2022-07-10 09:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:10:07 --> Total execution time: 0.0555
DEBUG - 2022-07-10 09:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:10:08 --> Total execution time: 0.0545
DEBUG - 2022-07-10 09:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:10:37 --> Total execution time: 0.0606
DEBUG - 2022-07-10 09:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:42:17 --> No URI present. Default controller set.
DEBUG - 2022-07-10 09:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:17 --> Total execution time: 0.1348
DEBUG - 2022-07-10 09:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:19 --> Total execution time: 0.0913
DEBUG - 2022-07-10 09:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:34 --> Total execution time: 0.0544
DEBUG - 2022-07-10 09:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:14:11 --> Total execution time: 0.0563
DEBUG - 2022-07-10 09:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:14:25 --> Total execution time: 0.0709
DEBUG - 2022-07-10 09:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:44:40 --> Total execution time: 0.0522
DEBUG - 2022-07-10 09:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:14:49 --> Total execution time: 0.1273
DEBUG - 2022-07-10 09:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:15:11 --> Total execution time: 0.1329
DEBUG - 2022-07-10 09:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:15:32 --> Total execution time: 0.0630
DEBUG - 2022-07-10 09:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:15:48 --> Total execution time: 0.0615
DEBUG - 2022-07-10 09:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:16:51 --> Total execution time: 0.0514
DEBUG - 2022-07-10 09:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:19:47 --> Total execution time: 0.0588
DEBUG - 2022-07-10 09:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:19:55 --> Total execution time: 0.0550
DEBUG - 2022-07-10 09:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:00 --> Total execution time: 0.0590
DEBUG - 2022-07-10 09:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:08 --> Total execution time: 0.0560
DEBUG - 2022-07-10 09:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:40 --> Total execution time: 0.0576
DEBUG - 2022-07-10 09:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:44 --> Total execution time: 0.0556
DEBUG - 2022-07-10 09:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:47 --> Total execution time: 0.0589
DEBUG - 2022-07-10 09:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:51:20 --> No URI present. Default controller set.
DEBUG - 2022-07-10 09:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:21:20 --> Total execution time: 0.0574
DEBUG - 2022-07-10 09:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:21:21 --> Total execution time: 0.0549
DEBUG - 2022-07-10 09:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:21:26 --> Total execution time: 0.0522
DEBUG - 2022-07-10 09:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:52:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 09:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:22:08 --> Total execution time: 0.0563
DEBUG - 2022-07-10 09:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:22:16 --> Total execution time: 0.0645
DEBUG - 2022-07-10 09:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:22:21 --> Total execution time: 0.0498
DEBUG - 2022-07-10 09:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:22:31 --> Total execution time: 0.0540
DEBUG - 2022-07-10 09:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:22:52 --> Total execution time: 0.1455
DEBUG - 2022-07-10 09:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:23:04 --> Total execution time: 0.0562
DEBUG - 2022-07-10 09:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:23:16 --> Total execution time: 0.0501
DEBUG - 2022-07-10 09:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:23:25 --> Total execution time: 0.0547
DEBUG - 2022-07-10 09:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:23:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 09:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:23:26 --> Total execution time: 0.0557
DEBUG - 2022-07-10 09:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:23:30 --> Total execution time: 0.0520
DEBUG - 2022-07-10 09:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:23:43 --> Total execution time: 0.0559
DEBUG - 2022-07-10 09:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:23:50 --> Total execution time: 0.1011
DEBUG - 2022-07-10 09:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:53:51 --> No URI present. Default controller set.
DEBUG - 2022-07-10 09:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:23:51 --> Total execution time: 0.0397
DEBUG - 2022-07-10 09:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:23:54 --> Total execution time: 0.0782
DEBUG - 2022-07-10 09:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:24:01 --> Total execution time: 0.0553
DEBUG - 2022-07-10 09:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:24:02 --> Total execution time: 0.1358
DEBUG - 2022-07-10 09:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:24:03 --> Total execution time: 0.0450
DEBUG - 2022-07-10 20:24:03 --> Total execution time: 0.0755
DEBUG - 2022-07-10 09:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:24:07 --> Total execution time: 0.0587
DEBUG - 2022-07-10 09:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:24:13 --> Total execution time: 0.0600
DEBUG - 2022-07-10 09:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:24:14 --> Total execution time: 0.0532
DEBUG - 2022-07-10 09:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:24:14 --> Total execution time: 0.0505
DEBUG - 2022-07-10 09:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:24:17 --> Total execution time: 0.0523
DEBUG - 2022-07-10 09:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:24:20 --> Total execution time: 0.0525
DEBUG - 2022-07-10 09:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:24:33 --> Total execution time: 0.0705
DEBUG - 2022-07-10 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:24:59 --> Total execution time: 0.0568
DEBUG - 2022-07-10 09:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:55:06 --> No URI present. Default controller set.
DEBUG - 2022-07-10 09:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:25:06 --> Total execution time: 0.0566
DEBUG - 2022-07-10 09:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:25:08 --> Total execution time: 0.0940
DEBUG - 2022-07-10 09:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:55:15 --> Total execution time: 0.0546
DEBUG - 2022-07-10 09:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:55:17 --> Total execution time: 0.0564
DEBUG - 2022-07-10 09:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:55:17 --> Total execution time: 0.0993
DEBUG - 2022-07-10 09:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:55:29 --> Total execution time: 0.1263
DEBUG - 2022-07-10 09:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:25:30 --> Total execution time: 0.0537
DEBUG - 2022-07-10 09:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:25:38 --> Total execution time: 0.0555
DEBUG - 2022-07-10 09:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:25:43 --> Total execution time: 0.0603
DEBUG - 2022-07-10 09:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:25:58 --> Total execution time: 0.0591
DEBUG - 2022-07-10 09:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:56:15 --> Total execution time: 0.0618
DEBUG - 2022-07-10 09:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:56:15 --> Total execution time: 0.0851
DEBUG - 2022-07-10 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 09:57:37 --> Total execution time: 0.0676
DEBUG - 2022-07-10 09:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:58:28 --> No URI present. Default controller set.
DEBUG - 2022-07-10 09:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:28:29 --> Total execution time: 0.1294
DEBUG - 2022-07-10 09:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:58:59 --> No URI present. Default controller set.
DEBUG - 2022-07-10 09:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:28:59 --> Total execution time: 0.0386
DEBUG - 2022-07-10 09:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 09:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 09:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:29:36 --> Total execution time: 0.0503
DEBUG - 2022-07-10 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:30:02 --> Total execution time: 0.0712
DEBUG - 2022-07-10 10:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:30:12 --> Total execution time: 0.0574
DEBUG - 2022-07-10 10:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:30:24 --> Total execution time: 0.0595
DEBUG - 2022-07-10 10:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:30:25 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 10:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:30:25 --> Total execution time: 0.0495
DEBUG - 2022-07-10 10:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:34:45 --> Total execution time: 0.1162
DEBUG - 2022-07-10 10:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:35:01 --> Total execution time: 0.0508
DEBUG - 2022-07-10 10:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:35:41 --> Total execution time: 0.1354
DEBUG - 2022-07-10 10:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:05:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:35:45 --> Total execution time: 0.0400
DEBUG - 2022-07-10 10:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:35:50 --> Total execution time: 0.0596
DEBUG - 2022-07-10 10:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:05:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 10:05:52 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-10 10:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:36:04 --> Total execution time: 0.0531
DEBUG - 2022-07-10 10:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:36:14 --> Total execution time: 0.0590
DEBUG - 2022-07-10 10:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:36:21 --> Total execution time: 0.0764
DEBUG - 2022-07-10 10:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:36:27 --> Total execution time: 0.0905
DEBUG - 2022-07-10 10:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:37:45 --> Total execution time: 0.0528
DEBUG - 2022-07-10 10:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:38:13 --> Total execution time: 0.0557
DEBUG - 2022-07-10 10:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:38:21 --> Total execution time: 0.0544
DEBUG - 2022-07-10 10:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:38:38 --> Total execution time: 0.0551
DEBUG - 2022-07-10 10:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:08:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 10:08:41 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 10:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:38:45 --> Total execution time: 0.0623
DEBUG - 2022-07-10 10:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:38:54 --> Total execution time: 0.0555
DEBUG - 2022-07-10 10:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:38:58 --> Total execution time: 0.0550
DEBUG - 2022-07-10 10:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:39:40 --> Total execution time: 0.0599
DEBUG - 2022-07-10 10:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:40:24 --> Total execution time: 0.0563
DEBUG - 2022-07-10 10:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:10:35 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:40:35 --> Total execution time: 0.0406
DEBUG - 2022-07-10 10:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 10:10:57 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-10 10:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:41:04 --> Total execution time: 0.0686
DEBUG - 2022-07-10 10:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:41:09 --> Total execution time: 0.0721
DEBUG - 2022-07-10 10:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:41:17 --> Total execution time: 0.0588
DEBUG - 2022-07-10 10:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:43:11 --> Total execution time: 0.0574
DEBUG - 2022-07-10 10:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:43:20 --> Total execution time: 0.0537
DEBUG - 2022-07-10 10:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:14:38 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:44:38 --> Total execution time: 0.0418
DEBUG - 2022-07-10 10:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:44:52 --> Total execution time: 0.0374
DEBUG - 2022-07-10 10:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:45:11 --> Total execution time: 0.0557
DEBUG - 2022-07-10 10:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:45:15 --> Total execution time: 0.0654
DEBUG - 2022-07-10 10:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:45:19 --> Total execution time: 0.0638
DEBUG - 2022-07-10 10:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:46:29 --> Total execution time: 0.0594
DEBUG - 2022-07-10 10:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:46:33 --> Total execution time: 0.0523
DEBUG - 2022-07-10 10:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:46:38 --> Total execution time: 0.0497
DEBUG - 2022-07-10 10:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:16:47 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:46:47 --> Total execution time: 0.0488
DEBUG - 2022-07-10 10:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:16:48 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:46:48 --> Total execution time: 0.0371
DEBUG - 2022-07-10 10:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:46:51 --> Total execution time: 0.0344
DEBUG - 2022-07-10 10:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:46:55 --> Total execution time: 0.0493
DEBUG - 2022-07-10 10:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 10:17:05 --> 404 Page Not Found: Category/campus-life
DEBUG - 2022-07-10 10:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:47:07 --> Total execution time: 0.0593
DEBUG - 2022-07-10 10:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:47:12 --> Total execution time: 0.0775
DEBUG - 2022-07-10 10:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:47:12 --> Total execution time: 0.0710
DEBUG - 2022-07-10 10:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:47:21 --> Total execution time: 0.0908
DEBUG - 2022-07-10 10:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:50:19 --> Total execution time: 0.2382
DEBUG - 2022-07-10 10:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:50:27 --> Total execution time: 0.0545
DEBUG - 2022-07-10 10:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:21:30 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:51:30 --> Total execution time: 0.0400
DEBUG - 2022-07-10 10:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:51:36 --> Total execution time: 0.0341
DEBUG - 2022-07-10 10:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:51:58 --> Total execution time: 0.0578
DEBUG - 2022-07-10 10:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:52:11 --> Total execution time: 0.0589
DEBUG - 2022-07-10 10:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:52:24 --> Total execution time: 0.1311
DEBUG - 2022-07-10 10:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:22:26 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:52:26 --> Total execution time: 0.0353
DEBUG - 2022-07-10 10:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:52:38 --> Total execution time: 0.0544
DEBUG - 2022-07-10 10:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:53:07 --> Total execution time: 0.0599
DEBUG - 2022-07-10 10:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:55:00 --> Total execution time: 0.0570
DEBUG - 2022-07-10 10:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:55:28 --> Total execution time: 0.0525
DEBUG - 2022-07-10 10:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:55:33 --> Total execution time: 0.1310
DEBUG - 2022-07-10 10:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:55:45 --> Total execution time: 0.0547
DEBUG - 2022-07-10 10:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:55:48 --> Total execution time: 0.0573
DEBUG - 2022-07-10 10:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:55:52 --> Total execution time: 0.0711
DEBUG - 2022-07-10 10:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:57:13 --> Total execution time: 0.0547
DEBUG - 2022-07-10 10:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:57:43 --> Total execution time: 0.0596
DEBUG - 2022-07-10 10:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:57:47 --> Total execution time: 0.0582
DEBUG - 2022-07-10 10:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:57:54 --> Total execution time: 0.0588
DEBUG - 2022-07-10 10:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:58:27 --> Total execution time: 0.0489
DEBUG - 2022-07-10 10:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:59:56 --> Total execution time: 0.0555
DEBUG - 2022-07-10 10:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:30:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:00:08 --> Total execution time: 0.1371
DEBUG - 2022-07-10 10:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:30:13 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:00:13 --> Total execution time: 0.0372
DEBUG - 2022-07-10 10:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:00:35 --> Total execution time: 0.1272
DEBUG - 2022-07-10 10:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:02:40 --> Total execution time: 0.2073
DEBUG - 2022-07-10 10:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:02:45 --> Total execution time: 0.1324
DEBUG - 2022-07-10 10:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:02:52 --> Total execution time: 0.0558
DEBUG - 2022-07-10 10:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:02:58 --> Total execution time: 0.0541
DEBUG - 2022-07-10 10:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:03:02 --> Total execution time: 0.0611
DEBUG - 2022-07-10 10:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:03:43 --> Total execution time: 0.0521
DEBUG - 2022-07-10 10:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:34:06 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:04:06 --> Total execution time: 0.0549
DEBUG - 2022-07-10 10:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 10:36:42 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-10 10:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:36:48 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:06:48 --> Total execution time: 0.0737
DEBUG - 2022-07-10 10:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:37:18 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:07:18 --> Total execution time: 0.0355
DEBUG - 2022-07-10 10:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:07:50 --> Total execution time: 0.0407
DEBUG - 2022-07-10 10:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:38:13 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:08:13 --> Total execution time: 0.0589
DEBUG - 2022-07-10 10:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:09:46 --> Total execution time: 0.0336
DEBUG - 2022-07-10 10:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:09:54 --> Total execution time: 0.1380
DEBUG - 2022-07-10 10:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:10:22 --> Total execution time: 0.0514
DEBUG - 2022-07-10 10:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:40:28 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:10:28 --> Total execution time: 0.1395
DEBUG - 2022-07-10 10:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:10:41 --> Total execution time: 0.0575
DEBUG - 2022-07-10 10:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:11:41 --> Total execution time: 0.1402
DEBUG - 2022-07-10 10:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:12:04 --> Total execution time: 0.0578
DEBUG - 2022-07-10 10:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:12:28 --> Total execution time: 0.0524
DEBUG - 2022-07-10 10:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:12:30 --> Total execution time: 0.0960
DEBUG - 2022-07-10 10:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:12:43 --> Total execution time: 0.0494
DEBUG - 2022-07-10 10:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:12:50 --> Total execution time: 0.0493
DEBUG - 2022-07-10 10:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:13:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 10:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:13:14 --> Total execution time: 0.0891
DEBUG - 2022-07-10 10:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:13:18 --> Total execution time: 0.1418
DEBUG - 2022-07-10 10:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:13:19 --> Total execution time: 0.0514
DEBUG - 2022-07-10 10:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:13:29 --> Total execution time: 0.0971
DEBUG - 2022-07-10 10:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:13:44 --> Total execution time: 0.0869
DEBUG - 2022-07-10 10:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:13:47 --> Total execution time: 0.0542
DEBUG - 2022-07-10 10:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:14:31 --> Total execution time: 0.0761
DEBUG - 2022-07-10 10:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:44:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:14:45 --> Total execution time: 0.0425
DEBUG - 2022-07-10 10:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:14:50 --> Total execution time: 0.1345
DEBUG - 2022-07-10 10:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:44:53 --> Total execution time: 0.0617
DEBUG - 2022-07-10 10:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:44:56 --> Total execution time: 0.0706
DEBUG - 2022-07-10 10:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:44:56 --> Total execution time: 0.1025
DEBUG - 2022-07-10 10:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:45:11 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:15:11 --> Total execution time: 0.0534
DEBUG - 2022-07-10 10:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:15:17 --> Total execution time: 0.1085
DEBUG - 2022-07-10 10:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:15:20 --> Total execution time: 0.0450
DEBUG - 2022-07-10 10:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:15:52 --> Total execution time: 0.0956
DEBUG - 2022-07-10 10:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:15:56 --> Total execution time: 0.0650
DEBUG - 2022-07-10 10:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:16:04 --> Total execution time: 0.0552
DEBUG - 2022-07-10 10:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:46:06 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:16:06 --> Total execution time: 0.0450
DEBUG - 2022-07-10 10:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:16:11 --> Total execution time: 0.0528
DEBUG - 2022-07-10 10:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:16:34 --> Total execution time: 0.1404
DEBUG - 2022-07-10 10:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:46:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 10:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:16:39 --> Total execution time: 0.0565
DEBUG - 2022-07-10 21:16:40 --> Total execution time: 1.9368
DEBUG - 2022-07-10 10:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:16:42 --> Total execution time: 0.0826
DEBUG - 2022-07-10 10:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 10:46:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 10:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:16:54 --> Total execution time: 0.1349
DEBUG - 2022-07-10 10:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:17:06 --> Total execution time: 0.0626
DEBUG - 2022-07-10 10:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:17:09 --> Total execution time: 0.0780
DEBUG - 2022-07-10 10:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:17:13 --> Total execution time: 0.0687
DEBUG - 2022-07-10 10:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:17:40 --> Total execution time: 0.0658
DEBUG - 2022-07-10 10:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:47:41 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:17:41 --> Total execution time: 0.0328
DEBUG - 2022-07-10 10:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:17:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 10:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:17:45 --> Total execution time: 0.0586
DEBUG - 2022-07-10 10:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:17:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 21:17:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 21:17:47 --> Total execution time: 0.2202
DEBUG - 2022-07-10 10:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:17:47 --> Total execution time: 0.0678
DEBUG - 2022-07-10 10:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:17:49 --> Total execution time: 0.0675
DEBUG - 2022-07-10 10:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:17:55 --> Total execution time: 0.0655
DEBUG - 2022-07-10 10:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:18:02 --> Total execution time: 0.0771
DEBUG - 2022-07-10 10:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:18:12 --> Total execution time: 0.0707
DEBUG - 2022-07-10 10:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:48:17 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:18:17 --> Total execution time: 0.0349
DEBUG - 2022-07-10 10:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:48:18 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:18:18 --> Total execution time: 0.0367
DEBUG - 2022-07-10 10:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:18:31 --> Total execution time: 0.1322
DEBUG - 2022-07-10 10:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:18:41 --> Total execution time: 0.0716
DEBUG - 2022-07-10 10:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:48:41 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:18:41 --> Total execution time: 0.1418
DEBUG - 2022-07-10 10:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:48:53 --> Total execution time: 0.0502
DEBUG - 2022-07-10 10:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:48:55 --> Total execution time: 0.0536
DEBUG - 2022-07-10 10:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:48:55 --> Total execution time: 0.1067
DEBUG - 2022-07-10 10:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:19:00 --> Total execution time: 0.0742
DEBUG - 2022-07-10 10:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:19:10 --> Total execution time: 0.0780
DEBUG - 2022-07-10 10:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:19:43 --> Total execution time: 0.0757
DEBUG - 2022-07-10 10:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:50:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 10:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:20:15 --> Total execution time: 1.4508
DEBUG - 2022-07-10 10:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 10:50:31 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 10:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:21:09 --> Total execution time: 1.4263
DEBUG - 2022-07-10 10:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:51:13 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:21:13 --> Total execution time: 0.0383
DEBUG - 2022-07-10 10:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:22:08 --> Total execution time: 0.0497
DEBUG - 2022-07-10 10:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:22:10 --> Total execution time: 0.0399
DEBUG - 2022-07-10 10:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:22:20 --> Total execution time: 0.0616
DEBUG - 2022-07-10 10:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:22:22 --> Total execution time: 0.0878
DEBUG - 2022-07-10 10:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:22:23 --> Total execution time: 0.0681
DEBUG - 2022-07-10 10:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:22:32 --> Total execution time: 2.4568
DEBUG - 2022-07-10 10:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:22:34 --> Total execution time: 0.0542
DEBUG - 2022-07-10 10:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:40 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:22:40 --> Total execution time: 0.0470
DEBUG - 2022-07-10 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:47 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:22:47 --> Total execution time: 0.0323
DEBUG - 2022-07-10 10:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:22:51 --> Total execution time: 0.0290
DEBUG - 2022-07-10 10:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:22:57 --> Total execution time: 0.0475
DEBUG - 2022-07-10 10:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:23:00 --> Total execution time: 0.0559
DEBUG - 2022-07-10 10:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:23:11 --> Total execution time: 0.0593
DEBUG - 2022-07-10 10:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:23:16 --> Total execution time: 0.0732
DEBUG - 2022-07-10 10:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:23:31 --> Total execution time: 0.0574
DEBUG - 2022-07-10 10:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:24:08 --> Total execution time: 0.0622
DEBUG - 2022-07-10 10:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:24:21 --> Total execution time: 0.0633
DEBUG - 2022-07-10 10:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:24:33 --> Total execution time: 0.0510
DEBUG - 2022-07-10 10:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:24:33 --> Total execution time: 0.0721
DEBUG - 2022-07-10 10:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:24:44 --> Total execution time: 0.0538
DEBUG - 2022-07-10 10:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:24:51 --> Total execution time: 0.0713
DEBUG - 2022-07-10 10:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:24:54 --> Total execution time: 0.0507
DEBUG - 2022-07-10 10:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:25:00 --> Total execution time: 0.0561
DEBUG - 2022-07-10 10:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:25:21 --> Total execution time: 0.1581
DEBUG - 2022-07-10 10:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:25:43 --> Total execution time: 0.0564
DEBUG - 2022-07-10 10:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:25:50 --> Total execution time: 0.0523
DEBUG - 2022-07-10 10:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 10:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:56:22 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:26:22 --> Total execution time: 0.0584
DEBUG - 2022-07-10 10:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:26:23 --> Total execution time: 0.0754
DEBUG - 2022-07-10 10:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:28:17 --> Total execution time: 0.0505
DEBUG - 2022-07-10 10:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:58:28 --> No URI present. Default controller set.
DEBUG - 2022-07-10 10:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:28:28 --> Total execution time: 0.0365
DEBUG - 2022-07-10 10:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:28:38 --> Total execution time: 0.0444
DEBUG - 2022-07-10 10:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:29:24 --> Total execution time: 0.0524
DEBUG - 2022-07-10 10:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:29:39 --> Total execution time: 0.0523
DEBUG - 2022-07-10 10:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:29:54 --> Total execution time: 0.0543
DEBUG - 2022-07-10 10:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 10:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 10:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:29:57 --> Total execution time: 0.0645
DEBUG - 2022-07-10 11:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:30:00 --> Total execution time: 0.0439
DEBUG - 2022-07-10 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:30:02 --> Total execution time: 0.0467
DEBUG - 2022-07-10 11:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:30:52 --> Total execution time: 0.0505
DEBUG - 2022-07-10 11:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:31:12 --> Total execution time: 0.0538
DEBUG - 2022-07-10 11:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:31:37 --> Total execution time: 0.0513
DEBUG - 2022-07-10 11:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:31:46 --> Total execution time: 0.0576
DEBUG - 2022-07-10 11:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:32:01 --> Total execution time: 0.0990
DEBUG - 2022-07-10 11:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:32:34 --> Total execution time: 0.0581
DEBUG - 2022-07-10 11:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:32:42 --> Total execution time: 0.0670
DEBUG - 2022-07-10 11:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:32:50 --> Total execution time: 0.0554
DEBUG - 2022-07-10 11:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:33:00 --> Total execution time: 0.0563
DEBUG - 2022-07-10 11:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:33:17 --> Total execution time: 0.0590
DEBUG - 2022-07-10 11:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:33:30 --> Total execution time: 0.0552
DEBUG - 2022-07-10 11:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:03:32 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:33:32 --> Total execution time: 0.1266
DEBUG - 2022-07-10 11:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:33:36 --> Total execution time: 0.1302
DEBUG - 2022-07-10 11:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:34:21 --> Total execution time: 0.1373
DEBUG - 2022-07-10 11:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:34:35 --> Total execution time: 0.0506
DEBUG - 2022-07-10 11:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:05:28 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:35:28 --> Total execution time: 0.0524
DEBUG - 2022-07-10 11:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:35:31 --> Total execution time: 0.0580
DEBUG - 2022-07-10 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:05:32 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:35:32 --> Total execution time: 0.1530
DEBUG - 2022-07-10 11:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:35:40 --> Total execution time: 0.0593
DEBUG - 2022-07-10 11:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:35:42 --> Total execution time: 0.0589
DEBUG - 2022-07-10 11:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:35:48 --> Total execution time: 0.0756
DEBUG - 2022-07-10 11:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:35:56 --> Total execution time: 0.1236
DEBUG - 2022-07-10 11:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:35:57 --> Total execution time: 0.0571
DEBUG - 2022-07-10 11:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:36:01 --> Total execution time: 0.0574
DEBUG - 2022-07-10 11:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:36:17 --> Total execution time: 0.0538
DEBUG - 2022-07-10 11:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:36:35 --> Total execution time: 0.0496
DEBUG - 2022-07-10 11:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:06:44 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:36:44 --> Total execution time: 0.0541
DEBUG - 2022-07-10 11:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:36:48 --> Total execution time: 0.0500
DEBUG - 2022-07-10 11:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:36:56 --> Total execution time: 0.0552
DEBUG - 2022-07-10 11:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:36:59 --> Total execution time: 0.0706
DEBUG - 2022-07-10 11:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:37:07 --> Total execution time: 0.0539
DEBUG - 2022-07-10 11:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:37:21 --> Total execution time: 0.0511
DEBUG - 2022-07-10 11:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:07:28 --> Total execution time: 0.0978
DEBUG - 2022-07-10 11:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:37:28 --> Total execution time: 0.0681
DEBUG - 2022-07-10 11:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:37:35 --> Total execution time: 0.0581
DEBUG - 2022-07-10 11:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:07:36 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:37:36 --> Total execution time: 0.1300
DEBUG - 2022-07-10 11:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:37:39 --> Total execution time: 0.0526
DEBUG - 2022-07-10 11:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:37:42 --> Total execution time: 0.0591
DEBUG - 2022-07-10 11:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:37:44 --> Total execution time: 0.0614
DEBUG - 2022-07-10 11:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:37:48 --> Total execution time: 0.0858
DEBUG - 2022-07-10 11:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:37:54 --> Total execution time: 0.0585
DEBUG - 2022-07-10 11:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:38:05 --> Total execution time: 0.0614
DEBUG - 2022-07-10 11:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:08:09 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:38:09 --> Total execution time: 0.0524
DEBUG - 2022-07-10 11:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:38:13 --> Total execution time: 0.0526
DEBUG - 2022-07-10 11:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:38:20 --> Total execution time: 0.0633
DEBUG - 2022-07-10 11:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:38:23 --> Total execution time: 0.0690
DEBUG - 2022-07-10 11:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:38:28 --> Total execution time: 0.0557
DEBUG - 2022-07-10 11:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:38:30 --> Total execution time: 0.0536
DEBUG - 2022-07-10 11:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:39:10 --> Total execution time: 0.1301
DEBUG - 2022-07-10 11:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:39:14 --> Total execution time: 0.0538
DEBUG - 2022-07-10 11:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:39:17 --> Total execution time: 0.0568
DEBUG - 2022-07-10 11:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:09:23 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:39:23 --> Total execution time: 0.0393
DEBUG - 2022-07-10 11:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:10:01 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:40:01 --> Total execution time: 0.0546
DEBUG - 2022-07-10 11:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:11:17 --> Total execution time: 0.0539
DEBUG - 2022-07-10 11:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:11:38 --> Total execution time: 0.0652
DEBUG - 2022-07-10 11:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:42:04 --> Total execution time: 0.0594
DEBUG - 2022-07-10 11:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:42:20 --> Total execution time: 0.0629
DEBUG - 2022-07-10 11:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:13:44 --> Total execution time: 0.0518
DEBUG - 2022-07-10 11:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:14:40 --> Total execution time: 0.0644
DEBUG - 2022-07-10 11:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:14:57 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:44:57 --> Total execution time: 0.0476
DEBUG - 2022-07-10 11:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:16:33 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:46:33 --> Total execution time: 0.0392
DEBUG - 2022-07-10 11:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:16:52 --> Total execution time: 0.0529
DEBUG - 2022-07-10 11:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:47:10 --> Total execution time: 0.0670
DEBUG - 2022-07-10 11:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:47:17 --> Total execution time: 0.0508
DEBUG - 2022-07-10 11:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:17:27 --> Total execution time: 0.0744
DEBUG - 2022-07-10 11:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:17:35 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:47:35 --> Total execution time: 0.0538
DEBUG - 2022-07-10 11:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:17:37 --> Total execution time: 0.0879
DEBUG - 2022-07-10 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:17:39 --> Total execution time: 0.0551
DEBUG - 2022-07-10 11:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:17:40 --> Total execution time: 0.0615
DEBUG - 2022-07-10 11:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:17:51 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:47:51 --> Total execution time: 0.0590
DEBUG - 2022-07-10 11:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:18:17 --> Total execution time: 0.0533
DEBUG - 2022-07-10 11:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:18:18 --> Total execution time: 0.0605
DEBUG - 2022-07-10 11:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:18:18 --> Total execution time: 0.1032
DEBUG - 2022-07-10 11:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:48:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 11:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:48:21 --> Total execution time: 0.0599
DEBUG - 2022-07-10 11:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:48:22 --> Total execution time: 0.0595
DEBUG - 2022-07-10 11:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:49:17 --> Total execution time: 0.0597
DEBUG - 2022-07-10 11:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:19:22 --> Total execution time: 0.0515
DEBUG - 2022-07-10 11:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:19:43 --> Total execution time: 0.0655
DEBUG - 2022-07-10 11:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:51:34 --> Total execution time: 0.0532
DEBUG - 2022-07-10 11:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:16 --> Total execution time: 0.0550
DEBUG - 2022-07-10 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:25 --> Total execution time: 0.0784
DEBUG - 2022-07-10 11:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:39 --> Total execution time: 0.0950
DEBUG - 2022-07-10 11:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:40 --> Total execution time: 0.0510
DEBUG - 2022-07-10 11:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:41 --> Total execution time: 0.0522
DEBUG - 2022-07-10 11:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:22:42 --> Total execution time: 0.0439
DEBUG - 2022-07-10 11:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:45 --> Total execution time: 0.0826
DEBUG - 2022-07-10 11:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:54 --> Total execution time: 0.0766
DEBUG - 2022-07-10 11:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:55 --> Total execution time: 0.0553
DEBUG - 2022-07-10 11:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:53:03 --> Total execution time: 0.0803
DEBUG - 2022-07-10 11:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:53:06 --> Total execution time: 0.0717
DEBUG - 2022-07-10 11:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:53:10 --> Total execution time: 0.0674
DEBUG - 2022-07-10 11:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:53:21 --> Total execution time: 0.0620
DEBUG - 2022-07-10 11:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:53:26 --> Total execution time: 0.1598
DEBUG - 2022-07-10 11:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:53:27 --> Total execution time: 0.0567
DEBUG - 2022-07-10 11:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:53:42 --> Total execution time: 0.0661
DEBUG - 2022-07-10 11:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:53:52 --> Total execution time: 0.0568
DEBUG - 2022-07-10 11:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:24:08 --> Total execution time: 0.0612
DEBUG - 2022-07-10 11:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:54:08 --> Total execution time: 0.0598
DEBUG - 2022-07-10 11:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:54:20 --> Total execution time: 0.0505
DEBUG - 2022-07-10 11:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:54:24 --> Total execution time: 0.0687
DEBUG - 2022-07-10 11:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:56:37 --> Total execution time: 0.0585
DEBUG - 2022-07-10 11:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:56:39 --> Total execution time: 0.0626
DEBUG - 2022-07-10 11:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:57:02 --> Total execution time: 0.0563
DEBUG - 2022-07-10 11:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:57:05 --> Total execution time: 0.0701
DEBUG - 2022-07-10 11:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:57:16 --> Total execution time: 0.0598
DEBUG - 2022-07-10 11:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:27:57 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:57:57 --> Total execution time: 0.1351
DEBUG - 2022-07-10 11:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:58:37 --> Total execution time: 0.0551
DEBUG - 2022-07-10 11:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:58:49 --> Total execution time: 0.0781
DEBUG - 2022-07-10 11:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:59:50 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 11:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:59:51 --> Total execution time: 0.0563
DEBUG - 2022-07-10 11:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:00:14 --> Total execution time: 0.0564
DEBUG - 2022-07-10 11:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:00:17 --> Total execution time: 0.0577
DEBUG - 2022-07-10 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:00:29 --> Total execution time: 0.0746
DEBUG - 2022-07-10 11:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:30:37 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:00:37 --> Total execution time: 0.0374
DEBUG - 2022-07-10 11:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:01:16 --> Total execution time: 0.0711
DEBUG - 2022-07-10 11:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:01:24 --> Total execution time: 0.0555
DEBUG - 2022-07-10 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:31:35 --> Total execution time: 0.0506
DEBUG - 2022-07-10 11:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:01:38 --> Total execution time: 0.0543
DEBUG - 2022-07-10 11:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:01:49 --> Total execution time: 0.0535
DEBUG - 2022-07-10 11:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:02:00 --> Total execution time: 0.1179
DEBUG - 2022-07-10 11:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:02:37 --> Total execution time: 0.0797
DEBUG - 2022-07-10 11:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:03:09 --> Total execution time: 0.0610
DEBUG - 2022-07-10 11:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:03:22 --> Total execution time: 0.0551
DEBUG - 2022-07-10 11:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:03:30 --> Total execution time: 0.0925
DEBUG - 2022-07-10 11:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:04:50 --> Total execution time: 0.0727
DEBUG - 2022-07-10 11:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:05:09 --> Total execution time: 0.1468
DEBUG - 2022-07-10 11:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:06:05 --> Total execution time: 0.0388
DEBUG - 2022-07-10 11:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:06:28 --> Total execution time: 0.0510
DEBUG - 2022-07-10 11:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:36:34 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:06:34 --> Total execution time: 0.0534
DEBUG - 2022-07-10 11:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:06:38 --> Total execution time: 0.0569
DEBUG - 2022-07-10 11:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:36:48 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:06:48 --> Total execution time: 0.0549
DEBUG - 2022-07-10 11:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:06:49 --> Total execution time: 0.0499
DEBUG - 2022-07-10 11:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:06:54 --> Total execution time: 0.0509
DEBUG - 2022-07-10 11:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:07:05 --> Total execution time: 0.0547
DEBUG - 2022-07-10 11:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:07:26 --> Total execution time: 0.0513
DEBUG - 2022-07-10 11:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:07:33 --> Total execution time: 0.0566
DEBUG - 2022-07-10 11:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:07:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 11:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:07:34 --> Total execution time: 0.0529
DEBUG - 2022-07-10 11:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:38:32 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:08:32 --> Total execution time: 0.0444
DEBUG - 2022-07-10 11:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:38:33 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:08:33 --> Total execution time: 0.0348
DEBUG - 2022-07-10 11:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:08:46 --> Total execution time: 0.0343
DEBUG - 2022-07-10 11:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:08:58 --> Total execution time: 0.0376
DEBUG - 2022-07-10 11:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:39:07 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:09:07 --> Total execution time: 0.0522
DEBUG - 2022-07-10 11:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:09:15 --> Total execution time: 0.0631
DEBUG - 2022-07-10 11:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:39:17 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:09:17 --> Total execution time: 0.0517
DEBUG - 2022-07-10 11:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:10:03 --> Total execution time: 0.0534
DEBUG - 2022-07-10 11:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:10:28 --> Total execution time: 0.0506
DEBUG - 2022-07-10 11:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:10:32 --> Total execution time: 0.0603
DEBUG - 2022-07-10 11:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:10:34 --> Total execution time: 0.0626
DEBUG - 2022-07-10 11:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:10:36 --> Total execution time: 0.0535
DEBUG - 2022-07-10 11:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:10:39 --> Total execution time: 0.0502
DEBUG - 2022-07-10 11:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:11:14 --> Total execution time: 0.1687
DEBUG - 2022-07-10 11:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:13:02 --> Total execution time: 0.0504
DEBUG - 2022-07-10 11:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:20:36 --> Total execution time: 0.2190
DEBUG - 2022-07-10 11:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:20:40 --> Total execution time: 0.0716
DEBUG - 2022-07-10 11:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:20:51 --> Total execution time: 0.0525
DEBUG - 2022-07-10 11:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:05 --> Total execution time: 0.0747
DEBUG - 2022-07-10 11:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:45 --> Total execution time: 0.0557
DEBUG - 2022-07-10 11:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:52:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 11:52:33 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-10 11:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:52:48 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:22:48 --> Total execution time: 0.0469
DEBUG - 2022-07-10 11:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:22:51 --> Total execution time: 0.0630
DEBUG - 2022-07-10 11:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:22:57 --> Total execution time: 0.0551
DEBUG - 2022-07-10 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 11:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:23:57 --> Total execution time: 0.0678
DEBUG - 2022-07-10 11:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:55:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 11:55:20 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 11:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:57:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 11:57:39 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-10 11:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:28:12 --> Total execution time: 0.2100
DEBUG - 2022-07-10 11:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 11:58:31 --> No URI present. Default controller set.
DEBUG - 2022-07-10 11:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 11:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:28:31 --> Total execution time: 0.0676
DEBUG - 2022-07-10 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:30:03 --> Total execution time: 0.0676
DEBUG - 2022-07-10 12:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:30:07 --> Total execution time: 0.0579
DEBUG - 2022-07-10 12:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:02:17 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:32:17 --> Total execution time: 0.1150
DEBUG - 2022-07-10 12:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:32:22 --> Total execution time: 0.0684
DEBUG - 2022-07-10 12:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:33:08 --> Total execution time: 0.0499
DEBUG - 2022-07-10 12:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:06:46 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:36:46 --> Total execution time: 0.0867
DEBUG - 2022-07-10 12:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:37:23 --> Total execution time: 0.0528
DEBUG - 2022-07-10 12:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:39:52 --> Total execution time: 0.1871
DEBUG - 2022-07-10 12:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:40:01 --> Total execution time: 0.0516
DEBUG - 2022-07-10 12:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:10:39 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:40:39 --> Total execution time: 0.1307
DEBUG - 2022-07-10 12:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:40:55 --> Total execution time: 2.0822
DEBUG - 2022-07-10 12:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:11:12 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:41:12 --> Total execution time: 0.0623
DEBUG - 2022-07-10 12:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:12:05 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:42:05 --> Total execution time: 0.0694
DEBUG - 2022-07-10 12:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:42:28 --> Total execution time: 1.6661
DEBUG - 2022-07-10 12:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:12:55 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:42:55 --> Total execution time: 0.0383
DEBUG - 2022-07-10 12:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:12:56 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:42:56 --> Total execution time: 0.0408
DEBUG - 2022-07-10 12:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:43:07 --> Total execution time: 0.0405
DEBUG - 2022-07-10 12:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:13:20 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:43:20 --> Total execution time: 0.0545
DEBUG - 2022-07-10 12:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:43:28 --> Total execution time: 0.0799
DEBUG - 2022-07-10 12:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:43:34 --> Total execution time: 0.0512
DEBUG - 2022-07-10 12:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:43:44 --> Total execution time: 0.0662
DEBUG - 2022-07-10 12:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:14:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:44:08 --> Total execution time: 0.0586
DEBUG - 2022-07-10 12:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:14:38 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:44:38 --> Total execution time: 0.0399
DEBUG - 2022-07-10 12:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:14:39 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:44:40 --> Total execution time: 0.0576
DEBUG - 2022-07-10 12:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:44:45 --> Total execution time: 0.0529
DEBUG - 2022-07-10 12:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:44:50 --> Total execution time: 0.0522
DEBUG - 2022-07-10 12:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:44:53 --> Total execution time: 0.0512
DEBUG - 2022-07-10 12:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:45:03 --> Total execution time: 0.0649
DEBUG - 2022-07-10 12:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:45:13 --> Total execution time: 0.0672
DEBUG - 2022-07-10 12:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:45:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 12:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:45:14 --> Total execution time: 0.0565
DEBUG - 2022-07-10 12:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:45:14 --> Total execution time: 0.0708
DEBUG - 2022-07-10 12:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:15:24 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:45:24 --> Total execution time: 0.0679
DEBUG - 2022-07-10 12:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:15:29 --> Total execution time: 0.0695
DEBUG - 2022-07-10 12:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:15:31 --> Total execution time: 0.0586
DEBUG - 2022-07-10 12:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:15:31 --> Total execution time: 0.0960
DEBUG - 2022-07-10 12:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:16:44 --> Total execution time: 1.2681
DEBUG - 2022-07-10 12:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:16:47 --> Total execution time: 0.0753
DEBUG - 2022-07-10 12:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:16:47 --> Total execution time: 0.1603
DEBUG - 2022-07-10 12:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:46:57 --> Total execution time: 0.0514
DEBUG - 2022-07-10 12:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:47:06 --> Total execution time: 0.1395
DEBUG - 2022-07-10 12:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:47:06 --> Total execution time: 0.1832
DEBUG - 2022-07-10 12:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:47:07 --> Total execution time: 0.1361
DEBUG - 2022-07-10 12:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:47:09 --> Total execution time: 0.0630
DEBUG - 2022-07-10 12:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:47:11 --> Total execution time: 0.0864
DEBUG - 2022-07-10 12:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:47:12 --> Total execution time: 0.1708
DEBUG - 2022-07-10 12:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:47:16 --> Total execution time: 0.0561
DEBUG - 2022-07-10 12:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:47:18 --> Total execution time: 0.0605
DEBUG - 2022-07-10 12:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:47:24 --> Total execution time: 0.0684
DEBUG - 2022-07-10 12:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:47:31 --> Total execution time: 0.0544
DEBUG - 2022-07-10 12:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:47:36 --> Total execution time: 0.1002
DEBUG - 2022-07-10 12:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:47:44 --> Total execution time: 0.0805
DEBUG - 2022-07-10 12:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:47:53 --> Total execution time: 0.0557
DEBUG - 2022-07-10 12:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:17:54 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:47:55 --> Total execution time: 1.5140
DEBUG - 2022-07-10 12:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:18:22 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:48:22 --> Total execution time: 0.0532
DEBUG - 2022-07-10 12:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:48:35 --> Total execution time: 0.0782
DEBUG - 2022-07-10 12:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:48:36 --> Total execution time: 0.0593
DEBUG - 2022-07-10 12:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:48:47 --> Total execution time: 0.1537
DEBUG - 2022-07-10 12:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:48:51 --> Total execution time: 0.0554
DEBUG - 2022-07-10 12:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:48:54 --> Total execution time: 0.0552
DEBUG - 2022-07-10 12:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:48:54 --> Total execution time: 0.0506
DEBUG - 2022-07-10 12:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:18:58 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:48:58 --> Total execution time: 0.0644
DEBUG - 2022-07-10 12:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:48:58 --> Total execution time: 0.1396
DEBUG - 2022-07-10 12:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:19:10 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:49:10 --> Total execution time: 0.0785
DEBUG - 2022-07-10 12:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:49:25 --> Total execution time: 0.0598
DEBUG - 2022-07-10 12:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:49:39 --> Total execution time: 0.0502
DEBUG - 2022-07-10 12:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:49:49 --> Total execution time: 0.0551
DEBUG - 2022-07-10 12:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:19:49 --> Total execution time: 0.0577
DEBUG - 2022-07-10 12:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:19:50 --> Total execution time: 0.0606
DEBUG - 2022-07-10 12:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:19:50 --> Total execution time: 0.1052
DEBUG - 2022-07-10 12:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:49:54 --> Total execution time: 0.0524
DEBUG - 2022-07-10 12:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:20:09 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:50:09 --> Total execution time: 0.0615
DEBUG - 2022-07-10 12:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:50:35 --> Total execution time: 0.0635
DEBUG - 2022-07-10 12:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:20:49 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:50:49 --> Total execution time: 0.0683
DEBUG - 2022-07-10 12:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:20:55 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:50:55 --> Total execution time: 0.0699
DEBUG - 2022-07-10 12:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:21:01 --> Total execution time: 0.0463
DEBUG - 2022-07-10 12:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:21:02 --> Total execution time: 0.0524
DEBUG - 2022-07-10 12:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:21:03 --> Total execution time: 0.0870
DEBUG - 2022-07-10 12:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:10 --> Total execution time: 0.0540
DEBUG - 2022-07-10 12:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:16 --> Total execution time: 0.1342
DEBUG - 2022-07-10 12:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:18 --> Total execution time: 0.0498
DEBUG - 2022-07-10 12:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:18 --> Total execution time: 0.0562
DEBUG - 2022-07-10 12:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:27 --> Total execution time: 0.0714
DEBUG - 2022-07-10 12:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:33 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:33 --> Total execution time: 0.0558
DEBUG - 2022-07-10 12:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:21:40 --> Total execution time: 0.0504
DEBUG - 2022-07-10 12:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:21:42 --> Total execution time: 0.0698
DEBUG - 2022-07-10 12:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:21:42 --> Total execution time: 0.0816
DEBUG - 2022-07-10 12:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:49 --> Total execution time: 0.0500
DEBUG - 2022-07-10 12:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:50 --> Total execution time: 0.0589
DEBUG - 2022-07-10 12:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:52:19 --> Total execution time: 0.0653
DEBUG - 2022-07-10 12:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:52:23 --> Total execution time: 0.0582
DEBUG - 2022-07-10 12:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:53:05 --> Total execution time: 0.0784
DEBUG - 2022-07-10 12:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:16 --> Total execution time: 0.0632
DEBUG - 2022-07-10 12:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:24:19 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:19 --> Total execution time: 0.1317
DEBUG - 2022-07-10 12:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:22 --> Total execution time: 0.0618
DEBUG - 2022-07-10 12:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:24:23 --> Total execution time: 0.1409
DEBUG - 2022-07-10 12:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:24:24 --> Total execution time: 0.0784
DEBUG - 2022-07-10 12:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:24:25 --> Total execution time: 0.0775
DEBUG - 2022-07-10 12:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:24:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 12:24:39 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-10 12:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:41 --> Total execution time: 0.0527
DEBUG - 2022-07-10 12:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:43 --> Total execution time: 0.0520
DEBUG - 2022-07-10 12:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:47 --> Total execution time: 0.0538
DEBUG - 2022-07-10 12:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:49 --> Total execution time: 0.0548
DEBUG - 2022-07-10 12:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:55:04 --> Total execution time: 0.0815
DEBUG - 2022-07-10 12:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:55:12 --> Total execution time: 0.0527
DEBUG - 2022-07-10 12:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:55:24 --> Total execution time: 0.0766
DEBUG - 2022-07-10 12:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:57:53 --> Total execution time: 0.0640
DEBUG - 2022-07-10 12:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:06 --> Total execution time: 0.0523
DEBUG - 2022-07-10 12:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:12 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:13 --> Total execution time: 0.0444
DEBUG - 2022-07-10 12:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:23 --> Total execution time: 0.0536
DEBUG - 2022-07-10 12:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:28:24 --> Total execution time: 0.0418
DEBUG - 2022-07-10 12:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:24 --> Total execution time: 0.0502
DEBUG - 2022-07-10 12:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:27 --> Total execution time: 0.0498
DEBUG - 2022-07-10 12:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:28 --> Total execution time: 0.0727
DEBUG - 2022-07-10 12:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:30 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:30 --> Total execution time: 0.0530
DEBUG - 2022-07-10 12:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:37 --> Total execution time: 1.8683
DEBUG - 2022-07-10 12:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 12:28:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 12:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:40 --> Total execution time: 0.0581
DEBUG - 2022-07-10 12:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:52 --> Total execution time: 0.0762
DEBUG - 2022-07-10 12:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:54 --> Total execution time: 0.0812
DEBUG - 2022-07-10 12:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:59:01 --> Total execution time: 0.1727
DEBUG - 2022-07-10 12:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:59:01 --> Total execution time: 0.3165
DEBUG - 2022-07-10 12:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:59:02 --> Total execution time: 0.0847
DEBUG - 2022-07-10 12:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:59:03 --> Total execution time: 0.0602
DEBUG - 2022-07-10 12:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:59:04 --> Total execution time: 0.0836
DEBUG - 2022-07-10 12:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:59:04 --> Total execution time: 0.0728
DEBUG - 2022-07-10 12:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:59:04 --> Total execution time: 0.0707
DEBUG - 2022-07-10 12:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:59:05 --> Total execution time: 0.0816
DEBUG - 2022-07-10 12:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:59:12 --> Total execution time: 0.3021
DEBUG - 2022-07-10 12:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:00:38 --> Total execution time: 0.0614
DEBUG - 2022-07-10 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:00:43 --> Total execution time: 0.0551
DEBUG - 2022-07-10 12:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:00:51 --> Total execution time: 0.0742
DEBUG - 2022-07-10 12:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:01:40 --> Total execution time: 2.4803
DEBUG - 2022-07-10 12:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:01:40 --> Total execution time: 1.8931
DEBUG - 2022-07-10 12:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 12:31:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 12:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:31:44 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:01:44 --> Total execution time: 0.0401
DEBUG - 2022-07-10 12:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:11 --> Total execution time: 0.0737
DEBUG - 2022-07-10 12:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:14 --> Total execution time: 0.0833
DEBUG - 2022-07-10 12:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:32:18 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:18 --> Total execution time: 0.0525
DEBUG - 2022-07-10 12:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:36 --> Total execution time: 0.0591
DEBUG - 2022-07-10 12:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:37 --> Total execution time: 0.0789
DEBUG - 2022-07-10 12:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:51 --> Total execution time: 0.0871
DEBUG - 2022-07-10 12:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:55 --> Total execution time: 0.0811
DEBUG - 2022-07-10 12:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:56 --> Total execution time: 0.0775
DEBUG - 2022-07-10 12:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:58 --> Total execution time: 0.0817
DEBUG - 2022-07-10 12:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:59 --> Total execution time: 0.0754
DEBUG - 2022-07-10 12:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:59 --> Total execution time: 0.1536
DEBUG - 2022-07-10 12:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:03:00 --> Total execution time: 0.0771
DEBUG - 2022-07-10 12:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:03:19 --> Total execution time: 0.0501
DEBUG - 2022-07-10 12:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:03:26 --> Total execution time: 0.6010
DEBUG - 2022-07-10 12:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 12:33:27 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-07-10 12:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 12:33:27 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-07-10 12:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 12:33:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 12:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 12:33:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 12:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:33:28 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:03:28 --> Total execution time: 0.0371
DEBUG - 2022-07-10 12:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:03:38 --> Total execution time: 1.5489
DEBUG - 2022-07-10 12:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:03:40 --> Total execution time: 0.0649
DEBUG - 2022-07-10 12:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:03:46 --> Total execution time: 0.1859
DEBUG - 2022-07-10 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:03:47 --> Total execution time: 0.0556
DEBUG - 2022-07-10 12:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:04:09 --> Total execution time: 1.5554
DEBUG - 2022-07-10 12:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:04:21 --> Total execution time: 0.1318
DEBUG - 2022-07-10 12:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:04:53 --> Total execution time: 0.0817
DEBUG - 2022-07-10 12:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:05:06 --> Total execution time: 0.0494
DEBUG - 2022-07-10 12:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:05:08 --> Total execution time: 0.1514
DEBUG - 2022-07-10 12:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:05:27 --> Total execution time: 0.0817
DEBUG - 2022-07-10 12:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:07:53 --> Total execution time: 2.5095
DEBUG - 2022-07-10 12:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:38:29 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:08:29 --> Total execution time: 0.1342
DEBUG - 2022-07-10 12:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:09:49 --> Total execution time: 0.1623
DEBUG - 2022-07-10 12:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:13:52 --> Total execution time: 0.0864
DEBUG - 2022-07-10 12:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:44:37 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:14:37 --> Total execution time: 0.1411
DEBUG - 2022-07-10 12:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:44:43 --> Total execution time: 0.0541
DEBUG - 2022-07-10 12:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:44:44 --> Total execution time: 0.0637
DEBUG - 2022-07-10 12:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:44:44 --> Total execution time: 0.1172
DEBUG - 2022-07-10 12:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:14:52 --> Total execution time: 0.0507
DEBUG - 2022-07-10 12:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:14:53 --> Total execution time: 0.0541
DEBUG - 2022-07-10 12:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:44:54 --> Total execution time: 0.0642
DEBUG - 2022-07-10 12:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:45:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:15:08 --> Total execution time: 0.0578
DEBUG - 2022-07-10 12:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:15:10 --> Total execution time: 0.0723
DEBUG - 2022-07-10 12:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:45:20 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:15:20 --> Total execution time: 0.0547
DEBUG - 2022-07-10 12:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:45:28 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:15:28 --> Total execution time: 0.0538
DEBUG - 2022-07-10 12:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:45:42 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:15:42 --> Total execution time: 0.0529
DEBUG - 2022-07-10 12:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:16:12 --> Total execution time: 0.0547
DEBUG - 2022-07-10 12:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:16:14 --> Total execution time: 0.0565
DEBUG - 2022-07-10 12:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:16:16 --> Total execution time: 0.0502
DEBUG - 2022-07-10 12:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:16:18 --> Total execution time: 0.0524
DEBUG - 2022-07-10 12:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:16:23 --> Total execution time: 0.0494
DEBUG - 2022-07-10 12:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:16:24 --> Total execution time: 0.0745
DEBUG - 2022-07-10 12:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:46:26 --> Total execution time: 0.0526
DEBUG - 2022-07-10 12:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:16:41 --> Total execution time: 0.0469
DEBUG - 2022-07-10 12:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:16:45 --> Total execution time: 0.0463
DEBUG - 2022-07-10 12:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:16:48 --> Total execution time: 0.0482
DEBUG - 2022-07-10 12:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:16:55 --> Total execution time: 0.0545
DEBUG - 2022-07-10 12:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:16:59 --> Total execution time: 0.0586
DEBUG - 2022-07-10 12:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:17:02 --> Total execution time: 0.0956
DEBUG - 2022-07-10 12:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:17:10 --> Total execution time: 0.0709
DEBUG - 2022-07-10 12:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:47:24 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:17:25 --> Total execution time: 0.0691
DEBUG - 2022-07-10 12:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:17:37 --> Total execution time: 0.0582
DEBUG - 2022-07-10 12:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:17:38 --> Total execution time: 0.1074
DEBUG - 2022-07-10 12:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:17:44 --> Total execution time: 0.0738
DEBUG - 2022-07-10 12:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:48:14 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:18:14 --> Total execution time: 0.0521
DEBUG - 2022-07-10 12:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:18:30 --> Total execution time: 0.0875
DEBUG - 2022-07-10 12:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:48:46 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:18:46 --> Total execution time: 0.0406
DEBUG - 2022-07-10 12:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:48:46 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:18:46 --> Total execution time: 0.0362
DEBUG - 2022-07-10 12:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:19:23 --> Total execution time: 0.0500
DEBUG - 2022-07-10 12:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:19:32 --> Total execution time: 0.0915
DEBUG - 2022-07-10 12:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:19:58 --> Total execution time: 0.0554
DEBUG - 2022-07-10 12:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:20:01 --> Total execution time: 0.0722
DEBUG - 2022-07-10 12:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:20:04 --> Total execution time: 0.0548
DEBUG - 2022-07-10 12:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 12:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:20:20 --> Total execution time: 0.0560
DEBUG - 2022-07-10 12:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:20:28 --> Total execution time: 0.0712
DEBUG - 2022-07-10 12:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:21:01 --> Total execution time: 0.1462
DEBUG - 2022-07-10 12:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:21:11 --> Total execution time: 0.0640
DEBUG - 2022-07-10 12:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:21:12 --> Total execution time: 0.0642
DEBUG - 2022-07-10 12:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:51:26 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:21:26 --> Total execution time: 0.0442
DEBUG - 2022-07-10 12:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:51:27 --> No URI present. Default controller set.
DEBUG - 2022-07-10 12:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:21:27 --> Total execution time: 0.0365
DEBUG - 2022-07-10 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:21:31 --> Total execution time: 0.0863
DEBUG - 2022-07-10 12:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:22:21 --> Total execution time: 0.0579
DEBUG - 2022-07-10 12:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:22:35 --> Total execution time: 0.0676
DEBUG - 2022-07-10 12:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:22:52 --> Total execution time: 0.0559
DEBUG - 2022-07-10 12:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:22:54 --> Total execution time: 0.0536
DEBUG - 2022-07-10 12:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:24:19 --> Total execution time: 0.1445
DEBUG - 2022-07-10 12:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:27:31 --> Total execution time: 0.2222
DEBUG - 2022-07-10 12:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:27:45 --> Total execution time: 0.0857
DEBUG - 2022-07-10 12:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:28:01 --> Total execution time: 0.0703
DEBUG - 2022-07-10 12:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:28:01 --> Total execution time: 0.0602
DEBUG - 2022-07-10 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:28:24 --> Total execution time: 0.0560
DEBUG - 2022-07-10 12:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:28:30 --> Total execution time: 0.0582
DEBUG - 2022-07-10 12:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:28:38 --> Total execution time: 0.0548
DEBUG - 2022-07-10 12:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:28:42 --> Total execution time: 0.1001
DEBUG - 2022-07-10 12:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:29:05 --> Total execution time: 0.0831
DEBUG - 2022-07-10 12:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:29:14 --> Total execution time: 0.0599
DEBUG - 2022-07-10 12:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:29:26 --> Total execution time: 0.0565
DEBUG - 2022-07-10 12:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:29:29 --> Total execution time: 0.0552
DEBUG - 2022-07-10 12:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:29:31 --> Total execution time: 0.0597
DEBUG - 2022-07-10 12:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:29:38 --> Total execution time: 0.0725
DEBUG - 2022-07-10 12:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 12:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 12:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:29:43 --> Total execution time: 0.0566
DEBUG - 2022-07-10 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:30:02 --> Total execution time: 0.0542
DEBUG - 2022-07-10 13:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:33:13 --> Total execution time: 0.2411
DEBUG - 2022-07-10 13:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:33:18 --> Total execution time: 0.0546
DEBUG - 2022-07-10 13:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:33:21 --> Total execution time: 0.0586
DEBUG - 2022-07-10 13:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:34:27 --> Total execution time: 0.0374
DEBUG - 2022-07-10 13:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:40:12 --> Total execution time: 0.1063
DEBUG - 2022-07-10 13:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:41:12 --> Total execution time: 0.1447
DEBUG - 2022-07-10 13:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:41:23 --> Total execution time: 0.0774
DEBUG - 2022-07-10 13:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:41:31 --> Total execution time: 0.0547
DEBUG - 2022-07-10 13:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:41:36 --> Total execution time: 0.0578
DEBUG - 2022-07-10 13:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:11:39 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:41:39 --> Total execution time: 0.0557
DEBUG - 2022-07-10 13:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:12:31 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:42:31 --> Total execution time: 0.0397
DEBUG - 2022-07-10 13:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:14:37 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:44:37 --> Total execution time: 0.0890
DEBUG - 2022-07-10 13:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:15:31 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:45:31 --> Total execution time: 0.0597
DEBUG - 2022-07-10 13:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:15:38 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:45:38 --> Total execution time: 0.0728
DEBUG - 2022-07-10 13:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:45:58 --> Total execution time: 1.9034
DEBUG - 2022-07-10 13:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:16:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 13:16:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 13:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:16:58 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:46:58 --> Total execution time: 0.1264
DEBUG - 2022-07-10 13:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:17:16 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:47:16 --> Total execution time: 0.0592
DEBUG - 2022-07-10 13:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:47:27 --> Total execution time: 0.0465
DEBUG - 2022-07-10 13:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:48:17 --> Total execution time: 0.0450
DEBUG - 2022-07-10 13:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:18:23 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:48:23 --> Total execution time: 0.0476
DEBUG - 2022-07-10 13:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:48:28 --> Total execution time: 0.0494
DEBUG - 2022-07-10 13:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:49:13 --> Total execution time: 0.0757
DEBUG - 2022-07-10 13:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:49:27 --> Total execution time: 0.0626
DEBUG - 2022-07-10 13:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:49:27 --> Total execution time: 0.0556
DEBUG - 2022-07-10 13:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:49:36 --> Total execution time: 0.0646
DEBUG - 2022-07-10 13:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:49:55 --> Total execution time: 0.0764
DEBUG - 2022-07-10 13:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:49:58 --> Total execution time: 0.0573
DEBUG - 2022-07-10 13:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:50:02 --> Total execution time: 0.0821
DEBUG - 2022-07-10 13:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:20:04 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:50:04 --> Total execution time: 0.0530
DEBUG - 2022-07-10 13:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:20:16 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:50:16 --> Total execution time: 0.0549
DEBUG - 2022-07-10 13:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:50:22 --> Total execution time: 0.0500
DEBUG - 2022-07-10 13:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:50:27 --> Total execution time: 0.0510
DEBUG - 2022-07-10 13:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:20:35 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:50:35 --> Total execution time: 0.0700
DEBUG - 2022-07-10 13:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:50:40 --> Total execution time: 0.0533
DEBUG - 2022-07-10 13:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:20:42 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:50:42 --> Total execution time: 0.0543
DEBUG - 2022-07-10 13:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:27:39 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:57:40 --> Total execution time: 0.2001
DEBUG - 2022-07-10 13:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:35:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:38:56 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:44:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 13:44:06 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-10 13:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 13:46:59 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 13:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 13:49:19 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-10 13:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:54:36 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:58:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 13:58:19 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-10 13:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:58:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 13:58:19 --> 404 Page Not Found: Become-an-affiliate/index
DEBUG - 2022-07-10 13:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:58:40 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:58:41 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 13:59:48 --> No URI present. Default controller set.
DEBUG - 2022-07-10 13:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 13:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:00:05 --> Total execution time: 0.0975
DEBUG - 2022-07-10 14:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:01:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 14:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:09:44 --> Total execution time: 0.4418
DEBUG - 2022-07-10 14:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:09:50 --> Total execution time: 0.1111
DEBUG - 2022-07-10 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:15:09 --> No URI present. Default controller set.
DEBUG - 2022-07-10 14:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:15:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 14:15:36 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-10 14:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:15:52 --> No URI present. Default controller set.
DEBUG - 2022-07-10 14:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:17:10 --> Total execution time: 0.0515
DEBUG - 2022-07-10 14:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:17:11 --> Total execution time: 0.0534
DEBUG - 2022-07-10 14:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:17:12 --> Total execution time: 0.0518
DEBUG - 2022-07-10 14:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:18:42 --> No URI present. Default controller set.
DEBUG - 2022-07-10 14:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:18:50 --> No URI present. Default controller set.
DEBUG - 2022-07-10 14:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:20:55 --> No URI present. Default controller set.
DEBUG - 2022-07-10 14:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:28:27 --> No URI present. Default controller set.
DEBUG - 2022-07-10 14:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:28:30 --> No URI present. Default controller set.
DEBUG - 2022-07-10 14:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 14:55:40 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-10 14:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:55:40 --> No URI present. Default controller set.
DEBUG - 2022-07-10 14:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 14:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 14:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 14:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 15:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:02:43 --> Total execution time: 0.1007
DEBUG - 2022-07-10 15:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 15:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 15:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:28:20 --> Total execution time: 0.0885
DEBUG - 2022-07-10 15:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 15:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 15:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:28:25 --> Total execution time: 0.1039
DEBUG - 2022-07-10 15:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:28:25 --> Total execution time: 0.1507
DEBUG - 2022-07-10 15:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:32:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 15:32:39 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-10 15:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:35:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 15:35:29 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 15:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:36:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 15:36:33 --> 404 Page Not Found: Learning-friendship-and-fun-for-everyone/index
DEBUG - 2022-07-10 15:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:37:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 15:37:52 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-10 15:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:54:00 --> No URI present. Default controller set.
DEBUG - 2022-07-10 15:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 15:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 15:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 15:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:54:02 --> Total execution time: 0.0644
DEBUG - 2022-07-10 15:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 15:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:54:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 15:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 15:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:54:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 15:54:07 --> 404 Page Not Found: Package-buy/index
DEBUG - 2022-07-10 15:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 15:54:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 15:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 15:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 16:03:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 16:03:57 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-10 16:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 16:10:27 --> No URI present. Default controller set.
DEBUG - 2022-07-10 16:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 16:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 16:32:28 --> No URI present. Default controller set.
DEBUG - 2022-07-10 16:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 16:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 16:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 16:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 16:37:22 --> No URI present. Default controller set.
DEBUG - 2022-07-10 16:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 16:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 16:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 16:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 16:38:50 --> No URI present. Default controller set.
DEBUG - 2022-07-10 16:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 16:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 16:42:18 --> No URI present. Default controller set.
DEBUG - 2022-07-10 16:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 16:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 16:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 16:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 16:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 16:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 16:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:00:29 --> No URI present. Default controller set.
DEBUG - 2022-07-10 17:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 17:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 17:22:33 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-10 17:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:25:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 17:25:32 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 17:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:28:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 17:28:05 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-10 17:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:33:32 --> No URI present. Default controller set.
DEBUG - 2022-07-10 17:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 17:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 17:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 17:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 17:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 17:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 17:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 17:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 17:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 17:46:59 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-10 17:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 17:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 17:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 17:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 17:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 17:55:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 17:55:13 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-10 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 18:07:37 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-10 18:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:07:37 --> No URI present. Default controller set.
DEBUG - 2022-07-10 18:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:33:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 18:33:16 --> 404 Page Not Found: Awscredentials/index
DEBUG - 2022-07-10 18:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:39:29 --> No URI present. Default controller set.
DEBUG - 2022-07-10 18:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:53:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 18:53:58 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-10 18:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:57:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 18:57:08 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-10 18:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 18:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 18:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 18:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:13:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 19:13:12 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-10 19:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:15:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 19:15:57 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 19:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:43:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 19:43:54 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-10 19:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:48:00 --> No URI present. Default controller set.
DEBUG - 2022-07-10 19:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:48:34 --> No URI present. Default controller set.
DEBUG - 2022-07-10 19:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:48:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 19:48:35 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-10 19:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:53:28 --> No URI present. Default controller set.
DEBUG - 2022-07-10 19:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 19:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:56:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 19:56:01 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-10 19:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 19:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 19:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:02:42 --> No URI present. Default controller set.
DEBUG - 2022-07-10 20:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:03:18 --> No URI present. Default controller set.
DEBUG - 2022-07-10 20:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:03:56 --> No URI present. Default controller set.
DEBUG - 2022-07-10 20:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:06:35 --> Total execution time: 0.0636
DEBUG - 2022-07-10 20:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:06:42 --> Total execution time: 0.1129
DEBUG - 2022-07-10 20:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:11:48 --> Total execution time: 0.0472
DEBUG - 2022-07-10 20:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:11:51 --> Total execution time: 0.0573
DEBUG - 2022-07-10 20:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:11:52 --> Total execution time: 0.0571
DEBUG - 2022-07-10 20:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:17 --> Total execution time: 0.0553
DEBUG - 2022-07-10 20:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:27 --> Total execution time: 0.0588
DEBUG - 2022-07-10 20:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:30 --> Total execution time: 0.0531
DEBUG - 2022-07-10 20:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:44 --> No URI present. Default controller set.
DEBUG - 2022-07-10 20:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:44 --> No URI present. Default controller set.
DEBUG - 2022-07-10 20:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:13:16 --> No URI present. Default controller set.
DEBUG - 2022-07-10 20:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:13:18 --> No URI present. Default controller set.
DEBUG - 2022-07-10 20:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:19:14 --> No URI present. Default controller set.
DEBUG - 2022-07-10 20:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:19:32 --> No URI present. Default controller set.
DEBUG - 2022-07-10 20:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:27:57 --> No URI present. Default controller set.
DEBUG - 2022-07-10 20:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:28:20 --> No URI present. Default controller set.
DEBUG - 2022-07-10 20:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:33:38 --> No URI present. Default controller set.
DEBUG - 2022-07-10 20:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:39:48 --> No URI present. Default controller set.
DEBUG - 2022-07-10 20:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:42:42 --> Total execution time: 0.0385
DEBUG - 2022-07-10 20:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:42:44 --> Total execution time: 0.0776
DEBUG - 2022-07-10 20:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:42:44 --> Total execution time: 0.1699
DEBUG - 2022-07-10 20:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:44:06 --> Total execution time: 0.0503
DEBUG - 2022-07-10 20:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 20:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:44:07 --> Total execution time: 0.0548
DEBUG - 2022-07-10 20:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 20:44:07 --> Total execution time: 0.0872
DEBUG - 2022-07-10 20:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 20:58:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 20:58:14 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-10 21:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:00:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 21:00:58 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 21:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 21:03:21 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-10 21:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:07:16 --> No URI present. Default controller set.
DEBUG - 2022-07-10 21:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:08:35 --> Total execution time: 0.0539
DEBUG - 2022-07-10 21:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:08:49 --> Total execution time: 0.0643
DEBUG - 2022-07-10 21:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:08:53 --> Total execution time: 0.0629
DEBUG - 2022-07-10 21:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:11:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 21:11:40 --> 404 Page Not Found: Wp-blockdownphp/index
DEBUG - 2022-07-10 21:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:15:26 --> No URI present. Default controller set.
DEBUG - 2022-07-10 21:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:15:32 --> Total execution time: 0.0542
DEBUG - 2022-07-10 21:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:15:35 --> Total execution time: 0.0519
DEBUG - 2022-07-10 21:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:15:35 --> Total execution time: 0.1065
DEBUG - 2022-07-10 21:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:16:25 --> No URI present. Default controller set.
DEBUG - 2022-07-10 21:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 21:20:01 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-10 21:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 21:20:21 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-10 21:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:22:42 --> No URI present. Default controller set.
DEBUG - 2022-07-10 21:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:27:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 21:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:27:23 --> No URI present. Default controller set.
DEBUG - 2022-07-10 21:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:28:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 21:28:20 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-10 21:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:34:41 --> No URI present. Default controller set.
DEBUG - 2022-07-10 21:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:52:05 --> No URI present. Default controller set.
DEBUG - 2022-07-10 21:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:53:58 --> No URI present. Default controller set.
DEBUG - 2022-07-10 21:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:56:52 --> No URI present. Default controller set.
DEBUG - 2022-07-10 21:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 21:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 21:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 21:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:00:14 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:04:13 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:33 --> Total execution time: 0.0768
DEBUG - 2022-07-10 22:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:34 --> Total execution time: 0.1275
DEBUG - 2022-07-10 22:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:34 --> Total execution time: 0.1829
DEBUG - 2022-07-10 22:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:54 --> Total execution time: 0.0540
DEBUG - 2022-07-10 22:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:55 --> Total execution time: 0.0551
DEBUG - 2022-07-10 22:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:55 --> Total execution time: 0.1149
DEBUG - 2022-07-10 22:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:56 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:23:23 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:25:00 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:26:01 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:26:02 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:26:57 --> Total execution time: 0.0384
DEBUG - 2022-07-10 22:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:27:05 --> Total execution time: 0.0503
DEBUG - 2022-07-10 22:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:27:08 --> Total execution time: 0.0529
DEBUG - 2022-07-10 22:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 22:27:11 --> 404 Page Not Found: Admin-login/index
DEBUG - 2022-07-10 22:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 22:27:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 22:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:27:15 --> Total execution time: 0.0504
DEBUG - 2022-07-10 22:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:27:21 --> Total execution time: 0.0543
DEBUG - 2022-07-10 22:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 22:27:27 --> 404 Page Not Found: Admin-login/index
DEBUG - 2022-07-10 22:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:45 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:52 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:28:34 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:28:58 --> Total execution time: 0.0618
DEBUG - 2022-07-10 22:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:00 --> Total execution time: 0.0557
DEBUG - 2022-07-10 22:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:00 --> Total execution time: 0.1043
DEBUG - 2022-07-10 22:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:14 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:46 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:53 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:29:59 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:31:00 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:31:57 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:32:01 --> Total execution time: 0.0692
DEBUG - 2022-07-10 22:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:32:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:32:09 --> Total execution time: 0.0646
DEBUG - 2022-07-10 22:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:32:09 --> Total execution time: 0.0676
DEBUG - 2022-07-10 22:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:32:33 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:34:12 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:34:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 22:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:34:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 22:34:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 22:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:38:15 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:39:15 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:39:26 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:40:23 --> Total execution time: 0.0512
DEBUG - 2022-07-10 22:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:40:27 --> Total execution time: 0.0489
DEBUG - 2022-07-10 22:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:40:27 --> Total execution time: 0.0514
DEBUG - 2022-07-10 22:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:41:25 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-10 22:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:41:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 22:41:31 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-10 22:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:43:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 22:43:15 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-10 22:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:46:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 22:46:04 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-10 22:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:46:06 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:46:13 --> Total execution time: 0.0624
DEBUG - 2022-07-10 22:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:46:15 --> Total execution time: 0.0609
DEBUG - 2022-07-10 22:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:46:16 --> Total execution time: 0.1045
DEBUG - 2022-07-10 22:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:46:25 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:48:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 22:48:18 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-10 22:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:49:58 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:50:14 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:51:26 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:51:31 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:51:32 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:49 --> Total execution time: 0.0530
DEBUG - 2022-07-10 22:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:51 --> Total execution time: 0.0551
DEBUG - 2022-07-10 22:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:51 --> Total execution time: 0.1214
DEBUG - 2022-07-10 22:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:51:54 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:54:38 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:54:39 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:48 --> Total execution time: 0.0720
DEBUG - 2022-07-10 22:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:50 --> Total execution time: 0.0578
DEBUG - 2022-07-10 22:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:54:50 --> Total execution time: 0.1551
DEBUG - 2022-07-10 22:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:56:03 --> No URI present. Default controller set.
DEBUG - 2022-07-10 22:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 22:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 22:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 22:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:00:08 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:00:10 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:05:55 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:05:56 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:09:15 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:09:19 --> Total execution time: 0.0533
DEBUG - 2022-07-10 23:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:09:20 --> Total execution time: 0.0930
DEBUG - 2022-07-10 23:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:09:20 --> Total execution time: 0.1711
DEBUG - 2022-07-10 23:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:09:40 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:13:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-10 23:13:33 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-10 23:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:20:23 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:20:57 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:29:29 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:29:32 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:35:07 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:35:15 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:38:16 --> Total execution time: 0.0679
DEBUG - 2022-07-10 23:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:39:23 --> Total execution time: 0.1058
DEBUG - 2022-07-10 23:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:40:09 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:46:30 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:46:53 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:46:57 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:47:09 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:50:30 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:50:31 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:18 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:52:39 --> Total execution time: 0.0472
DEBUG - 2022-07-10 23:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:53:16 --> Total execution time: 0.0560
DEBUG - 2022-07-10 23:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:55:21 --> No URI present. Default controller set.
DEBUG - 2022-07-10 23:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-10 23:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-10 23:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-10 23:59:22 --> Encryption: Auto-configured driver 'openssl'.
