<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-22 04:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 04:22:30 --> Total execution time: 0.7280
DEBUG - 2022-12-22 04:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 04:22:30 --> Total execution time: 0.0482
DEBUG - 2022-12-22 04:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 04:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 08:52:33 --> Total execution time: 0.1308
DEBUG - 2022-12-22 04:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:22:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 08:53:18 --> Total execution time: 0.0847
DEBUG - 2022-12-22 04:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:23:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:23:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 08:53:52 --> Total execution time: 0.0783
DEBUG - 2022-12-22 04:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:23:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:23:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 08:53:54 --> Total execution time: 0.0521
DEBUG - 2022-12-22 04:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:23:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:23:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 08:55:23 --> Total execution time: 0.0873
DEBUG - 2022-12-22 04:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:25:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:25:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 08:55:25 --> Total execution time: 0.0412
DEBUG - 2022-12-22 04:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 08:55:26 --> Total execution time: 0.0419
DEBUG - 2022-12-22 04:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:25:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 08:58:34 --> Total execution time: 0.0679
DEBUG - 2022-12-22 04:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:28:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:29:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:29:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:29:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:29:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:29:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:29:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:29:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 04:29:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:01:21 --> Total execution time: 0.0425
DEBUG - 2022-12-22 04:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:31:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:31:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:31:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:31:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:31:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:31:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:31:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:31:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:31:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:01:30 --> Total execution time: 0.0417
DEBUG - 2022-12-22 04:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:31:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:31:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:02:50 --> Total execution time: 0.0652
DEBUG - 2022-12-22 04:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:32:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:05:09 --> Total execution time: 0.0716
DEBUG - 2022-12-22 04:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:35:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:35:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:05:23 --> Total execution time: 0.0715
DEBUG - 2022-12-22 04:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:35:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:35:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:06:19 --> Total execution time: 0.0648
DEBUG - 2022-12-22 04:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:36:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:06:33 --> Total execution time: 0.0869
DEBUG - 2022-12-22 04:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:36:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:36:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:07:14 --> Total execution time: 0.0616
DEBUG - 2022-12-22 04:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:37:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:37:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:08:08 --> Total execution time: 0.0697
DEBUG - 2022-12-22 04:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:38:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:38:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:08:17 --> Total execution time: 0.0380
DEBUG - 2022-12-22 04:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:38:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:38:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:08:21 --> Total execution time: 0.0624
DEBUG - 2022-12-22 04:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:38:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:08:24 --> Total execution time: 0.0826
DEBUG - 2022-12-22 04:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:38:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:38:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:08:31 --> Total execution time: 0.0546
DEBUG - 2022-12-22 04:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:38:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:12:23 --> Total execution time: 0.0559
DEBUG - 2022-12-22 04:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:42:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:42:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:18:14 --> Total execution time: 0.0491
DEBUG - 2022-12-22 04:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:48:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:48:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:18:27 --> Total execution time: 0.0390
DEBUG - 2022-12-22 04:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:48:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:48:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:19:20 --> Total execution time: 0.0520
DEBUG - 2022-12-22 04:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:49:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:49:23 --> UTF-8 Support Enabled
ERROR - 2022-12-22 04:49:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:49:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:49:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:49:23 --> UTF-8 Support Enabled
ERROR - 2022-12-22 04:49:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:49:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:49:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:49:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:49:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:49:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:49:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:49:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:21:11 --> Total execution time: 0.0404
DEBUG - 2022-12-22 04:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:51:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:51:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:51:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:51:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:51:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 04:51:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:51:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 04:51:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:51:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:53:24 --> UTF-8 Support Enabled
ERROR - 2022-12-22 04:53:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:53:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:53:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:53:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:53:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 04:53:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:53:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:53:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 04:53:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:53:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:53:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 04:53:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:26:11 --> Total execution time: 0.0597
DEBUG - 2022-12-22 04:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:56:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:56:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:56:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 04:56:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:56:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:56:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:56:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:56:14 --> UTF-8 Support Enabled
ERROR - 2022-12-22 04:56:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:56:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 04:56:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:27:44 --> Total execution time: 0.0489
DEBUG - 2022-12-22 04:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:57:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 04:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:57:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:57:44 --> UTF-8 Support Enabled
ERROR - 2022-12-22 04:57:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:57:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:57:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:57:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 04:57:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:57:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:57:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:57:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:57:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:57:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:57:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 04:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 04:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 04:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:29:55 --> Total execution time: 0.0829
DEBUG - 2022-12-22 04:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 04:59:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 04:59:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:30:09 --> Total execution time: 0.0482
DEBUG - 2022-12-22 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:00:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:00:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:30:22 --> Total execution time: 0.0759
DEBUG - 2022-12-22 05:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:00:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:00:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:30:33 --> Total execution time: 0.0625
DEBUG - 2022-12-22 05:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:00:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:00:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:31:13 --> Total execution time: 0.0634
DEBUG - 2022-12-22 05:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:01:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:31:32 --> Total execution time: 0.0627
DEBUG - 2022-12-22 05:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:01:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:01:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:32:21 --> Total execution time: 0.0693
DEBUG - 2022-12-22 05:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:02:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:32:33 --> Total execution time: 0.0720
DEBUG - 2022-12-22 05:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:02:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:02:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:02:36 --> UTF-8 Support Enabled
ERROR - 2022-12-22 05:02:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:02:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:02:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:02:36 --> UTF-8 Support Enabled
ERROR - 2022-12-22 05:02:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:02:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:02:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:02:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:02:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:02:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:02:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:32:48 --> Total execution time: 0.0489
DEBUG - 2022-12-22 05:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:02:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:02:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:02:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:02:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:02:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:02:49 --> UTF-8 Support Enabled
ERROR - 2022-12-22 05:02:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:02:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:02:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:02:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:02:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:33:10 --> Total execution time: 0.0547
DEBUG - 2022-12-22 05:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:03:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:03:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:03:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:33:33 --> Total execution time: 0.0624
DEBUG - 2022-12-22 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:03:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:03:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:03:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:34:30 --> Total execution time: 0.0670
DEBUG - 2022-12-22 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:31 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-22 05:04:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:04:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:34:59 --> Total execution time: 0.0711
DEBUG - 2022-12-22 05:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:04:59 --> UTF-8 Support Enabled
ERROR - 2022-12-22 05:04:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:04:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:04:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:04:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:35:30 --> Total execution time: 0.0483
DEBUG - 2022-12-22 05:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:05:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:05:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:05:30 --> UTF-8 Support Enabled
ERROR - 2022-12-22 05:05:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:05:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:05:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:05:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:05:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:05:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:05:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:05:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:05:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:05:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:05:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:05:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:05:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:05:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:37:01 --> Total execution time: 0.0732
DEBUG - 2022-12-22 05:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:07:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:07:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:07:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:07:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:07:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:07:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:07:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:07:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:07:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:07:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:40:13 --> Total execution time: 0.0408
DEBUG - 2022-12-22 05:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:10:14 --> UTF-8 Support Enabled
ERROR - 2022-12-22 05:10:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:10:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 05:10:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:40:36 --> Total execution time: 0.0715
DEBUG - 2022-12-22 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:36 --> UTF-8 Support Enabled
ERROR - 2022-12-22 05:10:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:10:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 05:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:43:30 --> Total execution time: 0.0520
DEBUG - 2022-12-22 05:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:13:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:13:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:44:07 --> Total execution time: 0.0913
DEBUG - 2022-12-22 05:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:14:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:46:08 --> Total execution time: 0.0729
DEBUG - 2022-12-22 05:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:16:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:46:16 --> Total execution time: 0.0646
DEBUG - 2022-12-22 05:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:16:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:16:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:47:48 --> Total execution time: 0.0955
DEBUG - 2022-12-22 05:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:17:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:48:23 --> Total execution time: 0.0590
DEBUG - 2022-12-22 05:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:18:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:18:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:48:23 --> Total execution time: 0.0532
DEBUG - 2022-12-22 05:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:48:31 --> Total execution time: 0.0658
DEBUG - 2022-12-22 05:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:18:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:48:31 --> Total execution time: 0.0568
DEBUG - 2022-12-22 05:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:49:23 --> Total execution time: 0.0629
DEBUG - 2022-12-22 05:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:19:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:19:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:49:23 --> Total execution time: 0.0572
DEBUG - 2022-12-22 05:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:49:40 --> Total execution time: 0.0469
DEBUG - 2022-12-22 05:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:19:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:19:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:49:40 --> Total execution time: 0.0521
DEBUG - 2022-12-22 05:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:49:44 --> Total execution time: 0.0712
DEBUG - 2022-12-22 05:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:19:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 05:19:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 05:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 05:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 05:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 05:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 09:49:44 --> Total execution time: 0.0609
DEBUG - 2022-12-22 06:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:42:36 --> Total execution time: 0.0678
DEBUG - 2022-12-22 06:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:12:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:12:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:42:36 --> Total execution time: 0.0523
DEBUG - 2022-12-22 06:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:42:59 --> Total execution time: 0.0418
DEBUG - 2022-12-22 06:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:13:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:13:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:43:00 --> Total execution time: 0.0654
DEBUG - 2022-12-22 06:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:44:57 --> Total execution time: 0.0480
DEBUG - 2022-12-22 06:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:14:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:44:58 --> Total execution time: 0.0592
DEBUG - 2022-12-22 06:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:46:03 --> Total execution time: 0.0426
DEBUG - 2022-12-22 06:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:16:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:16:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:46:03 --> Total execution time: 0.0648
DEBUG - 2022-12-22 06:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:46:21 --> Total execution time: 0.0413
DEBUG - 2022-12-22 06:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:16:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:46:21 --> Total execution time: 0.0557
DEBUG - 2022-12-22 06:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:46:47 --> Total execution time: 0.0651
DEBUG - 2022-12-22 06:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:16:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:16:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:46:47 --> Total execution time: 0.0472
DEBUG - 2022-12-22 06:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:47:03 --> Total execution time: 0.0397
DEBUG - 2022-12-22 06:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:17:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:17:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:47:03 --> Total execution time: 0.0498
DEBUG - 2022-12-22 06:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:47:18 --> Total execution time: 0.0646
DEBUG - 2022-12-22 06:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:17:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:17:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:47:18 --> Total execution time: 0.0459
DEBUG - 2022-12-22 06:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:47:35 --> Total execution time: 0.0510
DEBUG - 2022-12-22 06:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:17:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:17:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:47:35 --> Total execution time: 0.0469
DEBUG - 2022-12-22 06:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:48:03 --> Total execution time: 0.0649
DEBUG - 2022-12-22 06:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:18:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:18:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:48:04 --> Total execution time: 0.0495
DEBUG - 2022-12-22 06:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:48:55 --> Total execution time: 0.0546
DEBUG - 2022-12-22 06:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:18:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:48:55 --> Total execution time: 0.0553
DEBUG - 2022-12-22 06:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:49:09 --> Total execution time: 0.0383
DEBUG - 2022-12-22 06:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:19:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:19:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:49:10 --> Total execution time: 0.0519
DEBUG - 2022-12-22 06:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:49:39 --> Total execution time: 0.0469
DEBUG - 2022-12-22 06:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:19:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:19:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:49:39 --> Total execution time: 0.0452
DEBUG - 2022-12-22 06:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:50:26 --> Total execution time: 0.0382
DEBUG - 2022-12-22 06:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:20:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:20:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:50:26 --> Total execution time: 0.0502
DEBUG - 2022-12-22 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:50:37 --> Total execution time: 0.0389
DEBUG - 2022-12-22 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:20:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:20:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:50:37 --> Total execution time: 0.0553
DEBUG - 2022-12-22 06:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:51:22 --> Total execution time: 0.0425
DEBUG - 2022-12-22 06:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:21:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:21:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:51:23 --> Total execution time: 0.0587
DEBUG - 2022-12-22 06:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:52:56 --> Total execution time: 0.0656
DEBUG - 2022-12-22 06:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:22:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:52:57 --> Total execution time: 0.0605
DEBUG - 2022-12-22 06:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:53:25 --> Total execution time: 0.0429
DEBUG - 2022-12-22 06:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:23:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:53:25 --> Total execution time: 0.0607
DEBUG - 2022-12-22 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:58:29 --> Total execution time: 0.0688
DEBUG - 2022-12-22 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:28:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:58:30 --> Total execution time: 0.0487
DEBUG - 2022-12-22 06:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:59:05 --> Total execution time: 0.0670
DEBUG - 2022-12-22 06:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:29:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 10:59:05 --> Total execution time: 0.0512
DEBUG - 2022-12-22 06:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:02:14 --> Total execution time: 0.0384
DEBUG - 2022-12-22 06:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:32:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:02:14 --> Total execution time: 0.0489
DEBUG - 2022-12-22 06:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:02:33 --> Total execution time: 0.0422
DEBUG - 2022-12-22 06:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:32:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:02:33 --> Total execution time: 0.0609
DEBUG - 2022-12-22 06:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:03:57 --> Total execution time: 0.0450
DEBUG - 2022-12-22 06:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:33:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:33:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:03:58 --> Total execution time: 0.0570
DEBUG - 2022-12-22 06:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:04:39 --> Total execution time: 0.0406
DEBUG - 2022-12-22 06:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:34:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:04:39 --> Total execution time: 0.0450
DEBUG - 2022-12-22 06:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:06:16 --> Total execution time: 0.0602
DEBUG - 2022-12-22 06:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:36:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:06:16 --> Total execution time: 0.0500
DEBUG - 2022-12-22 06:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:36:20 --> UTF-8 Support Enabled
ERROR - 2022-12-22 06:36:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:36:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:36:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:36:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:36:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:36:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 06:36:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:36:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:06:36 --> Total execution time: 0.0626
DEBUG - 2022-12-22 06:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:36:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:36:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:36:36 --> UTF-8 Support Enabled
ERROR - 2022-12-22 06:36:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:36:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:36:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:06:37 --> Total execution time: 0.0583
DEBUG - 2022-12-22 06:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:36:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:36:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 06:36:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 06:36:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:36:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:36:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:36:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:07:39 --> Total execution time: 0.0453
DEBUG - 2022-12-22 06:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:37:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:37:40 --> UTF-8 Support Enabled
ERROR - 2022-12-22 06:37:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:37:40 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 06:37:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:37:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:07:40 --> Total execution time: 0.0598
DEBUG - 2022-12-22 06:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:37:40 --> UTF-8 Support Enabled
ERROR - 2022-12-22 06:37:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:37:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:37:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:37:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:37:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 11:09:06 --> Total execution time: 0.0495
DEBUG - 2022-12-22 06:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:39:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 06:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:39:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 06:39:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:39:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:39:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 06:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 06:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:39:06 --> UTF-8 Support Enabled
ERROR - 2022-12-22 06:39:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 06:39:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:39:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:39:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:09:06 --> Total execution time: 0.1184
DEBUG - 2022-12-22 06:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:39:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:39:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:39:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:39:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:39:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:39:11 --> UTF-8 Support Enabled
ERROR - 2022-12-22 06:39:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:39:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:39:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:39:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 06:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 06:39:11 --> UTF-8 Support Enabled
ERROR - 2022-12-22 06:39:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 06:39:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 06:39:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 06:39:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:44:22 --> Total execution time: 0.0506
DEBUG - 2022-12-22 08:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:14:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:44:22 --> Total execution time: 0.0451
DEBUG - 2022-12-22 08:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:44:33 --> Total execution time: 0.0610
DEBUG - 2022-12-22 08:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:14:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:14:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:44:33 --> Total execution time: 0.0660
DEBUG - 2022-12-22 08:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:44:47 --> Total execution time: 0.0706
DEBUG - 2022-12-22 08:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:14:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:14:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:44:47 --> Total execution time: 0.0520
DEBUG - 2022-12-22 08:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:46:48 --> Total execution time: 0.0685
DEBUG - 2022-12-22 08:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:16:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:16:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:46:49 --> Total execution time: 0.0460
DEBUG - 2022-12-22 08:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:47:22 --> Total execution time: 0.0402
DEBUG - 2022-12-22 08:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:17:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:47:23 --> Total execution time: 0.0483
DEBUG - 2022-12-22 08:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:47:38 --> Total execution time: 0.0911
DEBUG - 2022-12-22 08:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:17:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:17:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:47:38 --> Total execution time: 0.0702
DEBUG - 2022-12-22 08:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:48:13 --> Total execution time: 0.0790
DEBUG - 2022-12-22 08:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:18:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:18:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:48:13 --> Total execution time: 0.0479
DEBUG - 2022-12-22 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:18:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:18:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:18:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:18:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:18:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:18:20 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:18:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:18:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:18:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:19:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:19:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:19:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:19:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:19:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:19:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:19:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:19:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:51:45 --> Total execution time: 0.0645
DEBUG - 2022-12-22 08:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:21:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:21:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:51:45 --> Total execution time: 0.0501
DEBUG - 2022-12-22 08:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:51:59 --> Total execution time: 0.1041
DEBUG - 2022-12-22 08:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:21:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:51:59 --> Total execution time: 0.0523
DEBUG - 2022-12-22 08:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:52:26 --> Total execution time: 0.0411
DEBUG - 2022-12-22 08:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:22:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:22:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:52:26 --> Total execution time: 0.0464
DEBUG - 2022-12-22 08:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:22:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:22:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:22:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:22:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:22:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:22:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:22:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:22:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:22:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:22:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:22:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:22:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:22:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:22:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:53:23 --> Total execution time: 0.0612
DEBUG - 2022-12-22 08:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:23:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:23:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:53:23 --> Total execution time: 0.0470
DEBUG - 2022-12-22 08:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:23:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:23:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:23:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:23:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:23:31 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:23:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:23:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:23:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:23:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:23:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:23:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:23:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:23:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:23:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:23:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:23:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:54:18 --> Total execution time: 0.0503
DEBUG - 2022-12-22 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:24:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:54:19 --> Total execution time: 0.0468
DEBUG - 2022-12-22 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:54:49 --> Total execution time: 0.0569
DEBUG - 2022-12-22 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:24:50 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:24:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:24:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:24:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:24:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:24:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:54:50 --> Total execution time: 0.0762
DEBUG - 2022-12-22 08:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:55:09 --> Total execution time: 0.0556
DEBUG - 2022-12-22 08:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:25:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:25:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:25:09 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:25:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:25:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:25:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:25:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:25:09 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:25:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:25:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:25:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:25:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:25:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:25:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:25:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:55:09 --> Total execution time: 0.0637
DEBUG - 2022-12-22 08:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:25:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:25:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:25:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:25:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:25:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:25:34 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:25:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:25:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:25:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:25:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:25:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:26:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:26:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:26:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:26:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:26:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:26:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:26:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:26:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:57:00 --> Total execution time: 0.0396
DEBUG - 2022-12-22 08:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:00 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:27:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:27:00 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:27:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:27:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:27:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:57:00 --> Total execution time: 0.0424
DEBUG - 2022-12-22 08:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:57:41 --> Total execution time: 0.0475
DEBUG - 2022-12-22 08:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:27:42 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:27:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:57:42 --> Total execution time: 0.0496
DEBUG - 2022-12-22 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:57:55 --> Total execution time: 0.0563
DEBUG - 2022-12-22 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:27:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:57:56 --> Total execution time: 0.0974
DEBUG - 2022-12-22 08:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:29:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:29:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:29:24 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:29:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:29:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:29:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:29:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:29:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:29:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:59:58 --> Total execution time: 0.0584
DEBUG - 2022-12-22 08:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:29:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:29:58 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:29:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:29:58 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:29:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:29:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:29:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:29:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:29:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:29:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:29:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 12:59:59 --> Total execution time: 0.0453
DEBUG - 2022-12-22 08:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:00:20 --> Total execution time: 0.0529
DEBUG - 2022-12-22 08:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:30:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:30:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:30:20 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:30:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:30:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:30:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:30:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:30:20 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:30:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:00:21 --> Total execution time: 0.0658
DEBUG - 2022-12-22 08:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:00:47 --> Total execution time: 0.0516
DEBUG - 2022-12-22 08:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:30:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:00:48 --> Total execution time: 0.0548
DEBUG - 2022-12-22 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:00:54 --> Total execution time: 0.1149
DEBUG - 2022-12-22 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:30:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:30:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:30:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:00:55 --> Total execution time: 0.0671
DEBUG - 2022-12-22 08:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:01:06 --> Total execution time: 0.0511
DEBUG - 2022-12-22 08:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:07 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:31:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:31:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:31:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:07 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:31:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:01:07 --> Total execution time: 0.0446
DEBUG - 2022-12-22 08:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:01:14 --> Total execution time: 0.0421
DEBUG - 2022-12-22 08:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:31:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:15 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:31:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:01:15 --> Total execution time: 0.0545
DEBUG - 2022-12-22 08:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:01:19 --> Total execution time: 0.0709
DEBUG - 2022-12-22 08:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:31:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:20 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:31:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:31:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:20 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:31:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:01:20 --> Total execution time: 0.0525
DEBUG - 2022-12-22 08:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:01:55 --> Total execution time: 0.0767
DEBUG - 2022-12-22 08:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:56 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:31:56 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:31:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:31:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:01:56 --> Total execution time: 0.0481
DEBUG - 2022-12-22 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:03:06 --> Total execution time: 0.0502
DEBUG - 2022-12-22 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:33:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:03:07 --> Total execution time: 0.0697
DEBUG - 2022-12-22 08:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:03:26 --> Total execution time: 0.0874
DEBUG - 2022-12-22 08:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:33:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:03:27 --> Total execution time: 0.0467
DEBUG - 2022-12-22 08:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:03:35 --> Total execution time: 0.0663
DEBUG - 2022-12-22 08:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:36 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:33:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:33:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:03:36 --> Total execution time: 0.0474
DEBUG - 2022-12-22 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:03:40 --> Total execution time: 0.0392
DEBUG - 2022-12-22 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:40 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:33:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:40 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:33:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:40 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:33:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:03:41 --> Total execution time: 0.0615
DEBUG - 2022-12-22 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:03:45 --> Total execution time: 0.0503
DEBUG - 2022-12-22 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:33:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:33:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:45 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:33:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:03:45 --> Total execution time: 0.0478
DEBUG - 2022-12-22 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:03:57 --> Total execution time: 0.0691
DEBUG - 2022-12-22 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:33:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:33:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:33:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:33:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:03:57 --> Total execution time: 0.0438
DEBUG - 2022-12-22 08:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:34:05 --> 404 Page Not Found: Admin/campaign/Campaign_Controller/add_store
DEBUG - 2022-12-22 08:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:04:06 --> Total execution time: 0.0462
DEBUG - 2022-12-22 08:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:34:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:34:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:34:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:34:06 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:34:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:34:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:34:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:34:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:34:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:04:07 --> Total execution time: 0.0478
DEBUG - 2022-12-22 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:04:29 --> Total execution time: 0.0561
DEBUG - 2022-12-22 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:34:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:34:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:34:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:34:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:34:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:34:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:34:29 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:34:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:34:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:34:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:04:29 --> Total execution time: 0.0446
DEBUG - 2022-12-22 08:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:05:38 --> Total execution time: 0.0507
DEBUG - 2022-12-22 08:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:35:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:05:39 --> Total execution time: 0.0455
DEBUG - 2022-12-22 08:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:06:42 --> Total execution time: 0.0741
DEBUG - 2022-12-22 08:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:36:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:06:42 --> Total execution time: 0.0481
DEBUG - 2022-12-22 08:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:06:50 --> Total execution time: 0.0635
DEBUG - 2022-12-22 08:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:36:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:06:51 --> Total execution time: 0.0477
DEBUG - 2022-12-22 08:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:07:07 --> Total execution time: 0.0611
DEBUG - 2022-12-22 08:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:37:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:07:07 --> Total execution time: 0.0445
DEBUG - 2022-12-22 08:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:07:17 --> Total execution time: 0.0772
DEBUG - 2022-12-22 08:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:37:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:37:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:07:17 --> Total execution time: 0.0513
DEBUG - 2022-12-22 08:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:07:25 --> Total execution time: 0.0755
DEBUG - 2022-12-22 08:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:37:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:07:25 --> Total execution time: 0.0493
DEBUG - 2022-12-22 08:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:07:31 --> Total execution time: 0.0537
DEBUG - 2022-12-22 08:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:37:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:07:31 --> Total execution time: 0.0477
DEBUG - 2022-12-22 08:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:07:45 --> Total execution time: 0.0400
DEBUG - 2022-12-22 08:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:37:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:37:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:07:45 --> Total execution time: 0.0516
DEBUG - 2022-12-22 08:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:07:56 --> Total execution time: 0.0660
DEBUG - 2022-12-22 08:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:37:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:07:56 --> Total execution time: 0.0533
DEBUG - 2022-12-22 08:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:08:05 --> Total execution time: 0.0697
DEBUG - 2022-12-22 08:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:38:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:08:05 --> Total execution time: 0.0505
DEBUG - 2022-12-22 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:08:25 --> Total execution time: 0.0508
DEBUG - 2022-12-22 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:38:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:38:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:08:26 --> Total execution time: 0.0428
DEBUG - 2022-12-22 08:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:38:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:38:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:08:26 --> Total execution time: 0.0489
DEBUG - 2022-12-22 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:08:38 --> Total execution time: 0.0392
DEBUG - 2022-12-22 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:38:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:38:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:08:46 --> Total execution time: 0.0523
DEBUG - 2022-12-22 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:38:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:09:12 --> Total execution time: 0.0814
DEBUG - 2022-12-22 08:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:39:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:09:16 --> Total execution time: 0.0672
DEBUG - 2022-12-22 08:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:39:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:39:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:09:51 --> Total execution time: 0.0518
DEBUG - 2022-12-22 08:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:39:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:39:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:09:53 --> Total execution time: 0.0376
DEBUG - 2022-12-22 08:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:10:16 --> Total execution time: 0.0426
DEBUG - 2022-12-22 08:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:40:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:40:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:10:35 --> Total execution time: 0.0649
DEBUG - 2022-12-22 08:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:40:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:10:35 --> Total execution time: 0.0492
DEBUG - 2022-12-22 08:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:11:10 --> Total execution time: 0.0624
DEBUG - 2022-12-22 08:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:41:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:41:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:11:10 --> Total execution time: 0.0543
DEBUG - 2022-12-22 08:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:11:28 --> Total execution time: 0.0551
DEBUG - 2022-12-22 08:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:41:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:41:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:41:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:41:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:11:28 --> Total execution time: 0.0546
DEBUG - 2022-12-22 08:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:11:30 --> Total execution time: 0.0543
DEBUG - 2022-12-22 08:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:41:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:14:17 --> Total execution time: 0.0543
DEBUG - 2022-12-22 08:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:44:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:44:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:14:20 --> Total execution time: 0.0580
DEBUG - 2022-12-22 08:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:44:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:44:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:14:20 --> Total execution time: 0.0531
DEBUG - 2022-12-22 08:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:45:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:45:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:45:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:45:17 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:45:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:45:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:45:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:45:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:45:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:16:46 --> Total execution time: 0.0658
DEBUG - 2022-12-22 08:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:46:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:46:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:16:47 --> Total execution time: 0.0478
DEBUG - 2022-12-22 08:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:19:23 --> Total execution time: 0.0676
DEBUG - 2022-12-22 08:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:49:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:49:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:19:24 --> Total execution time: 0.0641
DEBUG - 2022-12-22 08:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:49:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:19:25 --> Total execution time: 0.0488
DEBUG - 2022-12-22 08:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:50:50 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:50:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:50:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:50:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:50:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:50:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:50:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:50:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:50:50 --> UTF-8 Support Enabled
ERROR - 2022-12-22 08:50:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:50:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:50:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:50:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:21:19 --> Total execution time: 0.0718
DEBUG - 2022-12-22 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:19 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:51:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:21:19 --> Total execution time: 0.0504
DEBUG - 2022-12-22 08:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:21:49 --> Total execution time: 0.0509
DEBUG - 2022-12-22 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:51:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:50 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-22 08:51:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:51:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 08:51:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:51:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:21:50 --> Total execution time: 0.0669
DEBUG - 2022-12-22 08:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:22:09 --> Total execution time: 0.0998
DEBUG - 2022-12-22 08:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:52:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:52:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:23:46 --> Total execution time: 0.0595
DEBUG - 2022-12-22 08:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:53:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:23:46 --> Total execution time: 0.0495
DEBUG - 2022-12-22 08:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:23:57 --> Total execution time: 0.0490
DEBUG - 2022-12-22 08:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:53:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:23:57 --> Total execution time: 0.0530
DEBUG - 2022-12-22 08:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:24:46 --> Total execution time: 0.0594
DEBUG - 2022-12-22 08:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:54:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:24:48 --> Total execution time: 0.0439
DEBUG - 2022-12-22 08:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:54:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:24:48 --> Total execution time: 0.0597
DEBUG - 2022-12-22 08:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:25:16 --> Total execution time: 0.0586
DEBUG - 2022-12-22 08:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:55:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:25:38 --> Total execution time: 0.0598
DEBUG - 2022-12-22 08:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:55:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:26:01 --> Total execution time: 0.0544
DEBUG - 2022-12-22 08:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:56:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:56:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:26:56 --> Total execution time: 0.0466
DEBUG - 2022-12-22 08:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:56:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:56:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 08:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 08:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 08:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:28:37 --> Total execution time: 0.0450
DEBUG - 2022-12-22 08:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 08:58:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 08:58:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:30:28 --> Total execution time: 0.0456
DEBUG - 2022-12-22 09:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:00:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:00:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:00:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:00:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:00:39 --> UTF-8 Support Enabled
ERROR - 2022-12-22 09:00:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:00:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:00:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:00:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:00:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:00:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:00:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:00:39 --> UTF-8 Support Enabled
ERROR - 2022-12-22 09:00:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:00:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:00:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:00:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:00:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:31:18 --> Total execution time: 0.0409
DEBUG - 2022-12-22 09:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:34:15 --> Total execution time: 0.0435
DEBUG - 2022-12-22 09:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:04:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:04:25 --> UTF-8 Support Enabled
ERROR - 2022-12-22 09:04:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:04:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:04:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:04:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:04:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:04:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:04:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:04:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:04:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:04:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:04:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:04:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:04:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:04:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:04:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:37:01 --> Total execution time: 0.0750
DEBUG - 2022-12-22 09:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:01 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-22 09:07:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:37:17 --> Total execution time: 0.0495
DEBUG - 2022-12-22 09:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:07:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 09:07:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:07:17 --> UTF-8 Support Enabled
ERROR - 2022-12-22 09:07:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:07:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:07:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:38:01 --> Total execution time: 0.0410
DEBUG - 2022-12-22 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:08:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:08:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:08:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:08:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:08:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:08:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:08:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:08:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:08:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:08:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 09:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:39:58 --> Total execution time: 0.0578
DEBUG - 2022-12-22 09:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:09:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:09:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:40:38 --> Total execution time: 0.0669
DEBUG - 2022-12-22 09:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:10:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:10:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:41:10 --> Total execution time: 0.0610
DEBUG - 2022-12-22 09:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:11:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:41:16 --> Total execution time: 0.0616
DEBUG - 2022-12-22 09:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:11:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:42:01 --> Total execution time: 0.0514
DEBUG - 2022-12-22 09:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:12:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:12:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:42:59 --> Total execution time: 0.0602
DEBUG - 2022-12-22 09:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:12:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:44:47 --> Total execution time: 0.0692
DEBUG - 2022-12-22 09:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:14:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:48:37 --> Total execution time: 0.0455
DEBUG - 2022-12-22 09:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:18:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 09:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:18:39 --> 404 Page Not Found: Admin/campaign/Campaign_Controller/add_store
DEBUG - 2022-12-22 09:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:48:40 --> Total execution time: 0.0592
DEBUG - 2022-12-22 09:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:18:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:18:46 --> 404 Page Not Found: Admin/campaign/Campaign_Controller/add_store
DEBUG - 2022-12-22 09:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:48:47 --> Total execution time: 0.0574
DEBUG - 2022-12-22 09:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 09:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 09:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 13:49:10 --> Total execution time: 0.0652
DEBUG - 2022-12-22 09:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 09:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 09:19:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:30:14 --> Total execution time: 0.0697
DEBUG - 2022-12-22 11:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:00:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:32:36 --> Total execution time: 0.0588
DEBUG - 2022-12-22 11:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:02:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:02:36 --> 404 Page Not Found: admin/Assets/images
ERROR - 2022-12-22 11:02:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:02:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:02:36 --> 404 Page Not Found: admin/Assets/images
DEBUG - 2022-12-22 11:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:32:57 --> Total execution time: 0.0882
DEBUG - 2022-12-22 11:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:02:57 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-22 11:02:57 --> 404 Page Not Found: admin/Assets/images
DEBUG - 2022-12-22 11:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:02:57 --> 404 Page Not Found: admin/Assets/images
DEBUG - 2022-12-22 11:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:33:28 --> Total execution time: 0.0546
DEBUG - 2022-12-22 11:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:03:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:35:27 --> Total execution time: 0.0922
DEBUG - 2022-12-22 11:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:05:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:35:56 --> Total execution time: 0.0680
DEBUG - 2022-12-22 11:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:05:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:05:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:36:11 --> Total execution time: 0.0559
DEBUG - 2022-12-22 11:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:06:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:06:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:36:39 --> Total execution time: 0.0649
DEBUG - 2022-12-22 11:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:06:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:06:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:36:56 --> Total execution time: 0.0718
DEBUG - 2022-12-22 11:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:06:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:37:04 --> Total execution time: 0.0541
DEBUG - 2022-12-22 11:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:07:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:37:29 --> Total execution time: 0.0653
DEBUG - 2022-12-22 11:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:07:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:07:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:38:07 --> Total execution time: 0.0656
DEBUG - 2022-12-22 11:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:08:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:08:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:38:32 --> Total execution time: 0.0756
DEBUG - 2022-12-22 11:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:08:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:08:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:39:11 --> Total execution time: 0.0695
DEBUG - 2022-12-22 11:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:09:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:09:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:39:18 --> Total execution time: 0.0766
DEBUG - 2022-12-22 11:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:09:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:09:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:39:27 --> Total execution time: 0.0641
DEBUG - 2022-12-22 11:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:09:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:09:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:39:31 --> Total execution time: 0.0749
DEBUG - 2022-12-22 11:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:09:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:09:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:39:37 --> Total execution time: 0.0627
DEBUG - 2022-12-22 11:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:09:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:39:41 --> Total execution time: 0.0640
DEBUG - 2022-12-22 11:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:09:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:39:47 --> Total execution time: 0.0725
DEBUG - 2022-12-22 11:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:09:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:40:34 --> Total execution time: 0.0431
DEBUG - 2022-12-22 11:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:10:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:10:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:40:52 --> Total execution time: 0.0799
DEBUG - 2022-12-22 11:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:10:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:10:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:40:57 --> Total execution time: 0.0515
DEBUG - 2022-12-22 11:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:10:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:41:07 --> Total execution time: 0.0550
DEBUG - 2022-12-22 11:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:11:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:11:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:45:22 --> Total execution time: 0.0598
DEBUG - 2022-12-22 11:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:15:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:15:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:15:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:15:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:15:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:15:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:15:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:15:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:15:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:15:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:46:13 --> Total execution time: 0.0412
DEBUG - 2022-12-22 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:50:04 --> Total execution time: 0.0542
DEBUG - 2022-12-22 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:20:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:20:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:20:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:20:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:20:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:20:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:20:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:20:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:20:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:52:27 --> Total execution time: 0.0450
DEBUG - 2022-12-22 11:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:22:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:22:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:52:46 --> Total execution time: 0.0661
DEBUG - 2022-12-22 11:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:22:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:53:12 --> Total execution time: 0.0648
DEBUG - 2022-12-22 11:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:23:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:23:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:54:02 --> Total execution time: 0.0597
DEBUG - 2022-12-22 11:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:24:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:54:48 --> Total execution time: 0.0447
DEBUG - 2022-12-22 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:24:48 --> UTF-8 Support Enabled
ERROR - 2022-12-22 11:24:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:24:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:54:58 --> Total execution time: 0.0593
DEBUG - 2022-12-22 11:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:58 --> UTF-8 Support Enabled
ERROR - 2022-12-22 11:24:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:24:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:24:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:55:07 --> Total execution time: 0.0617
DEBUG - 2022-12-22 11:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:25:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:25:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:25:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:25:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:25:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:25:07 --> UTF-8 Support Enabled
ERROR - 2022-12-22 11:25:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:25:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:25:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:25:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:56:22 --> Total execution time: 0.0558
DEBUG - 2022-12-22 11:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:26:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:26:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:26:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:26:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:26:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:26:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:26:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:26:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:26:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:26:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:26:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:26:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:26:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:57:30 --> Total execution time: 0.0464
DEBUG - 2022-12-22 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:27:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:27:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:27:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:27:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:27:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:27:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:27:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:27:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:27:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:59:03 --> Total execution time: 0.0521
DEBUG - 2022-12-22 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:29:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:29:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:29:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:29:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:29:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:29:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:29:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:29:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:29:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:59:46 --> Total execution time: 0.0434
DEBUG - 2022-12-22 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:29:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:29:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:29:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:29:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:29:46 --> UTF-8 Support Enabled
ERROR - 2022-12-22 11:29:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:29:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:29:46 --> UTF-8 Support Enabled
ERROR - 2022-12-22 11:29:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:29:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:29:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:00:08 --> Total execution time: 0.0535
DEBUG - 2022-12-22 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:00:38 --> Total execution time: 0.0765
DEBUG - 2022-12-22 11:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:30:38 --> UTF-8 Support Enabled
ERROR - 2022-12-22 11:30:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:30:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:30:38 --> UTF-8 Support Enabled
ERROR - 2022-12-22 11:30:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:30:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:30:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:01:12 --> Total execution time: 0.0788
DEBUG - 2022-12-22 11:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:31:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:31:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:01:26 --> Total execution time: 0.0444
DEBUG - 2022-12-22 11:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:31:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:31:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:01:39 --> Total execution time: 0.0671
DEBUG - 2022-12-22 11:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:31:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:31:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:01:50 --> Total execution time: 0.0552
DEBUG - 2022-12-22 11:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:31:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:01:57 --> Total execution time: 0.0665
DEBUG - 2022-12-22 11:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:31:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:31:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:32:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:32:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:32:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:32:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:32:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:32:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:32:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:32:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:32:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:32:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:32:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:02:35 --> Total execution time: 0.0488
DEBUG - 2022-12-22 11:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:32:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:32:35 --> UTF-8 Support Enabled
ERROR - 2022-12-22 11:32:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:32:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:32:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:32:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:32:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:32:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 11:32:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:32:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:32:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:32:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 11:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:03:30 --> Total execution time: 0.0650
DEBUG - 2022-12-22 11:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:33:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:33:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:03:44 --> Total execution time: 0.0490
DEBUG - 2022-12-22 11:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:33:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:33:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:04:09 --> Total execution time: 0.0900
DEBUG - 2022-12-22 11:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:34:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:34:09 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-22 11:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:04:15 --> Total execution time: 0.0502
DEBUG - 2022-12-22 11:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:34:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:34:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:34:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:34:15 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-22 11:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:04:19 --> Total execution time: 0.0439
DEBUG - 2022-12-22 11:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:34:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:04:24 --> Total execution time: 0.0629
DEBUG - 2022-12-22 11:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:34:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:34:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:04:24 --> Total execution time: 0.0466
DEBUG - 2022-12-22 11:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:06:00 --> Total execution time: 0.0494
DEBUG - 2022-12-22 11:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:36:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:36:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:09:00 --> Total execution time: 0.0462
DEBUG - 2022-12-22 11:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:39:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:39:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:09:32 --> Total execution time: 0.0593
DEBUG - 2022-12-22 11:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:39:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:39:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:10:00 --> Total execution time: 0.0645
DEBUG - 2022-12-22 11:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:40:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:10:15 --> Total execution time: 0.0747
DEBUG - 2022-12-22 11:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:40:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:10:29 --> Total execution time: 0.0693
DEBUG - 2022-12-22 11:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:40:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:40:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:11:21 --> Total execution time: 0.6717
DEBUG - 2022-12-22 11:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:41:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:41:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:11:28 --> Total execution time: 0.0669
DEBUG - 2022-12-22 11:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:41:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:41:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:41:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:41:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:12:20 --> Total execution time: 0.0613
DEBUG - 2022-12-22 11:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:42:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:42:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:42:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:42:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:12:26 --> Total execution time: 0.0542
DEBUG - 2022-12-22 11:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:42:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:12:56 --> Total execution time: 0.0712
DEBUG - 2022-12-22 11:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:42:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:42:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:42:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:42:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:14:37 --> Total execution time: 0.0704
DEBUG - 2022-12-22 11:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:44:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:44:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:15:54 --> Total execution time: 0.0449
DEBUG - 2022-12-22 11:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:45:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:16:48 --> Total execution time: 0.0431
DEBUG - 2022-12-22 11:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:46:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:46:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:17:04 --> Total execution time: 0.0647
DEBUG - 2022-12-22 11:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:47:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:47:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:17:26 --> Total execution time: 0.0680
DEBUG - 2022-12-22 11:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:47:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:47:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:17:35 --> Total execution time: 0.0633
DEBUG - 2022-12-22 11:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:47:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:47:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:18:10 --> Total execution time: 0.0588
DEBUG - 2022-12-22 11:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:48:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:48:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:18:37 --> Total execution time: 0.0596
DEBUG - 2022-12-22 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:48:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:48:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:18:43 --> Total execution time: 0.0721
DEBUG - 2022-12-22 11:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:48:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:48:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:18:49 --> Total execution time: 0.0823
DEBUG - 2022-12-22 11:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:48:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:48:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:19:38 --> Total execution time: 0.0420
DEBUG - 2022-12-22 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:49:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:20:07 --> Total execution time: 0.0667
DEBUG - 2022-12-22 11:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:50:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:50:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:20:32 --> Total execution time: 0.0648
DEBUG - 2022-12-22 11:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:50:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:50:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:20:42 --> Total execution time: 0.0631
DEBUG - 2022-12-22 11:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:50:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:50:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:20:51 --> Total execution time: 0.0525
DEBUG - 2022-12-22 11:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:50:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:50:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:20:56 --> Total execution time: 0.0399
DEBUG - 2022-12-22 11:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:50:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:50:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:21:00 --> Total execution time: 0.0640
DEBUG - 2022-12-22 11:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:51:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:21:09 --> Total execution time: 0.0571
DEBUG - 2022-12-22 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:51:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:51:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:21:14 --> Total execution time: 0.0638
DEBUG - 2022-12-22 11:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:51:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:51:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:22:30 --> Total execution time: 0.0468
DEBUG - 2022-12-22 11:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:52:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:52:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:22:54 --> Total execution time: 0.0446
DEBUG - 2022-12-22 11:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:52:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:52:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:23:16 --> Total execution time: 0.0481
DEBUG - 2022-12-22 11:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:53:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:23:27 --> Total execution time: 0.0643
DEBUG - 2022-12-22 11:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:53:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:53:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:24:25 --> Total execution time: 0.0786
DEBUG - 2022-12-22 11:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:54:25 --> UTF-8 Support Enabled
ERROR - 2022-12-22 11:54:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:54:25 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-22 11:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:24:59 --> Total execution time: 0.0411
DEBUG - 2022-12-22 11:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:54:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:25:00 --> Total execution time: 0.0451
DEBUG - 2022-12-22 11:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:00 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-22 11:55:00 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-22 11:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:01 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-22 11:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:25:19 --> Total execution time: 0.0522
DEBUG - 2022-12-22 11:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:25:23 --> Total execution time: 0.0613
DEBUG - 2022-12-22 11:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:25:25 --> Total execution time: 0.0420
DEBUG - 2022-12-22 11:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:25:26 --> Total execution time: 0.0613
DEBUG - 2022-12-22 11:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:25:26 --> Total execution time: 0.0645
DEBUG - 2022-12-22 11:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:25:29 --> Total execution time: 0.0402
DEBUG - 2022-12-22 11:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:25:31 --> Total execution time: 0.0419
DEBUG - 2022-12-22 11:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:25:33 --> Total execution time: 0.0430
DEBUG - 2022-12-22 11:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:25:35 --> Total execution time: 0.0389
DEBUG - 2022-12-22 11:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:25:37 --> Total execution time: 0.0415
DEBUG - 2022-12-22 11:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:25:41 --> Total execution time: 0.0501
DEBUG - 2022-12-22 11:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:25:47 --> Total execution time: 0.0427
DEBUG - 2022-12-22 11:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:55:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:55:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:26:10 --> Total execution time: 0.0413
DEBUG - 2022-12-22 11:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:56:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:26:12 --> Total execution time: 0.0514
DEBUG - 2022-12-22 11:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:56:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:26:14 --> Total execution time: 0.0527
DEBUG - 2022-12-22 11:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:56:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:26:34 --> Total execution time: 0.0531
DEBUG - 2022-12-22 11:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:56:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:26:35 --> Total execution time: 0.0468
DEBUG - 2022-12-22 11:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:56:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:26:38 --> Total execution time: 0.0395
DEBUG - 2022-12-22 11:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:56:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:26:39 --> Total execution time: 0.0417
DEBUG - 2022-12-22 11:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:56:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:26:43 --> Total execution time: 0.0407
DEBUG - 2022-12-22 11:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:56:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:26:49 --> Total execution time: 0.0502
DEBUG - 2022-12-22 11:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:56:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:26:53 --> Total execution time: 0.0715
DEBUG - 2022-12-22 11:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:56:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:26:54 --> Total execution time: 0.0500
DEBUG - 2022-12-22 11:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:27:29 --> Total execution time: 0.0658
DEBUG - 2022-12-22 11:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:57:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:27:40 --> Total execution time: 0.0488
DEBUG - 2022-12-22 11:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:57:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:57:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:27:42 --> Total execution time: 0.0436
DEBUG - 2022-12-22 11:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:57:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:57:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:28:31 --> Total execution time: 0.1147
DEBUG - 2022-12-22 11:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:58:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:58:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:29:03 --> Total execution time: 0.1025
DEBUG - 2022-12-22 11:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:59:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:59:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:29:04 --> Total execution time: 0.0907
DEBUG - 2022-12-22 11:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:59:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:59:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:29:06 --> Total execution time: 0.0423
DEBUG - 2022-12-22 11:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:59:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:29:11 --> Total execution time: 0.0833
DEBUG - 2022-12-22 11:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:59:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:59:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:29:12 --> Total execution time: 0.0777
DEBUG - 2022-12-22 11:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:59:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:59:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:29:14 --> Total execution time: 0.0421
DEBUG - 2022-12-22 11:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:59:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 11:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 11:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 11:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:29:58 --> Total execution time: 0.0413
DEBUG - 2022-12-22 11:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 11:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 11:59:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 12:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:00:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 12:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 12:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 12:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:33:29 --> Total execution time: 0.0420
DEBUG - 2022-12-22 12:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:03:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:03:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 12:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 12:03:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:03:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 12:03:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:03:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:03:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 12:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:03:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 12:03:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:03:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:03:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 12:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 12:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:35:26 --> Total execution time: 0.0546
DEBUG - 2022-12-22 12:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:05:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 12:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:05:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:05:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:05:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:05:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:05:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 12:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 12:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 12:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:38:16 --> Total execution time: 0.0451
DEBUG - 2022-12-22 12:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:08:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 12:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 12:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 12:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:38:17 --> Total execution time: 0.0706
DEBUG - 2022-12-22 12:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:08:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 12:08:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 12:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 12:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 12:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 12:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 16:38:18 --> Total execution time: 0.0520
DEBUG - 2022-12-22 13:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 17:56:25 --> Total execution time: 0.0486
DEBUG - 2022-12-22 13:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:26:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:26:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 17:56:25 --> Total execution time: 0.0642
DEBUG - 2022-12-22 13:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:02:05 --> Total execution time: 0.0576
DEBUG - 2022-12-22 13:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:32:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:32:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:02:05 --> Total execution time: 0.0471
DEBUG - 2022-12-22 13:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:02:07 --> Total execution time: 0.0395
DEBUG - 2022-12-22 13:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:32:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:02:28 --> Total execution time: 0.0724
DEBUG - 2022-12-22 13:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:32:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:32:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:02:55 --> Total execution time: 0.0741
DEBUG - 2022-12-22 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:32:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:02:59 --> Total execution time: 0.0626
DEBUG - 2022-12-22 13:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:32:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:03:11 --> Total execution time: 0.0561
DEBUG - 2022-12-22 13:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:33:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:03:22 --> Total execution time: 0.0565
DEBUG - 2022-12-22 13:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:33:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:03:42 --> Total execution time: 0.0602
DEBUG - 2022-12-22 13:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:33:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:04:32 --> Total execution time: 0.0421
DEBUG - 2022-12-22 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:34:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:04:39 --> Total execution time: 0.0555
DEBUG - 2022-12-22 13:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:34:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:09:02 --> Total execution time: 0.0745
DEBUG - 2022-12-22 13:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:39:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:39:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:10:42 --> Total execution time: 0.0436
DEBUG - 2022-12-22 13:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:40:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:40:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:10:47 --> Total execution time: 0.0558
DEBUG - 2022-12-22 13:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:40:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:40:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:11:01 --> Total execution time: 0.0536
DEBUG - 2022-12-22 13:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:41:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:11:06 --> Total execution time: 0.0660
DEBUG - 2022-12-22 13:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:41:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:41:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:11:21 --> Total execution time: 0.0664
DEBUG - 2022-12-22 13:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:41:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:41:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:13:06 --> Total execution time: 0.0853
DEBUG - 2022-12-22 13:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:43:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:13:15 --> Total execution time: 0.0394
DEBUG - 2022-12-22 13:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:43:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:43:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:13:24 --> Total execution time: 0.0603
DEBUG - 2022-12-22 13:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:43:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:43:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:13:39 --> Total execution time: 0.0650
DEBUG - 2022-12-22 13:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:43:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:43:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:14:26 --> Total execution time: 0.0538
DEBUG - 2022-12-22 13:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:44:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:14:32 --> Total execution time: 0.0456
DEBUG - 2022-12-22 13:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:44:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:44:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:14:36 --> Total execution time: 0.0501
DEBUG - 2022-12-22 13:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:44:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:44:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:15:09 --> Total execution time: 0.0655
DEBUG - 2022-12-22 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:45:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:15:34 --> Total execution time: 0.0513
DEBUG - 2022-12-22 13:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:45:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:45:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:16:11 --> Total execution time: 0.0692
DEBUG - 2022-12-22 13:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:46:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:16:40 --> Total execution time: 0.0651
DEBUG - 2022-12-22 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:46:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:46:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:17:23 --> Total execution time: 0.0442
DEBUG - 2022-12-22 13:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:47:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:17:54 --> Total execution time: 0.0643
DEBUG - 2022-12-22 13:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:47:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:47:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:19:14 --> Total execution time: 0.0714
DEBUG - 2022-12-22 13:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:49:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:49:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:19:24 --> Total execution time: 0.0728
DEBUG - 2022-12-22 13:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:49:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:19:51 --> Total execution time: 0.0406
DEBUG - 2022-12-22 13:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:49:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:49:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:22:00 --> Total execution time: 0.0420
DEBUG - 2022-12-22 13:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:52:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:52:01 --> No URI present. Default controller set.
DEBUG - 2022-12-22 13:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:52:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-22 18:22:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Products C:\xampp\htdocs\gopal\crowd_funding\system\core\Loader.php 348
DEBUG - 2022-12-22 13:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:22:02 --> Total execution time: 0.0412
DEBUG - 2022-12-22 13:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:22:26 --> Total execution time: 0.0686
DEBUG - 2022-12-22 13:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:52:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:22:38 --> Total execution time: 0.0389
DEBUG - 2022-12-22 13:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:52:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:52:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:22:39 --> Total execution time: 0.0566
DEBUG - 2022-12-22 13:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:23:01 --> Total execution time: 0.0538
DEBUG - 2022-12-22 13:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:53:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:53:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:23:40 --> Total execution time: 0.0450
DEBUG - 2022-12-22 13:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:53:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:53:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:23:51 --> Total execution time: 0.0444
DEBUG - 2022-12-22 13:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:53:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:53:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:24:01 --> Total execution time: 0.0419
DEBUG - 2022-12-22 13:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:54:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:54:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:24:29 --> Total execution time: 0.0378
DEBUG - 2022-12-22 13:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:54:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:54:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:26:31 --> Total execution time: 0.0441
DEBUG - 2022-12-22 13:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:56:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:26:54 --> Total execution time: 0.0428
DEBUG - 2022-12-22 13:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:56:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:27:02 --> Total execution time: 0.0643
DEBUG - 2022-12-22 13:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:57:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:57:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:27:13 --> Total execution time: 0.0424
DEBUG - 2022-12-22 13:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:57:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:57:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:28:27 --> Total execution time: 0.0594
DEBUG - 2022-12-22 13:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:58:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:58:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:58:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:58:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:58:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:58:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 13:58:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:58:48 --> UTF-8 Support Enabled
ERROR - 2022-12-22 13:58:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 13:58:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:58:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:58:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:58:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 13:58:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:58:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:58:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:58:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 13:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:29:17 --> Total execution time: 0.0474
DEBUG - 2022-12-22 13:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:59:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:59:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 13:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 13:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 13:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:29:27 --> Total execution time: 0.0915
DEBUG - 2022-12-22 13:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 13:59:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 13:59:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:30:05 --> Total execution time: 0.0395
DEBUG - 2022-12-22 14:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:00:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:00:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:30:30 --> Total execution time: 0.0823
DEBUG - 2022-12-22 14:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:00:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:31:10 --> Total execution time: 0.0509
DEBUG - 2022-12-22 14:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:01:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:31:57 --> Total execution time: 0.0507
DEBUG - 2022-12-22 14:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:01:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:01:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:34:45 --> Total execution time: 0.0663
DEBUG - 2022-12-22 14:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:04:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:04:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:34:54 --> Total execution time: 0.0697
DEBUG - 2022-12-22 14:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:04:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:35:12 --> Total execution time: 0.0623
DEBUG - 2022-12-22 14:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:05:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:05:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:35:39 --> Total execution time: 0.0621
DEBUG - 2022-12-22 14:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:05:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:05:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:36:33 --> Total execution time: 0.0500
DEBUG - 2022-12-22 14:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:06:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:06:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:36:38 --> Total execution time: 0.0678
DEBUG - 2022-12-22 14:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:06:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:06:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:37:02 --> Total execution time: 0.0855
DEBUG - 2022-12-22 14:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:07:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:37:11 --> Total execution time: 0.0390
DEBUG - 2022-12-22 14:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:07:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:37:21 --> Total execution time: 0.0479
DEBUG - 2022-12-22 14:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:07:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:07:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:37:26 --> Total execution time: 0.0835
DEBUG - 2022-12-22 14:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:07:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:07:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:37:33 --> Total execution time: 0.0617
DEBUG - 2022-12-22 14:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:07:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:07:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:40:16 --> Total execution time: 0.0460
DEBUG - 2022-12-22 14:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:10:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:10:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:40:37 --> Total execution time: 0.0421
DEBUG - 2022-12-22 14:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:10:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:10:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:40:48 --> Total execution time: 0.0737
DEBUG - 2022-12-22 14:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:10:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:10:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:40:57 --> Total execution time: 0.0559
DEBUG - 2022-12-22 14:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:10:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:41:03 --> Total execution time: 0.0661
DEBUG - 2022-12-22 14:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:11:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:41:25 --> Total execution time: 0.0703
DEBUG - 2022-12-22 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:11:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:11:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:41:35 --> Total execution time: 0.0448
DEBUG - 2022-12-22 14:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:11:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:42:02 --> Total execution time: 0.0718
DEBUG - 2022-12-22 14:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:12:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:42:06 --> Total execution time: 0.0629
DEBUG - 2022-12-22 14:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:12:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:12:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:42:13 --> Total execution time: 0.0553
DEBUG - 2022-12-22 14:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:12:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:12:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:42:20 --> Total execution time: 0.0548
DEBUG - 2022-12-22 14:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:12:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:42:30 --> Total execution time: 0.0398
DEBUG - 2022-12-22 14:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:12:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:12:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:45:12 --> Total execution time: 0.0422
DEBUG - 2022-12-22 14:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:15:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:15:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:45:25 --> Total execution time: 0.0787
DEBUG - 2022-12-22 14:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:15:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:15:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:45:39 --> Total execution time: 0.0562
DEBUG - 2022-12-22 14:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:15:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:15:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:45:58 --> Total execution time: 0.0541
DEBUG - 2022-12-22 14:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:15:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:49:40 --> Total execution time: 0.0652
DEBUG - 2022-12-22 14:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:19:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:19:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:49:48 --> Total execution time: 0.0409
DEBUG - 2022-12-22 14:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:19:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:19:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:50:00 --> Total execution time: 0.0444
DEBUG - 2022-12-22 14:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:20:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:51:01 --> Total execution time: 0.0427
DEBUG - 2022-12-22 14:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:21:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:52:45 --> Total execution time: 0.0420
DEBUG - 2022-12-22 14:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:22:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:52:51 --> Total execution time: 0.0429
DEBUG - 2022-12-22 14:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:22:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:53:03 --> Total execution time: 0.0486
DEBUG - 2022-12-22 14:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:23:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:53:12 --> Total execution time: 0.0516
DEBUG - 2022-12-22 14:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:23:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:23:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:53:45 --> Total execution time: 0.0461
DEBUG - 2022-12-22 14:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:53:47 --> Total execution time: 0.0482
DEBUG - 2022-12-22 14:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:53:50 --> Total execution time: 0.0429
DEBUG - 2022-12-22 14:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:23:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:23:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:59:32 --> Total execution time: 0.0483
DEBUG - 2022-12-22 14:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:29:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:29:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:29:40 --> 404 Page Not Found: Admin/fundraiser/KYC_Controller/index
DEBUG - 2022-12-22 14:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 18:59:53 --> Total execution time: 0.0621
DEBUG - 2022-12-22 14:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:29:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:29:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:00:45 --> Total execution time: 0.0629
DEBUG - 2022-12-22 14:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:30:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:01:05 --> Total execution time: 0.0455
DEBUG - 2022-12-22 14:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:31:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:01:24 --> Total execution time: 0.0635
DEBUG - 2022-12-22 14:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:31:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:01:49 --> Total execution time: 0.0634
DEBUG - 2022-12-22 14:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:31:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:02:28 --> Total execution time: 0.0703
DEBUG - 2022-12-22 14:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:32:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:32:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:02:35 --> Total execution time: 0.0542
DEBUG - 2022-12-22 14:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:32:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:02:48 --> Total execution time: 0.0516
DEBUG - 2022-12-22 14:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:32:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:03:00 --> Total execution time: 0.0510
DEBUG - 2022-12-22 14:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:33:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:03:09 --> Total execution time: 0.0598
DEBUG - 2022-12-22 14:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:33:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:03:31 --> Total execution time: 0.0513
DEBUG - 2022-12-22 14:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:33:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:03:47 --> Total execution time: 0.0696
DEBUG - 2022-12-22 14:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:33:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 14:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:37:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:37:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:07:14 --> Total execution time: 0.0658
DEBUG - 2022-12-22 14:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:37:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:37:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:07:33 --> Total execution time: 0.0413
DEBUG - 2022-12-22 14:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:37:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:08:31 --> Total execution time: 0.0460
DEBUG - 2022-12-22 14:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:38:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:08:50 --> Total execution time: 0.0400
DEBUG - 2022-12-22 14:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:38:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:38:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:10:18 --> Total execution time: 0.0408
DEBUG - 2022-12-22 14:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:40:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:40:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:10:37 --> Total execution time: 0.0443
DEBUG - 2022-12-22 14:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:40:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:40:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:11:15 --> Total execution time: 0.0727
DEBUG - 2022-12-22 14:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:41:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:41:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:11:46 --> Total execution time: 0.0664
DEBUG - 2022-12-22 14:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:41:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:41:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:15:08 --> Total execution time: 0.0635
DEBUG - 2022-12-22 14:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:45:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:45:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 14:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:46:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:46:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:16:32 --> Total execution time: 0.0507
DEBUG - 2022-12-22 14:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:46:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:46:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:16:45 --> Total execution time: 0.0444
DEBUG - 2022-12-22 14:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:46:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:18:59 --> Total execution time: 0.0639
DEBUG - 2022-12-22 14:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:48:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:48:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 14:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:19:03 --> Total execution time: 0.0572
DEBUG - 2022-12-22 14:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:19:37 --> Total execution time: 0.0603
DEBUG - 2022-12-22 14:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:19:42 --> Total execution time: 0.0876
DEBUG - 2022-12-22 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 14:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 14:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 19:21:35 --> Total execution time: 0.0436
DEBUG - 2022-12-22 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 14:51:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:04:29 --> Total execution time: 0.0578
DEBUG - 2022-12-22 15:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:34:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:05:15 --> Total execution time: 0.0572
DEBUG - 2022-12-22 15:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:35:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:35:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:05:23 --> Total execution time: 0.0447
DEBUG - 2022-12-22 15:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:35:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:35:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:05:48 --> Total execution time: 0.0689
DEBUG - 2022-12-22 15:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:35:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:06:01 --> Total execution time: 0.0564
DEBUG - 2022-12-22 15:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:36:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:36:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:06:23 --> Total execution time: 0.0707
DEBUG - 2022-12-22 15:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:36:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:36:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:06:31 --> Total execution time: 0.0664
DEBUG - 2022-12-22 15:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:36:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:36:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:07:06 --> Total execution time: 0.6118
DEBUG - 2022-12-22 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:37:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:07:14 --> Total execution time: 0.0533
DEBUG - 2022-12-22 15:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:37:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:37:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:07:23 --> Total execution time: 0.0725
DEBUG - 2022-12-22 15:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:37:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:37:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:08:10 --> Total execution time: 0.8567
DEBUG - 2022-12-22 15:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:38:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:38:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:08:46 --> Total execution time: 0.0389
DEBUG - 2022-12-22 15:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:38:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:08:56 --> Total execution time: 0.0576
DEBUG - 2022-12-22 15:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:38:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:09:08 --> Total execution time: 0.0447
DEBUG - 2022-12-22 15:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:39:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:39:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:09:20 --> Total execution time: 0.0711
DEBUG - 2022-12-22 15:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:39:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:09:25 --> Total execution time: 0.0479
DEBUG - 2022-12-22 15:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:39:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:39:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:40:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 15:40:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:40:36 --> UTF-8 Support Enabled
ERROR - 2022-12-22 15:40:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:40:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:40:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:40:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:40:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:40:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:12:16 --> Total execution time: 0.0575
DEBUG - 2022-12-22 15:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:42:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:42:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:42:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:42:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 15:42:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:42:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:42:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:42:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:42:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:42:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:42:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:42:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:42:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:42:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:42:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:42:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:42:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:42:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:42:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:12:36 --> Total execution time: 0.0527
DEBUG - 2022-12-22 15:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:42:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:42:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:13:03 --> Total execution time: 0.0485
DEBUG - 2022-12-22 15:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:43:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:43:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:13:13 --> Total execution time: 0.0806
DEBUG - 2022-12-22 15:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:43:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:43:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:13:37 --> Total execution time: 0.0597
DEBUG - 2022-12-22 15:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:43:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:13:44 --> Total execution time: 0.0388
DEBUG - 2022-12-22 15:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:43:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:43:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:13:51 --> Total execution time: 0.0789
DEBUG - 2022-12-22 15:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:43:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:15:51 --> Total execution time: 0.0517
DEBUG - 2022-12-22 15:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:45:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:45:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:16:31 --> Total execution time: 0.0560
DEBUG - 2022-12-22 15:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:46:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:46:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:17:42 --> Total execution time: 0.0608
DEBUG - 2022-12-22 15:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:47:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:47:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:17:56 --> Total execution time: 0.0592
DEBUG - 2022-12-22 15:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:47:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:47:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:18:13 --> Total execution time: 0.0679
DEBUG - 2022-12-22 15:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:48:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:48:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:18:32 --> Total execution time: 0.0537
DEBUG - 2022-12-22 15:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:48:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:48:41 --> UTF-8 Support Enabled
ERROR - 2022-12-22 15:48:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:48:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:48:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:48:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:48:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:48:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:48:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:48:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:48:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:48:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:48:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 15:48:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:48:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:48:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:19:16 --> Total execution time: 0.0416
DEBUG - 2022-12-22 15:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:49:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:49:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:49:34 --> UTF-8 Support Enabled
ERROR - 2022-12-22 15:49:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:49:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:49:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:49:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:49:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:49:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:49:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:49:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:49:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:49:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:49:34 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 15:49:34 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 15:49:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:21:06 --> Total execution time: 0.0521
DEBUG - 2022-12-22 15:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:51:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:51:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:21:13 --> Total execution time: 0.0976
DEBUG - 2022-12-22 15:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:51:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:21:22 --> Total execution time: 0.0718
DEBUG - 2022-12-22 15:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:51:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:51:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:52:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:52:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:52:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:52:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:52:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:52:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:52:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:52:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 15:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:22:24 --> Total execution time: 0.0685
DEBUG - 2022-12-22 15:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:52:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:52:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:22:29 --> Total execution time: 0.0729
DEBUG - 2022-12-22 15:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:52:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:52:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:22:38 --> Total execution time: 0.0685
DEBUG - 2022-12-22 15:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:52:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:52:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:23:04 --> Total execution time: 0.0972
DEBUG - 2022-12-22 15:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:53:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 15:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:56:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:56:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:26:25 --> Total execution time: 0.0703
DEBUG - 2022-12-22 15:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:56:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:56:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:27:23 --> Total execution time: 0.0460
DEBUG - 2022-12-22 15:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:57:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:27:43 --> Total execution time: 0.0557
DEBUG - 2022-12-22 15:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:57:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:27:51 --> Total execution time: 0.0527
DEBUG - 2022-12-22 15:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:57:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:57:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 15:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 15:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 15:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:29:08 --> Total execution time: 0.0680
DEBUG - 2022-12-22 15:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 15:59:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 15:59:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:30:20 --> Total execution time: 0.0594
DEBUG - 2022-12-22 16:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:00:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:00:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:32:08 --> Total execution time: 0.0488
DEBUG - 2022-12-22 16:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:02:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:02:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:40:03 --> Total execution time: 0.0463
DEBUG - 2022-12-22 16:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:10:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:10:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:42:00 --> Total execution time: 0.0625
DEBUG - 2022-12-22 16:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:12:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:12:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:44:20 --> Total execution time: 0.0681
DEBUG - 2022-12-22 16:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:14:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:14:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:45:06 --> Total execution time: 0.0605
DEBUG - 2022-12-22 16:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:15:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:51:42 --> Total execution time: 0.0485
DEBUG - 2022-12-22 16:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:21:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:53:02 --> Total execution time: 0.0434
DEBUG - 2022-12-22 16:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:23:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:23:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:53:29 --> Total execution time: 0.0423
DEBUG - 2022-12-22 16:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:23:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:23:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:55:07 --> Total execution time: 0.0462
DEBUG - 2022-12-22 16:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:25:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:25:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:25:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:25:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:25:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:25:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:25:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 16:25:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:25:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:56:08 --> Total execution time: 0.0421
DEBUG - 2022-12-22 16:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:26:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:56:19 --> Total execution time: 0.0539
DEBUG - 2022-12-22 16:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:26:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 20:59:52 --> Total execution time: 0.0419
DEBUG - 2022-12-22 16:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:29:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:29:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:00:48 --> Total execution time: 0.0387
DEBUG - 2022-12-22 16:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:30:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:30:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:30:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:30:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:30:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:30:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:30:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:30:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 16:30:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:30:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:30:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:30:55 --> UTF-8 Support Enabled
ERROR - 2022-12-22 16:30:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 16:30:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:30:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:30:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:01:49 --> Total execution time: 0.0422
DEBUG - 2022-12-22 16:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:31:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:31:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 16:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:31:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:02:40 --> Total execution time: 0.0507
DEBUG - 2022-12-22 16:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:32:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:32:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:32:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:32:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:32:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:32:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:32:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:32:40 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-22 16:32:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:32:41 --> UTF-8 Support Enabled
ERROR - 2022-12-22 16:32:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:32:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:32:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 16:32:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:32:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:32:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:32:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:32:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:03:39 --> Total execution time: 0.0600
DEBUG - 2022-12-22 16:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:33:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:33:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:03:50 --> Total execution time: 0.0520
DEBUG - 2022-12-22 16:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:33:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:33:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:06:15 --> Total execution time: 0.0679
DEBUG - 2022-12-22 16:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:36:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:36:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:36:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:36:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:36:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:36:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:36:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:36:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:36:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:36:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:36:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:36:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:36:19 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 16:36:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:36:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:36:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:08:40 --> Total execution time: 0.0435
DEBUG - 2022-12-22 16:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:38:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:38:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:11:16 --> Total execution time: 0.0600
DEBUG - 2022-12-22 16:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:41:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:11:20 --> Total execution time: 0.0995
DEBUG - 2022-12-22 16:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:41:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:11:21 --> Total execution time: 0.0441
DEBUG - 2022-12-22 16:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:41:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:11:23 --> Total execution time: 0.0688
DEBUG - 2022-12-22 16:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:41:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:41:30 --> UTF-8 Support Enabled
ERROR - 2022-12-22 16:41:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:41:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:41:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:41:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:41:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:41:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:41:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 16:41:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:41:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:41:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:12:04 --> Total execution time: 0.0673
DEBUG - 2022-12-22 16:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:42:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:42:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:42:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:42:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:42:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:42:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-22 16:42:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:42:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:42:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:42:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-22 16:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:13:32 --> Total execution time: 0.0867
DEBUG - 2022-12-22 16:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:43:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:43:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:13:35 --> Total execution time: 0.1060
DEBUG - 2022-12-22 16:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:43:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:43:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:13:48 --> Total execution time: 0.1113
DEBUG - 2022-12-22 16:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:43:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:43:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:45:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:45:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'ismartw1_crowd_funding'@'localhost' (using password: YES) C:\xampp\htdocs\gopal\crowd_funding\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-12-22 16:45:48 --> Unable to connect to the database
DEBUG - 2022-12-22 16:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:45:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:45:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'ismartw1_crowd_funding'@'localhost' (using password: YES) C:\xampp\htdocs\gopal\crowd_funding\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-12-22 16:45:56 --> Unable to connect to the database
DEBUG - 2022-12-22 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:19:41 --> Total execution time: 0.0620
DEBUG - 2022-12-22 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:49:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:19:44 --> Total execution time: 0.0400
DEBUG - 2022-12-22 16:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:49:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:19:45 --> Total execution time: 0.0586
DEBUG - 2022-12-22 16:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:49:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:19:47 --> Total execution time: 0.0496
DEBUG - 2022-12-22 16:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:49:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:19:47 --> Total execution time: 0.0498
DEBUG - 2022-12-22 16:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:49:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:19:49 --> Total execution time: 0.0400
DEBUG - 2022-12-22 16:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:49:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:19:50 --> Total execution time: 0.0496
DEBUG - 2022-12-22 16:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:49:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-22 16:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-22 16:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-22 16:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-22 21:19:53 --> Total execution time: 0.0393
DEBUG - 2022-12-22 16:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-22 16:49:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-22 16:49:53 --> 404 Page Not Found: Assets/website_esa
