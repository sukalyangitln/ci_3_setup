<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-07 03:57:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 03:57:52 --> No URI present. Default controller set.
DEBUG - 2021-11-07 03:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 03:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 09:27:53 --> Total execution time: 1.0458
DEBUG - 2021-11-07 03:57:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 03:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 03:57:53 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 03:57:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 03:57:53 --> No URI present. Default controller set.
DEBUG - 2021-11-07 03:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 03:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 09:27:53 --> Total execution time: 0.0439
DEBUG - 2021-11-07 03:58:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 03:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 03:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 03:58:15 --> Total execution time: 0.1116
DEBUG - 2021-11-07 03:58:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 03:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 03:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 03:58:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 03:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 03:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 09:28:22 --> Total execution time: 0.1226
DEBUG - 2021-11-07 13:17:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:17:10 --> No URI present. Default controller set.
DEBUG - 2021-11-07 13:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 17:47:11 --> Total execution time: 0.0520
DEBUG - 2021-11-07 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:17:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:17:11 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:17:11 --> No URI present. Default controller set.
DEBUG - 2021-11-07 13:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 17:47:11 --> Total execution time: 0.0484
DEBUG - 2021-11-07 13:17:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 13:17:16 --> Total execution time: 0.0507
DEBUG - 2021-11-07 13:18:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 13:18:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 17:48:21 --> Total execution time: 0.0495
DEBUG - 2021-11-07 13:23:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 17:53:53 --> Total execution time: 0.0576
DEBUG - 2021-11-07 13:23:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:23:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:23:55 --> 404 Page Not Found: Admin-security/index
DEBUG - 2021-11-07 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:26:16 --> 404 Page Not Found: Admin-security/index
DEBUG - 2021-11-07 13:26:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 17:56:24 --> Total execution time: 0.0540
DEBUG - 2021-11-07 13:27:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 17:57:33 --> Total execution time: 0.0758
DEBUG - 2021-11-07 13:28:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 17:58:29 --> Total execution time: 0.0699
DEBUG - 2021-11-07 13:29:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 17:59:14 --> Total execution time: 0.0548
DEBUG - 2021-11-07 13:32:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:02:21 --> Total execution time: 0.0647
DEBUG - 2021-11-07 13:32:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:32:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:32:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:32:25 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-07 13:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:32:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:32:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:33:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:03:24 --> Total execution time: 0.0574
DEBUG - 2021-11-07 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:03:32 --> Total execution time: 0.0522
DEBUG - 2021-11-07 13:34:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:04:17 --> Total execution time: 0.0544
DEBUG - 2021-11-07 13:34:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:04:49 --> Total execution time: 0.0661
DEBUG - 2021-11-07 13:35:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:35:39 --> No URI present. Default controller set.
DEBUG - 2021-11-07 13:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:05:39 --> Total execution time: 0.0506
DEBUG - 2021-11-07 13:35:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:35:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:35:39 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 13:35:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:35:39 --> No URI present. Default controller set.
DEBUG - 2021-11-07 13:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:05:39 --> Total execution time: 0.0545
DEBUG - 2021-11-07 13:35:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:05:42 --> Total execution time: 0.0567
DEBUG - 2021-11-07 13:35:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 13:35:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:05:51 --> Total execution time: 0.0499
DEBUG - 2021-11-07 13:35:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:05:54 --> Total execution time: 0.0631
DEBUG - 2021-11-07 13:35:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:05:58 --> Total execution time: 0.0505
DEBUG - 2021-11-07 13:44:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:14:41 --> Total execution time: 0.0710
DEBUG - 2021-11-07 13:45:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:15:13 --> Total execution time: 0.0508
DEBUG - 2021-11-07 13:45:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:45:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:45:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:45:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:45:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:45:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:45:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:45:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:45:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:45:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:45:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:45:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:45:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:15:37 --> Total execution time: 0.0516
DEBUG - 2021-11-07 13:45:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:15:38 --> Total execution time: 0.0489
DEBUG - 2021-11-07 13:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:15:53 --> Total execution time: 0.0568
DEBUG - 2021-11-07 13:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:45:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:45:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:45:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:45:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:46:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:16:08 --> Total execution time: 0.0747
DEBUG - 2021-11-07 13:53:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:23:12 --> Total execution time: 0.0655
DEBUG - 2021-11-07 13:53:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:23:14 --> Total execution time: 0.0522
DEBUG - 2021-11-07 13:55:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:25:40 --> Total execution time: 0.0674
DEBUG - 2021-11-07 13:55:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:25:43 --> Total execution time: 0.0548
DEBUG - 2021-11-07 13:57:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:27:25 --> Total execution time: 0.0572
DEBUG - 2021-11-07 13:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:57:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:57:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:57:26 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-07 13:57:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:57:26 --> UTF-8 Support Enabled
ERROR - 2021-11-07 13:57:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:57:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:57:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:57:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 13:57:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 13:57:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:57:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-07 18:27:43 --> Severity: Notice --> Undefined property: Help_Controller::$Admins C:\xampp\htdocs\soumya\cp.whatsmessaging\application\controllers\Admin\settings\Help_Controller.php 63
ERROR - 2021-11-07 18:27:43 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\soumya\cp.whatsmessaging\application\controllers\Admin\settings\Help_Controller.php 63
DEBUG - 2021-11-07 13:58:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:28:20 --> Total execution time: 0.0536
DEBUG - 2021-11-07 13:58:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:28:39 --> Total execution time: 0.0507
DEBUG - 2021-11-07 13:58:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:28:42 --> Total execution time: 0.0529
DEBUG - 2021-11-07 13:58:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:28:56 --> Total execution time: 0.0538
DEBUG - 2021-11-07 13:59:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 13:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 13:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:29:01 --> Total execution time: 0.0532
DEBUG - 2021-11-07 14:00:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:30:32 --> Total execution time: 0.0616
DEBUG - 2021-11-07 14:01:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:31:31 --> Total execution time: 0.0623
DEBUG - 2021-11-07 14:02:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:32:22 --> Total execution time: 0.0600
DEBUG - 2021-11-07 14:02:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:32:44 --> Total execution time: 0.0760
DEBUG - 2021-11-07 14:02:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:32:49 --> Total execution time: 0.0594
DEBUG - 2021-11-07 14:05:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 14:05:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:05:54 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:35:54 --> Total execution time: 0.0629
DEBUG - 2021-11-07 14:05:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:05:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:05:54 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:05:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:05:54 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:35:54 --> Total execution time: 0.0638
DEBUG - 2021-11-07 14:08:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:08:17 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:38:17 --> Total execution time: 0.0627
DEBUG - 2021-11-07 14:08:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:08:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:08:17 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:08:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:08:17 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:38:17 --> Total execution time: 0.0598
DEBUG - 2021-11-07 14:08:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:08:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:08:24 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:09:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:03 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:39:03 --> Total execution time: 0.0727
DEBUG - 2021-11-07 14:09:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:09:03 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:09:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:04 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:39:04 --> Total execution time: 0.0763
DEBUG - 2021-11-07 14:09:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:09 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:39:09 --> Total execution time: 0.0673
DEBUG - 2021-11-07 14:09:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:09:10 --> No URI present. Default controller set.
ERROR - 2021-11-07 14:09:10 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:39:10 --> Total execution time: 0.0511
DEBUG - 2021-11-07 14:09:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:09:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-07 18:39:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Account_details C:\xampp\htdocs\soumya\cp.whatsmessaging\system\core\Loader.php 348
DEBUG - 2021-11-07 14:09:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:16 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:39:16 --> Total execution time: 0.0490
DEBUG - 2021-11-07 14:09:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:16 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:39:16 --> Total execution time: 0.0571
DEBUG - 2021-11-07 14:09:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:26 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:39:27 --> Total execution time: 0.0691
DEBUG - 2021-11-07 14:09:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:09:27 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:09:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:27 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:39:27 --> Total execution time: 0.0541
DEBUG - 2021-11-07 14:09:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:51 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:39:51 --> Total execution time: 0.0523
DEBUG - 2021-11-07 14:09:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:09:51 --> No URI present. Default controller set.
ERROR - 2021-11-07 14:09:51 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:39:51 --> Total execution time: 0.0549
DEBUG - 2021-11-07 14:09:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:09:59 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:39:59 --> Total execution time: 0.1193
DEBUG - 2021-11-07 14:10:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:10:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:10:00 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:10:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:10:00 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:40:00 --> Total execution time: 0.0534
DEBUG - 2021-11-07 14:10:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:10:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:10:17 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:10:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:10:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:10:49 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:11:37 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:41:37 --> Total execution time: 0.0679
DEBUG - 2021-11-07 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:11:37 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:11:37 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:41:37 --> Total execution time: 0.0593
DEBUG - 2021-11-07 14:11:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:11:46 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:41:46 --> Total execution time: 0.0513
DEBUG - 2021-11-07 14:11:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:11:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:11:46 --> No URI present. Default controller set.
ERROR - 2021-11-07 14:11:46 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:41:46 --> Total execution time: 0.0563
DEBUG - 2021-11-07 14:17:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:17:42 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:47:42 --> Total execution time: 0.0563
DEBUG - 2021-11-07 14:17:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:17:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:17:42 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:17:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:17:42 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:47:42 --> Total execution time: 0.0537
DEBUG - 2021-11-07 14:19:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:19:16 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:49:16 --> Total execution time: 0.0523
DEBUG - 2021-11-07 14:19:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:19:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:19:16 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:19:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:19:16 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:49:16 --> Total execution time: 0.0587
DEBUG - 2021-11-07 14:19:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:19:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:19:18 --> 404 Page Not Found: Forgot-password/index
DEBUG - 2021-11-07 14:21:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:21:32 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:51:32 --> Total execution time: 0.0646
DEBUG - 2021-11-07 14:21:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:21:32 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:51:32 --> Total execution time: 0.0621
DEBUG - 2021-11-07 14:21:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:21:37 --> No URI present. Default controller set.
DEBUG - 2021-11-07 14:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:51:37 --> Total execution time: 0.0813
DEBUG - 2021-11-07 14:21:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:21:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:21:37 --> No URI present. Default controller set.
ERROR - 2021-11-07 14:21:37 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:51:37 --> Total execution time: 0.0585
DEBUG - 2021-11-07 14:23:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:53:08 --> Total execution time: 0.0526
DEBUG - 2021-11-07 14:23:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:53:18 --> Total execution time: 0.0546
DEBUG - 2021-11-07 14:23:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:23:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:23:18 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:23:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:53:18 --> Total execution time: 0.0624
DEBUG - 2021-11-07 14:24:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:54:20 --> Total execution time: 0.0958
DEBUG - 2021-11-07 14:24:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:24:20 --> UTF-8 Support Enabled
ERROR - 2021-11-07 14:24:20 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:54:20 --> Total execution time: 0.0609
DEBUG - 2021-11-07 14:25:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:55:12 --> Total execution time: 0.0765
DEBUG - 2021-11-07 14:25:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:25:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:25:12 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:55:12 --> Total execution time: 0.0752
DEBUG - 2021-11-07 14:26:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:56:59 --> Total execution time: 0.0679
DEBUG - 2021-11-07 14:26:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:26:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:26:59 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:26:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:56:59 --> Total execution time: 0.0530
DEBUG - 2021-11-07 14:27:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:57:36 --> Total execution time: 0.0547
DEBUG - 2021-11-07 14:27:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:27:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:27:36 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:27:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:57:36 --> Total execution time: 0.0538
DEBUG - 2021-11-07 14:27:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:57:57 --> Total execution time: 0.0623
DEBUG - 2021-11-07 14:27:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:27:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:27:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:27:57 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:57:57 --> Total execution time: 0.0495
DEBUG - 2021-11-07 14:28:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:58:38 --> Total execution time: 0.0529
DEBUG - 2021-11-07 14:28:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:28:38 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:28:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:58:39 --> Total execution time: 0.0540
DEBUG - 2021-11-07 14:29:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:59:33 --> Total execution time: 0.0566
DEBUG - 2021-11-07 14:29:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:29:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:29:33 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 18:59:33 --> Total execution time: 0.0509
DEBUG - 2021-11-07 14:30:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:00:18 --> Total execution time: 0.0741
DEBUG - 2021-11-07 14:30:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:30:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:30:18 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:30:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:00:18 --> Total execution time: 0.0537
DEBUG - 2021-11-07 14:31:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:01:27 --> Total execution time: 0.0490
DEBUG - 2021-11-07 14:31:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:31:27 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:31:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:01:27 --> Total execution time: 0.0524
DEBUG - 2021-11-07 14:31:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:01:36 --> Total execution time: 0.0604
DEBUG - 2021-11-07 14:31:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:31:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:31:36 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:31:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:01:36 --> Total execution time: 0.0536
DEBUG - 2021-11-07 14:31:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:01:36 --> Total execution time: 0.0480
DEBUG - 2021-11-07 14:31:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:31:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:31:36 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:31:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:01:36 --> Total execution time: 0.0656
DEBUG - 2021-11-07 14:31:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:01:37 --> Total execution time: 0.0488
DEBUG - 2021-11-07 14:31:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:31:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:31:37 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:31:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:01:37 --> Total execution time: 0.0545
DEBUG - 2021-11-07 14:32:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:02:04 --> Total execution time: 0.0501
DEBUG - 2021-11-07 14:32:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:32:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:32:04 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:32:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:02:04 --> Total execution time: 0.0544
DEBUG - 2021-11-07 14:32:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:32:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:32:11 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:32:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:02:34 --> Total execution time: 0.0510
DEBUG - 2021-11-07 14:32:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:32:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:32:34 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:32:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:02:34 --> Total execution time: 0.0501
DEBUG - 2021-11-07 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:03:21 --> Total execution time: 0.0500
DEBUG - 2021-11-07 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:33:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:33:21 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:03:21 --> Total execution time: 0.0741
DEBUG - 2021-11-07 14:36:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:06:15 --> Total execution time: 0.0762
DEBUG - 2021-11-07 14:36:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:36:15 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:36:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:06:16 --> Total execution time: 0.0645
DEBUG - 2021-11-07 14:36:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:36:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:36:31 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:37:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:07:53 --> Total execution time: 0.0498
DEBUG - 2021-11-07 14:37:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:37:53 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:37:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:37:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:37:53 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:07:53 --> Total execution time: 0.0575
DEBUG - 2021-11-07 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:11:36 --> Total execution time: 0.0662
DEBUG - 2021-11-07 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:41:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:41:36 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 14:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 19:11:36 --> Total execution time: 0.0562
ERROR - 2021-11-07 14:41:36 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:42:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:12:07 --> Total execution time: 0.0540
DEBUG - 2021-11-07 14:42:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:42:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:42:07 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:42:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:42:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:42:07 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:42:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:12:07 --> Total execution time: 0.0531
DEBUG - 2021-11-07 14:42:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:12:29 --> Total execution time: 0.0925
DEBUG - 2021-11-07 14:42:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:42:29 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:42:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:42:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:42:29 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:12:29 --> Total execution time: 0.0554
DEBUG - 2021-11-07 14:52:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:22:59 --> Total execution time: 0.0735
DEBUG - 2021-11-07 14:52:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:52:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:52:59 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:52:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:22:59 --> Total execution time: 0.0580
DEBUG - 2021-11-07 14:53:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:23:38 --> Total execution time: 0.0508
DEBUG - 2021-11-07 14:53:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:53:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:53:39 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:53:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:23:39 --> Total execution time: 0.0573
DEBUG - 2021-11-07 14:59:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:29:17 --> Total execution time: 0.0781
DEBUG - 2021-11-07 14:59:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:59:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 14:59:18 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 14:59:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 14:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 14:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:29:18 --> Total execution time: 0.0701
DEBUG - 2021-11-07 15:05:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:35:45 --> Total execution time: 0.0571
DEBUG - 2021-11-07 15:05:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:05:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:05:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 15:05:45 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 15:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:35:45 --> Total execution time: 0.0574
DEBUG - 2021-11-07 15:07:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 15:07:57 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 15:09:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:09:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 15:09:03 --> 404 Page Not Found: Forgot-password/index
DEBUG - 2021-11-07 15:09:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:39:04 --> Total execution time: 0.0724
DEBUG - 2021-11-07 15:09:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:09:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 15:09:04 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 15:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:39:04 --> Total execution time: 0.0622
DEBUG - 2021-11-07 15:09:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:39:48 --> Total execution time: 0.0513
DEBUG - 2021-11-07 15:09:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 15:09:48 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 15:09:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:09:48 --> UTF-8 Support Enabled
ERROR - 2021-11-07 15:09:48 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 15:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:39:48 --> Total execution time: 0.0528
DEBUG - 2021-11-07 15:10:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 15:10:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:40:12 --> Total execution time: 0.0502
DEBUG - 2021-11-07 15:10:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:40:18 --> Total execution time: 0.0575
DEBUG - 2021-11-07 15:10:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:40:23 --> Total execution time: 0.0645
DEBUG - 2021-11-07 15:23:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:53:26 --> Total execution time: 0.0619
DEBUG - 2021-11-07 15:23:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 15:23:26 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 15:23:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:23:26 --> UTF-8 Support Enabled
ERROR - 2021-11-07 15:23:26 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 15:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:53:26 --> Total execution time: 0.0699
DEBUG - 2021-11-07 15:23:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 19:53:31 --> Total execution time: 0.0464
DEBUG - 2021-11-07 15:42:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:12:47 --> Total execution time: 0.0545
DEBUG - 2021-11-07 15:42:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:42:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 15:42:47 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 15:42:48 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 15:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:12:48 --> Total execution time: 0.0759
DEBUG - 2021-11-07 15:42:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:12:53 --> Total execution time: 0.0454
DEBUG - 2021-11-07 15:42:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:12:59 --> Total execution time: 0.0472
DEBUG - 2021-11-07 15:43:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:13:00 --> Total execution time: 0.0438
DEBUG - 2021-11-07 15:43:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:13:21 --> Total execution time: 0.0508
DEBUG - 2021-11-07 15:43:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 15:43:21 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 15:43:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:43:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 15:43:21 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 15:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:13:21 --> Total execution time: 0.0541
DEBUG - 2021-11-07 15:43:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:13:23 --> Total execution time: 0.0463
DEBUG - 2021-11-07 15:43:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:13:31 --> Total execution time: 0.0458
DEBUG - 2021-11-07 15:43:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:13:54 --> Total execution time: 0.0681
DEBUG - 2021-11-07 15:43:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:43:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 15:43:54 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 15:43:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:43:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:43:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 15:43:54 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 15:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:13:54 --> Total execution time: 0.0602
DEBUG - 2021-11-07 15:43:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:13:56 --> Total execution time: 0.0692
DEBUG - 2021-11-07 15:44:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 15:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 15:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:14:02 --> Total execution time: 0.0465
DEBUG - 2021-11-07 16:04:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:34:55 --> Total execution time: 0.0545
DEBUG - 2021-11-07 16:04:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:04:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 16:04:55 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 16:04:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:04:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:04:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 16:04:56 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 16:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:34:56 --> Total execution time: 0.0537
DEBUG - 2021-11-07 16:05:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:35:00 --> Total execution time: 0.0472
DEBUG - 2021-11-07 16:05:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:35:04 --> Total execution time: 0.0462
DEBUG - 2021-11-07 16:05:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:35:06 --> Total execution time: 0.0523
DEBUG - 2021-11-07 16:05:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:35:11 --> Total execution time: 0.0451
DEBUG - 2021-11-07 16:05:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:35:39 --> Total execution time: 0.0487
DEBUG - 2021-11-07 16:05:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 16:05:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:35:39 --> Total execution time: 0.0662
DEBUG - 2021-11-07 16:05:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:05:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 16:05:40 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 16:05:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 16:05:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:05:44 --> No URI present. Default controller set.
DEBUG - 2021-11-07 16:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:35:44 --> Total execution time: 0.0476
DEBUG - 2021-11-07 16:05:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:05:44 --> UTF-8 Support Enabled
ERROR - 2021-11-07 16:05:44 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-07 16:05:44 --> No URI present. Default controller set.
DEBUG - 2021-11-07 16:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:35:44 --> Total execution time: 0.0571
DEBUG - 2021-11-07 16:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:36:08 --> Total execution time: 0.0586
DEBUG - 2021-11-07 16:06:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:36:28 --> Total execution time: 0.0617
DEBUG - 2021-11-07 16:07:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:37:14 --> Total execution time: 0.0542
DEBUG - 2021-11-07 16:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:38:19 --> Total execution time: 0.0723
DEBUG - 2021-11-07 16:08:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:38:24 --> Total execution time: 0.0598
DEBUG - 2021-11-07 16:11:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:41:20 --> Total execution time: 0.0791
DEBUG - 2021-11-07 16:11:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:41:43 --> Total execution time: 0.0588
DEBUG - 2021-11-07 16:13:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:43:35 --> Total execution time: 0.0586
DEBUG - 2021-11-07 16:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:44:52 --> Total execution time: 0.0999
DEBUG - 2021-11-07 16:15:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:45:04 --> Total execution time: 0.0587
DEBUG - 2021-11-07 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:15:14 --> UTF-8 Support Enabled
ERROR - 2021-11-07 16:15:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 16:15:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 16:15:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:15:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 16:15:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:15:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 16:15:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 16:15:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:45:57 --> Total execution time: 0.0857
DEBUG - 2021-11-07 16:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 16:15:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 16:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 16:15:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 16:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 16:15:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 16:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-07 16:15:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-07 16:16:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:46:20 --> Total execution time: 0.0510
DEBUG - 2021-11-07 16:16:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:46:24 --> Total execution time: 0.0630
DEBUG - 2021-11-07 16:16:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:46:28 --> Total execution time: 0.0681
DEBUG - 2021-11-07 16:16:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:46:31 --> Total execution time: 0.0578
DEBUG - 2021-11-07 16:16:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-07 16:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-07 16:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-07 20:46:32 --> Total execution time: 0.0535
