<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-12 00:05:10 --> Total execution time: 0.9221
DEBUG - 2022-05-12 04:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 04:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 04:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 04:59:31 --> Total execution time: 1.3861
DEBUG - 2022-05-12 04:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 04:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 04:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 04:59:49 --> Total execution time: 0.7927
DEBUG - 2022-05-12 05:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 05:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:30:08 --> Total execution time: 0.0916
DEBUG - 2022-05-12 05:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:30:42 --> Total execution time: 3.4168
DEBUG - 2022-05-12 05:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 05:01:06 --> Total execution time: 0.7959
DEBUG - 2022-05-12 05:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 05:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:31:13 --> Total execution time: 0.0818
DEBUG - 2022-05-12 05:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 05:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:31:32 --> Total execution time: 2.6251
DEBUG - 2022-05-12 10:31:56 --> Total execution time: 2.6514
DEBUG - 2022-05-12 05:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:32:26 --> Total execution time: 2.5787
DEBUG - 2022-05-12 05:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:32:49 --> Total execution time: 3.4677
DEBUG - 2022-05-12 05:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 05:02:57 --> Total execution time: 0.0292
DEBUG - 2022-05-12 05:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 05:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:33:25 --> Total execution time: 0.0307
DEBUG - 2022-05-12 05:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:34:33 --> Total execution time: 3.6051
DEBUG - 2022-05-12 05:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:04:35 --> No URI present. Default controller set.
DEBUG - 2022-05-12 05:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:34:35 --> Total execution time: 0.1255
DEBUG - 2022-05-12 05:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:04:38 --> No URI present. Default controller set.
DEBUG - 2022-05-12 05:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:34:38 --> Total execution time: 0.0404
DEBUG - 2022-05-12 05:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:34:59 --> Total execution time: 0.0415
DEBUG - 2022-05-12 05:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 05:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:35:37 --> Total execution time: 0.0997
DEBUG - 2022-05-12 05:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:22:43 --> No URI present. Default controller set.
DEBUG - 2022-05-12 05:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:52:44 --> Total execution time: 1.1468
DEBUG - 2022-05-12 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:53:24 --> Total execution time: 0.0529
DEBUG - 2022-05-12 05:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 05:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 05:24:26 --> Total execution time: 0.0331
DEBUG - 2022-05-12 05:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:24:36 --> No URI present. Default controller set.
DEBUG - 2022-05-12 05:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:54:36 --> Total execution time: 0.0683
DEBUG - 2022-05-12 05:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:54:48 --> Total execution time: 0.0326
DEBUG - 2022-05-12 05:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 05:24:55 --> Total execution time: 0.0356
DEBUG - 2022-05-12 05:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 10:54:56 --> Total execution time: 0.0321
DEBUG - 2022-05-12 08:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 08:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 08:08:37 --> Total execution time: 0.0405
DEBUG - 2022-05-12 15:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 15:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 15:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 15:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 15:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 15:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-12 15:29:07 --> Total execution time: 0.0403
