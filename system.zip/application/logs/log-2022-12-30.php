<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-30 00:09:09 --> Total execution time: 0.0652
DEBUG - 2022-12-30 00:12:09 --> Total execution time: 0.0764
DEBUG - 2022-12-30 00:12:22 --> Total execution time: 0.0764
DEBUG - 2022-12-30 00:12:31 --> Total execution time: 0.0666
DEBUG - 2022-12-30 00:12:43 --> Total execution time: 0.0734
DEBUG - 2022-12-30 00:12:50 --> Total execution time: 0.0824
DEBUG - 2022-12-30 00:13:22 --> Total execution time: 0.0656
DEBUG - 2022-12-30 00:15:31 --> Total execution time: 0.0936
DEBUG - 2022-12-30 00:16:11 --> Total execution time: 0.0821
DEBUG - 2022-12-30 00:18:40 --> Total execution time: 0.0981
DEBUG - 2022-12-30 00:23:29 --> Total execution time: 0.1038
DEBUG - 2022-12-30 00:23:41 --> Total execution time: 0.1049
DEBUG - 2022-12-30 00:23:41 --> Total execution time: 0.0676
DEBUG - 2022-12-30 00:24:24 --> Total execution time: 0.1029
DEBUG - 2022-12-30 00:24:58 --> Total execution time: 0.0925
DEBUG - 2022-12-30 00:25:00 --> Total execution time: 0.0631
DEBUG - 2022-12-30 01:52:14 --> Total execution time: 0.1330
DEBUG - 2022-12-30 01:53:07 --> Total execution time: 0.0727
DEBUG - 2022-12-30 01:53:56 --> Total execution time: 0.0640
DEBUG - 2022-12-30 01:54:23 --> Total execution time: 0.0651
ERROR - 2022-12-30 01:57:21 --> Severity: Notice --> Undefined property: stdClass::$p_sl_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\account\donate-list.php 97
DEBUG - 2022-12-30 01:57:21 --> Total execution time: 0.0944
ERROR - 2022-12-30 01:58:16 --> Severity: Notice --> Undefined property: stdClass::$p_sl_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\account\donate-list.php 97
DEBUG - 2022-12-30 01:58:16 --> Total execution time: 0.0716
ERROR - 2022-12-30 01:59:03 --> Severity: Notice --> Undefined property: stdClass::$p_sl_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\account\donate-list.php 97
DEBUG - 2022-12-30 01:59:03 --> Total execution time: 0.0730
DEBUG - 2022-12-30 01:59:36 --> Total execution time: 0.0737
DEBUG - 2022-12-30 02:00:39 --> Total execution time: 0.0818
DEBUG - 2022-12-30 02:01:24 --> Total execution time: 0.0878
DEBUG - 2022-12-30 02:03:04 --> Total execution time: 0.1001
DEBUG - 2022-12-30 02:03:35 --> Total execution time: 0.1025
DEBUG - 2022-12-30 02:04:01 --> Total execution time: 0.0674
DEBUG - 2022-12-30 09:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 09:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 09:19:55 --> Total execution time: 0.0640
DEBUG - 2022-12-30 09:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 09:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 13:50:04 --> Total execution time: 0.1108
DEBUG - 2022-12-30 09:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:20:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 13:51:27 --> Total execution time: 0.0803
DEBUG - 2022-12-30 09:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:21:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:21:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:24:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-30 13:54:02 --> Severity: Notice --> Undefined property: stdClass::$don_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\account\donate-list.php 114
DEBUG - 2022-12-30 13:54:02 --> Total execution time: 0.0812
DEBUG - 2022-12-30 09:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:24:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 13:54:25 --> Total execution time: 0.0677
DEBUG - 2022-12-30 09:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:24:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 13:55:27 --> Total execution time: 0.0585
DEBUG - 2022-12-30 09:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:25:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 13:58:44 --> Total execution time: 0.0506
DEBUG - 2022-12-30 09:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:28:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:28:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:01:30 --> Total execution time: 0.0638
DEBUG - 2022-12-30 09:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:31:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:31:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:01:35 --> Total execution time: 0.0814
DEBUG - 2022-12-30 09:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:31:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:31:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:02:19 --> Total execution time: 0.0522
DEBUG - 2022-12-30 09:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:32:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:32:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:46:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:46:14 --> Severity: error --> Exception: syntax error, unexpected 'd' (T_STRING) C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\Donate_Controller.php 84
DEBUG - 2022-12-30 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:16:38 --> Total execution time: 0.0559
DEBUG - 2022-12-30 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:46:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:46:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:46:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:46:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:46:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:46:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:46:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:46:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:46:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 09:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 09:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 09:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:22:53 --> Total execution time: 0.0765
DEBUG - 2022-12-30 09:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:52:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:52:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:52:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:52:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:52:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:52:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:52:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:52:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:52:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 09:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:23:03 --> Total execution time: 0.0556
DEBUG - 2022-12-30 09:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:53:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:53:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:53:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:53:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:53:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:53:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:53:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:53:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:53:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:53:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-30 14:23:05 --> Severity: Notice --> Undefined variable: list C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\Donate_Controller.php 87
ERROR - 2022-12-30 14:23:05 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\Donate_Controller.php 87
ERROR - 2022-12-30 14:23:05 --> Severity: Notice --> Undefined variable: list C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\Donate_Controller.php 87
ERROR - 2022-12-30 14:23:05 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\Donate_Controller.php 87
DEBUG - 2022-12-30 14:23:05 --> Total execution time: 0.0812
DEBUG - 2022-12-30 09:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:23:15 --> Total execution time: 0.0547
DEBUG - 2022-12-30 09:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:53:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:53:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:53:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:53:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:53:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:53:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:53:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:53:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:53:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:23:17 --> Total execution time: 0.0541
DEBUG - 2022-12-30 09:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:23:33 --> Total execution time: 0.0562
DEBUG - 2022-12-30 09:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:23:54 --> Total execution time: 0.0498
DEBUG - 2022-12-30 09:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:24:03 --> Total execution time: 0.0623
DEBUG - 2022-12-30 09:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:24:15 --> Total execution time: 0.0639
DEBUG - 2022-12-30 09:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:24:58 --> Total execution time: 0.0699
DEBUG - 2022-12-30 09:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:25:07 --> Total execution time: 0.0549
DEBUG - 2022-12-30 09:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:25:41 --> Total execution time: 0.0549
DEBUG - 2022-12-30 09:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:55:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:55:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:55:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:55:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:55:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:55:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:55:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:55:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:55:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:55:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:55:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:55:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:55:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:55:42 --> UTF-8 Support Enabled
ERROR - 2022-12-30 09:55:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:55:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:55:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:55:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:55:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:25:43 --> Total execution time: 0.0651
DEBUG - 2022-12-30 09:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:26:01 --> Total execution time: 0.0612
DEBUG - 2022-12-30 09:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:02 --> UTF-8 Support Enabled
ERROR - 2022-12-30 09:56:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:56:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:56:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:26:03 --> Total execution time: 0.0738
DEBUG - 2022-12-30 09:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:26:26 --> Total execution time: 0.0687
DEBUG - 2022-12-30 09:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:56:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:56:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:56:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:26:29 --> Total execution time: 0.0502
DEBUG - 2022-12-30 09:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:26:48 --> Total execution time: 0.0580
DEBUG - 2022-12-30 09:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:48 --> UTF-8 Support Enabled
ERROR - 2022-12-30 09:56:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:56:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:49 --> UTF-8 Support Enabled
ERROR - 2022-12-30 09:56:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:56:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:56:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-30 14:26:50 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\Donate_Controller.php 72
DEBUG - 2022-12-30 14:26:50 --> Total execution time: 0.0911
DEBUG - 2022-12-30 09:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:27:00 --> Total execution time: 0.0642
DEBUG - 2022-12-30 09:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:57:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:57:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:57:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:57:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:57:00 --> UTF-8 Support Enabled
ERROR - 2022-12-30 09:57:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:57:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:57:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:57:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 09:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:57:00 --> UTF-8 Support Enabled
ERROR - 2022-12-30 09:57:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:57:00 --> UTF-8 Support Enabled
ERROR - 2022-12-30 09:57:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 09:57:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:57:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:57:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:57:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 09:57:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 09:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 09:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 09:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 09:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:27:01 --> Total execution time: 0.0737
DEBUG - 2022-12-30 10:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:30:03 --> Total execution time: 0.0609
DEBUG - 2022-12-30 10:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:00:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:00:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:30:04 --> Total execution time: 0.0695
DEBUG - 2022-12-30 10:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:30:52 --> Total execution time: 0.1015
DEBUG - 2022-12-30 10:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:00:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:30:55 --> Total execution time: 0.0793
DEBUG - 2022-12-30 10:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:00:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:31:12 --> Total execution time: 0.0482
DEBUG - 2022-12-30 10:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:02:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:02:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:02:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 10:02:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:02:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:02:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 10:02:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:02:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:33:06 --> Total execution time: 0.0604
DEBUG - 2022-12-30 10:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:03:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:03:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:03:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 10:03:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:03:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:03:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:03:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 10:03:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:03:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:03:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:33:09 --> Total execution time: 0.0480
DEBUG - 2022-12-30 10:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:33:24 --> Total execution time: 0.0769
DEBUG - 2022-12-30 10:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:03:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:03:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:35:31 --> Total execution time: 0.0749
DEBUG - 2022-12-30 10:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:05:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:05:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:35:36 --> Total execution time: 0.0690
DEBUG - 2022-12-30 10:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:35:36 --> Total execution time: 0.0656
DEBUG - 2022-12-30 10:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:36:47 --> Total execution time: 0.0680
DEBUG - 2022-12-30 10:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:06:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:37:14 --> Total execution time: 0.0800
DEBUG - 2022-12-30 10:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:07:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:07:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:37:27 --> Total execution time: 0.0529
DEBUG - 2022-12-30 10:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:07:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:07:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:37:31 --> Total execution time: 0.0575
DEBUG - 2022-12-30 10:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:07:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:07:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:42:01 --> Total execution time: 0.0721
DEBUG - 2022-12-30 10:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:12:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:12:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 10:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:42:23 --> Total execution time: 0.0702
DEBUG - 2022-12-30 10:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:12:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:12:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:45:03 --> Total execution time: 0.0681
DEBUG - 2022-12-30 10:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:15:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:15:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:46:01 --> Total execution time: 0.0667
DEBUG - 2022-12-30 10:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:16:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:16:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:47:07 --> Total execution time: 0.0711
DEBUG - 2022-12-30 10:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:17:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:17:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:17:22 --> UTF-8 Support Enabled
ERROR - 2022-12-30 10:17:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:17:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:17:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 10:17:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:17:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:17:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 10:17:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:48:18 --> Total execution time: 0.0846
DEBUG - 2022-12-30 10:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:18:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:18:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:18:19 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 10:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:18:19 --> UTF-8 Support Enabled
ERROR - 2022-12-30 10:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:18:19 --> UTF-8 Support Enabled
ERROR - 2022-12-30 10:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:18:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:49:42 --> Total execution time: 0.0744
DEBUG - 2022-12-30 10:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:19:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:19:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:19:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:19:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 10:19:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:19:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 10:19:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:19:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:19:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:19:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:19:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 10:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:50:07 --> Total execution time: 0.0741
DEBUG - 2022-12-30 10:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:20:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:52:41 --> Total execution time: 0.0715
DEBUG - 2022-12-30 10:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:22:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:52:42 --> Total execution time: 0.0519
DEBUG - 2022-12-30 10:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:55:14 --> Total execution time: 0.0755
DEBUG - 2022-12-30 10:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:25:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:55:16 --> Total execution time: 0.0500
DEBUG - 2022-12-30 10:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:56:22 --> Total execution time: 0.0635
DEBUG - 2022-12-30 10:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:26:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:26:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 14:56:51 --> Total execution time: 0.0635
DEBUG - 2022-12-30 10:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:26:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:26:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 15:00:24 --> Total execution time: 0.0792
DEBUG - 2022-12-30 10:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:30:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:30:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 15:00:27 --> Total execution time: 0.0590
DEBUG - 2022-12-30 10:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:30:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 15:00:28 --> Total execution time: 0.0608
DEBUG - 2022-12-30 10:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:30:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:30:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 15:00:30 --> Total execution time: 0.0557
DEBUG - 2022-12-30 10:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:30:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:30:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 15:01:01 --> Total execution time: 0.0593
DEBUG - 2022-12-30 10:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:31:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:31:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 15:05:21 --> Total execution time: 0.0696
DEBUG - 2022-12-30 10:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:35:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 15:08:10 --> Total execution time: 0.0727
DEBUG - 2022-12-30 10:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:38:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 10:38:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 10:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 10:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 10:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 10:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 10:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 12:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:30:06 --> Total execution time: 0.6557
DEBUG - 2022-12-30 12:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:00:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:00:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:30:08 --> Total execution time: 0.1026
DEBUG - 2022-12-30 12:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:31:24 --> Total execution time: 0.2243
DEBUG - 2022-12-30 12:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:01:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 12:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 12:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 12:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 12:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 12:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:41:20 --> Total execution time: 0.0867
DEBUG - 2022-12-30 12:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:11:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:42:55 --> Total execution time: 0.0767
DEBUG - 2022-12-30 12:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:12:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:12:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:43:24 --> Total execution time: 0.0792
DEBUG - 2022-12-30 12:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:13:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:13:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:43:53 --> Total execution time: 0.1314
DEBUG - 2022-12-30 12:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:13:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:13:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:44:31 --> Total execution time: 0.0675
DEBUG - 2022-12-30 12:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:14:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:14:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:45:03 --> Total execution time: 0.0638
DEBUG - 2022-12-30 12:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:15:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:15:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:45:14 --> Total execution time: 0.0798
DEBUG - 2022-12-30 12:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:15:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:15:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:45:45 --> Total execution time: 0.0733
DEBUG - 2022-12-30 12:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:15:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:15:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:46:59 --> Total execution time: 0.0677
DEBUG - 2022-12-30 12:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:16:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:16:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:47:21 --> Total execution time: 0.0680
DEBUG - 2022-12-30 12:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:17:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:48:36 --> Total execution time: 0.0935
DEBUG - 2022-12-30 12:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:18:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:49:50 --> Total execution time: 0.0891
DEBUG - 2022-12-30 12:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:19:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:19:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:19:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:19:54 --> UTF-8 Support Enabled
ERROR - 2022-12-30 12:19:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:19:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:19:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:19:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:19:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:19:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:50:21 --> Total execution time: 0.0667
DEBUG - 2022-12-30 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:21 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:20:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:21 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:20:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:20:21 --> UTF-8 Support Enabled
ERROR - 2022-12-30 12:20:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:21 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:20:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:50:44 --> Total execution time: 0.1262
DEBUG - 2022-12-30 12:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:20:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:20:45 --> UTF-8 Support Enabled
ERROR - 2022-12-30 12:20:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:20:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 16:50:52 --> Total execution time: 0.0699
DEBUG - 2022-12-30 12:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:20:52 --> UTF-8 Support Enabled
ERROR - 2022-12-30 12:20:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:20:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:20:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:20:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:20:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:20:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:20:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:08:38 --> Total execution time: 0.4239
DEBUG - 2022-12-30 12:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:38:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:38:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:09:05 --> Total execution time: 0.0755
DEBUG - 2022-12-30 12:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:39:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:39:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:09:15 --> Total execution time: 0.0902
DEBUG - 2022-12-30 12:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:39:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:39:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:09:22 --> Total execution time: 0.0770
DEBUG - 2022-12-30 12:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:39:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:09:30 --> Total execution time: 0.0713
DEBUG - 2022-12-30 12:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:39:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:39:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:09:41 --> Total execution time: 0.0902
DEBUG - 2022-12-30 12:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:39:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:39:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:09:53 --> Total execution time: 0.0693
DEBUG - 2022-12-30 12:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:39:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:39:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:09:58 --> Total execution time: 0.0805
DEBUG - 2022-12-30 12:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:39:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:39:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:10:04 --> Total execution time: 0.0903
DEBUG - 2022-12-30 12:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:40:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:11:15 --> Total execution time: 0.0756
DEBUG - 2022-12-30 12:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:41:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:41:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:12:18 --> Total execution time: 0.1080
DEBUG - 2022-12-30 12:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:42:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:42:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:12:20 --> Total execution time: 0.1014
DEBUG - 2022-12-30 12:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:42:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:12:21 --> Total execution time: 0.0960
DEBUG - 2022-12-30 12:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:12:21 --> Total execution time: 0.1144
DEBUG - 2022-12-30 12:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:42:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:42:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:42:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:12:43 --> Total execution time: 0.0883
DEBUG - 2022-12-30 12:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:42:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:42:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:13:00 --> Total execution time: 0.0680
DEBUG - 2022-12-30 12:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:43:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:43:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:13:14 --> Total execution time: 0.1037
DEBUG - 2022-12-30 12:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:43:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:43:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:13:20 --> Total execution time: 0.0968
DEBUG - 2022-12-30 12:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:43:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:43:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:15:27 --> Total execution time: 0.0821
DEBUG - 2022-12-30 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:45:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:45:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:15:50 --> Total execution time: 0.0717
DEBUG - 2022-12-30 12:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:45:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:45:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:21:59 --> Total execution time: 0.0681
DEBUG - 2022-12-30 12:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:51:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:51:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:22:41 --> Total execution time: 0.0684
DEBUG - 2022-12-30 12:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:52:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:52:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:22:52 --> Total execution time: 0.0719
DEBUG - 2022-12-30 12:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:52:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:52:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:23:16 --> Total execution time: 0.0872
DEBUG - 2022-12-30 12:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:53:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:53:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:23:29 --> Total execution time: 0.0743
DEBUG - 2022-12-30 12:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:53:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:23:38 --> Total execution time: 0.0727
DEBUG - 2022-12-30 12:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:53:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:53:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:53:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:53:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:53:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:53:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:53:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:53:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:53:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:53:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:53:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:24:09 --> Total execution time: 0.0609
DEBUG - 2022-12-30 12:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:09 --> UTF-8 Support Enabled
ERROR - 2022-12-30 12:54:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:54:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:24:22 --> Total execution time: 0.0893
DEBUG - 2022-12-30 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:54:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:54:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:23 --> UTF-8 Support Enabled
ERROR - 2022-12-30 12:54:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:23 --> UTF-8 Support Enabled
ERROR - 2022-12-30 12:54:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:24:39 --> Total execution time: 0.1210
DEBUG - 2022-12-30 12:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:54:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:39 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-30 12:54:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:54:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:54:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:54:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:24:50 --> Total execution time: 0.0769
DEBUG - 2022-12-30 12:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:54:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:54:51 --> UTF-8 Support Enabled
ERROR - 2022-12-30 12:54:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 12:54:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:54:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:54:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 12:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:26:34 --> Total execution time: 0.0738
DEBUG - 2022-12-30 12:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:56:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:56:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:26:46 --> Total execution time: 0.0788
DEBUG - 2022-12-30 12:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:56:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:56:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:26:54 --> Total execution time: 0.0907
DEBUG - 2022-12-30 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:56:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:27:21 --> Total execution time: 0.1004
DEBUG - 2022-12-30 12:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:57:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:57:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:27:46 --> Total execution time: 0.0807
DEBUG - 2022-12-30 12:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:57:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:57:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:28:05 --> Total execution time: 0.0670
DEBUG - 2022-12-30 12:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:58:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:58:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:28:30 --> Total execution time: 0.0788
DEBUG - 2022-12-30 12:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:58:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:58:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:28:46 --> Total execution time: 0.0789
DEBUG - 2022-12-30 12:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:58:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:58:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:28:56 --> Total execution time: 0.0840
DEBUG - 2022-12-30 12:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:58:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:58:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 12:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 12:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 12:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:29:52 --> Total execution time: 0.0802
DEBUG - 2022-12-30 12:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 12:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 12:59:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:30:57 --> Total execution time: 0.0928
DEBUG - 2022-12-30 13:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:00:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:31:08 --> Total execution time: 0.0656
DEBUG - 2022-12-30 13:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:01:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:32:07 --> Total execution time: 0.0669
DEBUG - 2022-12-30 13:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:02:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:35:29 --> Total execution time: 0.0763
DEBUG - 2022-12-30 13:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:05:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:35:40 --> Total execution time: 0.0794
DEBUG - 2022-12-30 13:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:05:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:05:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:35:46 --> Total execution time: 0.0722
DEBUG - 2022-12-30 13:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:05:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:05:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:35:52 --> Total execution time: 0.0777
DEBUG - 2022-12-30 13:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:05:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:05:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:36:23 --> Total execution time: 0.0653
DEBUG - 2022-12-30 13:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:06:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:36:42 --> Total execution time: 0.0838
DEBUG - 2022-12-30 13:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:06:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:06:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:37:43 --> Total execution time: 0.0989
DEBUG - 2022-12-30 13:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:07:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:10:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-30 17:40:45 --> Severity: Notice --> Undefined variable: CI C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 141
ERROR - 2022-12-30 17:40:45 --> Severity: Notice --> Trying to get property 'db' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 141
ERROR - 2022-12-30 17:40:45 --> Severity: error --> Exception: Call to a member function select_sum() on null C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 141
DEBUG - 2022-12-30 13:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:10:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:10:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:41:00 --> Total execution time: 0.0671
DEBUG - 2022-12-30 13:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:11:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:11:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:41:19 --> Total execution time: 0.0789
DEBUG - 2022-12-30 13:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:11:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:41:33 --> Total execution time: 0.0715
DEBUG - 2022-12-30 13:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:11:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:11:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:41:42 --> Total execution time: 0.0710
DEBUG - 2022-12-30 13:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:11:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:47:14 --> Total execution time: 0.0736
DEBUG - 2022-12-30 13:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:17:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:47:29 --> Total execution time: 0.1291
DEBUG - 2022-12-30 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:17:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:17:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:47:32 --> Total execution time: 0.1112
DEBUG - 2022-12-30 13:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:17:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:19:27 --> No URI present. Default controller set.
DEBUG - 2022-12-30 13:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:49:27 --> Total execution time: 0.2066
DEBUG - 2022-12-30 13:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:49:33 --> Total execution time: 0.0793
DEBUG - 2022-12-30 13:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:49:36 --> Total execution time: 0.0735
DEBUG - 2022-12-30 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:49:51 --> Total execution time: 0.0675
DEBUG - 2022-12-30 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:19:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:19:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:49:53 --> Total execution time: 0.0881
DEBUG - 2022-12-30 13:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:19:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:19:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:51:01 --> Total execution time: 0.0726
DEBUG - 2022-12-30 13:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:21:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:33:32 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 13:33:32 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 13:33:32 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:33:32 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 13:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 18:03:34 --> Total execution time: 0.0762
DEBUG - 2022-12-30 13:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:33:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:33:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 13:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:33:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:33:35 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 13:33:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 13:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:33:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:33:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 13:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 18:04:13 --> Total execution time: 0.0729
DEBUG - 2022-12-30 13:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:34:13 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 13:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:34:13 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 13:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:34:13 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 13:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:34:13 --> 404 Page Not Found: Get-affiliate-details/index
ERROR - 2022-12-30 13:34:13 --> 404 Page Not Found: Reg-get-package-details/index
DEBUG - 2022-12-30 13:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:34:13 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 13:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 13:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 18:04:35 --> Total execution time: 0.0666
DEBUG - 2022-12-30 13:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:34:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 13:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 13:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:34:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 13:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 13:34:35 --> UTF-8 Support Enabled
ERROR - 2022-12-30 13:34:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 13:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 13:34:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 17:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 17:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 17:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 17:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 17:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:47:53 --> Total execution time: 0.1196
DEBUG - 2022-12-30 17:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 17:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 17:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 17:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 17:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:47:55 --> Total execution time: 0.0541
DEBUG - 2022-12-30 17:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 17:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 17:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 17:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 17:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 17:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 22:18:05 --> Total execution time: 0.0959
DEBUG - 2022-12-30 17:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:48:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 17:48:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 17:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:48:10 --> No URI present. Default controller set.
DEBUG - 2022-12-30 17:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 17:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 17:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 22:18:10 --> Total execution time: 0.0986
DEBUG - 2022-12-30 17:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 17:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 17:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 22:18:13 --> Total execution time: 0.0819
DEBUG - 2022-12-30 17:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 17:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 17:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 22:18:42 --> Total execution time: 0.0564
DEBUG - 2022-12-30 17:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 17:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 17:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 22:23:37 --> Total execution time: 0.0713
DEBUG - 2022-12-30 17:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 17:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 17:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 22:27:49 --> Total execution time: 0.0620
DEBUG - 2022-12-30 17:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 17:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 17:57:51 --> UTF-8 Support Enabled
ERROR - 2022-12-30 17:57:51 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 17:57:51 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 17:57:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 17:57:51 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 17:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 17:57:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 17:57:51 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 22:30:42 --> Total execution time: 0.0637
DEBUG - 2022-12-30 18:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:00:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:00:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:00:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:00:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 22:30:59 --> Total execution time: 0.0713
DEBUG - 2022-12-30 18:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:00:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:00:59 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:01:00 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 18:01:00 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:01:00 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 22:33:32 --> Total execution time: 0.1287
DEBUG - 2022-12-30 18:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:03:33 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:03:33 --> UTF-8 Support Enabled
ERROR - 2022-12-30 18:03:33 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:03:33 --> UTF-8 Support Enabled
ERROR - 2022-12-30 18:03:33 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:03:33 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 22:34:31 --> Total execution time: 0.0732
DEBUG - 2022-12-30 18:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:04:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:04:31 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 18:04:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:04:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 22:35:51 --> Total execution time: 0.0746
DEBUG - 2022-12-30 18:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:05:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:05:51 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:05:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:05:51 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:05:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:05:51 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:05:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:05:51 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 22:37:54 --> Total execution time: 0.0860
DEBUG - 2022-12-30 18:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:07:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:07:55 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:07:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:07:55 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 18:07:55 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:07:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:07:55 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 22:38:55 --> Total execution time: 0.0729
DEBUG - 2022-12-30 18:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:08:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:08:55 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:08:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:08:55 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 18:08:55 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:08:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:08:55 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 22:39:36 --> Total execution time: 0.0671
DEBUG - 2022-12-30 18:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:09:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:09:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:09:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:09:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:09:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:09:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:09:37 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:02:17 --> Total execution time: 0.0660
DEBUG - 2022-12-30 18:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:32:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:32:17 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:32:17 --> UTF-8 Support Enabled
ERROR - 2022-12-30 18:32:17 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:32:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:32:17 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:32:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:32:17 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:02:50 --> Total execution time: 0.0631
DEBUG - 2022-12-30 18:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:02:53 --> Total execution time: 0.0590
DEBUG - 2022-12-30 18:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:02:54 --> Total execution time: 0.0533
DEBUG - 2022-12-30 18:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:03:02 --> Total execution time: 0.0560
DEBUG - 2022-12-30 18:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:03:02 --> Total execution time: 0.0545
DEBUG - 2022-12-30 18:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:03:03 --> Total execution time: 0.0532
DEBUG - 2022-12-30 18:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:04:11 --> Total execution time: 0.0661
DEBUG - 2022-12-30 18:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:34:11 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:34:11 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 18:34:11 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:34:12 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:04:14 --> Total execution time: 0.0633
DEBUG - 2022-12-30 18:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:04:45 --> Total execution time: 0.0713
DEBUG - 2022-12-30 18:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:34:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:34:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:34:45 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 18:34:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:34:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:04:48 --> Total execution time: 0.0603
DEBUG - 2022-12-30 18:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:04:50 --> Total execution time: 0.0587
DEBUG - 2022-12-30 18:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:04:50 --> Total execution time: 0.0554
DEBUG - 2022-12-30 18:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:04:50 --> Total execution time: 0.0560
DEBUG - 2022-12-30 18:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:05:11 --> Total execution time: 0.0631
DEBUG - 2022-12-30 18:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:35:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:35:11 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:35:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:35:11 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 18:35:11 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:35:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:35:11 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:06:57 --> Total execution time: 0.0720
DEBUG - 2022-12-30 18:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:36:58 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:36:58 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:36:58 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:36:58 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:07:30 --> Total execution time: 0.0837
DEBUG - 2022-12-30 18:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:37:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:37:30 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 18:37:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:37:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:08:12 --> Total execution time: 0.0661
DEBUG - 2022-12-30 18:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:22:45 --> Total execution time: 0.0767
DEBUG - 2022-12-30 18:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:52:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:52:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:52:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:52:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:23:05 --> Total execution time: 0.0766
DEBUG - 2022-12-30 18:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:23:21 --> Total execution time: 0.0627
DEBUG - 2022-12-30 18:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:53:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:53:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:53:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:53:21 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 18:53:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:53:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:53:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:23:51 --> Total execution time: 0.0639
DEBUG - 2022-12-30 18:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:53:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:53:51 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:53:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:53:51 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 18:53:51 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:53:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:53:51 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:24:12 --> Total execution time: 0.0794
DEBUG - 2022-12-30 18:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:24:34 --> Total execution time: 0.0638
DEBUG - 2022-12-30 18:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:54:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:54:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:54:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:54:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:54:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:25:22 --> Total execution time: 0.0716
DEBUG - 2022-12-30 18:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:55:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:55:22 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:55:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:55:23 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 18:55:23 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:55:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:55:23 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:25:40 --> Total execution time: 0.0711
DEBUG - 2022-12-30 18:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:26:05 --> Total execution time: 0.0635
DEBUG - 2022-12-30 18:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:26:16 --> Total execution time: 0.0632
DEBUG - 2022-12-30 18:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:26:21 --> Total execution time: 0.0584
DEBUG - 2022-12-30 18:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:27:25 --> Total execution time: 0.0663
DEBUG - 2022-12-30 18:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:57:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:57:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:57:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:57:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 18:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:29:20 --> Total execution time: 0.0722
DEBUG - 2022-12-30 18:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:29:26 --> Total execution time: 0.0643
DEBUG - 2022-12-30 18:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 18:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 18:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:29:38 --> Total execution time: 0.1666
DEBUG - 2022-12-30 18:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 18:59:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 18:59:38 --> 404 Page Not Found: User/dashboard
DEBUG - 2022-12-30 19:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:05:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:05:13 --> 404 Page Not Found: User/dashboard
DEBUG - 2022-12-30 19:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:05:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:05:21 --> 404 Page Not Found: fundraiser/Dashboard/index
DEBUG - 2022-12-30 19:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:05:35 --> 404 Page Not Found: fundraiser/Dashboard/index
DEBUG - 2022-12-30 19:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:05:35 --> 404 Page Not Found: fundraiser/Dashboard/index
DEBUG - 2022-12-30 19:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:06:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:06:58 --> 404 Page Not Found: fundraiser/Dashboard/index
DEBUG - 2022-12-30 19:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:07:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:07:08 --> 404 Page Not Found: fundraiser/Dashboard/index
DEBUG - 2022-12-30 19:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:37:11 --> Total execution time: 0.0600
DEBUG - 2022-12-30 19:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:37:25 --> Total execution time: 0.0582
DEBUG - 2022-12-30 19:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:37:31 --> Total execution time: 0.0629
DEBUG - 2022-12-30 19:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:07:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:07:59 --> 404 Page Not Found: fundraiser/Dashboard/index
DEBUG - 2022-12-30 19:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:08:31 --> 404 Page Not Found: fundraiser/Dashboard/index
DEBUG - 2022-12-30 19:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:08:43 --> 404 Page Not Found: fundraiser/Dashboard/index
DEBUG - 2022-12-30 19:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:08:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:08:45 --> 404 Page Not Found: fundraiser/Dashboard/index
DEBUG - 2022-12-30 19:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:09:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:09:11 --> 404 Page Not Found: fundraiser/Dashboard/index
DEBUG - 2022-12-30 19:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:09:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:09:35 --> 404 Page Not Found: fundraiser/Dashboard/index
DEBUG - 2022-12-30 19:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:09:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:09:54 --> 404 Page Not Found: fundraiser/Dashboard/index
DEBUG - 2022-12-30 19:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:10:30 --> Total execution time: 0.0681
DEBUG - 2022-12-30 19:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:10:47 --> Total execution time: 0.0598
DEBUG - 2022-12-30 19:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:10:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:10:50 --> 404 Page Not Found: fundraiser/Dashboard/index
DEBUG - 2022-12-30 19:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:10:56 --> Total execution time: 0.0606
DEBUG - 2022-12-30 19:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:11:23 --> Total execution time: 0.0609
DEBUG - 2022-12-30 19:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:11:35 --> Total execution time: 0.0800
DEBUG - 2022-12-30 19:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:11:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-30 19:11:50 --> Severity: Warning --> Use of undefined constant FR_ID - assumed 'FR_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Dashboard_Controller.php 9
DEBUG - 2022-12-30 19:11:50 --> Total execution time: 0.0774
DEBUG - 2022-12-30 19:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:42:10 --> Total execution time: 0.0697
DEBUG - 2022-12-30 19:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:12:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:12:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:12:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:12:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:12:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:12:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:12:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:12:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:42:36 --> Total execution time: 0.0631
DEBUG - 2022-12-30 19:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:12:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:12:37 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:12:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:12:37 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 19:12:37 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:12:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:12:37 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:43:06 --> Total execution time: 0.0617
DEBUG - 2022-12-30 19:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:13:06 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:13:06 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:13:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:13:06 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:13:06 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:43:11 --> Total execution time: 0.0619
DEBUG - 2022-12-30 19:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:13:12 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:13:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:13:12 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 19:13:12 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:13:12 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:43:14 --> Total execution time: 0.0639
DEBUG - 2022-12-30 19:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:13:14 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:13:14 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 19:13:14 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:13:14 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:43:57 --> Total execution time: 0.0728
DEBUG - 2022-12-30 19:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:44:04 --> Total execution time: 0.2280
DEBUG - 2022-12-30 19:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 23:44:04 --> Total execution time: 0.0718
DEBUG - 2022-12-30 19:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:37:56 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:37:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:37:56 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-30 19:37:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:37:56 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:37:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:37:56 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:37:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:37:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:38:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 19:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:39:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:39:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 19:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:42:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 19:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:46:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:46:39 --> 404 Page Not Found: Sukalyan/index
ERROR - 2022-12-30 19:46:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 19:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:46:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:46:47 --> 404 Page Not Found: Sukalyan/index
DEBUG - 2022-12-30 19:46:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:46:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 19:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:47:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:47:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:47:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:47:01 --> UTF-8 Support Enabled
ERROR - 2022-12-30 19:47:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:47:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:47:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:47:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:47:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:47:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:47:01 --> UTF-8 Support Enabled
ERROR - 2022-12-30 19:47:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:47:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:47:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:47:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 19:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:47:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:47:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:47:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:47:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:47:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:47:18 --> UTF-8 Support Enabled
ERROR - 2022-12-30 19:47:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:47:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:47:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:48:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:48:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 19:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:48:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:48:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:48:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:48:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:48:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:48:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 19:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:48:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:48:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:48:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:48:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:48:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:48:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:48:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:48:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:48:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:50:10 --> No URI present. Default controller set.
DEBUG - 2022-12-30 19:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:51:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 19:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:51:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:51:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:51:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:51:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 19:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:51:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:51:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:51:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:51:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:51:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:51:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 19:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:51:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:51:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:51:11 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-30 19:51:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:51:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:51:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:51:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:51:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:51:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:58:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 19:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:58:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:58:42 --> UTF-8 Support Enabled
ERROR - 2022-12-30 19:58:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:58:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:58:42 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-30 19:58:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:58:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:58:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-30 19:58:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:58:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:58:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-30 19:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 19:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 19:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 19:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:58:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:58:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:58:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:58:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 19:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 19:58:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 19:58:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 20:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 20:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 20:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 20:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 20:02:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 20:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 20:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 20:02:47 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 20:02:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 20:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 20:02:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 20:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 20:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 20:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 20:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:02:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 20:02:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 20:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 20:02:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 20:02:50 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 20:02:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 20:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:02:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 20:02:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 20:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 20:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 20:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 20:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:05:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 20:05:37 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 20:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 20:05:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 20:05:37 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-30 20:05:38 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 20:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 20:05:38 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 20:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 20:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 20:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 20:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:05:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 20:05:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 20:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 20:05:56 --> UTF-8 Support Enabled
ERROR - 2022-12-30 20:05:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 20:05:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 20:05:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 20:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:05:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 20:05:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-30 20:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:07:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 20:07:50 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\auth\UserAuth.php 51
DEBUG - 2022-12-30 20:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 20:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 20:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 20:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 21:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 21:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 21:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 21:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 21:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 21:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 21:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 21:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 21:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 21:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 21:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 21:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 21:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 21:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 21:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 21:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 21:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 21:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 21:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 21:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 21:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 21:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 21:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 21:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 21:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 21:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 21:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 21:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 21:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 21:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 21:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 21:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 21:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 21:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 21:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 21:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 21:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:48:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-30 21:48:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-30 21:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 21:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 21:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-30 21:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-30 21:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-30 21:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-30 21:48:07 --> Encryption: Auto-configured driver 'openssl'.
