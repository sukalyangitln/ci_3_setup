<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-26 03:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:39:23 --> No URI present. Default controller set.
DEBUG - 2022-12-26 03:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:09:24 --> Total execution time: 0.8292
DEBUG - 2022-12-26 03:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:39:24 --> No URI present. Default controller set.
DEBUG - 2022-12-26 03:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:09:24 --> Total execution time: 0.0490
DEBUG - 2022-12-26 03:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 03:39:30 --> Total execution time: 0.0642
DEBUG - 2022-12-26 03:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 03:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:09:32 --> Total execution time: 0.1479
DEBUG - 2022-12-26 03:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:39:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:09:38 --> Total execution time: 0.1086
DEBUG - 2022-12-26 03:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:39:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:09:49 --> Total execution time: 0.0946
DEBUG - 2022-12-26 03:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:39:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:09:54 --> Total execution time: 0.1005
DEBUG - 2022-12-26 03:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:39:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:11:58 --> Total execution time: 0.0544
DEBUG - 2022-12-26 03:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:41:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:41:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:12:08 --> Total execution time: 0.0686
DEBUG - 2022-12-26 03:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:42:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:42:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:14:07 --> Total execution time: 0.0687
DEBUG - 2022-12-26 03:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:44:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:14:17 --> Total execution time: 0.0617
DEBUG - 2022-12-26 03:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:44:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:44:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:14:19 --> Total execution time: 0.0715
DEBUG - 2022-12-26 03:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:44:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:44:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:44:38 --> UTF-8 Support Enabled
ERROR - 2022-12-26 03:44:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 03:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:44:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:44:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 03:44:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 03:44:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:44:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:44:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 03:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:44:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 03:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:19:54 --> Total execution time: 0.8109
DEBUG - 2022-12-26 03:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:49:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:49:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:21:37 --> Total execution time: 0.0451
DEBUG - 2022-12-26 03:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:51:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:51:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:22:46 --> Total execution time: 0.0506
DEBUG - 2022-12-26 03:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:52:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:23:00 --> Total execution time: 0.0678
DEBUG - 2022-12-26 03:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:53:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:24:54 --> Total execution time: 0.0451
DEBUG - 2022-12-26 03:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:54:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:54:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:25:11 --> Total execution time: 0.0433
DEBUG - 2022-12-26 03:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:55:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:55:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:26:39 --> Total execution time: 0.0782
DEBUG - 2022-12-26 03:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:56:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:56:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 03:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:56:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:56:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 03:56:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:56:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 03:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:56:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 03:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:56:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 03:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:56:40 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 03:56:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 03:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:56:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 03:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:56:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 03:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 03:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 03:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:26:55 --> Total execution time: 0.0485
DEBUG - 2022-12-26 03:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 03:56:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 03:56:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:30:50 --> Total execution time: 0.0607
DEBUG - 2022-12-26 04:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:00:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:00:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 04:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:30:58 --> Total execution time: 0.0496
DEBUG - 2022-12-26 04:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:00:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:00:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:31:13 --> Total execution time: 0.0603
DEBUG - 2022-12-26 04:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:01:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:01:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-26 08:31:16 --> Severity: error --> Exception: Call to undefined method User_logins::updateWheres() C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 369
DEBUG - 2022-12-26 04:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:31:24 --> Total execution time: 0.0558
DEBUG - 2022-12-26 04:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 04:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:31:27 --> Total execution time: 0.0469
DEBUG - 2022-12-26 04:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:01:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 04:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:31:36 --> Total execution time: 0.0460
DEBUG - 2022-12-26 04:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:01:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:01:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 04:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:31:48 --> Total execution time: 0.0493
DEBUG - 2022-12-26 04:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:01:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:01:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:32:25 --> Total execution time: 0.0811
DEBUG - 2022-12-26 04:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:02:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:32:28 --> Total execution time: 0.0734
DEBUG - 2022-12-26 04:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:02:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:02:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:32:29 --> Total execution time: 0.0620
DEBUG - 2022-12-26 04:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:02:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:02:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:32:32 --> Total execution time: 0.0642
DEBUG - 2022-12-26 04:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:02:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:02:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:38:09 --> Total execution time: 0.0639
DEBUG - 2022-12-26 04:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:08:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:43:23 --> Total execution time: 0.0539
DEBUG - 2022-12-26 04:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:13:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:13:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:43:25 --> Total execution time: 0.0417
DEBUG - 2022-12-26 04:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:13:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:13:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:13:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:13:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:43:38 --> Total execution time: 0.0526
DEBUG - 2022-12-26 04:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:13:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:13:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:44:54 --> Total execution time: 0.0732
DEBUG - 2022-12-26 04:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:14:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:14:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:45:09 --> Total execution time: 0.0724
DEBUG - 2022-12-26 04:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:15:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:45:33 --> Total execution time: 0.0664
DEBUG - 2022-12-26 04:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:15:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:15:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:45:40 --> Total execution time: 0.0694
DEBUG - 2022-12-26 04:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:15:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:17:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-26 08:47:49 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\fundraiser\kyc-list.php 114
ERROR - 2022-12-26 08:47:49 --> Severity: Notice --> Trying to get property 'kyc_status' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\fundraiser\kyc-list.php 114
ERROR - 2022-12-26 08:47:49 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\fundraiser\kyc-list.php 114
ERROR - 2022-12-26 08:47:49 --> Severity: Notice --> Trying to get property 'kyc_status' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\fundraiser\kyc-list.php 114
DEBUG - 2022-12-26 08:47:49 --> Total execution time: 0.0757
DEBUG - 2022-12-26 04:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:17:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:47:59 --> Total execution time: 0.0606
DEBUG - 2022-12-26 04:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:17:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:48:36 --> Total execution time: 0.0644
DEBUG - 2022-12-26 04:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:18:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:49:28 --> Total execution time: 0.0457
DEBUG - 2022-12-26 04:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:19:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:50:06 --> Total execution time: 0.0623
DEBUG - 2022-12-26 04:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:20:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:51:32 --> Total execution time: 0.0528
DEBUG - 2022-12-26 04:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:21:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:21:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:51:55 --> Total execution time: 0.0459
DEBUG - 2022-12-26 04:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:21:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:51:56 --> Total execution time: 0.0635
DEBUG - 2022-12-26 04:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:51:59 --> Total execution time: 0.0408
DEBUG - 2022-12-26 04:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:22:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:52:46 --> Total execution time: 0.0484
DEBUG - 2022-12-26 04:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:22:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:53:05 --> Total execution time: 0.0548
DEBUG - 2022-12-26 04:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:23:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:23:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:53:30 --> Total execution time: 0.0981
DEBUG - 2022-12-26 04:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:23:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:23:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:54:20 --> Total execution time: 0.0418
DEBUG - 2022-12-26 04:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:24:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 08:54:46 --> Total execution time: 0.0679
DEBUG - 2022-12-26 04:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:24:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:12:17 --> Total execution time: 0.0567
DEBUG - 2022-12-26 04:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:42:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:42:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:12:27 --> Total execution time: 0.0610
DEBUG - 2022-12-26 04:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:42:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:42:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:19:29 --> Total execution time: 0.0701
DEBUG - 2022-12-26 04:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:49:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:49:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:19:40 --> Total execution time: 0.0585
DEBUG - 2022-12-26 04:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:49:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:20:10 --> Total execution time: 0.0395
DEBUG - 2022-12-26 04:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:50:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:20:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 04:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:20:28 --> Total execution time: 0.0424
DEBUG - 2022-12-26 04:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:50:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:50:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:20:53 --> Total execution time: 0.0627
DEBUG - 2022-12-26 04:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:50:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:50:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:22:50 --> Total execution time: 0.0581
DEBUG - 2022-12-26 04:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:52:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:52:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:23:05 --> Total execution time: 0.0410
DEBUG - 2022-12-26 04:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:53:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:24:08 --> Total execution time: 0.0661
DEBUG - 2022-12-26 04:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:54:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:54:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:24:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 04:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:24:28 --> Total execution time: 0.0409
DEBUG - 2022-12-26 04:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:54:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:54:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:24:42 --> Total execution time: 0.0545
DEBUG - 2022-12-26 04:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:54:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:54:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:26:35 --> Total execution time: 0.0640
DEBUG - 2022-12-26 04:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:56:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:56:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:27:31 --> Total execution time: 0.0422
DEBUG - 2022-12-26 04:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:57:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:57:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 04:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 04:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 04:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:28:47 --> Total execution time: 0.0585
DEBUG - 2022-12-26 04:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 04:58:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 04:58:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:33:07 --> Total execution time: 0.0562
DEBUG - 2022-12-26 05:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:03:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:05:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:05:19 --> Severity: error --> Exception: syntax error, unexpected ''status'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 91
DEBUG - 2022-12-26 05:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:35:25 --> Total execution time: 0.0678
DEBUG - 2022-12-26 05:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:05:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:05:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 05:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:36:02 --> Total execution time: 0.0850
DEBUG - 2022-12-26 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:06:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:06:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:06:02 --> UTF-8 Support Enabled
ERROR - 2022-12-26 05:06:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:06:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:06:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:06:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:06:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:06:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:06:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:06:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:06:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 05:06:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 05:06:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:06:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:06:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:06:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:06:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:36:07 --> Total execution time: 0.0545
DEBUG - 2022-12-26 05:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:40:57 --> Total execution time: 0.0631
DEBUG - 2022-12-26 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:10:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:10:58 --> UTF-8 Support Enabled
ERROR - 2022-12-26 05:10:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:10:58 --> UTF-8 Support Enabled
ERROR - 2022-12-26 05:10:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:10:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:10:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:10:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:10:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:10:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:10:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 05:10:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:41:03 --> Total execution time: 0.0641
DEBUG - 2022-12-26 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:41:16 --> Total execution time: 0.0611
DEBUG - 2022-12-26 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:11:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:11:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:11:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:11:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:11:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:11:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:11:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:11:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:11:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:11:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:41:18 --> Total execution time: 0.0399
DEBUG - 2022-12-26 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:45:28 --> Total execution time: 0.0698
DEBUG - 2022-12-26 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:15:28 --> UTF-8 Support Enabled
ERROR - 2022-12-26 05:15:28 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 05:15:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:45:29 --> Total execution time: 0.0435
DEBUG - 2022-12-26 05:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:45:32 --> Total execution time: 0.0398
DEBUG - 2022-12-26 05:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:45:46 --> Total execution time: 0.0396
DEBUG - 2022-12-26 05:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 05:15:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:15:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 05:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:45:47 --> Total execution time: 0.0493
DEBUG - 2022-12-26 05:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:45:50 --> Total execution time: 0.0411
DEBUG - 2022-12-26 05:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:45:56 --> Total execution time: 0.0395
DEBUG - 2022-12-26 05:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:46:30 --> Total execution time: 0.0432
DEBUG - 2022-12-26 05:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:16:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:16:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:51:27 --> Total execution time: 0.0785
DEBUG - 2022-12-26 05:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:21:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:21:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:51:29 --> Total execution time: 0.0593
DEBUG - 2022-12-26 05:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:51:32 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 09:51:32 --> You did not select a file to upload.
DEBUG - 2022-12-26 05:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:51:32 --> Total execution time: 0.0430
DEBUG - 2022-12-26 05:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:21:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:21:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:51:34 --> Total execution time: 0.0592
DEBUG - 2022-12-26 05:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:51:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 09:51:38 --> You did not select a file to upload.
DEBUG - 2022-12-26 05:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:51:38 --> Total execution time: 0.0513
DEBUG - 2022-12-26 05:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:21:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:21:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:51:40 --> Total execution time: 0.0504
DEBUG - 2022-12-26 05:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:51:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 05:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:51:44 --> Total execution time: 0.0412
DEBUG - 2022-12-26 05:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:21:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:21:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:52:07 --> Total execution time: 0.0515
DEBUG - 2022-12-26 05:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:22:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:22:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:52:43 --> Total execution time: 0.0660
DEBUG - 2022-12-26 05:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:22:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:22:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:59:07 --> Total execution time: 0.0416
DEBUG - 2022-12-26 05:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:29:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:29:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:59:12 --> Total execution time: 0.0414
DEBUG - 2022-12-26 05:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:29:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 09:59:58 --> Total execution time: 0.0410
DEBUG - 2022-12-26 05:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:29:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 10:00:07 --> Total execution time: 0.0455
DEBUG - 2022-12-26 05:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 10:00:12 --> Total execution time: 0.0415
DEBUG - 2022-12-26 05:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:30:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:30:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 10:00:38 --> Total execution time: 0.0409
DEBUG - 2022-12-26 05:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:30:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 10:00:40 --> Total execution time: 0.0607
DEBUG - 2022-12-26 05:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 10:00:43 --> Total execution time: 0.0523
DEBUG - 2022-12-26 05:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:30:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 10:01:19 --> Total execution time: 0.0408
DEBUG - 2022-12-26 05:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:31:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:31:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 10:01:23 --> Total execution time: 0.0446
DEBUG - 2022-12-26 05:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 10:01:26 --> Total execution time: 0.0402
DEBUG - 2022-12-26 05:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:31:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:31:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 05:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 05:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 05:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 10:01:34 --> Total execution time: 0.0422
DEBUG - 2022-12-26 05:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 05:31:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 05:31:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 12:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:36:04 --> No URI present. Default controller set.
DEBUG - 2022-12-26 12:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:06:05 --> Total execution time: 0.9195
DEBUG - 2022-12-26 12:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 12:36:07 --> Total execution time: 0.0697
DEBUG - 2022-12-26 12:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 12:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:06:20 --> Total execution time: 0.1280
DEBUG - 2022-12-26 12:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:36:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 12:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:06:26 --> Total execution time: 0.0886
DEBUG - 2022-12-26 12:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:36:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:36:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 12:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:06:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 12:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:06:45 --> Total execution time: 0.0390
DEBUG - 2022-12-26 12:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:36:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 12:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:06:50 --> Total execution time: 0.0585
DEBUG - 2022-12-26 12:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:36:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 12:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:07:05 --> Total execution time: 0.0852
DEBUG - 2022-12-26 12:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:37:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 12:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:07:05 --> Total execution time: 0.0420
DEBUG - 2022-12-26 12:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:52:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-26 17:22:30 --> Severity: error --> Exception: Too few arguments to function get_search_user_campaign_add(), 0 passed in C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php on line 47 and exactly 1 expected C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 40
DEBUG - 2022-12-26 12:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:52:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:52:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 12:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:22:52 --> Total execution time: 0.1030
DEBUG - 2022-12-26 12:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:52:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:52:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 12:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:22:52 --> Total execution time: 0.0507
DEBUG - 2022-12-26 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:52:57 --> UTF-8 Support Enabled
ERROR - 2022-12-26 12:52:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:52:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:52:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:52:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:52:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 12:52:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:52:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:52:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:52:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:52:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 12:52:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:52:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:52:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:24:15 --> Total execution time: 0.0619
DEBUG - 2022-12-26 12:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 12:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:54:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:15 --> UTF-8 Support Enabled
ERROR - 2022-12-26 12:54:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:24:16 --> Total execution time: 0.0503
DEBUG - 2022-12-26 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:24:23 --> Total execution time: 0.0736
DEBUG - 2022-12-26 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 12:54:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 12:54:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:24:24 --> Total execution time: 0.0436
DEBUG - 2022-12-26 12:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:24:30 --> Total execution time: 0.0809
DEBUG - 2022-12-26 12:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:54:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 12:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:24:30 --> Total execution time: 0.0529
DEBUG - 2022-12-26 12:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:25:49 --> Total execution time: 0.0518
DEBUG - 2022-12-26 12:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:55:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 12:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:25:49 --> Total execution time: 0.0544
DEBUG - 2022-12-26 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:55:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:55:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:55:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:55:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:55:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:55:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 12:55:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:55:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:26:32 --> Total execution time: 0.0581
DEBUG - 2022-12-26 12:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:56:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 12:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:56:32 --> UTF-8 Support Enabled
ERROR - 2022-12-26 12:56:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:56:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:56:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:56:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:56:32 --> UTF-8 Support Enabled
ERROR - 2022-12-26 12:56:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:56:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:56:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 12:56:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 12:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 12:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 12:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 12:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:26:32 --> Total execution time: 0.0561
DEBUG - 2022-12-26 13:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:31:47 --> Total execution time: 0.0663
DEBUG - 2022-12-26 13:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:01:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:01:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:01:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:01:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:01:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:01:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:01:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:01:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:01:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:01:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:01:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:01:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:01:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:01:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:01:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:01:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:01:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:31:48 --> Total execution time: 0.0540
DEBUG - 2022-12-26 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:32:00 --> Total execution time: 0.0419
DEBUG - 2022-12-26 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:02:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:02:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:02:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:02:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:02:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:02:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:02:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:02:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 13:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 17:32:01 --> Total execution time: 0.0683
DEBUG - 2022-12-26 13:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:02:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:34:35 --> Total execution time: 0.0445
DEBUG - 2022-12-26 13:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:04:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:04:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:04:35 --> UTF-8 Support Enabled
ERROR - 2022-12-26 13:04:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:04:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:04:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:04:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:04:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:04:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:04:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:34:35 --> Total execution time: 0.0565
DEBUG - 2022-12-26 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:35:09 --> Total execution time: 0.0436
DEBUG - 2022-12-26 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:05:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:05:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:05:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:05:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:05:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:05:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:05:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:05:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:05:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:05:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:05:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:05:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:05:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:05:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:05:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:35:09 --> Total execution time: 0.0556
DEBUG - 2022-12-26 13:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:40:57 --> Total execution time: 0.0465
DEBUG - 2022-12-26 13:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:10:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:10:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:10:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:10:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:10:57 --> UTF-8 Support Enabled
ERROR - 2022-12-26 13:10:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:10:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:10:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:10:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:10:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:40:57 --> Total execution time: 0.0509
DEBUG - 2022-12-26 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:48:55 --> Total execution time: 0.0588
DEBUG - 2022-12-26 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:18:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:18:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:18:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:18:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:18:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:18:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:18:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:18:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:18:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:48:55 --> Total execution time: 0.0504
DEBUG - 2022-12-26 13:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:49:44 --> Total execution time: 0.0672
DEBUG - 2022-12-26 13:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:19:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:19:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:19:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:19:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:19:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:19:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:19:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:19:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:19:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:19:45 --> UTF-8 Support Enabled
ERROR - 2022-12-26 13:19:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:19:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:19:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:49:45 --> Total execution time: 0.0488
DEBUG - 2022-12-26 13:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:50:46 --> Total execution time: 0.0579
DEBUG - 2022-12-26 13:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:20:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:20:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:20:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:20:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:20:46 --> UTF-8 Support Enabled
ERROR - 2022-12-26 13:20:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:20:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:20:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:20:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:20:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:50:46 --> Total execution time: 0.0649
DEBUG - 2022-12-26 13:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:50:53 --> Total execution time: 0.0425
DEBUG - 2022-12-26 13:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:20:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:20:53 --> UTF-8 Support Enabled
ERROR - 2022-12-26 13:20:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:20:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:20:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:20:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:20:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:20:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:20:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:20:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:20:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:20:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:50:53 --> Total execution time: 0.0559
DEBUG - 2022-12-26 13:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:20:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:20:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:53:05 --> Total execution time: 0.0601
DEBUG - 2022-12-26 13:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:23:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:23:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:23:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:23:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:23:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:23:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:23:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:23:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:23:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:23:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:23:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:23:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:23:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 13:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:23:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 17:53:06 --> Total execution time: 0.0680
DEBUG - 2022-12-26 13:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:56:01 --> Total execution time: 0.0630
DEBUG - 2022-12-26 13:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:26:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:26:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:26:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:26:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:26:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 17:56:02 --> Total execution time: 0.0497
DEBUG - 2022-12-26 13:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:26:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:26:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:26:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:26:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:01:42 --> Total execution time: 0.0658
DEBUG - 2022-12-26 13:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:31:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:31:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:31:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:31:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:31:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:31:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:31:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:31:42 --> UTF-8 Support Enabled
ERROR - 2022-12-26 13:31:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:31:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:31:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:01:43 --> Total execution time: 0.0519
DEBUG - 2022-12-26 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:02:30 --> Total execution time: 0.0660
DEBUG - 2022-12-26 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:32:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:32:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:32:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:32:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:32:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:32:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:32:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:32:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:32:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:32:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:32:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:32:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:02:30 --> Total execution time: 0.0528
DEBUG - 2022-12-26 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:02:47 --> Total execution time: 0.0602
DEBUG - 2022-12-26 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:32:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:32:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:32:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:32:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:32:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:32:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:32:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:32:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:32:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:02:48 --> Total execution time: 0.0579
DEBUG - 2022-12-26 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:03:03 --> Total execution time: 0.0572
DEBUG - 2022-12-26 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:33:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:33:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:33:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:33:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:33:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:33:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:33:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:33:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:33:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:03:03 --> Total execution time: 0.0554
DEBUG - 2022-12-26 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:03:32 --> Total execution time: 0.0456
DEBUG - 2022-12-26 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:33:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:33:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:33:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:33:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:33:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:33:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:33:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:33:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:33:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:03:32 --> Total execution time: 0.0673
DEBUG - 2022-12-26 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:04:33 --> Total execution time: 0.0646
DEBUG - 2022-12-26 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:34:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:34:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:34:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:34:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:34:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:34:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:34:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:34:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:34:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:04:34 --> Total execution time: 0.0502
DEBUG - 2022-12-26 13:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:05:37 --> Total execution time: 0.0594
DEBUG - 2022-12-26 13:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:35:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:35:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:35:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:35:38 --> UTF-8 Support Enabled
ERROR - 2022-12-26 13:35:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:35:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:35:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:35:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:35:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:35:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:35:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:05:38 --> Total execution time: 0.0494
DEBUG - 2022-12-26 13:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:07:05 --> Total execution time: 0.0667
DEBUG - 2022-12-26 13:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:37:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:37:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:07:05 --> Total execution time: 0.0623
DEBUG - 2022-12-26 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:07:38 --> Total execution time: 0.0577
DEBUG - 2022-12-26 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:37:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:37:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:37:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:37:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:07:38 --> Total execution time: 0.0558
DEBUG - 2022-12-26 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:09:46 --> Total execution time: 0.0584
DEBUG - 2022-12-26 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:39:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:39:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:39:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:39:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:39:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:39:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:39:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:39:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:39:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:09:47 --> Total execution time: 0.0646
DEBUG - 2022-12-26 13:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:10:35 --> Total execution time: 0.0666
DEBUG - 2022-12-26 13:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:40:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:40:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:40:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:40:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:40:36 --> UTF-8 Support Enabled
ERROR - 2022-12-26 13:40:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:40:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:40:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:40:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:40:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:10:36 --> Total execution time: 0.0507
DEBUG - 2022-12-26 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:11:17 --> Total execution time: 0.0598
DEBUG - 2022-12-26 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:41:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:41:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:41:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:41:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:41:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:11:18 --> Total execution time: 0.0491
DEBUG - 2022-12-26 13:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:11:44 --> Total execution time: 0.0422
DEBUG - 2022-12-26 13:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:41:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:41:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:41:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:11:44 --> Total execution time: 0.0523
DEBUG - 2022-12-26 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:14:09 --> Total execution time: 0.0672
DEBUG - 2022-12-26 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:44:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:44:09 --> UTF-8 Support Enabled
ERROR - 2022-12-26 13:44:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:44:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:44:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:44:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:44:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:44:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:44:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:44:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:14:09 --> Total execution time: 0.0601
DEBUG - 2022-12-26 13:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:16:39 --> Total execution time: 0.0614
DEBUG - 2022-12-26 13:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:46:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:46:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:46:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:46:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:46:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:46:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:46:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:46:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:46:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:46:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:46:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:46:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:46:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:46:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:46:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:46:40 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:46:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:46:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:46:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:16:40 --> Total execution time: 0.0464
DEBUG - 2022-12-26 13:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:18:44 --> Total execution time: 0.0412
DEBUG - 2022-12-26 13:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:48:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:18:44 --> Total execution time: 0.0495
DEBUG - 2022-12-26 13:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:29:26 --> Total execution time: 0.0594
DEBUG - 2022-12-26 13:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:59:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:29:26 --> Total execution time: 0.0482
DEBUG - 2022-12-26 13:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:59:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:59:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:59:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:59:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:59:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:59:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:59:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:59:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:59:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 13:59:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:59:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:29:53 --> Total execution time: 0.0588
DEBUG - 2022-12-26 13:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:59:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 13:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:59:53 --> UTF-8 Support Enabled
ERROR - 2022-12-26 13:59:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:59:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:59:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:59:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:59:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:59:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:59:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 13:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 13:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 13:59:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 13:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 13:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:29:53 --> Total execution time: 0.0490
DEBUG - 2022-12-26 14:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:30:22 --> Total execution time: 0.0577
DEBUG - 2022-12-26 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:00:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:00:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:00:23 --> UTF-8 Support Enabled
ERROR - 2022-12-26 14:00:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:00:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:00:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:00:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:00:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:00:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:00:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:30:23 --> Total execution time: 0.0525
DEBUG - 2022-12-26 14:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:30:48 --> Total execution time: 0.0633
DEBUG - 2022-12-26 14:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:00:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:00:48 --> UTF-8 Support Enabled
ERROR - 2022-12-26 14:00:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:00:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:00:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:00:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:00:48 --> UTF-8 Support Enabled
ERROR - 2022-12-26 14:00:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:00:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:00:48 --> UTF-8 Support Enabled
ERROR - 2022-12-26 14:00:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:00:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:00:48 --> UTF-8 Support Enabled
ERROR - 2022-12-26 14:00:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:30:49 --> Total execution time: 0.0662
DEBUG - 2022-12-26 14:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:31:05 --> Total execution time: 0.0541
DEBUG - 2022-12-26 14:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:01:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:01:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:01:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:01:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:01:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:01:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:01:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:01:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:01:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:31:06 --> Total execution time: 0.0702
DEBUG - 2022-12-26 14:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:33:44 --> Total execution time: 0.0611
DEBUG - 2022-12-26 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:03:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:03:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:03:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:03:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:03:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:03:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:03:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:03:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:03:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:03:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:33:45 --> Total execution time: 0.0722
DEBUG - 2022-12-26 14:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:34:23 --> Total execution time: 0.0585
DEBUG - 2022-12-26 14:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:04:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:04:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:04:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:04:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:04:23 --> UTF-8 Support Enabled
ERROR - 2022-12-26 14:04:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:04:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:04:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:04:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:04:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:04:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:04:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:04:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:04:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:04:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:04:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:04:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:04:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:04:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:34:23 --> Total execution time: 0.0537
DEBUG - 2022-12-26 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:35:35 --> Total execution time: 0.0674
DEBUG - 2022-12-26 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:05:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:05:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:05:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:05:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:05:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:05:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:05:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:05:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:05:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:35:35 --> Total execution time: 0.0855
DEBUG - 2022-12-26 14:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:36:05 --> Total execution time: 0.0574
DEBUG - 2022-12-26 14:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:06:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:06:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:06:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:06:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:06:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:06:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:06:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:06:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:06:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:06:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:06:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:06:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:06:06 --> UTF-8 Support Enabled
ERROR - 2022-12-26 14:06:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:36:06 --> Total execution time: 0.0641
DEBUG - 2022-12-26 14:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:37:41 --> Total execution time: 0.0628
DEBUG - 2022-12-26 14:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:07:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:07:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:07:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:07:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:07:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:07:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:07:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:07:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:07:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:07:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:07:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:07:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:07:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:07:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:07:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:07:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:37:42 --> Total execution time: 0.0661
DEBUG - 2022-12-26 14:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:38:09 --> Total execution time: 0.0430
DEBUG - 2022-12-26 14:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:08:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:38:10 --> Total execution time: 0.0458
DEBUG - 2022-12-26 14:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:38:43 --> Total execution time: 0.0425
DEBUG - 2022-12-26 14:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:08:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:08:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:08:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:38:43 --> Total execution time: 0.0472
DEBUG - 2022-12-26 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:41:11 --> Total execution time: 0.0671
DEBUG - 2022-12-26 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:11:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:11:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:11:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:11:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:11:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:11:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:11:11 --> UTF-8 Support Enabled
ERROR - 2022-12-26 14:11:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:11:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:11:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:41:11 --> Total execution time: 0.0575
DEBUG - 2022-12-26 14:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:42:01 --> Total execution time: 0.0754
DEBUG - 2022-12-26 14:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:12:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:12:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:12:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:12:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:12:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:12:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:12:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:12:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:12:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:12:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:12:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:12:01 --> UTF-8 Support Enabled
ERROR - 2022-12-26 14:12:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:12:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:12:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:12:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:12:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:42:01 --> Total execution time: 0.0471
DEBUG - 2022-12-26 14:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:45:57 --> Total execution time: 0.0599
DEBUG - 2022-12-26 14:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:15:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:15:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:15:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:15:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:15:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:15:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:15:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:15:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:15:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-26 14:15:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:15:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:15:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:15:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-26 14:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:45:58 --> Total execution time: 0.0604
DEBUG - 2022-12-26 14:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:58:23 --> Total execution time: 0.5062
DEBUG - 2022-12-26 14:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:28:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:28:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 18:58:23 --> Total execution time: 0.0541
DEBUG - 2022-12-26 14:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:32:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-26 19:02:37 --> Severity: Notice --> Undefined variable: cat_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
ERROR - 2022-12-26 19:02:37 --> Severity: Notice --> Trying to get property 'cat_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
ERROR - 2022-12-26 19:02:37 --> Severity: Notice --> Undefined variable: cat_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
ERROR - 2022-12-26 19:02:37 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
ERROR - 2022-12-26 19:02:37 --> Severity: Notice --> Undefined variable: cat_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
ERROR - 2022-12-26 19:02:37 --> Severity: Notice --> Trying to get property 'cat_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
ERROR - 2022-12-26 19:02:37 --> Severity: Notice --> Undefined variable: cat_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
ERROR - 2022-12-26 19:02:37 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
DEBUG - 2022-12-26 19:02:37 --> Total execution time: 0.0789
DEBUG - 2022-12-26 14:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:32:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:32:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:32:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-26 19:02:38 --> Severity: Notice --> Undefined variable: cat_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
ERROR - 2022-12-26 19:02:38 --> Severity: Notice --> Trying to get property 'cat_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
ERROR - 2022-12-26 19:02:38 --> Severity: Notice --> Undefined variable: cat_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
ERROR - 2022-12-26 19:02:38 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
ERROR - 2022-12-26 19:02:38 --> Severity: Notice --> Undefined variable: cat_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
ERROR - 2022-12-26 19:02:38 --> Severity: Notice --> Trying to get property 'cat_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
ERROR - 2022-12-26 19:02:38 --> Severity: Notice --> Undefined variable: cat_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
ERROR - 2022-12-26 19:02:38 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-add.php 132
DEBUG - 2022-12-26 19:02:38 --> Total execution time: 0.0838
DEBUG - 2022-12-26 14:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:02:50 --> Total execution time: 0.0661
DEBUG - 2022-12-26 14:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:32:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:02:50 --> Total execution time: 0.0651
DEBUG - 2022-12-26 14:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:04:59 --> Total execution time: 0.0407
DEBUG - 2022-12-26 14:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:05:22 --> Total execution time: 0.0535
DEBUG - 2022-12-26 14:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:06:44 --> Total execution time: 0.0424
DEBUG - 2022-12-26 14:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:36:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 14:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:06:45 --> Total execution time: 0.0456
DEBUG - 2022-12-26 14:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 14:51:30 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 68
DEBUG - 2022-12-26 14:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 14:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 14:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:26:57 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 14:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 14:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 14:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 14:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 15:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 15:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 15:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 15:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:34:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 19:34:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 15:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 15:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 15:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 15:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:38:00 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 19:38:00 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 15:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 15:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 15:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 15:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:40:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 19:40:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 19:40:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 19:40:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 19:40:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-26 15:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 15:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 15:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 15:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:40:38 --> Total execution time: 0.0410
DEBUG - 2022-12-26 15:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 15:10:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 15:10:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 15:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 15:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 15:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 15:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:40:39 --> Total execution time: 0.0815
DEBUG - 2022-12-26 15:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 15:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 15:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 15:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:41:12 --> Total execution time: 0.0411
DEBUG - 2022-12-26 15:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 15:11:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 15:11:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 15:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 15:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 15:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 15:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:41:12 --> Total execution time: 0.0496
DEBUG - 2022-12-26 15:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 15:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 15:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 15:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 19:41:22 --> Total execution time: 0.0602
DEBUG - 2022-12-26 15:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 15:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 15:11:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 16:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 16:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 16:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 16:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 21:11:57 --> Total execution time: 0.0649
DEBUG - 2022-12-26 16:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 16:41:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-26 16:41:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-26 16:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-26 16:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-26 16:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-26 16:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-26 21:11:57 --> Total execution time: 0.0490
