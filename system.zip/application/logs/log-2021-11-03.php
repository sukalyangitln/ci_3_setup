<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-03 02:28:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 07:58:22 --> Total execution time: 0.0400
DEBUG - 2021-11-03 02:28:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 07:58:25 --> Total execution time: 0.0301
DEBUG - 2021-11-03 02:29:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 02:29:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 07:59:06 --> Total execution time: 0.0627
DEBUG - 2021-11-03 02:36:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:06:46 --> Total execution time: 0.0464
DEBUG - 2021-11-03 02:36:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:36:47 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 02:36:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:36:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 08:06:54 --> Severity: Warning --> First parameter must either be an object or the name of an existing class /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Front/TestMessage_Controller.php 41
DEBUG - 2021-11-03 08:06:54 --> Total execution time: 0.6660
DEBUG - 2021-11-03 02:37:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:37:02 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-03 02:37:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 08:07:12 --> Severity: Warning --> First parameter must either be an object or the name of an existing class /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Front/TestMessage_Controller.php 41
DEBUG - 2021-11-03 08:07:12 --> Total execution time: 0.5725
DEBUG - 2021-11-03 02:37:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 08:07:20 --> Severity: Warning --> First parameter must either be an object or the name of an existing class /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Front/TestMessage_Controller.php 41
DEBUG - 2021-11-03 08:07:20 --> Total execution time: 0.5832
DEBUG - 2021-11-03 02:37:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:37 --> Total execution time: 1.6031
DEBUG - 2021-11-03 02:37:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:37 --> Total execution time: 0.0440
DEBUG - 2021-11-03 02:37:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:38 --> Total execution time: 0.0369
DEBUG - 2021-11-03 02:37:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:39 --> Total execution time: 0.0414
DEBUG - 2021-11-03 02:37:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:39 --> Total execution time: 0.0381
DEBUG - 2021-11-03 02:37:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:40 --> Total execution time: 0.0668
DEBUG - 2021-11-03 02:37:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:41 --> Total execution time: 0.0391
DEBUG - 2021-11-03 02:37:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:43 --> Total execution time: 0.0379
DEBUG - 2021-11-03 02:37:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:44 --> Total execution time: 0.0368
DEBUG - 2021-11-03 02:37:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:46 --> Total execution time: 0.0413
DEBUG - 2021-11-03 02:37:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:48 --> Total execution time: 0.0353
DEBUG - 2021-11-03 02:37:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:49 --> Total execution time: 0.0484
DEBUG - 2021-11-03 02:37:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:50 --> Total execution time: 0.0345
DEBUG - 2021-11-03 02:37:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:51 --> Total execution time: 0.0402
DEBUG - 2021-11-03 02:37:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:51 --> Total execution time: 0.0384
DEBUG - 2021-11-03 02:37:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:51 --> Total execution time: 0.0509
DEBUG - 2021-11-03 02:37:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:52 --> Total execution time: 0.0338
DEBUG - 2021-11-03 02:37:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:53 --> Total execution time: 0.0443
DEBUG - 2021-11-03 02:37:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:53 --> Total execution time: 0.0384
DEBUG - 2021-11-03 02:37:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:54 --> Total execution time: 0.0361
DEBUG - 2021-11-03 02:37:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:07:57 --> Total execution time: 0.0449
DEBUG - 2021-11-03 02:38:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:08:01 --> Total execution time: 0.0414
DEBUG - 2021-11-03 02:38:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:08:02 --> Total execution time: 0.0461
DEBUG - 2021-11-03 02:38:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:08:02 --> Total execution time: 0.0790
DEBUG - 2021-11-03 02:38:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:08:02 --> Total execution time: 0.0654
DEBUG - 2021-11-03 02:38:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:08:02 --> Total execution time: 0.0639
DEBUG - 2021-11-03 02:38:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:08:02 --> Total execution time: 0.0725
DEBUG - 2021-11-03 02:38:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:08:03 --> Total execution time: 0.1198
DEBUG - 2021-11-03 02:38:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:08:03 --> Total execution time: 0.0531
DEBUG - 2021-11-03 02:38:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:08:03 --> Total execution time: 0.0876
DEBUG - 2021-11-03 02:38:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:08:03 --> Total execution time: 0.0759
DEBUG - 2021-11-03 02:38:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:38:09 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 02:38:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 02:38:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:38:16 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-03 08:08:16 --> Total execution time: 1.4214
DEBUG - 2021-11-03 02:38:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:08:53 --> Total execution time: 0.0604
DEBUG - 2021-11-03 02:38:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:08:55 --> Total execution time: 0.0346
DEBUG - 2021-11-03 02:38:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 02:39:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:09:00 --> Total execution time: 0.0359
DEBUG - 2021-11-03 02:39:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:09:08 --> {"session_id":"20211103080736946145","body":{"id":"3EB0E2B8AD94A04BAFC2","serialized":"false_919091982795@c.us_3EB0E2B8AD94A04BAFC2","numberRegistered":"917501561206","numberFrom":"919091982795","photoProfile":"https:\/\/pps.whatsapp.net\/v\/t61.24694-24\/186853013_593855165092190_2348862871019494260_n.jpg?ccb=11-4&oh=94a0f0c2c74575da626e35f47940f072&oe=61865815","name":"Dinesh Barman","pushName":"Dinesh Barman","isGroup":false,"participantsGroup":"","unreadCount":2,"hasMedia":false,"mediaKey":"","url_file":"","type":"chat","body":"Hi","sendBy":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1635907146,"broadcast":false,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":true,"isWAContact":true,"isBusiness":false,"isEnterprise":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-03 08:09:08 --> Total execution time: 0.0429
DEBUG - 2021-11-03 02:41:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:11:45 --> Total execution time: 0.0497
DEBUG - 2021-11-03 02:51:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:21:59 --> Total execution time: 0.0538
DEBUG - 2021-11-03 02:52:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:22:01 --> Total execution time: 0.0542
DEBUG - 2021-11-03 02:54:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:24:56 --> Total execution time: 0.0455
DEBUG - 2021-11-03 02:55:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:25:01 --> Total execution time: 0.1203
DEBUG - 2021-11-03 02:55:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:55:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:55:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:55:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:55:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:55:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:55:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:55:06 --> UTF-8 Support Enabled
ERROR - 2021-11-03 02:55:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:55:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:55:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:55:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:55:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:55:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:55:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:55:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:55:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:55:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:56:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:26:15 --> Total execution time: 0.0387
DEBUG - 2021-11-03 02:56:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:26:20 --> Total execution time: 0.0283
DEBUG - 2021-11-03 02:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:56:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:56:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:56:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:56:40 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-03 02:56:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:56:40 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-03 02:56:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 02:56:40 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-03 02:56:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 02:57:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:27:25 --> Total execution time: 0.0409
DEBUG - 2021-11-03 02:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:27:27 --> Total execution time: 0.0477
DEBUG - 2021-11-03 02:59:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:29:30 --> Total execution time: 0.0381
DEBUG - 2021-11-03 02:59:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 02:59:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:29:33 --> Total execution time: 0.0369
DEBUG - 2021-11-03 02:59:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 02:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 02:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:29:40 --> Total execution time: 0.0378
DEBUG - 2021-11-03 03:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:06:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:06:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:06:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:06:56 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-03 03:06:56 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-03 03:06:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:06:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:06:56 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-03 03:06:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:06:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:36:58 --> Total execution time: 0.0482
DEBUG - 2021-11-03 03:06:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:06:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:06:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:06:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:06:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:06:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:06:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:06:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:06:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:06:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:06:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:06:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:06:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:06:59 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-03 03:06:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:06:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:06:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:06:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:37:01 --> Total execution time: 0.0290
DEBUG - 2021-11-03 03:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:37:23 --> Total execution time: 0.0452
DEBUG - 2021-11-03 03:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:23 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-03 03:07:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:37:25 --> Total execution time: 0.0356
DEBUG - 2021-11-03 03:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:37:48 --> Total execution time: 0.0430
DEBUG - 2021-11-03 03:07:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:07:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:49 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-03 03:07:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 03:07:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 03:07:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:37:50 --> Total execution time: 0.0358
DEBUG - 2021-11-03 03:08:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:38:02 --> Total execution time: 0.2030
DEBUG - 2021-11-03 03:08:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:38:04 --> Total execution time: 0.0487
DEBUG - 2021-11-03 03:21:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:51:24 --> Total execution time: 0.0466
DEBUG - 2021-11-03 03:22:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:52:14 --> Total execution time: 0.0451
DEBUG - 2021-11-03 03:22:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 08:52:24 --> Total execution time: 0.0342
DEBUG - 2021-11-03 03:37:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 09:07:30 --> Total execution time: 0.0885
DEBUG - 2021-11-03 03:37:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 09:07:35 --> Total execution time: 0.1544
DEBUG - 2021-11-03 03:37:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 09:07:36 --> Total execution time: 0.1955
DEBUG - 2021-11-03 03:37:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 09:07:43 --> Total execution time: 0.0360
DEBUG - 2021-11-03 03:37:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 03:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 03:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 09:07:48 --> Total execution time: 0.0327
DEBUG - 2021-11-03 04:14:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 04:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 04:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 09:44:28 --> Total execution time: 0.1607
DEBUG - 2021-11-03 04:14:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 04:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 04:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 09:44:30 --> Total execution time: 0.0403
DEBUG - 2021-11-03 04:37:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 04:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 04:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 10:07:03 --> Total execution time: 0.1546
DEBUG - 2021-11-03 04:37:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 04:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 04:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 10:07:10 --> Total execution time: 0.0514
DEBUG - 2021-11-03 11:30:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:30:48 --> No URI present. Default controller set.
DEBUG - 2021-11-03 11:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:00:48 --> Total execution time: 0.9392
DEBUG - 2021-11-03 11:30:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 11:30:49 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-03 11:30:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:30:50 --> No URI present. Default controller set.
DEBUG - 2021-11-03 11:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:00:50 --> Total execution time: 0.0294
DEBUG - 2021-11-03 11:30:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 11:30:53 --> Total execution time: 0.0924
DEBUG - 2021-11-03 11:30:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:30:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:30:57 --> No URI present. Default controller set.
DEBUG - 2021-11-03 11:30:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 11:30:57 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-03 11:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:00:57 --> Total execution time: 0.0427
DEBUG - 2021-11-03 11:30:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:30:57 --> No URI present. Default controller set.
DEBUG - 2021-11-03 11:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:00:57 --> Total execution time: 0.0297
DEBUG - 2021-11-03 11:30:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 11:30:59 --> Total execution time: 0.0285
DEBUG - 2021-11-03 11:31:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 11:31:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:01:15 --> Total execution time: 0.2038
DEBUG - 2021-11-03 11:31:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 11:31:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:01:52 --> Total execution time: 0.1485
DEBUG - 2021-11-03 11:32:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:32:50 --> No URI present. Default controller set.
DEBUG - 2021-11-03 11:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 11:32:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:02:50 --> Total execution time: 0.0312
DEBUG - 2021-11-03 11:34:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:04:04 --> Total execution time: 0.1361
DEBUG - 2021-11-03 11:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:04:07 --> Total execution time: 0.1152
DEBUG - 2021-11-03 11:34:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:04:08 --> Total execution time: 0.1176
DEBUG - 2021-11-03 11:34:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:04:36 --> Total execution time: 0.0527
DEBUG - 2021-11-03 11:38:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:08:37 --> Total execution time: 0.0396
DEBUG - 2021-11-03 11:44:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:14:10 --> Total execution time: 0.0474
DEBUG - 2021-11-03 11:44:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:14:40 --> Total execution time: 0.0469
DEBUG - 2021-11-03 11:48:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 11:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 11:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:18:15 --> Total execution time: 0.0430
DEBUG - 2021-11-03 12:00:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:30:30 --> Total execution time: 0.0740
DEBUG - 2021-11-03 12:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:00:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:00:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:00:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:00:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:32:53 --> Total execution time: 0.0568
DEBUG - 2021-11-03 12:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:02:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:02:53 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-03 12:02:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:02:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:34:05 --> Total execution time: 0.0563
DEBUG - 2021-11-03 12:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:04:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:04:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:04:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:04:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:04:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:04:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:04:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:04:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:04:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:04:16 --> 404 Page Not Found: Front/Instance_Controller/PackageBuyBulk
DEBUG - 2021-11-03 12:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:36:08 --> Total execution time: 0.0529
DEBUG - 2021-11-03 12:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:06:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:06:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:06:08 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-03 12:06:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:06:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:06:16 --> 404 Page Not Found: Front/Instance_Controller/PackageBuyBulk
DEBUG - 2021-11-03 12:07:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:07:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:07:06 --> 404 Page Not Found: Admin/Instance_Controller/PackageBuyBulk
DEBUG - 2021-11-03 12:07:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:37:14 --> Total execution time: 0.0373
DEBUG - 2021-11-03 12:07:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:07:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:07:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:07:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:07:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:07:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:07:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:07:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:07:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:07:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:07:22 --> 404 Page Not Found: Admin/Instance_Controller/PackageBuyBulk
DEBUG - 2021-11-03 12:07:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:37:50 --> Total execution time: 0.0606
DEBUG - 2021-11-03 12:07:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:07:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:07:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:07:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:07:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:07:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:07:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:07:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:07:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:07:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:07:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:07:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:07:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:07:57 --> 404 Page Not Found: Admin/InstanceController/PackageBuyBulk
DEBUG - 2021-11-03 12:08:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:38:17 --> Total execution time: 0.0494
DEBUG - 2021-11-03 12:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:08:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:08:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:08:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:08:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:08:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 12:08:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 12:08:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 12:15:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:45:39 --> Total execution time: 0.0467
DEBUG - 2021-11-03 12:15:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:15:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:15:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:15:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:15:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:15:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:15:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:15:39 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-03 12:15:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:15:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:15:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:20:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:50:29 --> Total execution time: 0.0541
DEBUG - 2021-11-03 12:22:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:22:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:22:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:22:20 --> UTF-8 Support Enabled
ERROR - 2021-11-03 12:22:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:22:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:22:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:22:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:22:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:52:53 --> Total execution time: 0.0583
DEBUG - 2021-11-03 12:23:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:23:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 17:53:00 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/instance/InstanceController.php 334
ERROR - 2021-11-03 17:53:00 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/instance/InstanceController.php 334
DEBUG - 2021-11-03 17:53:00 --> Total execution time: 0.1230
DEBUG - 2021-11-03 12:23:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:23:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:23:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:23:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:23:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:23:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:23:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:23:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:23:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:23:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 17:53:07 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/instance/InstanceController.php 334
ERROR - 2021-11-03 17:53:07 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/instance/InstanceController.php 334
DEBUG - 2021-11-03 17:53:07 --> Total execution time: 0.0560
DEBUG - 2021-11-03 12:24:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:54:09 --> Total execution time: 0.0523
DEBUG - 2021-11-03 12:24:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:24:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:24:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:24:10 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-03 12:24:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:24:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:24:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:24:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:54:25 --> Total execution time: 0.0686
DEBUG - 2021-11-03 12:24:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:54:30 --> Total execution time: 0.0468
DEBUG - 2021-11-03 12:24:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:24:31 --> UTF-8 Support Enabled
ERROR - 2021-11-03 12:24:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:24:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:24:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:24:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:24:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:24:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:54:47 --> Total execution time: 0.0511
DEBUG - 2021-11-03 12:24:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:54:52 --> Total execution time: 0.0815
DEBUG - 2021-11-03 12:24:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:24:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:24:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:24:52 --> UTF-8 Support Enabled
ERROR - 2021-11-03 12:24:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:24:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:24:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 12:24:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 12:25:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:55:00 --> Total execution time: 0.0348
DEBUG - 2021-11-03 12:25:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:55:22 --> Total execution time: 0.0385
DEBUG - 2021-11-03 12:25:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 12:25:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:55:25 --> Total execution time: 0.0625
DEBUG - 2021-11-03 12:25:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:55:26 --> Total execution time: 0.0387
DEBUG - 2021-11-03 12:25:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 12:25:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:55:31 --> Total execution time: 0.0474
DEBUG - 2021-11-03 12:25:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:55:53 --> Total execution time: 0.0515
DEBUG - 2021-11-03 12:25:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 12:26:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 12:26:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 12:26:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 17:56:47 --> Total execution time: 0.0506
DEBUG - 2021-11-03 12:43:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:13:26 --> Total execution time: 0.2708
DEBUG - 2021-11-03 12:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:15:53 --> Total execution time: 0.0453
DEBUG - 2021-11-03 12:49:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:19:32 --> Total execution time: 0.0767
DEBUG - 2021-11-03 12:53:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:23:31 --> Total execution time: 0.0743
DEBUG - 2021-11-03 12:53:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:23:32 --> Total execution time: 0.0402
DEBUG - 2021-11-03 12:53:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 12:53:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:23:39 --> Total execution time: 0.0431
DEBUG - 2021-11-03 12:53:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:23:42 --> Total execution time: 0.0416
DEBUG - 2021-11-03 12:53:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 12:53:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:23:50 --> Total execution time: 0.0405
DEBUG - 2021-11-03 12:53:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:23:52 --> Total execution time: 0.0322
DEBUG - 2021-11-03 12:53:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 12:53:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:23:56 --> Total execution time: 0.0311
DEBUG - 2021-11-03 12:55:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:25:39 --> Total execution time: 0.0611
DEBUG - 2021-11-03 12:55:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:25:40 --> Total execution time: 0.0574
DEBUG - 2021-11-03 12:55:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:25:47 --> Total execution time: 0.0580
DEBUG - 2021-11-03 12:55:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:25:52 --> Total execution time: 0.0462
DEBUG - 2021-11-03 12:58:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:28:10 --> Total execution time: 0.0457
DEBUG - 2021-11-03 12:58:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 12:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 12:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:28:14 --> Total execution time: 0.0340
DEBUG - 2021-11-03 13:02:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:32:59 --> Total execution time: 0.0840
DEBUG - 2021-11-03 13:03:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:33:22 --> Total execution time: 0.0396
DEBUG - 2021-11-03 13:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 13:03:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 13:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 13:03:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 13:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 13:03:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 13:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 13:03:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 13:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 13:03:25 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-03 13:03:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 13:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:03:25 --> UTF-8 Support Enabled
ERROR - 2021-11-03 13:03:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 13:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 13:03:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 13:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 13:03:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-03 13:03:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:33:31 --> Total execution time: 0.0349
DEBUG - 2021-11-03 13:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:33:34 --> Total execution time: 0.0367
DEBUG - 2021-11-03 13:03:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:33:54 --> Total execution time: 0.0797
DEBUG - 2021-11-03 13:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:34:06 --> Total execution time: 0.1202
DEBUG - 2021-11-03 13:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:34:08 --> Total execution time: 0.0356
DEBUG - 2021-11-03 13:04:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:34:21 --> Total execution time: 0.0359
DEBUG - 2021-11-03 13:04:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:34:27 --> Total execution time: 0.0450
DEBUG - 2021-11-03 13:04:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:34:33 --> Total execution time: 0.0339
DEBUG - 2021-11-03 13:04:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:34:34 --> Total execution time: 0.0316
DEBUG - 2021-11-03 13:04:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:34:36 --> Total execution time: 0.0305
DEBUG - 2021-11-03 13:04:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:34:39 --> Total execution time: 0.0306
DEBUG - 2021-11-03 13:07:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:37:50 --> Total execution time: 0.0377
DEBUG - 2021-11-03 13:20:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:50:45 --> Total execution time: 0.0476
DEBUG - 2021-11-03 13:21:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:51:20 --> Total execution time: 0.0335
DEBUG - 2021-11-03 13:21:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:51:37 --> Total execution time: 0.0343
DEBUG - 2021-11-03 13:28:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 13:28:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:58:42 --> Total execution time: 0.0427
DEBUG - 2021-11-03 13:28:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:28:52 --> No URI present. Default controller set.
DEBUG - 2021-11-03 13:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 13:28:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:58:52 --> Total execution time: 0.0489
DEBUG - 2021-11-03 13:28:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:58:54 --> Total execution time: 0.0952
DEBUG - 2021-11-03 13:29:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 13:29:01 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 13:29:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 18:59:21 --> Total execution time: 0.0431
DEBUG - 2021-11-03 13:30:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:00:36 --> Total execution time: 0.0430
DEBUG - 2021-11-03 13:30:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:00:37 --> Total execution time: 0.0342
DEBUG - 2021-11-03 13:30:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:00:42 --> Total execution time: 0.0617
DEBUG - 2021-11-03 13:31:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 13:31:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:01:48 --> Total execution time: 0.0300
DEBUG - 2021-11-03 13:31:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:01:51 --> Total execution time: 0.0365
DEBUG - 2021-11-03 13:31:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:01:52 --> Total execution time: 0.0301
DEBUG - 2021-11-03 13:31:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:01:52 --> Total execution time: 0.0309
DEBUG - 2021-11-03 13:31:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:01:53 --> Total execution time: 0.0332
DEBUG - 2021-11-03 13:31:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:01:54 --> Total execution time: 0.0424
DEBUG - 2021-11-03 13:32:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:02:01 --> Total execution time: 0.0422
DEBUG - 2021-11-03 13:32:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:02:02 --> Total execution time: 0.0364
DEBUG - 2021-11-03 13:32:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:02:04 --> Total execution time: 0.0370
DEBUG - 2021-11-03 13:32:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:02:07 --> Total execution time: 0.0370
DEBUG - 2021-11-03 13:32:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:02:26 --> Total execution time: 0.0441
DEBUG - 2021-11-03 13:33:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 13:33:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:03:41 --> Total execution time: 0.0538
DEBUG - 2021-11-03 13:33:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:03:43 --> Total execution time: 0.0475
DEBUG - 2021-11-03 13:33:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:03:44 --> Total execution time: 0.0376
DEBUG - 2021-11-03 13:33:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:03:54 --> Total execution time: 0.0393
DEBUG - 2021-11-03 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:04:05 --> Total execution time: 0.0418
DEBUG - 2021-11-03 13:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:34:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 13:34:07 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 13:35:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:05:42 --> Total execution time: 0.0419
DEBUG - 2021-11-03 13:35:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 13:35:56 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 13:36:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:06:13 --> Total execution time: 0.0385
DEBUG - 2021-11-03 13:36:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:36:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 13:36:17 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 13:36:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:06:52 --> Total execution time: 0.0406
DEBUG - 2021-11-03 13:37:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:07:01 --> Total execution time: 0.0426
DEBUG - 2021-11-03 13:37:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:07:04 --> Total execution time: 0.0420
DEBUG - 2021-11-03 13:37:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:07:11 --> Total execution time: 0.0728
DEBUG - 2021-11-03 13:37:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:07:16 --> Total execution time: 0.0302
DEBUG - 2021-11-03 13:37:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:07:24 --> Total execution time: 0.0310
DEBUG - 2021-11-03 13:37:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:07:39 --> Total execution time: 0.0492
DEBUG - 2021-11-03 13:39:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 13:39:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:09:19 --> Total execution time: 0.0603
DEBUG - 2021-11-03 13:39:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:09:21 --> Total execution time: 0.0357
DEBUG - 2021-11-03 13:39:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 13:39:23 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 13:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:09:37 --> Total execution time: 0.0535
DEBUG - 2021-11-03 13:39:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:09:39 --> Total execution time: 0.0495
DEBUG - 2021-11-03 13:39:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:09:39 --> Total execution time: 0.0414
DEBUG - 2021-11-03 13:39:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:09:40 --> Total execution time: 0.0325
DEBUG - 2021-11-03 13:39:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:09:45 --> Total execution time: 0.0306
DEBUG - 2021-11-03 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:09:46 --> Total execution time: 0.0344
DEBUG - 2021-11-03 13:39:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:09:47 --> Total execution time: 0.0319
DEBUG - 2021-11-03 13:39:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:09:48 --> Total execution time: 0.0315
DEBUG - 2021-11-03 13:39:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:09:50 --> Total execution time: 0.0388
DEBUG - 2021-11-03 13:39:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:09:53 --> Total execution time: 0.0344
DEBUG - 2021-11-03 13:40:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:10:07 --> Total execution time: 0.0544
DEBUG - 2021-11-03 13:40:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:10:10 --> Total execution time: 0.0742
DEBUG - 2021-11-03 13:40:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:10:11 --> Total execution time: 0.1090
DEBUG - 2021-11-03 13:40:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:10:13 --> Total execution time: 0.0363
DEBUG - 2021-11-03 13:40:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:10:16 --> Total execution time: 0.0766
DEBUG - 2021-11-03 13:40:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:10:17 --> Total execution time: 0.1765
DEBUG - 2021-11-03 13:40:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:10:19 --> Total execution time: 0.0376
DEBUG - 2021-11-03 13:40:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:10:27 --> Total execution time: 0.0408
DEBUG - 2021-11-03 13:40:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:10:28 --> Total execution time: 0.0306
DEBUG - 2021-11-03 13:40:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:10:29 --> Total execution time: 0.0519
DEBUG - 2021-11-03 13:40:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:10:32 --> Total execution time: 0.0422
DEBUG - 2021-11-03 13:40:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:10:35 --> Total execution time: 0.0374
DEBUG - 2021-11-03 13:41:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:11:52 --> Total execution time: 0.0510
DEBUG - 2021-11-03 13:42:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 13:42:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:12:01 --> Total execution time: 0.0395
DEBUG - 2021-11-03 13:42:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:12:04 --> Total execution time: 0.0697
DEBUG - 2021-11-03 13:42:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:12:07 --> Total execution time: 0.0909
DEBUG - 2021-11-03 13:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:21:31 --> Total execution time: 0.0504
DEBUG - 2021-11-03 13:51:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 13:51:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:21:39 --> Total execution time: 0.0386
DEBUG - 2021-11-03 13:51:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:21:42 --> Total execution time: 0.0374
DEBUG - 2021-11-03 13:51:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:21:44 --> Total execution time: 0.0306
DEBUG - 2021-11-03 13:53:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:23:16 --> Total execution time: 0.1947
DEBUG - 2021-11-03 13:53:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 13:53:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:23:24 --> Total execution time: 0.0384
DEBUG - 2021-11-03 13:53:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:23:28 --> Total execution time: 0.0335
DEBUG - 2021-11-03 13:54:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:24:31 --> Total execution time: 0.0370
DEBUG - 2021-11-03 13:54:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 13:54:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:24:36 --> Total execution time: 0.0468
DEBUG - 2021-11-03 13:56:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:26:55 --> Total execution time: 0.0371
DEBUG - 2021-11-03 13:57:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 13:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 13:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:27:00 --> Total execution time: 0.0316
DEBUG - 2021-11-03 14:02:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:32:41 --> Total execution time: 0.0425
DEBUG - 2021-11-03 14:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:33:35 --> Total execution time: 0.0393
DEBUG - 2021-11-03 14:03:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:33:39 --> Total execution time: 0.0351
DEBUG - 2021-11-03 14:04:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:34:32 --> Total execution time: 0.0676
DEBUG - 2021-11-03 14:04:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:04:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:34:35 --> Total execution time: 0.0984
DEBUG - 2021-11-03 14:04:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:34:39 --> Total execution time: 0.0393
DEBUG - 2021-11-03 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:35:35 --> Total execution time: 0.0594
DEBUG - 2021-11-03 14:05:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:35:38 --> Total execution time: 0.0660
DEBUG - 2021-11-03 14:05:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:35:41 --> Total execution time: 0.0602
DEBUG - 2021-11-03 14:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:36:24 --> Total execution time: 0.0418
DEBUG - 2021-11-03 14:06:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:06:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:36:31 --> Total execution time: 0.0489
DEBUG - 2021-11-03 14:06:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:36:34 --> Total execution time: 0.0317
DEBUG - 2021-11-03 14:07:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:37:11 --> Total execution time: 0.0413
DEBUG - 2021-11-03 14:07:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:07:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:37:15 --> Total execution time: 0.0425
DEBUG - 2021-11-03 14:07:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:37:19 --> Total execution time: 0.0347
DEBUG - 2021-11-03 14:11:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:41:36 --> Total execution time: 0.0512
DEBUG - 2021-11-03 14:11:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:11:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:41:41 --> Total execution time: 0.0725
DEBUG - 2021-11-03 14:11:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:41:45 --> Total execution time: 0.0433
DEBUG - 2021-11-03 14:11:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:41:49 --> Total execution time: 0.0428
DEBUG - 2021-11-03 14:12:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:12:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:42:12 --> Total execution time: 0.0409
DEBUG - 2021-11-03 14:12:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:42:17 --> Total execution time: 0.0333
DEBUG - 2021-11-03 14:12:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:42:41 --> Total execution time: 0.1182
DEBUG - 2021-11-03 14:12:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:42:41 --> Total execution time: 0.0716
DEBUG - 2021-11-03 14:12:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:12:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:42:44 --> Total execution time: 0.1358
DEBUG - 2021-11-03 14:13:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:44:00 --> Total execution time: 0.0493
DEBUG - 2021-11-03 14:14:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:14:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:44:02 --> Total execution time: 0.0433
DEBUG - 2021-11-03 14:14:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:44:06 --> Total execution time: 0.0479
DEBUG - 2021-11-03 14:14:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:44:53 --> Total execution time: 0.0431
DEBUG - 2021-11-03 14:14:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:44:53 --> Total execution time: 0.0321
DEBUG - 2021-11-03 14:14:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:14:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:44:56 --> Total execution time: 0.0359
DEBUG - 2021-11-03 14:16:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:46:20 --> Total execution time: 0.0416
DEBUG - 2021-11-03 14:16:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:16:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:46:23 --> Total execution time: 0.0425
DEBUG - 2021-11-03 14:16:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:46:26 --> Total execution time: 0.0323
DEBUG - 2021-11-03 14:16:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:46:34 --> Total execution time: 0.0516
DEBUG - 2021-11-03 14:17:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:47:51 --> Total execution time: 0.0359
DEBUG - 2021-11-03 14:17:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:17:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:47:54 --> Total execution time: 0.0395
DEBUG - 2021-11-03 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:47:58 --> Total execution time: 0.0394
DEBUG - 2021-11-03 14:19:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:49:08 --> Total execution time: 0.0415
DEBUG - 2021-11-03 14:19:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:19:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:49:20 --> Total execution time: 0.0385
DEBUG - 2021-11-03 14:19:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:49:26 --> Total execution time: 0.0371
DEBUG - 2021-11-03 14:20:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:20:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:50:25 --> Total execution time: 0.3388
DEBUG - 2021-11-03 14:20:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:20:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 14:20:34 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 14:20:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:50:36 --> Total execution time: 0.0473
DEBUG - 2021-11-03 14:20:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 14:20:38 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 14:26:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:56:35 --> Total execution time: 0.0460
DEBUG - 2021-11-03 14:26:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:56:35 --> Total execution time: 0.0681
DEBUG - 2021-11-03 14:26:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:26:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:56:43 --> Total execution time: 0.0387
DEBUG - 2021-11-03 14:29:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:59:35 --> Total execution time: 0.1533
DEBUG - 2021-11-03 14:29:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:29:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:59:43 --> Total execution time: 0.0397
DEBUG - 2021-11-03 14:29:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:59:47 --> Total execution time: 0.0559
DEBUG - 2021-11-03 14:29:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 19:59:49 --> Total execution time: 0.0327
DEBUG - 2021-11-03 14:31:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:01:07 --> Total execution time: 0.0460
DEBUG - 2021-11-03 14:31:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:01:07 --> Total execution time: 0.0474
DEBUG - 2021-11-03 14:31:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:31:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:01:12 --> Total execution time: 0.0362
DEBUG - 2021-11-03 14:32:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:02:09 --> Total execution time: 0.0446
DEBUG - 2021-11-03 14:32:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:02:10 --> Total execution time: 0.0578
DEBUG - 2021-11-03 14:32:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:32:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:02:15 --> Total execution time: 0.0767
DEBUG - 2021-11-03 14:33:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:03:14 --> Total execution time: 0.0535
DEBUG - 2021-11-03 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:03:18 --> Total execution time: 0.0455
DEBUG - 2021-11-03 14:36:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:06:18 --> Total execution time: 1.1790
DEBUG - 2021-11-03 14:36:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:06:23 --> Total execution time: 0.1115
DEBUG - 2021-11-03 14:36:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:06:24 --> Total execution time: 0.3562
DEBUG - 2021-11-03 14:36:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:36:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:06:29 --> Total execution time: 0.2792
DEBUG - 2021-11-03 14:36:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:06:40 --> Total execution time: 0.0680
DEBUG - 2021-11-03 14:37:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:07:38 --> Total execution time: 0.1080
DEBUG - 2021-11-03 14:37:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:37:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:07:43 --> Total execution time: 0.2763
DEBUG - 2021-11-03 14:37:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:07:47 --> Total execution time: 1.0949
DEBUG - 2021-11-03 14:38:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:08:24 --> Total execution time: 0.5350
DEBUG - 2021-11-03 14:38:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:38:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:08:31 --> Total execution time: 0.6620
DEBUG - 2021-11-03 14:38:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:08:34 --> Total execution time: 0.4981
DEBUG - 2021-11-03 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:09:30 --> Total execution time: 0.5063
DEBUG - 2021-11-03 14:39:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:09:32 --> Total execution time: 0.5696
DEBUG - 2021-11-03 14:39:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:39:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:09:41 --> Total execution time: 0.7509
DEBUG - 2021-11-03 14:40:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:10:31 --> Total execution time: 0.0787
DEBUG - 2021-11-03 14:40:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:10:32 --> Total execution time: 0.0716
DEBUG - 2021-11-03 14:40:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:40:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:10:35 --> Total execution time: 0.0727
DEBUG - 2021-11-03 14:41:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:11:32 --> Total execution time: 0.0520
DEBUG - 2021-11-03 14:41:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:11:33 --> Total execution time: 0.0336
DEBUG - 2021-11-03 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:11:36 --> Total execution time: 0.0362
DEBUG - 2021-11-03 14:41:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:11:43 --> Total execution time: 0.0400
DEBUG - 2021-11-03 14:41:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:11:49 --> Total execution time: 0.0424
DEBUG - 2021-11-03 14:41:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:11:49 --> Total execution time: 0.0339
DEBUG - 2021-11-03 14:41:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:11:50 --> Total execution time: 0.0307
DEBUG - 2021-11-03 14:41:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:11:51 --> Total execution time: 0.0282
DEBUG - 2021-11-03 14:42:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:12:01 --> Total execution time: 0.0460
DEBUG - 2021-11-03 14:42:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:12:01 --> Total execution time: 0.0575
DEBUG - 2021-11-03 14:42:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:12:02 --> Total execution time: 0.0800
DEBUG - 2021-11-03 14:42:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:12:09 --> Total execution time: 0.0408
DEBUG - 2021-11-03 14:42:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:12:10 --> Total execution time: 0.0378
DEBUG - 2021-11-03 14:42:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:12:11 --> Total execution time: 0.0383
DEBUG - 2021-11-03 14:42:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:12:17 --> Total execution time: 0.0396
DEBUG - 2021-11-03 14:42:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:12:20 --> Total execution time: 0.0403
DEBUG - 2021-11-03 14:42:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:12:21 --> Total execution time: 0.0350
DEBUG - 2021-11-03 14:42:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:12:22 --> Total execution time: 0.0313
DEBUG - 2021-11-03 14:42:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:12:23 --> Total execution time: 0.0321
DEBUG - 2021-11-03 14:42:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:12:24 --> Total execution time: 0.0318
DEBUG - 2021-11-03 14:43:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:08 --> Total execution time: 0.0451
DEBUG - 2021-11-03 14:43:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:09 --> Total execution time: 0.0462
DEBUG - 2021-11-03 14:43:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:10 --> Total execution time: 0.0380
DEBUG - 2021-11-03 14:43:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:12 --> Total execution time: 0.0353
DEBUG - 2021-11-03 14:43:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:16 --> Total execution time: 0.0347
DEBUG - 2021-11-03 14:43:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:20 --> Total execution time: 0.0369
DEBUG - 2021-11-03 14:43:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:22 --> Total execution time: 0.0480
DEBUG - 2021-11-03 14:43:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:23 --> Total execution time: 0.0469
DEBUG - 2021-11-03 14:43:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:24 --> Total execution time: 0.0375
DEBUG - 2021-11-03 14:43:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:25 --> Total execution time: 0.0345
DEBUG - 2021-11-03 14:43:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:33 --> Total execution time: 0.0310
DEBUG - 2021-11-03 14:43:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:34 --> Total execution time: 0.0467
DEBUG - 2021-11-03 14:43:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:35 --> Total execution time: 0.0349
DEBUG - 2021-11-03 14:43:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:36 --> Total execution time: 0.0737
DEBUG - 2021-11-03 14:43:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:38 --> Total execution time: 0.0440
DEBUG - 2021-11-03 14:43:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:42 --> Total execution time: 0.0398
DEBUG - 2021-11-03 14:43:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:52 --> Total execution time: 0.0304
DEBUG - 2021-11-03 14:43:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:13:58 --> Total execution time: 0.0612
DEBUG - 2021-11-03 14:44:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:14:03 --> Total execution time: 0.0868
DEBUG - 2021-11-03 14:44:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:14:07 --> Total execution time: 0.0516
DEBUG - 2021-11-03 14:45:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:15:22 --> Total execution time: 0.0548
DEBUG - 2021-11-03 14:47:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:17:34 --> Total execution time: 0.2607
DEBUG - 2021-11-03 14:47:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:17:43 --> Total execution time: 0.0849
DEBUG - 2021-11-03 14:47:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:17:47 --> Total execution time: 0.1381
DEBUG - 2021-11-03 14:47:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:17:57 --> Total execution time: 0.1083
DEBUG - 2021-11-03 14:48:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:02 --> Total execution time: 0.0746
DEBUG - 2021-11-03 14:48:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:09 --> Total execution time: 0.0557
DEBUG - 2021-11-03 14:48:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:13 --> Total execution time: 0.0305
DEBUG - 2021-11-03 14:48:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:23 --> Total execution time: 0.0520
DEBUG - 2021-11-03 14:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:32 --> Total execution time: 0.0375
DEBUG - 2021-11-03 14:48:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:37 --> Total execution time: 0.0499
DEBUG - 2021-11-03 14:48:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 14:48:39 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 14:48:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:41 --> Total execution time: 1.6188
DEBUG - 2021-11-03 14:48:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:42 --> Total execution time: 0.2463
DEBUG - 2021-11-03 14:48:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:43 --> Total execution time: 0.0504
DEBUG - 2021-11-03 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:44 --> Total execution time: 0.0451
DEBUG - 2021-11-03 14:48:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:45 --> Total execution time: 0.0529
DEBUG - 2021-11-03 14:48:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:46 --> Total execution time: 0.0364
DEBUG - 2021-11-03 14:48:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:47 --> Total execution time: 0.0384
DEBUG - 2021-11-03 14:48:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:48 --> Total execution time: 0.0467
DEBUG - 2021-11-03 14:48:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:49 --> Total execution time: 0.0354
DEBUG - 2021-11-03 14:48:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:50 --> Total execution time: 0.0356
DEBUG - 2021-11-03 14:48:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:18:50 --> Total execution time: 0.0410
DEBUG - 2021-11-03 14:48:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:18:51 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode41.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:18:51 --> Total execution time: 0.2675
DEBUG - 2021-11-03 14:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:18:52 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode67.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:18:52 --> Total execution time: 0.0649
DEBUG - 2021-11-03 14:48:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:18:53 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode77.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:18:53 --> Total execution time: 0.0646
DEBUG - 2021-11-03 14:48:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:18:54 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode134.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:18:54 --> Total execution time: 0.0693
DEBUG - 2021-11-03 14:48:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:18:55 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode170.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:18:55 --> Total execution time: 0.0618
DEBUG - 2021-11-03 14:48:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:18:56 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode68.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:18:56 --> Total execution time: 0.0854
DEBUG - 2021-11-03 14:48:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:18:57 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode80.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:18:57 --> Total execution time: 0.0639
DEBUG - 2021-11-03 14:48:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:18:58 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode198.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:18:58 --> Total execution time: 0.0808
DEBUG - 2021-11-03 14:48:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:48:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:18:59 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode65.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:18:59 --> Total execution time: 0.0745
DEBUG - 2021-11-03 14:48:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:48:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 14:48:59 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-03 14:49:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:19:00 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode62.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:00 --> Total execution time: 0.0695
DEBUG - 2021-11-03 14:49:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:19:01 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode116.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:01 --> Total execution time: 0.0629
DEBUG - 2021-11-03 14:49:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:19:02 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode37.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:02 --> Total execution time: 0.1316
DEBUG - 2021-11-03 14:49:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:19:03 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode141.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:03 --> Total execution time: 0.0757
DEBUG - 2021-11-03 14:49:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:19:04 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode195.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:04 --> Total execution time: 0.0656
DEBUG - 2021-11-03 14:49:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:19:05 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode85.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:05 --> Total execution time: 0.0732
DEBUG - 2021-11-03 14:49:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:19:06 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode10.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:06 --> Total execution time: 0.0696
DEBUG - 2021-11-03 14:49:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:49:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 20:19:07 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode136.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:07 --> Total execution time: 0.0724
DEBUG - 2021-11-03 14:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:07 --> Total execution time: 0.0383
DEBUG - 2021-11-03 14:49:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:19:08 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode192.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:08 --> Total execution time: 0.0668
DEBUG - 2021-11-03 14:49:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:19:09 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode60.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:09 --> Total execution time: 0.0673
DEBUG - 2021-11-03 14:49:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:19:10 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode198.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:10 --> Total execution time: 0.0665
DEBUG - 2021-11-03 14:49:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:19:11 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode150.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:11 --> Total execution time: 0.0745
DEBUG - 2021-11-03 14:49:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:19:12 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode44.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:12 --> Total execution time: 0.0682
DEBUG - 2021-11-03 14:49:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:19:13 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode164.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:13 --> Total execution time: 0.0639
DEBUG - 2021-11-03 14:49:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:19:14 --> Severity: Warning --> imagepng(/home2/whatsmessaging/cp.whatsmessaging.com/cpnew/assets/qr/1@6mDi/LR-Qrcode140.png): failed to open stream: No such file or directory /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/third_party/qrcode/phpqrcode/qrimage.php 43
DEBUG - 2021-11-03 20:19:14 --> Total execution time: 0.0875
DEBUG - 2021-11-03 14:49:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 14:49:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 20:19:15 --> Total execution time: 1.0621
DEBUG - 2021-11-03 14:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:15 --> Total execution time: 0.3511
DEBUG - 2021-11-03 14:49:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:15 --> Total execution time: 0.0362
DEBUG - 2021-11-03 14:49:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:16 --> Total execution time: 0.0381
DEBUG - 2021-11-03 14:49:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:17 --> Total execution time: 0.0387
DEBUG - 2021-11-03 14:49:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:18 --> Total execution time: 0.0324
DEBUG - 2021-11-03 14:49:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:18 --> Total execution time: 0.0710
DEBUG - 2021-11-03 14:49:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:19 --> Total execution time: 0.0364
DEBUG - 2021-11-03 14:49:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:20 --> Total execution time: 0.0391
DEBUG - 2021-11-03 14:49:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:21 --> Total execution time: 0.0367
DEBUG - 2021-11-03 14:49:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:22 --> Total execution time: 0.0340
DEBUG - 2021-11-03 14:49:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:23 --> Total execution time: 0.0517
DEBUG - 2021-11-03 14:49:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:24 --> Total execution time: 0.0430
DEBUG - 2021-11-03 14:49:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:25 --> Total execution time: 0.0354
DEBUG - 2021-11-03 14:49:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:26 --> Total execution time: 0.0373
DEBUG - 2021-11-03 14:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:27 --> Total execution time: 0.0404
DEBUG - 2021-11-03 14:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:28 --> Total execution time: 0.0372
DEBUG - 2021-11-03 14:49:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:29 --> Total execution time: 0.0374
DEBUG - 2021-11-03 14:49:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:30 --> Total execution time: 0.0434
DEBUG - 2021-11-03 14:49:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:33 --> Total execution time: 0.0343
DEBUG - 2021-11-03 14:49:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:33 --> Total execution time: 0.0388
DEBUG - 2021-11-03 14:49:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:33 --> Total execution time: 0.0327
DEBUG - 2021-11-03 14:49:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:34 --> Total execution time: 0.0332
DEBUG - 2021-11-03 14:49:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:35 --> Total execution time: 0.0452
DEBUG - 2021-11-03 14:49:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:35 --> Total execution time: 0.0401
DEBUG - 2021-11-03 14:49:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:19:36 --> Total execution time: 0.0411
DEBUG - 2021-11-03 14:55:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:25:46 --> Total execution time: 0.0605
DEBUG - 2021-11-03 14:55:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:25:48 --> Total execution time: 0.0338
DEBUG - 2021-11-03 14:55:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:25:51 --> Total execution time: 0.0373
DEBUG - 2021-11-03 14:56:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:26:34 --> Total execution time: 0.0401
DEBUG - 2021-11-03 14:56:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:26:36 --> Total execution time: 0.0332
DEBUG - 2021-11-03 14:56:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:26:41 --> Total execution time: 0.0451
DEBUG - 2021-11-03 14:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:26:42 --> Total execution time: 0.0325
DEBUG - 2021-11-03 14:56:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 14:56:45 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 14:56:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:26:50 --> Total execution time: 0.0358
DEBUG - 2021-11-03 14:56:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:26:50 --> Total execution time: 0.0490
DEBUG - 2021-11-03 14:57:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 14:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 14:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:27:55 --> Total execution time: 0.0533
DEBUG - 2021-11-03 15:00:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:30:27 --> Total execution time: 0.0630
DEBUG - 2021-11-03 15:00:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:30:34 --> Total execution time: 0.1058
DEBUG - 2021-11-03 15:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:01:00 --> No URI present. Default controller set.
DEBUG - 2021-11-03 15:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 15:01:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:31:01 --> Total execution time: 0.0455
DEBUG - 2021-11-03 15:01:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:31:32 --> Total execution time: 0.0869
DEBUG - 2021-11-03 15:01:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:31:34 --> Total execution time: 0.0356
DEBUG - 2021-11-03 15:02:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:32:14 --> Total execution time: 0.0433
DEBUG - 2021-11-03 15:03:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:33:02 --> Total execution time: 0.0467
DEBUG - 2021-11-03 15:04:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:34:02 --> Total execution time: 0.0693
DEBUG - 2021-11-03 15:05:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:05:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 20:35:07 --> Severity: Notice --> Undefined index: secret_key /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/API/API_Controller.php 26
ERROR - 2021-11-03 20:35:07 --> Severity: Notice --> Undefined index: secret_id /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/API/API_Controller.php 27
DEBUG - 2021-11-03 20:35:07 --> Total execution time: 0.0568
DEBUG - 2021-11-03 15:05:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:35:32 --> Total execution time: 0.0462
DEBUG - 2021-11-03 15:13:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:43:32 --> Total execution time: 0.0913
DEBUG - 2021-11-03 15:13:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:43:34 --> Total execution time: 0.0419
DEBUG - 2021-11-03 15:13:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:43:35 --> Total execution time: 0.0525
DEBUG - 2021-11-03 15:13:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:43:35 --> Total execution time: 0.0317
DEBUG - 2021-11-03 15:13:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:43:40 --> Total execution time: 0.0308
DEBUG - 2021-11-03 15:14:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:44:20 --> Total execution time: 0.0370
DEBUG - 2021-11-03 15:14:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:44:23 --> Total execution time: 0.0400
DEBUG - 2021-11-03 15:14:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:44:33 --> Total execution time: 0.0425
DEBUG - 2021-11-03 15:14:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:44:57 --> Total execution time: 0.1062
DEBUG - 2021-11-03 15:15:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:45:08 --> Total execution time: 0.0615
DEBUG - 2021-11-03 15:19:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:49:28 --> Total execution time: 0.0697
DEBUG - 2021-11-03 15:19:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 20:49:35 --> Total execution time: 0.0450
DEBUG - 2021-11-03 15:32:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:32:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 21:02:21 --> Severity: Notice --> Undefined variable: mobile /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 13
ERROR - 2021-11-03 21:02:21 --> Severity: Notice --> Undefined variable: message /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 14
DEBUG - 2021-11-03 21:02:21 --> Total execution time: 0.0499
DEBUG - 2021-11-03 15:32:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 21:02:56 --> Total execution time: 0.0420
DEBUG - 2021-11-03 15:33:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 21:03:55 --> Total execution time: 0.0450
DEBUG - 2021-11-03 15:36:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:36:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 21:06:38 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 592
DEBUG - 2021-11-03 15:36:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:36:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 21:06:56 --> Severity: Notice --> Undefined variable: curl /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 573
ERROR - 2021-11-03 21:06:56 --> Severity: Warning --> curl_setopt_array() expects parameter 1 to be resource, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 574
ERROR - 2021-11-03 21:06:56 --> Severity: Notice --> Undefined variable: curl /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 588
ERROR - 2021-11-03 21:06:56 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 588
ERROR - 2021-11-03 21:06:56 --> Severity: Notice --> Undefined variable: curl /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 589
ERROR - 2021-11-03 21:06:56 --> Severity: Warning --> curl_close() expects parameter 1 to be resource, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 589
DEBUG - 2021-11-03 21:06:56 --> Total execution time: 0.0421
DEBUG - 2021-11-03 15:37:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 21:07:20 --> Total execution time: 3.1072
DEBUG - 2021-11-03 15:41:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 21:11:24 --> Total execution time: 1.4557
DEBUG - 2021-11-03 15:42:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 21:12:34 --> Total execution time: 1.5601
DEBUG - 2021-11-03 15:42:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 21:12:38 --> Total execution time: 0.0773
DEBUG - 2021-11-03 15:42:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 21:12:40 --> Total execution time: 0.0458
DEBUG - 2021-11-03 15:42:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 21:12:49 --> Total execution time: 0.0844
DEBUG - 2021-11-03 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 15:42:50 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-03 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 15:42:50 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-03 15:42:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 21:12:57 --> Total execution time: 1.4060
DEBUG - 2021-11-03 15:43:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 21:13:02 --> Total execution time: 0.0646
DEBUG - 2021-11-03 15:43:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:43:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 15:43:02 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-03 15:43:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:43:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 15:43:02 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-03 15:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:50:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-03 21:20:55 --> Severity: error --> Exception: syntax error, unexpected 'return' (T_RETURN) /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 26
DEBUG - 2021-11-03 15:51:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 15:51:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 21:21:08 --> Total execution time: 1.4245
DEBUG - 2021-11-03 15:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 21:21:09 --> Total execution time: 1.9813
DEBUG - 2021-11-03 15:51:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 15:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 15:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 21:21:25 --> Total execution time: 1.3461
DEBUG - 2021-11-03 16:27:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 21:57:59 --> Total execution time: 0.0637
DEBUG - 2021-11-03 16:28:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 21:58:13 --> Total execution time: 1.3789
DEBUG - 2021-11-03 16:34:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 22:04:03 --> Total execution time: 1.4748
DEBUG - 2021-11-03 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 22:04:10 --> Total execution time: 1.3641
DEBUG - 2021-11-03 16:36:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 22:06:37 --> Total execution time: 0.0697
DEBUG - 2021-11-03 16:36:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:36:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:36:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 16:36:38 --> 404 Page Not Found: Assets/front
ERROR - 2021-11-03 16:36:38 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-03 16:36:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 22:06:41 --> Total execution time: 0.0497
DEBUG - 2021-11-03 16:36:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 22:06:43 --> Total execution time: 0.0322
DEBUG - 2021-11-03 16:39:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 22:09:39 --> Total execution time: 0.1330
DEBUG - 2021-11-03 16:39:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 16:39:55 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 16:40:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 22:10:09 --> Total execution time: 0.3861
DEBUG - 2021-11-03 16:40:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 16:40:13 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-03 16:40:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 22:10:46 --> Total execution time: 0.6629
DEBUG - 2021-11-03 16:41:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 16:41:20 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-03 16:41:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:41:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 16:41:21 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 16:42:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 22:12:06 --> Total execution time: 0.0739
DEBUG - 2021-11-03 16:42:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 16:42:12 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 16:44:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 22:14:53 --> Total execution time: 0.0490
DEBUG - 2021-11-03 16:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 22:15:53 --> Total execution time: 0.0942
DEBUG - 2021-11-03 16:48:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 22:18:22 --> Total execution time: 0.0471
DEBUG - 2021-11-03 16:48:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 16:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 16:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 22:18:29 --> Total execution time: 0.0469
DEBUG - 2021-11-03 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-03 17:02:25 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-03 17:05:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-03 17:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-03 17:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-03 22:35:10 --> Total execution time: 0.2342
