<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-06-02 00:04:25 --> Total execution time: 0.0964
DEBUG - 2022-06-02 00:07:33 --> Total execution time: 0.1287
DEBUG - 2022-06-02 00:07:55 --> Total execution time: 0.0229
DEBUG - 2022-06-02 00:08:10 --> Total execution time: 0.0276
DEBUG - 2022-06-02 00:08:33 --> Total execution time: 0.0287
DEBUG - 2022-06-02 00:08:47 --> Total execution time: 0.0620
DEBUG - 2022-06-02 00:09:00 --> Total execution time: 0.0433
DEBUG - 2022-06-02 00:09:12 --> Total execution time: 0.0510
DEBUG - 2022-06-02 00:09:43 --> Total execution time: 0.0323
DEBUG - 2022-06-02 00:09:46 --> Total execution time: 0.0335
DEBUG - 2022-06-02 00:09:49 --> Total execution time: 0.0464
DEBUG - 2022-06-02 00:10:10 --> Total execution time: 0.0462
DEBUG - 2022-06-02 00:10:24 --> Total execution time: 0.0298
DEBUG - 2022-06-02 00:10:33 --> Total execution time: 0.0308
DEBUG - 2022-06-02 00:10:44 --> Total execution time: 0.0420
DEBUG - 2022-06-02 00:11:08 --> Total execution time: 0.0262
DEBUG - 2022-06-02 00:11:13 --> Total execution time: 0.0546
DEBUG - 2022-06-02 00:11:44 --> Total execution time: 0.0290
DEBUG - 2022-06-02 00:12:05 --> Total execution time: 0.0342
DEBUG - 2022-06-02 00:12:27 --> Total execution time: 0.0348
DEBUG - 2022-06-02 00:30:02 --> Total execution time: 0.3313
DEBUG - 2022-06-02 00:30:34 --> Total execution time: 0.0317
DEBUG - 2022-06-02 00:30:47 --> Total execution time: 0.0550
DEBUG - 2022-06-02 00:31:14 --> Total execution time: 0.0644
DEBUG - 2022-06-02 00:31:33 --> Total execution time: 0.0471
DEBUG - 2022-06-02 00:31:41 --> Total execution time: 0.0368
DEBUG - 2022-06-02 00:31:45 --> Total execution time: 0.0411
DEBUG - 2022-06-02 00:31:57 --> Total execution time: 0.0267
DEBUG - 2022-06-02 00:32:19 --> Total execution time: 0.0556
DEBUG - 2022-06-02 00:33:28 --> Total execution time: 0.0561
DEBUG - 2022-06-02 00:35:54 --> Total execution time: 0.0870
DEBUG - 2022-06-02 00:38:11 --> Total execution time: 0.0626
DEBUG - 2022-06-02 00:51:30 --> Total execution time: 0.1478
DEBUG - 2022-06-02 00:53:20 --> Total execution time: 0.0274
DEBUG - 2022-06-02 00:54:11 --> Total execution time: 0.0386
DEBUG - 2022-06-02 00:57:55 --> Total execution time: 0.0314
DEBUG - 2022-06-02 00:58:30 --> Total execution time: 0.0583
DEBUG - 2022-06-02 01:23:21 --> Total execution time: 0.1334
DEBUG - 2022-06-02 01:30:02 --> Total execution time: 0.2006
DEBUG - 2022-06-02 01:34:34 --> Total execution time: 0.0275
DEBUG - 2022-06-02 01:56:33 --> Total execution time: 0.0380
DEBUG - 2022-06-02 01:56:38 --> Total execution time: 0.0583
DEBUG - 2022-06-02 01:56:40 --> Total execution time: 0.0802
DEBUG - 2022-06-02 01:56:44 --> Total execution time: 0.0362
DEBUG - 2022-06-02 01:57:59 --> Total execution time: 0.0552
DEBUG - 2022-06-02 01:58:00 --> Total execution time: 0.0593
DEBUG - 2022-06-02 01:58:03 --> Total execution time: 0.0500
DEBUG - 2022-06-02 01:58:44 --> Total execution time: 0.0370
DEBUG - 2022-06-02 02:00:37 --> Total execution time: 0.0603
DEBUG - 2022-06-02 02:00:38 --> Total execution time: 0.0510
DEBUG - 2022-06-02 02:00:38 --> Total execution time: 0.0735
DEBUG - 2022-06-02 02:00:39 --> Total execution time: 0.0498
DEBUG - 2022-06-02 02:00:39 --> Total execution time: 0.0588
DEBUG - 2022-06-02 02:00:40 --> Total execution time: 0.0450
DEBUG - 2022-06-02 02:05:35 --> Total execution time: 0.0664
DEBUG - 2022-06-02 02:05:36 --> Total execution time: 0.0266
DEBUG - 2022-06-02 02:05:38 --> Total execution time: 0.0254
DEBUG - 2022-06-02 02:07:50 --> Total execution time: 0.0760
DEBUG - 2022-06-02 02:08:13 --> Total execution time: 0.0263
DEBUG - 2022-06-02 02:08:28 --> Total execution time: 0.0258
DEBUG - 2022-06-02 02:08:31 --> Total execution time: 0.0456
DEBUG - 2022-06-02 02:08:33 --> Total execution time: 0.0555
DEBUG - 2022-06-02 02:08:36 --> Total execution time: 0.0510
DEBUG - 2022-06-02 02:08:37 --> Total execution time: 0.0667
DEBUG - 2022-06-02 02:08:37 --> Total execution time: 0.0517
DEBUG - 2022-06-02 02:08:37 --> Total execution time: 0.0512
DEBUG - 2022-06-02 02:08:38 --> Total execution time: 0.0432
DEBUG - 2022-06-02 02:08:38 --> Total execution time: 0.0340
DEBUG - 2022-06-02 02:08:39 --> Total execution time: 0.0531
DEBUG - 2022-06-02 02:08:39 --> Total execution time: 0.0852
DEBUG - 2022-06-02 02:08:43 --> Total execution time: 0.0543
DEBUG - 2022-06-02 02:08:57 --> Total execution time: 1.3113
DEBUG - 2022-06-02 02:09:32 --> Total execution time: 1.2397
DEBUG - 2022-06-02 02:10:35 --> Total execution time: 0.0328
DEBUG - 2022-06-02 02:20:35 --> Total execution time: 0.0499
DEBUG - 2022-06-02 02:30:03 --> Total execution time: 0.2466
DEBUG - 2022-06-02 02:32:15 --> Total execution time: 0.0469
DEBUG - 2022-06-02 02:46:28 --> Total execution time: 0.1343
DEBUG - 2022-06-02 03:27:53 --> Total execution time: 0.1319
DEBUG - 2022-06-02 03:27:56 --> Total execution time: 0.0229
DEBUG - 2022-06-02 03:30:03 --> Total execution time: 0.0813
DEBUG - 2022-06-02 04:30:03 --> Total execution time: 0.3319
DEBUG - 2022-06-02 05:30:03 --> Total execution time: 0.3534
DEBUG - 2022-06-02 05:50:45 --> Total execution time: 0.0384
DEBUG - 2022-06-02 05:54:35 --> Total execution time: 0.0796
DEBUG - 2022-06-02 05:54:54 --> Total execution time: 0.0486
DEBUG - 2022-06-02 05:55:01 --> Total execution time: 0.0165
DEBUG - 2022-06-02 05:55:18 --> Total execution time: 0.0215
DEBUG - 2022-06-02 06:02:41 --> Total execution time: 0.0927
DEBUG - 2022-06-02 06:02:43 --> Total execution time: 0.0229
DEBUG - 2022-06-02 06:04:29 --> Total execution time: 0.0299
DEBUG - 2022-06-02 06:04:39 --> Total execution time: 0.0280
DEBUG - 2022-06-02 06:05:02 --> Total execution time: 0.0396
DEBUG - 2022-06-02 06:05:07 --> Total execution time: 0.0271
DEBUG - 2022-06-02 06:05:10 --> Total execution time: 0.0249
DEBUG - 2022-06-02 06:05:21 --> Total execution time: 0.0512
DEBUG - 2022-06-02 06:05:34 --> Total execution time: 0.0394
DEBUG - 2022-06-02 06:05:52 --> Total execution time: 0.0349
DEBUG - 2022-06-02 06:06:03 --> Total execution time: 0.0255
DEBUG - 2022-06-02 06:11:40 --> Total execution time: 0.0764
DEBUG - 2022-06-02 06:12:11 --> Total execution time: 0.0261
DEBUG - 2022-06-02 06:17:58 --> Total execution time: 0.0782
DEBUG - 2022-06-02 06:19:13 --> Total execution time: 0.0327
DEBUG - 2022-06-02 06:19:14 --> Total execution time: 0.0250
DEBUG - 2022-06-02 06:19:17 --> Total execution time: 0.0314
DEBUG - 2022-06-02 06:19:34 --> Total execution time: 0.0248
DEBUG - 2022-06-02 06:20:05 --> Total execution time: 0.0385
DEBUG - 2022-06-02 06:20:13 --> Total execution time: 0.0326
DEBUG - 2022-06-02 06:20:38 --> Total execution time: 0.1667
DEBUG - 2022-06-02 06:21:12 --> Total execution time: 0.0562
DEBUG - 2022-06-02 06:21:15 --> Total execution time: 0.0363
DEBUG - 2022-06-02 06:21:24 --> Total execution time: 0.0404
DEBUG - 2022-06-02 06:22:00 --> Total execution time: 0.0414
DEBUG - 2022-06-02 06:23:03 --> Total execution time: 0.0261
DEBUG - 2022-06-02 06:23:26 --> Total execution time: 0.0332
DEBUG - 2022-06-02 06:28:31 --> Total execution time: 0.0829
DEBUG - 2022-06-02 06:30:02 --> Total execution time: 0.0682
DEBUG - 2022-06-02 06:30:47 --> Total execution time: 0.0301
DEBUG - 2022-06-02 06:32:56 --> Total execution time: 0.0278
DEBUG - 2022-06-02 06:33:06 --> Total execution time: 0.0421
DEBUG - 2022-06-02 06:33:13 --> Total execution time: 0.0535
DEBUG - 2022-06-02 06:33:38 --> Total execution time: 0.0442
DEBUG - 2022-06-02 06:33:54 --> Total execution time: 0.0425
DEBUG - 2022-06-02 06:34:07 --> Total execution time: 0.0256
DEBUG - 2022-06-02 06:34:10 --> Total execution time: 0.0336
DEBUG - 2022-06-02 06:34:28 --> Total execution time: 0.0271
DEBUG - 2022-06-02 06:34:52 --> Total execution time: 0.0317
DEBUG - 2022-06-02 06:35:02 --> Total execution time: 0.0527
DEBUG - 2022-06-02 06:35:03 --> Total execution time: 0.0361
DEBUG - 2022-06-02 06:35:08 --> Total execution time: 0.0265
DEBUG - 2022-06-02 06:35:11 --> Total execution time: 0.0250
DEBUG - 2022-06-02 06:35:13 --> Total execution time: 0.0410
DEBUG - 2022-06-02 06:35:16 --> Total execution time: 0.0585
DEBUG - 2022-06-02 06:35:19 --> Total execution time: 0.0417
DEBUG - 2022-06-02 06:35:22 --> Total execution time: 0.0335
DEBUG - 2022-06-02 06:35:23 --> Total execution time: 0.0333
DEBUG - 2022-06-02 06:35:26 --> Total execution time: 0.0301
DEBUG - 2022-06-02 06:35:35 --> Total execution time: 0.0257
DEBUG - 2022-06-02 06:38:08 --> Total execution time: 0.0272
DEBUG - 2022-06-02 06:39:58 --> Total execution time: 0.0259
DEBUG - 2022-06-02 06:40:03 --> Total execution time: 0.0606
DEBUG - 2022-06-02 06:40:06 --> Total execution time: 0.0339
DEBUG - 2022-06-02 06:40:21 --> Total execution time: 0.0196
DEBUG - 2022-06-02 06:40:33 --> Total execution time: 0.0279
DEBUG - 2022-06-02 06:40:37 --> Total execution time: 0.0229
DEBUG - 2022-06-02 06:40:38 --> Total execution time: 0.0210
DEBUG - 2022-06-02 06:40:40 --> Total execution time: 0.0542
DEBUG - 2022-06-02 06:40:45 --> Total execution time: 0.0190
DEBUG - 2022-06-02 06:41:07 --> Total execution time: 0.0227
DEBUG - 2022-06-02 06:41:09 --> Total execution time: 0.0242
DEBUG - 2022-06-02 06:41:21 --> Total execution time: 0.0450
DEBUG - 2022-06-02 06:41:24 --> Total execution time: 1.5590
DEBUG - 2022-06-02 06:41:25 --> Total execution time: 0.0225
DEBUG - 2022-06-02 06:41:25 --> Total execution time: 0.0222
DEBUG - 2022-06-02 06:41:33 --> Total execution time: 0.0245
DEBUG - 2022-06-02 06:41:34 --> Total execution time: 0.0581
DEBUG - 2022-06-02 06:41:37 --> Total execution time: 0.0404
DEBUG - 2022-06-02 06:41:39 --> Total execution time: 0.0358
DEBUG - 2022-06-02 06:41:43 --> Total execution time: 0.0295
DEBUG - 2022-06-02 06:42:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 06:42:01 --> Total execution time: 0.0316
DEBUG - 2022-06-02 06:42:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 06:42:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 06:42:02 --> Total execution time: 0.1635
DEBUG - 2022-06-02 06:42:03 --> Total execution time: 0.0286
DEBUG - 2022-06-02 06:42:07 --> Total execution time: 0.0485
DEBUG - 2022-06-02 06:42:09 --> Total execution time: 0.0436
DEBUG - 2022-06-02 06:42:12 --> Total execution time: 0.0598
DEBUG - 2022-06-02 06:42:21 --> Total execution time: 0.0231
DEBUG - 2022-06-02 06:42:27 --> Total execution time: 0.0352
DEBUG - 2022-06-02 06:42:30 --> Total execution time: 0.0356
DEBUG - 2022-06-02 06:42:33 --> Total execution time: 0.0269
DEBUG - 2022-06-02 06:42:35 --> Total execution time: 0.0281
DEBUG - 2022-06-02 06:42:36 --> Total execution time: 0.0278
DEBUG - 2022-06-02 06:42:37 --> Total execution time: 0.0482
DEBUG - 2022-06-02 06:42:52 --> Total execution time: 0.0865
DEBUG - 2022-06-02 06:42:59 --> Total execution time: 0.0243
DEBUG - 2022-06-02 06:43:03 --> Total execution time: 0.0273
DEBUG - 2022-06-02 06:43:08 --> Total execution time: 0.0183
DEBUG - 2022-06-02 06:43:15 --> Total execution time: 0.0547
DEBUG - 2022-06-02 06:43:30 --> Total execution time: 0.0315
DEBUG - 2022-06-02 06:43:31 --> Total execution time: 0.0186
DEBUG - 2022-06-02 06:43:34 --> Total execution time: 0.0452
DEBUG - 2022-06-02 06:43:43 --> Total execution time: 0.0275
DEBUG - 2022-06-02 06:43:52 --> Total execution time: 0.0361
DEBUG - 2022-06-02 06:43:57 --> Total execution time: 0.0245
DEBUG - 2022-06-02 06:45:10 --> Total execution time: 0.0343
DEBUG - 2022-06-02 06:46:37 --> Total execution time: 0.0236
DEBUG - 2022-06-02 06:47:33 --> Total execution time: 0.0226
DEBUG - 2022-06-02 06:47:37 --> Total execution time: 0.0302
DEBUG - 2022-06-02 06:48:26 --> Total execution time: 0.0397
DEBUG - 2022-06-02 06:48:46 --> Total execution time: 0.0317
DEBUG - 2022-06-02 06:49:09 --> Total execution time: 0.0591
DEBUG - 2022-06-02 06:49:18 --> Total execution time: 0.0375
DEBUG - 2022-06-02 06:49:21 --> Total execution time: 0.0439
DEBUG - 2022-06-02 06:49:45 --> Total execution time: 0.0367
DEBUG - 2022-06-02 06:49:50 --> Total execution time: 0.0301
DEBUG - 2022-06-02 06:51:51 --> Total execution time: 0.0274
DEBUG - 2022-06-02 06:51:54 --> Total execution time: 0.0455
DEBUG - 2022-06-02 06:51:55 --> Total execution time: 0.0171
DEBUG - 2022-06-02 06:52:18 --> Total execution time: 0.0310
DEBUG - 2022-06-02 06:52:23 --> Total execution time: 0.0239
DEBUG - 2022-06-02 06:52:25 --> Total execution time: 0.0503
DEBUG - 2022-06-02 06:52:45 --> Total execution time: 0.0518
DEBUG - 2022-06-02 06:52:50 --> Total execution time: 0.0473
DEBUG - 2022-06-02 06:52:51 --> Total execution time: 0.0263
DEBUG - 2022-06-02 07:02:52 --> Total execution time: 0.1117
DEBUG - 2022-06-02 07:02:55 --> Total execution time: 0.0252
DEBUG - 2022-06-02 07:03:51 --> Total execution time: 0.0213
DEBUG - 2022-06-02 07:04:36 --> Total execution time: 0.0235
DEBUG - 2022-06-02 07:04:53 --> Total execution time: 0.0284
DEBUG - 2022-06-02 07:05:04 --> Total execution time: 0.0354
DEBUG - 2022-06-02 07:05:06 --> Total execution time: 0.0327
DEBUG - 2022-06-02 07:05:10 --> Total execution time: 0.0203
DEBUG - 2022-06-02 07:05:22 --> Total execution time: 0.0332
DEBUG - 2022-06-02 07:05:57 --> Total execution time: 0.0319
DEBUG - 2022-06-02 07:06:14 --> Total execution time: 0.0370
DEBUG - 2022-06-02 07:06:27 --> Total execution time: 0.0324
DEBUG - 2022-06-02 07:06:35 --> Total execution time: 0.0377
DEBUG - 2022-06-02 07:06:51 --> Total execution time: 0.0268
DEBUG - 2022-06-02 07:06:56 --> Total execution time: 0.0292
DEBUG - 2022-06-02 07:08:20 --> Total execution time: 1.5028
DEBUG - 2022-06-02 07:08:40 --> Total execution time: 0.0303
DEBUG - 2022-06-02 07:08:41 --> Total execution time: 0.0524
DEBUG - 2022-06-02 07:08:50 --> Total execution time: 0.0354
DEBUG - 2022-06-02 07:09:07 --> Total execution time: 0.0688
DEBUG - 2022-06-02 07:09:22 --> Total execution time: 0.0311
DEBUG - 2022-06-02 07:09:43 --> Total execution time: 0.0350
DEBUG - 2022-06-02 07:10:04 --> Total execution time: 0.0257
DEBUG - 2022-06-02 07:10:14 --> Total execution time: 0.0253
DEBUG - 2022-06-02 07:10:19 --> Total execution time: 0.0429
DEBUG - 2022-06-02 07:10:30 --> Total execution time: 0.0296
DEBUG - 2022-06-02 07:10:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 07:10:31 --> Total execution time: 0.0283
DEBUG - 2022-06-02 07:10:51 --> Total execution time: 0.0272
DEBUG - 2022-06-02 07:11:17 --> Total execution time: 0.0271
DEBUG - 2022-06-02 07:11:35 --> Total execution time: 0.0264
DEBUG - 2022-06-02 07:11:35 --> Total execution time: 0.0303
DEBUG - 2022-06-02 07:12:10 --> Total execution time: 0.0795
DEBUG - 2022-06-02 07:12:13 --> Total execution time: 0.0588
DEBUG - 2022-06-02 07:12:15 --> Total execution time: 0.0388
DEBUG - 2022-06-02 07:12:25 --> Total execution time: 0.0400
DEBUG - 2022-06-02 07:12:35 --> Total execution time: 0.0467
DEBUG - 2022-06-02 07:12:41 --> Total execution time: 0.0298
DEBUG - 2022-06-02 07:12:46 --> Total execution time: 0.0307
DEBUG - 2022-06-02 07:12:56 --> Total execution time: 0.0358
DEBUG - 2022-06-02 07:12:59 --> Total execution time: 0.0290
DEBUG - 2022-06-02 07:13:02 --> Total execution time: 0.0261
DEBUG - 2022-06-02 07:13:02 --> Total execution time: 0.0371
DEBUG - 2022-06-02 07:13:03 --> Total execution time: 0.0390
DEBUG - 2022-06-02 07:13:05 --> Total execution time: 0.0262
DEBUG - 2022-06-02 07:13:23 --> Total execution time: 0.0396
DEBUG - 2022-06-02 07:13:38 --> Total execution time: 0.0303
DEBUG - 2022-06-02 07:13:40 --> Total execution time: 0.0366
DEBUG - 2022-06-02 07:13:54 --> Total execution time: 0.0297
DEBUG - 2022-06-02 07:13:54 --> Total execution time: 0.0774
DEBUG - 2022-06-02 07:14:21 --> Total execution time: 0.0603
DEBUG - 2022-06-02 07:14:26 --> Total execution time: 0.0301
DEBUG - 2022-06-02 07:14:33 --> Total execution time: 0.0458
DEBUG - 2022-06-02 07:14:34 --> Total execution time: 0.0441
DEBUG - 2022-06-02 07:14:34 --> Total execution time: 0.0470
DEBUG - 2022-06-02 07:14:43 --> Total execution time: 0.0500
DEBUG - 2022-06-02 07:14:50 --> Total execution time: 0.0376
DEBUG - 2022-06-02 07:15:28 --> Total execution time: 0.0317
DEBUG - 2022-06-02 07:15:34 --> Total execution time: 0.0342
DEBUG - 2022-06-02 07:16:35 --> Total execution time: 0.0647
DEBUG - 2022-06-02 07:17:15 --> Total execution time: 0.0258
DEBUG - 2022-06-02 07:17:25 --> Total execution time: 0.0274
DEBUG - 2022-06-02 07:17:44 --> Total execution time: 0.0247
DEBUG - 2022-06-02 07:18:00 --> Total execution time: 0.0338
DEBUG - 2022-06-02 07:22:07 --> Total execution time: 0.0898
DEBUG - 2022-06-02 07:24:08 --> Total execution time: 0.0265
DEBUG - 2022-06-02 07:30:03 --> Total execution time: 0.0404
DEBUG - 2022-06-02 07:30:24 --> Total execution time: 0.0610
DEBUG - 2022-06-02 07:32:42 --> Total execution time: 0.1020
DEBUG - 2022-06-02 07:40:39 --> Total execution time: 0.1105
DEBUG - 2022-06-02 07:43:05 --> Total execution time: 0.0740
DEBUG - 2022-06-02 07:43:08 --> Total execution time: 0.0212
DEBUG - 2022-06-02 07:43:11 --> Total execution time: 0.0270
DEBUG - 2022-06-02 07:43:42 --> Total execution time: 0.0297
DEBUG - 2022-06-02 07:43:48 --> Total execution time: 0.0217
DEBUG - 2022-06-02 07:44:00 --> Total execution time: 0.0353
DEBUG - 2022-06-02 07:44:03 --> Total execution time: 0.0295
DEBUG - 2022-06-02 07:44:11 --> Total execution time: 0.0267
DEBUG - 2022-06-02 07:44:22 --> Total execution time: 0.0268
DEBUG - 2022-06-02 07:44:25 --> Total execution time: 0.0348
DEBUG - 2022-06-02 07:44:27 --> Total execution time: 0.0683
DEBUG - 2022-06-02 07:44:40 --> Total execution time: 0.0560
DEBUG - 2022-06-02 07:44:51 --> Total execution time: 0.0682
DEBUG - 2022-06-02 07:44:58 --> Total execution time: 0.1075
DEBUG - 2022-06-02 07:45:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 07:45:35 --> Total execution time: 0.0626
DEBUG - 2022-06-02 07:45:49 --> Total execution time: 0.0676
DEBUG - 2022-06-02 07:46:00 --> Total execution time: 0.0657
DEBUG - 2022-06-02 07:46:01 --> Total execution time: 0.0678
DEBUG - 2022-06-02 07:46:02 --> Total execution time: 0.0269
DEBUG - 2022-06-02 07:46:02 --> Total execution time: 0.0293
DEBUG - 2022-06-02 07:46:03 --> Total execution time: 0.0289
DEBUG - 2022-06-02 07:46:04 --> Total execution time: 0.0336
DEBUG - 2022-06-02 07:46:04 --> Total execution time: 0.0267
DEBUG - 2022-06-02 07:49:36 --> Total execution time: 0.0723
DEBUG - 2022-06-02 07:52:10 --> Total execution time: 0.0273
DEBUG - 2022-06-02 07:52:39 --> Total execution time: 0.0221
DEBUG - 2022-06-02 07:52:45 --> Total execution time: 0.0206
DEBUG - 2022-06-02 07:53:08 --> Total execution time: 0.0404
DEBUG - 2022-06-02 07:53:16 --> Total execution time: 0.0735
DEBUG - 2022-06-02 07:53:24 --> Total execution time: 0.0639
DEBUG - 2022-06-02 07:53:57 --> Total execution time: 0.0569
DEBUG - 2022-06-02 07:53:58 --> Total execution time: 0.0222
DEBUG - 2022-06-02 07:53:58 --> Total execution time: 0.0279
DEBUG - 2022-06-02 07:54:02 --> Total execution time: 0.0291
DEBUG - 2022-06-02 07:54:07 --> Total execution time: 0.0299
DEBUG - 2022-06-02 07:54:18 --> Total execution time: 0.0319
DEBUG - 2022-06-02 07:54:24 --> Total execution time: 0.0358
DEBUG - 2022-06-02 07:54:27 --> Total execution time: 0.0358
DEBUG - 2022-06-02 07:56:33 --> Total execution time: 0.0364
DEBUG - 2022-06-02 07:56:37 --> Total execution time: 0.0297
DEBUG - 2022-06-02 07:56:41 --> Total execution time: 0.0310
DEBUG - 2022-06-02 07:56:44 --> Total execution time: 0.0354
DEBUG - 2022-06-02 07:59:34 --> Total execution time: 0.1566
DEBUG - 2022-06-02 07:59:34 --> Total execution time: 0.0287
DEBUG - 2022-06-02 08:00:46 --> Total execution time: 0.0234
DEBUG - 2022-06-02 08:00:46 --> Total execution time: 0.0235
DEBUG - 2022-06-02 08:04:05 --> Total execution time: 0.0288
DEBUG - 2022-06-02 08:04:21 --> Total execution time: 0.0425
DEBUG - 2022-06-02 08:04:26 --> Total execution time: 0.0234
DEBUG - 2022-06-02 08:04:32 --> Total execution time: 0.0530
DEBUG - 2022-06-02 08:04:32 --> Total execution time: 0.0241
DEBUG - 2022-06-02 08:04:40 --> Total execution time: 0.0509
DEBUG - 2022-06-02 08:04:45 --> Total execution time: 0.0232
DEBUG - 2022-06-02 08:04:50 --> Total execution time: 0.0259
DEBUG - 2022-06-02 08:05:02 --> Total execution time: 0.0307
DEBUG - 2022-06-02 08:05:02 --> Total execution time: 0.0257
DEBUG - 2022-06-02 08:05:02 --> Total execution time: 0.0357
DEBUG - 2022-06-02 08:05:03 --> Total execution time: 0.0527
DEBUG - 2022-06-02 08:05:07 --> Total execution time: 0.0372
DEBUG - 2022-06-02 08:05:08 --> Total execution time: 0.0251
DEBUG - 2022-06-02 08:05:13 --> Total execution time: 0.0271
DEBUG - 2022-06-02 08:05:15 --> Total execution time: 0.0308
DEBUG - 2022-06-02 08:05:19 --> Total execution time: 0.0446
DEBUG - 2022-06-02 08:05:32 --> Total execution time: 0.0225
DEBUG - 2022-06-02 08:05:32 --> Total execution time: 0.0313
DEBUG - 2022-06-02 08:05:35 --> Total execution time: 0.0503
DEBUG - 2022-06-02 08:05:38 --> Total execution time: 0.0262
DEBUG - 2022-06-02 08:05:38 --> Total execution time: 0.0278
DEBUG - 2022-06-02 08:05:41 --> Total execution time: 0.0606
DEBUG - 2022-06-02 08:05:52 --> Total execution time: 0.0319
DEBUG - 2022-06-02 08:05:59 --> Total execution time: 0.0533
DEBUG - 2022-06-02 08:06:08 --> Total execution time: 0.0312
DEBUG - 2022-06-02 08:06:17 --> Total execution time: 0.0315
DEBUG - 2022-06-02 08:07:57 --> Total execution time: 0.0309
DEBUG - 2022-06-02 08:08:11 --> Total execution time: 0.0306
DEBUG - 2022-06-02 08:08:16 --> Total execution time: 0.0316
DEBUG - 2022-06-02 08:08:18 --> Total execution time: 0.0449
DEBUG - 2022-06-02 08:08:27 --> Total execution time: 0.0601
DEBUG - 2022-06-02 08:08:34 --> Total execution time: 0.0394
DEBUG - 2022-06-02 08:08:35 --> Total execution time: 0.0286
DEBUG - 2022-06-02 08:09:35 --> Total execution time: 0.0280
DEBUG - 2022-06-02 08:09:50 --> Total execution time: 0.0252
DEBUG - 2022-06-02 08:10:03 --> Total execution time: 0.0374
DEBUG - 2022-06-02 08:10:38 --> Total execution time: 0.0498
DEBUG - 2022-06-02 08:10:44 --> Total execution time: 0.0275
DEBUG - 2022-06-02 08:10:45 --> Total execution time: 0.0313
DEBUG - 2022-06-02 08:10:46 --> Total execution time: 0.0279
DEBUG - 2022-06-02 08:10:53 --> Total execution time: 0.0325
DEBUG - 2022-06-02 08:12:03 --> Total execution time: 1.5601
DEBUG - 2022-06-02 08:14:20 --> Total execution time: 0.0353
DEBUG - 2022-06-02 08:14:28 --> Total execution time: 0.0585
DEBUG - 2022-06-02 08:14:35 --> Total execution time: 0.0214
DEBUG - 2022-06-02 08:14:42 --> Total execution time: 0.0284
DEBUG - 2022-06-02 08:14:45 --> Total execution time: 0.0314
DEBUG - 2022-06-02 08:14:48 --> Total execution time: 0.0490
DEBUG - 2022-06-02 08:14:57 --> Total execution time: 0.0256
DEBUG - 2022-06-02 08:15:01 --> Total execution time: 0.0260
DEBUG - 2022-06-02 08:16:05 --> Total execution time: 0.0264
DEBUG - 2022-06-02 08:16:12 --> Total execution time: 0.0284
DEBUG - 2022-06-02 08:16:44 --> Total execution time: 0.0284
DEBUG - 2022-06-02 08:17:24 --> Total execution time: 0.0544
DEBUG - 2022-06-02 08:17:46 --> Total execution time: 0.0295
DEBUG - 2022-06-02 08:18:04 --> Total execution time: 0.0706
DEBUG - 2022-06-02 08:18:04 --> Total execution time: 0.0672
DEBUG - 2022-06-02 08:18:05 --> Total execution time: 0.0473
DEBUG - 2022-06-02 08:18:05 --> Total execution time: 0.0803
DEBUG - 2022-06-02 08:19:40 --> Total execution time: 0.0592
DEBUG - 2022-06-02 08:19:52 --> Total execution time: 0.0608
DEBUG - 2022-06-02 08:20:01 --> Total execution time: 0.0342
DEBUG - 2022-06-02 08:20:08 --> Total execution time: 0.0317
DEBUG - 2022-06-02 08:20:16 --> Total execution time: 0.0348
DEBUG - 2022-06-02 08:20:24 --> Total execution time: 0.0255
DEBUG - 2022-06-02 08:20:30 --> Total execution time: 0.0303
DEBUG - 2022-06-02 08:20:38 --> Total execution time: 0.0303
DEBUG - 2022-06-02 08:20:40 --> Total execution time: 0.0357
DEBUG - 2022-06-02 08:22:27 --> Total execution time: 0.0274
DEBUG - 2022-06-02 08:22:33 --> Total execution time: 0.0291
DEBUG - 2022-06-02 08:22:35 --> Total execution time: 0.0281
DEBUG - 2022-06-02 08:22:38 --> Total execution time: 0.0309
DEBUG - 2022-06-02 08:22:43 --> Total execution time: 0.0262
DEBUG - 2022-06-02 08:22:49 --> Total execution time: 0.0277
DEBUG - 2022-06-02 08:23:04 --> Total execution time: 0.0335
DEBUG - 2022-06-02 08:23:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:23:05 --> Total execution time: 0.0211
DEBUG - 2022-06-02 08:23:42 --> Total execution time: 0.0278
DEBUG - 2022-06-02 08:23:45 --> Total execution time: 0.0278
DEBUG - 2022-06-02 08:24:09 --> Total execution time: 0.0298
DEBUG - 2022-06-02 08:24:10 --> Total execution time: 0.0255
DEBUG - 2022-06-02 08:24:26 --> Total execution time: 0.0255
DEBUG - 2022-06-02 08:24:27 --> Total execution time: 0.0275
DEBUG - 2022-06-02 08:24:27 --> Total execution time: 0.0276
DEBUG - 2022-06-02 08:24:28 --> Total execution time: 0.0286
DEBUG - 2022-06-02 08:24:28 --> Total execution time: 0.0320
DEBUG - 2022-06-02 08:24:28 --> Total execution time: 0.0475
DEBUG - 2022-06-02 08:24:29 --> Total execution time: 0.0256
DEBUG - 2022-06-02 08:24:32 --> Total execution time: 0.0337
DEBUG - 2022-06-02 08:24:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:24:33 --> Total execution time: 0.0307
DEBUG - 2022-06-02 08:25:25 --> Total execution time: 0.0259
DEBUG - 2022-06-02 08:25:33 --> Total execution time: 0.0523
DEBUG - 2022-06-02 08:25:37 --> Total execution time: 0.0286
DEBUG - 2022-06-02 08:25:43 --> Total execution time: 0.0264
DEBUG - 2022-06-02 08:25:51 --> Total execution time: 0.0279
DEBUG - 2022-06-02 08:26:10 --> Total execution time: 0.0291
DEBUG - 2022-06-02 08:26:26 --> Total execution time: 0.0323
DEBUG - 2022-06-02 08:26:35 --> Total execution time: 0.0292
DEBUG - 2022-06-02 08:26:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:26:36 --> Total execution time: 0.0268
DEBUG - 2022-06-02 08:26:58 --> Total execution time: 0.0398
DEBUG - 2022-06-02 08:27:51 --> Total execution time: 0.0355
DEBUG - 2022-06-02 08:27:51 --> Total execution time: 0.0679
DEBUG - 2022-06-02 08:27:53 --> Total execution time: 0.0290
DEBUG - 2022-06-02 08:27:53 --> Total execution time: 0.0357
DEBUG - 2022-06-02 08:27:58 --> Total execution time: 0.0416
DEBUG - 2022-06-02 08:28:03 --> Total execution time: 0.0393
DEBUG - 2022-06-02 08:28:04 --> Total execution time: 0.0332
DEBUG - 2022-06-02 08:28:08 --> Total execution time: 0.0464
DEBUG - 2022-06-02 08:28:13 --> Total execution time: 0.0411
DEBUG - 2022-06-02 08:28:20 --> Total execution time: 0.0309
DEBUG - 2022-06-02 08:28:21 --> Total execution time: 0.0396
DEBUG - 2022-06-02 08:28:43 --> Total execution time: 0.0560
DEBUG - 2022-06-02 08:28:50 --> Total execution time: 0.0504
DEBUG - 2022-06-02 08:29:04 --> Total execution time: 0.0350
DEBUG - 2022-06-02 08:29:10 --> Total execution time: 0.0263
DEBUG - 2022-06-02 08:29:15 --> Total execution time: 0.0318
DEBUG - 2022-06-02 08:29:19 --> Total execution time: 0.0246
DEBUG - 2022-06-02 08:29:21 --> Total execution time: 0.0437
DEBUG - 2022-06-02 08:29:26 --> Total execution time: 0.0301
DEBUG - 2022-06-02 08:29:27 --> Total execution time: 0.0491
DEBUG - 2022-06-02 08:29:34 --> Total execution time: 0.0283
DEBUG - 2022-06-02 08:29:44 --> Total execution time: 0.0531
DEBUG - 2022-06-02 08:29:48 --> Total execution time: 0.0487
DEBUG - 2022-06-02 08:29:51 --> Total execution time: 0.0327
DEBUG - 2022-06-02 08:29:55 --> Total execution time: 0.0313
DEBUG - 2022-06-02 08:29:57 --> Total execution time: 0.0286
DEBUG - 2022-06-02 08:29:58 --> Total execution time: 0.0331
DEBUG - 2022-06-02 08:30:02 --> Total execution time: 0.0459
DEBUG - 2022-06-02 08:30:10 --> Total execution time: 0.0314
DEBUG - 2022-06-02 08:30:11 --> Total execution time: 0.0343
DEBUG - 2022-06-02 08:30:12 --> Total execution time: 0.0300
DEBUG - 2022-06-02 08:32:52 --> Total execution time: 0.0587
DEBUG - 2022-06-02 08:32:55 --> Total execution time: 0.0352
DEBUG - 2022-06-02 08:33:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:33:05 --> Total execution time: 0.0598
DEBUG - 2022-06-02 08:33:10 --> Total execution time: 0.0568
DEBUG - 2022-06-02 08:33:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:33:18 --> Total execution time: 0.0352
DEBUG - 2022-06-02 08:33:22 --> Total execution time: 0.0295
DEBUG - 2022-06-02 08:33:48 --> Total execution time: 0.0343
DEBUG - 2022-06-02 08:33:55 --> Total execution time: 0.0350
DEBUG - 2022-06-02 08:34:12 --> Total execution time: 0.0558
DEBUG - 2022-06-02 08:34:33 --> Total execution time: 0.0386
DEBUG - 2022-06-02 08:34:41 --> Total execution time: 0.0307
DEBUG - 2022-06-02 08:34:45 --> Total execution time: 0.0371
DEBUG - 2022-06-02 08:34:52 --> Total execution time: 0.0392
DEBUG - 2022-06-02 08:35:02 --> Total execution time: 0.0740
DEBUG - 2022-06-02 08:35:43 --> Total execution time: 0.0290
DEBUG - 2022-06-02 08:35:48 --> Total execution time: 0.0291
DEBUG - 2022-06-02 08:35:52 --> Total execution time: 0.0193
DEBUG - 2022-06-02 08:36:02 --> Total execution time: 0.0362
DEBUG - 2022-06-02 08:36:03 --> Total execution time: 0.0340
DEBUG - 2022-06-02 08:36:19 --> Total execution time: 0.0363
DEBUG - 2022-06-02 08:36:34 --> Total execution time: 0.0397
DEBUG - 2022-06-02 08:36:38 --> Total execution time: 0.0514
DEBUG - 2022-06-02 08:36:44 --> Total execution time: 0.0328
DEBUG - 2022-06-02 08:37:08 --> Total execution time: 0.0551
DEBUG - 2022-06-02 08:37:13 --> Total execution time: 0.0289
DEBUG - 2022-06-02 08:38:57 --> Total execution time: 0.0797
DEBUG - 2022-06-02 08:39:00 --> Total execution time: 0.0472
DEBUG - 2022-06-02 08:39:13 --> Total execution time: 0.0525
DEBUG - 2022-06-02 08:39:26 --> Total execution time: 0.0293
DEBUG - 2022-06-02 08:39:29 --> Total execution time: 0.0312
DEBUG - 2022-06-02 08:39:38 --> Total execution time: 0.0330
DEBUG - 2022-06-02 08:39:42 --> Total execution time: 0.0732
DEBUG - 2022-06-02 08:41:56 --> Total execution time: 1.4844
DEBUG - 2022-06-02 08:42:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:42:30 --> Total execution time: 0.0286
DEBUG - 2022-06-02 08:42:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:42:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:42:32 --> Total execution time: 0.1574
DEBUG - 2022-06-02 08:42:46 --> Total execution time: 1.5865
DEBUG - 2022-06-02 08:42:50 --> Total execution time: 0.0282
DEBUG - 2022-06-02 08:42:51 --> Total execution time: 0.0315
DEBUG - 2022-06-02 08:43:05 --> Total execution time: 0.0583
DEBUG - 2022-06-02 08:43:08 --> Total execution time: 0.0433
DEBUG - 2022-06-02 08:43:13 --> Total execution time: 0.0369
DEBUG - 2022-06-02 08:43:19 --> Total execution time: 0.0293
DEBUG - 2022-06-02 08:43:57 --> Total execution time: 0.0353
DEBUG - 2022-06-02 08:44:30 --> Total execution time: 0.0267
DEBUG - 2022-06-02 08:44:39 --> Total execution time: 0.0266
DEBUG - 2022-06-02 08:44:57 --> Total execution time: 0.0722
DEBUG - 2022-06-02 08:45:03 --> Total execution time: 0.0392
DEBUG - 2022-06-02 08:45:04 --> Total execution time: 0.0395
DEBUG - 2022-06-02 08:45:32 --> Total execution time: 0.0682
DEBUG - 2022-06-02 08:45:44 --> Total execution time: 0.0394
DEBUG - 2022-06-02 08:45:52 --> Total execution time: 0.0346
DEBUG - 2022-06-02 08:45:52 --> Total execution time: 0.0368
DEBUG - 2022-06-02 08:46:06 --> Total execution time: 0.0370
DEBUG - 2022-06-02 08:46:07 --> Total execution time: 0.0700
DEBUG - 2022-06-02 08:46:22 --> Total execution time: 0.0669
DEBUG - 2022-06-02 08:46:25 --> Total execution time: 0.0381
DEBUG - 2022-06-02 08:46:26 --> Total execution time: 0.0642
DEBUG - 2022-06-02 08:46:30 --> Total execution time: 0.0310
DEBUG - 2022-06-02 08:46:48 --> Total execution time: 0.0354
DEBUG - 2022-06-02 08:46:50 --> Total execution time: 0.0741
DEBUG - 2022-06-02 08:46:57 --> Total execution time: 0.0349
DEBUG - 2022-06-02 08:47:01 --> Total execution time: 0.0312
DEBUG - 2022-06-02 08:47:02 --> Total execution time: 0.0592
DEBUG - 2022-06-02 08:47:18 --> Total execution time: 0.0499
DEBUG - 2022-06-02 08:47:30 --> Total execution time: 0.0760
DEBUG - 2022-06-02 08:47:30 --> Total execution time: 0.0429
DEBUG - 2022-06-02 08:47:37 --> Total execution time: 0.0281
DEBUG - 2022-06-02 08:47:52 --> Total execution time: 0.0344
DEBUG - 2022-06-02 08:47:56 --> Total execution time: 0.0436
DEBUG - 2022-06-02 08:47:59 --> Total execution time: 0.0350
DEBUG - 2022-06-02 08:48:03 --> Total execution time: 0.0613
DEBUG - 2022-06-02 08:48:12 --> Total execution time: 0.0266
DEBUG - 2022-06-02 08:48:28 --> Total execution time: 0.0284
DEBUG - 2022-06-02 08:48:54 --> Total execution time: 0.0350
DEBUG - 2022-06-02 08:48:56 --> Total execution time: 0.0294
DEBUG - 2022-06-02 08:49:05 --> Total execution time: 0.0429
DEBUG - 2022-06-02 08:49:14 --> Total execution time: 0.0436
DEBUG - 2022-06-02 08:49:17 --> Total execution time: 0.0361
DEBUG - 2022-06-02 08:49:20 --> Total execution time: 0.0505
DEBUG - 2022-06-02 08:49:27 --> Total execution time: 0.0229
DEBUG - 2022-06-02 08:49:42 --> Total execution time: 0.0663
DEBUG - 2022-06-02 08:49:50 --> Total execution time: 0.0549
DEBUG - 2022-06-02 08:49:54 --> Total execution time: 0.0503
DEBUG - 2022-06-02 08:50:03 --> Total execution time: 0.0606
DEBUG - 2022-06-02 08:50:15 --> Total execution time: 0.0366
DEBUG - 2022-06-02 08:50:23 --> Total execution time: 0.0294
DEBUG - 2022-06-02 08:50:28 --> Total execution time: 0.0291
DEBUG - 2022-06-02 08:50:45 --> Total execution time: 0.0853
DEBUG - 2022-06-02 08:50:51 --> Total execution time: 0.0304
DEBUG - 2022-06-02 08:51:07 --> Total execution time: 0.0417
DEBUG - 2022-06-02 08:51:34 --> Total execution time: 0.0408
DEBUG - 2022-06-02 08:51:51 --> Total execution time: 0.0474
DEBUG - 2022-06-02 08:52:14 --> Total execution time: 0.0752
DEBUG - 2022-06-02 08:52:16 --> Total execution time: 0.0301
DEBUG - 2022-06-02 08:52:21 --> Total execution time: 0.0300
DEBUG - 2022-06-02 08:52:21 --> Total execution time: 0.0470
DEBUG - 2022-06-02 08:52:47 --> Total execution time: 0.0681
DEBUG - 2022-06-02 08:53:00 --> Total execution time: 0.0311
DEBUG - 2022-06-02 08:53:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:53:01 --> Total execution time: 0.0282
DEBUG - 2022-06-02 08:53:04 --> Total execution time: 0.0337
DEBUG - 2022-06-02 08:53:11 --> Total execution time: 0.0355
DEBUG - 2022-06-02 08:53:32 --> Total execution time: 0.0267
DEBUG - 2022-06-02 08:53:33 --> Total execution time: 0.0193
DEBUG - 2022-06-02 08:53:58 --> Total execution time: 0.0280
DEBUG - 2022-06-02 08:54:05 --> Total execution time: 0.0278
DEBUG - 2022-06-02 08:54:05 --> Total execution time: 0.0249
DEBUG - 2022-06-02 08:54:05 --> Total execution time: 0.0344
DEBUG - 2022-06-02 08:54:06 --> Total execution time: 0.0454
DEBUG - 2022-06-02 08:54:14 --> Total execution time: 0.0365
DEBUG - 2022-06-02 08:54:37 --> Total execution time: 0.0294
DEBUG - 2022-06-02 08:54:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:54:38 --> Total execution time: 0.0347
DEBUG - 2022-06-02 08:54:40 --> Total execution time: 0.0723
DEBUG - 2022-06-02 08:54:49 --> Total execution time: 0.0392
DEBUG - 2022-06-02 08:55:00 --> Total execution time: 0.0363
DEBUG - 2022-06-02 08:55:04 --> Total execution time: 0.0710
DEBUG - 2022-06-02 08:55:08 --> Total execution time: 0.0553
DEBUG - 2022-06-02 08:55:19 --> Total execution time: 0.0638
DEBUG - 2022-06-02 08:55:21 --> Total execution time: 0.0366
DEBUG - 2022-06-02 08:55:30 --> Total execution time: 0.0363
DEBUG - 2022-06-02 08:55:31 --> Total execution time: 0.0484
DEBUG - 2022-06-02 08:55:35 --> Total execution time: 0.0277
DEBUG - 2022-06-02 08:55:43 --> Total execution time: 0.0473
DEBUG - 2022-06-02 08:55:52 --> Total execution time: 0.0758
DEBUG - 2022-06-02 08:56:21 --> Total execution time: 0.0299
DEBUG - 2022-06-02 08:56:21 --> Total execution time: 0.0254
DEBUG - 2022-06-02 08:56:22 --> Total execution time: 0.0260
DEBUG - 2022-06-02 08:56:23 --> Total execution time: 0.0336
DEBUG - 2022-06-02 08:56:42 --> Total execution time: 0.0514
DEBUG - 2022-06-02 08:57:00 --> Total execution time: 0.0432
DEBUG - 2022-06-02 08:57:05 --> Total execution time: 0.0308
DEBUG - 2022-06-02 08:57:14 --> Total execution time: 0.0352
DEBUG - 2022-06-02 08:57:22 --> Total execution time: 0.0310
DEBUG - 2022-06-02 08:57:25 --> Total execution time: 0.0290
DEBUG - 2022-06-02 08:57:26 --> Total execution time: 0.0247
DEBUG - 2022-06-02 08:57:46 --> Total execution time: 0.0383
DEBUG - 2022-06-02 08:57:54 --> Total execution time: 0.0384
DEBUG - 2022-06-02 09:00:22 --> Total execution time: 0.0388
DEBUG - 2022-06-02 09:00:57 --> Total execution time: 0.0354
DEBUG - 2022-06-02 09:00:59 --> Total execution time: 0.0346
DEBUG - 2022-06-02 09:01:04 --> Total execution time: 0.0660
DEBUG - 2022-06-02 09:01:42 --> Total execution time: 0.0445
DEBUG - 2022-06-02 09:01:53 --> Total execution time: 0.0503
DEBUG - 2022-06-02 09:01:55 --> Total execution time: 0.0324
DEBUG - 2022-06-02 09:02:40 --> Total execution time: 0.0329
DEBUG - 2022-06-02 09:02:42 --> Total execution time: 0.0338
DEBUG - 2022-06-02 09:03:57 --> Total execution time: 0.0361
DEBUG - 2022-06-02 09:04:09 --> Total execution time: 0.0453
DEBUG - 2022-06-02 09:04:20 --> Total execution time: 0.0397
DEBUG - 2022-06-02 09:04:22 --> Total execution time: 0.0284
DEBUG - 2022-06-02 09:04:25 --> Total execution time: 0.0613
DEBUG - 2022-06-02 09:04:32 --> Total execution time: 0.0585
DEBUG - 2022-06-02 09:05:00 --> Total execution time: 0.0545
DEBUG - 2022-06-02 09:05:11 --> Total execution time: 0.0468
DEBUG - 2022-06-02 09:05:19 --> Total execution time: 0.0329
DEBUG - 2022-06-02 09:05:22 --> Total execution time: 0.0396
DEBUG - 2022-06-02 09:06:04 --> Total execution time: 0.0859
DEBUG - 2022-06-02 09:06:33 --> Total execution time: 0.0578
DEBUG - 2022-06-02 09:06:36 --> Total execution time: 0.0336
DEBUG - 2022-06-02 09:06:36 --> Total execution time: 0.0347
DEBUG - 2022-06-02 09:06:50 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 09:06:51 --> Total execution time: 0.0341
DEBUG - 2022-06-02 09:06:56 --> Total execution time: 0.0348
DEBUG - 2022-06-02 09:07:49 --> Total execution time: 0.0569
DEBUG - 2022-06-02 09:07:52 --> Total execution time: 0.0286
DEBUG - 2022-06-02 09:08:12 --> Total execution time: 0.0509
DEBUG - 2022-06-02 09:08:21 --> Total execution time: 0.0228
DEBUG - 2022-06-02 09:08:39 --> Total execution time: 0.0320
DEBUG - 2022-06-02 09:08:44 --> Total execution time: 0.0201
DEBUG - 2022-06-02 09:08:50 --> Total execution time: 0.0241
DEBUG - 2022-06-02 09:09:19 --> Total execution time: 0.0743
DEBUG - 2022-06-02 09:09:42 --> Total execution time: 0.0256
DEBUG - 2022-06-02 09:09:49 --> Total execution time: 0.0367
DEBUG - 2022-06-02 09:10:04 --> Total execution time: 0.0432
DEBUG - 2022-06-02 09:11:13 --> Total execution time: 0.0238
DEBUG - 2022-06-02 09:11:30 --> Total execution time: 0.0412
DEBUG - 2022-06-02 09:11:48 --> Total execution time: 0.0227
DEBUG - 2022-06-02 09:12:05 --> Total execution time: 0.0310
DEBUG - 2022-06-02 09:12:05 --> Total execution time: 0.0635
DEBUG - 2022-06-02 09:12:21 --> Total execution time: 0.0316
DEBUG - 2022-06-02 09:12:33 --> Total execution time: 0.0288
DEBUG - 2022-06-02 09:12:35 --> Total execution time: 0.0270
DEBUG - 2022-06-02 09:13:13 --> Total execution time: 0.0732
DEBUG - 2022-06-02 09:13:21 --> Total execution time: 0.0584
DEBUG - 2022-06-02 09:13:28 --> Total execution time: 0.0756
DEBUG - 2022-06-02 09:13:33 --> Total execution time: 0.0871
DEBUG - 2022-06-02 09:13:51 --> Total execution time: 0.0570
DEBUG - 2022-06-02 09:14:57 --> Total execution time: 0.0701
DEBUG - 2022-06-02 09:15:08 --> Total execution time: 0.0351
DEBUG - 2022-06-02 09:15:36 --> Total execution time: 0.0608
DEBUG - 2022-06-02 09:15:40 --> Total execution time: 0.0327
DEBUG - 2022-06-02 09:15:46 --> Total execution time: 0.0226
DEBUG - 2022-06-02 09:15:46 --> Total execution time: 0.0329
DEBUG - 2022-06-02 09:15:47 --> Total execution time: 0.0288
DEBUG - 2022-06-02 09:15:59 --> Total execution time: 0.0260
DEBUG - 2022-06-02 09:16:07 --> Total execution time: 0.0602
DEBUG - 2022-06-02 09:16:20 --> Total execution time: 0.0328
DEBUG - 2022-06-02 09:16:21 --> Total execution time: 0.0323
DEBUG - 2022-06-02 09:16:36 --> Total execution time: 0.0299
DEBUG - 2022-06-02 09:16:41 --> Total execution time: 0.0531
DEBUG - 2022-06-02 09:16:52 --> Total execution time: 0.0634
DEBUG - 2022-06-02 09:16:53 --> Total execution time: 0.0657
DEBUG - 2022-06-02 09:16:54 --> Total execution time: 0.0315
DEBUG - 2022-06-02 09:16:58 --> Total execution time: 0.0382
DEBUG - 2022-06-02 09:17:18 --> Total execution time: 0.0309
DEBUG - 2022-06-02 09:17:23 --> Total execution time: 0.0295
DEBUG - 2022-06-02 09:17:26 --> Total execution time: 0.0295
DEBUG - 2022-06-02 09:17:45 --> Total execution time: 0.0373
DEBUG - 2022-06-02 09:17:52 --> Total execution time: 0.0233
DEBUG - 2022-06-02 09:17:52 --> Total execution time: 0.0316
DEBUG - 2022-06-02 09:17:57 --> Total execution time: 0.0333
DEBUG - 2022-06-02 09:18:03 --> Total execution time: 0.0515
DEBUG - 2022-06-02 09:18:45 --> Total execution time: 0.0311
DEBUG - 2022-06-02 09:18:48 --> Total execution time: 0.0295
DEBUG - 2022-06-02 09:18:58 --> Total execution time: 0.0274
DEBUG - 2022-06-02 09:19:49 --> Total execution time: 0.0562
DEBUG - 2022-06-02 09:20:11 --> Total execution time: 0.0298
DEBUG - 2022-06-02 09:20:43 --> Total execution time: 0.0430
DEBUG - 2022-06-02 09:21:19 --> Total execution time: 0.0286
DEBUG - 2022-06-02 09:21:33 --> Total execution time: 0.0513
DEBUG - 2022-06-02 09:21:34 --> Total execution time: 0.0425
DEBUG - 2022-06-02 09:21:34 --> Total execution time: 0.0426
DEBUG - 2022-06-02 09:22:24 --> Total execution time: 0.0562
DEBUG - 2022-06-02 09:22:24 --> Total execution time: 0.0305
DEBUG - 2022-06-02 09:22:39 --> Total execution time: 0.0622
DEBUG - 2022-06-02 09:22:47 --> Total execution time: 0.0343
DEBUG - 2022-06-02 09:22:54 --> Total execution time: 0.0447
DEBUG - 2022-06-02 09:23:28 --> Total execution time: 0.1390
DEBUG - 2022-06-02 09:23:33 --> Total execution time: 0.1663
DEBUG - 2022-06-02 09:23:42 --> Total execution time: 0.0304
DEBUG - 2022-06-02 09:23:50 --> Total execution time: 0.0290
DEBUG - 2022-06-02 09:23:54 --> Total execution time: 0.0317
DEBUG - 2022-06-02 09:24:11 --> Total execution time: 0.0354
DEBUG - 2022-06-02 09:24:23 --> Total execution time: 0.0310
DEBUG - 2022-06-02 09:24:26 --> Total execution time: 0.0300
DEBUG - 2022-06-02 09:24:29 --> Total execution time: 0.0338
DEBUG - 2022-06-02 09:24:43 --> Total execution time: 0.0480
DEBUG - 2022-06-02 09:24:45 --> Total execution time: 0.0241
DEBUG - 2022-06-02 09:25:07 --> Total execution time: 0.0293
DEBUG - 2022-06-02 09:25:36 --> Total execution time: 0.1022
DEBUG - 2022-06-02 09:26:53 --> Total execution time: 0.0283
DEBUG - 2022-06-02 09:27:28 --> Total execution time: 0.0320
DEBUG - 2022-06-02 09:27:37 --> Total execution time: 0.0459
DEBUG - 2022-06-02 09:27:38 --> Total execution time: 0.0444
DEBUG - 2022-06-02 09:27:49 --> Total execution time: 0.0287
DEBUG - 2022-06-02 09:27:54 --> Total execution time: 0.0781
DEBUG - 2022-06-02 09:27:57 --> Total execution time: 0.0653
DEBUG - 2022-06-02 09:28:13 --> Total execution time: 0.0546
DEBUG - 2022-06-02 09:28:14 --> Total execution time: 0.0331
DEBUG - 2022-06-02 09:28:15 --> Total execution time: 0.0336
DEBUG - 2022-06-02 09:29:02 --> Total execution time: 0.0505
DEBUG - 2022-06-02 09:29:07 --> Total execution time: 0.0285
DEBUG - 2022-06-02 09:29:20 --> Total execution time: 0.0402
DEBUG - 2022-06-02 09:29:46 --> Total execution time: 0.0339
DEBUG - 2022-06-02 09:30:02 --> Total execution time: 0.0507
DEBUG - 2022-06-02 09:30:38 --> Total execution time: 0.0558
DEBUG - 2022-06-02 09:30:51 --> Total execution time: 0.0497
DEBUG - 2022-06-02 09:30:55 --> Total execution time: 0.0329
DEBUG - 2022-06-02 09:31:08 --> Total execution time: 0.0526
DEBUG - 2022-06-02 09:31:14 --> Total execution time: 0.0300
DEBUG - 2022-06-02 09:31:20 --> Total execution time: 0.0530
DEBUG - 2022-06-02 09:31:23 --> Total execution time: 0.0357
DEBUG - 2022-06-02 09:31:25 --> Total execution time: 0.0265
DEBUG - 2022-06-02 09:31:27 --> Total execution time: 0.0236
DEBUG - 2022-06-02 09:31:29 --> Total execution time: 0.0563
DEBUG - 2022-06-02 09:31:40 --> Total execution time: 0.0222
DEBUG - 2022-06-02 09:31:47 --> Total execution time: 0.0333
DEBUG - 2022-06-02 09:31:55 --> Total execution time: 0.0358
DEBUG - 2022-06-02 09:32:08 --> Total execution time: 0.0311
DEBUG - 2022-06-02 09:34:07 --> Total execution time: 0.0592
DEBUG - 2022-06-02 09:35:11 --> Total execution time: 0.0698
DEBUG - 2022-06-02 09:35:15 --> Total execution time: 0.0426
DEBUG - 2022-06-02 09:36:20 --> Total execution time: 0.1052
DEBUG - 2022-06-02 09:37:14 --> Total execution time: 0.0776
DEBUG - 2022-06-02 09:37:21 --> Total execution time: 0.0317
DEBUG - 2022-06-02 09:37:29 --> Total execution time: 0.0338
DEBUG - 2022-06-02 09:37:34 --> Total execution time: 0.0451
DEBUG - 2022-06-02 09:37:38 --> Total execution time: 0.0463
DEBUG - 2022-06-02 09:39:11 --> Total execution time: 0.0687
DEBUG - 2022-06-02 09:39:36 --> Total execution time: 0.0349
DEBUG - 2022-06-02 09:39:48 --> Total execution time: 1.5143
DEBUG - 2022-06-02 09:41:06 --> Total execution time: 1.4826
DEBUG - 2022-06-02 09:41:06 --> Total execution time: 0.0675
DEBUG - 2022-06-02 09:41:25 --> Total execution time: 0.0298
DEBUG - 2022-06-02 09:42:53 --> Total execution time: 0.0948
DEBUG - 2022-06-02 09:43:04 --> Total execution time: 1.8406
DEBUG - 2022-06-02 09:43:59 --> Total execution time: 0.0300
DEBUG - 2022-06-02 09:44:04 --> Total execution time: 2.9154
DEBUG - 2022-06-02 09:44:52 --> Total execution time: 0.0358
DEBUG - 2022-06-02 09:45:24 --> Total execution time: 0.0282
DEBUG - 2022-06-02 09:45:35 --> Total execution time: 1.4887
DEBUG - 2022-06-02 09:45:56 --> Total execution time: 0.0741
DEBUG - 2022-06-02 09:46:04 --> Total execution time: 0.0329
DEBUG - 2022-06-02 09:48:54 --> Total execution time: 0.0932
DEBUG - 2022-06-02 09:48:58 --> Total execution time: 0.0311
DEBUG - 2022-06-02 09:49:07 --> Total execution time: 0.0354
DEBUG - 2022-06-02 09:49:18 --> Total execution time: 0.0307
DEBUG - 2022-06-02 09:49:24 --> Total execution time: 0.0332
DEBUG - 2022-06-02 09:49:27 --> Total execution time: 0.0484
DEBUG - 2022-06-02 09:49:44 --> Total execution time: 0.0291
DEBUG - 2022-06-02 09:49:49 --> Total execution time: 0.0495
DEBUG - 2022-06-02 09:49:49 --> Total execution time: 0.0303
DEBUG - 2022-06-02 09:49:56 --> Total execution time: 0.0646
DEBUG - 2022-06-02 09:49:58 --> Total execution time: 0.0333
DEBUG - 2022-06-02 09:50:17 --> Total execution time: 0.0458
DEBUG - 2022-06-02 09:50:28 --> Total execution time: 0.0421
DEBUG - 2022-06-02 09:50:41 --> Total execution time: 0.0332
DEBUG - 2022-06-02 09:50:43 --> Total execution time: 0.0296
DEBUG - 2022-06-02 09:50:45 --> Total execution time: 0.0723
DEBUG - 2022-06-02 09:50:50 --> Total execution time: 0.0283
DEBUG - 2022-06-02 09:50:58 --> Total execution time: 0.0561
DEBUG - 2022-06-02 09:53:39 --> Total execution time: 0.1037
DEBUG - 2022-06-02 09:53:49 --> Total execution time: 0.0299
DEBUG - 2022-06-02 09:53:51 --> Total execution time: 0.0263
DEBUG - 2022-06-02 09:54:02 --> Total execution time: 0.0333
DEBUG - 2022-06-02 09:54:18 --> Total execution time: 0.0329
DEBUG - 2022-06-02 09:54:22 --> Total execution time: 0.0440
DEBUG - 2022-06-02 09:54:37 --> Total execution time: 0.0308
DEBUG - 2022-06-02 09:54:39 --> Total execution time: 0.0307
DEBUG - 2022-06-02 09:54:42 --> Total execution time: 0.0394
DEBUG - 2022-06-02 09:55:37 --> Total execution time: 0.0381
DEBUG - 2022-06-02 09:55:39 --> Total execution time: 0.0412
DEBUG - 2022-06-02 09:55:41 --> Total execution time: 0.0438
DEBUG - 2022-06-02 09:55:47 --> Total execution time: 0.0321
DEBUG - 2022-06-02 09:55:50 --> Total execution time: 0.0318
DEBUG - 2022-06-02 09:55:52 --> Total execution time: 0.0298
DEBUG - 2022-06-02 09:55:55 --> Total execution time: 0.0249
DEBUG - 2022-06-02 09:55:56 --> Total execution time: 0.0303
DEBUG - 2022-06-02 09:56:03 --> Total execution time: 0.0284
DEBUG - 2022-06-02 09:56:09 --> Total execution time: 0.0314
DEBUG - 2022-06-02 09:56:22 --> Total execution time: 0.0253
DEBUG - 2022-06-02 09:56:38 --> Total execution time: 0.0365
DEBUG - 2022-06-02 09:56:40 --> Total execution time: 0.0179
DEBUG - 2022-06-02 09:56:42 --> Total execution time: 0.0377
DEBUG - 2022-06-02 09:56:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 09:56:43 --> Total execution time: 0.0491
DEBUG - 2022-06-02 09:57:08 --> Total execution time: 0.0234
DEBUG - 2022-06-02 09:57:12 --> Total execution time: 0.0261
DEBUG - 2022-06-02 09:57:13 --> Total execution time: 0.0268
DEBUG - 2022-06-02 09:57:34 --> Total execution time: 0.0270
DEBUG - 2022-06-02 09:58:59 --> Total execution time: 0.0207
DEBUG - 2022-06-02 10:05:42 --> Total execution time: 0.0927
DEBUG - 2022-06-02 10:05:49 --> Total execution time: 0.0390
DEBUG - 2022-06-02 10:05:52 --> Total execution time: 0.0269
DEBUG - 2022-06-02 10:06:26 --> Total execution time: 0.0351
DEBUG - 2022-06-02 10:06:40 --> Total execution time: 0.0606
DEBUG - 2022-06-02 10:06:46 --> Total execution time: 0.0532
DEBUG - 2022-06-02 10:07:05 --> Total execution time: 0.0289
DEBUG - 2022-06-02 10:08:38 --> Total execution time: 0.0347
DEBUG - 2022-06-02 10:08:47 --> Total execution time: 0.0676
DEBUG - 2022-06-02 10:10:33 --> Total execution time: 0.0409
DEBUG - 2022-06-02 10:12:58 --> Total execution time: 0.0343
DEBUG - 2022-06-02 10:16:29 --> Total execution time: 0.0362
DEBUG - 2022-06-02 10:16:41 --> Total execution time: 0.0427
DEBUG - 2022-06-02 10:16:50 --> Total execution time: 0.0247
DEBUG - 2022-06-02 10:17:02 --> Total execution time: 0.0250
DEBUG - 2022-06-02 10:17:06 --> Total execution time: 0.0369
DEBUG - 2022-06-02 10:17:16 --> Total execution time: 0.0769
DEBUG - 2022-06-02 10:17:27 --> Total execution time: 0.0540
DEBUG - 2022-06-02 10:19:19 --> Total execution time: 0.0265
DEBUG - 2022-06-02 10:19:55 --> Total execution time: 0.0236
DEBUG - 2022-06-02 10:21:14 --> Total execution time: 0.0236
DEBUG - 2022-06-02 10:21:15 --> Total execution time: 0.0267
DEBUG - 2022-06-02 10:22:21 --> Total execution time: 0.0321
DEBUG - 2022-06-02 10:25:15 --> Total execution time: 0.1970
DEBUG - 2022-06-02 00:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:30:03 --> Total execution time: 0.1392
DEBUG - 2022-06-02 00:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:01:07 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:31:07 --> Total execution time: 0.0431
DEBUG - 2022-06-02 00:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:31:10 --> Total execution time: 0.0321
DEBUG - 2022-06-02 00:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:31:15 --> Total execution time: 0.0481
DEBUG - 2022-06-02 00:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:31:20 --> Total execution time: 0.0301
DEBUG - 2022-06-02 00:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:31:28 --> Total execution time: 0.0725
DEBUG - 2022-06-02 00:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:32:09 --> Total execution time: 0.0664
DEBUG - 2022-06-02 00:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:33:00 --> Total execution time: 0.0680
DEBUG - 2022-06-02 00:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:33:00 --> Total execution time: 0.0494
DEBUG - 2022-06-02 00:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:33:00 --> Total execution time: 0.0663
DEBUG - 2022-06-02 00:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:33:30 --> Total execution time: 0.0374
DEBUG - 2022-06-02 00:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:33:38 --> Total execution time: 0.0589
DEBUG - 2022-06-02 00:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:33:52 --> Total execution time: 0.0466
DEBUG - 2022-06-02 00:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:33:57 --> Total execution time: 0.0812
DEBUG - 2022-06-02 00:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:34:08 --> Total execution time: 0.1176
DEBUG - 2022-06-02 00:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:34:18 --> Total execution time: 0.0622
DEBUG - 2022-06-02 00:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:34:19 --> Total execution time: 0.0970
DEBUG - 2022-06-02 00:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:35:36 --> Total execution time: 0.0241
DEBUG - 2022-06-02 00:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:36:12 --> Total execution time: 0.0405
DEBUG - 2022-06-02 00:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:36:19 --> Total execution time: 0.0529
DEBUG - 2022-06-02 00:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:36:37 --> Total execution time: 0.0402
DEBUG - 2022-06-02 00:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:36:57 --> Total execution time: 0.0424
DEBUG - 2022-06-02 00:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:37:07 --> Total execution time: 0.0389
DEBUG - 2022-06-02 00:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:08:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 00:08:44 --> 404 Page Not Found: Apple-app-site-association/index
DEBUG - 2022-06-02 00:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:10:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 00:10:44 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-06-02 00:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:11:48 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:41:48 --> Total execution time: 0.0999
DEBUG - 2022-06-02 00:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:11:58 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:41:58 --> Total execution time: 0.0278
DEBUG - 2022-06-02 00:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:12:31 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:42:31 --> Total execution time: 0.0342
DEBUG - 2022-06-02 00:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:42:36 --> Total execution time: 0.0251
DEBUG - 2022-06-02 00:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:42:39 --> Total execution time: 0.0270
DEBUG - 2022-06-02 00:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:43:05 --> Total execution time: 0.0704
DEBUG - 2022-06-02 00:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:43:26 --> Total execution time: 0.0351
DEBUG - 2022-06-02 00:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:43:32 --> Total execution time: 0.0424
DEBUG - 2022-06-02 00:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:43:45 --> Total execution time: 0.0483
DEBUG - 2022-06-02 00:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:14:09 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:44:09 --> Total execution time: 0.0366
DEBUG - 2022-06-02 00:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:14:09 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:44:09 --> Total execution time: 0.0354
DEBUG - 2022-06-02 00:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:44:19 --> Total execution time: 0.0282
DEBUG - 2022-06-02 00:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:16:37 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:46:37 --> Total execution time: 0.0820
DEBUG - 2022-06-02 00:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:46:39 --> Total execution time: 0.0339
DEBUG - 2022-06-02 00:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:46:48 --> Total execution time: 0.0574
DEBUG - 2022-06-02 00:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:46:53 --> Total execution time: 0.2939
DEBUG - 2022-06-02 00:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:47:04 --> Total execution time: 0.0288
DEBUG - 2022-06-02 00:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:47:23 --> Total execution time: 0.0305
DEBUG - 2022-06-02 00:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:47:25 --> Total execution time: 0.0292
DEBUG - 2022-06-02 00:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:17:44 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:47:44 --> Total execution time: 0.0301
DEBUG - 2022-06-02 00:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 00:17:50 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-02 00:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:17:59 --> Total execution time: 0.0448
DEBUG - 2022-06-02 00:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:18:01 --> Total execution time: 0.1371
DEBUG - 2022-06-02 00:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:18:01 --> Total execution time: 0.1901
DEBUG - 2022-06-02 00:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:49:33 --> Total execution time: 0.0309
DEBUG - 2022-06-02 00:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:21:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 00:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:51:12 --> Total execution time: 1.5849
DEBUG - 2022-06-02 00:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 00:21:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 00:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:21:26 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:51:26 --> Total execution time: 0.0309
DEBUG - 2022-06-02 00:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:51:39 --> Total execution time: 0.0413
DEBUG - 2022-06-02 00:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:51:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 00:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:51:55 --> Total execution time: 0.0350
DEBUG - 2022-06-02 00:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:51:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 10:51:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 10:51:57 --> Total execution time: 0.1967
DEBUG - 2022-06-02 00:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:03 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:52:03 --> Total execution time: 0.0295
DEBUG - 2022-06-02 00:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:52:10 --> Total execution time: 0.0423
DEBUG - 2022-06-02 00:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:52:13 --> Total execution time: 0.0389
DEBUG - 2022-06-02 00:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:52:21 --> Total execution time: 0.0293
DEBUG - 2022-06-02 00:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:22:22 --> Total execution time: 0.0303
DEBUG - 2022-06-02 00:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:22:24 --> Total execution time: 0.0268
DEBUG - 2022-06-02 00:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:22:24 --> Total execution time: 0.0653
DEBUG - 2022-06-02 00:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:27 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:52:27 --> Total execution time: 0.0377
DEBUG - 2022-06-02 00:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:52:32 --> Total execution time: 0.0346
DEBUG - 2022-06-02 00:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:37 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:52:37 --> Total execution time: 0.0321
DEBUG - 2022-06-02 00:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:22:40 --> Total execution time: 0.0483
DEBUG - 2022-06-02 00:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:52:41 --> Total execution time: 0.0770
DEBUG - 2022-06-02 00:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:22:42 --> Total execution time: 0.0480
DEBUG - 2022-06-02 00:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:22:42 --> Total execution time: 0.0620
DEBUG - 2022-06-02 00:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:22:48 --> Total execution time: 0.0396
DEBUG - 2022-06-02 00:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:49 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:52:49 --> Total execution time: 0.0731
DEBUG - 2022-06-02 00:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:49 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:52:49 --> Total execution time: 0.0533
DEBUG - 2022-06-02 00:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:52:56 --> Total execution time: 0.0208
DEBUG - 2022-06-02 00:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:53:17 --> Total execution time: 0.0328
DEBUG - 2022-06-02 00:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:53:28 --> Total execution time: 0.0370
DEBUG - 2022-06-02 00:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:23:28 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:53:28 --> Total execution time: 0.0450
DEBUG - 2022-06-02 00:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:53:31 --> Total execution time: 0.0508
DEBUG - 2022-06-02 00:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:23:37 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:53:37 --> Total execution time: 0.0377
DEBUG - 2022-06-02 00:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:53:43 --> Total execution time: 0.0226
DEBUG - 2022-06-02 00:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:53:51 --> Total execution time: 0.0378
DEBUG - 2022-06-02 00:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:53:57 --> Total execution time: 0.0472
DEBUG - 2022-06-02 00:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:53:59 --> Total execution time: 0.0293
DEBUG - 2022-06-02 00:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:54:49 --> Total execution time: 0.0277
DEBUG - 2022-06-02 00:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:55:01 --> Total execution time: 0.0300
DEBUG - 2022-06-02 00:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:55:05 --> Total execution time: 0.0414
DEBUG - 2022-06-02 00:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:55:08 --> Total execution time: 0.0565
DEBUG - 2022-06-02 00:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:55:14 --> Total execution time: 0.0288
DEBUG - 2022-06-02 00:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:25:24 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:55:24 --> Total execution time: 0.0228
DEBUG - 2022-06-02 00:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:25:24 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:55:24 --> Total execution time: 0.0230
DEBUG - 2022-06-02 00:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:55:31 --> Total execution time: 0.0247
DEBUG - 2022-06-02 00:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:56:24 --> Total execution time: 0.0318
DEBUG - 2022-06-02 00:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:56:35 --> Total execution time: 0.0421
DEBUG - 2022-06-02 00:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:56:56 --> Total execution time: 0.0257
DEBUG - 2022-06-02 00:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:27:09 --> Total execution time: 0.0536
DEBUG - 2022-06-02 00:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:27:12 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:57:12 --> Total execution time: 0.0652
DEBUG - 2022-06-02 00:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:27:13 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:57:13 --> Total execution time: 0.0529
DEBUG - 2022-06-02 00:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:57:14 --> Total execution time: 0.0297
DEBUG - 2022-06-02 00:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:57:16 --> Total execution time: 0.0314
DEBUG - 2022-06-02 00:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:27:17 --> Total execution time: 0.0888
DEBUG - 2022-06-02 00:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:57:26 --> Total execution time: 0.0447
DEBUG - 2022-06-02 00:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:57:31 --> Total execution time: 0.0407
DEBUG - 2022-06-02 00:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:57:47 --> Total execution time: 0.0616
DEBUG - 2022-06-02 00:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:27:52 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:57:52 --> Total execution time: 0.0319
DEBUG - 2022-06-02 00:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:58:00 --> Total execution time: 0.0339
DEBUG - 2022-06-02 00:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 00:28:31 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-02 00:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:28:39 --> Total execution time: 0.0367
DEBUG - 2022-06-02 00:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:28:46 --> Total execution time: 0.0496
DEBUG - 2022-06-02 00:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:59:28 --> Total execution time: 0.0655
DEBUG - 2022-06-02 00:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:59:49 --> Total execution time: 0.0635
DEBUG - 2022-06-02 00:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:59:57 --> Total execution time: 0.0695
DEBUG - 2022-06-02 00:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:30:05 --> Total execution time: 0.0578
DEBUG - 2022-06-02 00:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:00:08 --> Total execution time: 0.0638
DEBUG - 2022-06-02 00:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:00:16 --> Total execution time: 0.0323
DEBUG - 2022-06-02 00:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:00:22 --> Total execution time: 0.0318
DEBUG - 2022-06-02 00:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:00:26 --> Total execution time: 0.0463
DEBUG - 2022-06-02 00:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:00:33 --> Total execution time: 0.0967
DEBUG - 2022-06-02 00:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:00:37 --> Total execution time: 0.0791
DEBUG - 2022-06-02 00:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:00:39 --> Total execution time: 0.0828
DEBUG - 2022-06-02 00:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:32:26 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:02:26 --> Total execution time: 0.1296
DEBUG - 2022-06-02 00:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:03:01 --> Total execution time: 0.0443
DEBUG - 2022-06-02 00:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:34:45 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:04:45 --> Total execution time: 0.0284
DEBUG - 2022-06-02 00:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:04:45 --> Total execution time: 0.0368
DEBUG - 2022-06-02 00:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:37:02 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:07:02 --> Total execution time: 0.0798
DEBUG - 2022-06-02 00:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 00:37:30 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-02 00:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:37:57 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:07:57 --> Total execution time: 0.0379
DEBUG - 2022-06-02 00:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:37:58 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:07:58 --> Total execution time: 0.0324
DEBUG - 2022-06-02 00:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:08:10 --> Total execution time: 0.0350
DEBUG - 2022-06-02 00:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:08:20 --> Total execution time: 0.0466
DEBUG - 2022-06-02 00:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:08:30 --> Total execution time: 0.0508
DEBUG - 2022-06-02 00:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:08:34 --> Total execution time: 0.0854
DEBUG - 2022-06-02 00:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:08:46 --> Total execution time: 0.0526
DEBUG - 2022-06-02 00:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:10:50 --> Total execution time: 0.0862
DEBUG - 2022-06-02 00:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:45:51 --> Total execution time: 0.2013
DEBUG - 2022-06-02 00:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:45:52 --> Total execution time: 0.1262
DEBUG - 2022-06-02 00:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:45:53 --> Total execution time: 0.1874
DEBUG - 2022-06-02 00:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:16:11 --> Total execution time: 0.0344
DEBUG - 2022-06-02 00:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:14 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:16:14 --> Total execution time: 0.0857
DEBUG - 2022-06-02 00:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:16:19 --> Total execution time: 0.0847
DEBUG - 2022-06-02 00:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:16:24 --> Total execution time: 0.0636
DEBUG - 2022-06-02 00:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:29 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:16:29 --> Total execution time: 0.0227
DEBUG - 2022-06-02 00:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:16:34 --> Total execution time: 0.0656
DEBUG - 2022-06-02 00:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:16:36 --> Total execution time: 0.0617
DEBUG - 2022-06-02 00:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:16:39 --> Total execution time: 0.0325
DEBUG - 2022-06-02 00:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:46:41 --> Total execution time: 0.0263
DEBUG - 2022-06-02 00:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:46:42 --> Total execution time: 0.0344
DEBUG - 2022-06-02 00:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:46:42 --> Total execution time: 0.0555
DEBUG - 2022-06-02 00:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:16:46 --> Total execution time: 0.0602
DEBUG - 2022-06-02 00:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:48:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 00:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:18:40 --> Total execution time: 1.5117
DEBUG - 2022-06-02 00:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:48:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 00:48:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 00:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:19:00 --> Total execution time: 1.5111
DEBUG - 2022-06-02 00:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:19:07 --> Total execution time: 0.0313
DEBUG - 2022-06-02 00:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:49:24 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:19:24 --> Total execution time: 0.0320
DEBUG - 2022-06-02 00:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:19:28 --> Total execution time: 1.4479
DEBUG - 2022-06-02 00:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:49:49 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:19:49 --> Total execution time: 0.0321
DEBUG - 2022-06-02 00:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:50:07 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:20:07 --> Total execution time: 0.0337
DEBUG - 2022-06-02 00:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:50:14 --> Total execution time: 0.0272
DEBUG - 2022-06-02 00:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:50:15 --> Total execution time: 0.0376
DEBUG - 2022-06-02 00:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:50:15 --> Total execution time: 0.0353
DEBUG - 2022-06-02 00:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:51:22 --> Total execution time: 0.0272
DEBUG - 2022-06-02 00:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:51:23 --> Total execution time: 0.0318
DEBUG - 2022-06-02 00:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:51:23 --> Total execution time: 0.0453
DEBUG - 2022-06-02 00:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:21:33 --> Total execution time: 0.0605
DEBUG - 2022-06-02 00:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:21:36 --> Total execution time: 0.0419
DEBUG - 2022-06-02 00:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:21:41 --> Total execution time: 0.0435
DEBUG - 2022-06-02 00:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:51:43 --> Total execution time: 0.0289
DEBUG - 2022-06-02 00:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:51:44 --> Total execution time: 0.0384
DEBUG - 2022-06-02 00:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:51:44 --> Total execution time: 0.0474
DEBUG - 2022-06-02 00:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:51:47 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:21:47 --> Total execution time: 0.0331
DEBUG - 2022-06-02 00:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:22:13 --> Total execution time: 0.0282
DEBUG - 2022-06-02 00:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:22:28 --> Total execution time: 0.0300
DEBUG - 2022-06-02 00:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:22:37 --> Total execution time: 0.0411
DEBUG - 2022-06-02 00:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:22:44 --> Total execution time: 0.0486
DEBUG - 2022-06-02 00:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:22:44 --> Total execution time: 0.0373
DEBUG - 2022-06-02 00:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:22:57 --> Total execution time: 0.0478
DEBUG - 2022-06-02 00:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:23:00 --> Total execution time: 0.0217
DEBUG - 2022-06-02 00:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:53:01 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:23:01 --> Total execution time: 0.0527
DEBUG - 2022-06-02 00:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:23:11 --> Total execution time: 1.4682
DEBUG - 2022-06-02 00:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:23:47 --> Total execution time: 0.0317
DEBUG - 2022-06-02 00:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:23:55 --> Total execution time: 0.0490
DEBUG - 2022-06-02 00:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:24:03 --> Total execution time: 0.0683
DEBUG - 2022-06-02 00:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:24:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 00:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:24:04 --> Total execution time: 0.0519
DEBUG - 2022-06-02 00:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:24:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 00:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:24:07 --> Total execution time: 0.0450
DEBUG - 2022-06-02 00:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:24:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 11:24:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 11:24:08 --> Total execution time: 0.1860
DEBUG - 2022-06-02 00:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:24:37 --> Total execution time: 0.0307
DEBUG - 2022-06-02 00:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:25:01 --> Total execution time: 0.0805
DEBUG - 2022-06-02 00:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:56:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 00:56:24 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 00:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:26:44 --> Total execution time: 0.0292
DEBUG - 2022-06-02 00:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:56:47 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:26:47 --> Total execution time: 0.0504
DEBUG - 2022-06-02 00:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:27:14 --> Total execution time: 0.0507
DEBUG - 2022-06-02 00:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:57:20 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:27:20 --> Total execution time: 0.0386
DEBUG - 2022-06-02 00:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:57:22 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:27:22 --> Total execution time: 0.0542
DEBUG - 2022-06-02 00:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:27:32 --> Total execution time: 0.0289
DEBUG - 2022-06-02 00:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:27:34 --> Total execution time: 0.0335
DEBUG - 2022-06-02 00:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:27:38 --> Total execution time: 0.0362
DEBUG - 2022-06-02 00:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:27:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 00:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:27:39 --> Total execution time: 0.0403
DEBUG - 2022-06-02 00:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:27:44 --> Total execution time: 0.0741
DEBUG - 2022-06-02 00:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 00:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:28:00 --> Total execution time: 0.0325
DEBUG - 2022-06-02 00:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:28:10 --> Total execution time: 0.0450
DEBUG - 2022-06-02 00:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:28:23 --> Total execution time: 0.0363
DEBUG - 2022-06-02 00:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:28:30 --> Total execution time: 0.0336
DEBUG - 2022-06-02 00:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:58:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 00:58:33 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 00:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:28:34 --> Total execution time: 0.0314
DEBUG - 2022-06-02 00:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:28:43 --> Total execution time: 0.0627
DEBUG - 2022-06-02 00:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:28:46 --> Total execution time: 0.0352
DEBUG - 2022-06-02 00:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:28:50 --> Total execution time: 0.0505
DEBUG - 2022-06-02 00:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:28:54 --> Total execution time: 0.0397
DEBUG - 2022-06-02 00:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:29:02 --> Total execution time: 0.0464
DEBUG - 2022-06-02 00:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:59:15 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:29:15 --> Total execution time: 0.0776
DEBUG - 2022-06-02 00:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:59:16 --> No URI present. Default controller set.
DEBUG - 2022-06-02 00:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:29:16 --> Total execution time: 0.0563
DEBUG - 2022-06-02 00:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:29:17 --> Total execution time: 0.0466
DEBUG - 2022-06-02 00:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:29:36 --> Total execution time: 0.0208
DEBUG - 2022-06-02 00:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:29:45 --> Total execution time: 0.0456
DEBUG - 2022-06-02 00:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 00:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 00:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:29:47 --> Total execution time: 0.0424
DEBUG - 2022-06-02 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:30:02 --> Total execution time: 0.0521
DEBUG - 2022-06-02 01:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:30:13 --> Total execution time: 0.0436
DEBUG - 2022-06-02 01:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:30:15 --> Total execution time: 0.0451
DEBUG - 2022-06-02 01:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:30:15 --> Total execution time: 0.0541
DEBUG - 2022-06-02 01:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:30:23 --> Total execution time: 0.0401
DEBUG - 2022-06-02 01:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:30:27 --> Total execution time: 0.0338
DEBUG - 2022-06-02 01:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:00:57 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:30:57 --> Total execution time: 0.0245
DEBUG - 2022-06-02 01:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:10 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:31:10 --> Total execution time: 0.0568
DEBUG - 2022-06-02 01:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:31:16 --> Total execution time: 0.0278
DEBUG - 2022-06-02 01:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:31:16 --> Total execution time: 0.0317
DEBUG - 2022-06-02 01:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:31:18 --> Total execution time: 0.0276
DEBUG - 2022-06-02 01:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:31:20 --> Total execution time: 0.0395
DEBUG - 2022-06-02 01:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:31:21 --> Total execution time: 0.0359
DEBUG - 2022-06-02 01:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:31:23 --> Total execution time: 0.0471
DEBUG - 2022-06-02 01:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:31:28 --> Total execution time: 0.0307
DEBUG - 2022-06-02 01:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:31:35 --> Total execution time: 0.0213
DEBUG - 2022-06-02 01:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:31:39 --> Total execution time: 0.0438
DEBUG - 2022-06-02 01:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:31:43 --> Total execution time: 0.0572
DEBUG - 2022-06-02 01:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:31:48 --> Total execution time: 0.0226
DEBUG - 2022-06-02 01:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:31:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 01:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:31:49 --> Total execution time: 0.0228
DEBUG - 2022-06-02 01:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:32:03 --> Total execution time: 0.0362
DEBUG - 2022-06-02 01:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:32:34 --> Total execution time: 0.0578
DEBUG - 2022-06-02 01:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:02:51 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:32:51 --> Total execution time: 0.0224
DEBUG - 2022-06-02 01:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:02:52 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:32:52 --> Total execution time: 0.0385
DEBUG - 2022-06-02 01:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:33:16 --> Total execution time: 0.0366
DEBUG - 2022-06-02 01:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:33:23 --> Total execution time: 0.0470
DEBUG - 2022-06-02 01:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:33:23 --> Total execution time: 0.0601
DEBUG - 2022-06-02 01:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:33:39 --> Total execution time: 0.0332
DEBUG - 2022-06-02 01:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:33:45 --> Total execution time: 0.0266
DEBUG - 2022-06-02 01:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:04:09 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:34:09 --> Total execution time: 0.0632
DEBUG - 2022-06-02 01:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:34:14 --> Total execution time: 0.0575
DEBUG - 2022-06-02 01:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:34:19 --> Total execution time: 0.0539
DEBUG - 2022-06-02 01:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:34:57 --> Total execution time: 0.0322
DEBUG - 2022-06-02 01:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:34:59 --> Total execution time: 0.0350
DEBUG - 2022-06-02 01:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:35:08 --> Total execution time: 0.0316
DEBUG - 2022-06-02 01:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:35:15 --> Total execution time: 0.0372
DEBUG - 2022-06-02 01:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:35:15 --> Total execution time: 0.0413
DEBUG - 2022-06-02 01:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:35:16 --> Total execution time: 0.0309
DEBUG - 2022-06-02 01:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:35:21 --> Total execution time: 0.0335
DEBUG - 2022-06-02 01:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:35:24 --> Total execution time: 0.0452
DEBUG - 2022-06-02 01:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:35:27 --> Total execution time: 0.0289
DEBUG - 2022-06-02 01:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:35:53 --> Total execution time: 0.0301
DEBUG - 2022-06-02 01:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:05:58 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:35:58 --> Total execution time: 0.0239
DEBUG - 2022-06-02 01:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:36:02 --> Total execution time: 0.0334
DEBUG - 2022-06-02 01:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:05 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:36:05 --> Total execution time: 0.0293
DEBUG - 2022-06-02 01:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:36:09 --> Total execution time: 0.0261
DEBUG - 2022-06-02 01:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:36:10 --> Total execution time: 0.0303
DEBUG - 2022-06-02 01:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:36:14 --> Total execution time: 0.0450
DEBUG - 2022-06-02 01:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:06:16 --> Total execution time: 0.0359
DEBUG - 2022-06-02 01:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:36:17 --> Total execution time: 0.0298
DEBUG - 2022-06-02 01:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:06:17 --> Total execution time: 0.0294
DEBUG - 2022-06-02 01:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:06:17 --> Total execution time: 0.0363
DEBUG - 2022-06-02 01:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:06:27 --> Total execution time: 0.0294
DEBUG - 2022-06-02 01:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:36:35 --> Total execution time: 0.0492
DEBUG - 2022-06-02 01:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:36:39 --> Total execution time: 0.0438
DEBUG - 2022-06-02 01:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:36:42 --> Total execution time: 0.0516
DEBUG - 2022-06-02 01:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:06:48 --> Total execution time: 0.0341
DEBUG - 2022-06-02 01:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:36:50 --> Total execution time: 0.0306
DEBUG - 2022-06-02 01:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:37:02 --> Total execution time: 0.0271
DEBUG - 2022-06-02 01:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:37:08 --> Total execution time: 0.0259
DEBUG - 2022-06-02 01:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:37:21 --> Total execution time: 0.0588
DEBUG - 2022-06-02 01:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:37:24 --> Total execution time: 0.0311
DEBUG - 2022-06-02 01:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:37:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 01:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:37:25 --> Total execution time: 0.0266
DEBUG - 2022-06-02 01:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:37:45 --> Total execution time: 0.0710
DEBUG - 2022-06-02 01:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:07:47 --> Total execution time: 0.0260
DEBUG - 2022-06-02 01:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:37:49 --> Total execution time: 0.0360
DEBUG - 2022-06-02 01:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:37:53 --> Total execution time: 0.0298
DEBUG - 2022-06-02 01:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:08:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 01:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:38:11 --> Total execution time: 1.5017
DEBUG - 2022-06-02 01:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:08:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 01:08:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 01:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:38:22 --> Total execution time: 0.0316
DEBUG - 2022-06-02 01:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:08:22 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:38:22 --> Total execution time: 0.0365
DEBUG - 2022-06-02 01:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:38:25 --> Total execution time: 0.0341
DEBUG - 2022-06-02 01:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:38:28 --> Total execution time: 0.0359
DEBUG - 2022-06-02 01:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:38:35 --> Total execution time: 0.0256
DEBUG - 2022-06-02 01:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:08:36 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:38:36 --> Total execution time: 0.0229
DEBUG - 2022-06-02 01:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:08:36 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:38:36 --> Total execution time: 0.0320
DEBUG - 2022-06-02 01:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:38:40 --> Total execution time: 0.0217
DEBUG - 2022-06-02 01:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:39:00 --> Total execution time: 0.0424
DEBUG - 2022-06-02 01:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:39:10 --> Total execution time: 0.0359
DEBUG - 2022-06-02 01:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:39:11 --> Total execution time: 0.0642
DEBUG - 2022-06-02 01:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:39:11 --> Total execution time: 0.0429
DEBUG - 2022-06-02 01:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:39:14 --> Total execution time: 0.0400
DEBUG - 2022-06-02 01:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:39:14 --> Total execution time: 0.0194
DEBUG - 2022-06-02 01:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:39:16 --> Total execution time: 0.0392
DEBUG - 2022-06-02 01:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:39:26 --> Total execution time: 0.0323
DEBUG - 2022-06-02 01:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:39:30 --> Total execution time: 0.0370
DEBUG - 2022-06-02 01:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:39:38 --> Total execution time: 0.0533
DEBUG - 2022-06-02 01:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:40:07 --> Total execution time: 0.0304
DEBUG - 2022-06-02 01:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:40:14 --> Total execution time: 0.0517
DEBUG - 2022-06-02 01:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:40:16 --> Total execution time: 0.0444
DEBUG - 2022-06-02 01:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:40:25 --> Total execution time: 0.0267
DEBUG - 2022-06-02 01:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:40:30 --> Total execution time: 0.0274
DEBUG - 2022-06-02 01:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:40:50 --> Total execution time: 0.1129
DEBUG - 2022-06-02 01:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:40:53 --> Total execution time: 0.0357
DEBUG - 2022-06-02 01:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:41:22 --> Total execution time: 0.0763
DEBUG - 2022-06-02 01:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:41:25 --> Total execution time: 0.0543
DEBUG - 2022-06-02 01:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:41:27 --> Total execution time: 0.0281
DEBUG - 2022-06-02 01:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:41:28 --> Total execution time: 0.0319
DEBUG - 2022-06-02 01:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:41:31 --> Total execution time: 0.0532
DEBUG - 2022-06-02 01:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:41:59 --> Total execution time: 0.0420
DEBUG - 2022-06-02 01:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:42:03 --> Total execution time: 0.0362
DEBUG - 2022-06-02 01:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:42:10 --> Total execution time: 0.0469
DEBUG - 2022-06-02 01:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:42:20 --> Total execution time: 0.0299
DEBUG - 2022-06-02 01:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:42:23 --> Total execution time: 0.0387
DEBUG - 2022-06-02 01:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:42:28 --> Total execution time: 0.0332
DEBUG - 2022-06-02 01:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:42:39 --> Total execution time: 0.0890
DEBUG - 2022-06-02 01:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:43:00 --> Total execution time: 0.0882
DEBUG - 2022-06-02 01:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:43:30 --> Total execution time: 0.0452
DEBUG - 2022-06-02 01:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:44:13 --> Total execution time: 0.0418
DEBUG - 2022-06-02 01:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:44:59 --> Total execution time: 0.0690
DEBUG - 2022-06-02 01:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:45:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 01:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:45:09 --> Total execution time: 0.0438
DEBUG - 2022-06-02 01:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 01:15:28 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-02 01:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:45:36 --> Total execution time: 0.0419
DEBUG - 2022-06-02 01:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:45:48 --> Total execution time: 0.0314
DEBUG - 2022-06-02 01:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:16:00 --> Total execution time: 0.0351
DEBUG - 2022-06-02 01:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:46:01 --> Total execution time: 0.0504
DEBUG - 2022-06-02 01:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:16:10 --> Total execution time: 0.0876
DEBUG - 2022-06-02 01:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:46:11 --> Total execution time: 0.0359
DEBUG - 2022-06-02 01:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:46:15 --> Total execution time: 0.0444
DEBUG - 2022-06-02 01:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 01:16:21 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-02 01:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:46:32 --> Total execution time: 0.0380
DEBUG - 2022-06-02 01:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:46:37 --> Total execution time: 0.0335
DEBUG - 2022-06-02 01:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:46:46 --> Total execution time: 0.0336
DEBUG - 2022-06-02 01:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:46:47 --> Total execution time: 0.0285
DEBUG - 2022-06-02 01:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:46:50 --> Total execution time: 0.0558
DEBUG - 2022-06-02 01:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:46:58 --> Total execution time: 0.0852
DEBUG - 2022-06-02 01:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:17:07 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:47:07 --> Total execution time: 0.0673
DEBUG - 2022-06-02 01:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:47:14 --> Total execution time: 0.0388
DEBUG - 2022-06-02 01:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:47:19 --> Total execution time: 0.0449
DEBUG - 2022-06-02 01:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:17:21 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:47:21 --> Total execution time: 0.0498
DEBUG - 2022-06-02 01:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:47:25 --> Total execution time: 0.0348
DEBUG - 2022-06-02 01:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:47:33 --> Total execution time: 0.0295
DEBUG - 2022-06-02 01:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 01:17:33 --> 404 Page Not Found: Memberships/index
DEBUG - 2022-06-02 01:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:17:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 01:17:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 01:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:17:47 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:47:47 --> Total execution time: 0.0270
DEBUG - 2022-06-02 01:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:47:54 --> Total execution time: 0.0312
DEBUG - 2022-06-02 01:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:48:41 --> Total execution time: 0.0316
DEBUG - 2022-06-02 01:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:49:05 --> Total execution time: 0.0266
DEBUG - 2022-06-02 01:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:49:41 --> Total execution time: 0.0628
DEBUG - 2022-06-02 01:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:19:58 --> Total execution time: 0.0299
DEBUG - 2022-06-02 01:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:20:01 --> Total execution time: 0.0304
DEBUG - 2022-06-02 01:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:20:01 --> Total execution time: 0.0270
DEBUG - 2022-06-02 01:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:20:16 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:50:16 --> Total execution time: 0.0370
DEBUG - 2022-06-02 01:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:20:21 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:50:21 --> Total execution time: 0.0270
DEBUG - 2022-06-02 01:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:20:28 --> Total execution time: 0.1197
DEBUG - 2022-06-02 01:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:50:34 --> Total execution time: 0.0859
DEBUG - 2022-06-02 01:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:20:45 --> Total execution time: 0.0958
DEBUG - 2022-06-02 01:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:21:01 --> Total execution time: 0.0835
DEBUG - 2022-06-02 01:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:51:02 --> Total execution time: 0.0256
DEBUG - 2022-06-02 01:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:24:34 --> Total execution time: 0.1924
DEBUG - 2022-06-02 01:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:54:56 --> Total execution time: 0.0783
DEBUG - 2022-06-02 01:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:55:13 --> Total execution time: 0.0532
DEBUG - 2022-06-02 01:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:55:26 --> Total execution time: 0.0273
DEBUG - 2022-06-02 01:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:55:33 --> Total execution time: 0.0387
DEBUG - 2022-06-02 01:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:25:39 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:55:39 --> Total execution time: 0.0265
DEBUG - 2022-06-02 01:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:55:42 --> Total execution time: 0.0484
DEBUG - 2022-06-02 01:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:55:50 --> Total execution time: 0.0472
DEBUG - 2022-06-02 01:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:56:32 --> Total execution time: 0.0304
DEBUG - 2022-06-02 01:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:56:57 --> Total execution time: 0.0759
DEBUG - 2022-06-02 01:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:57:04 --> Total execution time: 0.0324
DEBUG - 2022-06-02 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:57:57 --> Total execution time: 0.0500
DEBUG - 2022-06-02 01:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 01:31:21 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 01:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:32:26 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:02:26 --> Total execution time: 0.1264
DEBUG - 2022-06-02 01:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:03:00 --> Total execution time: 0.0217
DEBUG - 2022-06-02 01:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:03:28 --> Total execution time: 0.0357
DEBUG - 2022-06-02 01:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:03:35 --> Total execution time: 0.0534
DEBUG - 2022-06-02 01:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 01:33:43 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 01:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:04:33 --> Total execution time: 0.0276
DEBUG - 2022-06-02 01:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:04:48 --> Total execution time: 0.0538
DEBUG - 2022-06-02 01:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:04:50 --> Total execution time: 0.0250
DEBUG - 2022-06-02 01:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:06:14 --> Total execution time: 0.0298
DEBUG - 2022-06-02 01:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:06:35 --> Total execution time: 0.0386
DEBUG - 2022-06-02 01:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:06:51 --> Total execution time: 0.0364
DEBUG - 2022-06-02 01:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:06:52 --> Total execution time: 0.0330
DEBUG - 2022-06-02 01:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:00 --> Total execution time: 0.0371
DEBUG - 2022-06-02 01:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:04 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:04 --> Total execution time: 0.0579
DEBUG - 2022-06-02 01:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:04 --> Total execution time: 0.0309
DEBUG - 2022-06-02 01:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:12 --> Total execution time: 0.0349
DEBUG - 2022-06-02 01:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:24 --> Total execution time: 0.0324
DEBUG - 2022-06-02 01:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:24 --> Total execution time: 0.0260
DEBUG - 2022-06-02 01:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:25 --> Total execution time: 0.1234
DEBUG - 2022-06-02 01:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:39 --> Total execution time: 0.0600
DEBUG - 2022-06-02 01:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:42 --> Total execution time: 0.0511
DEBUG - 2022-06-02 01:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:43 --> Total execution time: 0.0632
DEBUG - 2022-06-02 01:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:44 --> Total execution time: 0.0643
DEBUG - 2022-06-02 01:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:46 --> Total execution time: 0.0386
DEBUG - 2022-06-02 01:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:48 --> Total execution time: 0.0349
DEBUG - 2022-06-02 01:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:48 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:48 --> Total execution time: 0.0311
DEBUG - 2022-06-02 01:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:48 --> Total execution time: 0.0462
DEBUG - 2022-06-02 01:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:49 --> Total execution time: 0.0352
DEBUG - 2022-06-02 01:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:37:59 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:07:59 --> Total execution time: 0.0292
DEBUG - 2022-06-02 01:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:04 --> Total execution time: 0.0453
DEBUG - 2022-06-02 01:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:10 --> Total execution time: 0.0981
DEBUG - 2022-06-02 01:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:14 --> Total execution time: 0.0203
DEBUG - 2022-06-02 01:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:21 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:21 --> Total execution time: 0.0657
DEBUG - 2022-06-02 01:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:21 --> Total execution time: 0.0403
DEBUG - 2022-06-02 01:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:21 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:21 --> Total execution time: 0.0333
DEBUG - 2022-06-02 01:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:25 --> Total execution time: 0.0317
DEBUG - 2022-06-02 01:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:26 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:26 --> Total execution time: 0.0498
DEBUG - 2022-06-02 01:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:26 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:26 --> Total execution time: 0.0362
DEBUG - 2022-06-02 01:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:29 --> Total execution time: 0.0374
DEBUG - 2022-06-02 01:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:30 --> Total execution time: 0.0795
DEBUG - 2022-06-02 01:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:33 --> Total execution time: 0.0490
DEBUG - 2022-06-02 01:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:38 --> Total execution time: 0.0301
DEBUG - 2022-06-02 01:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:40 --> Total execution time: 0.0692
DEBUG - 2022-06-02 01:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:41 --> Total execution time: 0.0577
DEBUG - 2022-06-02 01:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:46 --> Total execution time: 0.0256
DEBUG - 2022-06-02 01:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:55 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:55 --> Total execution time: 0.0349
DEBUG - 2022-06-02 01:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:58 --> Total execution time: 0.0300
DEBUG - 2022-06-02 01:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:07 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:09:07 --> Total execution time: 0.0340
DEBUG - 2022-06-02 01:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:09:07 --> Total execution time: 0.0299
DEBUG - 2022-06-02 01:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:09:13 --> Total execution time: 0.0405
DEBUG - 2022-06-02 01:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:39:14 --> Total execution time: 0.0351
DEBUG - 2022-06-02 01:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:09:15 --> Total execution time: 0.0256
DEBUG - 2022-06-02 01:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:39:15 --> Total execution time: 0.0452
DEBUG - 2022-06-02 01:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:39:15 --> Total execution time: 0.0924
DEBUG - 2022-06-02 01:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:09:17 --> Total execution time: 0.0253
DEBUG - 2022-06-02 01:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:09:33 --> Total execution time: 0.0329
DEBUG - 2022-06-02 01:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:09:51 --> Total execution time: 0.0300
DEBUG - 2022-06-02 01:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:09:52 --> Total execution time: 0.0297
DEBUG - 2022-06-02 01:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:02 --> Total execution time: 0.0324
DEBUG - 2022-06-02 01:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:03 --> Total execution time: 0.0331
DEBUG - 2022-06-02 01:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:15 --> Total execution time: 0.0272
DEBUG - 2022-06-02 01:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:29 --> Total execution time: 0.0359
DEBUG - 2022-06-02 01:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:36 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:36 --> Total execution time: 0.0249
DEBUG - 2022-06-02 01:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:36 --> Total execution time: 0.0312
DEBUG - 2022-06-02 01:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 01:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:37 --> Total execution time: 0.0270
DEBUG - 2022-06-02 01:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:44 --> Total execution time: 0.0300
DEBUG - 2022-06-02 01:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:48 --> Total execution time: 0.0420
DEBUG - 2022-06-02 01:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:40:50 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 01:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:52 --> Total execution time: 1.5967
DEBUG - 2022-06-02 01:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:53 --> Total execution time: 0.0367
DEBUG - 2022-06-02 01:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 01:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:54 --> Total execution time: 0.0259
DEBUG - 2022-06-02 01:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:54 --> Total execution time: 0.0366
DEBUG - 2022-06-02 01:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:40:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 01:40:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 01:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:06 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:06 --> Total execution time: 0.0405
DEBUG - 2022-06-02 01:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:24 --> Total execution time: 0.0266
DEBUG - 2022-06-02 01:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:25 --> Total execution time: 0.0319
DEBUG - 2022-06-02 01:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:27 --> Total execution time: 0.0292
DEBUG - 2022-06-02 01:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 01:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:28 --> Total execution time: 0.0308
DEBUG - 2022-06-02 01:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 12:11:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 12:11:29 --> Total execution time: 0.1595
DEBUG - 2022-06-02 01:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:37 --> Total execution time: 0.0326
DEBUG - 2022-06-02 01:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:39 --> Total execution time: 0.0422
DEBUG - 2022-06-02 01:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:41 --> Total execution time: 0.0356
DEBUG - 2022-06-02 01:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:45 --> Total execution time: 0.0513
DEBUG - 2022-06-02 12:11:45 --> Total execution time: 0.0462
DEBUG - 2022-06-02 01:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:47 --> Total execution time: 0.0278
DEBUG - 2022-06-02 01:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:53 --> Total execution time: 0.0354
DEBUG - 2022-06-02 01:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:53 --> Total execution time: 0.0291
DEBUG - 2022-06-02 01:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:11:56 --> Total execution time: 0.0287
DEBUG - 2022-06-02 01:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:12:03 --> Total execution time: 0.0899
DEBUG - 2022-06-02 01:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:12:04 --> Total execution time: 0.0253
DEBUG - 2022-06-02 01:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:12:05 --> Total execution time: 0.0375
DEBUG - 2022-06-02 01:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:12:06 --> Total execution time: 0.0295
DEBUG - 2022-06-02 01:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:12:10 --> Total execution time: 0.0597
DEBUG - 2022-06-02 01:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:42:15 --> Total execution time: 0.0457
DEBUG - 2022-06-02 01:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:42:18 --> Total execution time: 0.0364
DEBUG - 2022-06-02 01:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:42:18 --> Total execution time: 0.0561
DEBUG - 2022-06-02 01:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:12:18 --> Total execution time: 0.0414
DEBUG - 2022-06-02 01:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:23 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:12:23 --> Total execution time: 0.0365
DEBUG - 2022-06-02 01:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:12:48 --> Total execution time: 0.0430
DEBUG - 2022-06-02 01:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:12:50 --> Total execution time: 0.0458
DEBUG - 2022-06-02 01:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:13:00 --> Total execution time: 0.0296
DEBUG - 2022-06-02 01:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:13:04 --> Total execution time: 0.0357
DEBUG - 2022-06-02 01:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:13:08 --> Total execution time: 0.0274
DEBUG - 2022-06-02 01:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:13:17 --> Total execution time: 0.0743
DEBUG - 2022-06-02 01:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:43:24 --> Total execution time: 0.0295
DEBUG - 2022-06-02 01:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:43:41 --> Total execution time: 0.0404
DEBUG - 2022-06-02 01:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:13:42 --> Total execution time: 0.0681
DEBUG - 2022-06-02 01:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:43:54 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:13:55 --> Total execution time: 0.0286
DEBUG - 2022-06-02 01:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:44:03 --> Total execution time: 0.0308
DEBUG - 2022-06-02 01:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:08 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:14:08 --> Total execution time: 0.0576
DEBUG - 2022-06-02 01:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:08 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:14:08 --> Total execution time: 0.0466
DEBUG - 2022-06-02 01:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:44:09 --> Total execution time: 0.0292
DEBUG - 2022-06-02 01:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:44:12 --> Total execution time: 0.0244
DEBUG - 2022-06-02 01:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:44:19 --> Total execution time: 0.0312
DEBUG - 2022-06-02 01:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:44:21 --> Total execution time: 0.0246
DEBUG - 2022-06-02 01:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:44:22 --> Total execution time: 0.0249
DEBUG - 2022-06-02 01:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:44:23 --> Total execution time: 0.0245
DEBUG - 2022-06-02 01:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:14:25 --> Total execution time: 0.0365
DEBUG - 2022-06-02 01:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:14:33 --> Total execution time: 0.0257
DEBUG - 2022-06-02 01:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:14:34 --> Total execution time: 0.0344
DEBUG - 2022-06-02 01:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:14:37 --> Total execution time: 0.0378
DEBUG - 2022-06-02 01:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:14:42 --> Total execution time: 0.0348
DEBUG - 2022-06-02 01:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:14:46 --> Total execution time: 0.0307
DEBUG - 2022-06-02 01:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:14:52 --> Total execution time: 0.0328
DEBUG - 2022-06-02 01:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:14:53 --> Total execution time: 0.0300
DEBUG - 2022-06-02 01:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:14:56 --> Total execution time: 0.0314
DEBUG - 2022-06-02 01:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:15:01 --> Total execution time: 0.0422
DEBUG - 2022-06-02 01:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:15:54 --> Total execution time: 0.0737
DEBUG - 2022-06-02 01:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:16:30 --> Total execution time: 0.0629
DEBUG - 2022-06-02 01:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:16:37 --> Total execution time: 0.0548
DEBUG - 2022-06-02 01:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:17:13 --> Total execution time: 0.0829
DEBUG - 2022-06-02 01:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:17:53 --> Total execution time: 0.0627
DEBUG - 2022-06-02 01:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:17:55 --> Total execution time: 0.0332
DEBUG - 2022-06-02 01:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:17:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 01:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:17:57 --> Total execution time: 0.0293
DEBUG - 2022-06-02 01:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:48:13 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:18:13 --> Total execution time: 0.0472
DEBUG - 2022-06-02 01:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:18:22 --> Total execution time: 1.5485
DEBUG - 2022-06-02 01:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:48:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 01:48:25 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 01:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:19:18 --> Total execution time: 0.0549
DEBUG - 2022-06-02 01:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:19:20 --> Total execution time: 0.0332
DEBUG - 2022-06-02 01:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:49:21 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:19:21 --> Total execution time: 0.0322
DEBUG - 2022-06-02 01:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:19:40 --> Total execution time: 0.0451
DEBUG - 2022-06-02 01:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:50:04 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:20:04 --> Total execution time: 0.0422
DEBUG - 2022-06-02 01:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:20:10 --> Total execution time: 0.0278
DEBUG - 2022-06-02 01:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:20:28 --> Total execution time: 0.0279
DEBUG - 2022-06-02 01:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:20:38 --> Total execution time: 0.0325
DEBUG - 2022-06-02 01:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:20:41 --> Total execution time: 0.0894
DEBUG - 2022-06-02 01:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:20:43 --> Total execution time: 0.0339
DEBUG - 2022-06-02 01:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:20:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 01:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:20:44 --> Total execution time: 0.0310
DEBUG - 2022-06-02 01:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:21:08 --> Total execution time: 0.0642
DEBUG - 2022-06-02 01:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:21:14 --> Total execution time: 0.0882
DEBUG - 2022-06-02 01:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:21:36 --> Total execution time: 0.0312
DEBUG - 2022-06-02 01:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:21:37 --> Total execution time: 0.0395
DEBUG - 2022-06-02 01:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:23:19 --> Total execution time: 0.0340
DEBUG - 2022-06-02 01:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:53:21 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:23:21 --> Total execution time: 0.0468
DEBUG - 2022-06-02 01:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:23:23 --> Total execution time: 0.0257
DEBUG - 2022-06-02 01:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:23:29 --> Total execution time: 0.0255
DEBUG - 2022-06-02 01:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:23:37 --> Total execution time: 0.0286
DEBUG - 2022-06-02 01:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:23:42 --> Total execution time: 0.0583
DEBUG - 2022-06-02 01:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:23:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 01:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:23:44 --> Total execution time: 0.0326
DEBUG - 2022-06-02 01:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:24:05 --> Total execution time: 0.0294
DEBUG - 2022-06-02 01:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:24:15 --> Total execution time: 0.0299
DEBUG - 2022-06-02 01:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:24:20 --> Total execution time: 0.0318
DEBUG - 2022-06-02 01:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:24:34 --> Total execution time: 0.0486
DEBUG - 2022-06-02 01:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:24:37 --> Total execution time: 0.0452
DEBUG - 2022-06-02 01:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:24:39 --> Total execution time: 0.0351
DEBUG - 2022-06-02 01:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:24:39 --> Total execution time: 0.0526
DEBUG - 2022-06-02 01:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:24:53 --> Total execution time: 0.0405
DEBUG - 2022-06-02 01:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:25:02 --> Total execution time: 0.0988
DEBUG - 2022-06-02 01:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:25:05 --> Total execution time: 0.0710
DEBUG - 2022-06-02 01:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:10 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:25:10 --> Total execution time: 0.0365
DEBUG - 2022-06-02 01:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:25:10 --> Total execution time: 0.0494
DEBUG - 2022-06-02 01:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:25:10 --> Total execution time: 0.0509
DEBUG - 2022-06-02 01:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:25:13 --> Total execution time: 0.0464
DEBUG - 2022-06-02 01:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:15 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:25:15 --> Total execution time: 0.0393
DEBUG - 2022-06-02 01:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:25:23 --> Total execution time: 0.0411
DEBUG - 2022-06-02 01:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:30 --> No URI present. Default controller set.
DEBUG - 2022-06-02 01:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:25:30 --> Total execution time: 0.0631
DEBUG - 2022-06-02 01:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:25:31 --> Total execution time: 0.0363
DEBUG - 2022-06-02 01:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:25:46 --> Total execution time: 0.0545
DEBUG - 2022-06-02 01:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:25:54 --> Total execution time: 0.0400
DEBUG - 2022-06-02 01:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:26:06 --> Total execution time: 0.0583
DEBUG - 2022-06-02 01:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:26:18 --> Total execution time: 0.0392
DEBUG - 2022-06-02 01:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:28:45 --> Total execution time: 0.0293
DEBUG - 2022-06-02 01:58:45 --> Total execution time: 0.0903
DEBUG - 2022-06-02 01:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:58:52 --> Total execution time: 0.0445
DEBUG - 2022-06-02 01:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 01:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 01:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 01:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:29:36 --> Total execution time: 0.0584
DEBUG - 2022-06-02 02:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:30:01 --> Total execution time: 0.0649
DEBUG - 2022-06-02 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:30:03 --> Total execution time: 0.0728
DEBUG - 2022-06-02 02:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:30:05 --> Total execution time: 0.1751
DEBUG - 2022-06-02 02:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:30:09 --> Total execution time: 0.1935
DEBUG - 2022-06-02 02:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:05:17 --> No URI present. Default controller set.
DEBUG - 2022-06-02 02:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:35:17 --> Total execution time: 0.1276
DEBUG - 2022-06-02 02:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:39:09 --> Total execution time: 0.1658
DEBUG - 2022-06-02 02:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:39:16 --> Total execution time: 0.0462
DEBUG - 2022-06-02 02:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:39:19 --> Total execution time: 0.0390
DEBUG - 2022-06-02 02:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:39:26 --> Total execution time: 0.0294
DEBUG - 2022-06-02 02:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:39:29 --> Total execution time: 0.0316
DEBUG - 2022-06-02 02:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:09:40 --> Total execution time: 0.0322
DEBUG - 2022-06-02 02:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:09:42 --> Total execution time: 0.0266
DEBUG - 2022-06-02 02:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:39:43 --> Total execution time: 0.0755
DEBUG - 2022-06-02 02:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:39:44 --> Total execution time: 0.0580
DEBUG - 2022-06-02 02:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:39:47 --> Total execution time: 0.0277
DEBUG - 2022-06-02 02:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:09:48 --> Total execution time: 0.0255
DEBUG - 2022-06-02 02:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:39:50 --> Total execution time: 0.0401
DEBUG - 2022-06-02 02:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:39:51 --> Total execution time: 0.0310
DEBUG - 2022-06-02 02:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:39:54 --> Total execution time: 0.0893
DEBUG - 2022-06-02 02:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:39:54 --> Total execution time: 0.0550
DEBUG - 2022-06-02 02:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:39:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 02:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:39:55 --> Total execution time: 0.0281
DEBUG - 2022-06-02 02:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:40:04 --> Total execution time: 0.0604
DEBUG - 2022-06-02 02:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:40:07 --> Total execution time: 0.0371
DEBUG - 2022-06-02 02:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:40:14 --> Total execution time: 0.0476
DEBUG - 2022-06-02 02:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:40:32 --> Total execution time: 0.0288
DEBUG - 2022-06-02 02:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:40:33 --> Total execution time: 0.0319
DEBUG - 2022-06-02 02:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:40:46 --> Total execution time: 0.0774
DEBUG - 2022-06-02 02:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:41:18 --> Total execution time: 0.0713
DEBUG - 2022-06-02 02:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:41:40 --> Total execution time: 0.0693
DEBUG - 2022-06-02 02:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:41:54 --> Total execution time: 0.0493
DEBUG - 2022-06-02 02:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:42:02 --> Total execution time: 0.0418
DEBUG - 2022-06-02 02:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:42:11 --> Total execution time: 0.0453
DEBUG - 2022-06-02 02:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:42:15 --> Total execution time: 0.0323
DEBUG - 2022-06-02 02:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:42:30 --> Total execution time: 0.0347
DEBUG - 2022-06-02 02:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:44:16 --> Total execution time: 0.0499
DEBUG - 2022-06-02 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:44:43 --> Total execution time: 0.0717
DEBUG - 2022-06-02 02:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:45:02 --> Total execution time: 0.1305
DEBUG - 2022-06-02 02:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:45:13 --> Total execution time: 0.0394
DEBUG - 2022-06-02 02:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:45:20 --> Total execution time: 0.0441
DEBUG - 2022-06-02 02:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:45:20 --> Total execution time: 0.0457
DEBUG - 2022-06-02 02:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:45:20 --> Total execution time: 0.0560
DEBUG - 2022-06-02 02:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:45:20 --> Total execution time: 0.0509
DEBUG - 2022-06-02 02:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:45:54 --> Total execution time: 0.0286
DEBUG - 2022-06-02 02:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:16:20 --> No URI present. Default controller set.
DEBUG - 2022-06-02 02:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:46:20 --> Total execution time: 0.0293
DEBUG - 2022-06-02 02:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:46:30 --> Total execution time: 0.0198
DEBUG - 2022-06-02 02:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:46:42 --> Total execution time: 0.0293
DEBUG - 2022-06-02 02:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:46:51 --> Total execution time: 0.0306
DEBUG - 2022-06-02 02:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:47:01 --> Total execution time: 0.0307
DEBUG - 2022-06-02 02:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:47:06 --> Total execution time: 0.0459
DEBUG - 2022-06-02 02:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 02:18:39 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-02 02:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:51:04 --> Total execution time: 0.1028
DEBUG - 2022-06-02 02:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:27:08 --> No URI present. Default controller set.
DEBUG - 2022-06-02 02:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:57:09 --> Total execution time: 0.1426
DEBUG - 2022-06-02 02:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:27:09 --> No URI present. Default controller set.
DEBUG - 2022-06-02 02:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:57:09 --> Total execution time: 0.0268
DEBUG - 2022-06-02 02:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:27:21 --> Total execution time: 0.0250
DEBUG - 2022-06-02 02:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:27:25 --> Total execution time: 0.0398
DEBUG - 2022-06-02 02:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:27:25 --> Total execution time: 0.0581
DEBUG - 2022-06-02 02:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:27:31 --> No URI present. Default controller set.
DEBUG - 2022-06-02 02:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:57:31 --> Total execution time: 0.0314
DEBUG - 2022-06-02 02:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:57:49 --> Total execution time: 0.0396
DEBUG - 2022-06-02 02:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:57:57 --> Total execution time: 0.0471
DEBUG - 2022-06-02 02:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:58:06 --> Total execution time: 0.0483
DEBUG - 2022-06-02 02:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:58:11 --> Total execution time: 0.0325
DEBUG - 2022-06-02 02:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:58:18 --> Total execution time: 0.0345
DEBUG - 2022-06-02 02:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:58:22 --> Total execution time: 0.0387
DEBUG - 2022-06-02 02:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:58:43 --> Total execution time: 0.0732
DEBUG - 2022-06-02 02:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:59:00 --> Total execution time: 0.0338
DEBUG - 2022-06-02 02:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:59:03 --> Total execution time: 0.0406
DEBUG - 2022-06-02 02:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:59:08 --> Total execution time: 0.0316
DEBUG - 2022-06-02 02:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:59:11 --> Total execution time: 0.0411
DEBUG - 2022-06-02 02:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:59:18 --> Total execution time: 0.0486
DEBUG - 2022-06-02 02:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:59:48 --> Total execution time: 0.0320
DEBUG - 2022-06-02 02:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:59:53 --> Total execution time: 0.0351
DEBUG - 2022-06-02 02:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:59:58 --> Total execution time: 0.0634
DEBUG - 2022-06-02 02:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:59:58 --> Total execution time: 0.0371
DEBUG - 2022-06-02 02:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:00:00 --> Total execution time: 0.0342
DEBUG - 2022-06-02 02:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:00:24 --> Total execution time: 0.0286
DEBUG - 2022-06-02 02:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:00:28 --> Total execution time: 0.0250
DEBUG - 2022-06-02 02:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:00:31 --> Total execution time: 0.0231
DEBUG - 2022-06-02 02:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:00:41 --> Total execution time: 0.0449
DEBUG - 2022-06-02 02:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:00:48 --> Total execution time: 0.0917
DEBUG - 2022-06-02 02:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:00:54 --> Total execution time: 0.0250
DEBUG - 2022-06-02 02:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:02:01 --> Total execution time: 0.0250
DEBUG - 2022-06-02 02:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:02:11 --> Total execution time: 0.0288
DEBUG - 2022-06-02 02:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:02:25 --> Total execution time: 0.0314
DEBUG - 2022-06-02 02:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:03:02 --> Total execution time: 0.0815
DEBUG - 2022-06-02 02:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:04:44 --> Total execution time: 0.0296
DEBUG - 2022-06-02 02:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:05:39 --> Total execution time: 0.0699
DEBUG - 2022-06-02 02:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:06:08 --> Total execution time: 0.1717
DEBUG - 2022-06-02 02:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:06:29 --> Total execution time: 0.0878
DEBUG - 2022-06-02 02:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:06:33 --> Total execution time: 0.0413
DEBUG - 2022-06-02 02:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:16:06 --> Total execution time: 0.0231
DEBUG - 2022-06-02 02:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:46:33 --> No URI present. Default controller set.
DEBUG - 2022-06-02 02:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:16:33 --> Total execution time: 0.0310
DEBUG - 2022-06-02 02:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:47:43 --> No URI present. Default controller set.
DEBUG - 2022-06-02 02:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:17:43 --> Total execution time: 0.0272
DEBUG - 2022-06-02 02:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:47:43 --> No URI present. Default controller set.
DEBUG - 2022-06-02 02:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:17:43 --> Total execution time: 0.0291
DEBUG - 2022-06-02 02:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:48:29 --> Total execution time: 0.0287
DEBUG - 2022-06-02 02:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:48:37 --> No URI present. Default controller set.
DEBUG - 2022-06-02 02:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:18:37 --> Total execution time: 0.0235
DEBUG - 2022-06-02 02:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:18:45 --> Total execution time: 0.0319
DEBUG - 2022-06-02 02:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:49:09 --> No URI present. Default controller set.
DEBUG - 2022-06-02 02:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:19:09 --> Total execution time: 0.0309
DEBUG - 2022-06-02 02:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:19:36 --> Total execution time: 0.0785
DEBUG - 2022-06-02 02:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:52:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 02:52:59 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 02:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:53:20 --> No URI present. Default controller set.
DEBUG - 2022-06-02 02:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:23:20 --> Total execution time: 0.0803
DEBUG - 2022-06-02 02:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:53:23 --> No URI present. Default controller set.
DEBUG - 2022-06-02 02:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:23:23 --> Total execution time: 0.0284
DEBUG - 2022-06-02 02:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:25:38 --> Total execution time: 0.0285
DEBUG - 2022-06-02 02:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:57:16 --> No URI present. Default controller set.
DEBUG - 2022-06-02 02:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:27:16 --> Total execution time: 0.0250
DEBUG - 2022-06-02 02:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:27:24 --> Total execution time: 0.0306
DEBUG - 2022-06-02 02:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 02:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:27:32 --> Total execution time: 0.0449
DEBUG - 2022-06-02 02:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:27:41 --> Total execution time: 0.0446
DEBUG - 2022-06-02 02:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:27:43 --> Total execution time: 0.0332
DEBUG - 2022-06-02 02:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 02:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 02:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:27:52 --> Total execution time: 0.0347
DEBUG - 2022-06-02 03:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:00:01 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:30:01 --> Total execution time: 0.1332
DEBUG - 2022-06-02 03:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:30:01 --> Total execution time: 0.0450
DEBUG - 2022-06-02 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:30:02 --> Total execution time: 0.0848
DEBUG - 2022-06-02 03:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:02:37 --> Total execution time: 0.0612
DEBUG - 2022-06-02 03:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:02:39 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:32:39 --> Total execution time: 0.0218
DEBUG - 2022-06-02 03:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:05:12 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:35:12 --> Total execution time: 0.0300
DEBUG - 2022-06-02 03:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:06:01 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:36:01 --> Total execution time: 0.0287
DEBUG - 2022-06-02 03:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:06:40 --> Total execution time: 0.0304
DEBUG - 2022-06-02 03:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:06:42 --> Total execution time: 0.0282
DEBUG - 2022-06-02 03:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:06:42 --> Total execution time: 0.0550
DEBUG - 2022-06-02 03:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:07:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 03:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:37:30 --> Total execution time: 1.5303
DEBUG - 2022-06-02 03:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:07:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 03:07:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:08:35 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:38:35 --> Total execution time: 0.0534
DEBUG - 2022-06-02 03:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:08:54 --> Total execution time: 0.0551
DEBUG - 2022-06-02 03:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:08:57 --> Total execution time: 0.0604
DEBUG - 2022-06-02 03:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:08:57 --> Total execution time: 0.1127
DEBUG - 2022-06-02 03:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:09:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 03:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:39:54 --> Total execution time: 1.5498
DEBUG - 2022-06-02 03:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:39:54 --> Total execution time: 0.0464
DEBUG - 2022-06-02 03:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:40:07 --> Total execution time: 0.0559
DEBUG - 2022-06-02 03:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:40:30 --> Total execution time: 0.0828
DEBUG - 2022-06-02 03:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:40:35 --> Total execution time: 0.0393
DEBUG - 2022-06-02 03:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:40:46 --> Total execution time: 0.0292
DEBUG - 2022-06-02 03:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:43:23 --> Total execution time: 0.0542
DEBUG - 2022-06-02 03:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:43:44 --> Total execution time: 0.0410
DEBUG - 2022-06-02 03:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:43:58 --> Total execution time: 0.0408
DEBUG - 2022-06-02 03:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:45:09 --> Total execution time: 0.0287
DEBUG - 2022-06-02 03:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:15:47 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:45:47 --> Total execution time: 0.0224
DEBUG - 2022-06-02 03:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:15:47 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:45:47 --> Total execution time: 0.0218
DEBUG - 2022-06-02 03:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:45:49 --> Total execution time: 0.0327
DEBUG - 2022-06-02 03:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:45:53 --> Total execution time: 0.0191
DEBUG - 2022-06-02 03:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:16:05 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:46:05 --> Total execution time: 0.0422
DEBUG - 2022-06-02 03:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:46:08 --> Total execution time: 0.0416
DEBUG - 2022-06-02 03:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:46:11 --> Total execution time: 0.0412
DEBUG - 2022-06-02 03:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:46:19 --> Total execution time: 0.0376
DEBUG - 2022-06-02 03:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:46:25 --> Total execution time: 0.0257
DEBUG - 2022-06-02 03:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:46:44 --> Total execution time: 0.0873
DEBUG - 2022-06-02 03:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:17:07 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:47:07 --> Total execution time: 0.0290
DEBUG - 2022-06-02 03:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:48:54 --> Total execution time: 0.0246
DEBUG - 2022-06-02 03:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:49:54 --> Total execution time: 0.0345
DEBUG - 2022-06-02 03:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:20:21 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:50:21 --> Total execution time: 0.0661
DEBUG - 2022-06-02 03:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:23:01 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:53:01 --> Total execution time: 0.1762
DEBUG - 2022-06-02 03:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:23:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 03:23:02 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-02 03:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:53:11 --> Total execution time: 0.0260
DEBUG - 2022-06-02 03:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:53:28 --> Total execution time: 0.0350
DEBUG - 2022-06-02 03:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:53:34 --> Total execution time: 0.0512
DEBUG - 2022-06-02 03:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:53:45 --> Total execution time: 0.0704
DEBUG - 2022-06-02 03:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:54:32 --> Total execution time: 0.0711
DEBUG - 2022-06-02 03:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:25:01 --> Total execution time: 0.0598
DEBUG - 2022-06-02 03:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:25:12 --> Total execution time: 0.1039
DEBUG - 2022-06-02 03:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:55:31 --> Total execution time: 0.0707
DEBUG - 2022-06-02 03:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:55:39 --> Total execution time: 0.0272
DEBUG - 2022-06-02 03:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:55:42 --> Total execution time: 0.0254
DEBUG - 2022-06-02 03:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:56:18 --> Total execution time: 0.0252
DEBUG - 2022-06-02 03:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:56:58 --> Total execution time: 0.0302
DEBUG - 2022-06-02 03:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:57:11 --> Total execution time: 0.0229
DEBUG - 2022-06-02 03:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:57:22 --> Total execution time: 0.0535
DEBUG - 2022-06-02 03:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:27:39 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:57:39 --> Total execution time: 0.0737
DEBUG - 2022-06-02 03:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:27:39 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:57:39 --> Total execution time: 0.0272
DEBUG - 2022-06-02 03:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:57:43 --> Total execution time: 0.0402
DEBUG - 2022-06-02 03:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:57:48 --> Total execution time: 0.0289
DEBUG - 2022-06-02 03:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:58:04 --> Total execution time: 0.1038
DEBUG - 2022-06-02 03:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:58:09 --> Total execution time: 0.0355
DEBUG - 2022-06-02 03:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:58:13 --> Total execution time: 0.0796
DEBUG - 2022-06-02 03:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:58:13 --> Total execution time: 0.0386
DEBUG - 2022-06-02 03:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:58:24 --> Total execution time: 0.0530
DEBUG - 2022-06-02 03:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:58:26 --> Total execution time: 0.0601
DEBUG - 2022-06-02 03:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:58:32 --> Total execution time: 0.0283
DEBUG - 2022-06-02 03:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:58:37 --> Total execution time: 0.0447
DEBUG - 2022-06-02 03:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:59:02 --> Total execution time: 0.0392
DEBUG - 2022-06-02 03:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:59:28 --> Total execution time: 0.0212
DEBUG - 2022-06-02 03:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:29:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 03:29:30 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-02 03:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:59:33 --> Total execution time: 0.0739
DEBUG - 2022-06-02 03:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:59:37 --> Total execution time: 0.0202
DEBUG - 2022-06-02 03:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:59:40 --> Total execution time: 0.0513
DEBUG - 2022-06-02 03:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:29:44 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:59:44 --> Total execution time: 0.0391
DEBUG - 2022-06-02 03:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:59:57 --> Total execution time: 0.0279
DEBUG - 2022-06-02 03:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:00:04 --> Total execution time: 0.0801
DEBUG - 2022-06-02 03:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:00:08 --> Total execution time: 0.0450
DEBUG - 2022-06-02 03:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:00:21 --> Total execution time: 0.0261
DEBUG - 2022-06-02 03:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:00:28 --> Total execution time: 0.0353
DEBUG - 2022-06-02 03:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:30:57 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:00:57 --> Total execution time: 0.0222
DEBUG - 2022-06-02 03:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:31:06 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:01:06 --> Total execution time: 0.0229
DEBUG - 2022-06-02 03:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:31:15 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:01:15 --> Total execution time: 0.0280
DEBUG - 2022-06-02 03:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:31:22 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:01:22 --> Total execution time: 0.0324
DEBUG - 2022-06-02 03:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:01:24 --> Total execution time: 0.0280
DEBUG - 2022-06-02 03:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:31:30 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:01:30 --> Total execution time: 0.0213
DEBUG - 2022-06-02 03:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:31:31 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:01:31 --> Total execution time: 0.0316
DEBUG - 2022-06-02 03:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:31:34 --> Total execution time: 0.0209
DEBUG - 2022-06-02 03:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:31:35 --> Total execution time: 0.0230
DEBUG - 2022-06-02 03:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:31:35 --> Total execution time: 0.0339
DEBUG - 2022-06-02 03:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:31:40 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:01:40 --> Total execution time: 0.0231
DEBUG - 2022-06-02 03:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:31:41 --> Total execution time: 0.0275
DEBUG - 2022-06-02 03:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:31:43 --> Total execution time: 0.0231
DEBUG - 2022-06-02 03:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:31:43 --> Total execution time: 0.0371
DEBUG - 2022-06-02 03:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:32:38 --> Total execution time: 0.0575
DEBUG - 2022-06-02 03:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:32:39 --> Total execution time: 0.0330
DEBUG - 2022-06-02 03:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:32:39 --> Total execution time: 0.0621
DEBUG - 2022-06-02 03:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:33:18 --> Total execution time: 0.0349
DEBUG - 2022-06-02 03:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:33:20 --> Total execution time: 0.0299
DEBUG - 2022-06-02 03:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:33:20 --> Total execution time: 0.0294
DEBUG - 2022-06-02 03:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:03:30 --> Total execution time: 0.0285
DEBUG - 2022-06-02 03:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:03:41 --> Total execution time: 0.0331
DEBUG - 2022-06-02 03:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:03:48 --> Total execution time: 0.0626
DEBUG - 2022-06-02 03:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:03:58 --> Total execution time: 0.0389
DEBUG - 2022-06-02 03:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:10:30 --> Total execution time: 0.1259
DEBUG - 2022-06-02 03:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:11:01 --> Total execution time: 0.0357
DEBUG - 2022-06-02 03:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:11:14 --> Total execution time: 0.0325
DEBUG - 2022-06-02 03:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:11:28 --> Total execution time: 0.0415
DEBUG - 2022-06-02 03:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:11:48 --> Total execution time: 0.0344
DEBUG - 2022-06-02 03:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:13:06 --> Total execution time: 0.0296
DEBUG - 2022-06-02 03:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:43:11 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:13:11 --> Total execution time: 0.0299
DEBUG - 2022-06-02 03:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:13:37 --> Total execution time: 0.0276
DEBUG - 2022-06-02 03:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:14:11 --> Total execution time: 0.0309
DEBUG - 2022-06-02 03:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:53 --> Total execution time: 0.0668
DEBUG - 2022-06-02 03:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:50:08 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:20:08 --> Total execution time: 0.0291
DEBUG - 2022-06-02 03:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:20:16 --> Total execution time: 0.0543
DEBUG - 2022-06-02 03:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:20:18 --> Total execution time: 0.0361
DEBUG - 2022-06-02 03:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:20:19 --> Total execution time: 0.0420
DEBUG - 2022-06-02 03:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:20:39 --> Total execution time: 0.0463
DEBUG - 2022-06-02 03:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:50:57 --> Total execution time: 0.0289
DEBUG - 2022-06-02 03:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:21:00 --> Total execution time: 0.0379
DEBUG - 2022-06-02 03:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:21:14 --> Total execution time: 0.0328
DEBUG - 2022-06-02 03:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:52:43 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:22:43 --> Total execution time: 0.0251
DEBUG - 2022-06-02 03:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:52:58 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:22:58 --> Total execution time: 0.0322
DEBUG - 2022-06-02 03:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:27:15 --> Total execution time: 0.1056
DEBUG - 2022-06-02 03:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:57:34 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:27:34 --> Total execution time: 0.0257
DEBUG - 2022-06-02 03:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:57:37 --> Total execution time: 0.0355
DEBUG - 2022-06-02 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:57:39 --> Total execution time: 0.0458
DEBUG - 2022-06-02 03:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:57:39 --> Total execution time: 0.0720
DEBUG - 2022-06-02 03:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:58:20 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:28:20 --> Total execution time: 0.0658
DEBUG - 2022-06-02 03:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:58:27 --> No URI present. Default controller set.
DEBUG - 2022-06-02 03:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:28:27 --> Total execution time: 0.0543
DEBUG - 2022-06-02 03:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 03:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 03:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 03:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:29:32 --> Total execution time: 0.0350
DEBUG - 2022-06-02 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:30:02 --> Total execution time: 0.0545
DEBUG - 2022-06-02 04:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:00:24 --> No URI present. Default controller set.
DEBUG - 2022-06-02 04:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:30:24 --> Total execution time: 0.0357
DEBUG - 2022-06-02 04:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:00:27 --> No URI present. Default controller set.
DEBUG - 2022-06-02 04:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:30:27 --> Total execution time: 0.0373
DEBUG - 2022-06-02 04:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:30:43 --> Total execution time: 0.0417
DEBUG - 2022-06-02 04:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:30:49 --> Total execution time: 0.0345
DEBUG - 2022-06-02 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:34:19 --> Total execution time: 0.1247
DEBUG - 2022-06-02 04:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:35:19 --> Total execution time: 0.0305
DEBUG - 2022-06-02 04:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 04:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:35:29 --> Total execution time: 0.0275
DEBUG - 2022-06-02 04:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 04:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:35:43 --> Total execution time: 0.0263
DEBUG - 2022-06-02 04:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 04:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:35:57 --> Total execution time: 0.0319
DEBUG - 2022-06-02 04:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:36:10 --> Total execution time: 0.0295
DEBUG - 2022-06-02 04:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:36:33 --> Total execution time: 0.0305
DEBUG - 2022-06-02 04:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:36:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 04:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:36:34 --> Total execution time: 0.0271
DEBUG - 2022-06-02 04:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:41:27 --> Total execution time: 0.0910
DEBUG - 2022-06-02 04:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 04:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:41:44 --> Total execution time: 0.0434
DEBUG - 2022-06-02 04:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:41:58 --> Total execution time: 0.0334
DEBUG - 2022-06-02 04:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:42:36 --> Total execution time: 0.0516
DEBUG - 2022-06-02 04:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:42:39 --> Total execution time: 0.0444
DEBUG - 2022-06-02 04:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:42:48 --> Total execution time: 0.0519
DEBUG - 2022-06-02 04:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:42:52 --> Total execution time: 0.0376
DEBUG - 2022-06-02 04:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:43:02 --> Total execution time: 0.0309
DEBUG - 2022-06-02 04:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 04:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:43:17 --> Total execution time: 0.0279
DEBUG - 2022-06-02 04:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 04:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:43:39 --> Total execution time: 0.0398
DEBUG - 2022-06-02 04:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:43:53 --> Total execution time: 0.0363
DEBUG - 2022-06-02 04:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:43:58 --> Total execution time: 0.0410
DEBUG - 2022-06-02 04:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:44:25 --> Total execution time: 0.0415
DEBUG - 2022-06-02 04:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:44:26 --> Total execution time: 0.0458
DEBUG - 2022-06-02 04:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:14:42 --> No URI present. Default controller set.
DEBUG - 2022-06-02 04:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:44:42 --> Total execution time: 0.0314
DEBUG - 2022-06-02 04:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 04:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:48:40 --> Total execution time: 0.0295
DEBUG - 2022-06-02 04:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:51:27 --> Total execution time: 0.0767
DEBUG - 2022-06-02 04:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:52:11 --> Total execution time: 0.0698
DEBUG - 2022-06-02 04:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:22:26 --> No URI present. Default controller set.
DEBUG - 2022-06-02 04:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:52:26 --> Total execution time: 0.0236
DEBUG - 2022-06-02 04:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:52:28 --> Total execution time: 0.1099
DEBUG - 2022-06-02 04:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:52:33 --> Total execution time: 0.0443
DEBUG - 2022-06-02 04:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:52:38 --> Total execution time: 0.0260
DEBUG - 2022-06-02 04:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 04:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:52:51 --> Total execution time: 0.0249
DEBUG - 2022-06-02 04:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:53:00 --> Total execution time: 0.0290
DEBUG - 2022-06-02 04:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 04:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:53:09 --> Total execution time: 0.0297
DEBUG - 2022-06-02 04:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:23:30 --> No URI present. Default controller set.
DEBUG - 2022-06-02 04:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:53:30 --> Total execution time: 0.0390
DEBUG - 2022-06-02 04:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:53:33 --> Total execution time: 0.0330
DEBUG - 2022-06-02 04:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:53:33 --> Total execution time: 0.0504
DEBUG - 2022-06-02 04:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:53:36 --> Total execution time: 0.0448
DEBUG - 2022-06-02 04:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:53:49 --> Total execution time: 0.0521
DEBUG - 2022-06-02 04:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:53:54 --> Total execution time: 0.0459
DEBUG - 2022-06-02 04:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:54:17 --> Total execution time: 0.0235
DEBUG - 2022-06-02 04:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:54:21 --> Total execution time: 0.0514
DEBUG - 2022-06-02 04:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:24:42 --> No URI present. Default controller set.
DEBUG - 2022-06-02 04:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:54:42 --> Total execution time: 0.0226
DEBUG - 2022-06-02 04:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:24:46 --> No URI present. Default controller set.
DEBUG - 2022-06-02 04:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:54:46 --> Total execution time: 0.0363
DEBUG - 2022-06-02 04:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:54:53 --> Total execution time: 1.5283
DEBUG - 2022-06-02 04:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 04:24:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 04:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:54:57 --> Total execution time: 0.0603
DEBUG - 2022-06-02 04:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:55:03 --> Total execution time: 0.0481
DEBUG - 2022-06-02 04:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:55:03 --> Total execution time: 0.0317
DEBUG - 2022-06-02 04:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:55:06 --> Total execution time: 0.0315
DEBUG - 2022-06-02 04:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:55:11 --> Total execution time: 0.0433
DEBUG - 2022-06-02 04:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:55:13 --> Total execution time: 0.0287
DEBUG - 2022-06-02 04:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:55:15 --> Total execution time: 0.0422
DEBUG - 2022-06-02 04:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:55:18 --> Total execution time: 0.0391
DEBUG - 2022-06-02 04:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:25:28 --> No URI present. Default controller set.
DEBUG - 2022-06-02 04:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:55:28 --> Total execution time: 0.0384
DEBUG - 2022-06-02 04:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:55:38 --> Total execution time: 0.0544
DEBUG - 2022-06-02 04:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:55:59 --> Total execution time: 0.0584
DEBUG - 2022-06-02 04:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:56:56 --> Total execution time: 0.0554
DEBUG - 2022-06-02 04:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:57:11 --> Total execution time: 0.0504
DEBUG - 2022-06-02 04:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:58:34 --> Total execution time: 0.0311
DEBUG - 2022-06-02 04:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:58:38 --> Total execution time: 0.0330
DEBUG - 2022-06-02 04:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:59:02 --> Total execution time: 0.0670
DEBUG - 2022-06-02 04:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:31:54 --> No URI present. Default controller set.
DEBUG - 2022-06-02 04:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:01:54 --> Total execution time: 0.1143
DEBUG - 2022-06-02 04:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:02:06 --> Total execution time: 3.5724
DEBUG - 2022-06-02 04:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:32:30 --> No URI present. Default controller set.
DEBUG - 2022-06-02 04:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:02:30 --> Total execution time: 0.0299
DEBUG - 2022-06-02 04:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:02:33 --> Total execution time: 1.4694
DEBUG - 2022-06-02 04:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:04:51 --> Total execution time: 1.6074
DEBUG - 2022-06-02 04:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:34:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 04:34:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 04:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:05:00 --> Total execution time: 0.0615
DEBUG - 2022-06-02 04:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:35:11 --> No URI present. Default controller set.
DEBUG - 2022-06-02 04:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:05:11 --> Total execution time: 0.0298
DEBUG - 2022-06-02 04:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:05:15 --> Total execution time: 0.0432
DEBUG - 2022-06-02 04:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:35:52 --> No URI present. Default controller set.
DEBUG - 2022-06-02 04:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:05:52 --> Total execution time: 0.0274
DEBUG - 2022-06-02 04:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 04:36:17 --> Total execution time: 0.0391
DEBUG - 2022-06-02 04:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 04:36:19 --> Total execution time: 0.0312
DEBUG - 2022-06-02 04:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 04:36:19 --> Total execution time: 0.0281
DEBUG - 2022-06-02 04:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 04:40:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 04:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:10:56 --> Total execution time: 1.5400
DEBUG - 2022-06-02 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:12:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 04:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:12:45 --> Total execution time: 0.0360
DEBUG - 2022-06-02 04:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:12:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 15:12:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 15:12:46 --> Total execution time: 0.1792
DEBUG - 2022-06-02 04:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:47:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 04:47:02 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 04:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:52:37 --> No URI present. Default controller set.
DEBUG - 2022-06-02 04:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:22:37 --> Total execution time: 0.0887
DEBUG - 2022-06-02 04:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:22:40 --> Total execution time: 0.0424
DEBUG - 2022-06-02 04:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 04:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:22:45 --> Total execution time: 0.0430
DEBUG - 2022-06-02 04:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 04:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:22:49 --> Total execution time: 0.0541
DEBUG - 2022-06-02 04:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 04:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 04:59:58 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:30:02 --> Total execution time: 0.3174
DEBUG - 2022-06-02 05:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:34:16 --> Total execution time: 0.0834
DEBUG - 2022-06-02 05:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:07:44 --> No URI present. Default controller set.
DEBUG - 2022-06-02 05:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:37:44 --> Total execution time: 0.1140
DEBUG - 2022-06-02 05:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:08:18 --> No URI present. Default controller set.
DEBUG - 2022-06-02 05:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:38:18 --> Total execution time: 0.0679
DEBUG - 2022-06-02 05:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:18:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 05:18:32 --> 404 Page Not Found: Event/esalestrix.in
DEBUG - 2022-06-02 05:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:27:07 --> No URI present. Default controller set.
DEBUG - 2022-06-02 05:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:57:07 --> Total execution time: 0.1253
DEBUG - 2022-06-02 05:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 05:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:00:07 --> Total execution time: 0.0333
DEBUG - 2022-06-02 05:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 05:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:00:29 --> Total execution time: 0.0557
DEBUG - 2022-06-02 05:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:00:34 --> Total execution time: 0.0524
DEBUG - 2022-06-02 05:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:00:47 --> Total execution time: 0.0411
DEBUG - 2022-06-02 05:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:01:49 --> Total execution time: 0.0310
DEBUG - 2022-06-02 05:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:01:59 --> Total execution time: 0.0316
DEBUG - 2022-06-02 05:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:02:03 --> Total execution time: 0.0356
DEBUG - 2022-06-02 05:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:02:09 --> Total execution time: 0.0485
DEBUG - 2022-06-02 05:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:02:23 --> Total execution time: 0.0316
DEBUG - 2022-06-02 05:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:02:25 --> Total execution time: 0.0330
DEBUG - 2022-06-02 05:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:02:27 --> Total execution time: 0.0433
DEBUG - 2022-06-02 05:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:32:47 --> No URI present. Default controller set.
DEBUG - 2022-06-02 05:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:02:47 --> Total execution time: 0.0249
DEBUG - 2022-06-02 05:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:02:50 --> Total execution time: 0.0390
DEBUG - 2022-06-02 05:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:03:00 --> Total execution time: 0.0598
DEBUG - 2022-06-02 05:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:03:01 --> Total execution time: 0.1870
DEBUG - 2022-06-02 05:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:03:06 --> Total execution time: 0.0304
DEBUG - 2022-06-02 05:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:34:01 --> No URI present. Default controller set.
DEBUG - 2022-06-02 05:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:04:01 --> Total execution time: 0.0525
DEBUG - 2022-06-02 05:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:34:02 --> No URI present. Default controller set.
DEBUG - 2022-06-02 05:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:04:02 --> Total execution time: 0.0370
DEBUG - 2022-06-02 05:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:34:02 --> No URI present. Default controller set.
DEBUG - 2022-06-02 05:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:04:02 --> Total execution time: 0.0293
DEBUG - 2022-06-02 05:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:04:55 --> Total execution time: 0.0385
DEBUG - 2022-06-02 05:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:04:59 --> Total execution time: 0.0488
DEBUG - 2022-06-02 05:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:35:07 --> No URI present. Default controller set.
DEBUG - 2022-06-02 05:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:05:07 --> Total execution time: 0.0233
DEBUG - 2022-06-02 05:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 05:35:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 05:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:35:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 05:35:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 05:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:06:11 --> Total execution time: 0.0375
DEBUG - 2022-06-02 05:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 05:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:06:15 --> Total execution time: 0.0259
DEBUG - 2022-06-02 05:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:06:17 --> Total execution time: 0.0384
DEBUG - 2022-06-02 05:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:06:19 --> Total execution time: 0.0447
DEBUG - 2022-06-02 05:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:06:24 --> Total execution time: 0.0365
DEBUG - 2022-06-02 05:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:40:21 --> No URI present. Default controller set.
DEBUG - 2022-06-02 05:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:10:21 --> Total execution time: 0.1054
DEBUG - 2022-06-02 05:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:10:32 --> Total execution time: 0.0323
DEBUG - 2022-06-02 05:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:40:34 --> No URI present. Default controller set.
DEBUG - 2022-06-02 05:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:10:34 --> Total execution time: 0.0341
DEBUG - 2022-06-02 05:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:40:59 --> No URI present. Default controller set.
DEBUG - 2022-06-02 05:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:10:59 --> Total execution time: 0.0520
DEBUG - 2022-06-02 05:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 05:41:14 --> Total execution time: 0.0296
DEBUG - 2022-06-02 05:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 05:41:15 --> Total execution time: 0.0238
DEBUG - 2022-06-02 05:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 05:41:15 --> Total execution time: 0.0506
DEBUG - 2022-06-02 05:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:41:25 --> No URI present. Default controller set.
DEBUG - 2022-06-02 05:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:11:25 --> Total execution time: 0.0282
DEBUG - 2022-06-02 05:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 05:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:11:26 --> Total execution time: 0.0315
DEBUG - 2022-06-02 05:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:41:26 --> No URI present. Default controller set.
DEBUG - 2022-06-02 05:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:11:26 --> Total execution time: 0.0414
DEBUG - 2022-06-02 05:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:11:36 --> Total execution time: 0.0416
DEBUG - 2022-06-02 05:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:11:41 --> Total execution time: 0.0326
DEBUG - 2022-06-02 05:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:11:55 --> Total execution time: 0.0410
DEBUG - 2022-06-02 05:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:12:24 --> Total execution time: 0.0275
DEBUG - 2022-06-02 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:12:34 --> Total execution time: 0.0272
DEBUG - 2022-06-02 05:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:12:42 --> Total execution time: 0.0303
DEBUG - 2022-06-02 05:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:12:55 --> Total execution time: 0.0316
DEBUG - 2022-06-02 05:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:13:28 --> Total execution time: 0.0759
DEBUG - 2022-06-02 05:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:13:43 --> Total execution time: 0.0956
DEBUG - 2022-06-02 05:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:13:48 --> Total execution time: 0.0378
DEBUG - 2022-06-02 05:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:14:28 --> Total execution time: 0.0314
DEBUG - 2022-06-02 05:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:17:46 --> Total execution time: 0.1198
DEBUG - 2022-06-02 05:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 05:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 05:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:22:24 --> Total execution time: 0.1454
DEBUG - 2022-06-02 06:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:30:03 --> Total execution time: 0.3134
DEBUG - 2022-06-02 06:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:31:16 --> Total execution time: 0.0321
DEBUG - 2022-06-02 06:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:31:36 --> Total execution time: 0.0292
DEBUG - 2022-06-02 06:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:31:43 --> Total execution time: 0.0346
DEBUG - 2022-06-02 06:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:34:59 --> Total execution time: 0.1218
DEBUG - 2022-06-02 06:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:37:21 --> Total execution time: 0.0458
DEBUG - 2022-06-02 06:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:07:28 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:37:28 --> Total execution time: 0.0586
DEBUG - 2022-06-02 06:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:40:10 --> Total execution time: 0.0939
DEBUG - 2022-06-02 06:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:12:13 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:42:14 --> Total execution time: 0.0919
DEBUG - 2022-06-02 06:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:42:19 --> Total execution time: 0.0359
DEBUG - 2022-06-02 06:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:42:51 --> Total execution time: 0.0747
DEBUG - 2022-06-02 06:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:42:57 --> Total execution time: 0.0507
DEBUG - 2022-06-02 06:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:43:15 --> Total execution time: 0.1003
DEBUG - 2022-06-02 06:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:43:28 --> Total execution time: 0.0284
DEBUG - 2022-06-02 06:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:43:50 --> Total execution time: 0.0297
DEBUG - 2022-06-02 06:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:15:29 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:45:30 --> Total execution time: 0.0462
DEBUG - 2022-06-02 06:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:15:30 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:45:30 --> Total execution time: 0.0242
DEBUG - 2022-06-02 06:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:45:39 --> Total execution time: 0.0206
DEBUG - 2022-06-02 06:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:45:54 --> Total execution time: 0.0296
DEBUG - 2022-06-02 06:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:45:58 --> Total execution time: 0.0376
DEBUG - 2022-06-02 06:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:48:15 --> Total execution time: 0.0322
DEBUG - 2022-06-02 06:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:18:23 --> Total execution time: 0.0265
DEBUG - 2022-06-02 06:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:48:28 --> Total execution time: 0.0309
DEBUG - 2022-06-02 06:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:18:32 --> Total execution time: 0.0272
DEBUG - 2022-06-02 06:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:48:34 --> Total execution time: 0.0379
DEBUG - 2022-06-02 06:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:48:38 --> Total execution time: 0.0539
DEBUG - 2022-06-02 06:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:18:52 --> Total execution time: 0.0258
DEBUG - 2022-06-02 06:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:19:03 --> Total execution time: 0.0508
DEBUG - 2022-06-02 06:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:19:09 --> Total execution time: 0.0384
DEBUG - 2022-06-02 06:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:49:11 --> Total execution time: 0.0700
DEBUG - 2022-06-02 06:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:49:16 --> Total execution time: 0.0376
DEBUG - 2022-06-02 06:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:49:27 --> Total execution time: 0.0573
DEBUG - 2022-06-02 06:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:19:42 --> Total execution time: 0.0230
DEBUG - 2022-06-02 06:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:49:45 --> Total execution time: 0.1052
DEBUG - 2022-06-02 06:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:49:48 --> Total execution time: 0.0366
DEBUG - 2022-06-02 06:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:49:53 --> Total execution time: 0.0416
DEBUG - 2022-06-02 06:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:50:04 --> Total execution time: 0.0380
DEBUG - 2022-06-02 06:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:20:11 --> Total execution time: 0.0250
DEBUG - 2022-06-02 06:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:50:13 --> Total execution time: 0.0327
DEBUG - 2022-06-02 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:50:24 --> Total execution time: 0.1605
DEBUG - 2022-06-02 06:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:20:48 --> Total execution time: 0.0334
DEBUG - 2022-06-02 06:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:20:57 --> Total execution time: 0.0249
DEBUG - 2022-06-02 06:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:20:59 --> Total execution time: 0.0410
DEBUG - 2022-06-02 06:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:51:01 --> Total execution time: 0.1823
DEBUG - 2022-06-02 06:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:21:11 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:51:11 --> Total execution time: 0.0278
DEBUG - 2022-06-02 06:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:51:18 --> Total execution time: 0.1419
DEBUG - 2022-06-02 06:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:51:19 --> Total execution time: 0.0280
DEBUG - 2022-06-02 06:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:51:45 --> Total execution time: 0.0452
DEBUG - 2022-06-02 06:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:51:48 --> Total execution time: 0.0297
DEBUG - 2022-06-02 06:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:51:52 --> Total execution time: 0.0308
DEBUG - 2022-06-02 06:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:51:55 --> Total execution time: 0.0347
DEBUG - 2022-06-02 06:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:52:00 --> Total execution time: 0.0319
DEBUG - 2022-06-02 06:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:22:06 --> Total execution time: 0.0480
DEBUG - 2022-06-02 06:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:22:06 --> Total execution time: 0.0265
DEBUG - 2022-06-02 06:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:22:15 --> Total execution time: 0.0259
DEBUG - 2022-06-02 06:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:52:18 --> Total execution time: 0.0288
DEBUG - 2022-06-02 06:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:52:27 --> Total execution time: 0.0311
DEBUG - 2022-06-02 06:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:52:35 --> Total execution time: 0.0360
DEBUG - 2022-06-02 06:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:52:37 --> Total execution time: 0.0385
DEBUG - 2022-06-02 06:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:22:37 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:52:37 --> Total execution time: 0.0454
DEBUG - 2022-06-02 06:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:52:38 --> Total execution time: 0.0400
DEBUG - 2022-06-02 06:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:53:15 --> Total execution time: 0.0531
DEBUG - 2022-06-02 06:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:53:39 --> Total execution time: 0.0303
DEBUG - 2022-06-02 06:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:53:56 --> Total execution time: 0.0673
DEBUG - 2022-06-02 06:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:26:18 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:56:18 --> Total execution time: 0.0745
DEBUG - 2022-06-02 06:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:56:37 --> Total execution time: 0.0358
DEBUG - 2022-06-02 06:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:05:52 --> Total execution time: 0.4112
DEBUG - 2022-06-02 06:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:06:01 --> Total execution time: 0.0480
DEBUG - 2022-06-02 06:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:36:27 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:06:27 --> Total execution time: 0.0469
DEBUG - 2022-06-02 06:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:36:28 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:06:28 --> Total execution time: 0.0490
DEBUG - 2022-06-02 06:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:06:35 --> Total execution time: 0.0232
DEBUG - 2022-06-02 06:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:06:44 --> Total execution time: 0.0453
DEBUG - 2022-06-02 06:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:06:53 --> Total execution time: 0.1653
DEBUG - 2022-06-02 06:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:37:16 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:07:16 --> Total execution time: 0.0294
DEBUG - 2022-06-02 06:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:07:26 --> Total execution time: 1.5274
DEBUG - 2022-06-02 06:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:37:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 06:37:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 06:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:08:13 --> Total execution time: 0.0256
DEBUG - 2022-06-02 06:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:12:46 --> Total execution time: 0.1032
DEBUG - 2022-06-02 06:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:42:52 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:12:52 --> Total execution time: 0.0238
DEBUG - 2022-06-02 06:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:42:53 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:12:53 --> Total execution time: 0.0227
DEBUG - 2022-06-02 06:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:13:20 --> Total execution time: 0.0196
DEBUG - 2022-06-02 06:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:43:22 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:13:22 --> Total execution time: 0.0390
DEBUG - 2022-06-02 06:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:43:25 --> Total execution time: 0.0332
DEBUG - 2022-06-02 06:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:43:26 --> Total execution time: 0.0285
DEBUG - 2022-06-02 06:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:43:26 --> Total execution time: 0.0381
DEBUG - 2022-06-02 06:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:14:20 --> Total execution time: 0.0211
DEBUG - 2022-06-02 06:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:14:38 --> Total execution time: 0.0376
DEBUG - 2022-06-02 06:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:14:43 --> Total execution time: 0.0736
DEBUG - 2022-06-02 06:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:45:28 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:15:28 --> Total execution time: 0.0265
DEBUG - 2022-06-02 06:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:15:46 --> Total execution time: 0.0387
DEBUG - 2022-06-02 06:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:45:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 06:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:15:56 --> Total execution time: 1.6479
DEBUG - 2022-06-02 06:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:46:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 06:46:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 06:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:46:07 --> No URI present. Default controller set.
DEBUG - 2022-06-02 06:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:16:07 --> Total execution time: 0.0303
DEBUG - 2022-06-02 06:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:18:45 --> Total execution time: 0.0756
DEBUG - 2022-06-02 06:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:18:50 --> Total execution time: 0.0252
DEBUG - 2022-06-02 06:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:23:32 --> Total execution time: 0.0305
DEBUG - 2022-06-02 06:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:26:31 --> Total execution time: 0.0269
DEBUG - 2022-06-02 06:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:27:36 --> Total execution time: 0.0216
DEBUG - 2022-06-02 06:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:28:07 --> Total execution time: 0.0256
DEBUG - 2022-06-02 06:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:28:11 --> Total execution time: 0.0424
DEBUG - 2022-06-02 06:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:28:17 --> Total execution time: 0.0411
DEBUG - 2022-06-02 06:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:28:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 06:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:28:18 --> Total execution time: 0.0313
DEBUG - 2022-06-02 06:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:28:51 --> Total execution time: 0.0512
DEBUG - 2022-06-02 06:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 06:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:28:52 --> Total execution time: 0.0418
DEBUG - 2022-06-02 06:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:29:03 --> Total execution time: 0.0568
DEBUG - 2022-06-02 06:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 06:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 06:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:29:18 --> Total execution time: 0.0362
DEBUG - 2022-06-02 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:30:03 --> Total execution time: 0.0392
DEBUG - 2022-06-02 07:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:01:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:01:39 --> 404 Page Not Found: Refund/index
DEBUG - 2022-06-02 07:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:01:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 07:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:01:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 07:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:01:49 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:31:49 --> Total execution time: 0.0315
DEBUG - 2022-06-02 07:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:02:25 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 07:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:02:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:02:29 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 07:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:33:05 --> Total execution time: 0.0234
DEBUG - 2022-06-02 07:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:33:21 --> Total execution time: 0.0292
DEBUG - 2022-06-02 07:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:33:59 --> Total execution time: 0.0583
DEBUG - 2022-06-02 07:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:05:53 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:35:53 --> Total execution time: 0.0358
DEBUG - 2022-06-02 07:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:14:06 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:06 --> Total execution time: 0.0771
DEBUG - 2022-06-02 07:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:14:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:14:07 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2022-06-02 07:14:07 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 07:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:14:07 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:07 --> Total execution time: 0.0295
DEBUG - 2022-06-02 07:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:14:07 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 07:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:26 --> Total execution time: 1.5879
DEBUG - 2022-06-02 07:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:14:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 07:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:15:03 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:45:03 --> Total execution time: 0.0244
DEBUG - 2022-06-02 07:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:45:21 --> Total execution time: 0.0281
DEBUG - 2022-06-02 07:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:26:04 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:56:04 --> Total execution time: 0.1870
DEBUG - 2022-06-02 07:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:26:21 --> Total execution time: 0.0350
DEBUG - 2022-06-02 07:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:26:22 --> Total execution time: 0.0305
DEBUG - 2022-06-02 07:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:26:22 --> Total execution time: 0.0512
DEBUG - 2022-06-02 07:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:56:32 --> Total execution time: 0.0218
DEBUG - 2022-06-02 07:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:56:47 --> Total execution time: 0.0342
DEBUG - 2022-06-02 07:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:56:59 --> Total execution time: 0.0444
DEBUG - 2022-06-02 07:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:57:02 --> Total execution time: 0.0746
DEBUG - 2022-06-02 07:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:57:06 --> Total execution time: 0.0320
DEBUG - 2022-06-02 07:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:57:17 --> Total execution time: 0.0288
DEBUG - 2022-06-02 07:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:57:21 --> Total execution time: 0.0299
DEBUG - 2022-06-02 07:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:57:32 --> Total execution time: 0.0268
DEBUG - 2022-06-02 07:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:32:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:32:38 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-02 07:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:33:04 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:03:04 --> Total execution time: 0.0785
DEBUG - 2022-06-02 07:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:33:12 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:03:12 --> Total execution time: 0.0318
DEBUG - 2022-06-02 07:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:34:58 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:04:58 --> Total execution time: 0.0414
DEBUG - 2022-06-02 07:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:01 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:05:01 --> Total execution time: 0.0226
DEBUG - 2022-06-02 07:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:05:07 --> Total execution time: 0.0227
DEBUG - 2022-06-02 07:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:16 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:05:16 --> Total execution time: 0.0264
DEBUG - 2022-06-02 07:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:05:16 --> Total execution time: 0.0254
DEBUG - 2022-06-02 07:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:05:24 --> Total execution time: 0.0256
DEBUG - 2022-06-02 07:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:05:26 --> Total execution time: 0.0328
DEBUG - 2022-06-02 07:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:35:34 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-02 07:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:35:34 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-06-02 07:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:05:43 --> Total execution time: 0.0312
DEBUG - 2022-06-02 07:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:35:47 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:35:51 --> 404 Page Not Found: Well-known/gpc.json
DEBUG - 2022-06-02 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:35:51 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-02 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:35:51 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-06-02 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:35:51 --> 404 Page Not Found: Well-known/security.txt
DEBUG - 2022-06-02 07:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:35:51 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:35:51 --> 404 Page Not Found: Well-known/change-password
DEBUG - 2022-06-02 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:35:51 --> 404 Page Not Found: Well-known/resource-that-should-not-exist-whose-status-code-should-not-be-200
DEBUG - 2022-06-02 07:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:05:53 --> Total execution time: 0.0522
DEBUG - 2022-06-02 07:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:05:53 --> Total execution time: 0.0409
DEBUG - 2022-06-02 07:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:05:58 --> Total execution time: 0.0454
DEBUG - 2022-06-02 07:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:06:07 --> Total execution time: 0.0391
DEBUG - 2022-06-02 07:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:06:12 --> Total execution time: 0.0307
DEBUG - 2022-06-02 07:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:06:25 --> Total execution time: 0.0598
DEBUG - 2022-06-02 07:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:06:36 --> Total execution time: 0.0322
DEBUG - 2022-06-02 07:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:36:37 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:06:37 --> Total execution time: 0.0276
DEBUG - 2022-06-02 07:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:06:43 --> Total execution time: 0.0321
DEBUG - 2022-06-02 07:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:06:44 --> Total execution time: 0.0317
DEBUG - 2022-06-02 07:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:36:46 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:06:46 --> Total execution time: 0.0303
DEBUG - 2022-06-02 07:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:06:48 --> Total execution time: 0.0337
DEBUG - 2022-06-02 07:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:06:58 --> Total execution time: 0.0348
DEBUG - 2022-06-02 07:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:07:02 --> Total execution time: 0.0503
DEBUG - 2022-06-02 07:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:07:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 07:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:07:03 --> Total execution time: 0.0294
DEBUG - 2022-06-02 07:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:07:10 --> Total execution time: 0.0339
DEBUG - 2022-06-02 07:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:07:16 --> Total execution time: 0.0309
DEBUG - 2022-06-02 07:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:07:24 --> Total execution time: 0.0443
DEBUG - 2022-06-02 07:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:07:45 --> Total execution time: 0.0463
DEBUG - 2022-06-02 07:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:07:46 --> Total execution time: 0.0346
DEBUG - 2022-06-02 07:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:37:50 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 07:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:37:51 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:07:51 --> Total execution time: 0.0304
DEBUG - 2022-06-02 07:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:09:54 --> Total execution time: 0.1342
DEBUG - 2022-06-02 07:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:11:27 --> Total execution time: 0.0324
DEBUG - 2022-06-02 07:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:11:47 --> Total execution time: 0.0558
DEBUG - 2022-06-02 07:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:11:54 --> Total execution time: 0.0381
DEBUG - 2022-06-02 07:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:12:02 --> Total execution time: 0.0326
DEBUG - 2022-06-02 07:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:12:10 --> Total execution time: 0.0511
DEBUG - 2022-06-02 07:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:12:26 --> Total execution time: 0.0326
DEBUG - 2022-06-02 07:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:12:41 --> Total execution time: 0.0430
DEBUG - 2022-06-02 07:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:43:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:43:44 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-02 07:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:44:04 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:14:04 --> Total execution time: 0.0562
DEBUG - 2022-06-02 07:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:44:07 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:14:07 --> Total execution time: 0.0414
DEBUG - 2022-06-02 07:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:14:18 --> Total execution time: 0.0373
DEBUG - 2022-06-02 07:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:14:22 --> Total execution time: 0.1708
DEBUG - 2022-06-02 07:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:14:34 --> Total execution time: 0.0348
DEBUG - 2022-06-02 07:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:00 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:15:00 --> Total execution time: 0.0317
DEBUG - 2022-06-02 07:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:45:12 --> Total execution time: 0.0388
DEBUG - 2022-06-02 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:45:13 --> Total execution time: 0.0337
DEBUG - 2022-06-02 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:45:13 --> Total execution time: 0.0313
DEBUG - 2022-06-02 07:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:15:18 --> Total execution time: 1.6090
DEBUG - 2022-06-02 07:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:45:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 07:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:15:33 --> Total execution time: 1.5257
DEBUG - 2022-06-02 07:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:15:36 --> Total execution time: 0.0360
DEBUG - 2022-06-02 07:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:15:36 --> Total execution time: 0.0316
DEBUG - 2022-06-02 07:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:38 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:15:38 --> Total execution time: 0.0538
DEBUG - 2022-06-02 07:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:53 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:15:53 --> Total execution time: 0.0331
DEBUG - 2022-06-02 07:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:15:57 --> Total execution time: 0.0372
DEBUG - 2022-06-02 07:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:16:11 --> Total execution time: 0.0399
DEBUG - 2022-06-02 07:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:16:14 --> Total execution time: 0.0359
DEBUG - 2022-06-02 07:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:16:25 --> Total execution time: 0.0643
DEBUG - 2022-06-02 07:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:16:27 --> Total execution time: 0.0273
DEBUG - 2022-06-02 07:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:16:29 --> Total execution time: 0.0561
DEBUG - 2022-06-02 07:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:16:36 --> Total execution time: 0.0338
DEBUG - 2022-06-02 07:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:16:39 --> Total execution time: 0.0352
DEBUG - 2022-06-02 07:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:47:32 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:17:32 --> Total execution time: 0.0219
DEBUG - 2022-06-02 07:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:17:40 --> Total execution time: 0.0208
DEBUG - 2022-06-02 07:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:51:01 --> Total execution time: 0.0671
DEBUG - 2022-06-02 07:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:51:02 --> Total execution time: 0.0350
DEBUG - 2022-06-02 07:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:51:02 --> Total execution time: 0.0450
DEBUG - 2022-06-02 07:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:21:37 --> Total execution time: 0.0341
DEBUG - 2022-06-02 07:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:21:50 --> Total execution time: 0.0654
DEBUG - 2022-06-02 07:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:52:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 07:52:52 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-02 07:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:22:59 --> Total execution time: 0.0258
DEBUG - 2022-06-02 07:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:23:15 --> Total execution time: 0.0342
DEBUG - 2022-06-02 07:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:23:20 --> Total execution time: 0.1864
DEBUG - 2022-06-02 07:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:53:30 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:23:30 --> Total execution time: 0.0298
DEBUG - 2022-06-02 07:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:53:37 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:23:37 --> Total execution time: 0.0282
DEBUG - 2022-06-02 07:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:23:48 --> Total execution time: 1.5349
DEBUG - 2022-06-02 07:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:54:46 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:24:46 --> Total execution time: 0.0615
DEBUG - 2022-06-02 07:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:55:15 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:25:15 --> Total execution time: 0.0486
DEBUG - 2022-06-02 07:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:55:27 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:25:27 --> Total execution time: 0.0319
DEBUG - 2022-06-02 07:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:25:28 --> Total execution time: 0.0283
DEBUG - 2022-06-02 07:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:25:33 --> Total execution time: 0.0657
DEBUG - 2022-06-02 07:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:25:35 --> Total execution time: 0.0442
DEBUG - 2022-06-02 07:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:25:37 --> Total execution time: 1.4853
DEBUG - 2022-06-02 07:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:25:42 --> Total execution time: 0.0411
DEBUG - 2022-06-02 07:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:13 --> Total execution time: 0.0688
DEBUG - 2022-06-02 07:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:13 --> Total execution time: 0.0323
DEBUG - 2022-06-02 07:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:13 --> Total execution time: 0.0316
DEBUG - 2022-06-02 07:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:14 --> Total execution time: 0.0454
DEBUG - 2022-06-02 07:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:16 --> Total execution time: 0.0352
DEBUG - 2022-06-02 07:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:16 --> Total execution time: 0.0387
DEBUG - 2022-06-02 07:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:16 --> Total execution time: 0.0398
DEBUG - 2022-06-02 07:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:18 --> Total execution time: 0.0435
DEBUG - 2022-06-02 07:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:19 --> Total execution time: 0.0308
DEBUG - 2022-06-02 07:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:29 --> Total execution time: 0.0456
DEBUG - 2022-06-02 07:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:32 --> Total execution time: 0.0330
DEBUG - 2022-06-02 07:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:35 --> Total execution time: 0.0403
DEBUG - 2022-06-02 07:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:38 --> Total execution time: 0.0458
DEBUG - 2022-06-02 07:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:48 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:48 --> Total execution time: 0.0559
DEBUG - 2022-06-02 07:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:57 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:57 --> Total execution time: 0.0601
DEBUG - 2022-06-02 07:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:26:59 --> Total execution time: 1.4652
DEBUG - 2022-06-02 07:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:27:13 --> Total execution time: 0.0295
DEBUG - 2022-06-02 07:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:27:27 --> Total execution time: 0.0551
DEBUG - 2022-06-02 07:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:57:36 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:27:36 --> Total execution time: 0.0454
DEBUG - 2022-06-02 07:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:27:54 --> Total execution time: 1.4831
DEBUG - 2022-06-02 07:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:58:14 --> Total execution time: 0.0423
DEBUG - 2022-06-02 07:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:58:17 --> Total execution time: 0.1141
DEBUG - 2022-06-02 07:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:28:52 --> Total execution time: 0.0702
DEBUG - 2022-06-02 07:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:29:11 --> Total execution time: 0.0658
DEBUG - 2022-06-02 07:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:59:17 --> No URI present. Default controller set.
DEBUG - 2022-06-02 07:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:29:17 --> Total execution time: 0.0574
DEBUG - 2022-06-02 07:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:29:18 --> Total execution time: 0.0557
DEBUG - 2022-06-02 07:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 07:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:29:23 --> Total execution time: 0.0443
DEBUG - 2022-06-02 07:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:29:25 --> Total execution time: 0.0397
DEBUG - 2022-06-02 07:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:29:26 --> Total execution time: 0.0302
DEBUG - 2022-06-02 07:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:29:29 --> Total execution time: 0.0494
DEBUG - 2022-06-02 07:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:29:30 --> Total execution time: 0.0446
DEBUG - 2022-06-02 07:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:29:33 --> Total execution time: 0.0312
DEBUG - 2022-06-02 07:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:29:36 --> Total execution time: 0.0429
DEBUG - 2022-06-02 07:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:29:39 --> Total execution time: 0.0343
DEBUG - 2022-06-02 07:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:29:46 --> Total execution time: 0.0365
DEBUG - 2022-06-02 07:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 07:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 07:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:29:49 --> Total execution time: 0.0363
DEBUG - 2022-06-02 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:30:02 --> Total execution time: 0.0486
DEBUG - 2022-06-02 08:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:30:28 --> Total execution time: 0.0568
DEBUG - 2022-06-02 08:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:30:32 --> Total execution time: 0.0333
DEBUG - 2022-06-02 08:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:30:36 --> Total execution time: 0.0338
DEBUG - 2022-06-02 08:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:30:39 --> Total execution time: 0.0264
DEBUG - 2022-06-02 08:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:00:48 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:30:48 --> Total execution time: 0.0275
DEBUG - 2022-06-02 08:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:00:57 --> Total execution time: 0.0354
DEBUG - 2022-06-02 08:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:01:05 --> Total execution time: 0.0298
DEBUG - 2022-06-02 08:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:01:05 --> Total execution time: 0.0599
DEBUG - 2022-06-02 08:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:31:17 --> Total execution time: 0.0608
DEBUG - 2022-06-02 08:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:31:21 --> Total execution time: 0.0463
DEBUG - 2022-06-02 08:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:31:39 --> Total execution time: 0.0374
DEBUG - 2022-06-02 08:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:01:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:31:48 --> Total execution time: 1.5323
DEBUG - 2022-06-02 08:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:01:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 08:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:31:51 --> Total execution time: 0.0282
DEBUG - 2022-06-02 08:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:32:32 --> Total execution time: 0.0729
DEBUG - 2022-06-02 08:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:32:41 --> Total execution time: 0.0324
DEBUG - 2022-06-02 08:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:32:47 --> Total execution time: 0.0297
DEBUG - 2022-06-02 08:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:32:51 --> Total execution time: 0.0889
DEBUG - 2022-06-02 08:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:32:51 --> Total execution time: 0.0557
DEBUG - 2022-06-02 08:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:02:55 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:32:55 --> Total execution time: 0.0696
DEBUG - 2022-06-02 08:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:33:08 --> Total execution time: 0.0525
DEBUG - 2022-06-02 08:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:33:11 --> Total execution time: 0.0455
DEBUG - 2022-06-02 08:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:33:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:33:12 --> Total execution time: 0.0480
DEBUG - 2022-06-02 08:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:33:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:33:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 18:33:14 --> Total execution time: 0.0520
DEBUG - 2022-06-02 18:33:14 --> Total execution time: 0.1715
DEBUG - 2022-06-02 08:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:33:16 --> Total execution time: 0.0433
DEBUG - 2022-06-02 08:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:33:18 --> Total execution time: 0.0348
DEBUG - 2022-06-02 08:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:33:21 --> Total execution time: 0.0311
DEBUG - 2022-06-02 08:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:03:23 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:33:24 --> Total execution time: 0.1250
DEBUG - 2022-06-02 08:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:33:31 --> Total execution time: 0.0528
DEBUG - 2022-06-02 08:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:33:34 --> Total execution time: 0.0310
DEBUG - 2022-06-02 08:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:33:41 --> Total execution time: 0.0347
DEBUG - 2022-06-02 08:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:04:13 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:34:13 --> Total execution time: 0.0612
DEBUG - 2022-06-02 08:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:04:14 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:34:14 --> Total execution time: 0.0400
DEBUG - 2022-06-02 08:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:34:21 --> Total execution time: 0.0335
DEBUG - 2022-06-02 08:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:34:28 --> Total execution time: 0.0516
DEBUG - 2022-06-02 08:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:34:43 --> Total execution time: 0.0288
DEBUG - 2022-06-02 08:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:38:15 --> Total execution time: 0.0802
DEBUG - 2022-06-02 08:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:39:13 --> Total execution time: 0.0294
DEBUG - 2022-06-02 08:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:39:44 --> Total execution time: 0.0767
DEBUG - 2022-06-02 08:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:10:14 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:40:14 --> Total execution time: 0.0813
DEBUG - 2022-06-02 08:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:40:18 --> Total execution time: 0.0675
DEBUG - 2022-06-02 08:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:40:55 --> Total execution time: 0.0385
DEBUG - 2022-06-02 08:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:41:00 --> Total execution time: 0.0346
DEBUG - 2022-06-02 08:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:41:08 --> Total execution time: 0.0316
DEBUG - 2022-06-02 08:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:41:14 --> Total execution time: 0.0410
DEBUG - 2022-06-02 08:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:41:30 --> Total execution time: 0.0314
DEBUG - 2022-06-02 08:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:41:36 --> Total execution time: 0.0391
DEBUG - 2022-06-02 08:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:11:56 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:41:56 --> Total execution time: 0.0313
DEBUG - 2022-06-02 08:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:42:12 --> Total execution time: 0.0296
DEBUG - 2022-06-02 08:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:42:23 --> Total execution time: 0.0326
DEBUG - 2022-06-02 08:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:42:27 --> Total execution time: 0.0698
DEBUG - 2022-06-02 08:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:12:49 --> Total execution time: 0.0377
DEBUG - 2022-06-02 08:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:12:51 --> Total execution time: 0.0479
DEBUG - 2022-06-02 08:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:43:06 --> Total execution time: 0.0336
DEBUG - 2022-06-02 08:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:15:33 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:45:33 --> Total execution time: 0.0824
DEBUG - 2022-06-02 08:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:45:40 --> Total execution time: 0.0205
DEBUG - 2022-06-02 08:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:46:04 --> Total execution time: 0.0318
DEBUG - 2022-06-02 08:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:16:08 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:46:08 --> Total execution time: 0.0675
DEBUG - 2022-06-02 08:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:46:13 --> Total execution time: 0.0256
DEBUG - 2022-06-02 08:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:46:27 --> Total execution time: 0.0268
DEBUG - 2022-06-02 08:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:46:43 --> Total execution time: 0.0256
DEBUG - 2022-06-02 08:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:18:01 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:48:01 --> Total execution time: 0.0657
DEBUG - 2022-06-02 08:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:48:12 --> Total execution time: 0.0275
DEBUG - 2022-06-02 08:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:48:18 --> Total execution time: 0.0410
DEBUG - 2022-06-02 08:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:48:26 --> Total execution time: 0.0740
DEBUG - 2022-06-02 08:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:48:39 --> Total execution time: 0.0463
DEBUG - 2022-06-02 08:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:49:26 --> Total execution time: 0.0515
DEBUG - 2022-06-02 08:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:49:46 --> Total execution time: 0.0352
DEBUG - 2022-06-02 08:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:49:50 --> Total execution time: 0.0622
DEBUG - 2022-06-02 08:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:49:57 --> Total execution time: 0.0588
DEBUG - 2022-06-02 08:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:50:42 --> Total execution time: 0.0338
DEBUG - 2022-06-02 08:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:50:47 --> Total execution time: 0.0460
DEBUG - 2022-06-02 08:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:50:51 --> Total execution time: 0.0678
DEBUG - 2022-06-02 08:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:20:54 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:50:54 --> Total execution time: 0.0349
DEBUG - 2022-06-02 08:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:50:55 --> Total execution time: 0.0542
DEBUG - 2022-06-02 08:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:20:55 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:50:55 --> Total execution time: 0.0828
DEBUG - 2022-06-02 08:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:51:02 --> Total execution time: 0.0283
DEBUG - 2022-06-02 08:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:51:06 --> Total execution time: 0.0245
DEBUG - 2022-06-02 08:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:51:20 --> Total execution time: 0.0256
DEBUG - 2022-06-02 08:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:51:37 --> Total execution time: 0.0445
DEBUG - 2022-06-02 08:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:51:40 --> Total execution time: 0.0387
DEBUG - 2022-06-02 08:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:51:47 --> Total execution time: 0.0309
DEBUG - 2022-06-02 08:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:51:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:51:48 --> Total execution time: 0.0381
DEBUG - 2022-06-02 08:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:51:56 --> Total execution time: 0.0337
DEBUG - 2022-06-02 08:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:52:03 --> Total execution time: 0.0406
DEBUG - 2022-06-02 08:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:52:09 --> Total execution time: 0.0309
DEBUG - 2022-06-02 08:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:52:21 --> Total execution time: 0.0204
DEBUG - 2022-06-02 08:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:52:22 --> Total execution time: 0.0240
DEBUG - 2022-06-02 08:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:52:25 --> Total execution time: 0.0516
DEBUG - 2022-06-02 08:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:52:28 --> Total execution time: 0.0604
DEBUG - 2022-06-02 08:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:52:33 --> Total execution time: 0.0335
DEBUG - 2022-06-02 08:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:52:37 --> Total execution time: 0.0336
DEBUG - 2022-06-02 08:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:52:39 --> Total execution time: 0.0483
DEBUG - 2022-06-02 08:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:52:57 --> Total execution time: 0.0313
DEBUG - 2022-06-02 08:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:52:58 --> Total execution time: 0.0246
DEBUG - 2022-06-02 08:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:53:16 --> Total execution time: 0.0788
DEBUG - 2022-06-02 08:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:23:23 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:53:23 --> Total execution time: 0.0324
DEBUG - 2022-06-02 08:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:23:32 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:53:32 --> Total execution time: 0.0431
DEBUG - 2022-06-02 08:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:53:43 --> Total execution time: 0.0340
DEBUG - 2022-06-02 08:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:53:57 --> Total execution time: 0.0305
DEBUG - 2022-06-02 08:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:54:12 --> Total execution time: 0.0584
DEBUG - 2022-06-02 08:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:54:15 --> Total execution time: 0.0283
DEBUG - 2022-06-02 08:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:54:25 --> Total execution time: 0.0271
DEBUG - 2022-06-02 08:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:54:27 --> Total execution time: 0.0296
DEBUG - 2022-06-02 08:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:54:32 --> Total execution time: 0.0304
DEBUG - 2022-06-02 08:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:54:35 --> Total execution time: 0.0315
DEBUG - 2022-06-02 08:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:54:37 --> Total execution time: 0.0342
DEBUG - 2022-06-02 08:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:54:39 --> Total execution time: 0.0378
DEBUG - 2022-06-02 08:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:54:47 --> Total execution time: 0.0364
DEBUG - 2022-06-02 08:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:54:57 --> Total execution time: 0.0360
DEBUG - 2022-06-02 08:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:55:06 --> Total execution time: 0.0389
DEBUG - 2022-06-02 08:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:55:26 --> Total execution time: 0.0385
DEBUG - 2022-06-02 08:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:55:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 08:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:55:27 --> Total execution time: 0.0274
DEBUG - 2022-06-02 08:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:55:34 --> Total execution time: 0.0333
DEBUG - 2022-06-02 08:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:55:49 --> Total execution time: 0.0503
DEBUG - 2022-06-02 08:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:58:30 --> Total execution time: 0.0275
DEBUG - 2022-06-02 08:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:58:31 --> Total execution time: 0.0325
DEBUG - 2022-06-02 08:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:58:42 --> Total execution time: 0.0319
DEBUG - 2022-06-02 08:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:58:53 --> Total execution time: 0.0438
DEBUG - 2022-06-02 08:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:59:35 --> Total execution time: 0.0789
DEBUG - 2022-06-02 08:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:30:04 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:00:05 --> Total execution time: 0.0863
DEBUG - 2022-06-02 08:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:00:10 --> Total execution time: 0.0338
DEBUG - 2022-06-02 08:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:00:12 --> Total execution time: 0.0311
DEBUG - 2022-06-02 08:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:00:24 --> Total execution time: 0.0377
DEBUG - 2022-06-02 08:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:00:30 --> Total execution time: 0.0386
DEBUG - 2022-06-02 08:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:00:35 --> Total execution time: 0.0519
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-includes/css
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-includes/css
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> UTF-8 Support Enabled
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-06-02 08:32:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:53 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:53 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:53 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:54 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:54 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:54 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:54 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:54 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:54 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:54 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:55 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:55 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:55 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:55 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:55 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:55 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:56 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:56 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:56 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:56 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:56 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:56 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:57 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:57 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:57 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:57 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:57 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:58 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:58 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:58 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:58 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:58 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:58 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:58 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:59 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:59 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:59 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:59 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:59 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:59 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:32:59 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:00 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:01 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:01 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:01 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:02 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:02 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:03 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:03 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:03 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:04 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:04 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:04 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:05 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:05 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:06 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:06 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:06 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:07 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:07 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:07 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:08 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:08 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:09 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:09 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:09 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:10 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:10 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:10 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:11 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:11 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:11 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:12 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:12 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:13 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 08:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:13 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 08:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:13 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-02 08:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:14 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 08:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:14 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 08:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:33:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:33:14 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 08:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:04:22 --> Total execution time: 0.0271
DEBUG - 2022-06-02 08:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:04:26 --> Total execution time: 0.0365
DEBUG - 2022-06-02 08:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:04:30 --> Total execution time: 0.0348
DEBUG - 2022-06-02 08:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:04:35 --> Total execution time: 0.0374
DEBUG - 2022-06-02 08:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:04:38 --> Total execution time: 0.0472
DEBUG - 2022-06-02 08:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:08:01 --> Total execution time: 0.1433
DEBUG - 2022-06-02 08:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:08:59 --> Total execution time: 0.0271
DEBUG - 2022-06-02 08:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:39:33 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:09:33 --> Total execution time: 0.0266
DEBUG - 2022-06-02 08:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:39:34 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:09:34 --> Total execution time: 0.0378
DEBUG - 2022-06-02 08:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:39:35 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:09:35 --> Total execution time: 0.0264
DEBUG - 2022-06-02 08:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:39:36 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:09:36 --> Total execution time: 0.0247
DEBUG - 2022-06-02 08:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:39:36 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:09:36 --> Total execution time: 0.0300
DEBUG - 2022-06-02 08:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:39:49 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:09:49 --> Total execution time: 0.0225
DEBUG - 2022-06-02 08:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:39:49 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:09:49 --> Total execution time: 0.0272
DEBUG - 2022-06-02 08:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:39:50 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:09:50 --> Total execution time: 0.0232
DEBUG - 2022-06-02 08:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:39:51 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:09:51 --> Total execution time: 0.0237
DEBUG - 2022-06-02 08:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:39:52 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:09:52 --> Total execution time: 0.0248
DEBUG - 2022-06-02 08:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:39:53 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:09:53 --> Total execution time: 0.0212
DEBUG - 2022-06-02 08:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:39:56 --> 404 Page Not Found: Memberships/index
DEBUG - 2022-06-02 08:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:39:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 08:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:40:13 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:10:13 --> Total execution time: 0.0264
DEBUG - 2022-06-02 08:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:41:12 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:11:12 --> Total execution time: 0.0219
DEBUG - 2022-06-02 08:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:11:16 --> Total execution time: 0.0243
DEBUG - 2022-06-02 08:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:11:42 --> Total execution time: 0.0322
DEBUG - 2022-06-02 08:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:11:55 --> Total execution time: 0.0399
DEBUG - 2022-06-02 08:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 08:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:11:55 --> Total execution time: 0.0261
DEBUG - 2022-06-02 08:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:12:05 --> Total execution time: 0.0354
DEBUG - 2022-06-02 08:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:13:36 --> Total execution time: 0.0308
DEBUG - 2022-06-02 08:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:13:46 --> Total execution time: 0.0754
DEBUG - 2022-06-02 08:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:14:08 --> Total execution time: 0.0274
DEBUG - 2022-06-02 08:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:44:28 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:14:28 --> Total execution time: 0.0303
DEBUG - 2022-06-02 08:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:45:41 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:15:41 --> Total execution time: 0.0287
DEBUG - 2022-06-02 08:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:45:52 --> No URI present. Default controller set.
DEBUG - 2022-06-02 08:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:15:52 --> Total execution time: 0.0248
DEBUG - 2022-06-02 08:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 08:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:19:43 --> Total execution time: 0.0847
DEBUG - 2022-06-02 08:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:51:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:51:46 --> 404 Page Not Found: Old-indexphp/index
DEBUG - 2022-06-02 08:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 08:51:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 08:51:49 --> 404 Page Not Found: Wp-loadphp/index
DEBUG - 2022-06-02 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:30:03 --> Total execution time: 0.1549
DEBUG - 2022-06-02 09:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:33:37 --> Total execution time: 0.0781
DEBUG - 2022-06-02 09:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:05:10 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:35:10 --> Total execution time: 0.0362
DEBUG - 2022-06-02 09:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:35:17 --> Total execution time: 0.0343
DEBUG - 2022-06-02 09:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:35:42 --> Total execution time: 0.0264
DEBUG - 2022-06-02 09:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:35:57 --> Total execution time: 0.0257
DEBUG - 2022-06-02 09:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:06:25 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:36:26 --> Total execution time: 0.0448
DEBUG - 2022-06-02 09:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:37:51 --> Total execution time: 0.0366
DEBUG - 2022-06-02 09:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:37:59 --> Total execution time: 0.0197
DEBUG - 2022-06-02 09:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:38:00 --> Total execution time: 0.0366
DEBUG - 2022-06-02 09:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:38:15 --> Total execution time: 0.0932
DEBUG - 2022-06-02 09:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:39:41 --> Total execution time: 0.0529
DEBUG - 2022-06-02 09:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:39:48 --> Total execution time: 0.0339
DEBUG - 2022-06-02 09:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:39:55 --> Total execution time: 0.0294
DEBUG - 2022-06-02 09:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:40:24 --> Total execution time: 0.0593
DEBUG - 2022-06-02 09:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:40:29 --> Total execution time: 0.0347
DEBUG - 2022-06-02 09:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:40:33 --> Total execution time: 0.0329
DEBUG - 2022-06-02 09:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:40:35 --> Total execution time: 0.0553
DEBUG - 2022-06-02 09:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:40:45 --> Total execution time: 0.0597
DEBUG - 2022-06-02 09:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:41:01 --> Total execution time: 0.0490
DEBUG - 2022-06-02 09:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:42:48 --> Total execution time: 0.0200
DEBUG - 2022-06-02 09:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:12:58 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:42:58 --> Total execution time: 0.0246
DEBUG - 2022-06-02 09:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:43:02 --> Total execution time: 0.0320
DEBUG - 2022-06-02 09:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:43:07 --> Total execution time: 0.0306
DEBUG - 2022-06-02 09:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:43:08 --> Total execution time: 0.0255
DEBUG - 2022-06-02 09:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:43:09 --> Total execution time: 0.0350
DEBUG - 2022-06-02 09:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:43:12 --> Total execution time: 0.0432
DEBUG - 2022-06-02 09:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:43:17 --> Total execution time: 0.0267
DEBUG - 2022-06-02 09:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:43:26 --> Total execution time: 0.0368
DEBUG - 2022-06-02 09:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:43:32 --> Total execution time: 0.0724
DEBUG - 2022-06-02 09:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:43:42 --> Total execution time: 0.0308
DEBUG - 2022-06-02 09:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:43:47 --> Total execution time: 0.0316
DEBUG - 2022-06-02 09:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:43:59 --> Total execution time: 0.0431
DEBUG - 2022-06-02 09:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:49:52 --> Total execution time: 0.0281
DEBUG - 2022-06-02 09:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:49:59 --> Total execution time: 0.0279
DEBUG - 2022-06-02 09:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:50:22 --> Total execution time: 0.0342
DEBUG - 2022-06-02 09:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:50:30 --> Total execution time: 0.0344
DEBUG - 2022-06-02 09:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:50:37 --> Total execution time: 0.0504
DEBUG - 2022-06-02 09:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:52:10 --> Total execution time: 0.0202
DEBUG - 2022-06-02 09:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:15 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:52:15 --> Total execution time: 0.0269
DEBUG - 2022-06-02 09:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:15 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:52:15 --> Total execution time: 0.0219
DEBUG - 2022-06-02 09:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:52:20 --> Total execution time: 0.0302
DEBUG - 2022-06-02 09:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:52:35 --> Total execution time: 0.0301
DEBUG - 2022-06-02 09:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:22:42 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 09:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:22:43 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 09:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:22:44 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 09:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:22:44 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 09:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:22:44 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 09:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:22:45 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-06-02 09:22:45 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 09:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:22:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 09:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:22:45 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 09:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:22:47 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 09:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:22:47 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 09:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:22:48 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 09:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:22:48 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 09:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:22:48 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-02 09:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:53:10 --> Total execution time: 0.0337
DEBUG - 2022-06-02 09:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:24:22 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:54:22 --> Total execution time: 0.0409
DEBUG - 2022-06-02 09:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:24:22 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:54:22 --> Total execution time: 0.0253
DEBUG - 2022-06-02 09:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:54:27 --> Total execution time: 0.0218
DEBUG - 2022-06-02 09:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:54:34 --> Total execution time: 0.0482
DEBUG - 2022-06-02 09:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:54:48 --> Total execution time: 0.0505
DEBUG - 2022-06-02 09:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:54:55 --> Total execution time: 0.0585
DEBUG - 2022-06-02 09:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:54:59 --> Total execution time: 0.0555
DEBUG - 2022-06-02 09:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:55:09 --> Total execution time: 0.0390
DEBUG - 2022-06-02 09:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:25:10 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:55:10 --> Total execution time: 0.0337
DEBUG - 2022-06-02 09:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:25:17 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:55:17 --> Total execution time: 0.0324
DEBUG - 2022-06-02 09:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:25:21 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:55:21 --> Total execution time: 0.0287
DEBUG - 2022-06-02 09:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:55:37 --> Total execution time: 1.6377
DEBUG - 2022-06-02 09:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:25:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:25:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 09:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:26:01 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:56:01 --> Total execution time: 0.0333
DEBUG - 2022-06-02 09:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:26:12 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:56:12 --> Total execution time: 0.0250
DEBUG - 2022-06-02 09:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:32:48 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:02:48 --> Total execution time: 0.0859
DEBUG - 2022-06-02 09:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:33:58 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:03:58 --> Total execution time: 0.0593
DEBUG - 2022-06-02 09:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:34:31 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:04:31 --> Total execution time: 0.0425
DEBUG - 2022-06-02 09:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:34:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:34:56 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-02 09:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:35:21 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:05:22 --> Total execution time: 0.0297
DEBUG - 2022-06-02 09:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:05:44 --> Total execution time: 0.0352
DEBUG - 2022-06-02 09:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:36:08 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:06:08 --> Total execution time: 0.0406
DEBUG - 2022-06-02 09:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:37:27 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:07:27 --> Total execution time: 0.0468
DEBUG - 2022-06-02 09:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:07:32 --> Total execution time: 0.0231
DEBUG - 2022-06-02 09:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:37:39 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:07:39 --> Total execution time: 0.0316
DEBUG - 2022-06-02 09:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:07:44 --> Total execution time: 0.0210
DEBUG - 2022-06-02 09:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:37:50 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:07:50 --> Total execution time: 0.0284
DEBUG - 2022-06-02 09:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:08:00 --> Total execution time: 0.0195
DEBUG - 2022-06-02 09:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:38:16 --> Total execution time: 0.0232
DEBUG - 2022-06-02 09:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:38:18 --> Total execution time: 0.0237
DEBUG - 2022-06-02 09:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:38:18 --> Total execution time: 0.0327
DEBUG - 2022-06-02 09:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:38:25 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:08:25 --> Total execution time: 0.0318
DEBUG - 2022-06-02 09:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:38:34 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:08:34 --> Total execution time: 0.0347
DEBUG - 2022-06-02 09:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:38:39 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:08:39 --> Total execution time: 0.0372
DEBUG - 2022-06-02 09:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:09:04 --> Total execution time: 0.0884
DEBUG - 2022-06-02 09:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:39:13 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:09:13 --> Total execution time: 0.0230
DEBUG - 2022-06-02 09:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:09:20 --> Total execution time: 0.0311
DEBUG - 2022-06-02 09:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:09:32 --> Total execution time: 0.0290
DEBUG - 2022-06-02 09:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:09:48 --> Total execution time: 0.0398
DEBUG - 2022-06-02 09:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:39:59 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:09:59 --> Total execution time: 0.0502
DEBUG - 2022-06-02 09:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:10:00 --> Total execution time: 0.0392
DEBUG - 2022-06-02 09:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:10:06 --> Total execution time: 0.0413
DEBUG - 2022-06-02 09:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:10:08 --> Total execution time: 0.0372
DEBUG - 2022-06-02 09:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:40:20 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:10:20 --> Total execution time: 0.0450
DEBUG - 2022-06-02 09:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:10:26 --> Total execution time: 0.0323
DEBUG - 2022-06-02 09:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:10:32 --> Total execution time: 0.0518
DEBUG - 2022-06-02 09:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:10:32 --> Total execution time: 0.0267
DEBUG - 2022-06-02 09:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:40:33 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:10:33 --> Total execution time: 0.0382
DEBUG - 2022-06-02 09:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:10:41 --> Total execution time: 0.0432
DEBUG - 2022-06-02 09:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:10:59 --> Total execution time: 0.0442
DEBUG - 2022-06-02 09:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:10:59 --> Total execution time: 0.0255
DEBUG - 2022-06-02 09:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:11:08 --> Total execution time: 0.0772
DEBUG - 2022-06-02 09:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:11:14 --> Total execution time: 0.0363
DEBUG - 2022-06-02 09:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:11:26 --> Total execution time: 0.0713
DEBUG - 2022-06-02 09:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:11:31 --> Total execution time: 0.1008
DEBUG - 2022-06-02 09:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:11:36 --> Total execution time: 0.0309
DEBUG - 2022-06-02 09:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:11:47 --> Total execution time: 0.0516
DEBUG - 2022-06-02 09:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:11:56 --> Total execution time: 0.0288
DEBUG - 2022-06-02 09:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:11:57 --> Total execution time: 0.0398
DEBUG - 2022-06-02 09:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:41:58 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:11:58 --> Total execution time: 0.0398
DEBUG - 2022-06-02 09:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:41:58 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:11:58 --> Total execution time: 0.0312
DEBUG - 2022-06-02 09:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:12:30 --> Total execution time: 0.0253
DEBUG - 2022-06-02 09:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:12:46 --> Total execution time: 0.0259
DEBUG - 2022-06-02 09:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:12:55 --> Total execution time: 0.0261
DEBUG - 2022-06-02 09:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:42:56 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:12:56 --> Total execution time: 0.0228
DEBUG - 2022-06-02 09:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:13:28 --> Total execution time: 0.0344
DEBUG - 2022-06-02 09:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:13:34 --> Total execution time: 0.0368
DEBUG - 2022-06-02 09:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:14:04 --> Total execution time: 0.0522
DEBUG - 2022-06-02 09:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:14:09 --> Total execution time: 0.0773
DEBUG - 2022-06-02 09:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:14:16 --> Total execution time: 0.0397
DEBUG - 2022-06-02 09:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:14:26 --> Total execution time: 0.0723
DEBUG - 2022-06-02 09:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:14:37 --> Total execution time: 0.0633
DEBUG - 2022-06-02 09:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:14:44 --> Total execution time: 0.0305
DEBUG - 2022-06-02 09:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:14:46 --> Total execution time: 0.0308
DEBUG - 2022-06-02 09:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:46:07 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:16:07 --> Total execution time: 0.0312
DEBUG - 2022-06-02 09:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:16:24 --> Total execution time: 0.0198
DEBUG - 2022-06-02 09:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:46:44 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:16:44 --> Total execution time: 0.0247
DEBUG - 2022-06-02 09:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:47:13 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:17:13 --> Total execution time: 0.0237
DEBUG - 2022-06-02 09:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:17:17 --> Total execution time: 0.0299
DEBUG - 2022-06-02 09:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:17:19 --> Total execution time: 0.0729
DEBUG - 2022-06-02 09:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:17:19 --> Total execution time: 0.0210
DEBUG - 2022-06-02 09:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:17:28 --> Total execution time: 0.0412
DEBUG - 2022-06-02 09:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:17:31 --> Total execution time: 0.0314
DEBUG - 2022-06-02 09:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:17:39 --> Total execution time: 0.0793
DEBUG - 2022-06-02 09:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:17:51 --> Total execution time: 0.0325
DEBUG - 2022-06-02 09:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:02 --> Total execution time: 0.1134
DEBUG - 2022-06-02 09:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:05 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:05 --> Total execution time: 0.0583
DEBUG - 2022-06-02 09:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:09 --> Total execution time: 0.1035
DEBUG - 2022-06-02 09:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:11 --> Total execution time: 0.0344
DEBUG - 2022-06-02 09:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:11 --> Total execution time: 0.0290
DEBUG - 2022-06-02 09:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:12 --> Total execution time: 0.0380
DEBUG - 2022-06-02 09:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:21 --> Total execution time: 0.0281
DEBUG - 2022-06-02 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:22 --> Total execution time: 0.0271
DEBUG - 2022-06-02 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:25 --> Total execution time: 0.0303
DEBUG - 2022-06-02 09:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:31 --> Total execution time: 0.0352
DEBUG - 2022-06-02 09:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:35 --> Total execution time: 0.0437
DEBUG - 2022-06-02 09:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:44 --> Total execution time: 0.0454
DEBUG - 2022-06-02 09:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:45 --> Total execution time: 0.0326
DEBUG - 2022-06-02 09:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:53 --> Total execution time: 0.1461
DEBUG - 2022-06-02 09:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:55 --> Total execution time: 0.0240
DEBUG - 2022-06-02 09:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:59 --> Total execution time: 0.0554
DEBUG - 2022-06-02 09:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:19:06 --> Total execution time: 0.0448
DEBUG - 2022-06-02 09:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:19:25 --> Total execution time: 0.0323
DEBUG - 2022-06-02 09:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:19:44 --> Total execution time: 0.0360
DEBUG - 2022-06-02 09:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:19:59 --> Total execution time: 0.0314
DEBUG - 2022-06-02 09:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:20:07 --> Total execution time: 0.0367
DEBUG - 2022-06-02 09:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:20:11 --> Total execution time: 0.0334
DEBUG - 2022-06-02 09:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:20:13 --> Total execution time: 0.0515
DEBUG - 2022-06-02 09:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:20:16 --> Total execution time: 0.0260
DEBUG - 2022-06-02 09:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:20:20 --> Total execution time: 0.0383
DEBUG - 2022-06-02 09:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:20:22 --> Total execution time: 0.0299
DEBUG - 2022-06-02 09:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:21:19 --> Total execution time: 0.0346
DEBUG - 2022-06-02 09:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:21:46 --> Total execution time: 0.0836
DEBUG - 2022-06-02 09:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:53:10 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:23:10 --> Total execution time: 0.0316
DEBUG - 2022-06-02 09:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:53:10 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:23:10 --> Total execution time: 0.0233
DEBUG - 2022-06-02 09:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:23:16 --> Total execution time: 0.0237
DEBUG - 2022-06-02 09:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:23:54 --> Total execution time: 0.0248
DEBUG - 2022-06-02 09:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:24:21 --> Total execution time: 0.0310
DEBUG - 2022-06-02 09:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:24:22 --> Total execution time: 0.0254
DEBUG - 2022-06-02 09:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:24:25 --> Total execution time: 0.0367
DEBUG - 2022-06-02 09:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:24:28 --> Total execution time: 0.0319
DEBUG - 2022-06-02 09:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:24:35 --> Total execution time: 0.0251
DEBUG - 2022-06-02 09:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:24:38 --> Total execution time: 0.0464
DEBUG - 2022-06-02 09:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:24:40 --> Total execution time: 0.0334
DEBUG - 2022-06-02 09:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:24:43 --> Total execution time: 0.0292
DEBUG - 2022-06-02 09:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:24:48 --> Total execution time: 0.0301
DEBUG - 2022-06-02 09:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:25:18 --> Total execution time: 0.0258
DEBUG - 2022-06-02 09:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:25:31 --> Total execution time: 0.0269
DEBUG - 2022-06-02 09:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:25:39 --> Total execution time: 0.0251
DEBUG - 2022-06-02 09:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:25:40 --> Total execution time: 0.0218
DEBUG - 2022-06-02 09:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:25:45 --> Total execution time: 0.0271
DEBUG - 2022-06-02 09:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:25:46 --> Total execution time: 0.0259
DEBUG - 2022-06-02 09:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:26:12 --> Total execution time: 0.0216
DEBUG - 2022-06-02 09:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 09:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:26:55 --> Total execution time: 0.0478
DEBUG - 2022-06-02 09:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:28:07 --> Total execution time: 0.0754
DEBUG - 2022-06-02 09:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:28:13 --> Total execution time: 0.0308
DEBUG - 2022-06-02 09:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:28:20 --> Total execution time: 0.0320
DEBUG - 2022-06-02 09:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:28:29 --> Total execution time: 0.0482
DEBUG - 2022-06-02 09:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:59:13 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:29:13 --> Total execution time: 0.0245
DEBUG - 2022-06-02 09:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:59:16 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:29:16 --> Total execution time: 0.0329
DEBUG - 2022-06-02 09:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:59:33 --> No URI present. Default controller set.
DEBUG - 2022-06-02 09:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:29:33 --> Total execution time: 0.0228
DEBUG - 2022-06-02 09:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 09:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:29:42 --> Total execution time: 1.4861
DEBUG - 2022-06-02 09:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 09:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 09:59:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 10:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:30:03 --> Total execution time: 0.0346
DEBUG - 2022-06-02 10:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:00:03 --> Total execution time: 0.0448
DEBUG - 2022-06-02 10:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:00:07 --> Total execution time: 0.0654
DEBUG - 2022-06-02 10:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:00:07 --> Total execution time: 0.1276
DEBUG - 2022-06-02 10:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:01:04 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:31:04 --> Total execution time: 0.0222
DEBUG - 2022-06-02 10:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:01:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 10:01:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 10:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:04:27 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:34:27 --> Total execution time: 0.1533
DEBUG - 2022-06-02 10:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:34:40 --> Total execution time: 0.0297
DEBUG - 2022-06-02 10:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:34:43 --> Total execution time: 1.5885
DEBUG - 2022-06-02 10:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:35:02 --> Total execution time: 0.0356
DEBUG - 2022-06-02 10:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:05:02 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:35:02 --> Total execution time: 0.0251
DEBUG - 2022-06-02 10:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:05:03 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:35:03 --> Total execution time: 0.0293
DEBUG - 2022-06-02 10:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:35:38 --> Total execution time: 0.0855
DEBUG - 2022-06-02 10:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:35:48 --> Total execution time: 0.0532
DEBUG - 2022-06-02 10:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:35:59 --> Total execution time: 1.7410
DEBUG - 2022-06-02 10:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:36:24 --> Total execution time: 0.0383
DEBUG - 2022-06-02 10:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:36:31 --> Total execution time: 1.5055
DEBUG - 2022-06-02 10:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:36:38 --> Total execution time: 0.0510
DEBUG - 2022-06-02 10:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:36:46 --> Total execution time: 1.4843
DEBUG - 2022-06-02 10:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:07:28 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:37:28 --> Total execution time: 0.0295
DEBUG - 2022-06-02 10:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:09:23 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:39:23 --> Total execution time: 0.0412
DEBUG - 2022-06-02 10:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:39:23 --> Total execution time: 0.0216
DEBUG - 2022-06-02 10:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:39:24 --> Total execution time: 0.0285
DEBUG - 2022-06-02 10:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:10:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 10:10:30 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-06-02 10:10:30 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-02 10:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:10:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 10:10:31 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-02 10:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:10:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 10:10:31 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-02 10:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:10:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 10:10:32 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-02 10:10:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 10:10:32 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-02 10:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:10:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 10:10:32 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-02 10:10:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 10:10:32 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-02 10:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:18:55 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:48:55 --> Total execution time: 0.0832
DEBUG - 2022-06-02 10:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:18:56 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:48:56 --> Total execution time: 0.0216
DEBUG - 2022-06-02 10:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:49:01 --> Total execution time: 0.0270
DEBUG - 2022-06-02 10:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:49:06 --> Total execution time: 0.0487
DEBUG - 2022-06-02 10:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:49:12 --> Total execution time: 0.0266
DEBUG - 2022-06-02 10:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:19:36 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:49:36 --> Total execution time: 0.0220
DEBUG - 2022-06-02 10:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:49:41 --> Total execution time: 0.0197
DEBUG - 2022-06-02 10:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:49:46 --> Total execution time: 0.0312
DEBUG - 2022-06-02 10:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:16 --> Total execution time: 0.0427
DEBUG - 2022-06-02 10:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:24 --> Total execution time: 0.0328
DEBUG - 2022-06-02 10:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:28 --> Total execution time: 0.0429
DEBUG - 2022-06-02 10:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:29 --> Total execution time: 0.0333
DEBUG - 2022-06-02 10:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:41 --> Total execution time: 0.0292
DEBUG - 2022-06-02 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:42 --> Total execution time: 0.0297
DEBUG - 2022-06-02 10:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:44 --> Total execution time: 0.0315
DEBUG - 2022-06-02 10:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:49 --> Total execution time: 0.0316
DEBUG - 2022-06-02 10:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:53 --> Total execution time: 0.0309
DEBUG - 2022-06-02 10:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:59 --> Total execution time: 0.0312
DEBUG - 2022-06-02 10:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:59 --> Total execution time: 0.0295
DEBUG - 2022-06-02 10:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:51:56 --> Total execution time: 0.0308
DEBUG - 2022-06-02 10:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:22:00 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:52:00 --> Total execution time: 0.0290
DEBUG - 2022-06-02 10:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:52:09 --> Total execution time: 0.0268
DEBUG - 2022-06-02 10:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:52:20 --> Total execution time: 0.0252
DEBUG - 2022-06-02 10:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:52:29 --> Total execution time: 0.0386
DEBUG - 2022-06-02 10:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:52:30 --> Total execution time: 0.0277
DEBUG - 2022-06-02 10:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:52:32 --> Total execution time: 0.0282
DEBUG - 2022-06-02 10:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:22:34 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:52:34 --> Total execution time: 0.0298
DEBUG - 2022-06-02 10:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:52:44 --> Total execution time: 0.0259
DEBUG - 2022-06-02 10:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:53:02 --> Total execution time: 0.0253
DEBUG - 2022-06-02 10:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:58:19 --> Total execution time: 0.0879
DEBUG - 2022-06-02 10:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:31:12 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:01:12 --> Total execution time: 0.0780
DEBUG - 2022-06-02 10:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:31:13 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:01:13 --> Total execution time: 0.0310
DEBUG - 2022-06-02 10:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:31:13 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:01:13 --> Total execution time: 0.0235
DEBUG - 2022-06-02 10:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:01:15 --> Total execution time: 0.0262
DEBUG - 2022-06-02 10:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:01:15 --> Total execution time: 0.0252
DEBUG - 2022-06-02 10:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:01:17 --> Total execution time: 0.0289
DEBUG - 2022-06-02 10:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:02:48 --> Total execution time: 0.0610
DEBUG - 2022-06-02 10:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:34:03 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:04:03 --> Total execution time: 0.0241
DEBUG - 2022-06-02 10:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:34:11 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:04:11 --> Total execution time: 0.0257
DEBUG - 2022-06-02 10:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:34:13 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:04:13 --> Total execution time: 0.0230
DEBUG - 2022-06-02 10:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:04:17 --> Total execution time: 0.0328
DEBUG - 2022-06-02 10:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:04:26 --> Total execution time: 0.0376
DEBUG - 2022-06-02 10:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:04:31 --> Total execution time: 0.0302
DEBUG - 2022-06-02 10:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:04:35 --> Total execution time: 0.0566
DEBUG - 2022-06-02 10:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:04:41 --> Total execution time: 0.0267
DEBUG - 2022-06-02 10:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:35:04 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:05:04 --> Total execution time: 0.0327
DEBUG - 2022-06-02 10:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:35:04 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:05:04 --> Total execution time: 0.0232
DEBUG - 2022-06-02 10:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:06:22 --> Total execution time: 0.0283
DEBUG - 2022-06-02 10:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:06:54 --> Total execution time: 0.0358
DEBUG - 2022-06-02 10:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:37:51 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:07:52 --> Total execution time: 0.0454
DEBUG - 2022-06-02 10:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:08:00 --> Total execution time: 0.0324
DEBUG - 2022-06-02 10:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:08:29 --> Total execution time: 0.0552
DEBUG - 2022-06-02 10:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:08:40 --> Total execution time: 0.0297
DEBUG - 2022-06-02 10:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:38:44 --> Total execution time: 0.0612
DEBUG - 2022-06-02 10:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:08:44 --> Total execution time: 0.0914
DEBUG - 2022-06-02 10:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:08:47 --> Total execution time: 0.0309
DEBUG - 2022-06-02 10:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:08:47 --> Total execution time: 0.0406
DEBUG - 2022-06-02 10:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:09:02 --> Total execution time: 0.0508
DEBUG - 2022-06-02 10:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:09:04 --> Total execution time: 0.0316
DEBUG - 2022-06-02 10:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:09:11 --> Total execution time: 0.0590
DEBUG - 2022-06-02 10:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:09:47 --> Total execution time: 0.0292
DEBUG - 2022-06-02 10:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:09:53 --> Total execution time: 0.0595
DEBUG - 2022-06-02 10:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:09:59 --> Total execution time: 0.0593
DEBUG - 2022-06-02 10:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:10:07 --> Total execution time: 0.0483
DEBUG - 2022-06-02 10:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:10:29 --> Total execution time: 0.0265
DEBUG - 2022-06-02 10:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:11:24 --> Total execution time: 0.0272
DEBUG - 2022-06-02 10:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:11:37 --> Total execution time: 0.0274
DEBUG - 2022-06-02 10:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:42:21 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:12:21 --> Total execution time: 0.0248
DEBUG - 2022-06-02 10:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:44:55 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:14:55 --> Total execution time: 0.0921
DEBUG - 2022-06-02 10:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:17:43 --> Total execution time: 0.0281
DEBUG - 2022-06-02 10:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:18:00 --> Total execution time: 0.0329
DEBUG - 2022-06-02 10:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:18:07 --> Total execution time: 0.0383
DEBUG - 2022-06-02 10:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:18:09 --> Total execution time: 0.0354
DEBUG - 2022-06-02 10:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:18:13 --> Total execution time: 0.0345
DEBUG - 2022-06-02 10:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:48:29 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:18:29 --> Total execution time: 0.0370
DEBUG - 2022-06-02 10:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:18:31 --> Total execution time: 0.0316
DEBUG - 2022-06-02 10:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:18:34 --> Total execution time: 0.0306
DEBUG - 2022-06-02 10:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:18:37 --> Total execution time: 0.0299
DEBUG - 2022-06-02 10:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:18:47 --> Total execution time: 0.0363
DEBUG - 2022-06-02 10:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:19:18 --> Total execution time: 0.0426
DEBUG - 2022-06-02 10:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:51:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 10:51:37 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 10:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:51:38 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:21:38 --> Total execution time: 0.0771
DEBUG - 2022-06-02 10:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:55:40 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:25:40 --> Total execution time: 0.0905
DEBUG - 2022-06-02 10:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:27:43 --> Total execution time: 0.1030
DEBUG - 2022-06-02 10:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:57:46 --> No URI present. Default controller set.
DEBUG - 2022-06-02 10:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:27:46 --> Total execution time: 0.0184
DEBUG - 2022-06-02 10:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:29:33 --> Total execution time: 0.0286
DEBUG - 2022-06-02 10:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 10:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 10:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 10:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:29:41 --> Total execution time: 0.0382
DEBUG - 2022-06-02 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:30:02 --> Total execution time: 0.0513
DEBUG - 2022-06-02 11:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:30:29 --> Total execution time: 0.0294
DEBUG - 2022-06-02 11:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:30:54 --> Total execution time: 0.0297
DEBUG - 2022-06-02 11:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:00:55 --> No URI present. Default controller set.
DEBUG - 2022-06-02 11:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:30:55 --> Total execution time: 0.0280
DEBUG - 2022-06-02 11:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:30:58 --> Total execution time: 0.0353
DEBUG - 2022-06-02 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:31:11 --> Total execution time: 0.0653
DEBUG - 2022-06-02 11:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:31:22 --> Total execution time: 0.0611
DEBUG - 2022-06-02 11:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:31:28 --> Total execution time: 0.0324
DEBUG - 2022-06-02 11:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:31:30 --> Total execution time: 0.0427
DEBUG - 2022-06-02 11:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:31:33 --> Total execution time: 0.0366
DEBUG - 2022-06-02 11:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:31:36 --> Total execution time: 0.0343
DEBUG - 2022-06-02 11:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:32:08 --> Total execution time: 0.0678
DEBUG - 2022-06-02 11:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:33:00 --> Total execution time: 0.0296
DEBUG - 2022-06-02 11:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:03:03 --> No URI present. Default controller set.
DEBUG - 2022-06-02 11:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:33:03 --> Total execution time: 0.0576
DEBUG - 2022-06-02 11:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:35:59 --> Total execution time: 0.0283
DEBUG - 2022-06-02 11:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:36:29 --> Total execution time: 0.0363
DEBUG - 2022-06-02 11:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:36:36 --> Total execution time: 0.1106
DEBUG - 2022-06-02 11:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:37:00 --> Total execution time: 0.0711
DEBUG - 2022-06-02 11:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:37:08 --> Total execution time: 0.0309
DEBUG - 2022-06-02 11:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:37:57 --> Total execution time: 0.0682
DEBUG - 2022-06-02 11:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:37:59 --> Total execution time: 0.0326
DEBUG - 2022-06-02 11:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:38:20 --> Total execution time: 0.0484
DEBUG - 2022-06-02 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 11:10:20 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:10:20 --> No URI present. Default controller set.
DEBUG - 2022-06-02 11:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:40:20 --> Total execution time: 0.0487
DEBUG - 2022-06-02 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:10:20 --> No URI present. Default controller set.
DEBUG - 2022-06-02 11:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:40:20 --> Total execution time: 0.0190
DEBUG - 2022-06-02 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:11:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 11:11:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 11:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:11:16 --> No URI present. Default controller set.
DEBUG - 2022-06-02 11:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:41:16 --> Total execution time: 0.0222
DEBUG - 2022-06-02 11:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:41:51 --> Total execution time: 0.0341
DEBUG - 2022-06-02 11:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:41:59 --> Total execution time: 0.0317
DEBUG - 2022-06-02 11:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:42:01 --> Total execution time: 0.0816
DEBUG - 2022-06-02 11:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:42:20 --> Total execution time: 0.0348
DEBUG - 2022-06-02 11:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:42:29 --> Total execution time: 0.0336
DEBUG - 2022-06-02 11:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:42:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-02 11:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:42:30 --> Total execution time: 0.0267
DEBUG - 2022-06-02 11:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:43:16 --> Total execution time: 0.0327
DEBUG - 2022-06-02 11:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:43:32 --> Total execution time: 0.0282
DEBUG - 2022-06-02 11:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:43:37 --> Total execution time: 0.0319
DEBUG - 2022-06-02 11:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:43:46 --> Total execution time: 0.0669
DEBUG - 2022-06-02 11:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:43:54 --> Total execution time: 0.0300
DEBUG - 2022-06-02 11:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:44:04 --> Total execution time: 0.0462
DEBUG - 2022-06-02 11:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:45:40 --> Total execution time: 0.0225
DEBUG - 2022-06-02 11:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:28:36 --> No URI present. Default controller set.
DEBUG - 2022-06-02 11:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:58:36 --> Total execution time: 0.0849
DEBUG - 2022-06-02 11:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:00:09 --> Total execution time: 0.0560
DEBUG - 2022-06-02 11:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:01:38 --> Total execution time: 0.0221
DEBUG - 2022-06-02 11:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:34:21 --> No URI present. Default controller set.
DEBUG - 2022-06-02 11:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:04:22 --> Total execution time: 0.0929
DEBUG - 2022-06-02 11:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:36:14 --> No URI present. Default controller set.
DEBUG - 2022-06-02 11:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:06:14 --> Total execution time: 0.0226
DEBUG - 2022-06-02 11:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:36:35 --> No URI present. Default controller set.
DEBUG - 2022-06-02 11:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:06:35 --> Total execution time: 0.0309
DEBUG - 2022-06-02 11:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:37:40 --> No URI present. Default controller set.
DEBUG - 2022-06-02 11:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:07:40 --> Total execution time: 0.0232
DEBUG - 2022-06-02 11:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:38:07 --> No URI present. Default controller set.
DEBUG - 2022-06-02 11:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:08:07 --> Total execution time: 0.0303
DEBUG - 2022-06-02 11:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:38:12 --> No URI present. Default controller set.
DEBUG - 2022-06-02 11:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:08:12 --> Total execution time: 0.0323
DEBUG - 2022-06-02 11:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 11:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:20:16 --> Total execution time: 0.0269
DEBUG - 2022-06-02 11:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 11:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 11:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:23:51 --> Total execution time: 0.0698
DEBUG - 2022-06-02 12:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:30:04 --> Total execution time: 0.1366
DEBUG - 2022-06-02 12:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:00:22 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:30:22 --> Total execution time: 0.0237
DEBUG - 2022-06-02 12:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:04:51 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:34:51 --> Total execution time: 0.0913
DEBUG - 2022-06-02 12:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:38:04 --> Total execution time: 0.0984
DEBUG - 2022-06-02 12:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:08:11 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:38:11 --> Total execution time: 0.0235
DEBUG - 2022-06-02 12:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:08:12 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:38:12 --> Total execution time: 0.0296
DEBUG - 2022-06-02 12:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:08:15 --> Total execution time: 0.0278
DEBUG - 2022-06-02 12:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:10:21 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:40:21 --> Total execution time: 0.0512
DEBUG - 2022-06-02 12:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:40:24 --> Total execution time: 0.0266
DEBUG - 2022-06-02 12:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:40:33 --> Total execution time: 0.0232
DEBUG - 2022-06-02 12:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:11:43 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:41:43 --> Total execution time: 0.0289
DEBUG - 2022-06-02 12:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 12:12:09 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 12:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:42:50 --> Total execution time: 0.0895
DEBUG - 2022-06-02 12:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:45:06 --> Total execution time: 0.1082
DEBUG - 2022-06-02 12:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:45:27 --> Total execution time: 0.0312
DEBUG - 2022-06-02 12:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:45:30 --> Total execution time: 0.0340
DEBUG - 2022-06-02 12:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:45:32 --> Total execution time: 0.0338
DEBUG - 2022-06-02 12:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:45:35 --> Total execution time: 0.0401
DEBUG - 2022-06-02 12:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:45:56 --> Total execution time: 0.0287
DEBUG - 2022-06-02 12:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:16:00 --> Total execution time: 0.0274
DEBUG - 2022-06-02 12:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:46:09 --> Total execution time: 0.0489
DEBUG - 2022-06-02 12:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:16:50 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:46:50 --> Total execution time: 0.0267
DEBUG - 2022-06-02 12:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:16:51 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:46:51 --> Total execution time: 0.0158
DEBUG - 2022-06-02 12:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:46:53 --> Total execution time: 0.0217
DEBUG - 2022-06-02 12:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:46:58 --> Total execution time: 0.0233
DEBUG - 2022-06-02 12:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:47:05 --> Total execution time: 0.0611
DEBUG - 2022-06-02 12:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:17:13 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:47:13 --> Total execution time: 0.0167
DEBUG - 2022-06-02 12:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:47:17 --> Total execution time: 0.0428
DEBUG - 2022-06-02 12:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:47:22 --> Total execution time: 0.0373
DEBUG - 2022-06-02 12:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:47:31 --> Total execution time: 0.0219
DEBUG - 2022-06-02 12:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:47:36 --> Total execution time: 0.0300
DEBUG - 2022-06-02 12:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:47:46 --> Total execution time: 0.0282
DEBUG - 2022-06-02 12:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:47:57 --> Total execution time: 0.0575
DEBUG - 2022-06-02 12:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:48:14 --> Total execution time: 0.0364
DEBUG - 2022-06-02 12:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:48:18 --> Total execution time: 0.0252
DEBUG - 2022-06-02 12:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:48:21 --> Total execution time: 0.0272
DEBUG - 2022-06-02 12:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:50:31 --> Total execution time: 0.0999
DEBUG - 2022-06-02 12:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:51:00 --> Total execution time: 0.0354
DEBUG - 2022-06-02 12:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:51:07 --> Total execution time: 0.0366
DEBUG - 2022-06-02 12:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:51:08 --> Total execution time: 0.0641
DEBUG - 2022-06-02 12:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:51:23 --> Total execution time: 0.0383
DEBUG - 2022-06-02 12:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:51:41 --> Total execution time: 0.0317
DEBUG - 2022-06-02 12:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 12:22:01 --> 404 Page Not Found: Apple-app-site-association/index
DEBUG - 2022-06-02 12:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 12:24:01 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-06-02 12:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:27:23 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:57:23 --> Total execution time: 0.1087
DEBUG - 2022-06-02 12:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:57:35 --> Total execution time: 1.5737
DEBUG - 2022-06-02 12:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:57:36 --> Total execution time: 0.0606
DEBUG - 2022-06-02 12:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:27:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 12:27:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 12:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:27:47 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:57:47 --> Total execution time: 0.0394
DEBUG - 2022-06-02 12:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 12:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:01:26 --> Total execution time: 0.0366
DEBUG - 2022-06-02 12:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:40:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 12:40:50 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 12:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:40:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 12:40:51 --> 404 Page Not Found: Humanstxt/index
DEBUG - 2022-06-02 12:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:40:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 12:40:51 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-02 12:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:40:53 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:10:53 --> Total execution time: 0.0948
DEBUG - 2022-06-02 12:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:43:06 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:13:06 --> Total execution time: 0.0774
DEBUG - 2022-06-02 12:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:51:28 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:21:28 --> Total execution time: 0.0954
DEBUG - 2022-06-02 12:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 12:55:33 --> No URI present. Default controller set.
DEBUG - 2022-06-02 12:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 12:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:25:33 --> Total execution time: 0.0714
DEBUG - 2022-06-02 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:30:03 --> Total execution time: 0.1483
DEBUG - 2022-06-02 13:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:32:23 --> Total execution time: 0.0711
DEBUG - 2022-06-02 13:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:32:38 --> Total execution time: 0.0650
DEBUG - 2022-06-02 13:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:32:44 --> Total execution time: 0.0501
DEBUG - 2022-06-02 13:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:32:48 --> Total execution time: 0.0408
DEBUG - 2022-06-02 13:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:32:51 --> Total execution time: 0.0303
DEBUG - 2022-06-02 13:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:32:53 --> Total execution time: 0.0614
DEBUG - 2022-06-02 13:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:33:03 --> Total execution time: 0.0307
DEBUG - 2022-06-02 13:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:33:05 --> Total execution time: 0.0397
DEBUG - 2022-06-02 13:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:16:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 13:16:10 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 13:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:16:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 13:16:12 --> 404 Page Not Found: Lessons/add-someone-in-your-facebook
DEBUG - 2022-06-02 13:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:20:53 --> No URI present. Default controller set.
DEBUG - 2022-06-02 13:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:50:53 --> Total execution time: 0.0934
DEBUG - 2022-06-02 13:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 13:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 13:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 13:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:01:32 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:06:55 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:10:45 --> Total execution time: 0.0214
DEBUG - 2022-06-02 14:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:13:38 --> Total execution time: 0.0413
DEBUG - 2022-06-02 14:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:17:25 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:22:30 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:22:37 --> Total execution time: 0.0218
DEBUG - 2022-06-02 14:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:22:41 --> Total execution time: 0.0430
DEBUG - 2022-06-02 14:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:22:41 --> Total execution time: 0.0682
DEBUG - 2022-06-02 14:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:23:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 14:23:44 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 14:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:24:02 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:24:24 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:24:39 --> Total execution time: 0.0303
DEBUG - 2022-06-02 14:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:24:42 --> Total execution time: 0.0407
DEBUG - 2022-06-02 14:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:24:42 --> Total execution time: 0.0459
DEBUG - 2022-06-02 14:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:26:15 --> Total execution time: 0.0266
DEBUG - 2022-06-02 14:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:26:18 --> Total execution time: 0.0310
DEBUG - 2022-06-02 14:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:26:18 --> Total execution time: 0.0260
DEBUG - 2022-06-02 14:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:26:27 --> Total execution time: 0.0203
DEBUG - 2022-06-02 14:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:26:30 --> Total execution time: 0.0232
DEBUG - 2022-06-02 14:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:26:30 --> Total execution time: 0.0339
DEBUG - 2022-06-02 14:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:29:35 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:30:18 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:32:03 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:32:10 --> Total execution time: 0.0356
DEBUG - 2022-06-02 14:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:32:10 --> Total execution time: 0.0282
DEBUG - 2022-06-02 14:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:32:11 --> Total execution time: 0.0279
DEBUG - 2022-06-02 14:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:32:11 --> Total execution time: 0.0514
DEBUG - 2022-06-02 14:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:33:04 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:38:57 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:39:27 --> Total execution time: 0.0503
DEBUG - 2022-06-02 14:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:39:28 --> Total execution time: 0.0389
DEBUG - 2022-06-02 14:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:39:28 --> Total execution time: 0.0539
DEBUG - 2022-06-02 14:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:39:57 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:40:05 --> Total execution time: 0.0269
DEBUG - 2022-06-02 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:40:06 --> Total execution time: 0.0321
DEBUG - 2022-06-02 14:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:40:06 --> Total execution time: 0.0513
DEBUG - 2022-06-02 14:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:40:38 --> Total execution time: 0.0459
DEBUG - 2022-06-02 14:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:40:39 --> Total execution time: 0.0331
DEBUG - 2022-06-02 14:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:40:39 --> Total execution time: 0.0356
DEBUG - 2022-06-02 14:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:42:12 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:44:58 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:45:15 --> No URI present. Default controller set.
DEBUG - 2022-06-02 14:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:46:07 --> Total execution time: 0.0652
DEBUG - 2022-06-02 14:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:46:08 --> Total execution time: 0.0327
DEBUG - 2022-06-02 14:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:46:08 --> Total execution time: 0.0641
DEBUG - 2022-06-02 14:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 14:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 14:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 14:52:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 14:52:17 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-02 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 15:03:11 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-02 15:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:12:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 15:12:23 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-02 15:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:19:29 --> No URI present. Default controller set.
DEBUG - 2022-06-02 15:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 15:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 15:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 15:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 15:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 15:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 15:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:28:56 --> No URI present. Default controller set.
DEBUG - 2022-06-02 15:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 15:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:29:00 --> No URI present. Default controller set.
DEBUG - 2022-06-02 15:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 15:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 15:29:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 15:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 15:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 15:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 15:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 15:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 15:42:52 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 15:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:43:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 15:43:00 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 15:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:43:04 --> No URI present. Default controller set.
DEBUG - 2022-06-02 15:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 15:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 15:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:51:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 15:51:55 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 15:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 15:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 15:56:32 --> 404 Page Not Found: Login/index
DEBUG - 2022-06-02 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:36:51 --> No URI present. Default controller set.
DEBUG - 2022-06-02 16:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:52:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 16:52:40 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-02 16:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 16:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 16:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 16:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:07:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 17:07:28 --> 404 Page Not Found: Home-1/index
DEBUG - 2022-06-02 17:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:07:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 17:07:28 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 17:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 17:14:57 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 17:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:14:58 --> No URI present. Default controller set.
DEBUG - 2022-06-02 17:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 17:35:07 --> 404 Page Not Found: Teacher/roman-eithne
DEBUG - 2022-06-02 17:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:20 --> Total execution time: 0.0271
DEBUG - 2022-06-02 17:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:24 --> Total execution time: 0.0264
DEBUG - 2022-06-02 17:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:45:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 17:45:49 --> 404 Page Not Found: Wp-sitemap-posts-lp_course-1xml/index
DEBUG - 2022-06-02 17:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 17:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 17:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 17:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 18:18:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 18:18:32 --> 404 Page Not Found: Courses/index
DEBUG - 2022-06-02 18:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 18:30:58 --> No URI present. Default controller set.
DEBUG - 2022-06-02 18:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 18:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 18:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 18:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 18:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 18:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 18:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 18:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 18:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 18:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 18:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 18:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 18:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 18:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 18:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 18:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 18:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:01:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 19:01:57 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 19:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 19:14:24 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 19:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 19:14:24 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-02 19:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:23:20 --> No URI present. Default controller set.
DEBUG - 2022-06-02 19:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:27:01 --> No URI present. Default controller set.
DEBUG - 2022-06-02 19:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:27:02 --> No URI present. Default controller set.
DEBUG - 2022-06-02 19:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:28:54 --> No URI present. Default controller set.
DEBUG - 2022-06-02 19:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:29:41 --> Total execution time: 0.0264
DEBUG - 2022-06-02 19:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:46:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 19:46:17 --> 404 Page Not Found: Wp-sitemap-taxonomies-category-1xml/index
DEBUG - 2022-06-02 19:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:53:50 --> No URI present. Default controller set.
DEBUG - 2022-06-02 19:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:53:51 --> No URI present. Default controller set.
DEBUG - 2022-06-02 19:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:54:14 --> No URI present. Default controller set.
DEBUG - 2022-06-02 19:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:54:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 19:54:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 19:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:54:20 --> No URI present. Default controller set.
DEBUG - 2022-06-02 19:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:54:59 --> Total execution time: 0.0471
DEBUG - 2022-06-02 19:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 19:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 19:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 19:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:00:42 --> Total execution time: 0.0468
DEBUG - 2022-06-02 20:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:02:15 --> Total execution time: 0.0408
DEBUG - 2022-06-02 20:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:02:52 --> Total execution time: 0.0799
DEBUG - 2022-06-02 20:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:12:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 20:12:31 --> 404 Page Not Found: Shop/index
DEBUG - 2022-06-02 20:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:20:48 --> No URI present. Default controller set.
DEBUG - 2022-06-02 20:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:28:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 20:28:53 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-02 20:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:35:02 --> No URI present. Default controller set.
DEBUG - 2022-06-02 20:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:57:18 --> No URI present. Default controller set.
DEBUG - 2022-06-02 20:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 20:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 20:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 20:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:01:01 --> No URI present. Default controller set.
DEBUG - 2022-06-02 21:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:01:36 --> No URI present. Default controller set.
DEBUG - 2022-06-02 21:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:01:36 --> No URI present. Default controller set.
DEBUG - 2022-06-02 21:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:01:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 21:01:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 21:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:03:57 --> No URI present. Default controller set.
DEBUG - 2022-06-02 21:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 21:04:08 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 21:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:04:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 21:04:09 --> 404 Page Not Found: Asset-manifestjson/index
DEBUG - 2022-06-02 21:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:05:43 --> No URI present. Default controller set.
DEBUG - 2022-06-02 21:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:08:39 --> No URI present. Default controller set.
DEBUG - 2022-06-02 21:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:08:39 --> No URI present. Default controller set.
DEBUG - 2022-06-02 21:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:08:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 21:08:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-02 21:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:11:05 --> No URI present. Default controller set.
DEBUG - 2022-06-02 21:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:13:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 21:13:17 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-02 21:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:29:07 --> No URI present. Default controller set.
DEBUG - 2022-06-02 21:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:42:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 21:42:03 --> 404 Page Not Found: Wp-plainphp/index
DEBUG - 2022-06-02 21:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:42:10 --> No URI present. Default controller set.
DEBUG - 2022-06-02 21:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:42:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 21:42:36 --> 404 Page Not Found: Kukrgkygphp/index
DEBUG - 2022-06-02 21:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 21:42:48 --> 404 Page Not Found: Wp-plainphp/index
DEBUG - 2022-06-02 21:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:43:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 21:43:03 --> 404 Page Not Found: Kukrgkygphp/index
DEBUG - 2022-06-02 21:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:45:07 --> No URI present. Default controller set.
DEBUG - 2022-06-02 21:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:51:32 --> No URI present. Default controller set.
DEBUG - 2022-06-02 21:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:58:39 --> No URI present. Default controller set.
DEBUG - 2022-06-02 21:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:59:42 --> No URI present. Default controller set.
DEBUG - 2022-06-02 21:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:59:49 --> Total execution time: 0.0382
DEBUG - 2022-06-02 21:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 21:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 21:59:51 --> Total execution time: 0.0535
DEBUG - 2022-06-02 21:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 21:59:51 --> Total execution time: 0.0452
DEBUG - 2022-06-02 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:00:13 --> No URI present. Default controller set.
DEBUG - 2022-06-02 22:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:00:15 --> No URI present. Default controller set.
DEBUG - 2022-06-02 22:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:01:50 --> Total execution time: 0.0379
DEBUG - 2022-06-02 22:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:01:54 --> Total execution time: 0.1028
DEBUG - 2022-06-02 22:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:02:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 22:02:42 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-02 22:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:08:00 --> No URI present. Default controller set.
DEBUG - 2022-06-02 22:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:12:35 --> No URI present. Default controller set.
DEBUG - 2022-06-02 22:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:12:35 --> No URI present. Default controller set.
DEBUG - 2022-06-02 22:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:13:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 22:13:16 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-02 22:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:16:29 --> No URI present. Default controller set.
DEBUG - 2022-06-02 22:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:17:03 --> No URI present. Default controller set.
DEBUG - 2022-06-02 22:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:17:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 22:17:41 --> 404 Page Not Found: Wp-sitemap-posts-event-1xml/index
DEBUG - 2022-06-02 22:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:18:54 --> No URI present. Default controller set.
DEBUG - 2022-06-02 22:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:19:22 --> No URI present. Default controller set.
DEBUG - 2022-06-02 22:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:23:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 22:23:23 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-02 22:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:24:59 --> No URI present. Default controller set.
DEBUG - 2022-06-02 22:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:29:38 --> No URI present. Default controller set.
DEBUG - 2022-06-02 22:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:30:12 --> No URI present. Default controller set.
DEBUG - 2022-06-02 22:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:37:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 22:37:15 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 22:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:37:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 22:37:18 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 22:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 22:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:56:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 22:56:19 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-06-02 22:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 22:59:39 --> No URI present. Default controller set.
DEBUG - 2022-06-02 22:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 22:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:08:02 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:08:03 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:09:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:09:08 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-02 23:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:12:19 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 23:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:12:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:12:43 --> 404 Page Not Found: Personal-branding-course/index
DEBUG - 2022-06-02 23:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:16:25 --> Total execution time: 0.0332
DEBUG - 2022-06-02 23:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:16:47 --> Total execution time: 0.0298
DEBUG - 2022-06-02 23:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:19:12 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:21:05 --> Total execution time: 0.0279
DEBUG - 2022-06-02 23:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:22:00 --> Total execution time: 0.0542
DEBUG - 2022-06-02 23:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:22:13 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:22:30 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:22:54 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:22:58 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:23:46 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:23:55 --> Total execution time: 0.0351
DEBUG - 2022-06-02 23:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:23:57 --> Total execution time: 0.0305
DEBUG - 2022-06-02 23:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:23:57 --> Total execution time: 0.0534
DEBUG - 2022-06-02 23:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:24:00 --> Total execution time: 0.0263
DEBUG - 2022-06-02 23:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:24:01 --> Total execution time: 0.0397
DEBUG - 2022-06-02 23:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:24:01 --> Total execution time: 0.0545
DEBUG - 2022-06-02 23:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:25:42 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:03 --> Total execution time: 0.0284
DEBUG - 2022-06-02 23:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:05 --> Total execution time: 0.0355
DEBUG - 2022-06-02 23:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:05 --> Total execution time: 0.0593
DEBUG - 2022-06-02 23:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:26:45 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:51 --> Total execution time: 0.0449
DEBUG - 2022-06-02 23:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:26:52 --> Total execution time: 0.0336
DEBUG - 2022-06-02 23:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:26:52 --> Total execution time: 0.0409
DEBUG - 2022-06-02 23:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:27:14 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-02 23:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:27:55 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:34:23 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:36:08 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:36:14 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:36:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:36:29 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-02 23:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:37:47 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:37:57 --> Total execution time: 0.0304
DEBUG - 2022-06-02 23:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:37:58 --> Total execution time: 0.0309
DEBUG - 2022-06-02 23:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:37:58 --> Total execution time: 0.0346
DEBUG - 2022-06-02 23:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:38:54 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:41:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:41:47 --> 404 Page Not Found: Fwphp/index
DEBUG - 2022-06-02 23:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:42:21 --> 404 Page Not Found: FfAA531php/index
DEBUG - 2022-06-02 23:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:42:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:42:39 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-02 23:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:42:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:42:47 --> 404 Page Not Found: Old-indexphp/index
DEBUG - 2022-06-02 23:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:43:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:43:20 --> 404 Page Not Found: Xleet-shellphp/index
DEBUG - 2022-06-02 23:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:43:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:43:56 --> 404 Page Not Found: Wp-vatvaphp/index
DEBUG - 2022-06-02 23:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:44:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:44:21 --> 404 Page Not Found: Wp-2019php/index
DEBUG - 2022-06-02 23:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:44:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:44:36 --> 404 Page Not Found: Vabbaphp/index
DEBUG - 2022-06-02 23:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:45:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:45:18 --> 404 Page Not Found: Inbexwphp/index
DEBUG - 2022-06-02 23:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:45:54 --> 404 Page Not Found: Qwsphp/index
DEBUG - 2022-06-02 23:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:46:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:46:52 --> 404 Page Not Found: Wp-content/31cx4.php
DEBUG - 2022-06-02 23:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:47:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:47:19 --> 404 Page Not Found: Shell20211028php/index
DEBUG - 2022-06-02 23:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:47:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:47:38 --> 404 Page Not Found: 1indexphp/index
DEBUG - 2022-06-02 23:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:48:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:48:01 --> 404 Page Not Found: Autoload_classmapphp/index
DEBUG - 2022-06-02 23:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:48:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:48:26 --> 404 Page Not Found: Radiophp/index
DEBUG - 2022-06-02 23:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:49:20 --> 404 Page Not Found: Contentphp/index
DEBUG - 2022-06-02 23:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:49:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-02 23:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:49:26 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:49:37 --> 404 Page Not Found: New-indexphp/index
DEBUG - 2022-06-02 23:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:50:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:50:05 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-02 23:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:50:07 --> 404 Page Not Found: Wp-includes/wp-class.php
DEBUG - 2022-06-02 23:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:50:27 --> 404 Page Not Found: Wp-includes/images
DEBUG - 2022-06-02 23:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:50:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:50:50 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-02 23:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:50:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:50:54 --> 404 Page Not Found: Wp-content/languages
DEBUG - 2022-06-02 23:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:51:00 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-02 23:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:51:29 --> 404 Page Not Found: Wp-includes/Text
DEBUG - 2022-06-02 23:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:53:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:53:25 --> 404 Page Not Found: Wp-includes/images
DEBUG - 2022-06-02 23:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:54:02 --> 404 Page Not Found: Wp-includes/images
DEBUG - 2022-06-02 23:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:55:14 --> No URI present. Default controller set.
DEBUG - 2022-06-02 23:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:55:16 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 23:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:56:18 --> Total execution time: 0.0245
DEBUG - 2022-06-02 23:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-02 23:56:20 --> Total execution time: 0.0511
DEBUG - 2022-06-02 23:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-02 23:56:20 --> Total execution time: 0.0553
DEBUG - 2022-06-02 23:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:56:49 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-02 23:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:57:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:57:10 --> 404 Page Not Found: Cgi-etc/quti.php
DEBUG - 2022-06-02 23:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-02 23:58:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-02 23:58:42 --> 404 Page Not Found: Qindexphp/index
