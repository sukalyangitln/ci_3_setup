<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-11 03:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 03:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 03:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 04:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:56:07 --> No URI present. Default controller set.
DEBUG - 2022-05-11 04:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 10:26:08 --> Total execution time: 1.0911
DEBUG - 2022-05-11 04:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:57:19 --> No URI present. Default controller set.
DEBUG - 2022-05-11 04:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 10:27:20 --> Total execution time: 0.8365
DEBUG - 2022-05-11 04:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 10:29:14 --> Total execution time: 0.8236
DEBUG - 2022-05-11 04:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 04:59:18 --> Total execution time: 0.0395
DEBUG - 2022-05-11 04:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 10:29:29 --> Total execution time: 0.0298
DEBUG - 2022-05-11 09:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 14:36:19 --> Total execution time: 1.1090
DEBUG - 2022-05-11 09:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 14:38:58 --> Total execution time: 0.0301
DEBUG - 2022-05-11 09:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 09:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 14:39:50 --> Total execution time: 0.0292
DEBUG - 2022-05-11 09:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 09:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 14:41:22 --> Total execution time: 0.0323
DEBUG - 2022-05-11 09:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 14:42:13 --> Total execution time: 0.0304
DEBUG - 2022-05-11 09:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 14:42:30 --> Total execution time: 0.0324
DEBUG - 2022-05-11 09:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 09:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 14:42:58 --> Total execution time: 0.0286
DEBUG - 2022-05-11 09:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 09:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 14:43:22 --> Total execution time: 0.0325
DEBUG - 2022-05-11 09:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 09:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 14:43:36 --> Total execution time: 0.0296
DEBUG - 2022-05-11 09:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 09:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 09:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 14:43:37 --> Total execution time: 0.0317
DEBUG - 2022-05-11 10:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 10:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 10:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 16:26:26 --> Total execution time: 1.0289
DEBUG - 2022-05-11 10:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 10:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 10:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 10:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 10:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 10:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 16:26:57 --> Total execution time: 0.0286
DEBUG - 2022-05-11 12:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 12:30:04 --> No URI present. Default controller set.
DEBUG - 2022-05-11 12:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 12:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 18:00:05 --> Total execution time: 0.8698
DEBUG - 2022-05-11 12:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 12:36:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 12:36:06 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF) /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 269
DEBUG - 2022-05-11 12:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 12:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 12:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 12:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 12:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 12:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 12:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 12:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 12:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 18:15:20 --> Total execution time: 52.2935
DEBUG - 2022-05-11 12:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 12:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 12:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 12:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 12:45:53 --> No URI present. Default controller set.
DEBUG - 2022-05-11 12:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 12:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 18:15:54 --> Total execution time: 0.8857
DEBUG - 2022-05-11 12:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 12:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 12:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 12:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 12:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 12:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 13:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 13:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:01:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
ERROR - 2022-05-11 18:31:41 --> Severity: Notice --> Uninitialized string offset: 1 /home/gvprods/public_html/v1/gvv3/application/controllers/User/Cron_Controller.php 264
DEBUG - 2022-05-11 13:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 13:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 13:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 13:21:34 --> Total execution time: 0.9139
DEBUG - 2022-05-11 13:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 13:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 18:51:45 --> Total execution time: 0.2000
DEBUG - 2022-05-11 13:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 18:51:53 --> Total execution time: 0.0734
DEBUG - 2022-05-11 13:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 18:52:04 --> Total execution time: 0.0414
DEBUG - 2022-05-11 13:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 13:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:14:43 --> Total execution time: 2.7334
DEBUG - 2022-05-11 13:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:17:08 --> Total execution time: 2.4050
DEBUG - 2022-05-11 13:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 13:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:18:49 --> Total execution time: 2.4332
DEBUG - 2022-05-11 13:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:19:11 --> Total execution time: 0.0831
DEBUG - 2022-05-11 13:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:19:33 --> Total execution time: 2.4833
DEBUG - 2022-05-11 13:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:19:55 --> Total execution time: 0.0423
DEBUG - 2022-05-11 13:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:21:36 --> Total execution time: 1.1110
DEBUG - 2022-05-11 13:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:22:19 --> Total execution time: 0.0648
DEBUG - 2022-05-11 13:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 13:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:22:32 --> Total execution time: 0.0917
DEBUG - 2022-05-11 13:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:22:38 --> Total execution time: 0.0537
DEBUG - 2022-05-11 13:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:59:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-11 19:29:22 --> Query error: Unknown column 'ord_product_price' in 'order clause' - Invalid query: SELECT *
FROM `products`
WHERE `product_price` >= '7900'
ORDER BY `ord_product_price` ASC
DEBUG - 2022-05-11 13:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 13:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 13:59:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-11 19:29:43 --> Severity: Notice --> Undefined property: stdClass::$ord_id /home/gvprods/public_html/v1/gvv3/application/views/User/my-courses.php 43
DEBUG - 2022-05-11 19:29:43 --> Total execution time: 0.0466
DEBUG - 2022-05-11 14:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 14:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 14:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:30:08 --> Total execution time: 0.0326
DEBUG - 2022-05-11 14:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 14:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 14:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 14:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 14:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 14:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:30:12 --> Total execution time: 0.0331
DEBUG - 2022-05-11 14:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 14:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 14:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:31:14 --> Total execution time: 0.0422
DEBUG - 2022-05-11 14:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 14:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 14:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:31:21 --> Total execution time: 0.0320
DEBUG - 2022-05-11 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 14:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 14:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:31:24 --> Total execution time: 0.0307
DEBUG - 2022-05-11 14:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 14:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 14:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:31:26 --> Total execution time: 0.0342
DEBUG - 2022-05-11 14:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 14:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 14:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:31:38 --> Total execution time: 0.8619
DEBUG - 2022-05-11 14:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 14:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 14:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:33:24 --> Total execution time: 0.0490
DEBUG - 2022-05-11 14:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 14:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 14:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 19:33:30 --> Total execution time: 0.0380
DEBUG - 2022-05-11 15:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 15:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 20:44:35 --> Total execution time: 0.1128
DEBUG - 2022-05-11 15:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 20:45:52 --> Total execution time: 0.9526
DEBUG - 2022-05-11 15:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 15:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 20:45:58 --> Total execution time: 0.0578
DEBUG - 2022-05-11 15:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 20:46:09 --> Total execution time: 0.0623
DEBUG - 2022-05-11 15:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 20:46:42 --> Total execution time: 2.7570
DEBUG - 2022-05-11 15:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 15:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 20:47:55 --> Total execution time: 0.0682
DEBUG - 2022-05-11 15:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 15:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 15:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 20:49:48 --> Total execution time: 0.9448
DEBUG - 2022-05-11 15:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 20:49:54 --> Total execution time: 0.0855
DEBUG - 2022-05-11 15:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 20:50:02 --> Total execution time: 1.0666
DEBUG - 2022-05-11 15:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 15:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 20:52:13 --> Total execution time: 0.1278
DEBUG - 2022-05-11 15:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 20:52:15 --> Total execution time: 0.0737
DEBUG - 2022-05-11 15:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 15:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 20:55:27 --> Total execution time: 0.0842
DEBUG - 2022-05-11 15:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 15:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 20:57:17 --> Total execution time: 0.0866
DEBUG - 2022-05-11 15:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 20:57:20 --> Total execution time: 0.0690
DEBUG - 2022-05-11 15:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 15:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 21:00:52 --> Total execution time: 0.0869
DEBUG - 2022-05-11 15:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 21:00:56 --> Total execution time: 0.0710
DEBUG - 2022-05-11 15:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 21:03:36 --> Total execution time: 1.0590
DEBUG - 2022-05-11 15:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:33:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:33:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:33:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:33:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:33:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:33:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:33:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:33:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 21:04:49 --> Total execution time: 0.9177
DEBUG - 2022-05-11 15:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:35:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:35:08 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-11 15:35:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:35:08 --> UTF-8 Support Enabled
ERROR - 2022-05-11 15:35:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:35:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:35:08 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-11 15:35:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:35:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:35:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:35:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:35:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:35:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:35:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 21:05:34 --> Total execution time: 0.8356
DEBUG - 2022-05-11 15:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 21:06:36 --> Total execution time: 1.1249
DEBUG - 2022-05-11 15:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:36:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:36:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:36:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:36:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:36:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:36:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:36:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:36:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:36:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:36:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:36:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:36:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:36:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:36:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:36:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 15:36:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-11 15:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 21:08:10 --> Total execution time: 0.8594
DEBUG - 2022-05-11 15:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 15:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 21:09:42 --> Total execution time: 0.8237
DEBUG - 2022-05-11 15:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 21:10:29 --> Total execution time: 0.8828
DEBUG - 2022-05-11 15:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 15:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 15:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 21:13:36 --> Total execution time: 0.9407
DEBUG - 2022-05-11 16:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:00:05 --> Total execution time: 1.1219
DEBUG - 2022-05-11 16:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:00:43 --> Total execution time: 0.0290
DEBUG - 2022-05-11 16:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 16:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:01:06 --> Total execution time: 0.0292
DEBUG - 2022-05-11 16:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 16:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:01:27 --> Total execution time: 0.0291
DEBUG - 2022-05-11 16:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 16:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:01:58 --> Total execution time: 0.0309
DEBUG - 2022-05-11 16:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 16:37:31 --> Total execution time: 0.2270
DEBUG - 2022-05-11 16:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 16:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:07:48 --> Total execution time: 0.0824
DEBUG - 2022-05-11 16:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:08:17 --> Total execution time: 2.6274
DEBUG - 2022-05-11 16:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:09:06 --> Total execution time: 0.0560
DEBUG - 2022-05-11 16:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 16:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:09:31 --> Total execution time: 0.5843
DEBUG - 2022-05-11 16:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:22:03 --> Total execution time: 0.9138
DEBUG - 2022-05-11 16:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:22:13 --> Total execution time: 0.0390
DEBUG - 2022-05-11 16:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:22:31 --> Total execution time: 0.0323
DEBUG - 2022-05-11 16:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:22:56 --> Total execution time: 2.3880
DEBUG - 2022-05-11 16:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:23:23 --> Total execution time: 0.2551
DEBUG - 2022-05-11 16:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:23:38 --> Total execution time: 0.0919
DEBUG - 2022-05-11 16:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 16:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 16:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:25:01 --> Total execution time: 0.0300
DEBUG - 2022-05-11 17:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:01:16 --> No URI present. Default controller set.
DEBUG - 2022-05-11 17:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:31:17 --> Total execution time: 0.8516
DEBUG - 2022-05-11 17:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:02:15 --> No URI present. Default controller set.
DEBUG - 2022-05-11 17:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:32:16 --> Total execution time: 0.8315
DEBUG - 2022-05-11 17:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:03:54 --> No URI present. Default controller set.
DEBUG - 2022-05-11 17:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:33:54 --> Total execution time: 0.0318
DEBUG - 2022-05-11 17:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:04:05 --> No URI present. Default controller set.
DEBUG - 2022-05-11 17:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:34:05 --> Total execution time: 0.0367
DEBUG - 2022-05-11 17:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:11:23 --> No URI present. Default controller set.
DEBUG - 2022-05-11 17:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:41:24 --> Total execution time: 0.8316
DEBUG - 2022-05-11 17:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:41:34 --> Total execution time: 0.0378
DEBUG - 2022-05-11 17:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 17:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:42:12 --> Total execution time: 0.0312
DEBUG - 2022-05-11 17:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 17:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:45:01 --> Total execution time: 0.0339
DEBUG - 2022-05-11 17:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:47:59 --> Total execution time: 2.4399
DEBUG - 2022-05-11 17:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:20:05 --> No URI present. Default controller set.
DEBUG - 2022-05-11 17:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:50:05 --> Total execution time: 0.1828
DEBUG - 2022-05-11 17:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 22:55:16 --> Total execution time: 0.1520
DEBUG - 2022-05-11 17:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 23:06:01 --> Total execution time: 0.8201
DEBUG - 2022-05-11 17:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 17:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 23:06:50 --> Total execution time: 0.0321
DEBUG - 2022-05-11 17:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 17:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 23:07:28 --> Total execution time: 0.0294
DEBUG - 2022-05-11 17:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 17:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 23:07:45 --> Total execution time: 0.0296
DEBUG - 2022-05-11 17:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 17:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 23:08:59 --> Total execution time: 0.0304
DEBUG - 2022-05-11 17:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 23:13:01 --> Total execution time: 0.0303
DEBUG - 2022-05-11 17:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 17:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 17:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 17:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 23:14:07 --> Total execution time: 0.0290
DEBUG - 2022-05-11 18:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 18:06:57 --> No URI present. Default controller set.
DEBUG - 2022-05-11 18:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 18:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 23:36:58 --> Total execution time: 0.9989
DEBUG - 2022-05-11 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 18:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 18:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-11 23:37:16 --> Total execution time: 0.0329
DEBUG - 2022-05-11 18:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 18:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 18:35:10 --> Encryption: Auto-configured driver 'openssl'.
