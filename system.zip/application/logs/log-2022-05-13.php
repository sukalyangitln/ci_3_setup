<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-13 05:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 05:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 05:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 10:37:44 --> Total execution time: 0.8634
DEBUG - 2022-05-13 05:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 05:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 05:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 10:37:49 --> Total execution time: 0.0334
DEBUG - 2022-05-13 05:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 05:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 05:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 10:37:51 --> Total execution time: 0.0321
DEBUG - 2022-05-13 05:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 05:07:55 --> No URI present. Default controller set.
DEBUG - 2022-05-13 05:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 05:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 10:37:55 --> Total execution time: 0.0430
DEBUG - 2022-05-13 05:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 05:09:25 --> No URI present. Default controller set.
DEBUG - 2022-05-13 05:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 05:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 10:39:26 --> Total execution time: 0.8214
DEBUG - 2022-05-13 13:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 13:36:26 --> Total execution time: 1.0861
DEBUG - 2022-05-13 13:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 13:36:26 --> Total execution time: 0.0280
DEBUG - 2022-05-13 13:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 13:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:17:19 --> Total execution time: 0.2782
DEBUG - 2022-05-13 13:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:18:00 --> Total execution time: 0.8656
DEBUG - 2022-05-13 13:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:20:20 --> Total execution time: 1.0466
DEBUG - 2022-05-13 13:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 13:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:20:36 --> Total execution time: 0.0319
DEBUG - 2022-05-13 13:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:20:36 --> Total execution time: 0.1219
DEBUG - 2022-05-13 13:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:20:39 --> Total execution time: 0.0478
DEBUG - 2022-05-13 13:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:21:05 --> Total execution time: 0.2611
DEBUG - 2022-05-13 13:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 13:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:21:06 --> Total execution time: 0.0522
DEBUG - 2022-05-13 13:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:24:08 --> Total execution time: 0.8557
DEBUG - 2022-05-13 13:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:24:11 --> Total execution time: 0.0306
DEBUG - 2022-05-13 13:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 13:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 13:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:24:22 --> Total execution time: 0.0982
DEBUG - 2022-05-13 19:24:22 --> Total execution time: 3.3578
DEBUG - 2022-05-13 13:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:24:37 --> Total execution time: 0.9768
DEBUG - 2022-05-13 13:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:24:45 --> Total execution time: 0.9098
DEBUG - 2022-05-13 13:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:24:51 --> Total execution time: 1.0036
DEBUG - 2022-05-13 13:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:25:24 --> Total execution time: 0.8347
DEBUG - 2022-05-13 13:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 13:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:27:06 --> Total execution time: 0.0480
DEBUG - 2022-05-13 13:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:57:59 --> No URI present. Default controller set.
DEBUG - 2022-05-13 13:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:28:00 --> Total execution time: 0.7475
DEBUG - 2022-05-13 13:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:28:45 --> Total execution time: 0.7287
DEBUG - 2022-05-13 13:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 13:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:28:58 --> Total execution time: 0.0665
DEBUG - 2022-05-13 13:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:29:04 --> Total execution time: 0.1608
DEBUG - 2022-05-13 13:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:29:23 --> Total execution time: 0.1652
DEBUG - 2022-05-13 13:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 13:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 13:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:29:30 --> Total execution time: 0.1800
DEBUG - 2022-05-13 14:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:37:21 --> Total execution time: 1.4640
DEBUG - 2022-05-13 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:37:24 --> Total execution time: 0.0437
DEBUG - 2022-05-13 14:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 14:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:56:35 --> Total execution time: 0.1278
DEBUG - 2022-05-13 14:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 14:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:56:47 --> Total execution time: 0.0331
DEBUG - 2022-05-13 14:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:57:57 --> Total execution time: 0.3231
DEBUG - 2022-05-13 14:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:30:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:30:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-13 14:30:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-13 14:30:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:30:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-13 14:30:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:30:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:30:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:02:53 --> Total execution time: 1.0308
DEBUG - 2022-05-13 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:33:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:33:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-13 14:33:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-13 14:33:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:33:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:33:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:33:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:33:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:33:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:33:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:33:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:33:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:33:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:33:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:04:41 --> Total execution time: 0.6373
DEBUG - 2022-05-13 14:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:34:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:34:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:34:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:34:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:34:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:34:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:34:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:34:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:05:07 --> Total execution time: 0.0338
DEBUG - 2022-05-13 14:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:38:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-13 20:08:18 --> Severity: Notice --> Trying to get property 'sp_id' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/course_edit.php 123
ERROR - 2022-05-13 20:08:18 --> Severity: Notice --> Trying to get property 'sp_heading' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/course_edit.php 123
ERROR - 2022-05-13 20:08:18 --> Severity: Notice --> Trying to get property 'sp_id' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/course_edit.php 123
ERROR - 2022-05-13 20:08:18 --> Severity: Notice --> Trying to get property 'sp_order' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/course_edit.php 123
ERROR - 2022-05-13 20:08:18 --> Severity: Notice --> Trying to get property 'sp_id' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/course_edit.php 123
ERROR - 2022-05-13 20:08:18 --> Severity: Notice --> Trying to get property 'sp_id' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/course_edit.php 123
ERROR - 2022-05-13 20:08:18 --> Severity: Notice --> Trying to get property 'sp_data' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/course_edit.php 123
ERROR - 2022-05-13 20:08:18 --> Severity: Notice --> Trying to get property 'sp_id' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/course_edit.php 123
ERROR - 2022-05-13 20:08:18 --> Severity: Notice --> Trying to get property 'sp_heading' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/course_edit.php 123
ERROR - 2022-05-13 20:08:18 --> Severity: Notice --> Trying to get property 'sp_id' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/course_edit.php 123
ERROR - 2022-05-13 20:08:18 --> Severity: Notice --> Trying to get property 'sp_order' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/course_edit.php 123
ERROR - 2022-05-13 20:08:18 --> Severity: Notice --> Trying to get property 'sp_id' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/course_edit.php 123
ERROR - 2022-05-13 20:08:18 --> Severity: Notice --> Trying to get property 'sp_id' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/course_edit.php 123
ERROR - 2022-05-13 20:08:18 --> Severity: Notice --> Trying to get property 'sp_data' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/course_edit.php 123
DEBUG - 2022-05-13 20:08:18 --> Total execution time: 0.0398
DEBUG - 2022-05-13 14:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:10:21 --> Total execution time: 0.0321
DEBUG - 2022-05-13 14:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:51:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:51:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:51:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:51:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:51:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:51:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 14:51:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:51:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-13 14:51:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:51:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:51:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:51:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:51:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 14:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:51:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 14:51:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:31:08 --> Total execution time: 0.9957
DEBUG - 2022-05-13 15:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:01:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:01:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-13 15:01:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:01:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:01:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:01:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:01:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:01:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-13 15:01:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:32:06 --> Total execution time: 0.0310
DEBUG - 2022-05-13 15:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:02:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:02:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:02:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:02:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:02:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:02:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:02:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:02:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:02:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:02:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:02:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:02:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:02:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:02:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:33:05 --> Total execution time: 0.0375
DEBUG - 2022-05-13 15:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:03:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:03:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:03:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:03:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:03:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:03:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:03:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:03:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:03:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:03:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:03:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:51:33 --> Total execution time: 0.8476
DEBUG - 2022-05-13 15:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:21:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:21:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:21:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:21:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:21:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:21:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:21:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:21:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:21:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:21:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:21:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:21:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:21:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:21:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:21:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:21:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:51:42 --> Total execution time: 0.0290
DEBUG - 2022-05-13 15:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:52:37 --> Total execution time: 0.0302
DEBUG - 2022-05-13 15:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:22:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:22:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:22:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:22:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:22:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:22:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:22:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:22:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:22:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:22:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:22:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:22:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:22:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:22:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:22:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:22:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:52:43 --> Total execution time: 0.0357
DEBUG - 2022-05-13 15:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:53:41 --> Total execution time: 0.0278
DEBUG - 2022-05-13 15:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:54:24 --> Total execution time: 0.0306
DEBUG - 2022-05-13 15:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:24:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:24:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:24:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:24:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:24:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:24:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-13 15:24:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:24:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:54:32 --> Total execution time: 0.0285
DEBUG - 2022-05-13 15:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:54:52 --> Total execution time: 0.0349
DEBUG - 2022-05-13 15:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:24:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-13 15:24:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:24:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:24:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:24:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:24:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:24:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:24:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:54:58 --> Total execution time: 0.0327
DEBUG - 2022-05-13 15:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:58:39 --> Total execution time: 0.8638
DEBUG - 2022-05-13 15:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:28:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:28:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:28:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:28:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:28:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:28:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:28:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:28:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:59:19 --> Total execution time: 0.0321
DEBUG - 2022-05-13 15:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:29:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:29:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:29:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:29:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:29:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:29:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:29:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:29:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:29:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:29:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:29:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 20:59:25 --> Total execution time: 0.0303
DEBUG - 2022-05-13 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:05:38 --> Total execution time: 0.0335
DEBUG - 2022-05-13 15:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-13 15:35:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:35:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:05:45 --> Total execution time: 0.0292
DEBUG - 2022-05-13 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:07:07 --> Total execution time: 0.0288
DEBUG - 2022-05-13 15:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:07:33 --> Total execution time: 0.0301
DEBUG - 2022-05-13 15:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:11:55 --> Total execution time: 0.8397
DEBUG - 2022-05-13 15:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:12:12 --> Total execution time: 0.0296
DEBUG - 2022-05-13 15:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:12:29 --> Total execution time: 0.0281
DEBUG - 2022-05-13 15:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:13:09 --> Total execution time: 0.0291
DEBUG - 2022-05-13 15:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:18:59 --> Total execution time: 0.5937
DEBUG - 2022-05-13 15:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:49:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:49:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:49:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:49:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:49:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:49:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:49:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:49:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:49:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:49:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:49:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:19:06 --> Total execution time: 0.0302
DEBUG - 2022-05-13 15:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:21:56 --> Total execution time: 0.0337
DEBUG - 2022-05-13 15:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:51:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:51:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:51:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:51:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:51:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:51:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:51:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:51:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:51:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:51:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:51:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:51:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:51:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:51:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:51:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:51:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:22:06 --> Total execution time: 0.0318
DEBUG - 2022-05-13 15:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:24:30 --> Total execution time: 0.4858
DEBUG - 2022-05-13 15:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:54:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:54:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:54:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:54:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:54:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:54:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:54:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:54:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:54:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:54:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:54:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:54:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:54:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:54:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:54:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 15:54:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 15:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:24:35 --> Total execution time: 0.0305
DEBUG - 2022-05-13 15:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:24:53 --> Total execution time: 0.0303
DEBUG - 2022-05-13 15:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:27:12 --> Total execution time: 0.0299
DEBUG - 2022-05-13 15:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:27:21 --> Total execution time: 0.0304
DEBUG - 2022-05-13 15:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:27:42 --> Total execution time: 0.0329
DEBUG - 2022-05-13 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 15:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 15:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:27:48 --> Total execution time: 0.0296
DEBUG - 2022-05-13 16:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:37:45 --> Total execution time: 0.8317
DEBUG - 2022-05-13 16:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:38:07 --> Total execution time: 0.0315
DEBUG - 2022-05-13 16:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:38:18 --> Total execution time: 0.0323
DEBUG - 2022-05-13 16:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:38:56 --> Total execution time: 0.0313
DEBUG - 2022-05-13 16:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:39:05 --> Total execution time: 0.0296
DEBUG - 2022-05-13 16:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:09:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:09:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:09:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:09:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:09:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:09:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:09:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:09:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-13 16:09:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:09:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:09:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:09:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:09:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:09:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:09:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:09:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-13 21:39:38 --> Query error: Table 'gvprods_gvv3.ssub_product' doesn't exist - Invalid query: DELETE FROM `ssub_product`
WHERE `ssp_id` NOT IN('undefined', 'undefined')
AND `ssp_FK_product_id` = '33'
DEBUG - 2022-05-13 16:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:10:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-13 21:40:10 --> Query error: Unknown column 'ssp_FK_product_id' in 'where clause' - Invalid query: DELETE FROM `sub_sub_product`
WHERE `ssp_id` NOT IN('undefined', 'undefined')
AND `ssp_FK_product_id` = '33'
DEBUG - 2022-05-13 16:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:10:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-13 21:40:52 --> Severity: Notice --> Undefined variable: sp_id /home/gvprods/public_html/v1/gvv3/application/controllers/Admin/Course_crud_controller.php 298
ERROR - 2022-05-13 21:40:52 --> Severity: Notice --> Undefined variable: sp_id /home/gvprods/public_html/v1/gvv3/application/controllers/Admin/Course_crud_controller.php 299
ERROR - 2022-05-13 21:40:52 --> Severity: Notice --> Undefined variable: sp_id /home/gvprods/public_html/v1/gvv3/application/controllers/Admin/Course_crud_controller.php 298
ERROR - 2022-05-13 21:40:52 --> Severity: Notice --> Undefined variable: sp_id /home/gvprods/public_html/v1/gvv3/application/controllers/Admin/Course_crud_controller.php 299
DEBUG - 2022-05-13 21:40:52 --> Total execution time: 0.0301
DEBUG - 2022-05-13 16:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:41:30 --> Total execution time: 0.0298
DEBUG - 2022-05-13 16:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:41:37 --> Total execution time: 0.0318
DEBUG - 2022-05-13 16:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:11:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:11:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:11:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:42:05 --> Total execution time: 0.0301
DEBUG - 2022-05-13 16:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:42:12 --> Total execution time: 0.0298
DEBUG - 2022-05-13 16:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:42:15 --> Total execution time: 0.0315
DEBUG - 2022-05-13 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:12:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:12:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:12:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:12:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:12:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:12:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:12:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:12:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:43:01 --> Total execution time: 0.5890
DEBUG - 2022-05-13 16:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:43:08 --> Total execution time: 0.0293
DEBUG - 2022-05-13 16:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:43:54 --> Total execution time: 0.0306
DEBUG - 2022-05-13 16:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:44:08 --> Total execution time: 0.0284
DEBUG - 2022-05-13 16:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:44:58 --> Total execution time: 0.0320
DEBUG - 2022-05-13 16:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:45:01 --> Total execution time: 0.0332
DEBUG - 2022-05-13 16:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:45:09 --> Total execution time: 0.1023
DEBUG - 2022-05-13 16:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:45:18 --> Total execution time: 0.0291
DEBUG - 2022-05-13 16:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:45:23 --> Total execution time: 0.0298
DEBUG - 2022-05-13 16:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:45:32 --> Total execution time: 0.0290
DEBUG - 2022-05-13 16:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:45:43 --> Total execution time: 0.0296
DEBUG - 2022-05-13 16:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:46:12 --> Total execution time: 0.0325
DEBUG - 2022-05-13 16:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:47:57 --> Total execution time: 0.9066
DEBUG - 2022-05-13 16:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:48:04 --> Total execution time: 0.0312
DEBUG - 2022-05-13 16:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:50:05 --> Total execution time: 0.8907
DEBUG - 2022-05-13 16:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:50:10 --> Total execution time: 0.0334
DEBUG - 2022-05-13 16:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:50:19 --> Total execution time: 0.0321
DEBUG - 2022-05-13 16:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:50:26 --> Total execution time: 0.0313
DEBUG - 2022-05-13 16:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:50:29 --> Total execution time: 0.0323
DEBUG - 2022-05-13 16:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:50:32 --> Total execution time: 0.0322
DEBUG - 2022-05-13 16:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:51:16 --> Total execution time: 0.0341
DEBUG - 2022-05-13 16:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:21:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:21:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:21:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:21:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:21:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:21:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:21:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:21:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 16:21:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-13 16:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:52:53 --> Total execution time: 0.0811
DEBUG - 2022-05-13 16:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:53:36 --> Total execution time: 0.0294
DEBUG - 2022-05-13 16:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:55:33 --> Total execution time: 0.0428
DEBUG - 2022-05-13 16:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 16:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:55:47 --> Total execution time: 0.0682
DEBUG - 2022-05-13 16:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 16:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:55:48 --> Total execution time: 0.0331
DEBUG - 2022-05-13 16:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:55:50 --> Total execution time: 0.0495
DEBUG - 2022-05-13 16:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:55:55 --> Total execution time: 0.0314
DEBUG - 2022-05-13 16:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 21:56:07 --> Total execution time: 0.0337
DEBUG - 2022-05-13 16:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 22:02:58 --> Total execution time: 0.9109
DEBUG - 2022-05-13 16:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:33:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-13 22:03:03 --> Severity: Notice --> Undefined property: Courses_Controller::$Sub_sub_product /home/gvprods/public_html/v1/gvv3/application/controllers/User/Courses_Controller.php 40
ERROR - 2022-05-13 22:03:03 --> Severity: error --> Exception: Call to a member function get() on null /home/gvprods/public_html/v1/gvv3/application/controllers/User/Courses_Controller.php 40
ERROR - 2022-05-13 22:03:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/core/Common.php 564
DEBUG - 2022-05-13 16:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 22:03:28 --> Total execution time: 0.0373
DEBUG - 2022-05-13 16:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 22:03:33 --> Total execution time: 0.0294
DEBUG - 2022-05-13 16:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 22:04:32 --> Total execution time: 0.8376
DEBUG - 2022-05-13 16:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 22:05:00 --> Total execution time: 0.8014
DEBUG - 2022-05-13 16:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 22:11:04 --> Total execution time: 1.0349
DEBUG - 2022-05-13 16:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 22:11:24 --> Total execution time: 0.3013
DEBUG - 2022-05-13 16:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 22:13:31 --> Total execution time: 0.8465
DEBUG - 2022-05-13 16:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 22:13:42 --> Total execution time: 0.8213
DEBUG - 2022-05-13 16:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 22:15:06 --> Total execution time: 0.8544
DEBUG - 2022-05-13 16:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 22:15:30 --> Total execution time: 0.4612
DEBUG - 2022-05-13 16:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 22:22:48 --> Total execution time: 1.0023
DEBUG - 2022-05-13 16:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 16:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 16:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 22:23:07 --> Total execution time: 0.9529
DEBUG - 2022-05-13 17:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 17:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 17:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 17:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 17:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 17:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:23:36 --> Total execution time: 0.0713
DEBUG - 2022-05-13 17:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 17:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 17:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 17:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 17:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 17:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:23:49 --> Total execution time: 0.0289
DEBUG - 2022-05-13 17:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 17:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 17:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 17:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 17:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 17:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:24:02 --> Total execution time: 0.2183
DEBUG - 2022-05-13 17:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 17:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 17:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:24:10 --> Total execution time: 0.8155
DEBUG - 2022-05-13 17:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 17:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 17:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:24:21 --> Total execution time: 0.6683
DEBUG - 2022-05-13 18:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:42:02 --> Total execution time: 0.9812
DEBUG - 2022-05-13 18:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:42:52 --> Total execution time: 0.0378
DEBUG - 2022-05-13 18:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:43:01 --> Total execution time: 0.6843
DEBUG - 2022-05-13 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:43:11 --> Total execution time: 0.0484
DEBUG - 2022-05-13 18:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:43:33 --> Total execution time: 0.0335
DEBUG - 2022-05-13 18:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:43:48 --> Total execution time: 0.6052
DEBUG - 2022-05-13 18:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:44:04 --> Total execution time: 0.0413
DEBUG - 2022-05-13 18:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:44:10 --> Total execution time: 0.7484
DEBUG - 2022-05-13 18:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:44:14 --> Total execution time: 0.0370
DEBUG - 2022-05-13 18:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:44:25 --> Total execution time: 0.1359
DEBUG - 2022-05-13 18:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:44:37 --> Total execution time: 0.0329
DEBUG - 2022-05-13 18:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:44:40 --> Total execution time: 0.0799
DEBUG - 2022-05-13 18:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:44:51 --> Total execution time: 0.0421
DEBUG - 2022-05-13 18:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:45:04 --> Total execution time: 0.0379
DEBUG - 2022-05-13 18:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:45:07 --> Total execution time: 0.0364
DEBUG - 2022-05-13 18:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:45:10 --> Total execution time: 0.0341
DEBUG - 2022-05-13 18:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 18:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 18:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 23:45:22 --> Total execution time: 0.6610
DEBUG - 2022-05-13 19:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 19:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 19:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-13 19:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 19:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-13 19:59:05 --> Encryption: Auto-configured driver 'openssl'.
