<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-29 00:04:50 --> Total execution time: 0.3200
DEBUG - 2022-07-29 00:05:01 --> Total execution time: 0.0999
DEBUG - 2022-07-29 00:05:02 --> Total execution time: 0.0853
DEBUG - 2022-07-29 00:05:17 --> Total execution time: 0.0956
DEBUG - 2022-07-29 00:08:51 --> Total execution time: 0.1282
DEBUG - 2022-07-29 00:08:56 --> Total execution time: 0.0665
DEBUG - 2022-07-29 00:09:18 --> Total execution time: 0.0774
DEBUG - 2022-07-29 00:09:27 --> Total execution time: 0.0941
DEBUG - 2022-07-29 00:09:30 --> Total execution time: 0.0864
DEBUG - 2022-07-29 00:09:32 --> Total execution time: 0.1196
DEBUG - 2022-07-29 00:09:34 --> Total execution time: 0.1014
DEBUG - 2022-07-29 00:09:40 --> Total execution time: 0.0856
DEBUG - 2022-07-29 00:09:41 --> Total execution time: 0.0921
DEBUG - 2022-07-29 00:09:42 --> Total execution time: 0.0815
DEBUG - 2022-07-29 00:12:29 --> Total execution time: 0.1016
DEBUG - 2022-07-29 00:12:31 --> Total execution time: 0.0724
DEBUG - 2022-07-29 00:30:03 --> Total execution time: 0.3030
DEBUG - 2022-07-29 00:50:15 --> Total execution time: 0.1329
DEBUG - 2022-07-29 00:51:58 --> Total execution time: 0.1306
DEBUG - 2022-07-29 00:58:29 --> Total execution time: 0.1209
DEBUG - 2022-07-29 01:16:36 --> Total execution time: 0.1275
DEBUG - 2022-07-29 01:16:38 --> Total execution time: 0.0677
DEBUG - 2022-07-29 01:16:40 --> Total execution time: 0.1306
DEBUG - 2022-07-29 01:30:03 --> Total execution time: 0.3431
DEBUG - 2022-07-29 01:37:26 --> Total execution time: 0.2786
DEBUG - 2022-07-29 01:56:49 --> Total execution time: 0.0731
DEBUG - 2022-07-29 01:58:00 --> Total execution time: 0.0522
DEBUG - 2022-07-29 02:22:37 --> Total execution time: 0.1218
DEBUG - 2022-07-29 02:22:38 --> Total execution time: 0.0516
DEBUG - 2022-07-29 02:30:03 --> Total execution time: 0.2220
DEBUG - 2022-07-29 02:34:16 --> Total execution time: 0.0873
DEBUG - 2022-07-29 02:34:57 --> Total execution time: 0.0680
DEBUG - 2022-07-29 02:34:58 --> Total execution time: 0.0738
DEBUG - 2022-07-29 02:35:30 --> Total execution time: 0.2476
DEBUG - 2022-07-29 02:52:16 --> Total execution time: 0.1279
DEBUG - 2022-07-29 03:19:42 --> Total execution time: 0.1488
DEBUG - 2022-07-29 03:30:03 --> Total execution time: 0.2311
DEBUG - 2022-07-29 03:42:45 --> Total execution time: 0.0783
DEBUG - 2022-07-29 03:45:24 --> Total execution time: 0.1378
DEBUG - 2022-07-29 03:45:34 --> Total execution time: 0.1037
DEBUG - 2022-07-29 03:48:34 --> Total execution time: 0.1047
DEBUG - 2022-07-29 03:50:29 --> Total execution time: 0.0654
DEBUG - 2022-07-29 03:50:30 --> Total execution time: 0.0450
DEBUG - 2022-07-29 03:50:34 --> Total execution time: 0.0679
DEBUG - 2022-07-29 03:50:41 --> Total execution time: 0.0749
DEBUG - 2022-07-29 03:50:49 --> Total execution time: 0.0991
DEBUG - 2022-07-29 03:50:56 --> Total execution time: 0.0878
DEBUG - 2022-07-29 03:50:57 --> Total execution time: 0.0639
DEBUG - 2022-07-29 03:50:58 --> Total execution time: 0.0619
DEBUG - 2022-07-29 03:50:58 --> Total execution time: 0.0619
DEBUG - 2022-07-29 04:30:03 --> Total execution time: 0.9080
DEBUG - 2022-07-29 04:48:55 --> Total execution time: 0.2550
DEBUG - 2022-07-29 04:58:41 --> Total execution time: 0.1175
DEBUG - 2022-07-29 04:58:42 --> Total execution time: 0.0693
DEBUG - 2022-07-29 05:13:44 --> Total execution time: 0.0740
DEBUG - 2022-07-29 05:14:06 --> Total execution time: 0.0749
DEBUG - 2022-07-29 05:14:07 --> Total execution time: 0.0481
DEBUG - 2022-07-29 05:14:12 --> Total execution time: 0.0664
DEBUG - 2022-07-29 05:14:42 --> Total execution time: 0.0981
DEBUG - 2022-07-29 05:15:01 --> Total execution time: 0.1159
DEBUG - 2022-07-29 05:15:06 --> Total execution time: 0.0920
DEBUG - 2022-07-29 05:15:14 --> Total execution time: 0.0894
DEBUG - 2022-07-29 05:15:46 --> Total execution time: 0.0658
DEBUG - 2022-07-29 05:30:02 --> Total execution time: 0.1907
DEBUG - 2022-07-29 05:32:10 --> Total execution time: 0.1041
DEBUG - 2022-07-29 05:32:16 --> Total execution time: 0.0685
DEBUG - 2022-07-29 05:32:37 --> Total execution time: 0.0859
DEBUG - 2022-07-29 05:32:44 --> Total execution time: 0.1040
DEBUG - 2022-07-29 05:33:01 --> Total execution time: 0.1870
DEBUG - 2022-07-29 05:33:28 --> Total execution time: 0.1203
DEBUG - 2022-07-29 05:33:40 --> Total execution time: 0.0738
DEBUG - 2022-07-29 05:33:49 --> Total execution time: 0.0807
DEBUG - 2022-07-29 05:33:54 --> Total execution time: 0.0795
DEBUG - 2022-07-29 05:33:57 --> Total execution time: 0.1113
DEBUG - 2022-07-29 05:34:02 --> Total execution time: 0.1338
DEBUG - 2022-07-29 05:34:08 --> Total execution time: 0.0797
DEBUG - 2022-07-29 05:34:11 --> Total execution time: 0.0667
DEBUG - 2022-07-29 05:34:14 --> Total execution time: 0.0874
DEBUG - 2022-07-29 05:34:17 --> Total execution time: 0.0895
DEBUG - 2022-07-29 05:34:20 --> Total execution time: 0.0808
DEBUG - 2022-07-29 05:34:24 --> Total execution time: 0.0611
DEBUG - 2022-07-29 05:35:00 --> Total execution time: 0.0621
DEBUG - 2022-07-29 05:35:08 --> Total execution time: 0.0703
DEBUG - 2022-07-29 05:35:13 --> Total execution time: 0.0812
DEBUG - 2022-07-29 05:35:39 --> Total execution time: 0.0847
DEBUG - 2022-07-29 05:37:48 --> Total execution time: 0.0780
DEBUG - 2022-07-29 05:42:07 --> Total execution time: 0.1252
DEBUG - 2022-07-29 05:46:58 --> Total execution time: 0.3299
DEBUG - 2022-07-29 05:47:02 --> Total execution time: 0.1403
DEBUG - 2022-07-29 05:47:10 --> Total execution time: 0.0661
DEBUG - 2022-07-29 05:47:46 --> Total execution time: 0.0664
DEBUG - 2022-07-29 05:48:24 --> Total execution time: 0.0550
DEBUG - 2022-07-29 06:04:25 --> Total execution time: 0.3491
DEBUG - 2022-07-29 06:04:30 --> Total execution time: 0.0814
DEBUG - 2022-07-29 06:04:36 --> Total execution time: 0.1424
DEBUG - 2022-07-29 06:04:47 --> Total execution time: 0.0820
DEBUG - 2022-07-29 06:04:51 --> Total execution time: 0.1761
DEBUG - 2022-07-29 06:05:05 --> Total execution time: 0.1178
DEBUG - 2022-07-29 06:05:06 --> Total execution time: 0.0850
DEBUG - 2022-07-29 06:11:09 --> Total execution time: 0.1610
DEBUG - 2022-07-29 06:14:13 --> Total execution time: 0.1970
DEBUG - 2022-07-29 06:14:45 --> Total execution time: 0.0764
DEBUG - 2022-07-29 06:20:14 --> Total execution time: 0.1441
DEBUG - 2022-07-29 06:20:15 --> Total execution time: 0.0647
DEBUG - 2022-07-29 06:20:19 --> Total execution time: 0.0556
DEBUG - 2022-07-29 06:20:29 --> Total execution time: 0.0716
DEBUG - 2022-07-29 06:20:48 --> Total execution time: 0.1066
DEBUG - 2022-07-29 06:21:11 --> Total execution time: 0.0755
DEBUG - 2022-07-29 06:21:27 --> Total execution time: 0.0695
DEBUG - 2022-07-29 06:22:08 --> Total execution time: 0.1105
DEBUG - 2022-07-29 06:22:15 --> Total execution time: 0.0984
DEBUG - 2022-07-29 06:22:24 --> Total execution time: 0.1201
DEBUG - 2022-07-29 06:23:22 --> Total execution time: 0.0799
DEBUG - 2022-07-29 06:23:28 --> Total execution time: 0.1002
DEBUG - 2022-07-29 06:23:45 --> Total execution time: 0.0443
DEBUG - 2022-07-29 06:23:48 --> Total execution time: 0.0668
DEBUG - 2022-07-29 06:23:53 --> Total execution time: 0.1061
DEBUG - 2022-07-29 06:23:54 --> Total execution time: 0.0718
DEBUG - 2022-07-29 06:24:04 --> Total execution time: 0.0886
DEBUG - 2022-07-29 06:24:07 --> Total execution time: 0.0857
DEBUG - 2022-07-29 06:24:10 --> Total execution time: 0.1141
DEBUG - 2022-07-29 06:25:57 --> Total execution time: 0.1028
DEBUG - 2022-07-29 06:26:01 --> Total execution time: 0.1190
DEBUG - 2022-07-29 06:26:13 --> Total execution time: 0.1084
DEBUG - 2022-07-29 06:30:03 --> Total execution time: 0.2282
DEBUG - 2022-07-29 06:36:58 --> Total execution time: 0.0737
DEBUG - 2022-07-29 06:37:08 --> Total execution time: 0.2193
DEBUG - 2022-07-29 06:37:16 --> Total execution time: 0.0803
DEBUG - 2022-07-29 06:37:20 --> Total execution time: 0.0760
DEBUG - 2022-07-29 06:37:22 --> Total execution time: 0.0654
DEBUG - 2022-07-29 06:37:39 --> Total execution time: 0.0722
DEBUG - 2022-07-29 06:37:42 --> Total execution time: 0.0740
DEBUG - 2022-07-29 06:37:45 --> Total execution time: 0.0723
DEBUG - 2022-07-29 06:37:48 --> Total execution time: 0.0700
DEBUG - 2022-07-29 06:37:52 --> Total execution time: 0.0748
DEBUG - 2022-07-29 06:37:55 --> Total execution time: 0.0862
DEBUG - 2022-07-29 06:37:58 --> Total execution time: 0.0697
DEBUG - 2022-07-29 06:38:03 --> Total execution time: 0.0585
DEBUG - 2022-07-29 06:38:34 --> Total execution time: 0.0695
DEBUG - 2022-07-29 06:38:39 --> Total execution time: 0.0679
DEBUG - 2022-07-29 06:39:11 --> Total execution time: 0.1088
DEBUG - 2022-07-29 06:39:15 --> Total execution time: 0.0783
DEBUG - 2022-07-29 06:39:18 --> Total execution time: 0.0871
DEBUG - 2022-07-29 06:39:32 --> Total execution time: 0.0749
DEBUG - 2022-07-29 06:39:33 --> Total execution time: 0.0812
DEBUG - 2022-07-29 06:39:35 --> Total execution time: 0.0740
DEBUG - 2022-07-29 06:39:37 --> Total execution time: 0.0898
DEBUG - 2022-07-29 06:39:41 --> Total execution time: 0.1345
DEBUG - 2022-07-29 06:39:50 --> Total execution time: 0.0687
DEBUG - 2022-07-29 06:39:51 --> Total execution time: 0.0661
DEBUG - 2022-07-29 06:39:52 --> Total execution time: 0.1008
DEBUG - 2022-07-29 06:39:53 --> Total execution time: 0.0799
DEBUG - 2022-07-29 06:39:56 --> Total execution time: 0.0845
DEBUG - 2022-07-29 06:39:56 --> Total execution time: 0.0959
DEBUG - 2022-07-29 06:39:58 --> Total execution time: 0.0817
DEBUG - 2022-07-29 06:40:00 --> Total execution time: 0.0733
DEBUG - 2022-07-29 06:40:03 --> Total execution time: 0.1137
DEBUG - 2022-07-29 06:40:03 --> Total execution time: 0.0807
DEBUG - 2022-07-29 06:40:31 --> Total execution time: 0.0966
DEBUG - 2022-07-29 06:40:42 --> Total execution time: 0.0810
DEBUG - 2022-07-29 06:40:47 --> Total execution time: 0.0719
DEBUG - 2022-07-29 06:41:13 --> Total execution time: 0.0858
DEBUG - 2022-07-29 06:41:18 --> Total execution time: 0.0753
DEBUG - 2022-07-29 06:41:21 --> Total execution time: 0.0706
DEBUG - 2022-07-29 06:41:28 --> Total execution time: 0.0694
DEBUG - 2022-07-29 06:42:03 --> Total execution time: 0.0722
DEBUG - 2022-07-29 06:42:10 --> Total execution time: 0.2313
DEBUG - 2022-07-29 06:42:13 --> Total execution time: 0.0891
DEBUG - 2022-07-29 06:42:15 --> Total execution time: 0.0732
DEBUG - 2022-07-29 06:42:19 --> Total execution time: 0.0849
DEBUG - 2022-07-29 06:42:21 --> Total execution time: 0.0682
DEBUG - 2022-07-29 06:42:25 --> Total execution time: 0.0682
DEBUG - 2022-07-29 06:43:01 --> Total execution time: 0.0773
DEBUG - 2022-07-29 06:43:18 --> Total execution time: 0.0903
DEBUG - 2022-07-29 06:43:23 --> Total execution time: 0.1203
DEBUG - 2022-07-29 06:43:26 --> Total execution time: 0.0762
DEBUG - 2022-07-29 06:56:24 --> Total execution time: 0.1235
DEBUG - 2022-07-29 07:05:30 --> Total execution time: 0.2134
DEBUG - 2022-07-29 07:05:35 --> Total execution time: 0.0821
DEBUG - 2022-07-29 07:05:41 --> Total execution time: 0.1612
DEBUG - 2022-07-29 07:05:46 --> Total execution time: 0.0844
DEBUG - 2022-07-29 07:05:49 --> Total execution time: 0.1037
DEBUG - 2022-07-29 07:05:55 --> Total execution time: 0.0781
DEBUG - 2022-07-29 07:07:33 --> Total execution time: 0.0828
DEBUG - 2022-07-29 07:07:37 --> Total execution time: 0.1146
DEBUG - 2022-07-29 07:07:45 --> Total execution time: 0.0711
DEBUG - 2022-07-29 07:12:50 --> Total execution time: 0.1011
DEBUG - 2022-07-29 07:13:07 --> Total execution time: 0.0805
DEBUG - 2022-07-29 07:13:12 --> Total execution time: 0.0840
DEBUG - 2022-07-29 07:13:18 --> Total execution time: 0.0830
DEBUG - 2022-07-29 07:13:28 --> Total execution time: 0.1045
DEBUG - 2022-07-29 07:14:13 --> Total execution time: 0.0826
DEBUG - 2022-07-29 07:16:06 --> Total execution time: 0.1084
DEBUG - 2022-07-29 07:16:06 --> Total execution time: 0.0537
DEBUG - 2022-07-29 07:18:56 --> Total execution time: 0.3558
DEBUG - 2022-07-29 07:19:04 --> Total execution time: 0.1871
DEBUG - 2022-07-29 07:21:49 --> Total execution time: 0.1320
DEBUG - 2022-07-29 07:21:51 --> Total execution time: 0.0821
DEBUG - 2022-07-29 07:27:25 --> Total execution time: 0.0815
DEBUG - 2022-07-29 07:28:33 --> Total execution time: 0.0834
DEBUG - 2022-07-29 07:28:44 --> Total execution time: 0.0969
DEBUG - 2022-07-29 07:28:56 --> Total execution time: 0.0680
DEBUG - 2022-07-29 07:29:06 --> Total execution time: 0.0732
DEBUG - 2022-07-29 07:30:03 --> Total execution time: 0.1215
DEBUG - 2022-07-29 07:33:52 --> Total execution time: 0.2854
DEBUG - 2022-07-29 07:33:58 --> Total execution time: 0.0872
DEBUG - 2022-07-29 07:33:58 --> Total execution time: 0.0827
DEBUG - 2022-07-29 07:34:10 --> Total execution time: 0.0648
DEBUG - 2022-07-29 07:35:44 --> Total execution time: 0.2142
DEBUG - 2022-07-29 07:36:07 --> Total execution time: 0.1302
DEBUG - 2022-07-29 07:40:38 --> Total execution time: 0.1474
DEBUG - 2022-07-29 07:42:21 --> Total execution time: 0.0460
DEBUG - 2022-07-29 07:43:47 --> Total execution time: 0.0582
DEBUG - 2022-07-29 07:44:32 --> Total execution time: 2.0026
DEBUG - 2022-07-29 07:47:29 --> Total execution time: 0.1579
DEBUG - 2022-07-29 07:53:08 --> Total execution time: 0.0699
DEBUG - 2022-07-29 07:53:37 --> Total execution time: 0.0787
DEBUG - 2022-07-29 07:53:38 --> Total execution time: 0.0795
DEBUG - 2022-07-29 07:53:46 --> Total execution time: 0.0764
DEBUG - 2022-07-29 07:53:54 --> Total execution time: 0.0735
DEBUG - 2022-07-29 07:58:00 --> Total execution time: 0.1366
DEBUG - 2022-07-29 08:05:27 --> Total execution time: 0.1314
DEBUG - 2022-07-29 08:08:40 --> Total execution time: 0.0767
DEBUG - 2022-07-29 08:09:21 --> Total execution time: 0.0648
DEBUG - 2022-07-29 08:09:32 --> Total execution time: 0.0799
DEBUG - 2022-07-29 08:09:34 --> Total execution time: 0.0761
DEBUG - 2022-07-29 08:09:46 --> Total execution time: 0.1023
DEBUG - 2022-07-29 08:10:00 --> Total execution time: 0.0896
DEBUG - 2022-07-29 08:10:03 --> Total execution time: 0.0861
DEBUG - 2022-07-29 08:10:14 --> Total execution time: 0.0667
DEBUG - 2022-07-29 08:11:08 --> Total execution time: 0.1000
DEBUG - 2022-07-29 08:12:58 --> Total execution time: 0.0698
DEBUG - 2022-07-29 08:12:59 --> Total execution time: 0.0514
DEBUG - 2022-07-29 08:13:02 --> Total execution time: 0.0417
DEBUG - 2022-07-29 08:13:10 --> Total execution time: 0.0789
DEBUG - 2022-07-29 08:13:27 --> Total execution time: 0.0968
DEBUG - 2022-07-29 08:13:34 --> Total execution time: 0.0700
DEBUG - 2022-07-29 08:13:40 --> Total execution time: 0.1008
DEBUG - 2022-07-29 08:13:42 --> Total execution time: 0.0887
DEBUG - 2022-07-29 08:13:50 --> Total execution time: 0.1440
DEBUG - 2022-07-29 08:13:58 --> Total execution time: 0.0696
DEBUG - 2022-07-29 08:14:11 --> Total execution time: 0.0579
DEBUG - 2022-07-29 08:14:37 --> Total execution time: 0.0601
DEBUG - 2022-07-29 08:15:02 --> Total execution time: 0.0823
DEBUG - 2022-07-29 08:15:03 --> Total execution time: 0.0456
DEBUG - 2022-07-29 08:15:29 --> Total execution time: 0.0615
DEBUG - 2022-07-29 08:21:05 --> Total execution time: 0.0769
DEBUG - 2022-07-29 08:21:15 --> Total execution time: 0.0687
DEBUG - 2022-07-29 08:21:32 --> Total execution time: 0.0939
DEBUG - 2022-07-29 08:22:00 --> Total execution time: 0.0843
DEBUG - 2022-07-29 08:22:15 --> Total execution time: 0.0891
DEBUG - 2022-07-29 08:22:25 --> Total execution time: 0.0900
DEBUG - 2022-07-29 08:22:26 --> Total execution time: 0.0464
DEBUG - 2022-07-29 08:23:26 --> Total execution time: 0.2332
DEBUG - 2022-07-29 08:24:39 --> Total execution time: 0.0713
DEBUG - 2022-07-29 08:25:36 --> Total execution time: 0.2103
DEBUG - 2022-07-29 08:30:02 --> Total execution time: 0.4349
DEBUG - 2022-07-29 08:31:40 --> Total execution time: 0.0836
DEBUG - 2022-07-29 08:31:48 --> Total execution time: 0.0748
DEBUG - 2022-07-29 08:32:29 --> Total execution time: 0.0985
DEBUG - 2022-07-29 08:32:39 --> Total execution time: 0.0726
DEBUG - 2022-07-29 08:32:49 --> Total execution time: 0.2064
DEBUG - 2022-07-29 08:33:01 --> Total execution time: 0.1534
DEBUG - 2022-07-29 08:33:13 --> Total execution time: 0.1149
DEBUG - 2022-07-29 08:33:21 --> Total execution time: 0.1633
DEBUG - 2022-07-29 08:33:30 --> Total execution time: 0.0750
DEBUG - 2022-07-29 08:33:37 --> Total execution time: 0.0685
DEBUG - 2022-07-29 08:33:42 --> Total execution time: 0.0676
DEBUG - 2022-07-29 08:33:46 --> Total execution time: 0.0757
DEBUG - 2022-07-29 08:33:53 --> Total execution time: 0.0671
DEBUG - 2022-07-29 08:33:54 --> Total execution time: 0.0809
DEBUG - 2022-07-29 08:34:05 --> Total execution time: 0.0701
DEBUG - 2022-07-29 08:34:09 --> Total execution time: 0.1115
DEBUG - 2022-07-29 08:34:16 --> Total execution time: 0.1166
DEBUG - 2022-07-29 08:34:19 --> Total execution time: 0.0732
DEBUG - 2022-07-29 08:34:35 --> Total execution time: 0.0834
DEBUG - 2022-07-29 08:34:46 --> Total execution time: 0.1367
DEBUG - 2022-07-29 08:34:47 --> Total execution time: 0.0717
DEBUG - 2022-07-29 08:35:28 --> Total execution time: 0.0675
DEBUG - 2022-07-29 08:35:37 --> Total execution time: 0.0703
DEBUG - 2022-07-29 08:36:06 --> Total execution time: 0.0719
DEBUG - 2022-07-29 08:36:16 --> Total execution time: 0.0419
DEBUG - 2022-07-29 08:36:58 --> Total execution time: 0.0752
DEBUG - 2022-07-29 08:37:00 --> Total execution time: 0.0796
DEBUG - 2022-07-29 08:38:27 --> Total execution time: 0.0587
DEBUG - 2022-07-29 08:38:36 --> Total execution time: 0.0556
DEBUG - 2022-07-29 08:38:41 --> Total execution time: 0.0434
DEBUG - 2022-07-29 08:38:57 --> Total execution time: 0.0796
DEBUG - 2022-07-29 08:39:10 --> Total execution time: 0.0855
DEBUG - 2022-07-29 08:39:10 --> Total execution time: 0.0913
DEBUG - 2022-07-29 08:39:28 --> Total execution time: 0.0471
DEBUG - 2022-07-29 08:40:29 --> Total execution time: 0.2020
DEBUG - 2022-07-29 08:40:35 --> Total execution time: 0.0937
DEBUG - 2022-07-29 08:41:26 --> Total execution time: 2.1131
DEBUG - 2022-07-29 08:47:08 --> Total execution time: 0.2695
DEBUG - 2022-07-29 08:47:15 --> Total execution time: 0.0884
DEBUG - 2022-07-29 08:47:59 --> Total execution time: 0.0724
DEBUG - 2022-07-29 08:48:02 --> Total execution time: 0.0763
DEBUG - 2022-07-29 08:48:06 --> Total execution time: 0.0826
DEBUG - 2022-07-29 08:48:10 --> Total execution time: 0.0505
DEBUG - 2022-07-29 08:48:36 --> Total execution time: 0.0692
DEBUG - 2022-07-29 08:53:32 --> Total execution time: 0.1331
DEBUG - 2022-07-29 08:57:17 --> Total execution time: 0.1528
DEBUG - 2022-07-29 08:57:27 --> Total execution time: 0.0760
DEBUG - 2022-07-29 08:58:19 --> Total execution time: 0.1886
DEBUG - 2022-07-29 08:58:25 --> Total execution time: 0.0783
DEBUG - 2022-07-29 08:58:25 --> Total execution time: 0.0731
DEBUG - 2022-07-29 08:58:27 --> Total execution time: 0.0648
DEBUG - 2022-07-29 08:58:31 --> Total execution time: 0.0745
DEBUG - 2022-07-29 08:58:49 --> Total execution time: 0.0823
DEBUG - 2022-07-29 08:58:53 --> Total execution time: 0.0820
DEBUG - 2022-07-29 08:58:58 --> Total execution time: 0.0715
DEBUG - 2022-07-29 08:59:05 --> Total execution time: 0.0666
DEBUG - 2022-07-29 08:59:07 --> Total execution time: 0.0670
DEBUG - 2022-07-29 08:59:34 --> Total execution time: 0.0846
DEBUG - 2022-07-29 09:00:32 --> Total execution time: 0.0672
DEBUG - 2022-07-29 09:00:35 --> Total execution time: 0.0852
DEBUG - 2022-07-29 09:00:37 --> Total execution time: 0.0682
DEBUG - 2022-07-29 09:00:41 --> Total execution time: 0.0788
DEBUG - 2022-07-29 09:00:49 --> Total execution time: 0.0750
DEBUG - 2022-07-29 09:00:52 --> Total execution time: 0.0676
DEBUG - 2022-07-29 09:01:04 --> Total execution time: 0.0663
DEBUG - 2022-07-29 09:01:37 --> Total execution time: 0.1050
DEBUG - 2022-07-29 09:01:58 --> Total execution time: 0.0719
DEBUG - 2022-07-29 09:02:01 --> Total execution time: 0.1337
DEBUG - 2022-07-29 09:02:12 --> Total execution time: 0.0665
DEBUG - 2022-07-29 09:02:42 --> Total execution time: 0.1906
DEBUG - 2022-07-29 09:03:42 --> Total execution time: 0.0793
DEBUG - 2022-07-29 09:03:42 --> Total execution time: 0.0768
DEBUG - 2022-07-29 09:03:56 --> Total execution time: 0.0753
DEBUG - 2022-07-29 09:04:03 --> Total execution time: 0.0728
DEBUG - 2022-07-29 09:04:18 --> Total execution time: 0.0911
DEBUG - 2022-07-29 09:04:18 --> Total execution time: 0.1850
DEBUG - 2022-07-29 09:04:36 --> Total execution time: 0.1985
DEBUG - 2022-07-29 09:04:43 --> Total execution time: 0.0746
DEBUG - 2022-07-29 09:05:00 --> Total execution time: 0.1371
DEBUG - 2022-07-29 09:05:57 --> Total execution time: 0.0440
DEBUG - 2022-07-29 09:05:58 --> Total execution time: 0.0711
DEBUG - 2022-07-29 09:06:02 --> Total execution time: 0.0416
DEBUG - 2022-07-29 09:06:07 --> Total execution time: 0.1105
DEBUG - 2022-07-29 09:06:15 --> Total execution time: 0.0956
DEBUG - 2022-07-29 09:06:20 --> Total execution time: 0.1362
DEBUG - 2022-07-29 09:06:20 --> Total execution time: 0.1571
DEBUG - 2022-07-29 09:06:33 --> Total execution time: 0.0870
DEBUG - 2022-07-29 09:06:33 --> Total execution time: 0.1287
DEBUG - 2022-07-29 09:06:58 --> Total execution time: 0.1220
DEBUG - 2022-07-29 09:07:01 --> Total execution time: 0.0473
DEBUG - 2022-07-29 09:07:02 --> Total execution time: 0.0459
DEBUG - 2022-07-29 09:07:05 --> Total execution time: 0.0801
DEBUG - 2022-07-29 09:07:05 --> Total execution time: 0.0754
DEBUG - 2022-07-29 09:07:28 --> Total execution time: 0.1632
DEBUG - 2022-07-29 09:08:40 --> Total execution time: 0.0648
DEBUG - 2022-07-29 09:08:44 --> Total execution time: 0.0716
DEBUG - 2022-07-29 09:08:54 --> Total execution time: 0.0999
DEBUG - 2022-07-29 09:08:59 --> Total execution time: 0.0692
DEBUG - 2022-07-29 09:10:34 --> Total execution time: 0.0871
DEBUG - 2022-07-29 09:11:01 --> Total execution time: 0.0510
DEBUG - 2022-07-29 09:11:02 --> Total execution time: 0.0883
DEBUG - 2022-07-29 09:12:02 --> Total execution time: 1.9879
DEBUG - 2022-07-29 09:12:19 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 09:12:20 --> Total execution time: 0.0842
DEBUG - 2022-07-29 09:12:25 --> Total execution time: 0.0894
DEBUG - 2022-07-29 09:12:30 --> Total execution time: 0.0815
DEBUG - 2022-07-29 09:12:44 --> Total execution time: 0.1138
DEBUG - 2022-07-29 09:12:50 --> Total execution time: 0.0949
DEBUG - 2022-07-29 09:12:58 --> Total execution time: 0.1037
DEBUG - 2022-07-29 09:13:57 --> Total execution time: 0.0993
DEBUG - 2022-07-29 09:14:01 --> Total execution time: 0.0462
DEBUG - 2022-07-29 09:14:01 --> Total execution time: 0.0461
DEBUG - 2022-07-29 09:14:04 --> Total execution time: 0.0586
DEBUG - 2022-07-29 09:14:16 --> Total execution time: 0.0720
DEBUG - 2022-07-29 09:14:25 --> Total execution time: 0.1467
DEBUG - 2022-07-29 09:14:30 --> Total execution time: 0.1383
DEBUG - 2022-07-29 09:14:55 --> Total execution time: 1.4722
DEBUG - 2022-07-29 09:15:09 --> Total execution time: 0.0749
DEBUG - 2022-07-29 09:15:14 --> Total execution time: 0.1811
DEBUG - 2022-07-29 09:15:35 --> Total execution time: 0.1700
DEBUG - 2022-07-29 09:15:43 --> Total execution time: 0.1138
DEBUG - 2022-07-29 09:16:28 --> Total execution time: 0.0478
DEBUG - 2022-07-29 09:16:44 --> Total execution time: 0.0484
DEBUG - 2022-07-29 09:17:46 --> Total execution time: 0.0672
DEBUG - 2022-07-29 09:18:44 --> Total execution time: 0.1921
DEBUG - 2022-07-29 09:21:35 --> Total execution time: 0.1897
DEBUG - 2022-07-29 09:29:21 --> Total execution time: 0.2750
DEBUG - 2022-07-29 09:30:02 --> Total execution time: 0.1244
DEBUG - 2022-07-29 09:32:42 --> Total execution time: 0.2506
DEBUG - 2022-07-29 09:32:45 --> Total execution time: 0.0751
DEBUG - 2022-07-29 09:32:50 --> Total execution time: 0.0490
DEBUG - 2022-07-29 09:32:53 --> Total execution time: 0.0456
DEBUG - 2022-07-29 09:33:00 --> Total execution time: 0.0472
DEBUG - 2022-07-29 09:33:12 --> Total execution time: 0.0577
DEBUG - 2022-07-29 09:33:16 --> Total execution time: 0.0614
DEBUG - 2022-07-29 09:33:21 --> Total execution time: 0.0809
DEBUG - 2022-07-29 09:33:42 --> Total execution time: 0.4221
DEBUG - 2022-07-29 09:34:34 --> Total execution time: 0.0464
DEBUG - 2022-07-29 09:34:39 --> Total execution time: 0.0734
DEBUG - 2022-07-29 09:34:43 --> Total execution time: 0.1751
DEBUG - 2022-07-29 09:34:49 --> Total execution time: 0.0699
DEBUG - 2022-07-29 09:34:52 --> Total execution time: 0.0761
DEBUG - 2022-07-29 09:34:58 --> Total execution time: 0.1108
DEBUG - 2022-07-29 09:35:35 --> Total execution time: 0.1289
DEBUG - 2022-07-29 09:35:35 --> Total execution time: 0.1383
DEBUG - 2022-07-29 09:35:38 --> Total execution time: 0.1113
DEBUG - 2022-07-29 09:35:49 --> Total execution time: 0.0902
DEBUG - 2022-07-29 09:35:54 --> Total execution time: 0.0750
DEBUG - 2022-07-29 09:36:03 --> Total execution time: 0.0513
DEBUG - 2022-07-29 09:36:04 --> Total execution time: 0.0460
DEBUG - 2022-07-29 09:36:09 --> Total execution time: 0.0733
DEBUG - 2022-07-29 09:36:13 --> Total execution time: 0.1137
DEBUG - 2022-07-29 09:36:17 --> Total execution time: 0.0909
DEBUG - 2022-07-29 09:36:20 --> Total execution time: 0.1241
DEBUG - 2022-07-29 09:36:23 --> Total execution time: 0.0800
DEBUG - 2022-07-29 09:36:28 --> Total execution time: 0.0813
DEBUG - 2022-07-29 09:36:34 --> Total execution time: 0.1912
DEBUG - 2022-07-29 09:36:42 --> Total execution time: 0.0726
DEBUG - 2022-07-29 09:37:49 --> Total execution time: 0.0583
DEBUG - 2022-07-29 09:38:13 --> Total execution time: 2.1453
DEBUG - 2022-07-29 09:39:49 --> Total execution time: 0.0951
DEBUG - 2022-07-29 09:39:59 --> Total execution time: 0.1004
DEBUG - 2022-07-29 09:40:09 --> Total execution time: 0.0693
DEBUG - 2022-07-29 09:40:15 --> Total execution time: 1.4984
DEBUG - 2022-07-29 09:40:38 --> Total execution time: 0.0533
DEBUG - 2022-07-29 09:41:19 --> Total execution time: 0.1017
DEBUG - 2022-07-29 09:41:21 --> Total execution time: 0.1097
DEBUG - 2022-07-29 09:41:25 --> Total execution time: 0.0818
DEBUG - 2022-07-29 09:41:27 --> Total execution time: 0.0799
DEBUG - 2022-07-29 09:42:27 --> Total execution time: 0.2117
DEBUG - 2022-07-29 09:42:28 --> Total execution time: 0.0717
DEBUG - 2022-07-29 09:42:36 --> Total execution time: 0.1005
DEBUG - 2022-07-29 09:42:40 --> Total execution time: 0.0723
DEBUG - 2022-07-29 09:42:48 --> Total execution time: 1.5259
DEBUG - 2022-07-29 09:43:31 --> Total execution time: 0.0847
DEBUG - 2022-07-29 09:43:32 --> Total execution time: 0.1321
DEBUG - 2022-07-29 09:43:35 --> Total execution time: 0.0782
DEBUG - 2022-07-29 09:43:49 --> Total execution time: 0.0493
DEBUG - 2022-07-29 09:43:50 --> Total execution time: 0.0952
DEBUG - 2022-07-29 09:47:46 --> Total execution time: 0.1510
DEBUG - 2022-07-29 09:47:55 --> Total execution time: 0.0738
DEBUG - 2022-07-29 09:48:18 --> Total execution time: 0.3070
DEBUG - 2022-07-29 09:48:29 --> Total execution time: 0.1334
DEBUG - 2022-07-29 09:48:54 --> Total execution time: 0.1107
DEBUG - 2022-07-29 09:49:31 --> Total execution time: 0.0795
DEBUG - 2022-07-29 09:49:40 --> Total execution time: 0.0807
DEBUG - 2022-07-29 09:49:42 --> Total execution time: 0.0884
DEBUG - 2022-07-29 09:49:47 --> Total execution time: 0.0499
DEBUG - 2022-07-29 09:50:23 --> Total execution time: 0.1752
DEBUG - 2022-07-29 09:50:24 --> Total execution time: 0.1010
DEBUG - 2022-07-29 09:50:27 --> Total execution time: 0.0904
DEBUG - 2022-07-29 09:50:35 --> Total execution time: 0.1335
DEBUG - 2022-07-29 09:50:40 --> Total execution time: 0.1746
DEBUG - 2022-07-29 09:50:42 --> Total execution time: 0.1076
DEBUG - 2022-07-29 09:50:42 --> Total execution time: 0.0955
DEBUG - 2022-07-29 09:51:13 --> Total execution time: 0.2462
DEBUG - 2022-07-29 09:51:43 --> Total execution time: 0.0989
DEBUG - 2022-07-29 09:51:52 --> Total execution time: 0.0902
DEBUG - 2022-07-29 09:51:58 --> Total execution time: 0.1309
DEBUG - 2022-07-29 09:52:17 --> Total execution time: 0.1378
DEBUG - 2022-07-29 09:52:42 --> Total execution time: 0.1186
DEBUG - 2022-07-29 09:53:02 --> Total execution time: 0.0986
DEBUG - 2022-07-29 09:53:15 --> Total execution time: 0.0545
DEBUG - 2022-07-29 09:53:19 --> Total execution time: 0.0468
DEBUG - 2022-07-29 09:53:34 --> Total execution time: 0.1067
DEBUG - 2022-07-29 09:53:49 --> Total execution time: 0.1521
DEBUG - 2022-07-29 09:54:04 --> Total execution time: 0.1136
DEBUG - 2022-07-29 09:54:05 --> Total execution time: 0.0483
DEBUG - 2022-07-29 09:54:10 --> Total execution time: 0.0875
DEBUG - 2022-07-29 09:54:11 --> Total execution time: 0.0868
DEBUG - 2022-07-29 09:54:59 --> Total execution time: 0.1753
DEBUG - 2022-07-29 09:57:14 --> Total execution time: 0.0714
DEBUG - 2022-07-29 09:57:14 --> Total execution time: 0.0541
DEBUG - 2022-07-29 09:58:03 --> Total execution time: 0.0852
DEBUG - 2022-07-29 10:00:10 --> Total execution time: 0.3651
DEBUG - 2022-07-29 10:00:22 --> Total execution time: 0.1050
DEBUG - 2022-07-29 10:00:27 --> Total execution time: 0.0880
DEBUG - 2022-07-29 10:00:37 --> Total execution time: 0.1306
DEBUG - 2022-07-29 10:00:47 --> Total execution time: 0.3138
DEBUG - 2022-07-29 10:01:08 --> Total execution time: 0.1218
DEBUG - 2022-07-29 10:01:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 10:02:00 --> Total execution time: 0.1847
DEBUG - 2022-07-29 10:05:19 --> Total execution time: 0.1408
DEBUG - 2022-07-29 10:05:23 --> Total execution time: 0.0794
DEBUG - 2022-07-29 10:05:34 --> Total execution time: 0.0879
DEBUG - 2022-07-29 10:05:42 --> Total execution time: 0.1720
DEBUG - 2022-07-29 10:05:44 --> Total execution time: 0.0698
DEBUG - 2022-07-29 10:05:55 --> Total execution time: 0.0650
DEBUG - 2022-07-29 10:06:01 --> Total execution time: 0.0835
DEBUG - 2022-07-29 10:06:11 --> Total execution time: 0.0695
DEBUG - 2022-07-29 10:06:15 --> Total execution time: 0.0715
DEBUG - 2022-07-29 10:06:17 --> Total execution time: 0.0649
DEBUG - 2022-07-29 10:06:23 --> Total execution time: 0.0926
DEBUG - 2022-07-29 10:06:30 --> Total execution time: 0.0976
DEBUG - 2022-07-29 10:09:29 --> Total execution time: 0.0783
DEBUG - 2022-07-29 10:10:34 --> Total execution time: 0.1206
DEBUG - 2022-07-29 10:10:47 --> Total execution time: 0.1940
DEBUG - 2022-07-29 10:13:56 --> Total execution time: 0.0573
DEBUG - 2022-07-29 10:14:31 --> Total execution time: 0.0651
DEBUG - 2022-07-29 10:14:57 --> Total execution time: 0.0686
DEBUG - 2022-07-29 10:19:23 --> Total execution time: 0.3565
DEBUG - 2022-07-29 10:22:21 --> Total execution time: 0.2771
DEBUG - 2022-07-29 10:22:29 --> Total execution time: 0.1166
DEBUG - 2022-07-29 10:22:30 --> Total execution time: 0.0811
DEBUG - 2022-07-29 10:22:42 --> Total execution time: 0.0804
DEBUG - 2022-07-29 10:22:47 --> Total execution time: 0.0803
DEBUG - 2022-07-29 10:22:54 --> Total execution time: 0.0743
DEBUG - 2022-07-29 10:29:09 --> Total execution time: 0.4147
DEBUG - 2022-07-29 10:29:28 --> Total execution time: 0.0866
DEBUG - 2022-07-29 00:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:30:02 --> Total execution time: 0.1360
DEBUG - 2022-07-29 00:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:30:04 --> Total execution time: 0.2412
DEBUG - 2022-07-29 00:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:30:08 --> Total execution time: 0.2571
DEBUG - 2022-07-29 00:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:30:17 --> Total execution time: 0.1416
DEBUG - 2022-07-29 00:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:30:27 --> Total execution time: 0.1381
DEBUG - 2022-07-29 00:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:30:42 --> Total execution time: 0.1276
DEBUG - 2022-07-29 00:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:30:49 --> Total execution time: 0.2099
DEBUG - 2022-07-29 00:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:30:51 --> Total execution time: 0.1158
DEBUG - 2022-07-29 00:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:30:57 --> Total execution time: 0.1163
DEBUG - 2022-07-29 00:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:01:32 --> No URI present. Default controller set.
DEBUG - 2022-07-29 00:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:31:32 --> Total execution time: 0.2057
DEBUG - 2022-07-29 00:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:31:34 --> Total execution time: 0.0872
DEBUG - 2022-07-29 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:01:56 --> No URI present. Default controller set.
DEBUG - 2022-07-29 00:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:31:56 --> Total execution time: 0.0564
DEBUG - 2022-07-29 00:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:31:57 --> Total execution time: 0.1039
DEBUG - 2022-07-29 00:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:01:59 --> No URI present. Default controller set.
DEBUG - 2022-07-29 00:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:31:59 --> Total execution time: 0.0845
DEBUG - 2022-07-29 00:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:32:06 --> Total execution time: 2.0248
DEBUG - 2022-07-29 00:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:02:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 00:02:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 00:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:02:45 --> No URI present. Default controller set.
DEBUG - 2022-07-29 00:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:32:45 --> Total execution time: 0.0730
DEBUG - 2022-07-29 00:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:02:48 --> No URI present. Default controller set.
DEBUG - 2022-07-29 00:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:32:48 --> Total execution time: 0.0695
DEBUG - 2022-07-29 00:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:32:49 --> Total execution time: 0.1541
DEBUG - 2022-07-29 00:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:02:51 --> No URI present. Default controller set.
DEBUG - 2022-07-29 00:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:32:52 --> Total execution time: 0.0988
DEBUG - 2022-07-29 00:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:33:01 --> Total execution time: 1.5346
DEBUG - 2022-07-29 00:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:03:01 --> No URI present. Default controller set.
DEBUG - 2022-07-29 00:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:33:01 --> Total execution time: 0.2123
DEBUG - 2022-07-29 00:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:04:34 --> No URI present. Default controller set.
DEBUG - 2022-07-29 00:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:34:34 --> Total execution time: 0.0825
DEBUG - 2022-07-29 00:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:34:36 --> Total execution time: 0.1033
DEBUG - 2022-07-29 00:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:41:30 --> Total execution time: 0.2553
DEBUG - 2022-07-29 00:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:12:06 --> No URI present. Default controller set.
DEBUG - 2022-07-29 00:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:42:07 --> Total execution time: 0.1444
DEBUG - 2022-07-29 00:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:22:50 --> No URI present. Default controller set.
DEBUG - 2022-07-29 00:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:52:50 --> Total execution time: 0.2745
DEBUG - 2022-07-29 00:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:52:51 --> Total execution time: 0.1032
DEBUG - 2022-07-29 00:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:23:10 --> No URI present. Default controller set.
DEBUG - 2022-07-29 00:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:53:10 --> Total execution time: 0.0450
DEBUG - 2022-07-29 00:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:53:15 --> Total execution time: 0.0740
DEBUG - 2022-07-29 00:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:53:23 --> Total execution time: 0.1012
DEBUG - 2022-07-29 00:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:23:26 --> Total execution time: 0.0833
DEBUG - 2022-07-29 00:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:23:32 --> Total execution time: 0.1326
DEBUG - 2022-07-29 00:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:53:37 --> Total execution time: 0.0776
DEBUG - 2022-07-29 00:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:23:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 00:23:56 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-29 00:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:24:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 00:24:00 --> 404 Page Not Found: Wp-json/wp
DEBUG - 2022-07-29 00:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:58:03 --> Total execution time: 0.1259
DEBUG - 2022-07-29 00:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:58:29 --> Total execution time: 0.1010
DEBUG - 2022-07-29 00:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:58:41 --> Total execution time: 0.0739
DEBUG - 2022-07-29 00:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:58:59 --> Total execution time: 0.0647
DEBUG - 2022-07-29 00:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:59:00 --> Total execution time: 0.0754
DEBUG - 2022-07-29 00:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:29:14 --> Total execution time: 0.1184
DEBUG - 2022-07-29 00:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:29:24 --> Total execution time: 0.1139
DEBUG - 2022-07-29 00:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:59:51 --> Total execution time: 0.0718
DEBUG - 2022-07-29 00:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:00:16 --> Total execution time: 0.1355
DEBUG - 2022-07-29 00:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:00:25 --> Total execution time: 0.0845
DEBUG - 2022-07-29 00:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:00:38 --> Total execution time: 0.0843
DEBUG - 2022-07-29 00:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:00:46 --> Total execution time: 0.0799
DEBUG - 2022-07-29 00:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:00:53 --> Total execution time: 0.0681
DEBUG - 2022-07-29 00:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:00:55 --> Total execution time: 0.1124
DEBUG - 2022-07-29 00:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:00:57 --> Total execution time: 0.1037
DEBUG - 2022-07-29 00:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:01:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 00:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:01:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 00:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:01:26 --> Total execution time: 0.1228
DEBUG - 2022-07-29 00:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:01:34 --> Total execution time: 0.1206
DEBUG - 2022-07-29 00:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:01:52 --> Total execution time: 0.0887
DEBUG - 2022-07-29 00:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:01:57 --> Total execution time: 0.1140
DEBUG - 2022-07-29 00:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:02:08 --> Total execution time: 0.0739
DEBUG - 2022-07-29 00:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:02:17 --> Total execution time: 0.1224
DEBUG - 2022-07-29 00:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:02:21 --> Total execution time: 0.0938
DEBUG - 2022-07-29 00:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:02:29 --> Total execution time: 0.1596
DEBUG - 2022-07-29 00:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:02:48 --> Total execution time: 0.0999
DEBUG - 2022-07-29 00:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:02:51 --> Total execution time: 0.0884
DEBUG - 2022-07-29 00:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:02:53 --> Total execution time: 0.0879
DEBUG - 2022-07-29 00:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:03:00 --> Total execution time: 0.0732
DEBUG - 2022-07-29 00:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:03:03 --> Total execution time: 0.0763
DEBUG - 2022-07-29 00:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:03:03 --> Total execution time: 0.0704
DEBUG - 2022-07-29 00:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:03:20 --> Total execution time: 0.1064
DEBUG - 2022-07-29 00:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:03:26 --> Total execution time: 0.0802
DEBUG - 2022-07-29 00:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:03:28 --> Total execution time: 0.0835
DEBUG - 2022-07-29 00:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:03:30 --> Total execution time: 0.1253
DEBUG - 2022-07-29 00:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:33:35 --> No URI present. Default controller set.
DEBUG - 2022-07-29 00:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:03:35 --> Total execution time: 0.1172
DEBUG - 2022-07-29 00:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:04:21 --> Total execution time: 0.1161
DEBUG - 2022-07-29 00:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:04:22 --> Total execution time: 0.0939
DEBUG - 2022-07-29 00:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:04:23 --> Total execution time: 0.1124
DEBUG - 2022-07-29 00:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:04:24 --> Total execution time: 0.1105
DEBUG - 2022-07-29 00:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:04:25 --> Total execution time: 0.1091
DEBUG - 2022-07-29 00:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:04:26 --> Total execution time: 0.1598
DEBUG - 2022-07-29 00:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:34:40 --> No URI present. Default controller set.
DEBUG - 2022-07-29 00:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:04:40 --> Total execution time: 0.1717
DEBUG - 2022-07-29 00:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:04:54 --> Total execution time: 0.0704
DEBUG - 2022-07-29 00:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:05:30 --> Total execution time: 0.0859
DEBUG - 2022-07-29 00:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:05:34 --> Total execution time: 0.0703
DEBUG - 2022-07-29 00:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:06:24 --> Total execution time: 0.1030
DEBUG - 2022-07-29 00:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:07:25 --> Total execution time: 0.0741
DEBUG - 2022-07-29 00:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:07:54 --> Total execution time: 0.0648
DEBUG - 2022-07-29 00:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:08:04 --> Total execution time: 0.0796
DEBUG - 2022-07-29 00:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:10:17 --> Total execution time: 0.1490
DEBUG - 2022-07-29 00:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:15:56 --> Total execution time: 0.1762
DEBUG - 2022-07-29 00:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:18:56 --> Total execution time: 0.2944
DEBUG - 2022-07-29 00:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:19:04 --> Total execution time: 0.2082
DEBUG - 2022-07-29 00:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:23:17 --> Total execution time: 0.1229
DEBUG - 2022-07-29 00:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:23:25 --> Total execution time: 0.9010
DEBUG - 2022-07-29 00:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 00:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 00:53:36 --> No URI present. Default controller set.
DEBUG - 2022-07-29 00:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 00:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:23:36 --> Total execution time: 0.2235
DEBUG - 2022-07-29 01:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:38:08 --> Total execution time: 134.4606
DEBUG - 2022-07-29 01:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:08:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 01:08:28 --> 404 Page Not Found: 502shtml/index
DEBUG - 2022-07-29 01:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:11:18 --> No URI present. Default controller set.
DEBUG - 2022-07-29 01:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:13:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-07-29 11:44:52 --> Query error: Commands out of sync; you can't run this command now - Invalid query: INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c4c8de9c9868f032e1b9e00380d034407a7d44fd', '132.154.177.148', 1659075292, '__ci_last_regenerate|i:1659075194;')
DEBUG - 2022-07-29 01:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:49:15 --> Total execution time: 0.3127
DEBUG - 2022-07-29 01:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:19:24 --> No URI present. Default controller set.
DEBUG - 2022-07-29 01:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:49:24 --> Total execution time: 0.1098
DEBUG - 2022-07-29 01:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:49:25 --> Total execution time: 0.1982
DEBUG - 2022-07-29 01:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:19:26 --> No URI present. Default controller set.
DEBUG - 2022-07-29 01:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:49:26 --> Total execution time: 0.0992
DEBUG - 2022-07-29 01:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:49:30 --> Total execution time: 0.0508
DEBUG - 2022-07-29 01:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:49:56 --> Total execution time: 0.1632
DEBUG - 2022-07-29 01:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:20:06 --> No URI present. Default controller set.
DEBUG - 2022-07-29 01:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:50:06 --> Total execution time: 0.1976
DEBUG - 2022-07-29 01:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:50:10 --> Total execution time: 0.1298
DEBUG - 2022-07-29 01:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:50:28 --> Total execution time: 0.0822
DEBUG - 2022-07-29 01:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:50:34 --> Total execution time: 0.2607
DEBUG - 2022-07-29 01:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:25:44 --> No URI present. Default controller set.
DEBUG - 2022-07-29 01:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:55:45 --> Total execution time: 0.4387
DEBUG - 2022-07-29 01:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:56:53 --> Total execution time: 0.1928
DEBUG - 2022-07-29 01:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:07:00 --> Total execution time: 0.3633
DEBUG - 2022-07-29 01:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:07:03 --> Total execution time: 0.1813
DEBUG - 2022-07-29 01:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:39:40 --> No URI present. Default controller set.
DEBUG - 2022-07-29 01:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:09:40 --> Total execution time: 0.2239
DEBUG - 2022-07-29 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:09:43 --> Total execution time: 0.1382
DEBUG - 2022-07-29 01:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:10:05 --> Total execution time: 0.1617
DEBUG - 2022-07-29 01:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:10:12 --> Total execution time: 0.0918
DEBUG - 2022-07-29 01:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:10:20 --> Total execution time: 0.0805
DEBUG - 2022-07-29 01:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:10:26 --> Total execution time: 0.0658
DEBUG - 2022-07-29 01:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:45:37 --> No URI present. Default controller set.
DEBUG - 2022-07-29 01:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:15:38 --> Total execution time: 0.2933
DEBUG - 2022-07-29 12:15:38 --> Total execution time: 0.3207
DEBUG - 2022-07-29 01:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:15:50 --> Total execution time: 0.0798
DEBUG - 2022-07-29 01:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:15:52 --> Total execution time: 0.0877
DEBUG - 2022-07-29 01:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:15:57 --> Total execution time: 0.1228
DEBUG - 2022-07-29 01:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:16:04 --> Total execution time: 0.1046
DEBUG - 2022-07-29 01:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:46:49 --> Total execution time: 0.0884
DEBUG - 2022-07-29 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:46:57 --> Total execution time: 0.1321
DEBUG - 2022-07-29 01:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:47:01 --> No URI present. Default controller set.
DEBUG - 2022-07-29 01:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:17:01 --> Total execution time: 0.0753
DEBUG - 2022-07-29 01:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:47:51 --> No URI present. Default controller set.
DEBUG - 2022-07-29 01:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:17:51 --> Total execution time: 0.0747
DEBUG - 2022-07-29 01:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:47:53 --> No URI present. Default controller set.
DEBUG - 2022-07-29 01:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:17:53 --> Total execution time: 0.0719
DEBUG - 2022-07-29 01:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:17:55 --> Total execution time: 0.0840
DEBUG - 2022-07-29 01:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:18:00 --> Total execution time: 0.0720
DEBUG - 2022-07-29 01:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:48:10 --> No URI present. Default controller set.
DEBUG - 2022-07-29 01:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:18:10 --> Total execution time: 0.0795
DEBUG - 2022-07-29 01:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:18:13 --> Total execution time: 0.0769
DEBUG - 2022-07-29 01:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:22:25 --> Total execution time: 0.0702
DEBUG - 2022-07-29 01:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:22:58 --> Total execution time: 0.1078
DEBUG - 2022-07-29 01:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:23:09 --> Total execution time: 0.1281
DEBUG - 2022-07-29 01:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:23:52 --> Total execution time: 0.1045
DEBUG - 2022-07-29 01:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:23:54 --> Total execution time: 0.0475
DEBUG - 2022-07-29 01:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:24:09 --> Total execution time: 0.0869
DEBUG - 2022-07-29 01:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:24:15 --> Total execution time: 0.0951
DEBUG - 2022-07-29 01:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:24:56 --> Total execution time: 0.0758
DEBUG - 2022-07-29 01:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:55:09 --> Total execution time: 0.0668
DEBUG - 2022-07-29 01:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:55:16 --> Total execution time: 0.1065
DEBUG - 2022-07-29 01:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:25:17 --> Total execution time: 0.1314
DEBUG - 2022-07-29 01:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:25:29 --> Total execution time: 0.0735
DEBUG - 2022-07-29 01:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:55:46 --> No URI present. Default controller set.
DEBUG - 2022-07-29 01:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:25:46 --> Total execution time: 0.0639
DEBUG - 2022-07-29 01:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:55:52 --> Total execution time: 0.0693
DEBUG - 2022-07-29 01:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:55:54 --> Total execution time: 0.0749
DEBUG - 2022-07-29 01:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:55:54 --> Total execution time: 0.1543
DEBUG - 2022-07-29 01:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:26:25 --> Total execution time: 0.1721
DEBUG - 2022-07-29 01:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:57:05 --> No URI present. Default controller set.
DEBUG - 2022-07-29 01:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:27:05 --> Total execution time: 0.0755
DEBUG - 2022-07-29 01:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:27:08 --> Total execution time: 0.0639
DEBUG - 2022-07-29 01:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:28:44 --> Total execution time: 0.0684
DEBUG - 2022-07-29 01:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:28:48 --> Total execution time: 0.1044
DEBUG - 2022-07-29 01:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:29:15 --> Total execution time: 0.0651
DEBUG - 2022-07-29 01:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:59:24 --> No URI present. Default controller set.
DEBUG - 2022-07-29 01:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:29:24 --> Total execution time: 0.0444
DEBUG - 2022-07-29 01:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:59:32 --> Total execution time: 0.0691
DEBUG - 2022-07-29 01:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 01:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 01:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:59:33 --> Total execution time: 0.0965
DEBUG - 2022-07-29 01:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 01:59:34 --> Total execution time: 0.1610
DEBUG - 2022-07-29 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:30:03 --> Total execution time: 0.0485
DEBUG - 2022-07-29 02:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:00:11 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:30:11 --> Total execution time: 0.1209
DEBUG - 2022-07-29 02:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:00:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 02:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:30:41 --> Total execution time: 2.1380
DEBUG - 2022-07-29 02:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:00:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 02:00:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 02:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:31:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 02:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:31:14 --> Total execution time: 0.0695
DEBUG - 2022-07-29 02:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:31:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 12:31:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 12:31:16 --> Total execution time: 0.2597
DEBUG - 2022-07-29 02:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:31:19 --> Total execution time: 0.0973
DEBUG - 2022-07-29 02:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:31:21 --> Total execution time: 0.0669
DEBUG - 2022-07-29 02:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:31:44 --> Total execution time: 0.0995
DEBUG - 2022-07-29 02:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:31:52 --> Total execution time: 0.0660
DEBUG - 2022-07-29 02:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:02:51 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:32:51 --> Total execution time: 0.2169
DEBUG - 2022-07-29 02:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:03:19 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:33:19 --> Total execution time: 0.0797
DEBUG - 2022-07-29 02:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:33:33 --> Total execution time: 0.0652
DEBUG - 2022-07-29 02:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:03:40 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:33:40 --> Total execution time: 0.0652
DEBUG - 2022-07-29 02:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:36:40 --> Total execution time: 0.1259
DEBUG - 2022-07-29 02:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:38:15 --> Total execution time: 0.0804
DEBUG - 2022-07-29 02:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:38:56 --> Total execution time: 0.0937
DEBUG - 2022-07-29 02:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:38:59 --> Total execution time: 0.0785
DEBUG - 2022-07-29 02:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:39:24 --> Total execution time: 0.1385
DEBUG - 2022-07-29 02:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:09:56 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:39:56 --> Total execution time: 0.2111
DEBUG - 2022-07-29 02:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:01 --> Total execution time: 0.0655
DEBUG - 2022-07-29 02:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:11 --> Total execution time: 0.0787
DEBUG - 2022-07-29 02:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:20 --> Total execution time: 0.0711
DEBUG - 2022-07-29 02:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:23 --> Total execution time: 0.0624
DEBUG - 2022-07-29 02:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:25 --> Total execution time: 0.0662
DEBUG - 2022-07-29 02:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:27 --> Total execution time: 0.0780
DEBUG - 2022-07-29 02:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:30 --> Total execution time: 0.0635
DEBUG - 2022-07-29 02:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:40:33 --> Total execution time: 0.0973
DEBUG - 2022-07-29 02:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:33 --> Total execution time: 0.0787
DEBUG - 2022-07-29 02:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:35 --> Total execution time: 0.0640
DEBUG - 2022-07-29 02:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:37 --> Total execution time: 0.1656
DEBUG - 2022-07-29 02:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:39 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:39 --> Total execution time: 0.0576
DEBUG - 2022-07-29 02:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:46 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:46 --> Total execution time: 0.0745
DEBUG - 2022-07-29 02:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:49 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:49 --> Total execution time: 0.0554
DEBUG - 2022-07-29 02:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:57 --> Total execution time: 0.0773
DEBUG - 2022-07-29 02:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:41:02 --> Total execution time: 0.0678
DEBUG - 2022-07-29 02:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:41:06 --> Total execution time: 0.0721
DEBUG - 2022-07-29 02:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:41:13 --> Total execution time: 0.1149
DEBUG - 2022-07-29 02:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:41:14 --> Total execution time: 0.0967
DEBUG - 2022-07-29 02:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:41:30 --> Total execution time: 0.0818
DEBUG - 2022-07-29 02:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:42:04 --> Total execution time: 0.1135
DEBUG - 2022-07-29 02:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:42:06 --> Total execution time: 0.0744
DEBUG - 2022-07-29 02:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:42:22 --> Total execution time: 0.0874
DEBUG - 2022-07-29 02:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:42:31 --> Total execution time: 0.0795
DEBUG - 2022-07-29 02:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:42:34 --> Total execution time: 0.0809
DEBUG - 2022-07-29 02:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:12:36 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:42:36 --> Total execution time: 0.0667
DEBUG - 2022-07-29 02:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:12:54 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:42:54 --> Total execution time: 0.0671
DEBUG - 2022-07-29 02:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:48:08 --> Total execution time: 0.0993
DEBUG - 2022-07-29 02:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:18:08 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:48:09 --> Total execution time: 0.5422
DEBUG - 2022-07-29 02:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:48:22 --> Total execution time: 0.0666
DEBUG - 2022-07-29 02:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:48:25 --> Total execution time: 0.0645
DEBUG - 2022-07-29 02:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:48:33 --> Total execution time: 0.0877
DEBUG - 2022-07-29 02:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:48:39 --> Total execution time: 0.0789
DEBUG - 2022-07-29 02:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:48:42 --> Total execution time: 0.0696
DEBUG - 2022-07-29 02:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:48:44 --> Total execution time: 0.1650
DEBUG - 2022-07-29 02:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:48:52 --> Total execution time: 0.0814
DEBUG - 2022-07-29 02:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:49:14 --> Total execution time: 0.0994
DEBUG - 2022-07-29 02:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:51:33 --> Total execution time: 0.1470
DEBUG - 2022-07-29 02:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:21:34 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:51:34 --> Total execution time: 0.0752
DEBUG - 2022-07-29 02:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:23:59 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:53:59 --> Total execution time: 0.2125
DEBUG - 2022-07-29 02:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:24:25 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:54:25 --> Total execution time: 0.0500
DEBUG - 2022-07-29 02:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:24:25 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:54:25 --> Total execution time: 0.0459
DEBUG - 2022-07-29 02:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:26:36 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:56:36 --> Total execution time: 0.1360
DEBUG - 2022-07-29 02:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:28:14 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:58:14 --> Total execution time: 0.0579
DEBUG - 2022-07-29 02:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:00:47 --> Total execution time: 0.0737
DEBUG - 2022-07-29 02:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:02:55 --> Total execution time: 0.0531
DEBUG - 2022-07-29 02:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:03:41 --> Total execution time: 0.0675
DEBUG - 2022-07-29 02:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:04:02 --> Total execution time: 0.0872
DEBUG - 2022-07-29 02:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:04:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 02:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:04:03 --> Total execution time: 0.0674
DEBUG - 2022-07-29 02:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:05:03 --> Total execution time: 0.1098
DEBUG - 2022-07-29 02:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:35:18 --> Total execution time: 0.0676
DEBUG - 2022-07-29 02:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:35:20 --> Total execution time: 0.0797
DEBUG - 2022-07-29 02:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:35:20 --> Total execution time: 0.1715
DEBUG - 2022-07-29 02:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:38:02 --> Total execution time: 0.0645
DEBUG - 2022-07-29 02:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:38:04 --> Total execution time: 0.0842
DEBUG - 2022-07-29 02:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:38:04 --> Total execution time: 0.1443
DEBUG - 2022-07-29 02:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:10:46 --> Total execution time: 0.0813
DEBUG - 2022-07-29 02:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:40:49 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:10:49 --> Total execution time: 0.0480
DEBUG - 2022-07-29 02:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:10:52 --> Total execution time: 0.0700
DEBUG - 2022-07-29 02:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:11:12 --> Total execution time: 0.0739
DEBUG - 2022-07-29 02:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:11:17 --> Total execution time: 0.0838
DEBUG - 2022-07-29 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:11:20 --> Total execution time: 0.0862
DEBUG - 2022-07-29 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:11:25 --> Total execution time: 0.0658
DEBUG - 2022-07-29 02:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:13:15 --> Total execution time: 0.0683
DEBUG - 2022-07-29 02:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:13:16 --> Total execution time: 0.0649
DEBUG - 2022-07-29 02:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:13:36 --> Total execution time: 0.0690
DEBUG - 2022-07-29 02:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:13:40 --> Total execution time: 0.1292
DEBUG - 2022-07-29 02:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:13:48 --> Total execution time: 0.0707
DEBUG - 2022-07-29 02:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:13:59 --> Total execution time: 0.0892
DEBUG - 2022-07-29 02:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:14:48 --> Total execution time: 0.0708
DEBUG - 2022-07-29 02:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:16:20 --> Total execution time: 0.0642
DEBUG - 2022-07-29 02:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:16:25 --> Total execution time: 0.0798
DEBUG - 2022-07-29 02:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 02:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:16:30 --> Total execution time: 0.0677
DEBUG - 2022-07-29 02:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:16:42 --> Total execution time: 0.0700
DEBUG - 2022-07-29 02:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:16:44 --> Total execution time: 0.0690
DEBUG - 2022-07-29 02:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:16:48 --> Total execution time: 0.0761
DEBUG - 2022-07-29 02:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:16:51 --> Total execution time: 0.0795
DEBUG - 2022-07-29 02:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:16:57 --> Total execution time: 0.0636
DEBUG - 2022-07-29 02:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:18:58 --> Total execution time: 0.0634
DEBUG - 2022-07-29 02:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:23:39 --> Total execution time: 0.1297
DEBUG - 2022-07-29 02:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:58:17 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:28:17 --> Total execution time: 0.1421
DEBUG - 2022-07-29 02:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 02:59:21 --> No URI present. Default controller set.
DEBUG - 2022-07-29 02:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 02:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:29:21 --> Total execution time: 0.0501
DEBUG - 2022-07-29 03:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:30:04 --> Total execution time: 0.1746
DEBUG - 2022-07-29 03:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:33:50 --> Total execution time: 0.2708
DEBUG - 2022-07-29 03:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:33:57 --> Total execution time: 0.0680
DEBUG - 2022-07-29 03:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:06:33 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:36:33 --> Total execution time: 0.1305
DEBUG - 2022-07-29 03:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:36:37 --> Total execution time: 0.0690
DEBUG - 2022-07-29 03:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:36:44 --> Total execution time: 0.0685
DEBUG - 2022-07-29 03:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:36:45 --> Total execution time: 0.0818
DEBUG - 2022-07-29 03:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:36:45 --> Total execution time: 0.0718
DEBUG - 2022-07-29 03:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:36:46 --> Total execution time: 0.0635
DEBUG - 2022-07-29 03:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:36:46 --> Total execution time: 0.0822
DEBUG - 2022-07-29 03:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:36:47 --> Total execution time: 0.0705
DEBUG - 2022-07-29 03:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:08:16 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:38:16 --> Total execution time: 0.1746
DEBUG - 2022-07-29 03:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:08:42 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:38:42 --> Total execution time: 0.0689
DEBUG - 2022-07-29 03:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:09:11 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:39:11 --> Total execution time: 0.0487
DEBUG - 2022-07-29 03:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:09:12 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:39:12 --> Total execution time: 0.0512
DEBUG - 2022-07-29 03:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:16:11 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:46:12 --> Total execution time: 0.3500
DEBUG - 2022-07-29 03:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:18:05 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:48:05 --> Total execution time: 0.0539
DEBUG - 2022-07-29 03:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:18:39 --> Total execution time: 0.0568
DEBUG - 2022-07-29 03:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:18:41 --> Total execution time: 0.0768
DEBUG - 2022-07-29 03:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:18:41 --> Total execution time: 0.0964
DEBUG - 2022-07-29 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:19:01 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:49:01 --> Total execution time: 0.0691
DEBUG - 2022-07-29 03:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:21:14 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:51:14 --> Total execution time: 0.0643
DEBUG - 2022-07-29 03:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:55:54 --> Total execution time: 0.2013
DEBUG - 2022-07-29 13:55:54 --> Total execution time: 0.2604
DEBUG - 2022-07-29 03:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:55:57 --> Total execution time: 0.1316
DEBUG - 2022-07-29 03:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:56:30 --> Total execution time: 0.1137
DEBUG - 2022-07-29 03:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:57:17 --> Total execution time: 0.0671
DEBUG - 2022-07-29 03:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:34:04 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:04:05 --> Total execution time: 0.1689
DEBUG - 2022-07-29 03:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:04:10 --> Total execution time: 0.0460
DEBUG - 2022-07-29 03:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:04:25 --> Total execution time: 0.0891
DEBUG - 2022-07-29 03:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:04:32 --> Total execution time: 0.1686
DEBUG - 2022-07-29 03:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:47:03 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:17:04 --> Total execution time: 0.2704
DEBUG - 2022-07-29 03:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:48:57 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:18:57 --> Total execution time: 0.0679
DEBUG - 2022-07-29 03:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:49:57 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:19:57 --> Total execution time: 0.1888
DEBUG - 2022-07-29 03:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:20:00 --> Total execution time: 0.0647
DEBUG - 2022-07-29 03:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:20:17 --> Total execution time: 0.0805
DEBUG - 2022-07-29 03:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:20:26 --> Total execution time: 0.0945
DEBUG - 2022-07-29 03:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:20:53 --> Total execution time: 0.1539
DEBUG - 2022-07-29 03:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:21:04 --> Total execution time: 0.0772
DEBUG - 2022-07-29 03:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:21:08 --> Total execution time: 0.0893
DEBUG - 2022-07-29 03:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:51:33 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:21:33 --> Total execution time: 0.0752
DEBUG - 2022-07-29 03:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:51:48 --> Total execution time: 0.0667
DEBUG - 2022-07-29 03:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:51:49 --> Total execution time: 0.0818
DEBUG - 2022-07-29 03:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:51:50 --> Total execution time: 0.1721
DEBUG - 2022-07-29 03:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:25:42 --> Total execution time: 0.0804
DEBUG - 2022-07-29 03:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 03:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:28:16 --> Total execution time: 0.0764
DEBUG - 2022-07-29 03:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:59:37 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:29:37 --> Total execution time: 0.0479
DEBUG - 2022-07-29 03:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 03:59:40 --> No URI present. Default controller set.
DEBUG - 2022-07-29 03:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 03:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:29:40 --> Total execution time: 0.0686
DEBUG - 2022-07-29 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:30:02 --> Total execution time: 0.0660
DEBUG - 2022-07-29 04:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:30:45 --> Total execution time: 0.0466
DEBUG - 2022-07-29 04:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:30:47 --> Total execution time: 0.0697
DEBUG - 2022-07-29 04:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:30:53 --> Total execution time: 0.0662
DEBUG - 2022-07-29 04:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:30:59 --> Total execution time: 0.0631
DEBUG - 2022-07-29 04:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:31:04 --> Total execution time: 0.0716
DEBUG - 2022-07-29 04:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:32:33 --> Total execution time: 0.0655
DEBUG - 2022-07-29 04:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:04:48 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:34:48 --> Total execution time: 0.1038
DEBUG - 2022-07-29 04:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:06:29 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:36:29 --> Total execution time: 0.0481
DEBUG - 2022-07-29 04:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:36:33 --> Total execution time: 0.0458
DEBUG - 2022-07-29 04:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:37:04 --> Total execution time: 0.1088
DEBUG - 2022-07-29 04:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:37:22 --> Total execution time: 0.0991
DEBUG - 2022-07-29 04:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:38:01 --> Total execution time: 0.1424
DEBUG - 2022-07-29 04:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:08:15 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:38:15 --> Total execution time: 0.0868
DEBUG - 2022-07-29 04:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:08:16 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:38:16 --> Total execution time: 0.1258
DEBUG - 2022-07-29 04:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:08:18 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:38:18 --> Total execution time: 0.0593
DEBUG - 2022-07-29 04:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:08:18 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:38:18 --> Total execution time: 0.0590
DEBUG - 2022-07-29 04:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:38:18 --> Total execution time: 0.0424
DEBUG - 2022-07-29 04:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:38:19 --> Total execution time: 0.0765
DEBUG - 2022-07-29 04:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:10:01 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:40:01 --> Total execution time: 0.0441
DEBUG - 2022-07-29 04:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:41:20 --> Total execution time: 0.0659
DEBUG - 2022-07-29 04:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:42:31 --> Total execution time: 0.0450
DEBUG - 2022-07-29 04:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:42:44 --> Total execution time: 0.0628
DEBUG - 2022-07-29 04:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:42:54 --> Total execution time: 0.0777
DEBUG - 2022-07-29 04:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:43:02 --> Total execution time: 0.0672
DEBUG - 2022-07-29 04:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:43:14 --> Total execution time: 0.0825
DEBUG - 2022-07-29 04:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:43:49 --> Total execution time: 0.0716
DEBUG - 2022-07-29 04:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:43:55 --> Total execution time: 0.0948
DEBUG - 2022-07-29 04:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:43:58 --> Total execution time: 0.0842
DEBUG - 2022-07-29 04:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:44:36 --> Total execution time: 0.1104
DEBUG - 2022-07-29 04:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:46:24 --> Total execution time: 0.0565
DEBUG - 2022-07-29 04:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:46:54 --> Total execution time: 0.1706
DEBUG - 2022-07-29 04:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:46:58 --> Total execution time: 0.0662
DEBUG - 2022-07-29 04:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:17:00 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:47:00 --> Total execution time: 0.0516
DEBUG - 2022-07-29 04:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:47:31 --> Total execution time: 0.0628
DEBUG - 2022-07-29 04:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:18:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 04:18:57 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-29 04:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:18:57 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:48:57 --> Total execution time: 0.0577
DEBUG - 2022-07-29 04:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 04:19:14 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-29 04:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:50:00 --> Total execution time: 0.0824
DEBUG - 2022-07-29 04:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:51:25 --> Total execution time: 0.0664
DEBUG - 2022-07-29 04:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:53:04 --> Total execution time: 0.0784
DEBUG - 2022-07-29 04:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:53:08 --> Total execution time: 0.1059
DEBUG - 2022-07-29 04:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:53:14 --> Total execution time: 0.0790
DEBUG - 2022-07-29 04:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:54:03 --> Total execution time: 0.1714
DEBUG - 2022-07-29 04:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:54:08 --> Total execution time: 0.0695
DEBUG - 2022-07-29 04:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:54:09 --> Total execution time: 0.1056
DEBUG - 2022-07-29 04:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:54:14 --> Total execution time: 0.0818
DEBUG - 2022-07-29 04:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:56:05 --> Total execution time: 0.0793
DEBUG - 2022-07-29 04:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:56:10 --> Total execution time: 0.1766
DEBUG - 2022-07-29 04:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:56:19 --> Total execution time: 0.0696
DEBUG - 2022-07-29 04:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:56:23 --> Total execution time: 0.0994
DEBUG - 2022-07-29 04:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:56:25 --> Total execution time: 0.0840
DEBUG - 2022-07-29 04:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:56:27 --> Total execution time: 0.0685
DEBUG - 2022-07-29 04:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:56:33 --> Total execution time: 0.0708
DEBUG - 2022-07-29 04:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:56:35 --> Total execution time: 0.0855
DEBUG - 2022-07-29 04:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:56:39 --> Total execution time: 0.0693
DEBUG - 2022-07-29 04:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:56:52 --> Total execution time: 0.0798
DEBUG - 2022-07-29 04:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:56:57 --> Total execution time: 0.0814
DEBUG - 2022-07-29 04:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:57:02 --> Total execution time: 0.0775
DEBUG - 2022-07-29 04:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:27:15 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:57:15 --> Total execution time: 0.1500
DEBUG - 2022-07-29 04:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:57:49 --> Total execution time: 0.1268
DEBUG - 2022-07-29 04:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:58:46 --> Total execution time: 0.0707
DEBUG - 2022-07-29 04:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:59:05 --> Total execution time: 0.0682
DEBUG - 2022-07-29 04:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:59:13 --> Total execution time: 0.0825
DEBUG - 2022-07-29 04:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:59:17 --> Total execution time: 0.0739
DEBUG - 2022-07-29 04:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:59:20 --> Total execution time: 0.0717
DEBUG - 2022-07-29 04:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:59:30 --> Total execution time: 0.0943
DEBUG - 2022-07-29 04:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:59:32 --> Total execution time: 0.0715
DEBUG - 2022-07-29 04:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:59:35 --> Total execution time: 0.0769
DEBUG - 2022-07-29 04:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:59:45 --> Total execution time: 0.1156
DEBUG - 2022-07-29 04:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:59:50 --> Total execution time: 0.0901
DEBUG - 2022-07-29 04:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:30:17 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:00:17 --> Total execution time: 0.0818
DEBUG - 2022-07-29 04:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:30:18 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:00:18 --> Total execution time: 0.0526
DEBUG - 2022-07-29 04:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:00:21 --> Total execution time: 0.0657
DEBUG - 2022-07-29 04:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:31:16 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:01:16 --> Total execution time: 0.0762
DEBUG - 2022-07-29 04:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:35:32 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:05:33 --> Total execution time: 0.2440
DEBUG - 2022-07-29 04:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:06:34 --> Total execution time: 0.1868
DEBUG - 2022-07-29 04:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:06:52 --> Total execution time: 0.0736
DEBUG - 2022-07-29 04:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:06:56 --> Total execution time: 0.0414
DEBUG - 2022-07-29 04:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:06:57 --> Total execution time: 0.0900
DEBUG - 2022-07-29 04:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:07:03 --> Total execution time: 0.0739
DEBUG - 2022-07-29 04:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:07:10 --> Total execution time: 0.0761
DEBUG - 2022-07-29 04:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:07:14 --> Total execution time: 0.0864
DEBUG - 2022-07-29 04:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:07:17 --> Total execution time: 0.1490
DEBUG - 2022-07-29 04:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:42:54 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:12:54 --> Total execution time: 0.2346
DEBUG - 2022-07-29 04:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:42:56 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:12:56 --> Total execution time: 0.0441
DEBUG - 2022-07-29 04:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:43:47 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:13:47 --> Total execution time: 0.0502
DEBUG - 2022-07-29 04:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:43:57 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:13:57 --> Total execution time: 0.0543
DEBUG - 2022-07-29 04:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:14:18 --> Total execution time: 0.0611
DEBUG - 2022-07-29 04:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:14:20 --> Total execution time: 0.0790
DEBUG - 2022-07-29 04:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:44:22 --> Total execution time: 0.1128
DEBUG - 2022-07-29 04:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:44:25 --> Total execution time: 0.0746
DEBUG - 2022-07-29 04:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:44:25 --> Total execution time: 0.1339
DEBUG - 2022-07-29 04:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:14:26 --> Total execution time: 0.0885
DEBUG - 2022-07-29 04:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:14:34 --> Total execution time: 0.1240
DEBUG - 2022-07-29 04:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:14:52 --> Total execution time: 0.1012
DEBUG - 2022-07-29 04:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:15:01 --> Total execution time: 0.1218
DEBUG - 2022-07-29 04:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:45:18 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:15:18 --> Total execution time: 0.0603
DEBUG - 2022-07-29 04:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:17:11 --> Total execution time: 0.0822
DEBUG - 2022-07-29 04:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:47:12 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:17:12 --> Total execution time: 0.0672
DEBUG - 2022-07-29 04:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:17:22 --> Total execution time: 0.0940
DEBUG - 2022-07-29 04:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:17:42 --> Total execution time: 0.0980
DEBUG - 2022-07-29 04:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:18:25 --> Total execution time: 0.0734
DEBUG - 2022-07-29 04:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:18:28 --> Total execution time: 0.0744
DEBUG - 2022-07-29 04:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:49:54 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:19:54 --> Total execution time: 0.0460
DEBUG - 2022-07-29 04:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:19:57 --> Total execution time: 0.0647
DEBUG - 2022-07-29 04:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:20:04 --> Total execution time: 0.0684
DEBUG - 2022-07-29 04:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:20:09 --> Total execution time: 0.0726
DEBUG - 2022-07-29 04:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:20:16 --> Total execution time: 0.1013
DEBUG - 2022-07-29 04:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:20:17 --> Total execution time: 0.0721
DEBUG - 2022-07-29 04:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:20:22 --> Total execution time: 0.0766
DEBUG - 2022-07-29 04:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:20:29 --> Total execution time: 0.0816
DEBUG - 2022-07-29 04:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:50:38 --> Total execution time: 0.1440
DEBUG - 2022-07-29 04:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:20:43 --> Total execution time: 0.1548
DEBUG - 2022-07-29 04:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:20:47 --> Total execution time: 0.1078
DEBUG - 2022-07-29 04:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:20:55 --> Total execution time: 0.1014
DEBUG - 2022-07-29 04:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:20:58 --> Total execution time: 0.0789
DEBUG - 2022-07-29 04:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:52:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 04:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:22:34 --> Total execution time: 2.0497
DEBUG - 2022-07-29 04:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:52:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 04:52:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 04:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:22:53 --> Total execution time: 0.0638
DEBUG - 2022-07-29 04:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:23:19 --> Total execution time: 0.1282
DEBUG - 2022-07-29 04:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:23:38 --> Total execution time: 0.1666
DEBUG - 2022-07-29 04:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:23:39 --> Total execution time: 0.0954
DEBUG - 2022-07-29 04:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:23:59 --> Total execution time: 0.0869
DEBUG - 2022-07-29 04:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:24:01 --> Total execution time: 0.1103
DEBUG - 2022-07-29 04:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 04:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:24:15 --> Total execution time: 0.0755
DEBUG - 2022-07-29 04:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:24:25 --> Total execution time: 0.0738
DEBUG - 2022-07-29 04:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:24:30 --> Total execution time: 0.1553
DEBUG - 2022-07-29 04:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:24:47 --> Total execution time: 0.0684
DEBUG - 2022-07-29 04:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:24:57 --> Total execution time: 0.0803
DEBUG - 2022-07-29 04:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:25:00 --> Total execution time: 0.0705
DEBUG - 2022-07-29 04:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:25:08 --> Total execution time: 0.0911
DEBUG - 2022-07-29 04:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:25:32 --> Total execution time: 0.0657
DEBUG - 2022-07-29 04:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:26:05 --> Total execution time: 0.0703
DEBUG - 2022-07-29 04:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:56:29 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:26:29 --> Total execution time: 0.0729
DEBUG - 2022-07-29 04:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:26:40 --> Total execution time: 0.0683
DEBUG - 2022-07-29 04:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:56:47 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:26:47 --> Total execution time: 0.0690
DEBUG - 2022-07-29 04:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:26:58 --> Total execution time: 0.0746
DEBUG - 2022-07-29 04:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:27:11 --> Total execution time: 0.0714
DEBUG - 2022-07-29 04:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 04:57:28 --> No URI present. Default controller set.
DEBUG - 2022-07-29 04:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 04:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:27:28 --> Total execution time: 0.0820
DEBUG - 2022-07-29 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:02 --> Total execution time: 0.1521
DEBUG - 2022-07-29 05:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:07 --> Total execution time: 0.2440
DEBUG - 2022-07-29 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:09 --> Total execution time: 0.1624
DEBUG - 2022-07-29 05:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:13 --> Total execution time: 0.1202
DEBUG - 2022-07-29 05:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:00:15 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:15 --> Total execution time: 0.1008
DEBUG - 2022-07-29 05:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:00:29 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:29 --> Total execution time: 0.0461
DEBUG - 2022-07-29 05:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:40 --> Total execution time: 1.8585
DEBUG - 2022-07-29 05:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:44 --> Total execution time: 0.0682
DEBUG - 2022-07-29 05:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:31:00 --> Total execution time: 0.0806
DEBUG - 2022-07-29 05:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:01:07 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:31:07 --> Total execution time: 0.0816
DEBUG - 2022-07-29 05:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:01:13 --> Total execution time: 0.0911
DEBUG - 2022-07-29 05:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:01:15 --> Total execution time: 0.0994
DEBUG - 2022-07-29 05:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:01:15 --> Total execution time: 0.2686
DEBUG - 2022-07-29 05:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:01:23 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:31:23 --> Total execution time: 0.0788
DEBUG - 2022-07-29 05:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:31:32 --> Total execution time: 0.1727
DEBUG - 2022-07-29 05:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:32:58 --> Total execution time: 0.2530
DEBUG - 2022-07-29 05:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:36:21 --> Total execution time: 0.3377
DEBUG - 2022-07-29 05:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:36:25 --> Total execution time: 0.0872
DEBUG - 2022-07-29 05:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:36:34 --> Total execution time: 0.0903
DEBUG - 2022-07-29 05:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:36:54 --> Total execution time: 0.0666
DEBUG - 2022-07-29 05:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:37:25 --> Total execution time: 0.0740
DEBUG - 2022-07-29 05:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:39:09 --> Total execution time: 0.0441
DEBUG - 2022-07-29 05:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:40:59 --> Total execution time: 0.0745
DEBUG - 2022-07-29 05:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:11:04 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:41:04 --> Total execution time: 0.0670
DEBUG - 2022-07-29 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:41:09 --> Total execution time: 0.0648
DEBUG - 2022-07-29 05:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:41:29 --> Total execution time: 0.0700
DEBUG - 2022-07-29 05:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:41:49 --> Total execution time: 0.0750
DEBUG - 2022-07-29 05:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:42:38 --> Total execution time: 0.0441
DEBUG - 2022-07-29 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:16:34 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:46:34 --> Total execution time: 0.1181
DEBUG - 2022-07-29 05:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:19:50 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:49:50 --> Total execution time: 0.1462
DEBUG - 2022-07-29 05:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:19:51 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:49:51 --> Total execution time: 0.0394
DEBUG - 2022-07-29 05:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:50:30 --> Total execution time: 0.0647
DEBUG - 2022-07-29 05:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:51:10 --> Total execution time: 0.0629
DEBUG - 2022-07-29 05:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:51:38 --> Total execution time: 0.0674
DEBUG - 2022-07-29 05:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:52:29 --> Total execution time: 0.1147
DEBUG - 2022-07-29 05:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:53:58 --> Total execution time: 0.0695
DEBUG - 2022-07-29 05:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:24:50 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:54:50 --> Total execution time: 0.0536
DEBUG - 2022-07-29 05:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:25:15 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:55:15 --> Total execution time: 0.0800
DEBUG - 2022-07-29 05:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:55:39 --> Total execution time: 0.2225
DEBUG - 2022-07-29 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:25:53 --> Total execution time: 0.0905
DEBUG - 2022-07-29 05:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:25:55 --> Total execution time: 0.0670
DEBUG - 2022-07-29 05:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:25:55 --> Total execution time: 0.1483
DEBUG - 2022-07-29 05:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:55:55 --> Total execution time: 0.0720
DEBUG - 2022-07-29 05:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:56:05 --> Total execution time: 0.0700
DEBUG - 2022-07-29 05:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:56:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 05:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:56:06 --> Total execution time: 0.0649
DEBUG - 2022-07-29 05:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:27:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 05:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:57:43 --> Total execution time: 2.1653
DEBUG - 2022-07-29 05:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:57:44 --> Total execution time: 0.0385
DEBUG - 2022-07-29 05:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 05:27:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 05:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:58:00 --> Total execution time: 0.0690
DEBUG - 2022-07-29 05:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:58:03 --> Total execution time: 0.0706
DEBUG - 2022-07-29 05:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:28:29 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:58:29 --> Total execution time: 0.0711
DEBUG - 2022-07-29 05:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:58:37 --> Total execution time: 0.0644
DEBUG - 2022-07-29 05:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:58:40 --> Total execution time: 0.0395
DEBUG - 2022-07-29 05:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:58:54 --> Total execution time: 0.0771
DEBUG - 2022-07-29 05:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:59:49 --> Total execution time: 0.0895
DEBUG - 2022-07-29 05:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:59:54 --> Total execution time: 0.0698
DEBUG - 2022-07-29 05:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:00:17 --> Total execution time: 0.1790
DEBUG - 2022-07-29 05:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:01:02 --> Total execution time: 0.1246
DEBUG - 2022-07-29 05:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:01:54 --> Total execution time: 0.0846
DEBUG - 2022-07-29 05:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:32:03 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:02:03 --> Total execution time: 0.0815
DEBUG - 2022-07-29 05:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:02:33 --> Total execution time: 1.6683
DEBUG - 2022-07-29 05:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:33:33 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:03:34 --> Total execution time: 0.0962
DEBUG - 2022-07-29 05:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:03:35 --> Total execution time: 0.1878
DEBUG - 2022-07-29 05:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:03:48 --> Total execution time: 0.0675
DEBUG - 2022-07-29 05:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:03:55 --> Total execution time: 0.0903
DEBUG - 2022-07-29 05:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:04:36 --> Total execution time: 0.0720
DEBUG - 2022-07-29 05:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:35:17 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:05:17 --> Total execution time: 0.0647
DEBUG - 2022-07-29 05:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:05:52 --> Total execution time: 0.0704
DEBUG - 2022-07-29 05:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:06:09 --> Total execution time: 0.0754
DEBUG - 2022-07-29 05:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:06:20 --> Total execution time: 0.0752
DEBUG - 2022-07-29 05:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:06:40 --> Total execution time: 0.0759
DEBUG - 2022-07-29 05:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:06:50 --> Total execution time: 0.0708
DEBUG - 2022-07-29 05:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:38:55 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:08:55 --> Total execution time: 0.0495
DEBUG - 2022-07-29 05:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:08:59 --> Total execution time: 0.0724
DEBUG - 2022-07-29 05:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:09:14 --> Total execution time: 0.0711
DEBUG - 2022-07-29 05:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:09:20 --> Total execution time: 0.0773
DEBUG - 2022-07-29 05:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:09:40 --> Total execution time: 0.1871
DEBUG - 2022-07-29 05:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:10:00 --> Total execution time: 0.4528
DEBUG - 2022-07-29 05:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:40:07 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:10:07 --> Total execution time: 0.0666
DEBUG - 2022-07-29 05:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:11:29 --> Total execution time: 0.2226
DEBUG - 2022-07-29 05:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:42:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 05:42:42 --> 404 Page Not Found: Well-known/traffic-advice
DEBUG - 2022-07-29 05:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:42:43 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:12:43 --> Total execution time: 0.0446
DEBUG - 2022-07-29 05:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:12:49 --> Total execution time: 0.0838
DEBUG - 2022-07-29 05:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:12:52 --> Total execution time: 0.0744
DEBUG - 2022-07-29 05:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:12:53 --> Total execution time: 0.0546
DEBUG - 2022-07-29 05:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:12:58 --> Total execution time: 0.0681
DEBUG - 2022-07-29 05:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:13:03 --> Total execution time: 0.0784
DEBUG - 2022-07-29 05:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:13:08 --> Total execution time: 0.0755
DEBUG - 2022-07-29 05:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:13:14 --> Total execution time: 0.0679
DEBUG - 2022-07-29 05:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:13:25 --> Total execution time: 0.0703
DEBUG - 2022-07-29 05:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:13:31 --> Total execution time: 0.0798
DEBUG - 2022-07-29 05:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:43:31 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:13:31 --> Total execution time: 0.0728
DEBUG - 2022-07-29 05:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:44:08 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:14:08 --> Total execution time: 0.0681
DEBUG - 2022-07-29 05:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:15:02 --> Total execution time: 0.0955
DEBUG - 2022-07-29 05:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:15:14 --> Total execution time: 0.0764
DEBUG - 2022-07-29 05:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:45:42 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:15:42 --> Total execution time: 0.0540
DEBUG - 2022-07-29 05:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:45:42 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:15:42 --> Total execution time: 0.0505
DEBUG - 2022-07-29 05:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:46:38 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:16:38 --> Total execution time: 0.0476
DEBUG - 2022-07-29 05:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:16:46 --> Total execution time: 0.0453
DEBUG - 2022-07-29 05:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:18:16 --> Total execution time: 0.0975
DEBUG - 2022-07-29 05:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:18:29 --> Total execution time: 0.0886
DEBUG - 2022-07-29 05:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:18:53 --> Total execution time: 0.1584
DEBUG - 2022-07-29 05:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:19:09 --> Total execution time: 0.0853
DEBUG - 2022-07-29 05:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:20:19 --> Total execution time: 0.0598
DEBUG - 2022-07-29 05:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:27:19 --> Total execution time: 0.1122
DEBUG - 2022-07-29 05:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:27:25 --> Total execution time: 0.0889
DEBUG - 2022-07-29 05:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:27:31 --> Total execution time: 0.0894
DEBUG - 2022-07-29 05:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:27:34 --> Total execution time: 0.0713
DEBUG - 2022-07-29 05:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:28:09 --> Total execution time: 0.0819
DEBUG - 2022-07-29 05:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:28:15 --> Total execution time: 0.1285
DEBUG - 2022-07-29 05:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:28:18 --> Total execution time: 0.0991
DEBUG - 2022-07-29 05:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:28:25 --> Total execution time: 0.0794
DEBUG - 2022-07-29 05:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:28:26 --> Total execution time: 0.0820
DEBUG - 2022-07-29 05:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:29:03 --> Total execution time: 0.0911
DEBUG - 2022-07-29 05:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:29:09 --> Total execution time: 0.0767
DEBUG - 2022-07-29 05:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:29:14 --> Total execution time: 0.0850
DEBUG - 2022-07-29 05:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:59:17 --> No URI present. Default controller set.
DEBUG - 2022-07-29 05:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:29:17 --> Total execution time: 0.0764
DEBUG - 2022-07-29 05:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:29:18 --> Total execution time: 0.1684
DEBUG - 2022-07-29 05:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:29:22 --> Total execution time: 0.0681
DEBUG - 2022-07-29 05:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:29:31 --> Total execution time: 0.0788
DEBUG - 2022-07-29 05:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 05:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 05:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 05:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:29:34 --> Total execution time: 0.0644
DEBUG - 2022-07-29 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:30:02 --> Total execution time: 0.0861
DEBUG - 2022-07-29 06:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:30:05 --> Total execution time: 0.1343
DEBUG - 2022-07-29 06:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:30:10 --> Total execution time: 0.1302
DEBUG - 2022-07-29 06:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:30:14 --> Total execution time: 0.1239
DEBUG - 2022-07-29 06:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:30:19 --> Total execution time: 0.1169
DEBUG - 2022-07-29 06:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:38:06 --> Total execution time: 0.2530
DEBUG - 2022-07-29 06:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:10:10 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:40:10 --> Total execution time: 0.0589
DEBUG - 2022-07-29 06:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:40:24 --> Total execution time: 0.0696
DEBUG - 2022-07-29 06:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:41:12 --> Total execution time: 0.1763
DEBUG - 2022-07-29 06:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:41:22 --> Total execution time: 0.1267
DEBUG - 2022-07-29 06:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:42:03 --> Total execution time: 0.1435
DEBUG - 2022-07-29 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:12:48 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:42:48 --> Total execution time: 0.1010
DEBUG - 2022-07-29 06:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:42:48 --> Total execution time: 0.1005
DEBUG - 2022-07-29 06:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:42:51 --> Total execution time: 0.0763
DEBUG - 2022-07-29 06:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:12:55 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:42:55 --> Total execution time: 0.0554
DEBUG - 2022-07-29 06:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:42:56 --> Total execution time: 0.1134
DEBUG - 2022-07-29 06:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:42:57 --> Total execution time: 0.0806
DEBUG - 2022-07-29 06:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:43:03 --> Total execution time: 0.0756
DEBUG - 2022-07-29 06:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:43:08 --> Total execution time: 0.0733
DEBUG - 2022-07-29 06:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:43:08 --> Total execution time: 0.0804
DEBUG - 2022-07-29 06:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:43:11 --> Total execution time: 0.1318
DEBUG - 2022-07-29 06:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:43:16 --> Total execution time: 0.0778
DEBUG - 2022-07-29 06:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:43:20 --> Total execution time: 0.0847
DEBUG - 2022-07-29 06:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:43:25 --> Total execution time: 0.0656
DEBUG - 2022-07-29 06:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:13:33 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:43:33 --> Total execution time: 0.0491
DEBUG - 2022-07-29 06:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:44:23 --> Total execution time: 0.0676
DEBUG - 2022-07-29 06:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:14:23 --> Total execution time: 0.0796
DEBUG - 2022-07-29 06:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:14:26 --> Total execution time: 0.0654
DEBUG - 2022-07-29 06:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:14:26 --> Total execution time: 0.1569
DEBUG - 2022-07-29 06:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:14:38 --> Total execution time: 0.1036
DEBUG - 2022-07-29 06:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:14:45 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:44:45 --> Total execution time: 0.0698
DEBUG - 2022-07-29 06:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:45:58 --> Total execution time: 0.1789
DEBUG - 2022-07-29 06:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:46:06 --> Total execution time: 0.0927
DEBUG - 2022-07-29 06:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:46:12 --> Total execution time: 0.0997
DEBUG - 2022-07-29 06:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:46:17 --> Total execution time: 0.0813
DEBUG - 2022-07-29 06:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:46:20 --> Total execution time: 0.0761
DEBUG - 2022-07-29 06:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:16:26 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:46:26 --> Total execution time: 0.1080
DEBUG - 2022-07-29 06:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:46:28 --> Total execution time: 0.1283
DEBUG - 2022-07-29 06:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:46:38 --> Total execution time: 0.0812
DEBUG - 2022-07-29 06:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:46:45 --> Total execution time: 0.0716
DEBUG - 2022-07-29 06:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:46:48 --> Total execution time: 0.0897
DEBUG - 2022-07-29 06:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:46:56 --> Total execution time: 0.0786
DEBUG - 2022-07-29 06:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:48:36 --> Total execution time: 0.0734
DEBUG - 2022-07-29 06:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:48:39 --> Total execution time: 0.0711
DEBUG - 2022-07-29 06:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:48:43 --> Total execution time: 0.0963
DEBUG - 2022-07-29 06:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:48:48 --> Total execution time: 0.0729
DEBUG - 2022-07-29 06:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:48:51 --> Total execution time: 0.1022
DEBUG - 2022-07-29 06:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:48:55 --> Total execution time: 0.0699
DEBUG - 2022-07-29 06:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:49:02 --> Total execution time: 0.0703
DEBUG - 2022-07-29 06:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:49:07 --> Total execution time: 0.0912
DEBUG - 2022-07-29 06:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:49:20 --> Total execution time: 0.1124
DEBUG - 2022-07-29 06:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:49:23 --> Total execution time: 0.1058
DEBUG - 2022-07-29 06:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:49:26 --> Total execution time: 0.1676
DEBUG - 2022-07-29 06:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:49:51 --> Total execution time: 0.0723
DEBUG - 2022-07-29 06:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:50:01 --> Total execution time: 0.0829
DEBUG - 2022-07-29 06:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:50:26 --> Total execution time: 0.0709
DEBUG - 2022-07-29 06:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:50:29 --> Total execution time: 0.1129
DEBUG - 2022-07-29 06:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:50:32 --> Total execution time: 0.1055
DEBUG - 2022-07-29 06:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:50:53 --> Total execution time: 0.1062
DEBUG - 2022-07-29 06:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:50:56 --> Total execution time: 0.0869
DEBUG - 2022-07-29 06:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:51:07 --> Total execution time: 0.0709
DEBUG - 2022-07-29 06:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:51:11 --> Total execution time: 0.0737
DEBUG - 2022-07-29 06:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:51:20 --> Total execution time: 0.1869
DEBUG - 2022-07-29 06:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:51:22 --> Total execution time: 0.0854
DEBUG - 2022-07-29 06:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:51:26 --> Total execution time: 0.1051
DEBUG - 2022-07-29 06:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:51:32 --> Total execution time: 0.0776
DEBUG - 2022-07-29 06:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:21:57 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:51:57 --> Total execution time: 0.0515
DEBUG - 2022-07-29 06:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:52:01 --> Total execution time: 0.0421
DEBUG - 2022-07-29 06:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:53:18 --> Total execution time: 0.0700
DEBUG - 2022-07-29 06:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:53:27 --> Total execution time: 0.0708
DEBUG - 2022-07-29 06:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:53:27 --> Total execution time: 0.0962
DEBUG - 2022-07-29 06:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:53:33 --> Total execution time: 0.0746
DEBUG - 2022-07-29 06:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:53:39 --> Total execution time: 0.0730
DEBUG - 2022-07-29 06:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:53:55 --> Total execution time: 0.0642
DEBUG - 2022-07-29 06:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:54:14 --> Total execution time: 0.0659
DEBUG - 2022-07-29 06:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:54:15 --> Total execution time: 0.0770
DEBUG - 2022-07-29 06:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:54:24 --> Total execution time: 0.0909
DEBUG - 2022-07-29 06:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:54:34 --> Total execution time: 0.0661
DEBUG - 2022-07-29 06:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:24:54 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:54:54 --> Total execution time: 0.1370
DEBUG - 2022-07-29 06:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:28:16 --> Total execution time: 0.0835
DEBUG - 2022-07-29 06:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:28:17 --> Total execution time: 0.0792
DEBUG - 2022-07-29 06:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:28:18 --> Total execution time: 0.1144
DEBUG - 2022-07-29 06:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:28:22 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:58:22 --> Total execution time: 0.0823
DEBUG - 2022-07-29 06:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:58:32 --> Total execution time: 0.0880
DEBUG - 2022-07-29 06:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:58:41 --> Total execution time: 0.1004
DEBUG - 2022-07-29 06:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:58:48 --> Total execution time: 0.0978
DEBUG - 2022-07-29 06:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:59:04 --> Total execution time: 0.0770
DEBUG - 2022-07-29 06:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:59:05 --> Total execution time: 0.1907
DEBUG - 2022-07-29 06:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:59:10 --> Total execution time: 0.0659
DEBUG - 2022-07-29 06:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:59:13 --> Total execution time: 0.0648
DEBUG - 2022-07-29 06:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:59:59 --> Total execution time: 0.0666
DEBUG - 2022-07-29 06:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:00:02 --> Total execution time: 0.1571
DEBUG - 2022-07-29 06:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:02:25 --> Total execution time: 0.1633
DEBUG - 2022-07-29 06:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:33:00 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:03:00 --> Total execution time: 0.1993
DEBUG - 2022-07-29 06:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:03:05 --> Total execution time: 0.0688
DEBUG - 2022-07-29 06:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:03:10 --> Total execution time: 0.0645
DEBUG - 2022-07-29 06:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:03:20 --> Total execution time: 0.0700
DEBUG - 2022-07-29 06:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:03:28 --> Total execution time: 0.0712
DEBUG - 2022-07-29 06:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:03:32 --> Total execution time: 0.0957
DEBUG - 2022-07-29 06:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:03:45 --> Total execution time: 0.0664
DEBUG - 2022-07-29 06:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:04:22 --> Total execution time: 0.0669
DEBUG - 2022-07-29 06:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:04:37 --> Total execution time: 0.2812
DEBUG - 2022-07-29 06:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:04:54 --> Total execution time: 0.1983
DEBUG - 2022-07-29 06:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:04:56 --> Total execution time: 0.1027
DEBUG - 2022-07-29 06:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:05:32 --> Total execution time: 0.0749
DEBUG - 2022-07-29 06:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:05:40 --> Total execution time: 0.0759
DEBUG - 2022-07-29 06:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:05:53 --> Total execution time: 0.1239
DEBUG - 2022-07-29 06:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:06:07 --> Total execution time: 0.0823
DEBUG - 2022-07-29 06:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:06:11 --> Total execution time: 0.0707
DEBUG - 2022-07-29 06:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:06:13 --> Total execution time: 0.0991
DEBUG - 2022-07-29 06:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:06:21 --> Total execution time: 0.0918
DEBUG - 2022-07-29 06:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:06:54 --> Total execution time: 0.0647
DEBUG - 2022-07-29 06:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:07:48 --> Total execution time: 0.0726
DEBUG - 2022-07-29 06:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:07:51 --> Total execution time: 0.0752
DEBUG - 2022-07-29 06:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:37:54 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:07:54 --> Total execution time: 0.0501
DEBUG - 2022-07-29 06:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:08:12 --> Total execution time: 0.0649
DEBUG - 2022-07-29 06:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:08:23 --> Total execution time: 0.0750
DEBUG - 2022-07-29 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:08:34 --> Total execution time: 0.0798
DEBUG - 2022-07-29 06:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:08:35 --> Total execution time: 0.1236
DEBUG - 2022-07-29 06:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:08:41 --> Total execution time: 0.0696
DEBUG - 2022-07-29 06:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:08:44 --> Total execution time: 0.1006
DEBUG - 2022-07-29 06:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:08:49 --> Total execution time: 0.0740
DEBUG - 2022-07-29 06:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:40:53 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:10:53 --> Total execution time: 0.1459
DEBUG - 2022-07-29 06:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:41:10 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:11:10 --> Total execution time: 0.0772
DEBUG - 2022-07-29 06:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:11:14 --> Total execution time: 0.1867
DEBUG - 2022-07-29 06:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:11:18 --> Total execution time: 0.1432
DEBUG - 2022-07-29 06:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:12:23 --> Total execution time: 0.0432
DEBUG - 2022-07-29 06:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:12:36 --> Total execution time: 0.0659
DEBUG - 2022-07-29 06:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:13:00 --> Total execution time: 0.0732
DEBUG - 2022-07-29 06:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:13:34 --> Total execution time: 0.2530
DEBUG - 2022-07-29 06:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:13:49 --> Total execution time: 0.0764
DEBUG - 2022-07-29 06:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:44:03 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:14:03 --> Total execution time: 0.0544
DEBUG - 2022-07-29 06:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:44:05 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:14:05 --> Total execution time: 0.0690
DEBUG - 2022-07-29 06:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:44:27 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:14:27 --> Total execution time: 0.0657
DEBUG - 2022-07-29 06:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:15:18 --> Total execution time: 0.0637
DEBUG - 2022-07-29 06:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:15:22 --> Total execution time: 0.0960
DEBUG - 2022-07-29 06:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:15:30 --> Total execution time: 0.0626
DEBUG - 2022-07-29 06:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:15:34 --> Total execution time: 0.0721
DEBUG - 2022-07-29 06:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:15:40 --> Total execution time: 0.0854
DEBUG - 2022-07-29 06:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:15:40 --> Total execution time: 0.0689
DEBUG - 2022-07-29 06:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:15:43 --> Total execution time: 0.0740
DEBUG - 2022-07-29 06:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:15:45 --> Total execution time: 0.0973
DEBUG - 2022-07-29 06:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:15:54 --> Total execution time: 0.0675
DEBUG - 2022-07-29 06:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:16:01 --> Total execution time: 0.0724
DEBUG - 2022-07-29 06:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:16:29 --> Total execution time: 0.1577
DEBUG - 2022-07-29 06:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:16:30 --> Total execution time: 0.1409
DEBUG - 2022-07-29 06:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:16:30 --> Total execution time: 0.0955
DEBUG - 2022-07-29 06:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:16:33 --> Total execution time: 0.1109
DEBUG - 2022-07-29 06:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:16:34 --> Total execution time: 0.1232
DEBUG - 2022-07-29 06:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:16:34 --> Total execution time: 0.0966
DEBUG - 2022-07-29 06:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:16:41 --> Total execution time: 0.0676
DEBUG - 2022-07-29 06:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:16:44 --> Total execution time: 0.0723
DEBUG - 2022-07-29 06:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:46:47 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:16:47 --> Total execution time: 0.0478
DEBUG - 2022-07-29 06:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:16:53 --> Total execution time: 0.0917
DEBUG - 2022-07-29 06:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:16:57 --> Total execution time: 0.1252
DEBUG - 2022-07-29 06:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:47:01 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:17:01 --> Total execution time: 0.0646
DEBUG - 2022-07-29 06:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:17:02 --> Total execution time: 0.0893
DEBUG - 2022-07-29 06:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:17:07 --> Total execution time: 0.0725
DEBUG - 2022-07-29 06:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:17:08 --> Total execution time: 0.0960
DEBUG - 2022-07-29 06:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:17:12 --> Total execution time: 0.0961
DEBUG - 2022-07-29 06:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:17:14 --> Total execution time: 0.0911
DEBUG - 2022-07-29 06:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:47:22 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:17:22 --> Total execution time: 0.0758
DEBUG - 2022-07-29 06:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:18:34 --> Total execution time: 0.0910
DEBUG - 2022-07-29 06:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:18:39 --> Total execution time: 0.0691
DEBUG - 2022-07-29 06:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:18:41 --> Total execution time: 0.0915
DEBUG - 2022-07-29 06:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:18:53 --> Total execution time: 0.0664
DEBUG - 2022-07-29 06:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:51:17 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:21:18 --> Total execution time: 0.2759
DEBUG - 2022-07-29 06:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:21:33 --> Total execution time: 0.1219
DEBUG - 2022-07-29 06:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:21:46 --> Total execution time: 0.2359
DEBUG - 2022-07-29 06:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:21:50 --> Total execution time: 0.2707
DEBUG - 2022-07-29 06:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:51:50 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:21:50 --> Total execution time: 0.1806
DEBUG - 2022-07-29 06:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:51:57 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:21:57 --> Total execution time: 0.1770
DEBUG - 2022-07-29 06:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:52:01 --> Total execution time: 0.0670
DEBUG - 2022-07-29 06:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:22:01 --> Total execution time: 0.1426
DEBUG - 2022-07-29 06:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:52:02 --> Total execution time: 0.0715
DEBUG - 2022-07-29 06:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:52:02 --> Total execution time: 0.2245
DEBUG - 2022-07-29 06:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:52:09 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:22:09 --> Total execution time: 0.0756
DEBUG - 2022-07-29 06:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:52:20 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:22:20 --> Total execution time: 0.1107
DEBUG - 2022-07-29 06:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:52:20 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:22:21 --> Total execution time: 0.6871
DEBUG - 2022-07-29 06:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:22:24 --> Total execution time: 0.1891
DEBUG - 2022-07-29 06:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:22:30 --> Total execution time: 0.1304
DEBUG - 2022-07-29 06:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:53:12 --> Total execution time: 0.0673
DEBUG - 2022-07-29 06:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:53:18 --> Total execution time: 0.1589
DEBUG - 2022-07-29 06:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:53:48 --> Total execution time: 0.0665
DEBUG - 2022-07-29 06:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:53:49 --> Total execution time: 0.0688
DEBUG - 2022-07-29 06:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:53:49 --> Total execution time: 0.1543
DEBUG - 2022-07-29 06:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:23:50 --> Total execution time: 0.0907
DEBUG - 2022-07-29 06:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:23:59 --> Total execution time: 0.0832
DEBUG - 2022-07-29 06:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:24:02 --> Total execution time: 0.0719
DEBUG - 2022-07-29 06:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:54:04 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:24:04 --> Total execution time: 0.0895
DEBUG - 2022-07-29 06:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:54:19 --> Total execution time: 0.0634
DEBUG - 2022-07-29 06:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:54:20 --> Total execution time: 0.0736
DEBUG - 2022-07-29 06:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:54:21 --> Total execution time: 0.1172
DEBUG - 2022-07-29 06:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:55:42 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:25:42 --> Total execution time: 0.2076
DEBUG - 2022-07-29 06:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:55:54 --> Total execution time: 0.0801
DEBUG - 2022-07-29 06:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:55:56 --> Total execution time: 0.0691
DEBUG - 2022-07-29 06:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:55:56 --> Total execution time: 0.1287
DEBUG - 2022-07-29 06:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:56:03 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:26:03 --> Total execution time: 0.0738
DEBUG - 2022-07-29 06:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:56:06 --> No URI present. Default controller set.
DEBUG - 2022-07-29 06:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:26:06 --> Total execution time: 0.0735
DEBUG - 2022-07-29 06:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:26:07 --> Total execution time: 0.0669
DEBUG - 2022-07-29 06:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:26:58 --> Total execution time: 0.0690
DEBUG - 2022-07-29 06:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:27:03 --> Total execution time: 0.0667
DEBUG - 2022-07-29 06:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:27:05 --> Total execution time: 0.1720
DEBUG - 2022-07-29 06:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:27:17 --> Total execution time: 0.0693
DEBUG - 2022-07-29 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:27:24 --> Total execution time: 0.0867
DEBUG - 2022-07-29 06:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:28:03 --> Total execution time: 0.0814
DEBUG - 2022-07-29 06:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:58:24 --> Total execution time: 0.0796
DEBUG - 2022-07-29 06:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:58:37 --> Total execution time: 0.0933
DEBUG - 2022-07-29 06:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:29:08 --> Total execution time: 0.0868
DEBUG - 2022-07-29 06:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:29:30 --> Total execution time: 0.0738
DEBUG - 2022-07-29 06:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 06:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:29:55 --> Total execution time: 0.0830
DEBUG - 2022-07-29 06:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 06:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 06:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:00:00 --> Total execution time: 0.0808
DEBUG - 2022-07-29 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:30:03 --> Total execution time: 0.1363
DEBUG - 2022-07-29 07:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:00:14 --> Total execution time: 0.0619
DEBUG - 2022-07-29 07:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:00:25 --> Total execution time: 0.0744
DEBUG - 2022-07-29 07:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:00:41 --> Total execution time: 0.0640
DEBUG - 2022-07-29 07:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:00:43 --> Total execution time: 0.0629
DEBUG - 2022-07-29 07:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:30:44 --> Total execution time: 0.0896
DEBUG - 2022-07-29 07:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:30:46 --> Total execution time: 0.0779
DEBUG - 2022-07-29 07:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:30:52 --> Total execution time: 0.0965
DEBUG - 2022-07-29 07:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:31:09 --> Total execution time: 0.1009
DEBUG - 2022-07-29 07:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:31:13 --> Total execution time: 0.0722
DEBUG - 2022-07-29 07:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:31:29 --> Total execution time: 0.1100
DEBUG - 2022-07-29 07:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:31:41 --> Total execution time: 0.1035
DEBUG - 2022-07-29 07:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:31:42 --> Total execution time: 0.0772
DEBUG - 2022-07-29 07:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:31:45 --> Total execution time: 0.0724
DEBUG - 2022-07-29 07:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:32:00 --> Total execution time: 0.0807
DEBUG - 2022-07-29 07:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:32:07 --> Total execution time: 0.1784
DEBUG - 2022-07-29 07:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:32:13 --> Total execution time: 0.1174
DEBUG - 2022-07-29 07:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:02:15 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:32:15 --> Total execution time: 0.0733
DEBUG - 2022-07-29 07:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:32:23 --> Total execution time: 1.9141
DEBUG - 2022-07-29 07:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:02:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 07:02:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 07:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:33:15 --> Total execution time: 0.0624
DEBUG - 2022-07-29 07:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:33:25 --> Total execution time: 0.0778
DEBUG - 2022-07-29 07:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:33:32 --> Total execution time: 0.0681
DEBUG - 2022-07-29 07:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:33:35 --> Total execution time: 0.0736
DEBUG - 2022-07-29 07:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:33:39 --> Total execution time: 0.0706
DEBUG - 2022-07-29 07:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:34:59 --> Total execution time: 0.0824
DEBUG - 2022-07-29 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:35:15 --> Total execution time: 0.0737
DEBUG - 2022-07-29 07:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:35:39 --> Total execution time: 0.1015
DEBUG - 2022-07-29 07:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:36:07 --> Total execution time: 0.0697
DEBUG - 2022-07-29 07:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:36:25 --> Total execution time: 0.0761
DEBUG - 2022-07-29 07:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:36:39 --> Total execution time: 0.0804
DEBUG - 2022-07-29 07:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:36:49 --> Total execution time: 0.0794
DEBUG - 2022-07-29 07:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:36:54 --> Total execution time: 0.1146
DEBUG - 2022-07-29 07:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:36:56 --> Total execution time: 0.0936
DEBUG - 2022-07-29 07:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:36:58 --> Total execution time: 0.0804
DEBUG - 2022-07-29 07:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:08:32 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:38:32 --> Total execution time: 0.0712
DEBUG - 2022-07-29 07:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:09:10 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:39:10 --> Total execution time: 0.0717
DEBUG - 2022-07-29 07:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:39:18 --> Total execution time: 0.0634
DEBUG - 2022-07-29 07:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:39:38 --> Total execution time: 0.0692
DEBUG - 2022-07-29 07:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:39:54 --> Total execution time: 0.1132
DEBUG - 2022-07-29 07:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:40:01 --> Total execution time: 0.1105
DEBUG - 2022-07-29 07:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:17:15 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:47:15 --> Total execution time: 0.1205
DEBUG - 2022-07-29 07:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:17:45 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:47:45 --> Total execution time: 0.0508
DEBUG - 2022-07-29 07:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:18:45 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:48:45 --> Total execution time: 0.0663
DEBUG - 2022-07-29 07:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:19:12 --> Total execution time: 0.0654
DEBUG - 2022-07-29 07:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:19:19 --> Total execution time: 0.0683
DEBUG - 2022-07-29 07:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:19:19 --> Total execution time: 0.1065
DEBUG - 2022-07-29 07:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:19:32 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:49:32 --> Total execution time: 0.0654
DEBUG - 2022-07-29 07:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:49:35 --> Total execution time: 0.0430
DEBUG - 2022-07-29 07:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:51:48 --> Total execution time: 0.1847
DEBUG - 2022-07-29 07:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:51:53 --> Total execution time: 0.0673
DEBUG - 2022-07-29 07:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:51:57 --> Total execution time: 0.0674
DEBUG - 2022-07-29 07:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:25:04 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:55:04 --> Total execution time: 0.1221
DEBUG - 2022-07-29 07:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:25:08 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:55:08 --> Total execution time: 0.0812
DEBUG - 2022-07-29 07:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:27:11 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:57:12 --> Total execution time: 0.1092
DEBUG - 2022-07-29 07:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:28:09 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:58:09 --> Total execution time: 0.0739
DEBUG - 2022-07-29 07:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:28:11 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:58:11 --> Total execution time: 0.1079
DEBUG - 2022-07-29 07:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:28:11 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:58:11 --> Total execution time: 0.0645
DEBUG - 2022-07-29 07:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:28:25 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:58:25 --> Total execution time: 0.0687
DEBUG - 2022-07-29 07:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:28:31 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:58:31 --> Total execution time: 0.1773
DEBUG - 2022-07-29 07:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:58:34 --> Total execution time: 0.0463
DEBUG - 2022-07-29 07:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:58:55 --> Total execution time: 0.0766
DEBUG - 2022-07-29 07:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:58:59 --> Total execution time: 0.0774
DEBUG - 2022-07-29 07:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:59:05 --> Total execution time: 0.0708
DEBUG - 2022-07-29 07:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:59:23 --> Total execution time: 0.0936
DEBUG - 2022-07-29 07:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:59:26 --> Total execution time: 0.0748
DEBUG - 2022-07-29 07:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:00:07 --> Total execution time: 0.0597
DEBUG - 2022-07-29 07:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:00:14 --> Total execution time: 0.0624
DEBUG - 2022-07-29 07:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:00:21 --> Total execution time: 0.0898
DEBUG - 2022-07-29 07:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:00:25 --> Total execution time: 0.0743
DEBUG - 2022-07-29 07:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:00:50 --> Total execution time: 0.1003
DEBUG - 2022-07-29 07:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:00:50 --> Total execution time: 0.0975
DEBUG - 2022-07-29 07:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:02:17 --> Total execution time: 0.1593
DEBUG - 2022-07-29 07:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:02:33 --> Total execution time: 0.0764
DEBUG - 2022-07-29 07:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:33:11 --> Total execution time: 0.0826
DEBUG - 2022-07-29 07:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:33:46 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:03:46 --> Total execution time: 0.0479
DEBUG - 2022-07-29 07:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:03:49 --> Total execution time: 0.0640
DEBUG - 2022-07-29 07:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:03:54 --> Total execution time: 0.0792
DEBUG - 2022-07-29 07:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:03:58 --> Total execution time: 0.0740
DEBUG - 2022-07-29 07:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:04:02 --> Total execution time: 0.1007
DEBUG - 2022-07-29 07:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:04:05 --> Total execution time: 0.0974
DEBUG - 2022-07-29 07:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:04:07 --> Total execution time: 0.0889
DEBUG - 2022-07-29 07:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:04:11 --> Total execution time: 0.0826
DEBUG - 2022-07-29 07:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:04:12 --> Total execution time: 0.0673
DEBUG - 2022-07-29 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:34:35 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:04:35 --> Total execution time: 0.0461
DEBUG - 2022-07-29 07:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:04:43 --> Total execution time: 0.0486
DEBUG - 2022-07-29 07:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:05:04 --> Total execution time: 0.0669
DEBUG - 2022-07-29 07:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:05:11 --> Total execution time: 0.0733
DEBUG - 2022-07-29 07:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:05:20 --> Total execution time: 0.0949
DEBUG - 2022-07-29 07:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:37:13 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:07:13 --> Total execution time: 0.0451
DEBUG - 2022-07-29 07:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:07:17 --> Total execution time: 0.0737
DEBUG - 2022-07-29 07:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:07:46 --> Total execution time: 0.1185
DEBUG - 2022-07-29 07:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:38:10 --> Total execution time: 0.0779
DEBUG - 2022-07-29 07:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:08:10 --> Total execution time: 0.0669
DEBUG - 2022-07-29 07:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:12 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:08:12 --> Total execution time: 0.1266
DEBUG - 2022-07-29 07:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:08:19 --> Total execution time: 0.0920
DEBUG - 2022-07-29 07:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:38:20 --> Total execution time: 0.1207
DEBUG - 2022-07-29 07:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:20 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:08:20 --> Total execution time: 0.2183
DEBUG - 2022-07-29 07:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:08:21 --> Total execution time: 0.0823
DEBUG - 2022-07-29 07:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:08:33 --> Total execution time: 0.0815
DEBUG - 2022-07-29 07:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:08:35 --> Total execution time: 0.0937
DEBUG - 2022-07-29 07:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:08:43 --> Total execution time: 0.0793
DEBUG - 2022-07-29 07:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:08:52 --> Total execution time: 0.1548
DEBUG - 2022-07-29 07:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:08:59 --> Total execution time: 0.1096
DEBUG - 2022-07-29 07:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:09:03 --> Total execution time: 0.1000
DEBUG - 2022-07-29 07:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:09:06 --> Total execution time: 0.0803
DEBUG - 2022-07-29 07:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:39:09 --> Total execution time: 0.0891
DEBUG - 2022-07-29 07:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:39:17 --> Total execution time: 0.0940
DEBUG - 2022-07-29 07:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:39:17 --> Total execution time: 0.1839
DEBUG - 2022-07-29 07:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:39:25 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:09:25 --> Total execution time: 0.0756
DEBUG - 2022-07-29 07:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:09:39 --> Total execution time: 0.0721
DEBUG - 2022-07-29 07:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:09:47 --> Total execution time: 0.0542
DEBUG - 2022-07-29 07:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:09:48 --> Total execution time: 0.0736
DEBUG - 2022-07-29 07:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:10:03 --> Total execution time: 0.0748
DEBUG - 2022-07-29 07:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:10:09 --> Total execution time: 0.1118
DEBUG - 2022-07-29 07:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:10:10 --> Total execution time: 0.0745
DEBUG - 2022-07-29 07:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:10:17 --> Total execution time: 0.0730
DEBUG - 2022-07-29 07:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:10:22 --> Total execution time: 0.1123
DEBUG - 2022-07-29 07:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:10:27 --> Total execution time: 0.0686
DEBUG - 2022-07-29 07:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:40:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 07:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:10:56 --> Total execution time: 2.0794
DEBUG - 2022-07-29 07:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:41:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 07:41:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 07:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:41:10 --> Total execution time: 0.0778
DEBUG - 2022-07-29 07:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:11:17 --> Total execution time: 0.1445
DEBUG - 2022-07-29 07:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:11:18 --> Total execution time: 0.0740
DEBUG - 2022-07-29 07:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:11:29 --> Total execution time: 0.1066
DEBUG - 2022-07-29 07:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:11:30 --> Total execution time: 0.1279
DEBUG - 2022-07-29 07:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:11:42 --> Total execution time: 0.0681
DEBUG - 2022-07-29 07:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:11:55 --> Total execution time: 0.0630
DEBUG - 2022-07-29 07:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:12:03 --> Total execution time: 0.1793
DEBUG - 2022-07-29 07:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:12:24 --> Total execution time: 0.0932
DEBUG - 2022-07-29 07:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:12:38 --> Total execution time: 0.1307
DEBUG - 2022-07-29 07:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:12:39 --> Total execution time: 0.0803
DEBUG - 2022-07-29 07:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:12:43 --> Total execution time: 0.0670
DEBUG - 2022-07-29 07:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:12:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 07:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:12:44 --> Total execution time: 0.0599
DEBUG - 2022-07-29 07:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:12:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 18:12:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 18:12:45 --> Total execution time: 0.2190
DEBUG - 2022-07-29 07:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:12:55 --> Total execution time: 1.6405
DEBUG - 2022-07-29 07:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:12:59 --> Total execution time: 0.0612
DEBUG - 2022-07-29 07:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:42:59 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:12:59 --> Total execution time: 0.0759
DEBUG - 2022-07-29 07:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:13:10 --> Total execution time: 0.0834
DEBUG - 2022-07-29 07:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:43:10 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:13:11 --> Total execution time: 0.0693
DEBUG - 2022-07-29 07:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:13:18 --> Total execution time: 0.0704
DEBUG - 2022-07-29 07:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:13:18 --> Total execution time: 0.0649
DEBUG - 2022-07-29 07:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:13:42 --> Total execution time: 0.0761
DEBUG - 2022-07-29 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:14:13 --> Total execution time: 0.0815
DEBUG - 2022-07-29 07:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:14:22 --> Total execution time: 0.0738
DEBUG - 2022-07-29 07:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:14:28 --> Total execution time: 0.0894
DEBUG - 2022-07-29 07:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:14:28 --> Total execution time: 0.0882
DEBUG - 2022-07-29 07:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:14:32 --> Total execution time: 0.0917
DEBUG - 2022-07-29 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:44:40 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:14:40 --> Total execution time: 0.0512
DEBUG - 2022-07-29 07:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:14:53 --> Total execution time: 0.0413
DEBUG - 2022-07-29 07:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:16:16 --> Total execution time: 0.1976
DEBUG - 2022-07-29 07:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:16:22 --> Total execution time: 0.1853
DEBUG - 2022-07-29 07:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:16:26 --> Total execution time: 0.0855
DEBUG - 2022-07-29 07:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:16:29 --> Total execution time: 0.0825
DEBUG - 2022-07-29 07:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:16:31 --> Total execution time: 0.0699
DEBUG - 2022-07-29 07:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:16:31 --> Total execution time: 0.0871
DEBUG - 2022-07-29 07:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:16:36 --> Total execution time: 0.0674
DEBUG - 2022-07-29 07:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:16:39 --> Total execution time: 0.0673
DEBUG - 2022-07-29 07:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:16:58 --> Total execution time: 0.1879
DEBUG - 2022-07-29 07:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:17:01 --> Total execution time: 0.0663
DEBUG - 2022-07-29 07:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:17:14 --> Total execution time: 0.0722
DEBUG - 2022-07-29 07:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:17:17 --> Total execution time: 0.0789
DEBUG - 2022-07-29 07:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:17:23 --> Total execution time: 0.0782
DEBUG - 2022-07-29 07:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:19:03 --> Total execution time: 0.0496
DEBUG - 2022-07-29 07:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:11 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:19:11 --> Total execution time: 0.0658
DEBUG - 2022-07-29 07:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 07:49:34 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-29 07:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:19:36 --> Total execution time: 0.0662
DEBUG - 2022-07-29 07:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:19:37 --> Total execution time: 0.0814
DEBUG - 2022-07-29 07:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 07:49:38 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-29 07:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:19:49 --> Total execution time: 0.0776
DEBUG - 2022-07-29 07:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:19:53 --> Total execution time: 0.0614
DEBUG - 2022-07-29 07:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:19:53 --> Total execution time: 0.0799
DEBUG - 2022-07-29 07:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:19:56 --> Total execution time: 0.0769
DEBUG - 2022-07-29 07:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:19:57 --> Total execution time: 0.0644
DEBUG - 2022-07-29 07:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:20:01 --> Total execution time: 0.0640
DEBUG - 2022-07-29 07:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:20:03 --> Total execution time: 0.0706
DEBUG - 2022-07-29 07:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:20:06 --> Total execution time: 0.0660
DEBUG - 2022-07-29 07:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:20:06 --> Total execution time: 0.0710
DEBUG - 2022-07-29 07:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:20:11 --> Total execution time: 0.0690
DEBUG - 2022-07-29 07:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:20:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 07:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:20:12 --> Total execution time: 0.0596
DEBUG - 2022-07-29 07:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:20:21 --> Total execution time: 0.0682
DEBUG - 2022-07-29 07:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:20:25 --> Total execution time: 0.0757
DEBUG - 2022-07-29 07:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:20:39 --> Total execution time: 0.0635
DEBUG - 2022-07-29 07:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:20:51 --> Total execution time: 0.0737
DEBUG - 2022-07-29 07:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:20:59 --> Total execution time: 0.0662
DEBUG - 2022-07-29 07:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:21:05 --> Total execution time: 0.0692
DEBUG - 2022-07-29 07:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:21:12 --> Total execution time: 0.0749
DEBUG - 2022-07-29 07:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:21:17 --> Total execution time: 0.0949
DEBUG - 2022-07-29 07:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:21:24 --> Total execution time: 0.1597
DEBUG - 2022-07-29 07:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:21:31 --> Total execution time: 0.1018
DEBUG - 2022-07-29 07:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:21:36 --> Total execution time: 0.1779
DEBUG - 2022-07-29 07:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:21:46 --> Total execution time: 0.0714
DEBUG - 2022-07-29 07:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:21:48 --> Total execution time: 0.0645
DEBUG - 2022-07-29 07:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:22:02 --> Total execution time: 0.0705
DEBUG - 2022-07-29 07:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:22:22 --> Total execution time: 0.1850
DEBUG - 2022-07-29 07:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:22:28 --> Total execution time: 0.0826
DEBUG - 2022-07-29 07:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:22:35 --> Total execution time: 0.0681
DEBUG - 2022-07-29 07:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:23:11 --> Total execution time: 0.0691
DEBUG - 2022-07-29 07:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:23:13 --> Total execution time: 0.0617
DEBUG - 2022-07-29 07:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:23:14 --> Total execution time: 0.0885
DEBUG - 2022-07-29 07:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:23:15 --> Total execution time: 0.0635
DEBUG - 2022-07-29 07:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:23:15 --> Total execution time: 0.0594
DEBUG - 2022-07-29 07:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:23:16 --> Total execution time: 0.0614
DEBUG - 2022-07-29 07:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:23:16 --> Total execution time: 0.0688
DEBUG - 2022-07-29 07:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:23:21 --> Total execution time: 0.0652
DEBUG - 2022-07-29 07:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:23:24 --> Total execution time: 0.0782
DEBUG - 2022-07-29 07:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:28 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:23:28 --> Total execution time: 0.0750
DEBUG - 2022-07-29 07:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:53:33 --> Total execution time: 0.0587
DEBUG - 2022-07-29 07:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:53:35 --> Total execution time: 0.0709
DEBUG - 2022-07-29 07:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:53:35 --> Total execution time: 0.1560
DEBUG - 2022-07-29 07:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:23:41 --> Total execution time: 0.0666
DEBUG - 2022-07-29 07:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:42 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:23:43 --> Total execution time: 0.0923
DEBUG - 2022-07-29 07:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:23:49 --> Total execution time: 0.0648
DEBUG - 2022-07-29 07:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:24:00 --> Total execution time: 0.0663
DEBUG - 2022-07-29 07:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:24:09 --> Total execution time: 0.0921
DEBUG - 2022-07-29 07:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:24:22 --> Total execution time: 0.0747
DEBUG - 2022-07-29 07:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:24:23 --> Total execution time: 0.0753
DEBUG - 2022-07-29 07:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:24:24 --> Total execution time: 0.0924
DEBUG - 2022-07-29 07:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:24:25 --> Total execution time: 0.0843
DEBUG - 2022-07-29 07:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:24:26 --> Total execution time: 0.0684
DEBUG - 2022-07-29 07:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:24:26 --> Total execution time: 0.0926
DEBUG - 2022-07-29 07:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:24:37 --> Total execution time: 0.0681
DEBUG - 2022-07-29 07:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:24:38 --> Total execution time: 0.0896
DEBUG - 2022-07-29 07:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:54:54 --> Total execution time: 0.0667
DEBUG - 2022-07-29 07:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:55 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:24:55 --> Total execution time: 0.0533
DEBUG - 2022-07-29 07:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:24:59 --> Total execution time: 0.0651
DEBUG - 2022-07-29 07:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:24:59 --> Total execution time: 0.0431
DEBUG - 2022-07-29 07:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:25:06 --> Total execution time: 0.1183
DEBUG - 2022-07-29 07:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:25:07 --> Total execution time: 0.1241
DEBUG - 2022-07-29 07:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:25:08 --> Total execution time: 0.0825
DEBUG - 2022-07-29 07:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:25:19 --> Total execution time: 0.1084
DEBUG - 2022-07-29 07:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:25:29 --> Total execution time: 0.1064
DEBUG - 2022-07-29 07:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:25:29 --> Total execution time: 0.0996
DEBUG - 2022-07-29 07:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:25:31 --> Total execution time: 0.1034
DEBUG - 2022-07-29 07:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:25:31 --> Total execution time: 0.2097
DEBUG - 2022-07-29 07:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:25:31 --> Total execution time: 0.3206
DEBUG - 2022-07-29 07:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:25:32 --> Total execution time: 0.0976
DEBUG - 2022-07-29 07:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:25:51 --> Total execution time: 0.1190
DEBUG - 2022-07-29 07:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:25:57 --> Total execution time: 0.0724
DEBUG - 2022-07-29 07:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:25:58 --> Total execution time: 0.0652
DEBUG - 2022-07-29 07:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:26:03 --> Total execution time: 0.0849
DEBUG - 2022-07-29 07:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:26:11 --> Total execution time: 0.0920
DEBUG - 2022-07-29 07:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:26:13 --> Total execution time: 0.1067
DEBUG - 2022-07-29 07:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:26:18 --> Total execution time: 0.0715
DEBUG - 2022-07-29 07:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:26:19 --> Total execution time: 0.0894
DEBUG - 2022-07-29 07:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:26:25 --> Total execution time: 0.0849
DEBUG - 2022-07-29 07:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:26:26 --> Total execution time: 0.1690
DEBUG - 2022-07-29 07:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:26:26 --> Total execution time: 0.0801
DEBUG - 2022-07-29 07:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:26:28 --> Total execution time: 0.0644
DEBUG - 2022-07-29 07:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:26:34 --> Total execution time: 0.0681
DEBUG - 2022-07-29 07:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:56:36 --> Total execution time: 0.0715
DEBUG - 2022-07-29 07:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:26:37 --> Total execution time: 0.0702
DEBUG - 2022-07-29 07:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:41 --> No URI present. Default controller set.
DEBUG - 2022-07-29 07:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:26:41 --> Total execution time: 0.0734
DEBUG - 2022-07-29 07:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:26:42 --> Total execution time: 0.0658
DEBUG - 2022-07-29 07:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:26:47 --> Total execution time: 0.0763
DEBUG - 2022-07-29 07:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:27:22 --> Total execution time: 0.2149
DEBUG - 2022-07-29 07:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:27:28 --> Total execution time: 0.0897
DEBUG - 2022-07-29 07:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:27:28 --> Total execution time: 0.0663
DEBUG - 2022-07-29 07:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 07:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:27:33 --> Total execution time: 0.0710
DEBUG - 2022-07-29 07:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:27:40 --> Total execution time: 0.0660
DEBUG - 2022-07-29 07:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 07:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 07:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:27:50 --> Total execution time: 0.1891
DEBUG - 2022-07-29 08:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:30:24 --> Total execution time: 0.3509
DEBUG - 2022-07-29 08:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:30:42 --> Total execution time: 0.0821
DEBUG - 2022-07-29 08:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:30:51 --> Total execution time: 0.0688
DEBUG - 2022-07-29 08:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:31:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 08:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:31:40 --> Total execution time: 0.0884
DEBUG - 2022-07-29 08:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:31:54 --> Total execution time: 0.0724
DEBUG - 2022-07-29 08:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:32:12 --> Total execution time: 0.0897
DEBUG - 2022-07-29 08:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:32:21 --> Total execution time: 0.0867
DEBUG - 2022-07-29 08:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:32:22 --> Total execution time: 0.0814
DEBUG - 2022-07-29 08:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:32:24 --> Total execution time: 0.0857
DEBUG - 2022-07-29 08:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:32:26 --> Total execution time: 0.0823
DEBUG - 2022-07-29 08:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:32:33 --> Total execution time: 0.0989
DEBUG - 2022-07-29 08:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:32:48 --> Total execution time: 0.0820
DEBUG - 2022-07-29 08:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:32:49 --> Total execution time: 0.0965
DEBUG - 2022-07-29 08:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:32:54 --> Total execution time: 0.0807
DEBUG - 2022-07-29 08:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:33:01 --> Total execution time: 0.0713
DEBUG - 2022-07-29 08:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:33:03 --> Total execution time: 0.0690
DEBUG - 2022-07-29 08:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:33:41 --> Total execution time: 0.1133
DEBUG - 2022-07-29 08:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:33:55 --> Total execution time: 0.0665
DEBUG - 2022-07-29 08:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:07:37 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:37:37 --> Total execution time: 0.1366
DEBUG - 2022-07-29 08:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:08:05 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:38:05 --> Total execution time: 0.0440
DEBUG - 2022-07-29 08:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:08:16 --> Total execution time: 0.0721
DEBUG - 2022-07-29 08:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:08:18 --> Total execution time: 0.0859
DEBUG - 2022-07-29 08:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:08:18 --> Total execution time: 0.1336
DEBUG - 2022-07-29 08:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:38:19 --> Total execution time: 0.0768
DEBUG - 2022-07-29 08:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:08:25 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:38:25 --> Total execution time: 0.0745
DEBUG - 2022-07-29 08:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:38:59 --> Total execution time: 0.0682
DEBUG - 2022-07-29 08:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:39:23 --> Total execution time: 0.1701
DEBUG - 2022-07-29 08:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:39:27 --> Total execution time: 0.0766
DEBUG - 2022-07-29 08:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:39:32 --> Total execution time: 0.0717
DEBUG - 2022-07-29 08:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:39:32 --> Total execution time: 0.0620
DEBUG - 2022-07-29 08:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:12:23 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:42:23 --> Total execution time: 0.1282
DEBUG - 2022-07-29 08:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:12:58 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:42:58 --> Total execution time: 0.0648
DEBUG - 2022-07-29 08:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:43:49 --> Total execution time: 0.0758
DEBUG - 2022-07-29 08:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:15:08 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:45:08 --> Total execution time: 0.0443
DEBUG - 2022-07-29 08:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:15:14 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:45:14 --> Total execution time: 0.0576
DEBUG - 2022-07-29 08:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:15:58 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:45:58 --> Total execution time: 0.0461
DEBUG - 2022-07-29 08:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:15:58 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:45:58 --> Total execution time: 0.0414
DEBUG - 2022-07-29 08:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:16:51 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:46:51 --> Total execution time: 0.0437
DEBUG - 2022-07-29 08:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:17:32 --> Total execution time: 0.0594
DEBUG - 2022-07-29 08:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:17:33 --> Total execution time: 0.0832
DEBUG - 2022-07-29 08:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:17:34 --> Total execution time: 0.0610
DEBUG - 2022-07-29 08:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:18:16 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:48:17 --> Total execution time: 0.0778
DEBUG - 2022-07-29 08:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:48:28 --> Total execution time: 0.0602
DEBUG - 2022-07-29 08:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:48:30 --> Total execution time: 0.0695
DEBUG - 2022-07-29 08:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:49:13 --> Total execution time: 0.0696
DEBUG - 2022-07-29 08:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:50:01 --> Total execution time: 0.1153
DEBUG - 2022-07-29 08:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:50:41 --> Total execution time: 0.0748
DEBUG - 2022-07-29 08:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:22:33 --> Total execution time: 0.0888
DEBUG - 2022-07-29 08:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:22:44 --> Total execution time: 0.1173
DEBUG - 2022-07-29 08:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:54:13 --> Total execution time: 0.0845
DEBUG - 2022-07-29 08:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:56:05 --> Total execution time: 0.0857
DEBUG - 2022-07-29 08:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:56:18 --> Total execution time: 0.0863
DEBUG - 2022-07-29 08:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:26:25 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:56:25 --> Total execution time: 0.0533
DEBUG - 2022-07-29 08:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:57:08 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 08:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:57:09 --> Total execution time: 0.1275
DEBUG - 2022-07-29 08:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:57:21 --> Total execution time: 0.0664
DEBUG - 2022-07-29 08:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:58:39 --> Total execution time: 0.0797
DEBUG - 2022-07-29 08:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:58:50 --> Total execution time: 0.1064
DEBUG - 2022-07-29 08:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:59:03 --> Total execution time: 0.1732
DEBUG - 2022-07-29 08:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:59:05 --> Total execution time: 0.0720
DEBUG - 2022-07-29 08:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:59:09 --> Total execution time: 0.0827
DEBUG - 2022-07-29 08:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:59:09 --> Total execution time: 0.0930
DEBUG - 2022-07-29 08:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:59:17 --> Total execution time: 0.0842
DEBUG - 2022-07-29 08:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:30:28 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:00:28 --> Total execution time: 0.0606
DEBUG - 2022-07-29 08:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:00:39 --> Total execution time: 0.0704
DEBUG - 2022-07-29 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:00:58 --> Total execution time: 0.0735
DEBUG - 2022-07-29 08:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:01:02 --> Total execution time: 0.1323
DEBUG - 2022-07-29 08:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:01:05 --> Total execution time: 0.1905
DEBUG - 2022-07-29 08:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:01:08 --> Total execution time: 0.0933
DEBUG - 2022-07-29 08:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:01:11 --> Total execution time: 0.1001
DEBUG - 2022-07-29 08:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:01:13 --> Total execution time: 0.0683
DEBUG - 2022-07-29 08:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:31:16 --> Total execution time: 0.0790
DEBUG - 2022-07-29 08:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:01:16 --> Total execution time: 0.0794
DEBUG - 2022-07-29 08:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:31:19 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:01:19 --> Total execution time: 0.1709
DEBUG - 2022-07-29 08:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:31:41 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:01:41 --> Total execution time: 0.0679
DEBUG - 2022-07-29 08:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:31:45 --> Total execution time: 0.0833
DEBUG - 2022-07-29 08:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:01:46 --> Total execution time: 0.0751
DEBUG - 2022-07-29 08:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:31:58 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:01:58 --> Total execution time: 0.0775
DEBUG - 2022-07-29 08:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:02:20 --> Total execution time: 0.0967
DEBUG - 2022-07-29 08:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:02:35 --> Total execution time: 0.0936
DEBUG - 2022-07-29 08:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:02:40 --> Total execution time: 0.1057
DEBUG - 2022-07-29 08:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:02:58 --> Total execution time: 0.0911
DEBUG - 2022-07-29 08:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:03:03 --> Total execution time: 0.0692
DEBUG - 2022-07-29 08:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:03:10 --> Total execution time: 0.0746
DEBUG - 2022-07-29 08:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:03:56 --> Total execution time: 0.0688
DEBUG - 2022-07-29 08:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:34:25 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:04:25 --> Total execution time: 0.0794
DEBUG - 2022-07-29 08:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:04:35 --> Total execution time: 0.0749
DEBUG - 2022-07-29 08:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:04:46 --> Total execution time: 0.0849
DEBUG - 2022-07-29 08:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:35:47 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:05:47 --> Total execution time: 0.0608
DEBUG - 2022-07-29 08:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:07:39 --> Total execution time: 0.0641
DEBUG - 2022-07-29 08:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:08:57 --> Total execution time: 0.1969
DEBUG - 2022-07-29 08:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:09:31 --> Total execution time: 0.0817
DEBUG - 2022-07-29 08:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:39:34 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:09:34 --> Total execution time: 0.0451
DEBUG - 2022-07-29 08:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:39:35 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:09:35 --> Total execution time: 0.0489
DEBUG - 2022-07-29 08:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:39:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 08:39:35 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-29 08:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:39:36 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:09:36 --> Total execution time: 0.0492
DEBUG - 2022-07-29 08:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:09:37 --> Total execution time: 0.0931
DEBUG - 2022-07-29 08:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:10:25 --> Total execution time: 0.1920
DEBUG - 2022-07-29 08:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:10:49 --> Total execution time: 0.0862
DEBUG - 2022-07-29 08:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:44:41 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:14:41 --> Total execution time: 0.1297
DEBUG - 2022-07-29 08:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:45:06 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:15:06 --> Total execution time: 0.0530
DEBUG - 2022-07-29 08:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:15:08 --> Total execution time: 0.0766
DEBUG - 2022-07-29 08:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:15:09 --> Total execution time: 0.0674
DEBUG - 2022-07-29 08:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:15:24 --> Total execution time: 0.1796
DEBUG - 2022-07-29 08:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:15:34 --> Total execution time: 0.0728
DEBUG - 2022-07-29 08:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:15:38 --> Total execution time: 0.0978
DEBUG - 2022-07-29 08:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:18:00 --> Total execution time: 0.0976
DEBUG - 2022-07-29 08:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:48:05 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:18:05 --> Total execution time: 0.0712
DEBUG - 2022-07-29 08:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:18:06 --> Total execution time: 0.0682
DEBUG - 2022-07-29 08:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:18:09 --> Total execution time: 0.0953
DEBUG - 2022-07-29 08:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:18:14 --> Total execution time: 0.0761
DEBUG - 2022-07-29 08:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:19:06 --> Total execution time: 0.0690
DEBUG - 2022-07-29 08:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:19:08 --> Total execution time: 0.0658
DEBUG - 2022-07-29 08:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:10 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:19:10 --> Total execution time: 0.0731
DEBUG - 2022-07-29 08:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:19:42 --> Total execution time: 0.0651
DEBUG - 2022-07-29 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:49:46 --> Total execution time: 0.1706
DEBUG - 2022-07-29 08:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:19:47 --> Total execution time: 0.1058
DEBUG - 2022-07-29 08:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:49:48 --> Total execution time: 0.0687
DEBUG - 2022-07-29 08:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:49:48 --> Total execution time: 0.1394
DEBUG - 2022-07-29 08:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:51 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:19:51 --> Total execution time: 0.0648
DEBUG - 2022-07-29 08:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:19:55 --> Total execution time: 0.0992
DEBUG - 2022-07-29 08:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:49:57 --> Total execution time: 0.0684
DEBUG - 2022-07-29 08:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:49:58 --> Total execution time: 0.0681
DEBUG - 2022-07-29 08:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:49:58 --> Total execution time: 0.1372
DEBUG - 2022-07-29 08:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:50:01 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:20:01 --> Total execution time: 0.0785
DEBUG - 2022-07-29 08:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:50:30 --> Total execution time: 0.0699
DEBUG - 2022-07-29 08:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:50:32 --> Total execution time: 0.0900
DEBUG - 2022-07-29 08:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:50:32 --> Total execution time: 0.1358
DEBUG - 2022-07-29 08:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:20:46 --> Total execution time: 0.2201
DEBUG - 2022-07-29 08:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:50:49 --> Total execution time: 0.0661
DEBUG - 2022-07-29 08:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:20:51 --> Total execution time: 0.1038
DEBUG - 2022-07-29 08:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:50:58 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:20:58 --> Total execution time: 0.0453
DEBUG - 2022-07-29 08:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:21:00 --> Total execution time: 0.0846
DEBUG - 2022-07-29 08:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:21:06 --> Total execution time: 0.0936
DEBUG - 2022-07-29 08:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:21:08 --> Total execution time: 0.0528
DEBUG - 2022-07-29 08:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:21:11 --> Total execution time: 0.0734
DEBUG - 2022-07-29 08:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:21:22 --> Total execution time: 0.0737
DEBUG - 2022-07-29 08:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:51:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 08:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:21:26 --> Total execution time: 0.0846
DEBUG - 2022-07-29 19:21:26 --> Total execution time: 1.9543
DEBUG - 2022-07-29 08:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 08:51:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 08:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:21:33 --> Total execution time: 0.1173
DEBUG - 2022-07-29 08:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:21:42 --> Total execution time: 0.0798
DEBUG - 2022-07-29 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:21:50 --> Total execution time: 0.1374
DEBUG - 2022-07-29 08:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:21:53 --> Total execution time: 0.0984
DEBUG - 2022-07-29 08:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:21:55 --> Total execution time: 0.1281
DEBUG - 2022-07-29 08:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:21:56 --> Total execution time: 0.0880
DEBUG - 2022-07-29 08:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:22:04 --> Total execution time: 0.0898
DEBUG - 2022-07-29 08:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:22:11 --> Total execution time: 0.0925
DEBUG - 2022-07-29 08:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:22:17 --> Total execution time: 0.0677
DEBUG - 2022-07-29 08:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:22:21 --> Total execution time: 0.0672
DEBUG - 2022-07-29 08:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:22:24 --> Total execution time: 0.0959
DEBUG - 2022-07-29 08:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:22:26 --> Total execution time: 0.0644
DEBUG - 2022-07-29 08:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:52:30 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:22:30 --> Total execution time: 0.1842
DEBUG - 2022-07-29 08:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:53:47 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:23:47 --> Total execution time: 0.0499
DEBUG - 2022-07-29 08:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:24:51 --> Total execution time: 0.1045
DEBUG - 2022-07-29 08:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:24:54 --> Total execution time: 0.0812
DEBUG - 2022-07-29 08:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:24:56 --> Total execution time: 0.2085
DEBUG - 2022-07-29 08:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:25:02 --> Total execution time: 0.0707
DEBUG - 2022-07-29 08:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:25:04 --> Total execution time: 0.0676
DEBUG - 2022-07-29 08:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:25:15 --> Total execution time: 0.1250
DEBUG - 2022-07-29 08:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:25:28 --> Total execution time: 0.0808
DEBUG - 2022-07-29 08:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:25:32 --> Total execution time: 0.0720
DEBUG - 2022-07-29 08:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:25:35 --> Total execution time: 0.0890
DEBUG - 2022-07-29 08:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:25:39 --> Total execution time: 0.0869
DEBUG - 2022-07-29 08:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:25:46 --> Total execution time: 0.0781
DEBUG - 2022-07-29 08:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:25:54 --> Total execution time: 0.0720
DEBUG - 2022-07-29 08:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:26:07 --> Total execution time: 0.1007
DEBUG - 2022-07-29 08:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 08:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:26:28 --> Total execution time: 0.0935
DEBUG - 2022-07-29 08:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:26:31 --> Total execution time: 0.0829
DEBUG - 2022-07-29 08:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:26:36 --> Total execution time: 0.0977
DEBUG - 2022-07-29 08:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:26:44 --> Total execution time: 0.0774
DEBUG - 2022-07-29 08:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:27:57 --> Total execution time: 0.0710
DEBUG - 2022-07-29 08:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 08:58:13 --> No URI present. Default controller set.
DEBUG - 2022-07-29 08:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 08:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:28:13 --> Total execution time: 0.1163
DEBUG - 2022-07-29 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:30:02 --> Total execution time: 0.0841
DEBUG - 2022-07-29 09:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:30:15 --> Total execution time: 0.1188
DEBUG - 2022-07-29 09:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:30:29 --> Total execution time: 0.0958
DEBUG - 2022-07-29 09:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:30:32 --> Total execution time: 0.0785
DEBUG - 2022-07-29 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:30:39 --> Total execution time: 0.0746
DEBUG - 2022-07-29 09:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:00:48 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:30:48 --> Total execution time: 0.0461
DEBUG - 2022-07-29 09:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:00:48 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:30:48 --> Total execution time: 0.0572
DEBUG - 2022-07-29 09:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:30:53 --> Total execution time: 0.0414
DEBUG - 2022-07-29 09:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:30:56 --> Total execution time: 0.0671
DEBUG - 2022-07-29 09:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:01:03 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:31:03 --> Total execution time: 0.1868
DEBUG - 2022-07-29 09:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:31:03 --> Total execution time: 0.0700
DEBUG - 2022-07-29 09:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:31:10 --> Total execution time: 1.5743
DEBUG - 2022-07-29 09:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:31:30 --> Total execution time: 0.1814
DEBUG - 2022-07-29 09:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 09:01:31 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 09:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:32:29 --> Total execution time: 0.2103
DEBUG - 2022-07-29 09:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:35:37 --> Total execution time: 0.1635
DEBUG - 2022-07-29 09:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:08:03 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:38:04 --> Total execution time: 0.2569
DEBUG - 2022-07-29 09:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:38:12 --> Total execution time: 0.0695
DEBUG - 2022-07-29 09:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:38:23 --> Total execution time: 0.0675
DEBUG - 2022-07-29 09:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:38:28 --> Total execution time: 0.0768
DEBUG - 2022-07-29 09:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:38:32 --> Total execution time: 0.0739
DEBUG - 2022-07-29 09:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:38:40 --> Total execution time: 0.0638
DEBUG - 2022-07-29 09:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:40:46 --> Total execution time: 0.1453
DEBUG - 2022-07-29 09:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:19:54 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:49:55 --> Total execution time: 0.1189
DEBUG - 2022-07-29 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:49:58 --> Total execution time: 0.0654
DEBUG - 2022-07-29 09:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:50:18 --> Total execution time: 0.1067
DEBUG - 2022-07-29 09:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:50:46 --> Total execution time: 0.0830
DEBUG - 2022-07-29 09:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:51:01 --> Total execution time: 0.0702
DEBUG - 2022-07-29 09:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:52:04 --> Total execution time: 0.0786
DEBUG - 2022-07-29 09:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:52:34 --> Total execution time: 0.0884
DEBUG - 2022-07-29 09:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:52:40 --> Total execution time: 0.0870
DEBUG - 2022-07-29 09:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:25:12 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:55:12 --> Total execution time: 0.2457
DEBUG - 2022-07-29 09:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:25:16 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:55:16 --> Total execution time: 0.0449
DEBUG - 2022-07-29 09:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:01:00 --> Total execution time: 0.1151
DEBUG - 2022-07-29 09:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:31:35 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:01:35 --> Total execution time: 0.0574
DEBUG - 2022-07-29 09:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:31:42 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:01:42 --> Total execution time: 0.0658
DEBUG - 2022-07-29 09:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:01:46 --> Total execution time: 0.0648
DEBUG - 2022-07-29 09:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:32:04 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:02:04 --> Total execution time: 0.0720
DEBUG - 2022-07-29 09:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:32:12 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:02:12 --> Total execution time: 0.0489
DEBUG - 2022-07-29 09:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:34:49 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:04:49 --> Total execution time: 0.1105
DEBUG - 2022-07-29 09:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:35:53 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:05:53 --> Total execution time: 0.0639
DEBUG - 2022-07-29 09:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:36:30 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:06:30 --> Total execution time: 0.0450
DEBUG - 2022-07-29 09:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:37:01 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:07:01 --> Total execution time: 0.0774
DEBUG - 2022-07-29 09:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:38:08 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:08:08 --> Total execution time: 0.0459
DEBUG - 2022-07-29 09:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:08:17 --> Total execution time: 0.0404
DEBUG - 2022-07-29 09:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:08:25 --> Total execution time: 0.0710
DEBUG - 2022-07-29 09:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:08:28 --> Total execution time: 0.0795
DEBUG - 2022-07-29 09:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:08:31 --> Total execution time: 0.0798
DEBUG - 2022-07-29 09:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:08:39 --> Total execution time: 0.0601
DEBUG - 2022-07-29 09:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:39:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 09:39:09 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-29 09:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:41:08 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:11:08 --> Total execution time: 0.0510
DEBUG - 2022-07-29 09:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:41:09 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:11:09 --> Total execution time: 0.0657
DEBUG - 2022-07-29 09:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:11:21 --> Total execution time: 0.0459
DEBUG - 2022-07-29 09:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:12:03 --> Total execution time: 0.0848
DEBUG - 2022-07-29 09:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:12:07 --> Total execution time: 0.0702
DEBUG - 2022-07-29 09:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:42:16 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:12:16 --> Total execution time: 0.1667
DEBUG - 2022-07-29 09:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:43:06 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:13:06 --> Total execution time: 0.1662
DEBUG - 2022-07-29 09:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:13:12 --> Total execution time: 0.0672
DEBUG - 2022-07-29 09:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:13:18 --> Total execution time: 0.1700
DEBUG - 2022-07-29 09:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:43:21 --> Total execution time: 0.0979
DEBUG - 2022-07-29 09:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:13:28 --> Total execution time: 0.0738
DEBUG - 2022-07-29 09:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:13:35 --> Total execution time: 0.0655
DEBUG - 2022-07-29 09:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:14:09 --> Total execution time: 0.0701
DEBUG - 2022-07-29 09:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:44:46 --> Total execution time: 0.0700
DEBUG - 2022-07-29 09:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:44:46 --> Total execution time: 0.1702
DEBUG - 2022-07-29 09:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:45:56 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:15:56 --> Total execution time: 0.0665
DEBUG - 2022-07-29 09:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:46:43 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:16:43 --> Total execution time: 0.0705
DEBUG - 2022-07-29 09:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:46:55 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:16:55 --> Total execution time: 0.0556
DEBUG - 2022-07-29 09:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:47:08 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:17:08 --> Total execution time: 0.1754
DEBUG - 2022-07-29 09:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:48:59 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:18:59 --> Total execution time: 0.0476
DEBUG - 2022-07-29 09:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:51:22 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:21:22 --> Total execution time: 0.1436
DEBUG - 2022-07-29 09:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:51:29 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:21:29 --> Total execution time: 0.0476
DEBUG - 2022-07-29 09:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:21:31 --> Total execution time: 0.0824
DEBUG - 2022-07-29 09:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:53:19 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:23:19 --> Total execution time: 0.0506
DEBUG - 2022-07-29 09:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:23:59 --> Total execution time: 0.0677
DEBUG - 2022-07-29 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:24:19 --> Total execution time: 0.0752
DEBUG - 2022-07-29 09:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:54:39 --> No URI present. Default controller set.
DEBUG - 2022-07-29 09:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:24:39 --> Total execution time: 0.0710
DEBUG - 2022-07-29 09:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:24:43 --> Total execution time: 0.0476
DEBUG - 2022-07-29 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:24:59 --> Total execution time: 0.0651
DEBUG - 2022-07-29 09:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:25:03 --> Total execution time: 0.0841
DEBUG - 2022-07-29 09:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:25:05 --> Total execution time: 0.0690
DEBUG - 2022-07-29 09:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:25:17 --> Total execution time: 0.0738
DEBUG - 2022-07-29 09:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:25:20 --> Total execution time: 0.0786
DEBUG - 2022-07-29 09:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:25:26 --> Total execution time: 0.0887
DEBUG - 2022-07-29 09:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:25:28 --> Total execution time: 0.0683
DEBUG - 2022-07-29 09:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:25:28 --> Total execution time: 0.0775
DEBUG - 2022-07-29 09:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:25:33 --> Total execution time: 0.0740
DEBUG - 2022-07-29 09:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:25:41 --> Total execution time: 0.0714
DEBUG - 2022-07-29 09:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:26:07 --> Total execution time: 0.0627
DEBUG - 2022-07-29 09:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:26:21 --> Total execution time: 0.0856
DEBUG - 2022-07-29 09:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:27:56 --> Total execution time: 0.0749
DEBUG - 2022-07-29 09:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 09:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 09:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 09:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:29:09 --> Total execution time: 0.0737
DEBUG - 2022-07-29 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:30:02 --> Total execution time: 0.1165
DEBUG - 2022-07-29 10:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:32:50 --> Total execution time: 0.2507
DEBUG - 2022-07-29 10:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:03:00 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:33:00 --> Total execution time: 0.0517
DEBUG - 2022-07-29 10:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:03:11 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:33:11 --> Total execution time: 0.1310
DEBUG - 2022-07-29 10:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:03:11 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:33:11 --> Total execution time: 0.0725
DEBUG - 2022-07-29 10:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:33:43 --> Total execution time: 0.0427
DEBUG - 2022-07-29 10:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:34:13 --> Total execution time: 0.0727
DEBUG - 2022-07-29 10:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:34:35 --> Total execution time: 0.0710
DEBUG - 2022-07-29 10:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:34:47 --> Total execution time: 0.0712
DEBUG - 2022-07-29 10:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:34:52 --> Total execution time: 0.0739
DEBUG - 2022-07-29 10:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:34:55 --> Total execution time: 0.0807
DEBUG - 2022-07-29 10:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:35:02 --> Total execution time: 0.0781
DEBUG - 2022-07-29 10:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:36:18 --> Total execution time: 0.0645
DEBUG - 2022-07-29 10:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:37:10 --> Total execution time: 0.1709
DEBUG - 2022-07-29 10:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:37:13 --> Total execution time: 0.1035
DEBUG - 2022-07-29 10:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:37:16 --> Total execution time: 0.0716
DEBUG - 2022-07-29 10:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:07:29 --> Total execution time: 0.0828
DEBUG - 2022-07-29 10:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:07:31 --> Total execution time: 0.0713
DEBUG - 2022-07-29 10:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:07:31 --> Total execution time: 0.0892
DEBUG - 2022-07-29 10:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:07:45 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:37:45 --> Total execution time: 0.0693
DEBUG - 2022-07-29 10:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:07:46 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:37:46 --> Total execution time: 0.0446
DEBUG - 2022-07-29 10:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:07:48 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:37:48 --> Total execution time: 0.1661
DEBUG - 2022-07-29 10:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:37:55 --> Total execution time: 0.0716
DEBUG - 2022-07-29 10:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:38:02 --> Total execution time: 0.0702
DEBUG - 2022-07-29 10:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:38:06 --> Total execution time: 0.0978
DEBUG - 2022-07-29 10:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:38:21 --> Total execution time: 0.0860
DEBUG - 2022-07-29 10:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:23 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:38:23 --> Total execution time: 0.0552
DEBUG - 2022-07-29 10:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:38:24 --> Total execution time: 0.0720
DEBUG - 2022-07-29 10:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:38:27 --> Total execution time: 0.0862
DEBUG - 2022-07-29 10:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:38:29 --> Total execution time: 0.0690
DEBUG - 2022-07-29 10:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:38:34 --> Total execution time: 0.0649
DEBUG - 2022-07-29 10:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:38:35 --> Total execution time: 0.0684
DEBUG - 2022-07-29 10:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:38:39 --> Total execution time: 0.0697
DEBUG - 2022-07-29 10:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:38:51 --> Total execution time: 0.0646
DEBUG - 2022-07-29 10:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:53 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:38:53 --> Total execution time: 0.0484
DEBUG - 2022-07-29 10:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:38:54 --> Total execution time: 0.0728
DEBUG - 2022-07-29 10:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:39:02 --> Total execution time: 0.0671
DEBUG - 2022-07-29 10:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:39:15 --> Total execution time: 0.0643
DEBUG - 2022-07-29 10:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:09:24 --> Total execution time: 0.0659
DEBUG - 2022-07-29 10:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:39:29 --> Total execution time: 0.0734
DEBUG - 2022-07-29 10:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:39:50 --> Total execution time: 0.1236
DEBUG - 2022-07-29 10:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:39:51 --> Total execution time: 0.2129
DEBUG - 2022-07-29 10:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:39:53 --> Total execution time: 0.0907
DEBUG - 2022-07-29 10:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:40:03 --> Total execution time: 0.1271
DEBUG - 2022-07-29 10:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:40:11 --> Total execution time: 0.1062
DEBUG - 2022-07-29 10:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:40:13 --> Total execution time: 0.1503
DEBUG - 2022-07-29 10:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:40:16 --> Total execution time: 0.1354
DEBUG - 2022-07-29 10:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:40:17 --> Total execution time: 0.0933
DEBUG - 2022-07-29 10:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:40:17 --> Total execution time: 0.1069
DEBUG - 2022-07-29 10:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:40:17 --> Total execution time: 0.1172
DEBUG - 2022-07-29 10:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:40:18 --> Total execution time: 0.1146
DEBUG - 2022-07-29 10:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:40:25 --> Total execution time: 0.0993
DEBUG - 2022-07-29 10:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:40:56 --> Total execution time: 0.0673
DEBUG - 2022-07-29 10:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:41:04 --> Total execution time: 0.0700
DEBUG - 2022-07-29 10:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:41:17 --> Total execution time: 0.0866
DEBUG - 2022-07-29 10:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:41:28 --> Total execution time: 0.0738
DEBUG - 2022-07-29 10:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:11:52 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:41:52 --> Total execution time: 0.1523
DEBUG - 2022-07-29 10:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:11:53 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:41:53 --> Total execution time: 0.1474
DEBUG - 2022-07-29 10:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:12:26 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:42:26 --> Total execution time: 0.0597
DEBUG - 2022-07-29 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:44:33 --> Total execution time: 0.0682
DEBUG - 2022-07-29 10:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:18:34 --> Total execution time: 0.0692
DEBUG - 2022-07-29 10:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:58:01 --> Total execution time: 0.0728
DEBUG - 2022-07-29 10:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:58:39 --> Total execution time: 0.0663
DEBUG - 2022-07-29 10:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:59:32 --> Total execution time: 0.0843
DEBUG - 2022-07-29 10:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:59:38 --> Total execution time: 0.0745
DEBUG - 2022-07-29 10:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:00:06 --> Total execution time: 0.1975
DEBUG - 2022-07-29 10:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:00:11 --> Total execution time: 0.0981
DEBUG - 2022-07-29 10:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:00:22 --> Total execution time: 0.0625
DEBUG - 2022-07-29 10:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:00:25 --> Total execution time: 0.0707
DEBUG - 2022-07-29 10:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:00:43 --> Total execution time: 0.0680
DEBUG - 2022-07-29 10:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:00:59 --> Total execution time: 0.0639
DEBUG - 2022-07-29 10:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:33:03 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:03:04 --> Total execution time: 0.2111
DEBUG - 2022-07-29 10:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:03:07 --> Total execution time: 0.0793
DEBUG - 2022-07-29 10:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:03:10 --> Total execution time: 0.0777
DEBUG - 2022-07-29 10:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:03:19 --> Total execution time: 0.0714
DEBUG - 2022-07-29 10:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:03:23 --> Total execution time: 0.0747
DEBUG - 2022-07-29 10:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:33:30 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:03:31 --> Total execution time: 0.2514
DEBUG - 2022-07-29 10:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:05:41 --> Total execution time: 0.1426
DEBUG - 2022-07-29 10:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:36:36 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:06:36 --> Total execution time: 0.0491
DEBUG - 2022-07-29 10:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:36:38 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:06:38 --> Total execution time: 0.0666
DEBUG - 2022-07-29 10:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:06:41 --> Total execution time: 0.0715
DEBUG - 2022-07-29 10:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:06:43 --> Total execution time: 0.0908
DEBUG - 2022-07-29 10:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:06:51 --> Total execution time: 0.0829
DEBUG - 2022-07-29 10:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:06:55 --> Total execution time: 0.0684
DEBUG - 2022-07-29 10:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:08:09 --> Total execution time: 0.0685
DEBUG - 2022-07-29 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:38:21 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:08:21 --> Total execution time: 0.0838
DEBUG - 2022-07-29 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:38:33 --> Total execution time: 0.0718
DEBUG - 2022-07-29 10:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:38:35 --> Total execution time: 0.0639
DEBUG - 2022-07-29 10:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:38:35 --> Total execution time: 0.1933
DEBUG - 2022-07-29 10:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:40:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 10:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:10:10 --> Total execution time: 1.9777
DEBUG - 2022-07-29 10:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 10:40:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 10:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:40:14 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:10:14 --> Total execution time: 0.0444
DEBUG - 2022-07-29 10:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:40:23 --> Total execution time: 0.0834
DEBUG - 2022-07-29 10:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:40:25 --> Total execution time: 0.0728
DEBUG - 2022-07-29 10:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:40:25 --> Total execution time: 0.1720
DEBUG - 2022-07-29 10:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:42:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 10:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:12:11 --> Total execution time: 1.6961
DEBUG - 2022-07-29 10:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:42:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 10:42:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 10:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:12:35 --> Total execution time: 0.0839
DEBUG - 2022-07-29 10:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:13:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 10:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:13:20 --> Total execution time: 0.0739
DEBUG - 2022-07-29 10:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:13:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 21:13:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 21:13:22 --> Total execution time: 0.2271
DEBUG - 2022-07-29 10:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:13:23 --> Total execution time: 0.0682
DEBUG - 2022-07-29 10:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:13:31 --> Total execution time: 0.1230
DEBUG - 2022-07-29 10:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:13:39 --> Total execution time: 0.0727
DEBUG - 2022-07-29 10:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:44:37 --> Total execution time: 0.0641
DEBUG - 2022-07-29 10:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:14:44 --> Total execution time: 0.0689
DEBUG - 2022-07-29 10:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:14:53 --> Total execution time: 0.1058
DEBUG - 2022-07-29 10:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:14:55 --> Total execution time: 0.1018
DEBUG - 2022-07-29 10:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:15:20 --> Total execution time: 0.0715
DEBUG - 2022-07-29 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:15:22 --> Total execution time: 0.0663
DEBUG - 2022-07-29 10:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:15:29 --> Total execution time: 0.0755
DEBUG - 2022-07-29 10:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:15:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 10:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:15:35 --> Total execution time: 0.0719
DEBUG - 2022-07-29 10:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:15:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 21:15:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 21:15:36 --> Total execution time: 0.2234
DEBUG - 2022-07-29 10:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:45:38 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:15:38 --> Total execution time: 0.0518
DEBUG - 2022-07-29 10:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:15:40 --> Total execution time: 0.4880
DEBUG - 2022-07-29 10:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:46:20 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:16:20 --> Total execution time: 0.0618
DEBUG - 2022-07-29 10:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:16:22 --> Total execution time: 0.1953
DEBUG - 2022-07-29 10:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:16:24 --> Total execution time: 0.0509
DEBUG - 2022-07-29 10:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:16:25 --> Total execution time: 0.0623
DEBUG - 2022-07-29 10:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:16:34 --> Total execution time: 0.0694
DEBUG - 2022-07-29 10:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:16:35 --> Total execution time: 0.0682
DEBUG - 2022-07-29 10:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:16:38 --> Total execution time: 0.0809
DEBUG - 2022-07-29 10:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:16:39 --> Total execution time: 0.1067
DEBUG - 2022-07-29 10:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:16:46 --> Total execution time: 0.0903
DEBUG - 2022-07-29 10:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:16:53 --> Total execution time: 0.0714
DEBUG - 2022-07-29 10:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:03 --> Total execution time: 0.0700
DEBUG - 2022-07-29 10:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:08 --> Total execution time: 0.0733
DEBUG - 2022-07-29 10:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:12 --> Total execution time: 0.0785
DEBUG - 2022-07-29 10:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:16 --> Total execution time: 0.0681
DEBUG - 2022-07-29 10:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:19 --> Total execution time: 0.0762
DEBUG - 2022-07-29 10:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:21 --> Total execution time: 0.1084
DEBUG - 2022-07-29 10:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:24 --> Total execution time: 0.0857
DEBUG - 2022-07-29 10:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:25 --> Total execution time: 0.0748
DEBUG - 2022-07-29 10:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:25 --> Total execution time: 0.0948
DEBUG - 2022-07-29 10:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:26 --> Total execution time: 0.0653
DEBUG - 2022-07-29 10:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:31 --> Total execution time: 0.0773
DEBUG - 2022-07-29 10:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:34 --> Total execution time: 0.0952
DEBUG - 2022-07-29 10:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:41 --> Total execution time: 0.0775
DEBUG - 2022-07-29 10:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:48 --> Total execution time: 0.0792
DEBUG - 2022-07-29 10:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:48:34 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:18:35 --> Total execution time: 0.0498
DEBUG - 2022-07-29 10:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:18:45 --> Total execution time: 0.0726
DEBUG - 2022-07-29 10:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:19:12 --> Total execution time: 0.0969
DEBUG - 2022-07-29 10:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:21:25 --> Total execution time: 0.2469
DEBUG - 2022-07-29 10:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:21:25 --> Total execution time: 0.0754
DEBUG - 2022-07-29 10:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:51:37 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:21:37 --> Total execution time: 0.0764
DEBUG - 2022-07-29 10:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:51:42 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:21:42 --> Total execution time: 0.0554
DEBUG - 2022-07-29 10:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 10:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:21:48 --> Total execution time: 0.0873
DEBUG - 2022-07-29 10:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:22:10 --> Total execution time: 0.0975
DEBUG - 2022-07-29 10:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:52:25 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:22:25 --> Total execution time: 0.0433
DEBUG - 2022-07-29 10:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:22:30 --> Total execution time: 0.0689
DEBUG - 2022-07-29 10:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:22:37 --> Total execution time: 0.1203
DEBUG - 2022-07-29 10:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:22:42 --> Total execution time: 0.0731
DEBUG - 2022-07-29 10:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:22:51 --> Total execution time: 0.0964
DEBUG - 2022-07-29 10:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:23:03 --> Total execution time: 0.0799
DEBUG - 2022-07-29 10:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:54:38 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:24:38 --> Total execution time: 0.0798
DEBUG - 2022-07-29 10:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:54:48 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:24:48 --> Total execution time: 0.0651
DEBUG - 2022-07-29 10:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:54:52 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:24:52 --> Total execution time: 0.0639
DEBUG - 2022-07-29 10:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:56:26 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:26:26 --> Total execution time: 0.0435
DEBUG - 2022-07-29 10:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:27:11 --> Total execution time: 0.1682
DEBUG - 2022-07-29 10:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:59:36 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:29:37 --> Total execution time: 0.1153
DEBUG - 2022-07-29 10:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 10:59:37 --> No URI present. Default controller set.
DEBUG - 2022-07-29 10:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 10:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:29:37 --> Total execution time: 0.0447
DEBUG - 2022-07-29 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:30:02 --> Total execution time: 0.0560
DEBUG - 2022-07-29 11:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:00:07 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:30:07 --> Total execution time: 0.0757
DEBUG - 2022-07-29 11:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:00:09 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:30:09 --> Total execution time: 0.0693
DEBUG - 2022-07-29 11:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:30:12 --> Total execution time: 0.2182
DEBUG - 2022-07-29 11:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:30:24 --> Total execution time: 0.0760
DEBUG - 2022-07-29 11:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:30:30 --> Total execution time: 0.3177
DEBUG - 2022-07-29 11:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:30:39 --> Total execution time: 0.1414
DEBUG - 2022-07-29 11:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:01:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 11:01:34 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-07-29 11:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:01:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 11:01:34 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-29 11:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:01:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 11:01:35 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-29 11:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:01:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 11:01:35 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-07-29 11:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:01:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 11:01:36 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-29 11:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:01:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 11:01:36 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-07-29 11:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:01:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 11:01:37 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-29 11:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:01:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 11:01:37 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-07-29 11:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:31:37 --> Total execution time: 0.0468
DEBUG - 2022-07-29 11:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:32:32 --> Total execution time: 0.1090
DEBUG - 2022-07-29 11:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:06:09 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:36:10 --> Total execution time: 0.1290
DEBUG - 2022-07-29 11:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:06:10 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:36:10 --> Total execution time: 0.0465
DEBUG - 2022-07-29 11:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:36:17 --> Total execution time: 0.0510
DEBUG - 2022-07-29 11:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:36:24 --> Total execution time: 0.0842
DEBUG - 2022-07-29 11:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:36:29 --> Total execution time: 0.0792
DEBUG - 2022-07-29 11:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:36:41 --> Total execution time: 0.0749
DEBUG - 2022-07-29 11:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:37:04 --> Total execution time: 0.0980
DEBUG - 2022-07-29 11:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:38:25 --> Total execution time: 0.1239
DEBUG - 2022-07-29 11:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:38:27 --> Total execution time: 0.0746
DEBUG - 2022-07-29 11:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:41:26 --> Total execution time: 0.2359
DEBUG - 2022-07-29 11:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:41:40 --> Total execution time: 0.1085
DEBUG - 2022-07-29 11:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:42:04 --> Total execution time: 0.1769
DEBUG - 2022-07-29 11:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:42:04 --> Total execution time: 0.0696
DEBUG - 2022-07-29 11:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:42:06 --> Total execution time: 0.0676
DEBUG - 2022-07-29 11:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:12:07 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:42:08 --> Total execution time: 0.1765
DEBUG - 2022-07-29 11:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:12:09 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:42:09 --> Total execution time: 0.0875
DEBUG - 2022-07-29 11:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:42:45 --> Total execution time: 0.0739
DEBUG - 2022-07-29 11:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:43:06 --> Total execution time: 0.0512
DEBUG - 2022-07-29 11:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:43:09 --> Total execution time: 0.0661
DEBUG - 2022-07-29 11:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:43:13 --> Total execution time: 0.0653
DEBUG - 2022-07-29 11:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:43:19 --> Total execution time: 0.0706
DEBUG - 2022-07-29 11:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:43:21 --> Total execution time: 0.0733
DEBUG - 2022-07-29 11:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:43:25 --> Total execution time: 0.0744
DEBUG - 2022-07-29 11:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:43:26 --> Total execution time: 0.0688
DEBUG - 2022-07-29 11:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:43:28 --> Total execution time: 0.0750
DEBUG - 2022-07-29 11:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:43:35 --> Total execution time: 0.0810
DEBUG - 2022-07-29 11:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:43:50 --> Total execution time: 0.3651
DEBUG - 2022-07-29 11:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:43:54 --> Total execution time: 0.0785
DEBUG - 2022-07-29 11:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:44:01 --> Total execution time: 0.0648
DEBUG - 2022-07-29 11:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:44:02 --> Total execution time: 0.0680
DEBUG - 2022-07-29 11:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:44:06 --> Total execution time: 0.0928
DEBUG - 2022-07-29 11:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:44:08 --> Total execution time: 0.0676
DEBUG - 2022-07-29 11:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:44:10 --> Total execution time: 0.0643
DEBUG - 2022-07-29 11:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:44:20 --> Total execution time: 0.0639
DEBUG - 2022-07-29 11:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:46:52 --> Total execution time: 0.0730
DEBUG - 2022-07-29 11:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:17:16 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:47:16 --> Total execution time: 0.0777
DEBUG - 2022-07-29 11:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:17:20 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:47:20 --> Total execution time: 0.0767
DEBUG - 2022-07-29 11:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:47:33 --> Total execution time: 0.0656
DEBUG - 2022-07-29 11:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:47:55 --> Total execution time: 0.0689
DEBUG - 2022-07-29 11:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:48:24 --> Total execution time: 0.0774
DEBUG - 2022-07-29 11:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:18:38 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:48:38 --> Total execution time: 0.0715
DEBUG - 2022-07-29 11:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:18:43 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:48:43 --> Total execution time: 0.0742
DEBUG - 2022-07-29 11:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:49:27 --> Total execution time: 0.0711
DEBUG - 2022-07-29 11:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:22:19 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:52:19 --> Total execution time: 0.1229
DEBUG - 2022-07-29 11:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:52:27 --> Total execution time: 0.0587
DEBUG - 2022-07-29 11:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:53:13 --> Total execution time: 0.0863
DEBUG - 2022-07-29 11:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:24:00 --> Total execution time: 0.0650
DEBUG - 2022-07-29 11:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:54:04 --> Total execution time: 0.0726
DEBUG - 2022-07-29 11:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:54:19 --> Total execution time: 0.0803
DEBUG - 2022-07-29 11:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:57:29 --> Total execution time: 0.2426
DEBUG - 2022-07-29 11:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:27:49 --> Total execution time: 0.0908
DEBUG - 2022-07-29 11:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:27:58 --> Total execution time: 0.1229
DEBUG - 2022-07-29 11:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:58:24 --> Total execution time: 0.1845
DEBUG - 2022-07-29 11:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:59:44 --> Total execution time: 0.0833
DEBUG - 2022-07-29 11:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:29:54 --> Total execution time: 0.0666
DEBUG - 2022-07-29 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:29:58 --> Total execution time: 0.0906
DEBUG - 2022-07-29 11:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:31:32 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:01:32 --> Total execution time: 0.0586
DEBUG - 2022-07-29 11:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:02:08 --> Total execution time: 0.1223
DEBUG - 2022-07-29 11:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:03:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 11:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:03:12 --> Total execution time: 0.1066
DEBUG - 2022-07-29 11:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:03:19 --> Total execution time: 0.1112
DEBUG - 2022-07-29 11:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:03:23 --> Total execution time: 0.0772
DEBUG - 2022-07-29 11:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:33:39 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:03:39 --> Total execution time: 0.0569
DEBUG - 2022-07-29 11:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:33:39 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:03:39 --> Total execution time: 0.0685
DEBUG - 2022-07-29 11:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:34:05 --> Total execution time: 0.0717
DEBUG - 2022-07-29 11:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:34:07 --> Total execution time: 0.0712
DEBUG - 2022-07-29 11:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:34:07 --> Total execution time: 0.1485
DEBUG - 2022-07-29 11:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:34:31 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:04:31 --> Total execution time: 0.0652
DEBUG - 2022-07-29 11:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:34:31 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:04:31 --> Total execution time: 0.0724
DEBUG - 2022-07-29 11:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:04:36 --> Total execution time: 0.0647
DEBUG - 2022-07-29 11:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:34:48 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:04:48 --> Total execution time: 0.0745
DEBUG - 2022-07-29 11:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:04:54 --> Total execution time: 0.1102
DEBUG - 2022-07-29 11:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:05:55 --> Total execution time: 0.0747
DEBUG - 2022-07-29 11:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:36:04 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:06:04 --> Total execution time: 0.0669
DEBUG - 2022-07-29 11:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:06:28 --> Total execution time: 0.0633
DEBUG - 2022-07-29 11:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:06:44 --> Total execution time: 0.0672
DEBUG - 2022-07-29 11:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:07:04 --> Total execution time: 0.1058
DEBUG - 2022-07-29 11:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:08:24 --> Total execution time: 0.0765
DEBUG - 2022-07-29 11:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:08:36 --> Total execution time: 0.1615
DEBUG - 2022-07-29 11:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:08:41 --> Total execution time: 0.1307
DEBUG - 2022-07-29 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:09:22 --> Total execution time: 0.0692
DEBUG - 2022-07-29 11:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:09:23 --> Total execution time: 0.0901
DEBUG - 2022-07-29 11:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:09:51 --> Total execution time: 0.0728
DEBUG - 2022-07-29 11:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:16:07 --> Total execution time: 0.0679
DEBUG - 2022-07-29 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:16:14 --> Total execution time: 0.0938
DEBUG - 2022-07-29 11:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:16:19 --> Total execution time: 0.1849
DEBUG - 2022-07-29 11:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:46:58 --> Total execution time: 0.0712
DEBUG - 2022-07-29 11:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:47:12 --> Total execution time: 0.0852
DEBUG - 2022-07-29 11:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:20:05 --> Total execution time: 0.1074
DEBUG - 2022-07-29 11:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:20:33 --> Total execution time: 0.1110
DEBUG - 2022-07-29 11:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:21:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 11:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:21:36 --> Total execution time: 0.1035
DEBUG - 2022-07-29 11:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:23:05 --> Total execution time: 0.0798
DEBUG - 2022-07-29 11:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:23:20 --> Total execution time: 0.1151
DEBUG - 2022-07-29 11:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:23:39 --> Total execution time: 0.0996
DEBUG - 2022-07-29 11:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:23:42 --> Total execution time: 0.0891
DEBUG - 2022-07-29 11:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:23:47 --> Total execution time: 0.1070
DEBUG - 2022-07-29 11:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:24:01 --> Total execution time: 0.0801
DEBUG - 2022-07-29 11:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:24:11 --> Total execution time: 0.1073
DEBUG - 2022-07-29 11:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:24:30 --> Total execution time: 0.0921
DEBUG - 2022-07-29 11:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:24:36 --> Total execution time: 0.1036
DEBUG - 2022-07-29 11:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:24:39 --> Total execution time: 0.1037
DEBUG - 2022-07-29 11:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:25:01 --> Total execution time: 0.0715
DEBUG - 2022-07-29 11:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:55:08 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:25:09 --> Total execution time: 0.1949
DEBUG - 2022-07-29 11:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:25:19 --> Total execution time: 0.0665
DEBUG - 2022-07-29 11:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:25:32 --> Total execution time: 0.1185
DEBUG - 2022-07-29 11:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:25:39 --> Total execution time: 0.0736
DEBUG - 2022-07-29 11:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:26:13 --> Total execution time: 0.1163
DEBUG - 2022-07-29 11:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:26:18 --> Total execution time: 0.0688
DEBUG - 2022-07-29 11:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:19 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:26:19 --> Total execution time: 0.0693
DEBUG - 2022-07-29 11:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:26:25 --> Total execution time: 0.0689
DEBUG - 2022-07-29 11:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:31 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:26:31 --> Total execution time: 0.0435
DEBUG - 2022-07-29 11:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:34 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:26:34 --> Total execution time: 0.0997
DEBUG - 2022-07-29 11:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:26:37 --> Total execution time: 0.0774
DEBUG - 2022-07-29 11:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:37 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:26:38 --> Total execution time: 0.0462
DEBUG - 2022-07-29 11:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:42 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:26:42 --> Total execution time: 0.0661
DEBUG - 2022-07-29 11:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:26:43 --> Total execution time: 0.0988
DEBUG - 2022-07-29 11:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:26:44 --> Total execution time: 0.0735
DEBUG - 2022-07-29 11:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:47 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:26:47 --> Total execution time: 0.0959
DEBUG - 2022-07-29 11:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:26:59 --> Total execution time: 0.0652
DEBUG - 2022-07-29 11:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:27:08 --> Total execution time: 0.0770
DEBUG - 2022-07-29 11:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:27:10 --> Total execution time: 0.0436
DEBUG - 2022-07-29 11:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:27:17 --> Total execution time: 0.1118
DEBUG - 2022-07-29 11:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:27:24 --> Total execution time: 0.0895
DEBUG - 2022-07-29 11:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:27:31 --> Total execution time: 0.0664
DEBUG - 2022-07-29 11:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:27:48 --> Total execution time: 0.0800
DEBUG - 2022-07-29 11:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:27:54 --> Total execution time: 0.1112
DEBUG - 2022-07-29 11:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:28:05 --> Total execution time: 0.0856
DEBUG - 2022-07-29 11:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:28:08 --> Total execution time: 0.0917
DEBUG - 2022-07-29 11:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:28:08 --> Total execution time: 0.0835
DEBUG - 2022-07-29 11:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:28:14 --> Total execution time: 0.1076
DEBUG - 2022-07-29 11:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:58:15 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:28:15 --> Total execution time: 0.0663
DEBUG - 2022-07-29 11:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 11:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:28:29 --> Total execution time: 0.0989
DEBUG - 2022-07-29 11:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:28:30 --> Total execution time: 0.0997
DEBUG - 2022-07-29 11:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:28:30 --> Total execution time: 0.0696
DEBUG - 2022-07-29 11:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:28:36 --> Total execution time: 0.0748
DEBUG - 2022-07-29 11:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:28:44 --> Total execution time: 0.0867
DEBUG - 2022-07-29 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:59:44 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:29:44 --> Total execution time: 0.0617
DEBUG - 2022-07-29 11:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:59:45 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:29:45 --> Total execution time: 0.0477
DEBUG - 2022-07-29 11:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:59:49 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:29:49 --> Total execution time: 0.0733
DEBUG - 2022-07-29 11:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:59:51 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:29:52 --> Total execution time: 0.0527
DEBUG - 2022-07-29 11:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 11:59:56 --> No URI present. Default controller set.
DEBUG - 2022-07-29 11:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 11:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:29:56 --> Total execution time: 0.0495
DEBUG - 2022-07-29 12:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:30:02 --> Total execution time: 0.1003
DEBUG - 2022-07-29 12:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:00:12 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:30:12 --> Total execution time: 0.1225
DEBUG - 2022-07-29 12:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:00:26 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:30:26 --> Total execution time: 0.0567
DEBUG - 2022-07-29 12:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:33 --> Total execution time: 0.2560
DEBUG - 2022-07-29 12:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:34:45 --> Total execution time: 0.1101
DEBUG - 2022-07-29 12:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:34:50 --> Total execution time: 0.0770
DEBUG - 2022-07-29 12:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:34:58 --> Total execution time: 0.0940
DEBUG - 2022-07-29 12:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:35:26 --> Total execution time: 0.0679
DEBUG - 2022-07-29 12:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:06:24 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:36:24 --> Total execution time: 0.0683
DEBUG - 2022-07-29 12:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:09:17 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:39:17 --> Total execution time: 0.2449
DEBUG - 2022-07-29 12:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:41:05 --> Total execution time: 0.0758
DEBUG - 2022-07-29 12:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:41:23 --> Total execution time: 0.0724
DEBUG - 2022-07-29 12:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:42:14 --> Total execution time: 0.0718
DEBUG - 2022-07-29 12:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:42:23 --> Total execution time: 0.0710
DEBUG - 2022-07-29 12:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:42:26 --> Total execution time: 0.0791
DEBUG - 2022-07-29 12:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:12:33 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:42:33 --> Total execution time: 0.0503
DEBUG - 2022-07-29 12:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:42:37 --> Total execution time: 0.0865
DEBUG - 2022-07-29 12:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:42:42 --> Total execution time: 0.0703
DEBUG - 2022-07-29 12:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:42:44 --> Total execution time: 0.0697
DEBUG - 2022-07-29 12:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:43:14 --> Total execution time: 0.0680
DEBUG - 2022-07-29 12:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:43:53 --> Total execution time: 0.0678
DEBUG - 2022-07-29 12:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:43:55 --> Total execution time: 0.0984
DEBUG - 2022-07-29 12:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:43:58 --> Total execution time: 0.0654
DEBUG - 2022-07-29 12:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:14:08 --> Total execution time: 0.0607
DEBUG - 2022-07-29 12:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:14:13 --> Total execution time: 0.0754
DEBUG - 2022-07-29 12:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:14:16 --> Total execution time: 0.0620
DEBUG - 2022-07-29 12:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:14:20 --> Total execution time: 0.0568
DEBUG - 2022-07-29 12:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:14:23 --> Total execution time: 0.0617
DEBUG - 2022-07-29 12:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:14:24 --> Total execution time: 0.0916
DEBUG - 2022-07-29 12:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:14:25 --> Total execution time: 0.0636
DEBUG - 2022-07-29 12:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:44:25 --> Total execution time: 0.0610
DEBUG - 2022-07-29 12:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:28 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:44:28 --> Total execution time: 0.0611
DEBUG - 2022-07-29 12:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:44:53 --> Total execution time: 0.0665
DEBUG - 2022-07-29 12:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:15:36 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:45:36 --> Total execution time: 0.0851
DEBUG - 2022-07-29 12:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:16:06 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:46:06 --> Total execution time: 0.0830
DEBUG - 2022-07-29 12:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:16:11 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:46:11 --> Total execution time: 0.0651
DEBUG - 2022-07-29 12:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:46:23 --> Total execution time: 0.0649
DEBUG - 2022-07-29 12:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:16:34 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:46:34 --> Total execution time: 0.0664
DEBUG - 2022-07-29 12:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:16:46 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:46:46 --> Total execution time: 0.0473
DEBUG - 2022-07-29 12:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:46:49 --> Total execution time: 0.0765
DEBUG - 2022-07-29 12:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:46:50 --> Total execution time: 0.0630
DEBUG - 2022-07-29 12:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:46:55 --> Total execution time: 0.0756
DEBUG - 2022-07-29 12:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:47:19 --> Total execution time: 0.0688
DEBUG - 2022-07-29 12:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:47:25 --> Total execution time: 0.0944
DEBUG - 2022-07-29 12:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:17:52 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:47:52 --> Total execution time: 0.1730
DEBUG - 2022-07-29 12:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:47:57 --> Total execution time: 0.0671
DEBUG - 2022-07-29 12:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:48:01 --> Total execution time: 0.2848
DEBUG - 2022-07-29 12:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:48:07 --> Total execution time: 0.0892
DEBUG - 2022-07-29 12:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:48:09 --> Total execution time: 0.1012
DEBUG - 2022-07-29 12:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:48:10 --> Total execution time: 0.0910
DEBUG - 2022-07-29 12:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:48:14 --> Total execution time: 0.1268
DEBUG - 2022-07-29 12:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:48:37 --> Total execution time: 0.0867
DEBUG - 2022-07-29 12:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:48:45 --> Total execution time: 0.1007
DEBUG - 2022-07-29 12:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:18:58 --> 404 Page Not Found: Wp-loadphp/index
DEBUG - 2022-07-29 12:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:18:59 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:48:59 --> Total execution time: 0.0687
DEBUG - 2022-07-29 12:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:19:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:19:04 --> 404 Page Not Found: Stylephp/index
DEBUG - 2022-07-29 12:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:19:05 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:49:05 --> Total execution time: 0.0506
DEBUG - 2022-07-29 12:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:19:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:19:18 --> 404 Page Not Found: Wp-admin/style.php
DEBUG - 2022-07-29 12:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:19:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:19:26 --> 404 Page Not Found: S_ephp/index
DEBUG - 2022-07-29 12:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:19:28 --> Total execution time: 0.0982
DEBUG - 2022-07-29 12:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:19:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:19:31 --> 404 Page Not Found: S_nephp/index
DEBUG - 2022-07-29 12:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:19:47 --> 404 Page Not Found: 1indexphp/index
DEBUG - 2022-07-29 12:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:19:47 --> Total execution time: 0.0711
DEBUG - 2022-07-29 12:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:19:47 --> Total execution time: 0.1522
DEBUG - 2022-07-29 12:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:19:48 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:49:48 --> Total execution time: 0.0544
DEBUG - 2022-07-29 12:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:19:50 --> 404 Page Not Found: Radiophp/index
DEBUG - 2022-07-29 12:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:49:51 --> Total execution time: 0.0451
DEBUG - 2022-07-29 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:19:54 --> 404 Page Not Found: Docphp/index
DEBUG - 2022-07-29 12:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:20:01 --> 404 Page Not Found: Wp_wrong_datlibphp/index
DEBUG - 2022-07-29 12:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:50:03 --> Total execution time: 0.0892
DEBUG - 2022-07-29 12:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:20:06 --> 404 Page Not Found: Beencephp/index
DEBUG - 2022-07-29 12:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:50:08 --> Total execution time: 0.0919
DEBUG - 2022-07-29 12:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:20:08 --> 404 Page Not Found: Upsphp/index
DEBUG - 2022-07-29 22:50:10 --> Total execution time: 1.9341
DEBUG - 2022-07-29 12:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:50:10 --> Total execution time: 0.0727
DEBUG - 2022-07-29 12:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:20:11 --> 404 Page Not Found: Wp-signinphp/index
DEBUG - 2022-07-29 12:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:20:13 --> 404 Page Not Found: Media-adminphp/index
DEBUG - 2022-07-29 12:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:20:16 --> 404 Page Not Found: Exportphp/index
DEBUG - 2022-07-29 12:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:20:16 --> 404 Page Not Found: Wp-content/export.php
DEBUG - 2022-07-29 12:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:50:18 --> Total execution time: 0.0630
DEBUG - 2022-07-29 12:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:20:26 --> 404 Page Not Found: Wp-includes/wp-class.php
DEBUG - 2022-07-29 12:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:20:28 --> 404 Page Not Found: Wp-includes/wp-atom.php
DEBUG - 2022-07-29 12:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:20:32 --> 404 Page Not Found: Wp-includes/images
DEBUG - 2022-07-29 12:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:20:34 --> 404 Page Not Found: Wp-includes/css
DEBUG - 2022-07-29 12:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:20:40 --> 404 Page Not Found: Defau1tphp/index
DEBUG - 2022-07-29 12:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:20:47 --> 404 Page Not Found: Modulessphp/index
DEBUG - 2022-07-29 12:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:20:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:20:54 --> 404 Page Not Found: Wp-bookingphp/index
DEBUG - 2022-07-29 12:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:21:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:21:03 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 12:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:21:06 --> 404 Page Not Found: Wp-content/mu-plugins
DEBUG - 2022-07-29 12:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:21:09 --> 404 Page Not Found: Wp-includes/css
DEBUG - 2022-07-29 12:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:21:21 --> 404 Page Not Found: Legionphp/index
DEBUG - 2022-07-29 12:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:21:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:21:26 --> 404 Page Not Found: Wp-pluginsphp/index
DEBUG - 2022-07-29 12:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:21:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:21:30 --> 404 Page Not Found: GankphpPhP/index
DEBUG - 2022-07-29 12:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:51:35 --> Total execution time: 1.6433
DEBUG - 2022-07-29 12:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:21:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:21:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 12:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:21:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 12:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:51:50 --> Total execution time: 1.5261
DEBUG - 2022-07-29 12:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:21:52 --> 404 Page Not Found: Wp-content/db-cache.php
DEBUG - 2022-07-29 12:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:21:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 12:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:22:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:22:07 --> 404 Page Not Found: Archivesphp/index
DEBUG - 2022-07-29 12:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:22:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:22:13 --> 404 Page Not Found: Defau11php/index
DEBUG - 2022-07-29 12:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:22:16 --> 404 Page Not Found: Wp-content/outcms.php
DEBUG - 2022-07-29 12:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:22:20 --> 404 Page Not Found: System_logphp/index
DEBUG - 2022-07-29 12:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:22:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:22:25 --> 404 Page Not Found: Wp-backup-sql-302php/index
DEBUG - 2022-07-29 12:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:22:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:22:28 --> 404 Page Not Found: Errorphp/index
DEBUG - 2022-07-29 12:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:22:34 --> 404 Page Not Found: ALFA_DATA/index
DEBUG - 2022-07-29 12:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:22:41 --> 404 Page Not Found: Alfacgiapi/index
DEBUG - 2022-07-29 12:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:22:47 --> 404 Page Not Found: Cgialfa/index
DEBUG - 2022-07-29 12:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:52:51 --> Total execution time: 1.5109
DEBUG - 2022-07-29 12:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:22:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:22:58 --> 404 Page Not Found: Well-known/ALFA_DATA
DEBUG - 2022-07-29 12:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:23:00 --> 404 Page Not Found: Well-known/alfacgiapi
DEBUG - 2022-07-29 12:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:05 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:53:05 --> Total execution time: 0.0450
DEBUG - 2022-07-29 12:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:05 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:53:05 --> Total execution time: 0.0447
DEBUG - 2022-07-29 12:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:23:06 --> 404 Page Not Found: Well-known/cgialfa
DEBUG - 2022-07-29 12:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:53:09 --> Total execution time: 1.5635
DEBUG - 2022-07-29 12:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:15 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:53:15 --> Total execution time: 0.0684
DEBUG - 2022-07-29 12:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:15 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:53:15 --> Total execution time: 0.0741
DEBUG - 2022-07-29 12:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:23:16 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-29 12:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:23:18 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-29 12:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:23:21 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-29 12:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:23:26 --> 404 Page Not Found: Wp-includes/ALFA_DATA
DEBUG - 2022-07-29 12:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:23:33 --> 404 Page Not Found: Wp-includes/alfacgiapi
DEBUG - 2022-07-29 12:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:53:33 --> Total execution time: 0.2103
DEBUG - 2022-07-29 12:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:53:34 --> Total execution time: 0.0705
DEBUG - 2022-07-29 12:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:23:36 --> 404 Page Not Found: Wp-includes/cgialfa
DEBUG - 2022-07-29 12:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:53:40 --> Total execution time: 0.0679
DEBUG - 2022-07-29 12:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:23:49 --> 404 Page Not Found: Wp-admin/ALFA_DATA
DEBUG - 2022-07-29 12:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:51 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:53:51 --> Total execution time: 0.0656
DEBUG - 2022-07-29 12:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:23:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:23:55 --> 404 Page Not Found: Wp-admin/alfacgiapi
DEBUG - 2022-07-29 12:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:24:02 --> 404 Page Not Found: Wp-admin/cgialfa
DEBUG - 2022-07-29 12:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:24:06 --> 404 Page Not Found: Wp-content/ALFA_DATA
DEBUG - 2022-07-29 12:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:24:14 --> 404 Page Not Found: Wp-content/alfacgiapi
DEBUG - 2022-07-29 12:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:24:16 --> 404 Page Not Found: Wp-content/cgialfa
DEBUG - 2022-07-29 12:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:24:19 --> 404 Page Not Found: Templates/beez3
DEBUG - 2022-07-29 12:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:54:20 --> Total execution time: 0.0633
DEBUG - 2022-07-29 12:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:24:21 --> 404 Page Not Found: Templates/beez3
DEBUG - 2022-07-29 12:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:24:24 --> 404 Page Not Found: Templates/beez3
DEBUG - 2022-07-29 12:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:24:27 --> 404 Page Not Found: Sites/default
DEBUG - 2022-07-29 12:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:54:36 --> Total execution time: 0.0628
DEBUG - 2022-07-29 12:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:24:37 --> 404 Page Not Found: Sites/default
DEBUG - 2022-07-29 12:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:24:43 --> 404 Page Not Found: Sites/default
DEBUG - 2022-07-29 12:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:24:49 --> 404 Page Not Found: Admin/controller
DEBUG - 2022-07-29 12:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:54:52 --> Total execution time: 0.0657
DEBUG - 2022-07-29 12:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:24:52 --> 404 Page Not Found: Admin/controller
DEBUG - 2022-07-29 12:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:24:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:24:54 --> 404 Page Not Found: Admin/controller
DEBUG - 2022-07-29 12:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:02 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 12:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:03 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:55:03 --> Total execution time: 0.0447
DEBUG - 2022-07-29 12:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:55:14 --> Total execution time: 0.0772
DEBUG - 2022-07-29 12:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:14 --> 404 Page Not Found: Oluxphp/index
DEBUG - 2022-07-29 12:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:15 --> 404 Page Not Found: Xleetphp/index
DEBUG - 2022-07-29 12:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:16 --> 404 Page Not Found: Wsophp/index
DEBUG - 2022-07-29 12:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:18 --> 404 Page Not Found: Shellphp/index
DEBUG - 2022-07-29 12:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:19 --> 404 Page Not Found: Upphp/index
DEBUG - 2022-07-29 12:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:20 --> 404 Page Not Found: Uploadphp/index
DEBUG - 2022-07-29 12:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:20 --> 404 Page Not Found: 1php/index
DEBUG - 2022-07-29 12:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:55:21 --> Total execution time: 0.1115
DEBUG - 2022-07-29 12:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:22 --> 404 Page Not Found: Xphp/index
DEBUG - 2022-07-29 12:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:25 --> 404 Page Not Found: Zphp/index
DEBUG - 2022-07-29 12:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:55:33 --> Total execution time: 0.0753
DEBUG - 2022-07-29 12:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:35 --> 404 Page Not Found: Testphp/index
DEBUG - 2022-07-29 12:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:36 --> 404 Page Not Found: Wpphp/index
DEBUG - 2022-07-29 12:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:37 --> 404 Page Not Found: Alfaphp/index
DEBUG - 2022-07-29 12:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:38 --> 404 Page Not Found: Configphp/index
DEBUG - 2022-07-29 12:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:39 --> 404 Page Not Found: Templates/beez3
DEBUG - 2022-07-29 12:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:41 --> 404 Page Not Found: Aboutphp/index
DEBUG - 2022-07-29 12:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:25:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:25:41 --> 404 Page Not Found: Shellsphp/index
DEBUG - 2022-07-29 12:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:27:10 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:57:10 --> Total execution time: 0.0561
DEBUG - 2022-07-29 12:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:27:21 --> Total execution time: 0.0656
DEBUG - 2022-07-29 12:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:27:32 --> Total execution time: 0.0731
DEBUG - 2022-07-29 12:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:27:32 --> Total execution time: 0.1378
DEBUG - 2022-07-29 12:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:57:33 --> Total execution time: 0.0670
DEBUG - 2022-07-29 12:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:28:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 12:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:58:17 --> Total execution time: 1.5858
DEBUG - 2022-07-29 12:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:28:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:28:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 12:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:58:35 --> Total execution time: 0.2109
DEBUG - 2022-07-29 12:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:58:37 --> Total execution time: 0.1052
DEBUG - 2022-07-29 12:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:58:47 --> Total execution time: 0.0811
DEBUG - 2022-07-29 12:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:58:48 --> Total execution time: 0.0797
DEBUG - 2022-07-29 12:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:59:00 --> Total execution time: 0.0835
DEBUG - 2022-07-29 12:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:59:06 --> Total execution time: 0.0714
DEBUG - 2022-07-29 12:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:59:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 12:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:59:08 --> Total execution time: 0.0593
DEBUG - 2022-07-29 12:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:59:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 22:59:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 22:59:10 --> Total execution time: 0.1958
DEBUG - 2022-07-29 12:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:29:11 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:59:11 --> Total execution time: 0.0437
DEBUG - 2022-07-29 12:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:29:45 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:59:46 --> Total execution time: 0.0441
DEBUG - 2022-07-29 12:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:01:19 --> Total execution time: 0.0677
DEBUG - 2022-07-29 12:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:01:38 --> Total execution time: 0.0868
DEBUG - 2022-07-29 12:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:01:39 --> Total execution time: 0.0902
DEBUG - 2022-07-29 12:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:01:44 --> Total execution time: 0.1777
DEBUG - 2022-07-29 12:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:01:45 --> Total execution time: 0.1077
DEBUG - 2022-07-29 12:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:31:47 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:01:47 --> Total execution time: 0.0679
DEBUG - 2022-07-29 12:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:31:55 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:01:55 --> Total execution time: 0.0669
DEBUG - 2022-07-29 12:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:01:57 --> Total execution time: 0.0712
DEBUG - 2022-07-29 12:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:02:56 --> Total execution time: 0.0637
DEBUG - 2022-07-29 12:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:06:05 --> Total execution time: 0.2379
DEBUG - 2022-07-29 12:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:06:06 --> Total execution time: 0.0693
DEBUG - 2022-07-29 12:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:06:13 --> Total execution time: 0.0692
DEBUG - 2022-07-29 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:06:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:06:22 --> Total execution time: 0.0666
DEBUG - 2022-07-29 12:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:06:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 23:06:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 23:06:24 --> Total execution time: 0.2638
DEBUG - 2022-07-29 12:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:06:29 --> Total execution time: 1.6641
DEBUG - 2022-07-29 12:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:07:22 --> Total execution time: 0.0732
DEBUG - 2022-07-29 12:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:37:43 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:07:43 --> Total execution time: 0.0548
DEBUG - 2022-07-29 12:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:37:48 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:07:49 --> Total execution time: 0.0990
DEBUG - 2022-07-29 12:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:38:05 --> Total execution time: 0.0561
DEBUG - 2022-07-29 12:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:38:06 --> Total execution time: 0.0690
DEBUG - 2022-07-29 12:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:38:06 --> Total execution time: 0.0426
DEBUG - 2022-07-29 12:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:38:14 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:08:14 --> Total execution time: 0.0479
DEBUG - 2022-07-29 12:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:39:50 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:09:50 --> Total execution time: 0.1711
DEBUG - 2022-07-29 12:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:09:53 --> Total execution time: 0.1651
DEBUG - 2022-07-29 12:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:10:02 --> Total execution time: 0.1226
DEBUG - 2022-07-29 12:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:10:05 --> Total execution time: 0.1095
DEBUG - 2022-07-29 12:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:10:34 --> Total execution time: 0.1041
DEBUG - 2022-07-29 12:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:10:35 --> Total execution time: 0.0929
DEBUG - 2022-07-29 12:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:10:37 --> Total execution time: 0.0688
DEBUG - 2022-07-29 12:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:10:47 --> Total execution time: 0.0960
DEBUG - 2022-07-29 12:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:10:55 --> Total execution time: 0.0431
DEBUG - 2022-07-29 12:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:11:00 --> Total execution time: 0.3705
DEBUG - 2022-07-29 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:11:07 --> Total execution time: 0.4969
DEBUG - 2022-07-29 12:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:11:26 --> Total execution time: 0.0419
DEBUG - 2022-07-29 12:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:12:50 --> Total execution time: 0.0619
DEBUG - 2022-07-29 12:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:14:08 --> Total execution time: 0.1005
DEBUG - 2022-07-29 12:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:14:32 --> Total execution time: 0.0867
DEBUG - 2022-07-29 12:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:44:59 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:14:59 --> Total execution time: 0.0473
DEBUG - 2022-07-29 12:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:15:10 --> Total execution time: 0.1798
DEBUG - 2022-07-29 12:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:16:02 --> Total execution time: 0.0873
DEBUG - 2022-07-29 12:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:16:04 --> Total execution time: 0.1124
DEBUG - 2022-07-29 12:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:46:12 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:16:12 --> Total execution time: 0.0447
DEBUG - 2022-07-29 12:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:46:15 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:16:15 --> Total execution time: 0.0638
DEBUG - 2022-07-29 12:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:16:19 --> Total execution time: 0.0876
DEBUG - 2022-07-29 12:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:16:19 --> Total execution time: 0.0992
DEBUG - 2022-07-29 12:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:16:20 --> Total execution time: 0.0960
DEBUG - 2022-07-29 12:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:16:23 --> Total execution time: 0.1032
DEBUG - 2022-07-29 12:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:16:23 --> Total execution time: 0.2272
DEBUG - 2022-07-29 12:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:16:23 --> Total execution time: 0.3281
DEBUG - 2022-07-29 12:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:16:32 --> Total execution time: 0.3249
DEBUG - 2022-07-29 12:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:16:36 --> Total execution time: 0.0595
DEBUG - 2022-07-29 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:46:53 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:16:53 --> Total execution time: 0.0454
DEBUG - 2022-07-29 12:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:16:56 --> Total execution time: 0.0628
DEBUG - 2022-07-29 12:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:17:12 --> Total execution time: 0.0647
DEBUG - 2022-07-29 12:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:17:19 --> Total execution time: 0.0848
DEBUG - 2022-07-29 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:17:25 --> Total execution time: 0.0672
DEBUG - 2022-07-29 12:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:17:30 --> Total execution time: 0.1105
DEBUG - 2022-07-29 12:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:17:31 --> Total execution time: 0.1106
DEBUG - 2022-07-29 12:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:17:31 --> Total execution time: 0.0903
DEBUG - 2022-07-29 12:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:17:32 --> Total execution time: 0.0874
DEBUG - 2022-07-29 12:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:17:32 --> Total execution time: 0.0806
DEBUG - 2022-07-29 12:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:17:39 --> Total execution time: 0.0651
DEBUG - 2022-07-29 12:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:17:44 --> Total execution time: 0.0723
DEBUG - 2022-07-29 12:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:17:53 --> Total execution time: 0.1029
DEBUG - 2022-07-29 12:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:18:00 --> Total execution time: 0.0669
DEBUG - 2022-07-29 12:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:18:04 --> Total execution time: 0.0755
DEBUG - 2022-07-29 12:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:18:12 --> Total execution time: 0.0770
DEBUG - 2022-07-29 12:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:18:12 --> Total execution time: 0.0657
DEBUG - 2022-07-29 12:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:18:20 --> Total execution time: 0.1011
DEBUG - 2022-07-29 12:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:18:23 --> Total execution time: 0.1271
DEBUG - 2022-07-29 12:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:48:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 12:48:53 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-29 12:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:48:53 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:18:53 --> Total execution time: 0.0439
DEBUG - 2022-07-29 12:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:50:50 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:20:50 --> Total execution time: 0.1671
DEBUG - 2022-07-29 12:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:20:53 --> Total execution time: 0.1684
DEBUG - 2022-07-29 12:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:00 --> Total execution time: 0.1777
DEBUG - 2022-07-29 12:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:01 --> Total execution time: 0.1052
DEBUG - 2022-07-29 12:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:10 --> Total execution time: 0.0942
DEBUG - 2022-07-29 12:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:14 --> Total execution time: 0.0823
DEBUG - 2022-07-29 12:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:23 --> Total execution time: 0.1285
DEBUG - 2022-07-29 12:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:25 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:25 --> Total execution time: 0.0455
DEBUG - 2022-07-29 12:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:27 --> Total execution time: 0.0640
DEBUG - 2022-07-29 12:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:29 --> Total execution time: 0.0425
DEBUG - 2022-07-29 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:31 --> Total execution time: 0.0669
DEBUG - 2022-07-29 12:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:36 --> Total execution time: 0.0676
DEBUG - 2022-07-29 12:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:38 --> Total execution time: 0.1193
DEBUG - 2022-07-29 12:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:39 --> Total execution time: 0.0707
DEBUG - 2022-07-29 12:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:40 --> Total execution time: 0.0674
DEBUG - 2022-07-29 12:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:43 --> Total execution time: 0.0701
DEBUG - 2022-07-29 12:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:45 --> Total execution time: 0.1071
DEBUG - 2022-07-29 12:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:46 --> Total execution time: 0.0728
DEBUG - 2022-07-29 12:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:49 --> Total execution time: 0.0857
DEBUG - 2022-07-29 12:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:21:53 --> Total execution time: 0.0882
DEBUG - 2022-07-29 12:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:22:03 --> Total execution time: 0.0867
DEBUG - 2022-07-29 12:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:22:30 --> Total execution time: 0.0756
DEBUG - 2022-07-29 12:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:22:47 --> Total execution time: 0.1673
DEBUG - 2022-07-29 12:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:52:53 --> No URI present. Default controller set.
DEBUG - 2022-07-29 12:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:22:53 --> Total execution time: 0.1782
DEBUG - 2022-07-29 12:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:23:06 --> Total execution time: 0.1266
DEBUG - 2022-07-29 12:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:23:32 --> Total execution time: 0.0960
DEBUG - 2022-07-29 12:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 12:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:23:50 --> Total execution time: 0.0629
DEBUG - 2022-07-29 12:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:28:43 --> Total execution time: 0.2815
DEBUG - 2022-07-29 12:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:29:08 --> Total execution time: 0.0824
DEBUG - 2022-07-29 12:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:29:34 --> Total execution time: 0.1073
DEBUG - 2022-07-29 12:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 12:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 12:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:29:45 --> Total execution time: 0.1238
DEBUG - 2022-07-29 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:30:02 --> Total execution time: 0.0523
DEBUG - 2022-07-29 13:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:30:40 --> Total execution time: 0.0888
DEBUG - 2022-07-29 13:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:31:11 --> Total execution time: 0.0877
DEBUG - 2022-07-29 13:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:31:35 --> Total execution time: 0.0817
DEBUG - 2022-07-29 13:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:32:02 --> Total execution time: 0.0918
DEBUG - 2022-07-29 13:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:32:11 --> Total execution time: 0.0689
DEBUG - 2022-07-29 13:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:35:58 --> Total execution time: 0.0618
DEBUG - 2022-07-29 13:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:37:41 --> Total execution time: 0.2020
DEBUG - 2022-07-29 13:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:38:41 --> Total execution time: 0.0831
DEBUG - 2022-07-29 13:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:39:02 --> Total execution time: 0.1139
DEBUG - 2022-07-29 13:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:39:59 --> Total execution time: 0.1985
DEBUG - 2022-07-29 13:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:40:28 --> Total execution time: 0.1142
DEBUG - 2022-07-29 13:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:41:05 --> Total execution time: 0.0771
DEBUG - 2022-07-29 13:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:41:31 --> Total execution time: 0.0932
DEBUG - 2022-07-29 13:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:42:49 --> Total execution time: 0.3439
DEBUG - 2022-07-29 13:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:13:00 --> No URI present. Default controller set.
DEBUG - 2022-07-29 13:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:43:00 --> Total execution time: 0.0492
DEBUG - 2022-07-29 13:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:13:02 --> No URI present. Default controller set.
DEBUG - 2022-07-29 13:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:43:02 --> Total execution time: 0.1313
DEBUG - 2022-07-29 13:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:43:07 --> Total execution time: 0.0606
DEBUG - 2022-07-29 13:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:43:17 --> Total execution time: 0.0977
DEBUG - 2022-07-29 13:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:43:18 --> Total execution time: 0.0771
DEBUG - 2022-07-29 13:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:43:24 --> Total execution time: 0.1052
DEBUG - 2022-07-29 13:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:43:28 --> Total execution time: 0.1096
DEBUG - 2022-07-29 13:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:43:46 --> Total execution time: 0.0957
DEBUG - 2022-07-29 13:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:43:49 --> Total execution time: 0.0750
DEBUG - 2022-07-29 13:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:44:06 --> Total execution time: 0.1024
DEBUG - 2022-07-29 13:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:45:15 --> Total execution time: 0.0939
DEBUG - 2022-07-29 13:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:15:33 --> No URI present. Default controller set.
DEBUG - 2022-07-29 13:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:15:33 --> No URI present. Default controller set.
DEBUG - 2022-07-29 13:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:45:33 --> Total execution time: 0.0496
DEBUG - 2022-07-29 13:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:45:33 --> Total execution time: 0.0838
DEBUG - 2022-07-29 13:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:46:12 --> Total execution time: 0.1109
DEBUG - 2022-07-29 13:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:48:13 --> Total execution time: 0.1735
DEBUG - 2022-07-29 13:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:18:39 --> No URI present. Default controller set.
DEBUG - 2022-07-29 13:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:48:39 --> Total execution time: 0.0573
DEBUG - 2022-07-29 13:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:48:47 --> Total execution time: 0.0894
DEBUG - 2022-07-29 13:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:49:47 --> Total execution time: 0.0699
DEBUG - 2022-07-29 13:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:23:07 --> No URI present. Default controller set.
DEBUG - 2022-07-29 13:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:53:07 --> Total execution time: 0.2019
DEBUG - 2022-07-29 13:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:24:34 --> No URI present. Default controller set.
DEBUG - 2022-07-29 13:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:54:34 --> Total execution time: 0.0485
DEBUG - 2022-07-29 13:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:24:50 --> Total execution time: 0.1193
DEBUG - 2022-07-29 13:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:24:51 --> Total execution time: 0.0773
DEBUG - 2022-07-29 13:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:24:51 --> Total execution time: 0.1443
DEBUG - 2022-07-29 13:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:25:08 --> No URI present. Default controller set.
DEBUG - 2022-07-29 13:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:55:09 --> Total execution time: 0.0739
DEBUG - 2022-07-29 13:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:25:16 --> Total execution time: 0.0710
DEBUG - 2022-07-29 13:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:25:18 --> Total execution time: 0.0696
DEBUG - 2022-07-29 13:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:25:18 --> Total execution time: 0.1304
DEBUG - 2022-07-29 13:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:25:45 --> No URI present. Default controller set.
DEBUG - 2022-07-29 13:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:55:45 --> Total execution time: 0.0719
DEBUG - 2022-07-29 13:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:26:33 --> Total execution time: 0.0719
DEBUG - 2022-07-29 13:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:26:35 --> Total execution time: 0.0708
DEBUG - 2022-07-29 13:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:26:35 --> Total execution time: 0.1436
DEBUG - 2022-07-29 13:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:59:13 --> Total execution time: 0.2853
DEBUG - 2022-07-29 13:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:30:48 --> No URI present. Default controller set.
DEBUG - 2022-07-29 13:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:37:29 --> No URI present. Default controller set.
DEBUG - 2022-07-29 13:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 13:43:07 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-29 13:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:53:19 --> No URI present. Default controller set.
DEBUG - 2022-07-29 13:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:53:56 --> No URI present. Default controller set.
DEBUG - 2022-07-29 13:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 13:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 13:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 13:59:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 13:59:34 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-29 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:04:55 --> Total execution time: 0.1010
DEBUG - 2022-07-29 14:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:04:56 --> Total execution time: 0.0676
DEBUG - 2022-07-29 14:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:04:56 --> Total execution time: 0.1062
DEBUG - 2022-07-29 14:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:05:20 --> No URI present. Default controller set.
DEBUG - 2022-07-29 14:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:07:13 --> No URI present. Default controller set.
DEBUG - 2022-07-29 14:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:10:53 --> No URI present. Default controller set.
DEBUG - 2022-07-29 14:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:11:55 --> No URI present. Default controller set.
DEBUG - 2022-07-29 14:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:12:10 --> No URI present. Default controller set.
DEBUG - 2022-07-29 14:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:15:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 14:15:19 --> 404 Page Not Found: Wp-content/uploads.php
DEBUG - 2022-07-29 14:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:29:51 --> No URI present. Default controller set.
DEBUG - 2022-07-29 14:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:45:04 --> No URI present. Default controller set.
DEBUG - 2022-07-29 14:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 14:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 14:47:09 --> No URI present. Default controller set.
DEBUG - 2022-07-29 14:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 14:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:01:20 --> No URI present. Default controller set.
DEBUG - 2022-07-29 15:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:03:22 --> No URI present. Default controller set.
DEBUG - 2022-07-29 15:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:03:45 --> No URI present. Default controller set.
DEBUG - 2022-07-29 15:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:03:46 --> No URI present. Default controller set.
DEBUG - 2022-07-29 15:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:29:49 --> No URI present. Default controller set.
DEBUG - 2022-07-29 15:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:30:14 --> No URI present. Default controller set.
DEBUG - 2022-07-29 15:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:32:10 --> No URI present. Default controller set.
DEBUG - 2022-07-29 15:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:32:10 --> No URI present. Default controller set.
DEBUG - 2022-07-29 15:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:39:01 --> No URI present. Default controller set.
DEBUG - 2022-07-29 15:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:41:06 --> No URI present. Default controller set.
DEBUG - 2022-07-29 15:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:54:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 15:54:41 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-29 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 15:54:50 --> 404 Page Not Found: Lessons/dow-theory-all-about-dow-theory
DEBUG - 2022-07-29 15:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 15:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 15:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 16:09:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 16:09:43 --> 404 Page Not Found: 502shtml/index
DEBUG - 2022-07-29 16:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 16:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 16:33:09 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-29 16:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 16:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 16:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 16:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 16:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 16:41:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 16:41:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-29 16:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 16:41:26 --> No URI present. Default controller set.
DEBUG - 2022-07-29 16:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 16:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 16:41:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 16:41:28 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-29 16:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 16:49:38 --> No URI present. Default controller set.
DEBUG - 2022-07-29 16:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 16:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 16:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 16:59:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 16:59:31 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-29 16:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 16:59:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 16:59:36 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-29 16:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 16:59:55 --> No URI present. Default controller set.
DEBUG - 2022-07-29 16:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 16:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 17:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 17:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 17:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 17:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 17:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 17:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 17:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 17:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 17:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 17:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 17:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 17:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:00:27 --> Total execution time: 0.0685
DEBUG - 2022-07-29 17:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 17:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 17:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 17:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 17:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 17:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 17:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 17:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 17:49:46 --> No URI present. Default controller set.
DEBUG - 2022-07-29 17:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 17:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:21:26 --> No URI present. Default controller set.
DEBUG - 2022-07-29 18:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:43:12 --> No URI present. Default controller set.
DEBUG - 2022-07-29 18:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:43:32 --> No URI present. Default controller set.
DEBUG - 2022-07-29 18:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:54:37 --> No URI present. Default controller set.
DEBUG - 2022-07-29 18:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 18:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 18:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 18:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:23:47 --> No URI present. Default controller set.
DEBUG - 2022-07-29 19:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:23:47 --> No URI present. Default controller set.
DEBUG - 2022-07-29 19:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:30:04 --> No URI present. Default controller set.
DEBUG - 2022-07-29 19:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:31:26 --> Total execution time: 0.0495
DEBUG - 2022-07-29 19:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:31:32 --> Total execution time: 0.0940
DEBUG - 2022-07-29 19:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:31:32 --> Total execution time: 0.0584
DEBUG - 2022-07-29 19:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:31:44 --> Total execution time: 0.0752
DEBUG - 2022-07-29 19:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:31:49 --> Total execution time: 0.0871
DEBUG - 2022-07-29 19:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:34:49 --> No URI present. Default controller set.
DEBUG - 2022-07-29 19:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-includes/css
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:49 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:49 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:39:49 --> UTF-8 Support Enabled
ERROR - 2022-07-29 19:39:49 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:49 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:49 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:49 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2022-07-29 19:39:49 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:49 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:49 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 19:39:49 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-29 19:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:53:14 --> No URI present. Default controller set.
DEBUG - 2022-07-29 19:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:54:52 --> No URI present. Default controller set.
DEBUG - 2022-07-29 19:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 19:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 19:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 19:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:01:28 --> No URI present. Default controller set.
DEBUG - 2022-07-29 20:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:01:52 --> No URI present. Default controller set.
DEBUG - 2022-07-29 20:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:24:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 20:24:12 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-07-29 20:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:39:12 --> No URI present. Default controller set.
DEBUG - 2022-07-29 20:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:39:13 --> No URI present. Default controller set.
DEBUG - 2022-07-29 20:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:39:46 --> Total execution time: 0.0511
DEBUG - 2022-07-29 20:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:39:47 --> Total execution time: 0.1398
DEBUG - 2022-07-29 20:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:39:47 --> Total execution time: 0.2443
DEBUG - 2022-07-29 20:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:39:50 --> No URI present. Default controller set.
DEBUG - 2022-07-29 20:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:39:57 --> No URI present. Default controller set.
DEBUG - 2022-07-29 20:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:46:29 --> No URI present. Default controller set.
DEBUG - 2022-07-29 20:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:47:24 --> No URI present. Default controller set.
DEBUG - 2022-07-29 20:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:48:02 --> No URI present. Default controller set.
DEBUG - 2022-07-29 20:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:52:54 --> No URI present. Default controller set.
DEBUG - 2022-07-29 20:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:53:20 --> Total execution time: 0.0610
DEBUG - 2022-07-29 20:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:53:29 --> Total execution time: 0.0660
DEBUG - 2022-07-29 20:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:53:29 --> Total execution time: 0.1795
DEBUG - 2022-07-29 20:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 20:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 20:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 20:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:02:05 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 21:02:53 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-29 21:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:09:06 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:10:06 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:24:16 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:24:51 --> Total execution time: 0.0715
DEBUG - 2022-07-29 21:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:24:52 --> Total execution time: 0.0812
DEBUG - 2022-07-29 21:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:24:52 --> Total execution time: 0.1135
DEBUG - 2022-07-29 21:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:25:27 --> Total execution time: 0.0464
DEBUG - 2022-07-29 21:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:25:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 21:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:25:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 21:25:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 21:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:25:47 --> Total execution time: 0.0762
DEBUG - 2022-07-29 21:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:25:47 --> Total execution time: 0.1552
DEBUG - 2022-07-29 21:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:31:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 21:31:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 21:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:35:23 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:36:03 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:37:13 --> Total execution time: 0.0988
DEBUG - 2022-07-29 21:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:37:14 --> Total execution time: 0.0709
DEBUG - 2022-07-29 21:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:37:14 --> Total execution time: 0.1438
DEBUG - 2022-07-29 21:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:37:27 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:37:27 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:37:32 --> Total execution time: 0.1002
DEBUG - 2022-07-29 21:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:37:33 --> Total execution time: 0.0691
DEBUG - 2022-07-29 21:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:37:33 --> Total execution time: 0.1169
DEBUG - 2022-07-29 21:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:38:56 --> Total execution time: 0.0665
DEBUG - 2022-07-29 21:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:39:01 --> Total execution time: 0.1118
DEBUG - 2022-07-29 21:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:39:02 --> Total execution time: 0.0692
DEBUG - 2022-07-29 21:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:39:02 --> Total execution time: 0.1331
DEBUG - 2022-07-29 21:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:39:13 --> Total execution time: 0.0641
DEBUG - 2022-07-29 21:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:39:14 --> Total execution time: 0.0767
DEBUG - 2022-07-29 21:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:39:14 --> Total execution time: 0.1284
DEBUG - 2022-07-29 21:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:39:18 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:39:42 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:44:06 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:44:28 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:45:47 --> Total execution time: 0.0820
DEBUG - 2022-07-29 21:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:45:48 --> Total execution time: 0.0796
DEBUG - 2022-07-29 21:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:45:49 --> Total execution time: 0.1457
DEBUG - 2022-07-29 21:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:46:10 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:46:20 --> Total execution time: 0.0816
DEBUG - 2022-07-29 21:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:46:21 --> Total execution time: 0.0755
DEBUG - 2022-07-29 21:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:46:21 --> Total execution time: 0.1309
DEBUG - 2022-07-29 21:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:46:26 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:46:53 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:54:40 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:57:43 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:57:43 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:58:08 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:59:03 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:59:45 --> No URI present. Default controller set.
DEBUG - 2022-07-29 21:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 21:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 21:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 21:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:00:08 --> No URI present. Default controller set.
DEBUG - 2022-07-29 22:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:00:26 --> Total execution time: 0.0771
DEBUG - 2022-07-29 22:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:00:27 --> Total execution time: 0.0685
DEBUG - 2022-07-29 22:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:00:27 --> Total execution time: 0.1439
DEBUG - 2022-07-29 22:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:00:57 --> No URI present. Default controller set.
DEBUG - 2022-07-29 22:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:17:16 --> No URI present. Default controller set.
DEBUG - 2022-07-29 22:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:17:26 --> Total execution time: 0.0650
DEBUG - 2022-07-29 22:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:17:28 --> Total execution time: 0.0765
DEBUG - 2022-07-29 22:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:17:28 --> Total execution time: 0.1732
DEBUG - 2022-07-29 22:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:17:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 22:17:41 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-29 22:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:20:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 22:20:53 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-29 22:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:20:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 22:20:56 --> 404 Page Not Found: Event/index
DEBUG - 2022-07-29 22:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:21:57 --> Total execution time: 0.2005
DEBUG - 2022-07-29 22:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:22:04 --> Total execution time: 0.1218
DEBUG - 2022-07-29 22:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:32:26 --> No URI present. Default controller set.
DEBUG - 2022-07-29 22:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 22:33:04 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-29 22:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 22:33:12 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-29 22:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 22:33:21 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-29 22:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:21 --> No URI present. Default controller set.
DEBUG - 2022-07-29 22:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:35 --> No URI present. Default controller set.
DEBUG - 2022-07-29 22:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:35:22 --> No URI present. Default controller set.
DEBUG - 2022-07-29 22:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:41:12 --> No URI present. Default controller set.
DEBUG - 2022-07-29 22:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:44:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 22:44:56 --> 404 Page Not Found: Wp-admin/admin-ajax.php
DEBUG - 2022-07-29 22:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:44:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 22:44:56 --> 404 Page Not Found: Wp-configphp/index
DEBUG - 2022-07-29 22:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:45:06 --> No URI present. Default controller set.
DEBUG - 2022-07-29 22:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:53:17 --> No URI present. Default controller set.
DEBUG - 2022-07-29 22:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:53:19 --> No URI present. Default controller set.
DEBUG - 2022-07-29 22:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:58:52 --> No URI present. Default controller set.
DEBUG - 2022-07-29 22:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 22:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 22:59:23 --> No URI present. Default controller set.
DEBUG - 2022-07-29 22:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 22:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:02:51 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:03:30 --> Total execution time: 0.0693
DEBUG - 2022-07-29 23:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:03:32 --> Total execution time: 0.0662
DEBUG - 2022-07-29 23:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:03:32 --> Total execution time: 0.1574
DEBUG - 2022-07-29 23:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:06:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 23:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:06:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 23:06:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 23:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:06:29 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:06:48 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:11:28 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:13:29 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:23:47 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:24:32 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:26:23 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:26:39 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:26:56 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:26:56 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:27:05 --> Total execution time: 0.0627
DEBUG - 2022-07-29 23:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:27:06 --> Total execution time: 0.0821
DEBUG - 2022-07-29 23:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:27:07 --> Total execution time: 0.1611
DEBUG - 2022-07-29 23:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:28:28 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:28:51 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:28:52 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:29:39 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:29:56 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:29:58 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:30:13 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:30:33 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:31:01 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:31:11 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:32:48 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:32:59 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:34:46 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:34:47 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:38:34 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:40:37 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:45:46 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:46:11 --> Total execution time: 0.0664
DEBUG - 2022-07-29 23:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:46:12 --> Total execution time: 0.0995
DEBUG - 2022-07-29 23:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:46:12 --> Total execution time: 0.1245
DEBUG - 2022-07-29 23:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:46:53 --> Total execution time: 0.0802
DEBUG - 2022-07-29 23:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:47:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-29 23:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:47:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-29 23:47:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-29 23:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:53:19 --> Total execution time: 0.0710
DEBUG - 2022-07-29 23:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:53:28 --> Total execution time: 0.0734
DEBUG - 2022-07-29 23:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:53:38 --> Total execution time: 0.0922
DEBUG - 2022-07-29 23:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:55:45 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:55:47 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:56:13 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:56:20 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:56:45 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:56:52 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-29 23:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-29 23:59:07 --> No URI present. Default controller set.
DEBUG - 2022-07-29 23:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-29 23:59:07 --> Encryption: Auto-configured driver 'openssl'.
