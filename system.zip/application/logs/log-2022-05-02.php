<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-02 07:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 07:47:38 --> No URI present. Default controller set.
DEBUG - 2022-05-02 07:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 07:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 13:17:39 --> Total execution time: 1.4691
DEBUG - 2022-05-02 07:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 07:48:55 --> No URI present. Default controller set.
DEBUG - 2022-05-02 07:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 07:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 13:18:55 --> Total execution time: 0.8332
DEBUG - 2022-05-02 07:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 07:56:32 --> No URI present. Default controller set.
DEBUG - 2022-05-02 07:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 07:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 13:26:33 --> Total execution time: 1.0201
DEBUG - 2022-05-02 07:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 07:58:25 --> No URI present. Default controller set.
DEBUG - 2022-05-02 07:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 07:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 13:28:26 --> Total execution time: 0.8361
DEBUG - 2022-05-02 07:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 07:58:49 --> No URI present. Default controller set.
DEBUG - 2022-05-02 07:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 07:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 13:28:50 --> Total execution time: 0.8291
DEBUG - 2022-05-02 08:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 08:00:39 --> No URI present. Default controller set.
DEBUG - 2022-05-02 08:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 08:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 13:30:40 --> Total execution time: 0.9083
DEBUG - 2022-05-02 08:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 08:01:31 --> No URI present. Default controller set.
DEBUG - 2022-05-02 08:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 08:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 13:31:31 --> Total execution time: 0.4030
DEBUG - 2022-05-02 08:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 08:02:52 --> No URI present. Default controller set.
DEBUG - 2022-05-02 08:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 08:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 13:32:53 --> Total execution time: 0.7971
DEBUG - 2022-05-02 10:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 10:06:29 --> No URI present. Default controller set.
DEBUG - 2022-05-02 10:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 10:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 15:36:30 --> Total execution time: 0.9853
DEBUG - 2022-05-02 12:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 12:30:46 --> No URI present. Default controller set.
DEBUG - 2022-05-02 12:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 12:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:00:47 --> Total execution time: 1.0434
DEBUG - 2022-05-02 12:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 12:32:05 --> No URI present. Default controller set.
DEBUG - 2022-05-02 12:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 12:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:02:05 --> Total execution time: 0.0401
DEBUG - 2022-05-02 12:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 12:36:48 --> No URI present. Default controller set.
DEBUG - 2022-05-02 12:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 12:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:06:49 --> Total execution time: 0.8051
DEBUG - 2022-05-02 12:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 12:38:52 --> No URI present. Default controller set.
DEBUG - 2022-05-02 12:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 12:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:08:52 --> Total execution time: 0.0327
DEBUG - 2022-05-02 12:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 12:43:41 --> No URI present. Default controller set.
DEBUG - 2022-05-02 12:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 12:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:13:42 --> Total execution time: 0.7661
DEBUG - 2022-05-02 12:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 12:45:25 --> No URI present. Default controller set.
DEBUG - 2022-05-02 12:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 12:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:15:25 --> Total execution time: 0.0325
DEBUG - 2022-05-02 12:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 12:48:29 --> No URI present. Default controller set.
DEBUG - 2022-05-02 12:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 12:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:18:29 --> Total execution time: 0.0352
DEBUG - 2022-05-02 12:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 12:50:07 --> No URI present. Default controller set.
DEBUG - 2022-05-02 12:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 12:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:20:08 --> Total execution time: 0.8321
DEBUG - 2022-05-02 12:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 12:54:44 --> No URI present. Default controller set.
DEBUG - 2022-05-02 12:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 12:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:24:44 --> Total execution time: 0.8051
DEBUG - 2022-05-02 12:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 12:55:14 --> No URI present. Default controller set.
DEBUG - 2022-05-02 12:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 12:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:25:15 --> Total execution time: 0.5940
DEBUG - 2022-05-02 12:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 12:58:21 --> No URI present. Default controller set.
DEBUG - 2022-05-02 12:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 12:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:28:22 --> Total execution time: 0.8991
DEBUG - 2022-05-02 13:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:02:52 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:32:53 --> Total execution time: 0.8151
DEBUG - 2022-05-02 13:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:03:26 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:33:27 --> Total execution time: 1.1972
DEBUG - 2022-05-02 13:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:04:10 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:34:11 --> Total execution time: 0.8321
DEBUG - 2022-05-02 13:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:08:04 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:38:05 --> Total execution time: 0.8561
DEBUG - 2022-05-02 13:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:08:34 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:38:34 --> Total execution time: 0.0560
DEBUG - 2022-05-02 13:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:09:59 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:40:00 --> Total execution time: 0.8908
DEBUG - 2022-05-02 13:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:18:26 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:48:27 --> Total execution time: 1.0863
DEBUG - 2022-05-02 13:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:18:52 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:48:52 --> Total execution time: 0.2719
DEBUG - 2022-05-02 13:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:22:35 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:52:36 --> Total execution time: 0.9521
DEBUG - 2022-05-02 13:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:23:18 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:53:19 --> Total execution time: 0.8364
DEBUG - 2022-05-02 13:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:24:03 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:54:03 --> Total execution time: 0.8051
DEBUG - 2022-05-02 13:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:25:35 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:55:36 --> Total execution time: 0.8589
DEBUG - 2022-05-02 13:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:27:10 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:57:11 --> Total execution time: 0.8331
DEBUG - 2022-05-02 13:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:31:24 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:01:25 --> Total execution time: 0.8791
DEBUG - 2022-05-02 13:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:34:59 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:05:00 --> Total execution time: 0.8051
DEBUG - 2022-05-02 13:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:35:27 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:05:27 --> Total execution time: 0.0300
DEBUG - 2022-05-02 13:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:39:59 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:10:00 --> Total execution time: 0.8051
DEBUG - 2022-05-02 13:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:43:42 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:13:43 --> Total execution time: 0.8062
DEBUG - 2022-05-02 13:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:45:04 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:15:04 --> Total execution time: 0.0637
DEBUG - 2022-05-02 13:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:15:28 --> Total execution time: 0.0334
DEBUG - 2022-05-02 13:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:47:00 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:17:00 --> Total execution time: 0.0313
DEBUG - 2022-05-02 13:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:47:34 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:17:34 --> Total execution time: 0.0297
DEBUG - 2022-05-02 13:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:48:20 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:18:20 --> Total execution time: 0.0311
DEBUG - 2022-05-02 13:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 13:48:55 --> No URI present. Default controller set.
DEBUG - 2022-05-02 13:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 13:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:18:55 --> Total execution time: 0.0310
DEBUG - 2022-05-02 14:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:00:40 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:30:41 --> Total execution time: 0.9921
DEBUG - 2022-05-02 14:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:05:25 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:35:25 --> Total execution time: 0.8211
DEBUG - 2022-05-02 14:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:06:25 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:36:25 --> Total execution time: 0.0352
DEBUG - 2022-05-02 14:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:07:10 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:37:10 --> Total execution time: 0.0316
DEBUG - 2022-05-02 14:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:08:17 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:38:17 --> Total execution time: 0.0302
DEBUG - 2022-05-02 14:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:13:43 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:43:43 --> Total execution time: 0.8401
DEBUG - 2022-05-02 14:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:14:43 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:44:43 --> Total execution time: 0.0331
DEBUG - 2022-05-02 14:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:16:01 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:46:01 --> Total execution time: 0.0310
DEBUG - 2022-05-02 14:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:16:39 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:46:39 --> Total execution time: 0.0297
DEBUG - 2022-05-02 14:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:17:12 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:47:12 --> Total execution time: 0.0302
DEBUG - 2022-05-02 14:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:18:42 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:48:42 --> Total execution time: 0.0304
DEBUG - 2022-05-02 14:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:19:03 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:49:03 --> Total execution time: 0.0345
DEBUG - 2022-05-02 14:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:19:51 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:49:51 --> Total execution time: 0.0305
DEBUG - 2022-05-02 14:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:20:34 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:50:34 --> Total execution time: 0.0312
DEBUG - 2022-05-02 14:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:22:23 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:52:23 --> Total execution time: 0.0318
DEBUG - 2022-05-02 14:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:22:43 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:52:43 --> Total execution time: 0.0302
DEBUG - 2022-05-02 14:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:26:49 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:56:49 --> Total execution time: 0.0341
DEBUG - 2022-05-02 14:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:28:00 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:58:00 --> Total execution time: 0.0306
DEBUG - 2022-05-02 14:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:29:34 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:59:34 --> Total execution time: 0.0306
DEBUG - 2022-05-02 14:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:30:49 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:00:49 --> Total execution time: 0.0373
DEBUG - 2022-05-02 14:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:31:09 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:01:09 --> Total execution time: 0.0329
DEBUG - 2022-05-02 14:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:31:28 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:01:28 --> Total execution time: 0.0352
DEBUG - 2022-05-02 14:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:33:15 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:03:15 --> Total execution time: 0.0310
DEBUG - 2022-05-02 14:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:33:47 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:03:47 --> Total execution time: 0.0320
DEBUG - 2022-05-02 14:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:36:29 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:06:29 --> Total execution time: 0.0334
DEBUG - 2022-05-02 14:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:37:01 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:07:01 --> Total execution time: 0.0310
DEBUG - 2022-05-02 14:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:37:30 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:07:30 --> Total execution time: 0.0298
DEBUG - 2022-05-02 14:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:38:21 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:08:21 --> Total execution time: 0.7671
DEBUG - 2022-05-02 14:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:39:32 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:09:32 --> Total execution time: 0.0307
DEBUG - 2022-05-02 14:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:40:37 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:10:37 --> Total execution time: 0.0371
DEBUG - 2022-05-02 14:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:48:19 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:18:20 --> Total execution time: 0.8802
DEBUG - 2022-05-02 14:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:46 --> 404 Page Not Found: Assets/assets
DEBUG - 2022-05-02 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:55 --> 404 Page Not Found: Assets/assets
DEBUG - 2022-05-02 14:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:49:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:49:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:52:29 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:22:30 --> Total execution time: 0.6139
DEBUG - 2022-05-02 14:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:52:59 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:22:59 --> Total execution time: 0.0321
DEBUG - 2022-05-02 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:53:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:53:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:53:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-05-02 14:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 14:53:34 --> 404 Page Not Found: Assets/assets
DEBUG - 2022-05-02 14:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:54:05 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:24:06 --> Total execution time: 0.6148
DEBUG - 2022-05-02 14:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:54:20 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:24:20 --> Total execution time: 0.0306
DEBUG - 2022-05-02 14:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 14:56:01 --> No URI present. Default controller set.
DEBUG - 2022-05-02 14:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 14:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:26:01 --> Total execution time: 0.0311
DEBUG - 2022-05-02 15:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:03:55 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:33:56 --> Total execution time: 0.8311
DEBUG - 2022-05-02 15:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:04:23 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:34:23 --> Total execution time: 0.0350
DEBUG - 2022-05-02 15:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:04:38 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:34:38 --> Total execution time: 0.0342
DEBUG - 2022-05-02 15:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:05:18 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:35:18 --> Total execution time: 0.0319
DEBUG - 2022-05-02 15:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:07:51 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:37:52 --> Total execution time: 0.8291
DEBUG - 2022-05-02 15:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:08:30 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:38:30 --> Total execution time: 0.0301
DEBUG - 2022-05-02 15:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:08:58 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:38:58 --> Total execution time: 0.0342
DEBUG - 2022-05-02 15:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:10:14 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:40:15 --> Total execution time: 0.0347
DEBUG - 2022-05-02 15:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:11:21 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:41:21 --> Total execution time: 0.0316
DEBUG - 2022-05-02 15:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:26:11 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:56:12 --> Total execution time: 0.8291
DEBUG - 2022-05-02 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:28:33 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:58:33 --> Total execution time: 0.0315
DEBUG - 2022-05-02 15:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:29:44 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:59:44 --> Total execution time: 0.0305
DEBUG - 2022-05-02 15:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:31:03 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:01:03 --> Total execution time: 0.2180
DEBUG - 2022-05-02 15:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:31:33 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:01:33 --> Total execution time: 0.0319
DEBUG - 2022-05-02 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:32:24 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:02:24 --> Total execution time: 0.0310
DEBUG - 2022-05-02 15:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:33:18 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:03:18 --> Total execution time: 0.0333
DEBUG - 2022-05-02 15:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:35:12 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:05:13 --> Total execution time: 0.7421
DEBUG - 2022-05-02 15:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:35:48 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:05:48 --> Total execution time: 0.0315
DEBUG - 2022-05-02 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:37:05 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:07:05 --> Total execution time: 0.8715
DEBUG - 2022-05-02 15:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 15:38:00 --> No URI present. Default controller set.
DEBUG - 2022-05-02 15:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 15:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:08:00 --> Total execution time: 0.7582
DEBUG - 2022-05-02 16:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:04:47 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:34:48 --> Total execution time: 1.2302
DEBUG - 2022-05-02 16:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:05:27 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:35:28 --> Total execution time: 0.8442
DEBUG - 2022-05-02 16:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:06:31 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:36:32 --> Total execution time: 0.8241
DEBUG - 2022-05-02 16:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:07:08 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:37:09 --> Total execution time: 0.8251
DEBUG - 2022-05-02 16:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:07:21 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:37:21 --> Total execution time: 0.4844
DEBUG - 2022-05-02 16:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:07:24 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:37:24 --> Total execution time: 0.0313
DEBUG - 2022-05-02 16:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 16:08:47 --> Total execution time: 0.8924
DEBUG - 2022-05-02 16:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 16:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:39:10 --> Total execution time: 0.2057
DEBUG - 2022-05-02 16:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:39:46 --> Total execution time: 0.0534
DEBUG - 2022-05-02 16:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:41:47 --> Total execution time: 0.8321
DEBUG - 2022-05-02 16:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:41:54 --> Total execution time: 0.0376
DEBUG - 2022-05-02 16:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:42:00 --> Total execution time: 0.0700
DEBUG - 2022-05-02 16:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:44:18 --> Total execution time: 0.9382
DEBUG - 2022-05-02 16:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:45:31 --> Total execution time: 1.0939
DEBUG - 2022-05-02 16:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:15:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:15:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:15:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:15:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:15:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:15:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:15:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:15:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:15:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:15:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:15:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:15:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:15:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:15:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:48:00 --> Total execution time: 0.0320
DEBUG - 2022-05-02 16:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:18:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:18:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-02 16:18:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-02 16:18:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:18:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:18:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:18:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:18:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-02 16:18:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:18:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:18:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:18:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:18:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:48:21 --> Total execution time: 0.0299
DEBUG - 2022-05-02 16:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:19:07 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:49:07 --> Total execution time: 0.0600
DEBUG - 2022-05-02 16:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:49:13 --> Total execution time: 0.0303
DEBUG - 2022-05-02 16:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:19:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:19:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:19:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:19:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:19:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:19:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:19:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:19:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:19:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:19:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:19:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:19:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:19:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:19:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:19:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-02 16:19:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-02 16:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:49:50 --> Total execution time: 0.0297
DEBUG - 2022-05-02 16:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 16:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:50:29 --> Total execution time: 0.0310
DEBUG - 2022-05-02 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:20:35 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:50:35 --> Total execution time: 0.0309
DEBUG - 2022-05-02 16:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:21:19 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:51:19 --> Total execution time: 0.0357
DEBUG - 2022-05-02 16:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:21:47 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:51:47 --> Total execution time: 0.0379
DEBUG - 2022-05-02 16:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:52:03 --> Total execution time: 0.0476
DEBUG - 2022-05-02 16:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:53:10 --> Total execution time: 0.0366
DEBUG - 2022-05-02 16:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:53:17 --> Total execution time: 0.0626
DEBUG - 2022-05-02 16:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 16:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:53:47 --> Total execution time: 0.0316
DEBUG - 2022-05-02 16:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:53:49 --> Total execution time: 0.0317
DEBUG - 2022-05-02 16:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:54:17 --> Total execution time: 0.0431
DEBUG - 2022-05-02 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:54:19 --> Total execution time: 0.0324
DEBUG - 2022-05-02 16:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 16:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:54:46 --> Total execution time: 0.0323
DEBUG - 2022-05-02 16:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:24:49 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:54:49 --> Total execution time: 0.0729
DEBUG - 2022-05-02 16:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:26:26 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:56:26 --> Total execution time: 0.0304
DEBUG - 2022-05-02 16:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:26:53 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:56:53 --> Total execution time: 0.0961
DEBUG - 2022-05-02 16:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:27:39 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:57:39 --> Total execution time: 0.0323
DEBUG - 2022-05-02 16:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 16:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:58:24 --> Total execution time: 0.0311
DEBUG - 2022-05-02 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:28:30 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:58:30 --> Total execution time: 0.0307
DEBUG - 2022-05-02 16:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:30:21 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:00:21 --> Total execution time: 0.0801
DEBUG - 2022-05-02 16:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:32:19 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:02:19 --> Total execution time: 0.0334
DEBUG - 2022-05-02 16:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:33:50 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:03:50 --> Total execution time: 0.0325
DEBUG - 2022-05-02 16:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:33:59 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:03:59 --> Total execution time: 0.0356
DEBUG - 2022-05-02 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:34:12 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:04:12 --> Total execution time: 0.0305
DEBUG - 2022-05-02 16:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:35:07 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:05:07 --> Total execution time: 0.0316
DEBUG - 2022-05-02 16:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:35:50 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:05:50 --> Total execution time: 0.0303
DEBUG - 2022-05-02 16:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:36:07 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:06:07 --> Total execution time: 0.0311
DEBUG - 2022-05-02 16:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:51:46 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:21:47 --> Total execution time: 0.9222
DEBUG - 2022-05-02 16:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:52:30 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:22:30 --> Total execution time: 0.0316
DEBUG - 2022-05-02 16:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:53:48 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:23:48 --> Total execution time: 0.0317
DEBUG - 2022-05-02 16:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:54:11 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:24:11 --> Total execution time: 0.0315
DEBUG - 2022-05-02 16:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:55:33 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:25:33 --> Total execution time: 0.0321
DEBUG - 2022-05-02 16:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:56:44 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:26:44 --> Total execution time: 0.0304
DEBUG - 2022-05-02 16:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:57:29 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:27:30 --> Total execution time: 0.5503
DEBUG - 2022-05-02 16:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:57:44 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:27:44 --> Total execution time: 0.0309
DEBUG - 2022-05-02 16:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 16:59:13 --> No URI present. Default controller set.
DEBUG - 2022-05-02 16:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 16:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:29:13 --> Total execution time: 0.0305
DEBUG - 2022-05-02 17:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 17:01:26 --> No URI present. Default controller set.
DEBUG - 2022-05-02 17:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 17:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:31:26 --> Total execution time: 0.5492
DEBUG - 2022-05-02 17:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 17:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 17:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:32:39 --> Total execution time: 0.0967
DEBUG - 2022-05-02 17:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 17:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 17:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 17:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 17:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 17:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:32:54 --> Total execution time: 0.0307
DEBUG - 2022-05-02 17:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 17:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 17:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:33:08 --> Total execution time: 0.0317
DEBUG - 2022-05-02 17:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 17:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 17:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 17:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 17:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 17:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:33:22 --> Total execution time: 0.0297
DEBUG - 2022-05-02 17:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 17:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 17:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:33:31 --> Total execution time: 0.0307
DEBUG - 2022-05-02 17:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 17:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 17:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 17:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 17:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 17:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:33:45 --> Total execution time: 0.0307
DEBUG - 2022-05-02 17:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 17:03:49 --> No URI present. Default controller set.
DEBUG - 2022-05-02 17:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 17:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:33:49 --> Total execution time: 0.0327
DEBUG - 2022-05-02 17:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 17:04:34 --> No URI present. Default controller set.
DEBUG - 2022-05-02 17:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 17:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 22:34:35 --> Total execution time: 0.8051
DEBUG - 2022-05-02 17:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 17:51:45 --> No URI present. Default controller set.
DEBUG - 2022-05-02 17:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 17:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:21:46 --> Total execution time: 1.1413
DEBUG - 2022-05-02 17:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 17:51:52 --> No URI present. Default controller set.
DEBUG - 2022-05-02 17:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 17:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:21:52 --> Total execution time: 0.0301
DEBUG - 2022-05-02 18:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:44:59 --> Total execution time: 0.8598
DEBUG - 2022-05-02 18:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:45:16 --> Total execution time: 0.1113
DEBUG - 2022-05-02 18:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:45:34 --> Total execution time: 0.0526
DEBUG - 2022-05-02 18:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:45:38 --> Total execution time: 0.0305
DEBUG - 2022-05-02 18:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:45:45 --> Total execution time: 0.0428
DEBUG - 2022-05-02 18:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:46:14 --> Total execution time: 0.8091
DEBUG - 2022-05-02 18:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:46:20 --> Total execution time: 0.0342
DEBUG - 2022-05-02 18:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:46:30 --> Total execution time: 0.1304
DEBUG - 2022-05-02 18:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:46:47 --> Total execution time: 0.0506
DEBUG - 2022-05-02 18:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:46:56 --> Total execution time: 0.0312
DEBUG - 2022-05-02 18:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:47:04 --> Total execution time: 0.0490
DEBUG - 2022-05-02 18:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:17:56 --> Total execution time: 0.0503
DEBUG - 2022-05-02 18:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:50:43 --> Total execution time: 0.8911
DEBUG - 2022-05-02 18:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:50:43 --> Total execution time: 0.0536
DEBUG - 2022-05-02 18:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:51:07 --> Total execution time: 0.8361
DEBUG - 2022-05-02 18:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:51:31 --> Total execution time: 0.8253
DEBUG - 2022-05-02 18:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:51:43 --> Total execution time: 0.6692
DEBUG - 2022-05-02 18:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:52:05 --> Total execution time: 0.8211
DEBUG - 2022-05-02 18:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:52:12 --> Total execution time: 0.0839
DEBUG - 2022-05-02 18:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:52:23 --> Total execution time: 0.0501
DEBUG - 2022-05-02 18:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:22:39 --> No URI present. Default controller set.
DEBUG - 2022-05-02 18:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:52:40 --> Total execution time: 0.8351
DEBUG - 2022-05-02 18:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:14 --> No URI present. Default controller set.
DEBUG - 2022-05-02 18:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:53:15 --> Total execution time: 0.8251
DEBUG - 2022-05-02 18:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:23:25 --> Total execution time: 0.6678
DEBUG - 2022-05-02 18:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:23:27 --> Total execution time: 0.0834
DEBUG - 2022-05-02 18:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:23:27 --> Total execution time: 0.0430
DEBUG - 2022-05-02 18:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:28 --> No URI present. Default controller set.
DEBUG - 2022-05-02 18:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:53:28 --> Total execution time: 0.0333
DEBUG - 2022-05-02 18:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:23:30 --> Total execution time: 0.0317
DEBUG - 2022-05-02 18:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:23:32 --> Total execution time: 0.0301
DEBUG - 2022-05-02 18:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:23:32 --> Total execution time: 0.0336
DEBUG - 2022-05-02 18:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:23:38 --> Total execution time: 0.0293
DEBUG - 2022-05-02 18:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:23:39 --> Total execution time: 0.0312
DEBUG - 2022-05-02 18:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:23:40 --> Total execution time: 0.0311
DEBUG - 2022-05-02 18:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:23:40 --> Total execution time: 0.0298
DEBUG - 2022-05-02 18:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:23:40 --> Total execution time: 0.0290
DEBUG - 2022-05-02 18:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:23:41 --> Total execution time: 0.0371
DEBUG - 2022-05-02 18:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:23:41 --> Total execution time: 0.0306
DEBUG - 2022-05-02 18:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:24:47 --> No URI present. Default controller set.
DEBUG - 2022-05-02 18:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:54:48 --> Total execution time: 0.8251
DEBUG - 2022-05-02 18:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:26:11 --> Total execution time: 0.0456
DEBUG - 2022-05-02 18:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:26:12 --> Total execution time: 0.0843
DEBUG - 2022-05-02 18:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 18:26:12 --> Total execution time: 0.0300
DEBUG - 2022-05-02 18:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 18:27:49 --> No URI present. Default controller set.
DEBUG - 2022-05-02 18:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 18:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 23:57:49 --> Total execution time: 0.0662
DEBUG - 2022-05-02 19:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 19:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 19:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 19:29:32 --> No URI present. Default controller set.
DEBUG - 2022-05-02 19:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 19:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 19:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 19:30:42 --> No URI present. Default controller set.
DEBUG - 2022-05-02 19:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 19:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 20:42:42 --> No URI present. Default controller set.
DEBUG - 2022-05-02 20:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 20:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 20:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 20:45:10 --> No URI present. Default controller set.
DEBUG - 2022-05-02 20:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 20:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-02 21:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-02 21:00:45 --> No URI present. Default controller set.
DEBUG - 2022-05-02 21:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-02 21:00:46 --> Encryption: Auto-configured driver 'openssl'.
