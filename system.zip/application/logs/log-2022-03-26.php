<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-26 17:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:30:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-26 17:30:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\personal\jaal\application\core\DB_Controller.php 28
DEBUG - 2022-03-26 17:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 17:30:24 --> Total execution time: 0.0851
DEBUG - 2022-03-26 17:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 17:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:00:26 --> Total execution time: 0.0998
DEBUG - 2022-03-26 17:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:30:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-26 22:00:30 --> Severity: error --> Exception: Call to undefined method CI_Loader::encryption() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 77
DEBUG - 2022-03-26 17:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:00:36 --> Total execution time: 0.0983
DEBUG - 2022-03-26 17:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:00:41 --> Total execution time: 0.0696
DEBUG - 2022-03-26 17:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:00:53 --> Total execution time: 0.0571
DEBUG - 2022-03-26 17:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:30:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-26 22:00:54 --> Severity: error --> Exception: Call to undefined method CI_Loader::encryption() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 77
DEBUG - 2022-03-26 17:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:30:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-26 22:00:59 --> Severity: error --> Exception: Call to undefined method CI_Loader::encryption() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 77
DEBUG - 2022-03-26 17:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:32:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-26 22:02:05 --> Severity: error --> Exception: Call to undefined method CI_Loader::encryption() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 77
DEBUG - 2022-03-26 17:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:32:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-26 22:02:38 --> Severity: error --> Exception: Call to undefined method CI_Loader::encryption() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 77
DEBUG - 2022-03-26 17:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:32:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-26 22:02:50 --> Severity: error --> Exception: Call to undefined method CI_Loader::encryption() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 77
DEBUG - 2022-03-26 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:33:12 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 17:33:12 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 17:33:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:33:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-26 22:03:14 --> Severity: error --> Exception: Call to undefined method CI_Loader::encryption() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 77
DEBUG - 2022-03-26 17:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:33:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:33:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:33:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:33:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:33:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:33:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:33:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-26 22:03:46 --> Severity: error --> Exception: Call to undefined method CI_Loader::encryption() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 77
DEBUG - 2022-03-26 17:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:04:20 --> Total execution time: 0.0821
DEBUG - 2022-03-26 17:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:04:22 --> Total execution time: 0.0777
DEBUG - 2022-03-26 17:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:34:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 17:34:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:34:23 --> UTF-8 Support Enabled
ERROR - 2022-03-26 17:34:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:04:34 --> Total execution time: 0.0842
DEBUG - 2022-03-26 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:34:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:34 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 17:34:34 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 17:34:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:34:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:34 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 17:34:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:34:34 --> UTF-8 Support Enabled
ERROR - 2022-03-26 17:34:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:04:38 --> Total execution time: 0.0651
DEBUG - 2022-03-26 17:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 17:34:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 17:34:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:34:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:04:52 --> Total execution time: 0.0508
DEBUG - 2022-03-26 17:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:04:53 --> Total execution time: 0.0687
DEBUG - 2022-03-26 17:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:09:42 --> Total execution time: 0.0605
DEBUG - 2022-03-26 17:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:39:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:39:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 17:39:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:39:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:39:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:39:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:39:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:39:42 --> UTF-8 Support Enabled
ERROR - 2022-03-26 17:39:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:39:42 --> UTF-8 Support Enabled
ERROR - 2022-03-26 17:39:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:39:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:39:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:39:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:39:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:10:12 --> Total execution time: 0.0512
DEBUG - 2022-03-26 17:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:10:15 --> Total execution time: 0.0446
DEBUG - 2022-03-26 17:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:10:20 --> Total execution time: 0.0488
DEBUG - 2022-03-26 17:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:47:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:47:37 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\personal\jaal\application\controllers\Admin\Collection_Controller.php 46
DEBUG - 2022-03-26 17:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:18:08 --> Total execution time: 0.0717
DEBUG - 2022-03-26 17:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:18:12 --> Total execution time: 0.0589
DEBUG - 2022-03-26 17:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:48:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-26 22:18:17 --> Query error: Column 'rent_type' cannot be null - Invalid query: INSERT INTO `rents` (`rent_FK_client_id`, `rent_type`, `rent_name`, `rent_phone`, `rent_address`, `rent_hand`, `rent_day`, `rent_amount`, `rent_date`) VALUES ('3', NULL, 'Barman Dinesh', '09091982795', 'Gopinathpur', '200', '2', 400, '2022-03-26')
DEBUG - 2022-03-26 17:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:19:00 --> Total execution time: 0.0679
DEBUG - 2022-03-26 17:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:19:04 --> Total execution time: 0.0500
DEBUG - 2022-03-26 17:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 17:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:19:08 --> Total execution time: 0.0487
DEBUG - 2022-03-26 17:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:19:26 --> Total execution time: 0.0529
DEBUG - 2022-03-26 17:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:19:30 --> Total execution time: 0.0453
DEBUG - 2022-03-26 17:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 17:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:19:35 --> Total execution time: 0.0513
DEBUG - 2022-03-26 17:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:19:57 --> Total execution time: 0.0519
DEBUG - 2022-03-26 17:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:25:01 --> Total execution time: 0.0798
DEBUG - 2022-03-26 17:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:25:24 --> Total execution time: 0.0986
DEBUG - 2022-03-26 17:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:25:47 --> Total execution time: 0.0538
DEBUG - 2022-03-26 17:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:26:28 --> Total execution time: 0.0723
DEBUG - 2022-03-26 17:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:26:54 --> Total execution time: 0.0733
DEBUG - 2022-03-26 17:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:26:56 --> Total execution time: 0.0518
DEBUG - 2022-03-26 17:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:26:57 --> Total execution time: 0.0551
DEBUG - 2022-03-26 17:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:27:01 --> Total execution time: 0.0759
DEBUG - 2022-03-26 17:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:27:57 --> Total execution time: 0.1021
DEBUG - 2022-03-26 17:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:58:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:58:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:58:13 --> UTF-8 Support Enabled
ERROR - 2022-03-26 17:58:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:58:13 --> UTF-8 Support Enabled
ERROR - 2022-03-26 17:58:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:58:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:58:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:58:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:58:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:58:13 --> UTF-8 Support Enabled
ERROR - 2022-03-26 17:58:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:58:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:58:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:58:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:58:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:28:34 --> Total execution time: 0.0709
DEBUG - 2022-03-26 17:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:28:45 --> Total execution time: 0.0558
DEBUG - 2022-03-26 17:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:28:57 --> Total execution time: 0.0860
DEBUG - 2022-03-26 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:59:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 17:59:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:59:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 17:59:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:59:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:59:06 --> UTF-8 Support Enabled
ERROR - 2022-03-26 17:59:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 17:59:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:59:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:29:24 --> Total execution time: 0.0650
DEBUG - 2022-03-26 17:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:59:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:59:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:59:24 --> UTF-8 Support Enabled
ERROR - 2022-03-26 17:59:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:59:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:59:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:59:24 --> UTF-8 Support Enabled
ERROR - 2022-03-26 17:59:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:59:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:59:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 17:59:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:59:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 17:59:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 17:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 17:59:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 17:59:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:30:10 --> Total execution time: 0.0571
DEBUG - 2022-03-26 18:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:30:15 --> Total execution time: 0.0901
DEBUG - 2022-03-26 18:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:30:24 --> Total execution time: 0.0597
DEBUG - 2022-03-26 18:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:30:34 --> Total execution time: 0.0703
DEBUG - 2022-03-26 18:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:31:15 --> Total execution time: 0.0724
DEBUG - 2022-03-26 18:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:35:06 --> Total execution time: 0.0763
DEBUG - 2022-03-26 18:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 18:05:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 18:05:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 18:05:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 18:05:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 18:05:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 18:05:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 18:05:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 18:05:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:35:32 --> Total execution time: 0.0775
DEBUG - 2022-03-26 18:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 18:05:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 18:05:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 18:05:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 18:05:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:33 --> UTF-8 Support Enabled
ERROR - 2022-03-26 18:05:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:33 --> UTF-8 Support Enabled
ERROR - 2022-03-26 18:05:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 18:05:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 18:05:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:35:37 --> Total execution time: 0.0534
DEBUG - 2022-03-26 18:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:35:38 --> Total execution time: 0.0679
DEBUG - 2022-03-26 18:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 18:05:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:38 --> UTF-8 Support Enabled
ERROR - 2022-03-26 18:05:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 18:05:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 18:05:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 18:05:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 18:05:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-26 18:05:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 18:05:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-26 18:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:35:42 --> Total execution time: 0.0461
DEBUG - 2022-03-26 18:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 18:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:35:47 --> Total execution time: 0.0500
DEBUG - 2022-03-26 18:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:36:27 --> Total execution time: 0.0766
DEBUG - 2022-03-26 18:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 18:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 18:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-26 22:36:31 --> Total execution time: 0.0542
