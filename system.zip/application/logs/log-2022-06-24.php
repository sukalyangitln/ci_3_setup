<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-06-24 00:00:05 --> Total execution time: 0.1540
DEBUG - 2022-06-24 00:00:10 --> Total execution time: 0.1232
DEBUG - 2022-06-24 00:00:12 --> Total execution time: 0.1420
DEBUG - 2022-06-24 00:00:51 --> Total execution time: 0.0305
DEBUG - 2022-06-24 00:01:25 --> Total execution time: 0.0401
DEBUG - 2022-06-24 00:04:19 --> Total execution time: 0.0509
DEBUG - 2022-06-24 00:09:37 --> Total execution time: 0.0829
DEBUG - 2022-06-24 00:09:46 --> Total execution time: 0.0360
DEBUG - 2022-06-24 00:09:57 --> Total execution time: 0.0499
DEBUG - 2022-06-24 00:10:01 --> Total execution time: 0.0611
DEBUG - 2022-06-24 00:10:07 --> Total execution time: 0.0542
DEBUG - 2022-06-24 00:10:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 00:10:08 --> Total execution time: 0.0427
DEBUG - 2022-06-24 00:10:55 --> Total execution time: 0.0466
DEBUG - 2022-06-24 00:10:56 --> Total execution time: 0.0496
DEBUG - 2022-06-24 00:11:05 --> Total execution time: 0.0462
DEBUG - 2022-06-24 00:11:11 --> Total execution time: 0.0455
DEBUG - 2022-06-24 00:11:38 --> Total execution time: 0.0540
DEBUG - 2022-06-24 00:11:45 --> Total execution time: 0.0550
DEBUG - 2022-06-24 00:11:56 --> Total execution time: 0.0743
DEBUG - 2022-06-24 00:11:59 --> Total execution time: 0.0473
DEBUG - 2022-06-24 00:12:03 --> Total execution time: 0.0503
DEBUG - 2022-06-24 00:12:10 --> Total execution time: 0.0557
DEBUG - 2022-06-24 00:12:16 --> Total execution time: 0.0825
DEBUG - 2022-06-24 00:12:18 --> Total execution time: 0.0508
DEBUG - 2022-06-24 00:12:25 --> Total execution time: 0.0679
DEBUG - 2022-06-24 00:12:33 --> Total execution time: 0.0461
DEBUG - 2022-06-24 00:17:28 --> Total execution time: 0.1450
DEBUG - 2022-06-24 00:19:41 --> Total execution time: 0.0985
DEBUG - 2022-06-24 00:28:09 --> Total execution time: 0.1597
DEBUG - 2022-06-24 00:29:50 --> Total execution time: 0.0406
DEBUG - 2022-06-24 00:30:02 --> Total execution time: 0.1010
DEBUG - 2022-06-24 00:30:39 --> Total execution time: 0.0473
DEBUG - 2022-06-24 00:31:13 --> Total execution time: 0.0666
DEBUG - 2022-06-24 00:31:17 --> Total execution time: 0.0457
DEBUG - 2022-06-24 00:31:25 --> Total execution time: 0.1404
DEBUG - 2022-06-24 00:32:09 --> Total execution time: 0.0481
DEBUG - 2022-06-24 00:32:44 --> Total execution time: 0.0421
DEBUG - 2022-06-24 00:33:34 --> Total execution time: 0.0431
DEBUG - 2022-06-24 00:33:34 --> Total execution time: 0.0530
DEBUG - 2022-06-24 00:33:37 --> Total execution time: 0.0753
DEBUG - 2022-06-24 00:33:39 --> Total execution time: 0.1386
DEBUG - 2022-06-24 00:39:13 --> Total execution time: 0.1029
DEBUG - 2022-06-24 00:39:15 --> Total execution time: 0.0462
DEBUG - 2022-06-24 00:39:16 --> Total execution time: 0.0431
DEBUG - 2022-06-24 01:11:55 --> Total execution time: 0.1740
DEBUG - 2022-06-24 01:13:18 --> Total execution time: 0.0420
DEBUG - 2022-06-24 01:13:18 --> Total execution time: 0.0394
DEBUG - 2022-06-24 01:27:51 --> Total execution time: 0.0520
DEBUG - 2022-06-24 01:30:03 --> Total execution time: 0.1652
DEBUG - 2022-06-24 01:43:30 --> Total execution time: 0.1144
DEBUG - 2022-06-24 02:04:45 --> Total execution time: 0.1631
DEBUG - 2022-06-24 02:04:45 --> Total execution time: 0.0428
DEBUG - 2022-06-24 02:05:59 --> Total execution time: 0.0463
DEBUG - 2022-06-24 02:30:03 --> Total execution time: 0.2693
DEBUG - 2022-06-24 02:49:24 --> Total execution time: 0.1871
DEBUG - 2022-06-24 02:49:34 --> Total execution time: 0.0727
DEBUG - 2022-06-24 02:49:38 --> Total execution time: 0.0853
DEBUG - 2022-06-24 02:49:44 --> Total execution time: 0.0618
DEBUG - 2022-06-24 02:49:45 --> Total execution time: 0.0642
DEBUG - 2022-06-24 03:30:04 --> Total execution time: 0.2635
DEBUG - 2022-06-24 04:02:11 --> Total execution time: 0.1116
DEBUG - 2022-06-24 04:29:20 --> Total execution time: 0.1338
DEBUG - 2022-06-24 04:29:20 --> Total execution time: 0.0282
DEBUG - 2022-06-24 04:30:02 --> Total execution time: 0.0802
DEBUG - 2022-06-24 04:34:32 --> Total execution time: 0.0858
DEBUG - 2022-06-24 04:54:08 --> Total execution time: 0.1175
DEBUG - 2022-06-24 04:57:44 --> Total execution time: 0.1420
DEBUG - 2022-06-24 05:21:50 --> Total execution time: 0.1696
DEBUG - 2022-06-24 05:30:02 --> Total execution time: 0.1716
DEBUG - 2022-06-24 05:44:27 --> Total execution time: 0.1164
DEBUG - 2022-06-24 06:30:02 --> Total execution time: 0.2298
DEBUG - 2022-06-24 07:00:00 --> Total execution time: 0.2081
DEBUG - 2022-06-24 07:00:26 --> Total execution time: 0.0349
DEBUG - 2022-06-24 07:00:35 --> Total execution time: 0.0800
DEBUG - 2022-06-24 07:00:46 --> Total execution time: 0.0787
DEBUG - 2022-06-24 07:00:58 --> Total execution time: 0.0872
DEBUG - 2022-06-24 07:01:12 --> Total execution time: 0.0530
DEBUG - 2022-06-24 07:01:20 --> Total execution time: 0.0504
DEBUG - 2022-06-24 07:01:30 --> Total execution time: 0.0527
DEBUG - 2022-06-24 07:01:32 --> Total execution time: 0.0800
DEBUG - 2022-06-24 07:01:37 --> Total execution time: 0.0512
DEBUG - 2022-06-24 07:01:38 --> Total execution time: 0.0500
DEBUG - 2022-06-24 07:01:39 --> Total execution time: 0.0603
DEBUG - 2022-06-24 07:01:40 --> Total execution time: 0.0477
DEBUG - 2022-06-24 07:08:15 --> Total execution time: 0.0876
DEBUG - 2022-06-24 07:14:26 --> Total execution time: 0.0908
DEBUG - 2022-06-24 07:14:26 --> Total execution time: 0.0984
DEBUG - 2022-06-24 07:14:40 --> Total execution time: 0.0492
DEBUG - 2022-06-24 07:14:58 --> Total execution time: 0.0565
DEBUG - 2022-06-24 07:15:06 --> Total execution time: 0.0566
DEBUG - 2022-06-24 07:15:22 --> Total execution time: 0.0789
DEBUG - 2022-06-24 07:15:27 --> Total execution time: 0.0572
DEBUG - 2022-06-24 07:19:15 --> Total execution time: 0.1086
DEBUG - 2022-06-24 07:26:40 --> Total execution time: 0.0600
DEBUG - 2022-06-24 07:28:49 --> Total execution time: 0.0483
DEBUG - 2022-06-24 07:30:03 --> Total execution time: 0.1521
DEBUG - 2022-06-24 07:30:34 --> Total execution time: 0.1293
DEBUG - 2022-06-24 07:30:38 --> Total execution time: 0.0628
DEBUG - 2022-06-24 07:30:43 --> Total execution time: 0.0352
DEBUG - 2022-06-24 07:31:03 --> Total execution time: 0.0453
DEBUG - 2022-06-24 07:38:21 --> Total execution time: 0.1048
DEBUG - 2022-06-24 07:50:22 --> Total execution time: 0.0635
DEBUG - 2022-06-24 07:50:33 --> Total execution time: 0.0566
DEBUG - 2022-06-24 07:50:34 --> Total execution time: 0.0615
DEBUG - 2022-06-24 07:50:43 --> Total execution time: 0.0752
DEBUG - 2022-06-24 07:50:47 --> Total execution time: 0.0539
DEBUG - 2022-06-24 07:50:57 --> Total execution time: 0.0425
DEBUG - 2022-06-24 07:55:04 --> Total execution time: 0.0458
DEBUG - 2022-06-24 07:55:20 --> Total execution time: 0.0365
DEBUG - 2022-06-24 07:56:02 --> Total execution time: 0.0480
DEBUG - 2022-06-24 07:56:30 --> Total execution time: 0.0517
DEBUG - 2022-06-24 07:56:52 --> Total execution time: 0.0933
DEBUG - 2022-06-24 07:57:49 --> Total execution time: 0.0301
DEBUG - 2022-06-24 07:59:16 --> Total execution time: 0.0358
DEBUG - 2022-06-24 08:06:40 --> Total execution time: 0.1283
DEBUG - 2022-06-24 08:06:46 --> Total execution time: 0.0454
DEBUG - 2022-06-24 08:07:01 --> Total execution time: 0.0545
DEBUG - 2022-06-24 08:08:21 --> Total execution time: 0.0344
DEBUG - 2022-06-24 08:08:35 --> Total execution time: 0.0411
DEBUG - 2022-06-24 08:08:57 --> Total execution time: 0.0508
DEBUG - 2022-06-24 08:09:04 --> Total execution time: 0.0575
DEBUG - 2022-06-24 08:09:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 08:09:05 --> Total execution time: 0.0438
DEBUG - 2022-06-24 08:09:49 --> Total execution time: 0.0630
DEBUG - 2022-06-24 08:09:51 --> Total execution time: 0.0498
DEBUG - 2022-06-24 08:10:34 --> Total execution time: 0.0700
DEBUG - 2022-06-24 08:11:10 --> Total execution time: 0.0701
DEBUG - 2022-06-24 08:26:44 --> Total execution time: 0.0486
DEBUG - 2022-06-24 08:26:55 --> Total execution time: 0.0402
DEBUG - 2022-06-24 08:26:56 --> Total execution time: 0.0515
DEBUG - 2022-06-24 08:27:03 --> Total execution time: 0.0322
DEBUG - 2022-06-24 08:27:08 --> Total execution time: 0.0514
DEBUG - 2022-06-24 08:27:18 --> Total execution time: 0.1102
DEBUG - 2022-06-24 08:27:30 --> Total execution time: 0.0591
DEBUG - 2022-06-24 08:27:34 --> Total execution time: 0.0482
DEBUG - 2022-06-24 08:27:40 --> Total execution time: 0.0582
DEBUG - 2022-06-24 08:27:44 --> Total execution time: 0.0609
DEBUG - 2022-06-24 08:27:47 --> Total execution time: 0.0641
DEBUG - 2022-06-24 08:27:48 --> Total execution time: 0.0555
DEBUG - 2022-06-24 08:28:03 --> Total execution time: 0.0534
DEBUG - 2022-06-24 08:28:10 --> Total execution time: 0.0792
DEBUG - 2022-06-24 08:28:11 --> Total execution time: 0.0536
DEBUG - 2022-06-24 08:28:19 --> Total execution time: 0.0661
DEBUG - 2022-06-24 08:28:19 --> Total execution time: 0.0891
DEBUG - 2022-06-24 08:29:36 --> Total execution time: 0.0436
DEBUG - 2022-06-24 08:29:55 --> Total execution time: 0.1025
DEBUG - 2022-06-24 08:29:58 --> Total execution time: 0.1163
DEBUG - 2022-06-24 08:29:58 --> Total execution time: 0.0655
DEBUG - 2022-06-24 08:30:03 --> Total execution time: 0.0693
DEBUG - 2022-06-24 08:30:06 --> Total execution time: 0.1183
DEBUG - 2022-06-24 08:30:09 --> Total execution time: 0.1249
DEBUG - 2022-06-24 08:30:30 --> Total execution time: 0.0686
DEBUG - 2022-06-24 08:30:34 --> Total execution time: 0.0779
DEBUG - 2022-06-24 08:33:19 --> Total execution time: 0.1113
DEBUG - 2022-06-24 08:33:32 --> Total execution time: 0.0455
DEBUG - 2022-06-24 08:35:03 --> Total execution time: 0.0478
DEBUG - 2022-06-24 08:36:00 --> Total execution time: 0.0493
DEBUG - 2022-06-24 08:36:31 --> Total execution time: 0.0413
DEBUG - 2022-06-24 08:37:05 --> Total execution time: 0.0460
DEBUG - 2022-06-24 08:38:04 --> Total execution time: 0.1256
DEBUG - 2022-06-24 08:38:04 --> Total execution time: 0.0364
DEBUG - 2022-06-24 08:39:18 --> Total execution time: 0.0424
DEBUG - 2022-06-24 08:42:48 --> Total execution time: 0.1079
DEBUG - 2022-06-24 08:43:00 --> Total execution time: 0.1529
DEBUG - 2022-06-24 08:43:01 --> Total execution time: 0.0522
DEBUG - 2022-06-24 08:43:06 --> Total execution time: 0.0664
DEBUG - 2022-06-24 08:43:52 --> Total execution time: 0.0671
DEBUG - 2022-06-24 08:44:32 --> Total execution time: 2.2281
DEBUG - 2022-06-24 08:46:42 --> Total execution time: 0.0323
DEBUG - 2022-06-24 08:46:43 --> Total execution time: 0.0381
DEBUG - 2022-06-24 08:46:52 --> Total execution time: 0.0438
DEBUG - 2022-06-24 08:47:40 --> Total execution time: 0.0553
DEBUG - 2022-06-24 08:47:53 --> Total execution time: 0.0572
DEBUG - 2022-06-24 08:48:36 --> Total execution time: 0.0441
DEBUG - 2022-06-24 08:48:54 --> Total execution time: 0.0417
DEBUG - 2022-06-24 08:49:23 --> Total execution time: 0.0454
DEBUG - 2022-06-24 08:49:49 --> Total execution time: 0.0318
DEBUG - 2022-06-24 08:50:06 --> Total execution time: 0.0482
DEBUG - 2022-06-24 08:50:27 --> Total execution time: 0.0434
DEBUG - 2022-06-24 08:50:35 --> Total execution time: 0.0419
DEBUG - 2022-06-24 08:50:38 --> Total execution time: 0.0459
DEBUG - 2022-06-24 08:50:46 --> Total execution time: 0.0468
DEBUG - 2022-06-24 08:51:01 --> Total execution time: 0.0523
DEBUG - 2022-06-24 08:51:19 --> Total execution time: 0.0462
DEBUG - 2022-06-24 08:52:19 --> Total execution time: 0.0357
DEBUG - 2022-06-24 08:52:44 --> Total execution time: 0.0598
DEBUG - 2022-06-24 08:53:13 --> Total execution time: 0.0665
DEBUG - 2022-06-24 08:53:31 --> Total execution time: 0.0703
DEBUG - 2022-06-24 08:53:33 --> Total execution time: 0.0479
DEBUG - 2022-06-24 08:53:37 --> Total execution time: 0.0914
DEBUG - 2022-06-24 08:53:57 --> Total execution time: 0.0860
DEBUG - 2022-06-24 08:54:45 --> Total execution time: 0.0336
DEBUG - 2022-06-24 08:54:49 --> Total execution time: 0.0306
DEBUG - 2022-06-24 08:54:59 --> Total execution time: 0.0365
DEBUG - 2022-06-24 08:55:39 --> Total execution time: 0.0552
DEBUG - 2022-06-24 08:56:59 --> Total execution time: 0.0659
DEBUG - 2022-06-24 08:58:04 --> Total execution time: 2.5320
DEBUG - 2022-06-24 09:02:52 --> Total execution time: 0.0902
DEBUG - 2022-06-24 09:03:41 --> Total execution time: 0.1190
DEBUG - 2022-06-24 09:03:49 --> Total execution time: 0.0474
DEBUG - 2022-06-24 09:04:07 --> Total execution time: 0.0335
DEBUG - 2022-06-24 09:04:42 --> Total execution time: 0.0357
DEBUG - 2022-06-24 09:04:59 --> Total execution time: 0.0693
DEBUG - 2022-06-24 09:05:09 --> Total execution time: 0.0465
DEBUG - 2022-06-24 09:05:23 --> Total execution time: 0.0519
DEBUG - 2022-06-24 09:05:39 --> Total execution time: 0.0411
DEBUG - 2022-06-24 09:05:45 --> Total execution time: 0.0467
DEBUG - 2022-06-24 09:05:47 --> Total execution time: 0.0478
DEBUG - 2022-06-24 09:05:54 --> Total execution time: 0.0661
DEBUG - 2022-06-24 09:06:05 --> Total execution time: 0.0486
DEBUG - 2022-06-24 09:06:18 --> Total execution time: 2.0787
DEBUG - 2022-06-24 09:06:58 --> Total execution time: 1.4695
DEBUG - 2022-06-24 09:07:22 --> Total execution time: 0.0528
DEBUG - 2022-06-24 09:08:24 --> Total execution time: 0.0688
DEBUG - 2022-06-24 09:09:22 --> Total execution time: 0.1792
DEBUG - 2022-06-24 09:09:37 --> Total execution time: 0.0906
DEBUG - 2022-06-24 09:09:59 --> Total execution time: 0.1461
DEBUG - 2022-06-24 09:10:17 --> Total execution time: 0.0563
DEBUG - 2022-06-24 09:10:27 --> Total execution time: 0.0480
DEBUG - 2022-06-24 09:10:39 --> Total execution time: 0.0576
DEBUG - 2022-06-24 09:16:54 --> Total execution time: 0.0804
DEBUG - 2022-06-24 09:16:59 --> Total execution time: 0.0366
DEBUG - 2022-06-24 09:17:10 --> Total execution time: 0.0828
DEBUG - 2022-06-24 09:18:53 --> Total execution time: 0.0761
DEBUG - 2022-06-24 09:18:59 --> Total execution time: 0.0763
DEBUG - 2022-06-24 09:20:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 09:20:06 --> Total execution time: 0.0728
DEBUG - 2022-06-24 09:20:12 --> Total execution time: 0.0775
DEBUG - 2022-06-24 09:20:25 --> Total execution time: 0.0770
DEBUG - 2022-06-24 09:20:27 --> Total execution time: 0.0718
DEBUG - 2022-06-24 09:20:47 --> Total execution time: 0.0718
DEBUG - 2022-06-24 09:21:01 --> Total execution time: 0.0810
DEBUG - 2022-06-24 09:21:11 --> Total execution time: 0.0717
DEBUG - 2022-06-24 09:21:15 --> Total execution time: 0.0515
DEBUG - 2022-06-24 09:21:20 --> Total execution time: 0.0801
DEBUG - 2022-06-24 09:21:34 --> Total execution time: 0.0424
DEBUG - 2022-06-24 09:22:57 --> Total execution time: 0.0361
DEBUG - 2022-06-24 09:23:17 --> Total execution time: 0.1561
DEBUG - 2022-06-24 09:23:40 --> Total execution time: 0.0724
DEBUG - 2022-06-24 09:27:43 --> Total execution time: 0.1461
DEBUG - 2022-06-24 09:30:03 --> Total execution time: 0.1302
DEBUG - 2022-06-24 09:33:55 --> Total execution time: 0.1030
DEBUG - 2022-06-24 09:33:59 --> Total execution time: 0.0639
DEBUG - 2022-06-24 09:34:33 --> Total execution time: 0.0458
DEBUG - 2022-06-24 09:34:55 --> Total execution time: 0.1232
DEBUG - 2022-06-24 09:34:57 --> Total execution time: 0.0420
DEBUG - 2022-06-24 09:35:26 --> Total execution time: 0.0656
DEBUG - 2022-06-24 09:35:40 --> Total execution time: 0.0634
DEBUG - 2022-06-24 09:35:44 --> Total execution time: 0.0584
DEBUG - 2022-06-24 09:35:48 --> Total execution time: 0.0535
DEBUG - 2022-06-24 09:35:57 --> Total execution time: 0.0474
DEBUG - 2022-06-24 09:35:59 --> Total execution time: 0.0414
DEBUG - 2022-06-24 09:36:41 --> Total execution time: 0.0430
DEBUG - 2022-06-24 09:36:53 --> Total execution time: 0.0567
DEBUG - 2022-06-24 09:37:08 --> Total execution time: 0.0515
DEBUG - 2022-06-24 09:37:10 --> Total execution time: 0.0437
DEBUG - 2022-06-24 09:37:26 --> Total execution time: 0.0525
DEBUG - 2022-06-24 09:37:36 --> Total execution time: 0.1177
DEBUG - 2022-06-24 09:41:04 --> Total execution time: 0.1786
DEBUG - 2022-06-24 09:41:49 --> Total execution time: 0.0863
DEBUG - 2022-06-24 09:41:49 --> Total execution time: 0.1109
DEBUG - 2022-06-24 09:41:53 --> Total execution time: 0.0420
DEBUG - 2022-06-24 09:42:22 --> Total execution time: 0.0428
DEBUG - 2022-06-24 09:43:15 --> Total execution time: 0.0593
DEBUG - 2022-06-24 09:43:28 --> Total execution time: 0.0437
DEBUG - 2022-06-24 09:43:33 --> Total execution time: 0.0460
DEBUG - 2022-06-24 09:43:44 --> Total execution time: 0.0426
DEBUG - 2022-06-24 09:44:02 --> Total execution time: 0.0518
DEBUG - 2022-06-24 09:47:00 --> Total execution time: 0.0835
DEBUG - 2022-06-24 09:47:10 --> Total execution time: 0.0390
DEBUG - 2022-06-24 09:47:35 --> Total execution time: 0.0551
DEBUG - 2022-06-24 09:47:47 --> Total execution time: 0.0496
DEBUG - 2022-06-24 09:47:55 --> Total execution time: 0.0508
DEBUG - 2022-06-24 09:50:12 --> Total execution time: 0.1041
DEBUG - 2022-06-24 09:51:34 --> Total execution time: 0.1831
DEBUG - 2022-06-24 09:52:27 --> Total execution time: 0.0343
DEBUG - 2022-06-24 09:52:31 --> Total execution time: 0.0373
DEBUG - 2022-06-24 09:52:37 --> Total execution time: 0.0459
DEBUG - 2022-06-24 09:52:53 --> Total execution time: 0.0472
DEBUG - 2022-06-24 09:52:56 --> Total execution time: 0.0861
DEBUG - 2022-06-24 09:53:12 --> Total execution time: 0.0463
DEBUG - 2022-06-24 09:53:14 --> Total execution time: 0.0495
DEBUG - 2022-06-24 09:53:14 --> Total execution time: 0.0552
DEBUG - 2022-06-24 09:53:21 --> Total execution time: 0.0593
DEBUG - 2022-06-24 09:53:26 --> Total execution time: 0.0765
DEBUG - 2022-06-24 09:53:31 --> Total execution time: 0.0454
DEBUG - 2022-06-24 09:53:36 --> Total execution time: 0.0554
DEBUG - 2022-06-24 09:53:38 --> Total execution time: 0.0788
DEBUG - 2022-06-24 09:53:44 --> Total execution time: 0.0440
DEBUG - 2022-06-24 09:54:51 --> Total execution time: 0.0531
DEBUG - 2022-06-24 09:54:54 --> Total execution time: 0.0630
DEBUG - 2022-06-24 09:54:55 --> Total execution time: 0.0768
DEBUG - 2022-06-24 09:55:03 --> Total execution time: 0.0489
DEBUG - 2022-06-24 09:55:08 --> Total execution time: 0.0486
DEBUG - 2022-06-24 09:55:56 --> Total execution time: 0.0618
DEBUG - 2022-06-24 09:55:59 --> Total execution time: 0.0682
DEBUG - 2022-06-24 09:56:04 --> Total execution time: 0.0458
DEBUG - 2022-06-24 09:56:10 --> Total execution time: 0.0507
DEBUG - 2022-06-24 09:56:14 --> Total execution time: 0.0773
DEBUG - 2022-06-24 09:56:26 --> Total execution time: 0.0299
DEBUG - 2022-06-24 09:57:06 --> Total execution time: 0.0550
DEBUG - 2022-06-24 09:57:24 --> Total execution time: 0.0336
DEBUG - 2022-06-24 09:57:43 --> Total execution time: 0.0498
DEBUG - 2022-06-24 09:57:57 --> Total execution time: 0.0565
DEBUG - 2022-06-24 09:57:58 --> Total execution time: 0.0357
DEBUG - 2022-06-24 09:57:59 --> Total execution time: 0.0527
DEBUG - 2022-06-24 09:58:02 --> Total execution time: 0.0492
DEBUG - 2022-06-24 09:58:07 --> Total execution time: 0.0725
DEBUG - 2022-06-24 09:58:30 --> Total execution time: 0.0441
DEBUG - 2022-06-24 09:58:59 --> Total execution time: 0.0594
DEBUG - 2022-06-24 09:58:59 --> Total execution time: 0.0736
DEBUG - 2022-06-24 09:59:12 --> Total execution time: 0.0806
DEBUG - 2022-06-24 09:59:15 --> Total execution time: 0.0577
DEBUG - 2022-06-24 09:59:18 --> Total execution time: 0.0817
DEBUG - 2022-06-24 09:59:29 --> Total execution time: 0.0454
DEBUG - 2022-06-24 10:02:05 --> Total execution time: 0.1185
DEBUG - 2022-06-24 10:03:05 --> Total execution time: 0.0480
DEBUG - 2022-06-24 10:04:13 --> Total execution time: 0.0459
DEBUG - 2022-06-24 10:04:52 --> Total execution time: 0.1524
DEBUG - 2022-06-24 10:05:03 --> Total execution time: 0.0476
DEBUG - 2022-06-24 10:05:07 --> Total execution time: 0.0412
DEBUG - 2022-06-24 10:05:12 --> Total execution time: 0.0623
DEBUG - 2022-06-24 10:05:28 --> Total execution time: 0.0656
DEBUG - 2022-06-24 10:05:30 --> Total execution time: 0.1271
DEBUG - 2022-06-24 10:05:44 --> Total execution time: 0.0300
DEBUG - 2022-06-24 10:06:03 --> Total execution time: 0.0380
DEBUG - 2022-06-24 10:06:09 --> Total execution time: 0.0440
DEBUG - 2022-06-24 10:06:09 --> Total execution time: 0.0353
DEBUG - 2022-06-24 10:06:20 --> Total execution time: 0.0531
DEBUG - 2022-06-24 10:06:35 --> Total execution time: 0.0602
DEBUG - 2022-06-24 10:06:38 --> Total execution time: 0.0488
DEBUG - 2022-06-24 10:06:50 --> Total execution time: 0.0418
DEBUG - 2022-06-24 10:06:52 --> Total execution time: 0.0469
DEBUG - 2022-06-24 10:06:52 --> Total execution time: 0.0464
DEBUG - 2022-06-24 10:07:06 --> Total execution time: 0.0584
DEBUG - 2022-06-24 10:07:24 --> Total execution time: 0.0599
DEBUG - 2022-06-24 10:07:31 --> Total execution time: 0.0375
DEBUG - 2022-06-24 10:08:04 --> Total execution time: 0.0316
DEBUG - 2022-06-24 10:08:17 --> Total execution time: 0.0468
DEBUG - 2022-06-24 10:09:30 --> Total execution time: 0.0649
DEBUG - 2022-06-24 10:09:38 --> Total execution time: 0.0295
DEBUG - 2022-06-24 10:09:54 --> Total execution time: 0.0486
DEBUG - 2022-06-24 10:10:09 --> Total execution time: 0.0686
DEBUG - 2022-06-24 10:14:53 --> Total execution time: 0.1441
DEBUG - 2022-06-24 10:25:49 --> Total execution time: 0.2125
DEBUG - 2022-06-24 10:25:54 --> Total execution time: 0.0342
DEBUG - 2022-06-24 10:26:13 --> Total execution time: 0.0461
DEBUG - 2022-06-24 10:27:05 --> Total execution time: 0.0605
DEBUG - 2022-06-24 10:29:14 --> Total execution time: 0.0388
DEBUG - 2022-06-24 10:29:32 --> Total execution time: 0.0423
DEBUG - 2022-06-24 10:29:39 --> Total execution time: 0.0561
DEBUG - 2022-06-24 10:29:43 --> Total execution time: 0.0415
DEBUG - 2022-06-24 10:29:59 --> Total execution time: 0.0514
DEBUG - 2022-06-24 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:30:02 --> Total execution time: 0.0667
DEBUG - 2022-06-24 00:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:00:12 --> Total execution time: 0.1159
DEBUG - 2022-06-24 00:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:00:14 --> Total execution time: 0.0616
DEBUG - 2022-06-24 00:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:00:14 --> Total execution time: 0.1340
DEBUG - 2022-06-24 00:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:00:18 --> Total execution time: 0.0686
DEBUG - 2022-06-24 00:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:30:27 --> Total execution time: 0.0637
DEBUG - 2022-06-24 00:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:30:35 --> Total execution time: 0.0530
DEBUG - 2022-06-24 00:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:31:04 --> Total execution time: 0.0535
DEBUG - 2022-06-24 00:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:31:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 00:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:31:06 --> Total execution time: 0.0490
DEBUG - 2022-06-24 00:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:01:25 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 00:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:31:27 --> Total execution time: 1.9894
DEBUG - 2022-06-24 00:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:31:28 --> Total execution time: 0.0668
DEBUG - 2022-06-24 00:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:31:58 --> Total execution time: 0.0488
DEBUG - 2022-06-24 00:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:32:08 --> Total execution time: 0.0690
DEBUG - 2022-06-24 00:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:33:03 --> Total execution time: 0.0646
DEBUG - 2022-06-24 00:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:33:15 --> Total execution time: 0.0868
DEBUG - 2022-06-24 00:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:33:39 --> Total execution time: 0.0609
DEBUG - 2022-06-24 00:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:03:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 00:03:41 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 00:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:06:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 00:06:06 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 00:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 00:06:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 00:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:08:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 00:08:05 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 00:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:09:26 --> Total execution time: 0.1049
DEBUG - 2022-06-24 00:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:09:44 --> Total execution time: 0.1207
DEBUG - 2022-06-24 00:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:40:30 --> Total execution time: 0.1253
DEBUG - 2022-06-24 00:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:11:38 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:41:38 --> Total execution time: 0.0450
DEBUG - 2022-06-24 00:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:41:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 00:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:41:42 --> Total execution time: 0.0513
DEBUG - 2022-06-24 00:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:11:45 --> Total execution time: 0.0451
DEBUG - 2022-06-24 00:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:11:46 --> Total execution time: 0.0481
DEBUG - 2022-06-24 00:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:11:46 --> Total execution time: 0.0716
DEBUG - 2022-06-24 00:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:42:19 --> Total execution time: 0.0927
DEBUG - 2022-06-24 00:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:13:26 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:43:26 --> Total execution time: 0.0549
DEBUG - 2022-06-24 00:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:43:32 --> Total execution time: 0.0654
DEBUG - 2022-06-24 00:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:44:17 --> Total execution time: 0.0335
DEBUG - 2022-06-24 00:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:44:32 --> Total execution time: 0.0913
DEBUG - 2022-06-24 00:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:44:43 --> Total execution time: 0.0396
DEBUG - 2022-06-24 00:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:14:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 00:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:45:02 --> Total execution time: 1.5598
DEBUG - 2022-06-24 00:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 00:15:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 00:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:45:23 --> Total execution time: 0.0607
DEBUG - 2022-06-24 00:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:45:33 --> Total execution time: 0.1481
DEBUG - 2022-06-24 00:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:45:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 00:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:45:38 --> Total execution time: 0.0623
DEBUG - 2022-06-24 00:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:45:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 10:45:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 10:45:40 --> Total execution time: 0.2163
DEBUG - 2022-06-24 00:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:45:42 --> Total execution time: 0.0658
DEBUG - 2022-06-24 00:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:45:48 --> Total execution time: 0.0798
DEBUG - 2022-06-24 00:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:45:53 --> Total execution time: 0.0302
DEBUG - 2022-06-24 00:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:45:53 --> Total execution time: 0.0651
DEBUG - 2022-06-24 00:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:45:55 --> Total execution time: 0.0480
DEBUG - 2022-06-24 00:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:45:56 --> Total execution time: 0.0445
DEBUG - 2022-06-24 00:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:45:59 --> Total execution time: 0.0425
DEBUG - 2022-06-24 00:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:46:03 --> Total execution time: 0.0491
DEBUG - 2022-06-24 00:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:46:45 --> Total execution time: 0.0422
DEBUG - 2022-06-24 00:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:17:03 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:47:04 --> Total execution time: 0.0438
DEBUG - 2022-06-24 00:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:47:24 --> Total execution time: 0.0451
DEBUG - 2022-06-24 00:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:47:26 --> Total execution time: 0.0345
DEBUG - 2022-06-24 00:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:47:34 --> Total execution time: 0.0559
DEBUG - 2022-06-24 00:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:47:37 --> Total execution time: 0.0547
DEBUG - 2022-06-24 00:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:47:42 --> Total execution time: 0.0439
DEBUG - 2022-06-24 00:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:47:56 --> Total execution time: 0.0575
DEBUG - 2022-06-24 00:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:48:02 --> Total execution time: 0.0805
DEBUG - 2022-06-24 00:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:48:10 --> Total execution time: 0.2712
DEBUG - 2022-06-24 00:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:48:27 --> Total execution time: 0.0468
DEBUG - 2022-06-24 00:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:48:31 --> Total execution time: 0.0436
DEBUG - 2022-06-24 00:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:48:35 --> Total execution time: 0.0479
DEBUG - 2022-06-24 00:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:48:58 --> Total execution time: 0.0666
DEBUG - 2022-06-24 00:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:49:56 --> Total execution time: 0.0632
DEBUG - 2022-06-24 00:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:50:07 --> Total execution time: 0.0939
DEBUG - 2022-06-24 00:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:50:17 --> Total execution time: 0.0741
DEBUG - 2022-06-24 00:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:50:38 --> Total execution time: 0.0777
DEBUG - 2022-06-24 00:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:51:00 --> Total execution time: 0.1391
DEBUG - 2022-06-24 00:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:51:05 --> Total execution time: 0.0565
DEBUG - 2022-06-24 00:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:52:32 --> Total execution time: 0.0545
DEBUG - 2022-06-24 00:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:52:43 --> Total execution time: 0.0540
DEBUG - 2022-06-24 00:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:52:43 --> Total execution time: 0.0484
DEBUG - 2022-06-24 00:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:52:48 --> Total execution time: 0.0876
DEBUG - 2022-06-24 00:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:52:55 --> Total execution time: 0.0652
DEBUG - 2022-06-24 00:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:52:57 --> Total execution time: 0.0502
DEBUG - 2022-06-24 00:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:52:59 --> Total execution time: 0.2066
DEBUG - 2022-06-24 00:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:53:01 --> Total execution time: 0.1978
DEBUG - 2022-06-24 00:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:53:03 --> Total execution time: 0.1654
DEBUG - 2022-06-24 00:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:53:06 --> Total execution time: 0.1616
DEBUG - 2022-06-24 00:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:53:09 --> Total execution time: 0.2811
DEBUG - 2022-06-24 00:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:53:11 --> Total execution time: 0.0706
DEBUG - 2022-06-24 00:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:53:13 --> Total execution time: 0.0552
DEBUG - 2022-06-24 00:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:53:21 --> Total execution time: 0.0484
DEBUG - 2022-06-24 00:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:53:24 --> Total execution time: 0.0448
DEBUG - 2022-06-24 00:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:25 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:53:25 --> Total execution time: 0.0535
DEBUG - 2022-06-24 00:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:25 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:53:26 --> Total execution time: 0.0273
DEBUG - 2022-06-24 00:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:53:57 --> Total execution time: 0.0488
DEBUG - 2022-06-24 00:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:24:04 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:54:04 --> Total execution time: 0.0387
DEBUG - 2022-06-24 00:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:24:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:54:05 --> Total execution time: 0.0548
DEBUG - 2022-06-24 00:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:54:18 --> Total execution time: 0.0694
DEBUG - 2022-06-24 00:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:54:47 --> Total execution time: 0.0475
DEBUG - 2022-06-24 00:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:25:01 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:55:01 --> Total execution time: 0.0692
DEBUG - 2022-06-24 00:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:25:06 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:55:06 --> Total execution time: 0.0430
DEBUG - 2022-06-24 00:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:25:07 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:55:07 --> Total execution time: 0.0573
DEBUG - 2022-06-24 00:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:25:23 --> Total execution time: 0.0545
DEBUG - 2022-06-24 00:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:25:25 --> Total execution time: 0.0532
DEBUG - 2022-06-24 00:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:25:25 --> Total execution time: 0.1117
DEBUG - 2022-06-24 00:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:25:37 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:55:38 --> Total execution time: 0.1118
DEBUG - 2022-06-24 00:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:26:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 00:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:56:19 --> Total execution time: 1.9590
DEBUG - 2022-06-24 00:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:26:26 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:56:26 --> Total execution time: 0.0552
DEBUG - 2022-06-24 00:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 00:26:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 00:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:56:35 --> Total execution time: 0.0444
DEBUG - 2022-06-24 00:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:56:44 --> Total execution time: 0.0462
DEBUG - 2022-06-24 00:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:56:49 --> Total execution time: 0.0522
DEBUG - 2022-06-24 00:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:56:56 --> Total execution time: 0.0528
DEBUG - 2022-06-24 00:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:56:59 --> Total execution time: 0.0637
DEBUG - 2022-06-24 00:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:57:24 --> Total execution time: 0.0434
DEBUG - 2022-06-24 00:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:57:30 --> Total execution time: 0.0652
DEBUG - 2022-06-24 00:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:57:39 --> Total execution time: 0.0548
DEBUG - 2022-06-24 00:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:57:47 --> Total execution time: 0.0567
DEBUG - 2022-06-24 00:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:27:47 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:57:47 --> Total execution time: 0.0462
DEBUG - 2022-06-24 00:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:58:29 --> Total execution time: 0.0593
DEBUG - 2022-06-24 00:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:58:34 --> Total execution time: 0.0507
DEBUG - 2022-06-24 00:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:58:37 --> Total execution time: 0.0814
DEBUG - 2022-06-24 00:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:59:07 --> Total execution time: 0.0479
DEBUG - 2022-06-24 00:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:30:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:00:05 --> Total execution time: 0.0577
DEBUG - 2022-06-24 00:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 00:30:08 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 00:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:30:30 --> Total execution time: 0.1203
DEBUG - 2022-06-24 00:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:30:32 --> Total execution time: 0.0522
DEBUG - 2022-06-24 00:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:30:32 --> Total execution time: 0.0627
DEBUG - 2022-06-24 00:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:00:42 --> Total execution time: 0.0496
DEBUG - 2022-06-24 00:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:30:49 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:00:49 --> Total execution time: 0.0550
DEBUG - 2022-06-24 00:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:00:50 --> Total execution time: 0.1262
DEBUG - 2022-06-24 00:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:31:02 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:01:02 --> Total execution time: 0.0583
DEBUG - 2022-06-24 00:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:31:07 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:01:07 --> Total execution time: 0.0607
DEBUG - 2022-06-24 00:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:31:11 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:01:11 --> Total execution time: 0.0468
DEBUG - 2022-06-24 00:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:01:17 --> Total execution time: 0.1103
DEBUG - 2022-06-24 00:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:01:19 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 00:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:01:19 --> Total execution time: 0.1168
DEBUG - 2022-06-24 00:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:31:21 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:01:21 --> Total execution time: 0.0596
DEBUG - 2022-06-24 00:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:01:31 --> Total execution time: 0.1100
DEBUG - 2022-06-24 00:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:01:42 --> Total execution time: 0.1120
DEBUG - 2022-06-24 00:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:01:50 --> Total execution time: 0.0975
DEBUG - 2022-06-24 00:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:04:51 --> Total execution time: 0.1155
DEBUG - 2022-06-24 00:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:06:41 --> Total execution time: 0.1816
DEBUG - 2022-06-24 00:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:06:43 --> Total execution time: 0.0557
DEBUG - 2022-06-24 00:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:06:51 --> Total execution time: 0.0458
DEBUG - 2022-06-24 00:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:10:01 --> Total execution time: 0.1064
DEBUG - 2022-06-24 00:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:10:23 --> Total execution time: 0.0671
DEBUG - 2022-06-24 00:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:10:24 --> Total execution time: 0.0475
DEBUG - 2022-06-24 00:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:10:44 --> Total execution time: 0.0554
DEBUG - 2022-06-24 00:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:10:48 --> Total execution time: 0.0724
DEBUG - 2022-06-24 00:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:13:05 --> Total execution time: 0.0840
DEBUG - 2022-06-24 00:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:13:40 --> Total execution time: 0.1258
DEBUG - 2022-06-24 00:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:13:53 --> Total execution time: 0.0709
DEBUG - 2022-06-24 00:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:14:12 --> Total execution time: 0.0476
DEBUG - 2022-06-24 00:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:15:18 --> Total execution time: 0.0430
DEBUG - 2022-06-24 00:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:47:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:17:14 --> Total execution time: 0.0424
DEBUG - 2022-06-24 00:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:47:24 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:17:24 --> Total execution time: 0.0560
DEBUG - 2022-06-24 00:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:19:48 --> Total execution time: 0.0874
DEBUG - 2022-06-24 00:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:19:55 --> Total execution time: 0.0514
DEBUG - 2022-06-24 00:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:20:05 --> Total execution time: 0.0613
DEBUG - 2022-06-24 00:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:50:45 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:20:45 --> Total execution time: 0.0334
DEBUG - 2022-06-24 00:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:50:46 --> Total execution time: 0.0431
DEBUG - 2022-06-24 00:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:50:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 00:50:46 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-06-24 00:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:20:53 --> Total execution time: 0.0590
DEBUG - 2022-06-24 00:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:20:59 --> Total execution time: 0.1388
DEBUG - 2022-06-24 00:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:51:09 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:21:09 --> Total execution time: 0.0408
DEBUG - 2022-06-24 00:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:21:17 --> Total execution time: 0.0340
DEBUG - 2022-06-24 00:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:21:49 --> Total execution time: 0.0586
DEBUG - 2022-06-24 00:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:22:02 --> Total execution time: 0.1125
DEBUG - 2022-06-24 00:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:22:02 --> Total execution time: 0.2025
DEBUG - 2022-06-24 00:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:22:08 --> Total execution time: 0.1706
DEBUG - 2022-06-24 00:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:22:31 --> Total execution time: 0.0792
DEBUG - 2022-06-24 00:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:22:36 --> Total execution time: 0.1341
DEBUG - 2022-06-24 00:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:52:44 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:22:44 --> Total execution time: 0.2137
DEBUG - 2022-06-24 00:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:52:48 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:22:48 --> Total execution time: 0.0398
DEBUG - 2022-06-24 00:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 00:52:49 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-06-24 00:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:52:55 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:22:55 --> Total execution time: 0.0507
DEBUG - 2022-06-24 00:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:52:55 --> Total execution time: 0.0691
DEBUG - 2022-06-24 00:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:23:00 --> Total execution time: 0.0535
DEBUG - 2022-06-24 00:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:23:04 --> Total execution time: 0.0837
DEBUG - 2022-06-24 00:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:23:08 --> Total execution time: 0.1155
DEBUG - 2022-06-24 00:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:53:09 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:23:09 --> Total execution time: 0.0557
DEBUG - 2022-06-24 00:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:23:13 --> Total execution time: 0.0733
DEBUG - 2022-06-24 00:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:23:18 --> Total execution time: 0.0545
DEBUG - 2022-06-24 00:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:23:21 --> Total execution time: 0.1057
DEBUG - 2022-06-24 00:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:23:25 --> Total execution time: 0.0815
DEBUG - 2022-06-24 00:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:23:37 --> Total execution time: 0.0809
DEBUG - 2022-06-24 00:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:23:41 --> Total execution time: 0.0769
DEBUG - 2022-06-24 00:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:25:06 --> Total execution time: 0.0653
DEBUG - 2022-06-24 00:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:25:49 --> Total execution time: 0.1047
DEBUG - 2022-06-24 00:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:26:00 --> Total execution time: 0.0424
DEBUG - 2022-06-24 00:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:56:24 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:26:24 --> Total execution time: 0.0329
DEBUG - 2022-06-24 00:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:27:37 --> Total execution time: 0.0387
DEBUG - 2022-06-24 00:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:57:54 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:27:55 --> Total execution time: 0.1559
DEBUG - 2022-06-24 00:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:28:02 --> Total execution time: 0.0462
DEBUG - 2022-06-24 00:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:58:03 --> Total execution time: 0.1294
DEBUG - 2022-06-24 00:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:58:04 --> Total execution time: 0.0689
DEBUG - 2022-06-24 00:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 00:58:04 --> Total execution time: 0.0937
DEBUG - 2022-06-24 00:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 00:58:56 --> No URI present. Default controller set.
DEBUG - 2022-06-24 00:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 00:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:28:56 --> Total execution time: 0.0482
DEBUG - 2022-06-24 01:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:30:01 --> Total execution time: 0.0472
DEBUG - 2022-06-24 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:00:02 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:30:03 --> Total execution time: 0.0847
DEBUG - 2022-06-24 01:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:00:26 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:30:26 --> Total execution time: 0.0596
DEBUG - 2022-06-24 01:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:00:37 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:30:37 --> Total execution time: 0.0434
DEBUG - 2022-06-24 01:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:00:38 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:30:38 --> Total execution time: 0.0331
DEBUG - 2022-06-24 01:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:00:52 --> Total execution time: 0.0613
DEBUG - 2022-06-24 01:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:00:53 --> Total execution time: 0.0733
DEBUG - 2022-06-24 01:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:00:53 --> Total execution time: 0.1235
DEBUG - 2022-06-24 01:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:01:00 --> Total execution time: 0.0438
DEBUG - 2022-06-24 01:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:01:02 --> Total execution time: 0.0664
DEBUG - 2022-06-24 01:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:01:02 --> Total execution time: 0.1296
DEBUG - 2022-06-24 01:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:01:09 --> Total execution time: 0.0528
DEBUG - 2022-06-24 01:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:01:13 --> Total execution time: 0.0527
DEBUG - 2022-06-24 01:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:01:16 --> Total execution time: 0.0567
DEBUG - 2022-06-24 01:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:02:08 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:32:08 --> Total execution time: 0.0495
DEBUG - 2022-06-24 01:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:03:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:33:05 --> Total execution time: 0.1261
DEBUG - 2022-06-24 01:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:04:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 01:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:34:18 --> Total execution time: 1.9460
DEBUG - 2022-06-24 01:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:04:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 01:04:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 01:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:36:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 01:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:36:13 --> Total execution time: 0.0596
DEBUG - 2022-06-24 01:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:36:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 11:36:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 11:36:16 --> Total execution time: 0.1815
DEBUG - 2022-06-24 01:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:37:22 --> Total execution time: 0.0847
DEBUG - 2022-06-24 01:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:38:07 --> Total execution time: 0.0558
DEBUG - 2022-06-24 01:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:38:15 --> Total execution time: 0.0496
DEBUG - 2022-06-24 01:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:38:18 --> Total execution time: 0.0481
DEBUG - 2022-06-24 01:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:38:40 --> Total execution time: 0.0508
DEBUG - 2022-06-24 01:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:38:51 --> Total execution time: 0.0513
DEBUG - 2022-06-24 01:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:08:57 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:38:57 --> Total execution time: 0.0419
DEBUG - 2022-06-24 01:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:09:01 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:39:01 --> Total execution time: 0.0383
DEBUG - 2022-06-24 01:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:09:43 --> Total execution time: 0.0618
DEBUG - 2022-06-24 01:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:09:55 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:39:55 --> Total execution time: 0.0325
DEBUG - 2022-06-24 01:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:40:00 --> Total execution time: 0.0364
DEBUG - 2022-06-24 01:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:10:04 --> Total execution time: 0.0428
DEBUG - 2022-06-24 01:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:12 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:40:12 --> Total execution time: 0.0719
DEBUG - 2022-06-24 01:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:16 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:40:16 --> Total execution time: 0.0533
DEBUG - 2022-06-24 01:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:40:16 --> Total execution time: 0.0487
DEBUG - 2022-06-24 01:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:10:18 --> Total execution time: 0.0455
DEBUG - 2022-06-24 01:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:40:23 --> Total execution time: 0.0475
DEBUG - 2022-06-24 01:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:10:24 --> Total execution time: 0.0566
DEBUG - 2022-06-24 01:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:26 --> Total execution time: 0.0508
DEBUG - 2022-06-24 01:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:10:26 --> Total execution time: 0.0674
DEBUG - 2022-06-24 01:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:40:38 --> Total execution time: 0.0672
DEBUG - 2022-06-24 01:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:40:38 --> Total execution time: 0.0556
DEBUG - 2022-06-24 01:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:40:39 --> Total execution time: 0.0792
DEBUG - 2022-06-24 01:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:39 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:40:39 --> Total execution time: 0.0534
DEBUG - 2022-06-24 01:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:10:53 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:40:53 --> Total execution time: 0.0488
DEBUG - 2022-06-24 01:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:11:27 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:41:27 --> Total execution time: 0.0587
DEBUG - 2022-06-24 01:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:11:37 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:41:37 --> Total execution time: 0.0552
DEBUG - 2022-06-24 01:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:41:52 --> Total execution time: 1.4753
DEBUG - 2022-06-24 01:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:12:01 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:42:01 --> Total execution time: 0.0507
DEBUG - 2022-06-24 01:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:12:06 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:42:06 --> Total execution time: 0.0873
DEBUG - 2022-06-24 01:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:43:16 --> Total execution time: 0.0730
DEBUG - 2022-06-24 01:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:44:19 --> Total execution time: 0.0807
DEBUG - 2022-06-24 01:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:44:47 --> Total execution time: 0.0593
DEBUG - 2022-06-24 01:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:45:06 --> Total execution time: 0.1274
DEBUG - 2022-06-24 01:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:45:26 --> Total execution time: 0.0609
DEBUG - 2022-06-24 01:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:18:45 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:48:45 --> Total execution time: 0.1129
DEBUG - 2022-06-24 01:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:01 --> Total execution time: 0.0439
DEBUG - 2022-06-24 01:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:09 --> Total execution time: 0.0324
DEBUG - 2022-06-24 01:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:25 --> Total execution time: 0.0553
DEBUG - 2022-06-24 01:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:33 --> Total execution time: 0.0500
DEBUG - 2022-06-24 01:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:39 --> Total execution time: 0.1004
DEBUG - 2022-06-24 01:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:45 --> Total execution time: 0.0567
DEBUG - 2022-06-24 01:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:19:51 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:52 --> Total execution time: 0.0361
DEBUG - 2022-06-24 01:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:50:24 --> Total execution time: 0.0762
DEBUG - 2022-06-24 01:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:53:10 --> Total execution time: 0.2223
DEBUG - 2022-06-24 01:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:23:26 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:53:26 --> Total execution time: 0.0395
DEBUG - 2022-06-24 01:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:53:27 --> Total execution time: 0.0497
DEBUG - 2022-06-24 01:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:53:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 01:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:53:28 --> Total execution time: 0.0695
DEBUG - 2022-06-24 01:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:54:00 --> Total execution time: 0.0444
DEBUG - 2022-06-24 01:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:24:29 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:54:29 --> Total execution time: 0.0345
DEBUG - 2022-06-24 01:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:55:26 --> Total execution time: 0.0450
DEBUG - 2022-06-24 01:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:55:29 --> Total execution time: 0.0434
DEBUG - 2022-06-24 01:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:56:02 --> Total execution time: 0.0418
DEBUG - 2022-06-24 01:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:56:38 --> Total execution time: 0.0837
DEBUG - 2022-06-24 01:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:56:58 --> Total execution time: 0.0536
DEBUG - 2022-06-24 01:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:57:14 --> Total execution time: 0.0455
DEBUG - 2022-06-24 01:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:57:44 --> Total execution time: 0.0416
DEBUG - 2022-06-24 01:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:28:30 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:58:30 --> Total execution time: 0.0340
DEBUG - 2022-06-24 01:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:58:33 --> Total execution time: 0.0518
DEBUG - 2022-06-24 01:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:58:44 --> Total execution time: 0.0980
DEBUG - 2022-06-24 01:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:58:47 --> Total execution time: 0.0722
DEBUG - 2022-06-24 01:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:58:51 --> Total execution time: 0.0562
DEBUG - 2022-06-24 01:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:58:52 --> Total execution time: 0.0693
DEBUG - 2022-06-24 01:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:59:05 --> Total execution time: 0.0864
DEBUG - 2022-06-24 01:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:59:28 --> Total execution time: 0.0513
DEBUG - 2022-06-24 01:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:59:31 --> Total execution time: 0.0622
DEBUG - 2022-06-24 01:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:59:34 --> Total execution time: 0.0952
DEBUG - 2022-06-24 01:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:59:36 --> Total execution time: 0.0373
DEBUG - 2022-06-24 01:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:59:53 --> Total execution time: 0.0478
DEBUG - 2022-06-24 01:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:29:56 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:59:56 --> Total execution time: 0.0280
DEBUG - 2022-06-24 01:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:59:57 --> Total execution time: 0.0869
DEBUG - 2022-06-24 01:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:00:01 --> Total execution time: 0.0496
DEBUG - 2022-06-24 01:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:30:17 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:00:17 --> Total execution time: 0.0409
DEBUG - 2022-06-24 01:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:02:44 --> Total execution time: 0.1915
DEBUG - 2022-06-24 01:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:33:00 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:03:00 --> Total execution time: 0.0475
DEBUG - 2022-06-24 01:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:03:33 --> Total execution time: 0.0674
DEBUG - 2022-06-24 01:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:03:35 --> Total execution time: 0.0737
DEBUG - 2022-06-24 01:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:03:42 --> Total execution time: 0.0824
DEBUG - 2022-06-24 01:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:03:48 --> Total execution time: 0.0588
DEBUG - 2022-06-24 01:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:05:11 --> Total execution time: 0.1141
DEBUG - 2022-06-24 01:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:05:14 --> Total execution time: 0.0460
DEBUG - 2022-06-24 01:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:05:30 --> Total execution time: 0.0626
DEBUG - 2022-06-24 01:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:05:57 --> Total execution time: 0.0538
DEBUG - 2022-06-24 01:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:05:59 --> Total execution time: 0.0540
DEBUG - 2022-06-24 01:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:06:12 --> Total execution time: 0.0470
DEBUG - 2022-06-24 01:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:06:16 --> Total execution time: 0.0754
DEBUG - 2022-06-24 01:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:37:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 01:37:46 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 01:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:38:58 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:08:58 --> Total execution time: 0.0452
DEBUG - 2022-06-24 01:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:39:34 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:09:34 --> Total execution time: 0.0355
DEBUG - 2022-06-24 01:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:40:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 01:40:11 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 01:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:11:17 --> Total execution time: 0.0455
DEBUG - 2022-06-24 01:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:11:34 --> Total execution time: 0.0515
DEBUG - 2022-06-24 01:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:41:38 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:11:38 --> Total execution time: 0.1454
DEBUG - 2022-06-24 01:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:11:41 --> Total execution time: 0.0955
DEBUG - 2022-06-24 01:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:11:52 --> Total execution time: 0.0611
DEBUG - 2022-06-24 01:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:12:05 --> Total execution time: 0.0805
DEBUG - 2022-06-24 01:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:12:08 --> Total execution time: 0.0521
DEBUG - 2022-06-24 01:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:12:09 --> Total execution time: 0.0528
DEBUG - 2022-06-24 01:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 01:42:12 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 01:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:12:12 --> Total execution time: 0.0402
DEBUG - 2022-06-24 01:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:12:12 --> Total execution time: 0.0401
DEBUG - 2022-06-24 01:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:12:24 --> Total execution time: 0.1090
DEBUG - 2022-06-24 01:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:42:48 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:12:48 --> Total execution time: 0.0422
DEBUG - 2022-06-24 01:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:12:59 --> Total execution time: 0.0590
DEBUG - 2022-06-24 01:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:13:02 --> Total execution time: 0.0468
DEBUG - 2022-06-24 01:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:13:24 --> Total execution time: 0.0610
DEBUG - 2022-06-24 01:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:13:53 --> Total execution time: 0.0484
DEBUG - 2022-06-24 01:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:13:57 --> Total execution time: 0.0511
DEBUG - 2022-06-24 01:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:15:09 --> Total execution time: 0.0433
DEBUG - 2022-06-24 01:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:15:16 --> Total execution time: 0.0423
DEBUG - 2022-06-24 01:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:16:52 --> Total execution time: 0.1202
DEBUG - 2022-06-24 01:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:16:56 --> Total execution time: 0.0457
DEBUG - 2022-06-24 01:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:46:59 --> Total execution time: 0.0702
DEBUG - 2022-06-24 01:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:47:06 --> Total execution time: 0.1114
DEBUG - 2022-06-24 01:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:17:55 --> Total execution time: 0.0641
DEBUG - 2022-06-24 01:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:18:08 --> Total execution time: 0.0696
DEBUG - 2022-06-24 01:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:18:08 --> Total execution time: 0.0537
DEBUG - 2022-06-24 01:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:18:10 --> Total execution time: 0.0630
DEBUG - 2022-06-24 01:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:48:15 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:18:16 --> Total execution time: 0.0358
DEBUG - 2022-06-24 01:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:18:25 --> Total execution time: 0.0321
DEBUG - 2022-06-24 01:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:18:34 --> Total execution time: 0.0656
DEBUG - 2022-06-24 01:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:19:09 --> Total execution time: 0.1180
DEBUG - 2022-06-24 01:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:19:16 --> Total execution time: 0.2144
DEBUG - 2022-06-24 01:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:20:08 --> Total execution time: 0.0609
DEBUG - 2022-06-24 01:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:20:12 --> Total execution time: 0.0495
DEBUG - 2022-06-24 01:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:20:21 --> Total execution time: 0.0457
DEBUG - 2022-06-24 01:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:20:36 --> Total execution time: 0.0477
DEBUG - 2022-06-24 01:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:20:44 --> Total execution time: 0.0795
DEBUG - 2022-06-24 01:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:20:45 --> Total execution time: 0.0533
DEBUG - 2022-06-24 01:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:20:47 --> Total execution time: 0.0451
DEBUG - 2022-06-24 01:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:21:01 --> Total execution time: 0.0695
DEBUG - 2022-06-24 01:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:21:32 --> Total execution time: 0.0503
DEBUG - 2022-06-24 01:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:21:48 --> Total execution time: 0.0576
DEBUG - 2022-06-24 01:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:22:42 --> Total execution time: 0.1420
DEBUG - 2022-06-24 01:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:52:52 --> Total execution time: 0.0408
DEBUG - 2022-06-24 01:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:52:57 --> Total execution time: 0.1224
DEBUG - 2022-06-24 01:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:22:59 --> Total execution time: 0.0899
DEBUG - 2022-06-24 01:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 01:53:12 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-24 01:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:53:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 01:53:15 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-24 01:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:23:35 --> Total execution time: 0.1168
DEBUG - 2022-06-24 01:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:00 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:24:01 --> Total execution time: 0.0757
DEBUG - 2022-06-24 01:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:54:07 --> Total execution time: 0.0631
DEBUG - 2022-06-24 01:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:07 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:24:07 --> Total execution time: 0.1139
DEBUG - 2022-06-24 01:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:24:09 --> Total execution time: 0.1300
DEBUG - 2022-06-24 01:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:54:09 --> Total execution time: 0.0934
DEBUG - 2022-06-24 01:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:54:09 --> Total execution time: 0.1363
DEBUG - 2022-06-24 01:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:24:21 --> Total execution time: 0.1898
DEBUG - 2022-06-24 01:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:24:28 --> Total execution time: 0.1943
DEBUG - 2022-06-24 01:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:24:44 --> Total execution time: 0.1046
DEBUG - 2022-06-24 01:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:24:48 --> Total execution time: 0.2604
DEBUG - 2022-06-24 01:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:24:56 --> Total execution time: 0.1608
DEBUG - 2022-06-24 01:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:25:29 --> Total execution time: 0.1241
DEBUG - 2022-06-24 01:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:55:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 01:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:25:35 --> Total execution time: 0.2361
DEBUG - 2022-06-24 12:25:36 --> Total execution time: 2.2025
DEBUG - 2022-06-24 01:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:55:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 01:55:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 01:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:25:43 --> Total execution time: 0.1416
DEBUG - 2022-06-24 01:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:55:57 --> Total execution time: 0.0539
DEBUG - 2022-06-24 01:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:56:07 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:26:07 --> Total execution time: 0.0441
DEBUG - 2022-06-24 01:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:56:07 --> Total execution time: 0.0419
DEBUG - 2022-06-24 01:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:56:10 --> Total execution time: 0.0418
DEBUG - 2022-06-24 01:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:26:12 --> Total execution time: 0.0976
DEBUG - 2022-06-24 01:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:26:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 01:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:26:14 --> Total execution time: 0.0494
DEBUG - 2022-06-24 01:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:26:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 12:26:15 --> Total execution time: 0.1330
DEBUG - 2022-06-24 01:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:56:17 --> Total execution time: 0.0431
DEBUG - 2022-06-24 01:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:26:19 --> Total execution time: 0.0964
DEBUG - 2022-06-24 01:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:26:30 --> Total execution time: 0.0582
DEBUG - 2022-06-24 01:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:26:35 --> Total execution time: 0.0470
DEBUG - 2022-06-24 01:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:56:55 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:26:55 --> Total execution time: 0.0357
DEBUG - 2022-06-24 01:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:05 --> Total execution time: 0.1459
DEBUG - 2022-06-24 01:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:10 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:10 --> Total execution time: 0.0336
DEBUG - 2022-06-24 01:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:11 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:11 --> Total execution time: 0.0258
DEBUG - 2022-06-24 01:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:13 --> Total execution time: 0.0477
DEBUG - 2022-06-24 01:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:24 --> Total execution time: 0.0485
DEBUG - 2022-06-24 01:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:27 --> Total execution time: 0.0448
DEBUG - 2022-06-24 01:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:27 --> Total execution time: 0.0900
DEBUG - 2022-06-24 01:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:28 --> Total execution time: 0.0782
DEBUG - 2022-06-24 01:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:28 --> No URI present. Default controller set.
DEBUG - 2022-06-24 01:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:28 --> Total execution time: 0.0646
DEBUG - 2022-06-24 01:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:29 --> Total execution time: 0.0628
DEBUG - 2022-06-24 01:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:34 --> Total execution time: 0.0712
DEBUG - 2022-06-24 01:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:47 --> Total execution time: 0.0699
DEBUG - 2022-06-24 01:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:50 --> Total execution time: 0.1330
DEBUG - 2022-06-24 01:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:55 --> Total execution time: 0.0658
DEBUG - 2022-06-24 01:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 01:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:27:59 --> Total execution time: 0.0517
DEBUG - 2022-06-24 01:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:28:08 --> Total execution time: 0.0627
DEBUG - 2022-06-24 01:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:28:13 --> Total execution time: 0.0777
DEBUG - 2022-06-24 01:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:28:32 --> Total execution time: 0.0886
DEBUG - 2022-06-24 01:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:28:50 --> Total execution time: 0.0559
DEBUG - 2022-06-24 01:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:29:02 --> Total execution time: 0.0492
DEBUG - 2022-06-24 01:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:29:06 --> Total execution time: 0.0516
DEBUG - 2022-06-24 01:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:29:19 --> Total execution time: 0.0540
DEBUG - 2022-06-24 01:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:29:25 --> Total execution time: 0.0545
DEBUG - 2022-06-24 01:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:29:25 --> Total execution time: 0.0528
DEBUG - 2022-06-24 01:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:29:30 --> Total execution time: 0.0606
DEBUG - 2022-06-24 01:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 01:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 01:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:29:38 --> Total execution time: 0.0680
DEBUG - 2022-06-24 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:30:03 --> Total execution time: 0.0820
DEBUG - 2022-06-24 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:30:04 --> Total execution time: 0.0982
DEBUG - 2022-06-24 02:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:30:43 --> Total execution time: 0.0731
DEBUG - 2022-06-24 02:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:30:59 --> Total execution time: 0.0586
DEBUG - 2022-06-24 02:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:31:06 --> Total execution time: 0.0568
DEBUG - 2022-06-24 02:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:31:11 --> Total execution time: 0.1027
DEBUG - 2022-06-24 02:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:31:14 --> Total execution time: 0.0330
DEBUG - 2022-06-24 02:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:31:16 --> Total execution time: 0.0469
DEBUG - 2022-06-24 02:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:31:18 --> Total execution time: 0.0731
DEBUG - 2022-06-24 02:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:31:19 --> Total execution time: 0.0448
DEBUG - 2022-06-24 02:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:31:23 --> Total execution time: 0.0779
DEBUG - 2022-06-24 02:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:31:26 --> Total execution time: 0.0695
DEBUG - 2022-06-24 02:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:31:30 --> Total execution time: 0.0497
DEBUG - 2022-06-24 02:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:31:44 --> Total execution time: 0.0635
DEBUG - 2022-06-24 02:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:31:44 --> Total execution time: 0.0653
DEBUG - 2022-06-24 02:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:31:44 --> Total execution time: 0.0739
DEBUG - 2022-06-24 02:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:31:53 --> Total execution time: 0.0507
DEBUG - 2022-06-24 02:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:33:59 --> Total execution time: 0.0481
DEBUG - 2022-06-24 02:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:04:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 02:04:41 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 02:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:35:04 --> Total execution time: 0.1438
DEBUG - 2022-06-24 02:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:35:07 --> Total execution time: 0.0723
DEBUG - 2022-06-24 02:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:35:18 --> Total execution time: 0.0523
DEBUG - 2022-06-24 02:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:35:19 --> Total execution time: 0.0720
DEBUG - 2022-06-24 02:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:35:23 --> Total execution time: 0.0713
DEBUG - 2022-06-24 02:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:35:27 --> Total execution time: 0.0667
DEBUG - 2022-06-24 02:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:35:40 --> Total execution time: 0.0472
DEBUG - 2022-06-24 02:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:35:47 --> Total execution time: 0.0723
DEBUG - 2022-06-24 02:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:36:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 02:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:36:27 --> Total execution time: 0.0679
DEBUG - 2022-06-24 02:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:37:24 --> Total execution time: 0.0705
DEBUG - 2022-06-24 02:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:38:35 --> Total execution time: 0.0609
DEBUG - 2022-06-24 02:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:38:35 --> Total execution time: 0.0618
DEBUG - 2022-06-24 02:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:38:36 --> Total execution time: 0.0707
DEBUG - 2022-06-24 02:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:38:42 --> Total execution time: 0.0618
DEBUG - 2022-06-24 02:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:38:51 --> Total execution time: 0.0587
DEBUG - 2022-06-24 02:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:38:55 --> Total execution time: 0.1116
DEBUG - 2022-06-24 02:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:39:03 --> Total execution time: 0.0771
DEBUG - 2022-06-24 02:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:09:20 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:39:20 --> Total execution time: 0.0658
DEBUG - 2022-06-24 02:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:39:29 --> Total execution time: 1.5212
DEBUG - 2022-06-24 02:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:39:47 --> Total execution time: 1.4586
DEBUG - 2022-06-24 02:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:40:09 --> Total execution time: 0.1312
DEBUG - 2022-06-24 02:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:40:17 --> Total execution time: 1.5851
DEBUG - 2022-06-24 02:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:40:26 --> Total execution time: 0.0893
DEBUG - 2022-06-24 02:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:40:38 --> Total execution time: 1.5019
DEBUG - 2022-06-24 02:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:11:53 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:41:53 --> Total execution time: 0.1178
DEBUG - 2022-06-24 02:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:41:58 --> Total execution time: 0.0489
DEBUG - 2022-06-24 02:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:12:01 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:42:01 --> Total execution time: 0.0334
DEBUG - 2022-06-24 02:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:12:02 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:42:02 --> Total execution time: 0.0852
DEBUG - 2022-06-24 02:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:42:11 --> Total execution time: 0.0507
DEBUG - 2022-06-24 02:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:42:17 --> Total execution time: 0.0546
DEBUG - 2022-06-24 02:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:42:22 --> Total execution time: 0.0579
DEBUG - 2022-06-24 02:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:12:25 --> Total execution time: 0.0469
DEBUG - 2022-06-24 02:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:12:26 --> Total execution time: 0.0509
DEBUG - 2022-06-24 02:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:12:28 --> Total execution time: 0.0533
DEBUG - 2022-06-24 02:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:12:28 --> Total execution time: 0.0859
DEBUG - 2022-06-24 02:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:42:39 --> Total execution time: 0.0461
DEBUG - 2022-06-24 02:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:13:21 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:43:21 --> Total execution time: 0.0496
DEBUG - 2022-06-24 02:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:43:27 --> Total execution time: 0.0428
DEBUG - 2022-06-24 02:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:43:35 --> Total execution time: 0.0475
DEBUG - 2022-06-24 02:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:43:36 --> Total execution time: 0.0467
DEBUG - 2022-06-24 02:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:43:41 --> Total execution time: 0.0853
DEBUG - 2022-06-24 02:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:14:02 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:44:02 --> Total execution time: 0.0427
DEBUG - 2022-06-24 02:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:14:03 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:44:03 --> Total execution time: 0.0344
DEBUG - 2022-06-24 02:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:14:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:14:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:44:05 --> Total execution time: 0.0363
DEBUG - 2022-06-24 02:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:44:05 --> Total execution time: 0.0424
DEBUG - 2022-06-24 02:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:14:13 --> Total execution time: 0.0460
DEBUG - 2022-06-24 02:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:14:17 --> Total execution time: 0.0472
DEBUG - 2022-06-24 02:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:14:17 --> Total execution time: 0.0910
DEBUG - 2022-06-24 02:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:14:28 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:44:28 --> Total execution time: 0.0469
DEBUG - 2022-06-24 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:14:44 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:44:44 --> Total execution time: 0.0373
DEBUG - 2022-06-24 02:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:44:58 --> Total execution time: 0.0471
DEBUG - 2022-06-24 02:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:45:06 --> Total execution time: 0.0472
DEBUG - 2022-06-24 02:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:15:10 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:45:10 --> Total execution time: 0.0867
DEBUG - 2022-06-24 02:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:45:17 --> Total execution time: 0.0845
DEBUG - 2022-06-24 02:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:15:29 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:45:30 --> Total execution time: 0.0758
DEBUG - 2022-06-24 02:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:45:48 --> Total execution time: 1.9799
DEBUG - 2022-06-24 02:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:15:49 --> Total execution time: 0.0534
DEBUG - 2022-06-24 02:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:47:43 --> Total execution time: 0.0603
DEBUG - 2022-06-24 02:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:19:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 02:19:19 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-24 02:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 02:19:27 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-24 02:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:50:34 --> Total execution time: 1.7350
DEBUG - 2022-06-24 02:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:21:36 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:51:36 --> Total execution time: 0.0467
DEBUG - 2022-06-24 02:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:21:36 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:51:36 --> Total execution time: 0.0317
DEBUG - 2022-06-24 02:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:22:41 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:52:41 --> Total execution time: 0.0392
DEBUG - 2022-06-24 02:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:53:59 --> Total execution time: 0.1270
DEBUG - 2022-06-24 02:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:25:48 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:55:48 --> Total execution time: 0.1251
DEBUG - 2022-06-24 02:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:55:51 --> Total execution time: 1.4775
DEBUG - 2022-06-24 02:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:26:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:56:05 --> Total execution time: 0.0457
DEBUG - 2022-06-24 02:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:57:18 --> Total execution time: 0.0432
DEBUG - 2022-06-24 02:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:30:06 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:00:06 --> Total execution time: 0.1001
DEBUG - 2022-06-24 02:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:00:42 --> Total execution time: 0.0467
DEBUG - 2022-06-24 02:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:30:53 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:00:53 --> Total execution time: 0.0584
DEBUG - 2022-06-24 02:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:00:59 --> Total execution time: 0.1761
DEBUG - 2022-06-24 02:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:01:25 --> Total execution time: 0.0561
DEBUG - 2022-06-24 02:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:02:00 --> Total execution time: 0.0459
DEBUG - 2022-06-24 02:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:35:19 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:05:20 --> Total execution time: 0.1107
DEBUG - 2022-06-24 02:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:06:34 --> Total execution time: 0.0474
DEBUG - 2022-06-24 02:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:07:19 --> Total execution time: 0.1672
DEBUG - 2022-06-24 02:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:09:10 --> Total execution time: 0.0558
DEBUG - 2022-06-24 02:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:09:19 --> Total execution time: 0.0488
DEBUG - 2022-06-24 02:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:09:55 --> Total execution time: 0.0539
DEBUG - 2022-06-24 02:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:10:06 --> Total execution time: 0.0523
DEBUG - 2022-06-24 02:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:41:33 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:11:33 --> Total execution time: 0.0389
DEBUG - 2022-06-24 02:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:11:45 --> Total execution time: 0.0313
DEBUG - 2022-06-24 02:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:41:58 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:11:58 --> Total execution time: 0.0481
DEBUG - 2022-06-24 02:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:12:06 --> Total execution time: 0.0581
DEBUG - 2022-06-24 02:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:12:11 --> Total execution time: 0.0351
DEBUG - 2022-06-24 02:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:14:02 --> Total execution time: 0.0754
DEBUG - 2022-06-24 02:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:14:17 --> Total execution time: 0.0843
DEBUG - 2022-06-24 02:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:44:52 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:14:52 --> Total execution time: 0.0614
DEBUG - 2022-06-24 02:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:45:25 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:15:25 --> Total execution time: 0.0618
DEBUG - 2022-06-24 02:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:15:52 --> Total execution time: 1.9575
DEBUG - 2022-06-24 02:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 02:45:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 02:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:46:21 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:16:21 --> Total execution time: 0.1375
DEBUG - 2022-06-24 02:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:46:32 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:16:32 --> Total execution time: 0.0790
DEBUG - 2022-06-24 02:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:46:33 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:16:33 --> Total execution time: 0.0458
DEBUG - 2022-06-24 02:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:46:48 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:16:48 --> Total execution time: 0.0762
DEBUG - 2022-06-24 02:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:46:49 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:16:49 --> Total execution time: 0.0483
DEBUG - 2022-06-24 02:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:46:51 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:16:51 --> Total execution time: 0.0660
DEBUG - 2022-06-24 02:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:17:00 --> Total execution time: 0.0924
DEBUG - 2022-06-24 02:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:17:09 --> Total execution time: 0.0735
DEBUG - 2022-06-24 02:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:47:21 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:17:22 --> Total execution time: 0.0581
DEBUG - 2022-06-24 02:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:17:34 --> Total execution time: 1.4848
DEBUG - 2022-06-24 02:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:48:02 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:18:02 --> Total execution time: 0.0683
DEBUG - 2022-06-24 02:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:18:06 --> Total execution time: 0.1465
DEBUG - 2022-06-24 02:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:18:12 --> Total execution time: 0.0801
DEBUG - 2022-06-24 02:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:18:19 --> Total execution time: 0.0844
DEBUG - 2022-06-24 02:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:48:39 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:18:39 --> Total execution time: 0.0436
DEBUG - 2022-06-24 02:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:18:49 --> Total execution time: 0.1080
DEBUG - 2022-06-24 02:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:19:56 --> Total execution time: 0.1734
DEBUG - 2022-06-24 02:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:50:22 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:20:22 --> Total execution time: 0.1224
DEBUG - 2022-06-24 02:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:20:25 --> Total execution time: 0.0549
DEBUG - 2022-06-24 02:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:20:33 --> Total execution time: 0.1200
DEBUG - 2022-06-24 02:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:20:37 --> Total execution time: 0.0470
DEBUG - 2022-06-24 02:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:20:43 --> Total execution time: 0.0669
DEBUG - 2022-06-24 02:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:20:46 --> Total execution time: 0.0468
DEBUG - 2022-06-24 02:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:20:47 --> Total execution time: 0.0637
DEBUG - 2022-06-24 02:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:20:50 --> Total execution time: 0.1161
DEBUG - 2022-06-24 02:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:20:51 --> Total execution time: 0.0366
DEBUG - 2022-06-24 02:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:20:58 --> Total execution time: 0.1367
DEBUG - 2022-06-24 02:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:21:38 --> Total execution time: 0.1191
DEBUG - 2022-06-24 02:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:21:49 --> Total execution time: 0.1329
DEBUG - 2022-06-24 02:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:22:06 --> Total execution time: 0.0896
DEBUG - 2022-06-24 02:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:52:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:22:14 --> Total execution time: 0.0434
DEBUG - 2022-06-24 02:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:22:16 --> Total execution time: 0.0477
DEBUG - 2022-06-24 02:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:52:17 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:22:18 --> Total execution time: 0.1716
DEBUG - 2022-06-24 02:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:52:36 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:22:36 --> Total execution time: 0.0535
DEBUG - 2022-06-24 02:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:23:01 --> Total execution time: 0.0590
DEBUG - 2022-06-24 02:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 02:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:23:50 --> Total execution time: 0.0538
DEBUG - 2022-06-24 02:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:24:45 --> Total execution time: 0.0748
DEBUG - 2022-06-24 02:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:24:50 --> Total execution time: 0.1636
DEBUG - 2022-06-24 02:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:25:10 --> Total execution time: 0.0810
DEBUG - 2022-06-24 02:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:25:14 --> Total execution time: 0.0528
DEBUG - 2022-06-24 02:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:25:23 --> Total execution time: 0.0866
DEBUG - 2022-06-24 02:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:25:38 --> Total execution time: 0.0709
DEBUG - 2022-06-24 02:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:56:02 --> No URI present. Default controller set.
DEBUG - 2022-06-24 02:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:26:02 --> Total execution time: 0.0586
DEBUG - 2022-06-24 02:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:26:07 --> Total execution time: 0.0502
DEBUG - 2022-06-24 02:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 02:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:27:09 --> Total execution time: 0.0394
DEBUG - 2022-06-24 02:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:58:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 02:58:19 --> 404 Page Not Found: Wp-admin/admin-ajax.php
DEBUG - 2022-06-24 02:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:58:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 02:58:24 --> 404 Page Not Found: Wp-admin/admin-ajax.php
DEBUG - 2022-06-24 02:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:58:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 02:58:26 --> 404 Page Not Found: Wp-admin/admin-ajax.php
DEBUG - 2022-06-24 02:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:58:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 02:58:29 --> 404 Page Not Found: Wp-admin/admin-ajax.php
DEBUG - 2022-06-24 02:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 02:58:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 02:58:31 --> 404 Page Not Found: Wp-admin/post.php
DEBUG - 2022-06-24 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:30:02 --> Total execution time: 0.0729
DEBUG - 2022-06-24 03:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:01:50 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:31:50 --> Total execution time: 0.1327
DEBUG - 2022-06-24 03:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:32:06 --> Total execution time: 1.6752
DEBUG - 2022-06-24 03:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:32:08 --> Total execution time: 1.7299
DEBUG - 2022-06-24 03:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:32:31 --> Total execution time: 0.0855
DEBUG - 2022-06-24 03:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:32:40 --> Total execution time: 0.1273
DEBUG - 2022-06-24 03:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:32:42 --> Total execution time: 0.0702
DEBUG - 2022-06-24 03:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:34:03 --> Total execution time: 0.0518
DEBUG - 2022-06-24 03:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:04:12 --> Total execution time: 0.0497
DEBUG - 2022-06-24 03:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:04:14 --> Total execution time: 0.0762
DEBUG - 2022-06-24 03:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:04:14 --> Total execution time: 0.1119
DEBUG - 2022-06-24 03:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:34:23 --> Total execution time: 0.0528
DEBUG - 2022-06-24 03:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:04:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:34:40 --> Total execution time: 0.0516
DEBUG - 2022-06-24 03:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:04:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:34:40 --> Total execution time: 0.0338
DEBUG - 2022-06-24 03:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:04:50 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:34:50 --> Total execution time: 0.1113
DEBUG - 2022-06-24 03:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:34:53 --> Total execution time: 0.0582
DEBUG - 2022-06-24 03:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:05:00 --> Total execution time: 0.0544
DEBUG - 2022-06-24 03:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:05:01 --> Total execution time: 0.0522
DEBUG - 2022-06-24 03:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:05:01 --> Total execution time: 0.0965
DEBUG - 2022-06-24 03:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:05:12 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:35:12 --> Total execution time: 0.0517
DEBUG - 2022-06-24 03:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:05:35 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:35:35 --> Total execution time: 0.0478
DEBUG - 2022-06-24 03:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:05:45 --> Total execution time: 0.0492
DEBUG - 2022-06-24 03:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:05:49 --> Total execution time: 0.0446
DEBUG - 2022-06-24 03:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:05:49 --> Total execution time: 0.0965
DEBUG - 2022-06-24 03:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:06:10 --> Total execution time: 0.0771
DEBUG - 2022-06-24 03:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:06:11 --> Total execution time: 0.0567
DEBUG - 2022-06-24 03:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:06:12 --> Total execution time: 0.0843
DEBUG - 2022-06-24 03:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:37:09 --> Total execution time: 0.0346
DEBUG - 2022-06-24 03:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:37:11 --> Total execution time: 0.0579
DEBUG - 2022-06-24 03:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:37:16 --> Total execution time: 0.0461
DEBUG - 2022-06-24 03:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:37:19 --> Total execution time: 0.0457
DEBUG - 2022-06-24 03:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:37:56 --> Total execution time: 0.1317
DEBUG - 2022-06-24 03:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:38:12 --> Total execution time: 0.0543
DEBUG - 2022-06-24 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:08:35 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:38:35 --> Total execution time: 0.0640
DEBUG - 2022-06-24 03:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:08:36 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:38:36 --> Total execution time: 0.0672
DEBUG - 2022-06-24 03:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:38:46 --> Total execution time: 0.0375
DEBUG - 2022-06-24 03:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:38:48 --> Total execution time: 0.0505
DEBUG - 2022-06-24 03:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:38:53 --> Total execution time: 0.0567
DEBUG - 2022-06-24 03:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:38:57 --> Total execution time: 0.0905
DEBUG - 2022-06-24 03:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:38:59 --> Total execution time: 0.0475
DEBUG - 2022-06-24 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:39:02 --> Total execution time: 0.0764
DEBUG - 2022-06-24 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:39:03 --> Total execution time: 0.0997
DEBUG - 2022-06-24 03:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:39:09 --> Total execution time: 0.0494
DEBUG - 2022-06-24 03:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:09:11 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:39:11 --> Total execution time: 0.0395
DEBUG - 2022-06-24 03:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:39:40 --> Total execution time: 0.0560
DEBUG - 2022-06-24 03:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:39:47 --> Total execution time: 0.0430
DEBUG - 2022-06-24 03:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:40:00 --> Total execution time: 0.0490
DEBUG - 2022-06-24 03:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:40:00 --> Total execution time: 0.0865
DEBUG - 2022-06-24 03:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:40:27 --> Total execution time: 0.0495
DEBUG - 2022-06-24 03:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:10:42 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:40:42 --> Total execution time: 0.0625
DEBUG - 2022-06-24 03:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:40:44 --> Total execution time: 0.0459
DEBUG - 2022-06-24 03:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:40:51 --> Total execution time: 0.0582
DEBUG - 2022-06-24 03:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:40:52 --> Total execution time: 0.0466
DEBUG - 2022-06-24 03:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:41:11 --> Total execution time: 0.0556
DEBUG - 2022-06-24 03:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:41:25 --> Total execution time: 0.0506
DEBUG - 2022-06-24 03:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:41:27 --> Total execution time: 0.0470
DEBUG - 2022-06-24 03:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:11:29 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:41:29 --> Total execution time: 0.0485
DEBUG - 2022-06-24 03:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:41:31 --> Total execution time: 0.0732
DEBUG - 2022-06-24 03:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:41:37 --> Total execution time: 0.0472
DEBUG - 2022-06-24 03:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:41:37 --> Total execution time: 0.0828
DEBUG - 2022-06-24 03:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:41:41 --> Total execution time: 0.0884
DEBUG - 2022-06-24 03:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:41:55 --> Total execution time: 0.0745
DEBUG - 2022-06-24 03:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:12:06 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:42:06 --> Total execution time: 0.0390
DEBUG - 2022-06-24 03:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:42:11 --> Total execution time: 0.0741
DEBUG - 2022-06-24 03:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:12:24 --> Total execution time: 0.0753
DEBUG - 2022-06-24 03:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:12:26 --> Total execution time: 0.0505
DEBUG - 2022-06-24 03:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:12:26 --> Total execution time: 0.0907
DEBUG - 2022-06-24 03:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:13:24 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:43:24 --> Total execution time: 0.0741
DEBUG - 2022-06-24 03:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:43:29 --> Total execution time: 0.0407
DEBUG - 2022-06-24 03:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:13:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 03:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:43:41 --> Total execution time: 1.9511
DEBUG - 2022-06-24 03:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:13:42 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:43:42 --> Total execution time: 0.0486
DEBUG - 2022-06-24 03:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:43:44 --> Total execution time: 0.0495
DEBUG - 2022-06-24 03:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:43:46 --> Total execution time: 0.0384
DEBUG - 2022-06-24 03:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:13:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 03:13:53 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 03:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:43:58 --> Total execution time: 0.0594
DEBUG - 2022-06-24 03:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:44:14 --> Total execution time: 0.0592
DEBUG - 2022-06-24 03:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:44:16 --> Total execution time: 0.0547
DEBUG - 2022-06-24 03:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:44:44 --> Total execution time: 0.0571
DEBUG - 2022-06-24 03:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:44:46 --> Total execution time: 0.0659
DEBUG - 2022-06-24 03:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:14:47 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:44:47 --> Total execution time: 0.0606
DEBUG - 2022-06-24 03:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:44:54 --> Total execution time: 0.0667
DEBUG - 2022-06-24 03:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 03:14:57 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-24 03:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:44:59 --> Total execution time: 0.0774
DEBUG - 2022-06-24 03:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:45:05 --> Total execution time: 0.0865
DEBUG - 2022-06-24 03:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:45:05 --> Total execution time: 0.0515
DEBUG - 2022-06-24 03:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:45:12 --> Total execution time: 0.1560
DEBUG - 2022-06-24 03:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:45:16 --> Total execution time: 0.0944
DEBUG - 2022-06-24 03:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:15:18 --> Total execution time: 0.0466
DEBUG - 2022-06-24 03:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:18 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:45:18 --> Total execution time: 0.0410
DEBUG - 2022-06-24 03:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:45:19 --> Total execution time: 0.0766
DEBUG - 2022-06-24 03:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:45:23 --> Total execution time: 0.0930
DEBUG - 2022-06-24 03:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:15:37 --> Total execution time: 0.0478
DEBUG - 2022-06-24 03:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:45:42 --> Total execution time: 0.0486
DEBUG - 2022-06-24 03:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:15:45 --> Total execution time: 0.0544
DEBUG - 2022-06-24 03:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:49 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:45:49 --> Total execution time: 0.0484
DEBUG - 2022-06-24 03:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:45:52 --> Total execution time: 0.0482
DEBUG - 2022-06-24 03:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:45:56 --> Total execution time: 0.0757
DEBUG - 2022-06-24 03:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:15:59 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:45:59 --> Total execution time: 0.0605
DEBUG - 2022-06-24 03:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:16:00 --> Total execution time: 0.0552
DEBUG - 2022-06-24 03:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:04 --> Total execution time: 0.0708
DEBUG - 2022-06-24 03:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:16:05 --> Total execution time: 0.0490
DEBUG - 2022-06-24 03:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:09 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:09 --> Total execution time: 0.0533
DEBUG - 2022-06-24 03:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:11 --> Total execution time: 0.0527
DEBUG - 2022-06-24 03:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:12 --> Total execution time: 0.0588
DEBUG - 2022-06-24 03:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:12 --> Total execution time: 0.0470
DEBUG - 2022-06-24 03:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:12 --> Total execution time: 0.0574
DEBUG - 2022-06-24 03:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 03:16:20 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 03:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:22 --> Total execution time: 0.0614
DEBUG - 2022-06-24 03:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:24 --> Total execution time: 0.0492
DEBUG - 2022-06-24 03:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:28 --> Total execution time: 0.0660
DEBUG - 2022-06-24 03:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:16:28 --> Total execution time: 0.1697
DEBUG - 2022-06-24 03:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:16:29 --> Total execution time: 0.0596
DEBUG - 2022-06-24 03:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:16:30 --> Total execution time: 0.0484
DEBUG - 2022-06-24 03:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:16:31 --> Total execution time: 0.0768
DEBUG - 2022-06-24 03:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:33 --> Total execution time: 0.0529
DEBUG - 2022-06-24 03:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:33 --> Total execution time: 0.0796
DEBUG - 2022-06-24 03:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:41 --> Total execution time: 0.0880
DEBUG - 2022-06-24 03:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:44 --> Total execution time: 0.0577
DEBUG - 2022-06-24 03:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:46 --> Total execution time: 0.0519
DEBUG - 2022-06-24 03:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:47 --> Total execution time: 0.0511
DEBUG - 2022-06-24 03:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:51 --> Total execution time: 0.0519
DEBUG - 2022-06-24 03:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:51 --> Total execution time: 0.0540
DEBUG - 2022-06-24 03:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:51 --> Total execution time: 0.0897
DEBUG - 2022-06-24 03:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:59 --> Total execution time: 0.0443
DEBUG - 2022-06-24 03:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:46:59 --> Total execution time: 0.0825
DEBUG - 2022-06-24 03:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:47:06 --> Total execution time: 0.0569
DEBUG - 2022-06-24 03:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:17:15 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:47:16 --> Total execution time: 0.0855
DEBUG - 2022-06-24 03:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:17:24 --> Total execution time: 0.0491
DEBUG - 2022-06-24 03:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:17:24 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:47:24 --> Total execution time: 0.0512
DEBUG - 2022-06-24 03:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:17:26 --> Total execution time: 0.0471
DEBUG - 2022-06-24 03:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:17:26 --> Total execution time: 0.0515
DEBUG - 2022-06-24 03:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:17:39 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:47:39 --> Total execution time: 0.0808
DEBUG - 2022-06-24 03:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:47:45 --> Total execution time: 0.0525
DEBUG - 2022-06-24 03:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:18:00 --> Total execution time: 0.0715
DEBUG - 2022-06-24 03:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:18:01 --> Total execution time: 0.1198
DEBUG - 2022-06-24 03:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:18:01 --> Total execution time: 0.1319
DEBUG - 2022-06-24 03:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:48:08 --> Total execution time: 0.0635
DEBUG - 2022-06-24 03:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:48:13 --> Total execution time: 0.0575
DEBUG - 2022-06-24 03:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:48:17 --> Total execution time: 0.0545
DEBUG - 2022-06-24 03:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 03:18:29 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 03:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:48:46 --> Total execution time: 0.0777
DEBUG - 2022-06-24 03:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:18:56 --> Total execution time: 0.0553
DEBUG - 2022-06-24 03:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:18:57 --> Total execution time: 0.0495
DEBUG - 2022-06-24 03:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:18:58 --> Total execution time: 0.0577
DEBUG - 2022-06-24 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:19:00 --> Total execution time: 0.0532
DEBUG - 2022-06-24 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:19:01 --> Total execution time: 0.0773
DEBUG - 2022-06-24 03:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:19:01 --> Total execution time: 0.1501
DEBUG - 2022-06-24 03:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:19:12 --> Total execution time: 0.0578
DEBUG - 2022-06-24 03:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:19:14 --> Total execution time: 0.0506
DEBUG - 2022-06-24 03:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:19:14 --> Total execution time: 0.0972
DEBUG - 2022-06-24 03:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:49:20 --> Total execution time: 0.0632
DEBUG - 2022-06-24 03:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:49:23 --> Total execution time: 0.1336
DEBUG - 2022-06-24 03:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:49:25 --> Total execution time: 0.0463
DEBUG - 2022-06-24 03:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:49:28 --> Total execution time: 0.0523
DEBUG - 2022-06-24 03:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:49:31 --> Total execution time: 0.0546
DEBUG - 2022-06-24 03:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:49:37 --> Total execution time: 0.0550
DEBUG - 2022-06-24 03:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:19:52 --> Total execution time: 0.0662
DEBUG - 2022-06-24 03:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:19:53 --> Total execution time: 0.0533
DEBUG - 2022-06-24 03:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:19:54 --> Total execution time: 0.0675
DEBUG - 2022-06-24 03:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:49:58 --> Total execution time: 0.0440
DEBUG - 2022-06-24 03:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:19:58 --> Total execution time: 0.0515
DEBUG - 2022-06-24 03:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:19:59 --> Total execution time: 0.0720
DEBUG - 2022-06-24 03:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:20:00 --> Total execution time: 0.0467
DEBUG - 2022-06-24 03:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:50:22 --> Total execution time: 0.0521
DEBUG - 2022-06-24 03:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:50:26 --> Total execution time: 0.1457
DEBUG - 2022-06-24 03:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:50:29 --> Total execution time: 0.0506
DEBUG - 2022-06-24 03:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:50:37 --> Total execution time: 0.1013
DEBUG - 2022-06-24 03:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:51:11 --> Total execution time: 0.1108
DEBUG - 2022-06-24 03:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:51:42 --> Total execution time: 0.1227
DEBUG - 2022-06-24 03:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:51:52 --> Total execution time: 0.1530
DEBUG - 2022-06-24 03:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:52:18 --> Total execution time: 0.1415
DEBUG - 2022-06-24 03:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:22:29 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:52:29 --> Total execution time: 0.0846
DEBUG - 2022-06-24 03:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:52:36 --> Total execution time: 0.0443
DEBUG - 2022-06-24 03:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:52:42 --> Total execution time: 0.0525
DEBUG - 2022-06-24 03:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:52:45 --> Total execution time: 0.0526
DEBUG - 2022-06-24 03:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:52:54 --> Total execution time: 0.1083
DEBUG - 2022-06-24 03:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:23:11 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:53:11 --> Total execution time: 0.0587
DEBUG - 2022-06-24 03:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:53:22 --> Total execution time: 0.0554
DEBUG - 2022-06-24 03:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:53:26 --> Total execution time: 0.0547
DEBUG - 2022-06-24 03:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:23:31 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:53:32 --> Total execution time: 0.0606
DEBUG - 2022-06-24 03:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:23:48 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:53:48 --> Total execution time: 0.0818
DEBUG - 2022-06-24 03:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:23:54 --> Total execution time: 0.0501
DEBUG - 2022-06-24 03:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:23:57 --> Total execution time: 0.0499
DEBUG - 2022-06-24 03:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:23:57 --> Total execution time: 0.0864
DEBUG - 2022-06-24 03:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:54:03 --> Total execution time: 0.1465
DEBUG - 2022-06-24 03:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:26:45 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:56:45 --> Total execution time: 0.1171
DEBUG - 2022-06-24 03:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:56:53 --> Total execution time: 0.0402
DEBUG - 2022-06-24 03:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:57:01 --> Total execution time: 0.0652
DEBUG - 2022-06-24 03:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:27:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 03:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:57:11 --> Total execution time: 1.6193
DEBUG - 2022-06-24 03:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 03:27:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 03:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:57:14 --> Total execution time: 0.0603
DEBUG - 2022-06-24 03:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:57:24 --> Total execution time: 0.0547
DEBUG - 2022-06-24 03:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:58:11 --> Total execution time: 0.0650
DEBUG - 2022-06-24 03:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:58:33 --> Total execution time: 0.1725
DEBUG - 2022-06-24 03:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:59:09 --> Total execution time: 0.0982
DEBUG - 2022-06-24 03:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:59:25 --> Total execution time: 0.0643
DEBUG - 2022-06-24 03:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:29:51 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:59:51 --> Total execution time: 0.0413
DEBUG - 2022-06-24 03:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:59:56 --> Total execution time: 0.0622
DEBUG - 2022-06-24 03:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:00:01 --> Total execution time: 0.0552
DEBUG - 2022-06-24 03:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:00:04 --> Total execution time: 0.0757
DEBUG - 2022-06-24 03:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:30:21 --> Total execution time: 0.1327
DEBUG - 2022-06-24 03:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:00:22 --> Total execution time: 0.0544
DEBUG - 2022-06-24 03:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:30:23 --> Total execution time: 0.0718
DEBUG - 2022-06-24 03:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:30:23 --> Total execution time: 0.1068
DEBUG - 2022-06-24 03:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:00:31 --> Total execution time: 0.0580
DEBUG - 2022-06-24 03:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:00:33 --> Total execution time: 0.0665
DEBUG - 2022-06-24 03:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:30:51 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:00:51 --> Total execution time: 0.0344
DEBUG - 2022-06-24 03:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:03:10 --> Total execution time: 0.1824
DEBUG - 2022-06-24 03:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:03:42 --> Total execution time: 0.0643
DEBUG - 2022-06-24 03:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:05:27 --> Total execution time: 0.2655
DEBUG - 2022-06-24 03:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:36:42 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:06:42 --> Total execution time: 0.1704
DEBUG - 2022-06-24 03:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:36:54 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:06:54 --> Total execution time: 0.0601
DEBUG - 2022-06-24 03:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:07:07 --> Total execution time: 0.0630
DEBUG - 2022-06-24 03:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:07:15 --> Total execution time: 0.1001
DEBUG - 2022-06-24 03:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:07:19 --> Total execution time: 0.0531
DEBUG - 2022-06-24 03:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:07:22 --> Total execution time: 0.0552
DEBUG - 2022-06-24 03:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:07:32 --> Total execution time: 0.0545
DEBUG - 2022-06-24 03:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:09:48 --> Total execution time: 0.1141
DEBUG - 2022-06-24 03:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 03:41:22 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 03:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:41:35 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:11:35 --> Total execution time: 0.1162
DEBUG - 2022-06-24 03:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:11:37 --> Total execution time: 0.0404
DEBUG - 2022-06-24 03:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:11:55 --> Total execution time: 0.0608
DEBUG - 2022-06-24 03:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:42:15 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:12:15 --> Total execution time: 0.0726
DEBUG - 2022-06-24 03:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:12:30 --> Total execution time: 0.0320
DEBUG - 2022-06-24 03:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:12:39 --> Total execution time: 0.0543
DEBUG - 2022-06-24 03:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:13:13 --> Total execution time: 0.0893
DEBUG - 2022-06-24 03:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:43:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 03:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:13:40 --> Total execution time: 0.1490
DEBUG - 2022-06-24 03:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:13:45 --> Total execution time: 0.0523
DEBUG - 2022-06-24 03:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:13:53 --> Total execution time: 0.1597
DEBUG - 2022-06-24 03:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:14:07 --> Total execution time: 0.0570
DEBUG - 2022-06-24 03:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:15:41 --> Total execution time: 0.1427
DEBUG - 2022-06-24 03:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:17:37 --> Total execution time: 0.0491
DEBUG - 2022-06-24 03:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:17:55 --> Total execution time: 0.0716
DEBUG - 2022-06-24 03:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:18:21 --> Total execution time: 0.1470
DEBUG - 2022-06-24 03:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:18:29 --> Total execution time: 0.0442
DEBUG - 2022-06-24 03:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:20:17 --> Total execution time: 0.1165
DEBUG - 2022-06-24 03:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:22:14 --> Total execution time: 0.0500
DEBUG - 2022-06-24 03:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:22:53 --> Total execution time: 0.1386
DEBUG - 2022-06-24 03:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:22:59 --> Total execution time: 0.0746
DEBUG - 2022-06-24 03:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:24:11 --> Total execution time: 0.0746
DEBUG - 2022-06-24 03:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:24:27 --> Total execution time: 0.0485
DEBUG - 2022-06-24 03:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 03:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:24:28 --> Total execution time: 0.0556
DEBUG - 2022-06-24 03:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:25:17 --> Total execution time: 0.0497
DEBUG - 2022-06-24 03:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:25:31 --> Total execution time: 0.0545
DEBUG - 2022-06-24 03:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 03:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 03:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:29:13 --> Total execution time: 0.1135
DEBUG - 2022-06-24 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:30:02 --> Total execution time: 0.1315
DEBUG - 2022-06-24 04:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:08:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:38:14 --> Total execution time: 0.1959
DEBUG - 2022-06-24 04:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:09:49 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:39:49 --> Total execution time: 0.0773
DEBUG - 2022-06-24 04:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:41:39 --> Total execution time: 0.0505
DEBUG - 2022-06-24 04:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:42:11 --> Total execution time: 0.1648
DEBUG - 2022-06-24 04:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:43:42 --> Total execution time: 0.0491
DEBUG - 2022-06-24 04:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:13:53 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:43:53 --> Total execution time: 0.0500
DEBUG - 2022-06-24 04:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:44:01 --> Total execution time: 0.0896
DEBUG - 2022-06-24 04:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:44:03 --> Total execution time: 0.0591
DEBUG - 2022-06-24 04:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:47:31 --> Total execution time: 0.0826
DEBUG - 2022-06-24 04:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:47:41 --> Total execution time: 0.0473
DEBUG - 2022-06-24 04:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:48:18 --> Total execution time: 0.0693
DEBUG - 2022-06-24 04:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:48:23 --> Total execution time: 0.0441
DEBUG - 2022-06-24 04:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:48:47 --> Total execution time: 0.0644
DEBUG - 2022-06-24 04:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:48:55 --> Total execution time: 0.0872
DEBUG - 2022-06-24 04:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:49:21 --> Total execution time: 0.0668
DEBUG - 2022-06-24 04:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:19:52 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:49:52 --> Total execution time: 0.0545
DEBUG - 2022-06-24 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:21:00 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:51:00 --> Total execution time: 0.0473
DEBUG - 2022-06-24 04:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:53:10 --> Total execution time: 0.0857
DEBUG - 2022-06-24 04:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:53:12 --> Total execution time: 0.0617
DEBUG - 2022-06-24 04:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:53:38 --> Total execution time: 0.0748
DEBUG - 2022-06-24 04:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:23:47 --> Total execution time: 0.0470
DEBUG - 2022-06-24 04:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:53:49 --> Total execution time: 0.0625
DEBUG - 2022-06-24 04:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:53:54 --> Total execution time: 0.0612
DEBUG - 2022-06-24 04:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:53:58 --> Total execution time: 0.0654
DEBUG - 2022-06-24 04:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:55:06 --> Total execution time: 0.0616
DEBUG - 2022-06-24 04:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:55:10 --> Total execution time: 0.0467
DEBUG - 2022-06-24 04:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:55:16 --> Total execution time: 0.0971
DEBUG - 2022-06-24 04:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:26:34 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:56:34 --> Total execution time: 0.0454
DEBUG - 2022-06-24 04:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:01:43 --> Total execution time: 0.2507
DEBUG - 2022-06-24 04:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:02:05 --> Total execution time: 0.0929
DEBUG - 2022-06-24 04:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:32:57 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:02:57 --> Total execution time: 0.0552
DEBUG - 2022-06-24 04:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:03:06 --> Total execution time: 0.0480
DEBUG - 2022-06-24 04:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:03:27 --> Total execution time: 0.0804
DEBUG - 2022-06-24 04:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:03:39 --> Total execution time: 0.0740
DEBUG - 2022-06-24 04:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:03:46 --> Total execution time: 0.0862
DEBUG - 2022-06-24 04:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:04:02 --> Total execution time: 0.1251
DEBUG - 2022-06-24 04:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:04:11 --> Total execution time: 0.0785
DEBUG - 2022-06-24 04:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:40:00 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:10:00 --> Total execution time: 0.2151
DEBUG - 2022-06-24 04:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:40:00 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:10:00 --> Total execution time: 0.0514
DEBUG - 2022-06-24 04:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:40:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:10:14 --> Total execution time: 0.0564
DEBUG - 2022-06-24 04:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:40:29 --> Total execution time: 0.0454
DEBUG - 2022-06-24 04:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:40:31 --> Total execution time: 0.0457
DEBUG - 2022-06-24 04:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:40:31 --> Total execution time: 0.1091
DEBUG - 2022-06-24 04:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:11:00 --> Total execution time: 0.1260
DEBUG - 2022-06-24 04:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:41:03 --> Total execution time: 0.0438
DEBUG - 2022-06-24 04:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:41:04 --> Total execution time: 0.0479
DEBUG - 2022-06-24 04:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:41:04 --> Total execution time: 0.0922
DEBUG - 2022-06-24 04:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:42:08 --> Total execution time: 0.0489
DEBUG - 2022-06-24 04:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:42:10 --> Total execution time: 0.0633
DEBUG - 2022-06-24 04:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:42:10 --> Total execution time: 0.0856
DEBUG - 2022-06-24 04:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:43:26 --> Total execution time: 0.0436
DEBUG - 2022-06-24 04:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:43:28 --> Total execution time: 0.0455
DEBUG - 2022-06-24 04:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:43:28 --> Total execution time: 0.0785
DEBUG - 2022-06-24 04:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:43:39 --> Total execution time: 0.0499
DEBUG - 2022-06-24 04:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:43:40 --> Total execution time: 0.0479
DEBUG - 2022-06-24 04:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:43:40 --> Total execution time: 0.0900
DEBUG - 2022-06-24 04:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:43:41 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:13:41 --> Total execution time: 0.0482
DEBUG - 2022-06-24 04:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 04:44:11 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-24 04:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:44:20 --> Total execution time: 0.0555
DEBUG - 2022-06-24 04:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:44:21 --> Total execution time: 0.0501
DEBUG - 2022-06-24 04:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:44:21 --> Total execution time: 0.0614
DEBUG - 2022-06-24 04:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:44:26 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:14:26 --> Total execution time: 0.0468
DEBUG - 2022-06-24 04:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:44:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 04:44:27 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-24 04:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:45:00 --> Total execution time: 0.0683
DEBUG - 2022-06-24 04:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:45:02 --> Total execution time: 0.1045
DEBUG - 2022-06-24 04:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:45:02 --> Total execution time: 0.1281
DEBUG - 2022-06-24 04:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:46:02 --> Total execution time: 0.0574
DEBUG - 2022-06-24 04:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:46:04 --> Total execution time: 0.0620
DEBUG - 2022-06-24 04:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:46:04 --> Total execution time: 0.0985
DEBUG - 2022-06-24 04:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:46:47 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:16:47 --> Total execution time: 0.0387
DEBUG - 2022-06-24 04:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:46:54 --> Total execution time: 0.0508
DEBUG - 2022-06-24 04:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:46:55 --> Total execution time: 0.0580
DEBUG - 2022-06-24 04:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:46:55 --> Total execution time: 0.1108
DEBUG - 2022-06-24 04:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:47:59 --> Total execution time: 0.0329
DEBUG - 2022-06-24 04:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:48:01 --> Total execution time: 0.0815
DEBUG - 2022-06-24 04:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:48:01 --> Total execution time: 0.1307
DEBUG - 2022-06-24 04:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:48:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 04:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:18:44 --> Total execution time: 1.9658
DEBUG - 2022-06-24 04:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:19:19 --> Total execution time: 0.0630
DEBUG - 2022-06-24 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:49:21 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:19:21 --> Total execution time: 0.0577
DEBUG - 2022-06-24 04:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:20:02 --> Total execution time: 0.1849
DEBUG - 2022-06-24 04:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 04:51:13 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 04:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:22:31 --> Total execution time: 0.1888
DEBUG - 2022-06-24 04:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:22:46 --> Total execution time: 0.0559
DEBUG - 2022-06-24 04:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:23:02 --> Total execution time: 0.0872
DEBUG - 2022-06-24 04:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:23:04 --> Total execution time: 0.0498
DEBUG - 2022-06-24 04:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:23:06 --> Total execution time: 0.0701
DEBUG - 2022-06-24 04:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:23:09 --> Total execution time: 0.0648
DEBUG - 2022-06-24 04:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:23:11 --> Total execution time: 0.0547
DEBUG - 2022-06-24 04:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:53:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:23:14 --> Total execution time: 0.1073
DEBUG - 2022-06-24 04:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:53:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 04:53:21 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 04:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:53:34 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:23:34 --> Total execution time: 0.1474
DEBUG - 2022-06-24 04:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:23:50 --> Total execution time: 0.0484
DEBUG - 2022-06-24 04:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:53:57 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:23:57 --> Total execution time: 0.0407
DEBUG - 2022-06-24 04:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:23:59 --> Total execution time: 0.0462
DEBUG - 2022-06-24 04:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:24:00 --> Total execution time: 0.0521
DEBUG - 2022-06-24 04:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:24:05 --> Total execution time: 0.0748
DEBUG - 2022-06-24 04:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:24:08 --> Total execution time: 0.0440
DEBUG - 2022-06-24 04:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:54:08 --> Total execution time: 0.0526
DEBUG - 2022-06-24 04:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:54:12 --> Total execution time: 0.0727
DEBUG - 2022-06-24 04:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:54:12 --> Total execution time: 0.1050
DEBUG - 2022-06-24 04:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:24:21 --> Total execution time: 0.0665
DEBUG - 2022-06-24 04:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:55:10 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:25:10 --> Total execution time: 0.0365
DEBUG - 2022-06-24 04:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:55:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 04:55:26 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 04:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:55:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 04:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:25:41 --> Total execution time: 1.4516
DEBUG - 2022-06-24 04:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:55:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 04:55:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 04:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:25:59 --> Total execution time: 0.0515
DEBUG - 2022-06-24 04:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:26:07 --> Total execution time: 0.0493
DEBUG - 2022-06-24 04:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:26:15 --> Total execution time: 0.0491
DEBUG - 2022-06-24 04:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:26:23 --> Total execution time: 0.0904
DEBUG - 2022-06-24 04:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 04:56:30 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-24 04:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:26:33 --> Total execution time: 0.0447
DEBUG - 2022-06-24 04:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:26:36 --> Total execution time: 0.0437
DEBUG - 2022-06-24 04:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:26:55 --> Total execution time: 0.0479
DEBUG - 2022-06-24 04:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:57:46 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:27:46 --> Total execution time: 0.0343
DEBUG - 2022-06-24 04:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:27:50 --> Total execution time: 0.1272
DEBUG - 2022-06-24 04:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:28:13 --> Total execution time: 0.0766
DEBUG - 2022-06-24 04:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:58:21 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:28:21 --> Total execution time: 0.0483
DEBUG - 2022-06-24 04:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:28:24 --> Total execution time: 0.0419
DEBUG - 2022-06-24 04:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:28:32 --> Total execution time: 0.0455
DEBUG - 2022-06-24 04:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:28:33 --> Total execution time: 0.0307
DEBUG - 2022-06-24 04:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:28:48 --> Total execution time: 0.0465
DEBUG - 2022-06-24 04:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:28:52 --> Total execution time: 0.0547
DEBUG - 2022-06-24 04:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:58:58 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:28:58 --> Total execution time: 0.0405
DEBUG - 2022-06-24 04:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:28:58 --> Total execution time: 0.0536
DEBUG - 2022-06-24 04:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:58:59 --> No URI present. Default controller set.
DEBUG - 2022-06-24 04:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:28:59 --> Total execution time: 0.0403
DEBUG - 2022-06-24 04:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:00 --> Total execution time: 0.0732
DEBUG - 2022-06-24 04:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 04:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:01 --> Total execution time: 0.0492
DEBUG - 2022-06-24 04:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:08 --> Total execution time: 0.0372
DEBUG - 2022-06-24 04:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:12 --> Total execution time: 0.1039
DEBUG - 2022-06-24 04:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 04:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:13 --> Total execution time: 0.0563
DEBUG - 2022-06-24 04:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:26 --> Total execution time: 0.0533
DEBUG - 2022-06-24 04:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:31 --> Total execution time: 0.0891
DEBUG - 2022-06-24 04:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:40 --> Total execution time: 0.0933
DEBUG - 2022-06-24 04:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:47 --> Total execution time: 0.0485
DEBUG - 2022-06-24 04:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:48 --> Total execution time: 0.0610
DEBUG - 2022-06-24 04:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:48 --> Total execution time: 0.0470
DEBUG - 2022-06-24 04:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 04:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:50 --> Total execution time: 0.0648
DEBUG - 2022-06-24 04:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:56 --> Total execution time: 0.0384
DEBUG - 2022-06-24 04:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 04:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 04:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:29:58 --> Total execution time: 0.0553
DEBUG - 2022-06-24 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:30:02 --> Total execution time: 0.0566
DEBUG - 2022-06-24 05:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:30:06 --> Total execution time: 0.1075
DEBUG - 2022-06-24 05:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:30:06 --> Total execution time: 0.0988
DEBUG - 2022-06-24 05:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:30:07 --> Total execution time: 0.1183
DEBUG - 2022-06-24 05:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:30:13 --> Total execution time: 0.0498
DEBUG - 2022-06-24 05:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:30:16 --> Total execution time: 0.0900
DEBUG - 2022-06-24 05:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:30:23 --> Total execution time: 0.0489
DEBUG - 2022-06-24 05:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:30:23 --> Total execution time: 0.1158
DEBUG - 2022-06-24 05:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:30:29 --> Total execution time: 0.0687
DEBUG - 2022-06-24 05:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:30:31 --> Total execution time: 0.0841
DEBUG - 2022-06-24 05:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:30:33 --> Total execution time: 0.0531
DEBUG - 2022-06-24 05:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:30:36 --> Total execution time: 0.0551
DEBUG - 2022-06-24 05:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:00:42 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:30:43 --> Total execution time: 0.0368
DEBUG - 2022-06-24 05:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:01:32 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:31:32 --> Total execution time: 0.0456
DEBUG - 2022-06-24 05:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:02:02 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:32:02 --> Total execution time: 0.0476
DEBUG - 2022-06-24 05:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:02:03 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:32:03 --> Total execution time: 0.0401
DEBUG - 2022-06-24 05:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 15:32:18 --> Total execution time: 31.4841
DEBUG - 2022-06-24 05:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:32:19 --> Total execution time: 2.6571
DEBUG - 2022-06-24 05:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:02:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 05:02:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 05:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:02:54 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:32:54 --> Total execution time: 0.0408
DEBUG - 2022-06-24 05:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:02 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:33:03 --> Total execution time: 0.0576
DEBUG - 2022-06-24 05:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:03 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:33:03 --> Total execution time: 0.0383
DEBUG - 2022-06-24 05:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:03:04 --> Total execution time: 0.0618
DEBUG - 2022-06-24 05:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:03:06 --> Total execution time: 0.0924
DEBUG - 2022-06-24 05:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:03:06 --> Total execution time: 0.1604
DEBUG - 2022-06-24 05:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:33:06 --> Total execution time: 0.0742
DEBUG - 2022-06-24 05:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:33:09 --> Total execution time: 0.0709
DEBUG - 2022-06-24 05:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:09 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:33:09 --> Total execution time: 0.0507
DEBUG - 2022-06-24 05:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:33:18 --> Total execution time: 0.1506
DEBUG - 2022-06-24 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:33:20 --> Total execution time: 0.0782
DEBUG - 2022-06-24 15:33:21 --> Total execution time: 1.5117
DEBUG - 2022-06-24 05:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 05:03:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 05:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:03:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 05:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:03:44 --> Total execution time: 0.0755
DEBUG - 2022-06-24 15:33:45 --> Total execution time: 1.5223
DEBUG - 2022-06-24 05:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:03:48 --> Total execution time: 0.1068
DEBUG - 2022-06-24 05:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 05:03:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 05:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:33:53 --> Total execution time: 0.1348
DEBUG - 2022-06-24 05:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:33:53 --> Total execution time: 0.0684
DEBUG - 2022-06-24 05:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:33:57 --> Total execution time: 0.0794
DEBUG - 2022-06-24 05:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:04:03 --> Total execution time: 0.0736
DEBUG - 2022-06-24 05:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:04:15 --> Total execution time: 0.0518
DEBUG - 2022-06-24 05:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:04:30 --> Total execution time: 0.0673
DEBUG - 2022-06-24 05:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:04:32 --> Total execution time: 0.0600
DEBUG - 2022-06-24 05:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:04:35 --> Total execution time: 0.0638
DEBUG - 2022-06-24 05:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:34:37 --> Total execution time: 0.0784
DEBUG - 2022-06-24 05:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:34:43 --> Total execution time: 0.0670
DEBUG - 2022-06-24 05:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:34:46 --> Total execution time: 0.0843
DEBUG - 2022-06-24 05:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:34:49 --> Total execution time: 0.0645
DEBUG - 2022-06-24 05:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:35:04 --> Total execution time: 0.1862
DEBUG - 2022-06-24 05:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:35:16 --> Total execution time: 0.2766
DEBUG - 2022-06-24 05:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:35:25 --> Total execution time: 0.0356
DEBUG - 2022-06-24 05:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:05:27 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:35:27 --> Total execution time: 0.0335
DEBUG - 2022-06-24 05:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:05:28 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:35:28 --> Total execution time: 0.0374
DEBUG - 2022-06-24 05:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:35:51 --> Total execution time: 0.0612
DEBUG - 2022-06-24 05:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:35:53 --> Total execution time: 0.1024
DEBUG - 2022-06-24 05:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:35:53 --> Total execution time: 0.0565
DEBUG - 2022-06-24 05:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:35:56 --> Total execution time: 0.0558
DEBUG - 2022-06-24 05:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:35:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 05:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:00 --> Total execution time: 0.0556
DEBUG - 2022-06-24 05:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:00 --> Total execution time: 0.0557
DEBUG - 2022-06-24 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 15:36:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 15:36:03 --> Total execution time: 0.2074
DEBUG - 2022-06-24 05:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:04 --> Total execution time: 0.0531
DEBUG - 2022-06-24 05:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:06:12 --> Total execution time: 0.0519
DEBUG - 2022-06-24 05:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:15 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:15 --> Total execution time: 0.1094
DEBUG - 2022-06-24 05:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:17 --> Total execution time: 0.0494
DEBUG - 2022-06-24 05:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:19 --> Total execution time: 0.0553
DEBUG - 2022-06-24 05:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:25 --> Total execution time: 0.0835
DEBUG - 2022-06-24 05:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:28 --> Total execution time: 0.0532
DEBUG - 2022-06-24 05:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:34 --> Total execution time: 0.0763
DEBUG - 2022-06-24 05:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:35 --> Total execution time: 0.0530
DEBUG - 2022-06-24 05:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:37 --> Total execution time: 0.0855
DEBUG - 2022-06-24 05:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:39 --> Total execution time: 0.0493
DEBUG - 2022-06-24 05:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:41 --> Total execution time: 0.0597
DEBUG - 2022-06-24 05:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:42 --> Total execution time: 0.0672
DEBUG - 2022-06-24 05:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:50 --> Total execution time: 0.0898
DEBUG - 2022-06-24 05:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:53 --> Total execution time: 0.0484
DEBUG - 2022-06-24 05:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:55 --> Total execution time: 0.0526
DEBUG - 2022-06-24 05:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:57 --> Total execution time: 0.0632
DEBUG - 2022-06-24 05:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:36:58 --> Total execution time: 0.0622
DEBUG - 2022-06-24 05:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:37:22 --> Total execution time: 0.0796
DEBUG - 2022-06-24 05:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:07:31 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:37:31 --> Total execution time: 0.0453
DEBUG - 2022-06-24 05:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:37:31 --> Total execution time: 0.0605
DEBUG - 2022-06-24 05:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:37:36 --> Total execution time: 0.0551
DEBUG - 2022-06-24 05:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:37:39 --> Total execution time: 0.0661
DEBUG - 2022-06-24 05:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:37:43 --> Total execution time: 0.0643
DEBUG - 2022-06-24 05:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:37:46 --> Total execution time: 0.0493
DEBUG - 2022-06-24 05:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:37:47 --> Total execution time: 0.0455
DEBUG - 2022-06-24 05:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:37:50 --> Total execution time: 1.8788
DEBUG - 2022-06-24 05:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:08:04 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:38:04 --> Total execution time: 0.0571
DEBUG - 2022-06-24 05:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:08:12 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:38:12 --> Total execution time: 0.0552
DEBUG - 2022-06-24 05:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:38:13 --> Total execution time: 0.0461
DEBUG - 2022-06-24 05:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:38:16 --> Total execution time: 0.0562
DEBUG - 2022-06-24 05:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:38:21 --> Total execution time: 1.5807
DEBUG - 2022-06-24 05:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:38:50 --> Total execution time: 1.5442
DEBUG - 2022-06-24 15:38:50 --> Total execution time: 0.1262
DEBUG - 2022-06-24 05:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:08:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 05:08:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 05:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:08:56 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:38:56 --> Total execution time: 0.0960
DEBUG - 2022-06-24 05:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:08:58 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:38:58 --> Total execution time: 0.0456
DEBUG - 2022-06-24 05:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:06 --> Total execution time: 0.0491
DEBUG - 2022-06-24 05:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:12 --> Total execution time: 0.0467
DEBUG - 2022-06-24 05:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:16 --> Total execution time: 0.0470
DEBUG - 2022-06-24 05:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:18 --> Total execution time: 0.0589
DEBUG - 2022-06-24 05:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:23 --> Total execution time: 0.0611
DEBUG - 2022-06-24 05:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:27 --> Total execution time: 0.0747
DEBUG - 2022-06-24 05:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:28 --> Total execution time: 0.0385
DEBUG - 2022-06-24 05:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:35 --> Total execution time: 0.1298
DEBUG - 2022-06-24 05:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:42 --> Total execution time: 0.0781
DEBUG - 2022-06-24 05:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:45 --> Total execution time: 0.0771
DEBUG - 2022-06-24 05:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:46 --> Total execution time: 0.0688
DEBUG - 2022-06-24 05:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:49 --> Total execution time: 0.0781
DEBUG - 2022-06-24 05:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:52 --> Total execution time: 0.0545
DEBUG - 2022-06-24 05:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:58 --> Total execution time: 0.0607
DEBUG - 2022-06-24 05:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:39:59 --> Total execution time: 0.0532
DEBUG - 2022-06-24 05:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:40:09 --> Total execution time: 0.0546
DEBUG - 2022-06-24 05:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:40:13 --> Total execution time: 0.0598
DEBUG - 2022-06-24 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:10:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:40:14 --> Total execution time: 0.1241
DEBUG - 2022-06-24 05:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:10:37 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:40:37 --> Total execution time: 0.0711
DEBUG - 2022-06-24 05:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:10:50 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:40:50 --> Total execution time: 0.0485
DEBUG - 2022-06-24 05:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:40:54 --> Total execution time: 0.0431
DEBUG - 2022-06-24 05:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:40:56 --> Total execution time: 0.0394
DEBUG - 2022-06-24 05:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:41:00 --> Total execution time: 0.0580
DEBUG - 2022-06-24 05:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:41:03 --> Total execution time: 0.0503
DEBUG - 2022-06-24 05:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:41:06 --> Total execution time: 0.1253
DEBUG - 2022-06-24 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:41:09 --> Total execution time: 0.0560
DEBUG - 2022-06-24 05:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:11:36 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:41:37 --> Total execution time: 0.0374
DEBUG - 2022-06-24 05:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:11:38 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:41:38 --> Total execution time: 0.0499
DEBUG - 2022-06-24 05:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:41:38 --> Total execution time: 0.0469
DEBUG - 2022-06-24 05:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:41:41 --> Total execution time: 0.0516
DEBUG - 2022-06-24 05:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:41:58 --> Total execution time: 0.0563
DEBUG - 2022-06-24 05:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:42:11 --> Total execution time: 0.0602
DEBUG - 2022-06-24 05:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:42:16 --> Total execution time: 0.0539
DEBUG - 2022-06-24 05:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:42:27 --> Total execution time: 0.0580
DEBUG - 2022-06-24 05:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:42:27 --> Total execution time: 0.0616
DEBUG - 2022-06-24 05:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:42:31 --> Total execution time: 0.0805
DEBUG - 2022-06-24 05:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:42:35 --> Total execution time: 0.0535
DEBUG - 2022-06-24 05:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:42:39 --> Total execution time: 0.0712
DEBUG - 2022-06-24 05:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:42:43 --> Total execution time: 0.0634
DEBUG - 2022-06-24 05:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:42:50 --> Total execution time: 0.0538
DEBUG - 2022-06-24 05:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:12:52 --> Total execution time: 0.0351
DEBUG - 2022-06-24 05:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:12:55 --> Total execution time: 0.0986
DEBUG - 2022-06-24 05:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:12:55 --> Total execution time: 0.1513
DEBUG - 2022-06-24 15:42:55 --> Total execution time: 0.1131
DEBUG - 2022-06-24 05:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:12:56 --> Total execution time: 0.0561
DEBUG - 2022-06-24 05:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:42:58 --> Total execution time: 0.0470
DEBUG - 2022-06-24 05:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:43:00 --> Total execution time: 0.0638
DEBUG - 2022-06-24 05:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:43:05 --> Total execution time: 0.0708
DEBUG - 2022-06-24 05:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:43:07 --> Total execution time: 0.0500
DEBUG - 2022-06-24 05:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:43:08 --> Total execution time: 0.0827
DEBUG - 2022-06-24 05:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:43:16 --> Total execution time: 0.1113
DEBUG - 2022-06-24 05:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:43:37 --> Total execution time: 0.0531
DEBUG - 2022-06-24 05:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:13:38 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:43:38 --> Total execution time: 0.0517
DEBUG - 2022-06-24 05:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:14:45 --> Total execution time: 0.0435
DEBUG - 2022-06-24 05:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:44:59 --> Total execution time: 0.0457
DEBUG - 2022-06-24 05:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:45:30 --> Total execution time: 0.0737
DEBUG - 2022-06-24 05:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:45:36 --> Total execution time: 0.0804
DEBUG - 2022-06-24 05:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:45:38 --> Total execution time: 0.0749
DEBUG - 2022-06-24 05:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:15:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:45:40 --> Total execution time: 0.0496
DEBUG - 2022-06-24 05:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:46:00 --> Total execution time: 0.0869
DEBUG - 2022-06-24 05:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:46:00 --> Total execution time: 0.0631
DEBUG - 2022-06-24 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:46:35 --> Total execution time: 0.0510
DEBUG - 2022-06-24 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:47:08 --> Total execution time: 0.1421
DEBUG - 2022-06-24 05:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:47:21 --> Total execution time: 0.0677
DEBUG - 2022-06-24 05:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:47:41 --> Total execution time: 0.0494
DEBUG - 2022-06-24 05:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:47:45 --> Total execution time: 0.0715
DEBUG - 2022-06-24 05:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:47:50 --> Total execution time: 0.0459
DEBUG - 2022-06-24 05:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:47:52 --> Total execution time: 0.0588
DEBUG - 2022-06-24 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:48:05 --> Total execution time: 0.0570
DEBUG - 2022-06-24 05:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:18:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 05:18:35 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 05:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:48:57 --> Total execution time: 0.1080
DEBUG - 2022-06-24 05:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:19:01 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:49:01 --> Total execution time: 0.0711
DEBUG - 2022-06-24 05:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:49:02 --> Total execution time: 0.0620
DEBUG - 2022-06-24 05:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:49:18 --> Total execution time: 0.0743
DEBUG - 2022-06-24 05:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:49:20 --> Total execution time: 0.0845
DEBUG - 2022-06-24 05:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:49:24 --> Total execution time: 0.0859
DEBUG - 2022-06-24 05:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:19:26 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:49:26 --> Total execution time: 0.0611
DEBUG - 2022-06-24 05:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:49:34 --> Total execution time: 0.0509
DEBUG - 2022-06-24 05:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:19:37 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:49:37 --> Total execution time: 0.0501
DEBUG - 2022-06-24 05:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:49:54 --> Total execution time: 0.0591
DEBUG - 2022-06-24 05:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:50:16 --> Total execution time: 0.0614
DEBUG - 2022-06-24 05:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:50:26 --> Total execution time: 0.1384
DEBUG - 2022-06-24 05:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:50:26 --> Total execution time: 0.0530
DEBUG - 2022-06-24 05:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:50:28 --> Total execution time: 0.0977
DEBUG - 2022-06-24 05:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:20:28 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:50:28 --> Total execution time: 0.0341
DEBUG - 2022-06-24 05:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:20:28 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:50:28 --> Total execution time: 0.0481
DEBUG - 2022-06-24 05:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:20:37 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:50:37 --> Total execution time: 0.0505
DEBUG - 2022-06-24 05:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:50:40 --> Total execution time: 0.0825
DEBUG - 2022-06-24 05:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:20:45 --> Total execution time: 0.0443
DEBUG - 2022-06-24 05:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:20:47 --> Total execution time: 0.0614
DEBUG - 2022-06-24 05:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:20:47 --> Total execution time: 0.1194
DEBUG - 2022-06-24 05:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:20:58 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:50:58 --> Total execution time: 0.0636
DEBUG - 2022-06-24 05:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:20:59 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:50:59 --> Total execution time: 0.0313
DEBUG - 2022-06-24 05:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:51:09 --> Total execution time: 0.0957
DEBUG - 2022-06-24 05:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:51:10 --> Total execution time: 0.0752
DEBUG - 2022-06-24 05:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:51:11 --> Total execution time: 0.0975
DEBUG - 2022-06-24 05:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:51:11 --> Total execution time: 0.1622
DEBUG - 2022-06-24 05:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:51:11 --> Total execution time: 0.0816
DEBUG - 2022-06-24 05:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:51:12 --> Total execution time: 0.0866
DEBUG - 2022-06-24 05:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:51:13 --> Total execution time: 0.0707
DEBUG - 2022-06-24 05:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:51:22 --> Total execution time: 0.0606
DEBUG - 2022-06-24 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:21:26 --> Total execution time: 0.0459
DEBUG - 2022-06-24 05:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:21:27 --> Total execution time: 0.0462
DEBUG - 2022-06-24 05:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:21:27 --> Total execution time: 0.0993
DEBUG - 2022-06-24 05:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:51:39 --> Total execution time: 0.0571
DEBUG - 2022-06-24 05:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:51:46 --> Total execution time: 0.0539
DEBUG - 2022-06-24 05:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:51:50 --> Total execution time: 0.0536
DEBUG - 2022-06-24 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:52:00 --> Total execution time: 0.0612
DEBUG - 2022-06-24 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:52:01 --> Total execution time: 0.0566
DEBUG - 2022-06-24 05:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:52:04 --> Total execution time: 0.0625
DEBUG - 2022-06-24 05:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:52:19 --> Total execution time: 0.0540
DEBUG - 2022-06-24 05:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:23:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 05:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:53:06 --> Total execution time: 2.4560
DEBUG - 2022-06-24 05:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:23:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 05:23:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 05:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:53:42 --> Total execution time: 0.0354
DEBUG - 2022-06-24 05:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:24:02 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:54:02 --> Total execution time: 0.0458
DEBUG - 2022-06-24 05:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:24:54 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:54:54 --> Total execution time: 0.0510
DEBUG - 2022-06-24 05:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:25:35 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:55:35 --> Total execution time: 0.0522
DEBUG - 2022-06-24 05:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:25:44 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:55:44 --> Total execution time: 0.0490
DEBUG - 2022-06-24 05:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:56:13 --> Total execution time: 0.5188
DEBUG - 2022-06-24 05:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:56:46 --> Total execution time: 0.0926
DEBUG - 2022-06-24 05:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:56:48 --> Total execution time: 0.0933
DEBUG - 2022-06-24 05:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:57:00 --> Total execution time: 0.0637
DEBUG - 2022-06-24 05:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:57:05 --> Total execution time: 0.1417
DEBUG - 2022-06-24 05:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:57:08 --> Total execution time: 0.0810
DEBUG - 2022-06-24 05:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:57:26 --> Total execution time: 0.0605
DEBUG - 2022-06-24 05:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:57:28 --> Total execution time: 0.0587
DEBUG - 2022-06-24 05:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:57:35 --> Total execution time: 0.0729
DEBUG - 2022-06-24 05:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:57:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 05:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:57:38 --> Total execution time: 0.0655
DEBUG - 2022-06-24 05:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:57:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 15:57:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 15:57:39 --> Total execution time: 0.2145
DEBUG - 2022-06-24 05:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:57:57 --> Total execution time: 0.0548
DEBUG - 2022-06-24 05:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:58:19 --> Total execution time: 0.4403
DEBUG - 2022-06-24 05:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:28:24 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:58:24 --> Total execution time: 0.1549
DEBUG - 2022-06-24 05:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:28:25 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:58:25 --> Total execution time: 0.0825
DEBUG - 2022-06-24 05:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:28:37 --> Total execution time: 0.0554
DEBUG - 2022-06-24 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:28:38 --> Total execution time: 0.0468
DEBUG - 2022-06-24 05:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:28:38 --> Total execution time: 0.0665
DEBUG - 2022-06-24 05:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:28:52 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:58:52 --> Total execution time: 0.0466
DEBUG - 2022-06-24 05:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:59:27 --> Total execution time: 0.0541
DEBUG - 2022-06-24 05:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:59:32 --> Total execution time: 0.0785
DEBUG - 2022-06-24 05:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:59:56 --> Total execution time: 0.0442
DEBUG - 2022-06-24 05:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:01:24 --> Total execution time: 0.0647
DEBUG - 2022-06-24 05:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:02:32 --> Total execution time: 0.1397
DEBUG - 2022-06-24 05:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:03:03 --> Total execution time: 0.1370
DEBUG - 2022-06-24 05:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:03:06 --> Total execution time: 0.0614
DEBUG - 2022-06-24 05:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:03:11 --> Total execution time: 0.0474
DEBUG - 2022-06-24 05:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:03:15 --> Total execution time: 0.0559
DEBUG - 2022-06-24 05:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:03:16 --> Total execution time: 0.0520
DEBUG - 2022-06-24 05:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:04:00 --> Total execution time: 0.0605
DEBUG - 2022-06-24 05:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:04:01 --> Total execution time: 0.0690
DEBUG - 2022-06-24 05:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:04:06 --> Total execution time: 0.0690
DEBUG - 2022-06-24 05:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:04:18 --> Total execution time: 0.0800
DEBUG - 2022-06-24 05:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:34:24 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:04:24 --> Total execution time: 0.0502
DEBUG - 2022-06-24 05:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:04:43 --> Total execution time: 0.0479
DEBUG - 2022-06-24 05:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:04:47 --> Total execution time: 0.0531
DEBUG - 2022-06-24 05:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:34:57 --> Total execution time: 0.0386
DEBUG - 2022-06-24 05:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:34:59 --> Total execution time: 0.0661
DEBUG - 2022-06-24 05:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:34:59 --> Total execution time: 0.1077
DEBUG - 2022-06-24 05:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:05:01 --> Total execution time: 0.1262
DEBUG - 2022-06-24 05:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:05:20 --> Total execution time: 0.0680
DEBUG - 2022-06-24 05:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:35:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 05:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:05:44 --> Total execution time: 1.8624
DEBUG - 2022-06-24 05:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 05:35:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 05:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:05:46 --> Total execution time: 0.0555
DEBUG - 2022-06-24 05:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:06:08 --> Total execution time: 0.0722
DEBUG - 2022-06-24 05:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:06:11 --> Total execution time: 0.0693
DEBUG - 2022-06-24 05:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:37:12 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:07:12 --> Total execution time: 0.1228
DEBUG - 2022-06-24 05:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:07:18 --> Total execution time: 0.0464
DEBUG - 2022-06-24 05:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:07:22 --> Total execution time: 0.0646
DEBUG - 2022-06-24 05:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:07:31 --> Total execution time: 0.0586
DEBUG - 2022-06-24 05:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:07:41 --> Total execution time: 0.0458
DEBUG - 2022-06-24 05:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:37:51 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:07:51 --> Total execution time: 0.1088
DEBUG - 2022-06-24 05:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:08:53 --> Total execution time: 0.1176
DEBUG - 2022-06-24 05:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:08:59 --> Total execution time: 0.1024
DEBUG - 2022-06-24 05:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:09:29 --> Total execution time: 0.0931
DEBUG - 2022-06-24 05:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:19:38 --> Total execution time: 0.1656
DEBUG - 2022-06-24 05:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:19:45 --> Total execution time: 0.0503
DEBUG - 2022-06-24 05:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:19:48 --> Total execution time: 0.0556
DEBUG - 2022-06-24 05:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:19:51 --> Total execution time: 0.0382
DEBUG - 2022-06-24 05:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:19:52 --> Total execution time: 0.0383
DEBUG - 2022-06-24 05:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:19:52 --> Total execution time: 0.0443
DEBUG - 2022-06-24 05:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:19:53 --> Total execution time: 0.0359
DEBUG - 2022-06-24 05:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:20:14 --> Total execution time: 0.0618
DEBUG - 2022-06-24 05:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:20:23 --> Total execution time: 0.0567
DEBUG - 2022-06-24 05:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:50:24 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:20:24 --> Total execution time: 0.1124
DEBUG - 2022-06-24 05:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:20:28 --> Total execution time: 0.0507
DEBUG - 2022-06-24 05:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:20:36 --> Total execution time: 0.0506
DEBUG - 2022-06-24 05:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:20:45 --> Total execution time: 0.0720
DEBUG - 2022-06-24 05:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:20:56 --> Total execution time: 0.1437
DEBUG - 2022-06-24 05:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:21:03 --> Total execution time: 0.1008
DEBUG - 2022-06-24 05:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:21:12 --> Total execution time: 0.0656
DEBUG - 2022-06-24 05:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:21:20 --> Total execution time: 0.0720
DEBUG - 2022-06-24 05:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:21:23 --> Total execution time: 0.0742
DEBUG - 2022-06-24 05:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 16:21:35 --> Total execution time: 0.0527
DEBUG - 2022-06-24 05:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:21:35 --> Total execution time: 0.1153
DEBUG - 2022-06-24 05:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:52:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:22:05 --> Total execution time: 0.0363
DEBUG - 2022-06-24 05:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:52:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:22:05 --> Total execution time: 0.0343
DEBUG - 2022-06-24 05:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:22:46 --> Total execution time: 0.0451
DEBUG - 2022-06-24 05:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:25:49 --> Total execution time: 0.1013
DEBUG - 2022-06-24 05:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 05:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:26:06 --> Total execution time: 0.0924
DEBUG - 2022-06-24 05:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:26:12 --> Total execution time: 0.0743
DEBUG - 2022-06-24 05:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:58:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 05:58:35 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-06-24 05:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:58:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 05:58:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 05:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:29:26 --> Total execution time: 0.1059
DEBUG - 2022-06-24 05:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:29:37 --> Total execution time: 0.0440
DEBUG - 2022-06-24 05:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:59:54 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:29:55 --> Total execution time: 0.1241
DEBUG - 2022-06-24 05:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 05:59:55 --> No URI present. Default controller set.
DEBUG - 2022-06-24 05:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 05:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:29:55 --> Total execution time: 0.0580
DEBUG - 2022-06-24 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:30:02 --> Total execution time: 0.0928
DEBUG - 2022-06-24 06:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:01:03 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:31:03 --> Total execution time: 0.0623
DEBUG - 2022-06-24 06:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:11:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:41:40 --> Total execution time: 0.2226
DEBUG - 2022-06-24 06:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:11:41 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:41:41 --> Total execution time: 0.0422
DEBUG - 2022-06-24 06:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:12:16 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:42:16 --> Total execution time: 0.0419
DEBUG - 2022-06-24 06:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:12:30 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:42:30 --> Total execution time: 0.0516
DEBUG - 2022-06-24 06:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:42:32 --> Total execution time: 0.0426
DEBUG - 2022-06-24 06:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:42:33 --> Total execution time: 0.0415
DEBUG - 2022-06-24 06:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:12:39 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:42:39 --> Total execution time: 0.0600
DEBUG - 2022-06-24 06:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:12:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:12:40 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-24 06:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:12:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:12:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 06:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:12:49 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-24 06:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:12:55 --> Total execution time: 0.0500
DEBUG - 2022-06-24 06:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:12:56 --> Total execution time: 0.0708
DEBUG - 2022-06-24 06:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:12:56 --> Total execution time: 0.1234
DEBUG - 2022-06-24 06:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:13:01 --> Total execution time: 0.0753
DEBUG - 2022-06-24 06:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:13:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:13:03 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-24 06:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:13:04 --> Total execution time: 0.0484
DEBUG - 2022-06-24 06:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:13:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:13:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 06:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:13:24 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:43:24 --> Total execution time: 0.0342
DEBUG - 2022-06-24 06:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:43:33 --> Total execution time: 0.0320
DEBUG - 2022-06-24 06:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:43:51 --> Total execution time: 0.0807
DEBUG - 2022-06-24 06:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:13:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 06:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:43:56 --> Total execution time: 2.0495
DEBUG - 2022-06-24 06:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:13:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:13:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 06:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:44:04 --> Total execution time: 0.0606
DEBUG - 2022-06-24 06:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:44:08 --> Total execution time: 0.1267
DEBUG - 2022-06-24 06:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:44:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 06:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:44:32 --> Total execution time: 0.0830
DEBUG - 2022-06-24 06:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:44:51 --> Total execution time: 0.1034
DEBUG - 2022-06-24 06:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:45:07 --> Total execution time: 0.0811
DEBUG - 2022-06-24 06:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:45:08 --> Total execution time: 0.0700
DEBUG - 2022-06-24 06:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:45:29 --> Total execution time: 0.0535
DEBUG - 2022-06-24 06:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:45:37 --> Total execution time: 0.0504
DEBUG - 2022-06-24 06:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:45:50 --> Total execution time: 0.0492
DEBUG - 2022-06-24 06:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:45:52 --> Total execution time: 0.0634
DEBUG - 2022-06-24 06:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:45:54 --> Total execution time: 0.1007
DEBUG - 2022-06-24 06:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:46:05 --> Total execution time: 0.0601
DEBUG - 2022-06-24 06:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:46:26 --> Total execution time: 0.1139
DEBUG - 2022-06-24 06:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:47:32 --> Total execution time: 0.0645
DEBUG - 2022-06-24 06:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:17:36 --> Total execution time: 0.0345
DEBUG - 2022-06-24 06:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:17:37 --> Total execution time: 0.0704
DEBUG - 2022-06-24 06:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:17:37 --> Total execution time: 0.1075
DEBUG - 2022-06-24 06:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:17:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:47:40 --> Total execution time: 0.0575
DEBUG - 2022-06-24 06:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:17:40 --> Total execution time: 0.0699
DEBUG - 2022-06-24 06:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:17:57 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:47:57 --> Total execution time: 0.0536
DEBUG - 2022-06-24 06:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:48:05 --> Total execution time: 0.0583
DEBUG - 2022-06-24 06:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:48:24 --> Total execution time: 0.0606
DEBUG - 2022-06-24 06:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:48:41 --> Total execution time: 0.1212
DEBUG - 2022-06-24 06:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:50:05 --> Total execution time: 0.0889
DEBUG - 2022-06-24 06:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:50:10 --> Total execution time: 0.0627
DEBUG - 2022-06-24 06:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:50:24 --> Total execution time: 0.0615
DEBUG - 2022-06-24 06:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:50:28 --> Total execution time: 0.0494
DEBUG - 2022-06-24 06:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:50:31 --> Total execution time: 0.0887
DEBUG - 2022-06-24 06:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:50:54 --> Total execution time: 0.0475
DEBUG - 2022-06-24 06:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:20:58 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:50:58 --> Total execution time: 0.1185
DEBUG - 2022-06-24 06:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:54:47 --> Total execution time: 0.1886
DEBUG - 2022-06-24 06:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:54:53 --> Total execution time: 0.0510
DEBUG - 2022-06-24 06:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:27:23 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:57:23 --> Total execution time: 0.2563
DEBUG - 2022-06-24 06:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:57:41 --> Total execution time: 0.0594
DEBUG - 2022-06-24 06:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:57:59 --> Total execution time: 0.0706
DEBUG - 2022-06-24 06:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:58:34 --> Total execution time: 0.2354
DEBUG - 2022-06-24 06:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:29:05 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 06:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:29:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:29:30 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-24 06:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:29:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:29:31 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 06:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:29:49 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:59:49 --> Total execution time: 0.0454
DEBUG - 2022-06-24 06:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:29:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:29:49 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-24 06:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:00:17 --> Total execution time: 0.0308
DEBUG - 2022-06-24 06:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:00:23 --> Total execution time: 0.0547
DEBUG - 2022-06-24 06:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:30:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:30:28 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-24 06:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:30:29 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:00:29 --> Total execution time: 0.0459
DEBUG - 2022-06-24 06:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:00:35 --> Total execution time: 0.0743
DEBUG - 2022-06-24 06:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:00:47 --> Total execution time: 2.0009
DEBUG - 2022-06-24 06:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:00:51 --> Total execution time: 0.0818
DEBUG - 2022-06-24 06:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:30:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:30:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 06:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:31:13 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:31:13 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:01:13 --> Total execution time: 0.0373
DEBUG - 2022-06-24 06:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:01:13 --> Total execution time: 0.1338
DEBUG - 2022-06-24 06:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:31:13 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:01:13 --> Total execution time: 0.0431
DEBUG - 2022-06-24 06:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:31:18 --> Total execution time: 0.0399
DEBUG - 2022-06-24 06:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:31:19 --> Total execution time: 0.0416
DEBUG - 2022-06-24 06:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:31:19 --> Total execution time: 0.0935
DEBUG - 2022-06-24 06:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:01:32 --> Total execution time: 0.0621
DEBUG - 2022-06-24 06:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:31:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:31:37 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 06:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:01:46 --> Total execution time: 0.0742
DEBUG - 2022-06-24 06:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:01:51 --> Total execution time: 0.0570
DEBUG - 2022-06-24 06:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:31:54 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:01:54 --> Total execution time: 0.0441
DEBUG - 2022-06-24 06:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:32:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:32:13 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-24 06:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:32:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:32:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 06:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:02:18 --> Total execution time: 0.0472
DEBUG - 2022-06-24 06:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:32:24 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-24 06:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:32:29 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:02:29 --> Total execution time: 0.0448
DEBUG - 2022-06-24 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:33:42 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:03:42 --> Total execution time: 0.1332
DEBUG - 2022-06-24 06:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:33:44 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 06:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:34:41 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:04:41 --> Total execution time: 0.0325
DEBUG - 2022-06-24 06:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:35:00 --> Total execution time: 0.0663
DEBUG - 2022-06-24 06:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:35:03 --> Total execution time: 0.0552
DEBUG - 2022-06-24 06:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:35:03 --> Total execution time: 0.1054
DEBUG - 2022-06-24 06:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:36:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 06:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:06:15 --> Total execution time: 1.5341
DEBUG - 2022-06-24 06:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:06:43 --> Total execution time: 0.1502
DEBUG - 2022-06-24 06:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:37:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 06:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:07:42 --> Total execution time: 1.5502
DEBUG - 2022-06-24 06:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:37:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:37:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 06:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:07:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 06:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:07:47 --> Total execution time: 0.0588
DEBUG - 2022-06-24 06:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:37:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-06-24 17:07:49 --> Severity: Notice --> Trying to get property 'ul_login_status' of non-object /home3/esalesei/esalestrix.in/application/helpers/project_helper.php 414
DEBUG - 2022-06-24 17:07:49 --> Total execution time: 0.0616
DEBUG - 2022-06-24 06:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:37:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:37:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 06:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:08:00 --> Total execution time: 0.0578
DEBUG - 2022-06-24 06:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:08:16 --> Total execution time: 0.0522
DEBUG - 2022-06-24 06:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:08:23 --> Total execution time: 0.0523
DEBUG - 2022-06-24 06:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:08:24 --> Total execution time: 0.0490
DEBUG - 2022-06-24 06:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:08:42 --> Total execution time: 0.0531
DEBUG - 2022-06-24 06:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:08:52 --> Total execution time: 0.0581
DEBUG - 2022-06-24 06:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:39:19 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 17:09:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 06:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:09:19 --> Total execution time: 0.1207
DEBUG - 2022-06-24 06:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:09:21 --> Total execution time: 0.1379
DEBUG - 2022-06-24 06:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:09:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 17:09:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 17:09:24 --> Total execution time: 0.3876
DEBUG - 2022-06-24 06:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:39:25 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:09:25 --> Total execution time: 0.1434
DEBUG - 2022-06-24 06:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:09:43 --> Total execution time: 0.1166
DEBUG - 2022-06-24 06:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:10:23 --> Total execution time: 0.0306
DEBUG - 2022-06-24 06:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:10:35 --> Total execution time: 0.0755
DEBUG - 2022-06-24 06:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:10:56 --> Total execution time: 0.0483
DEBUG - 2022-06-24 06:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:10:57 --> Total execution time: 0.0617
DEBUG - 2022-06-24 06:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:41:03 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:11:03 --> Total execution time: 0.0655
DEBUG - 2022-06-24 06:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:41:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:11:14 --> Total execution time: 0.0515
DEBUG - 2022-06-24 06:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:11:17 --> Total execution time: 0.0372
DEBUG - 2022-06-24 06:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:11:38 --> Total execution time: 0.0487
DEBUG - 2022-06-24 06:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:11:49 --> Total execution time: 0.0491
DEBUG - 2022-06-24 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:11:51 --> Total execution time: 0.1121
DEBUG - 2022-06-24 06:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:41:57 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:11:57 --> Total execution time: 0.0302
DEBUG - 2022-06-24 06:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:12:01 --> Total execution time: 0.0433
DEBUG - 2022-06-24 06:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:12:06 --> Total execution time: 0.0510
DEBUG - 2022-06-24 06:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:12:07 --> Total execution time: 0.0395
DEBUG - 2022-06-24 06:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:12:11 --> Total execution time: 0.0795
DEBUG - 2022-06-24 06:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:12 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:12:12 --> Total execution time: 0.0569
DEBUG - 2022-06-24 06:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:12:30 --> Total execution time: 0.0697
DEBUG - 2022-06-24 06:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:12:35 --> Total execution time: 0.0589
DEBUG - 2022-06-24 06:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:12:42 --> Total execution time: 0.0572
DEBUG - 2022-06-24 06:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:12:45 --> Total execution time: 0.0718
DEBUG - 2022-06-24 06:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:12:50 --> Total execution time: 0.0897
DEBUG - 2022-06-24 06:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:12:56 --> Total execution time: 0.0616
DEBUG - 2022-06-24 06:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:12:59 --> Total execution time: 0.0548
DEBUG - 2022-06-24 06:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:13:05 --> Total execution time: 0.0495
DEBUG - 2022-06-24 06:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:13:26 --> Total execution time: 0.0548
DEBUG - 2022-06-24 06:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:13:41 --> Total execution time: 0.0968
DEBUG - 2022-06-24 06:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:13:54 --> Total execution time: 0.1147
DEBUG - 2022-06-24 06:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:43:58 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:13:58 --> Total execution time: 0.0652
DEBUG - 2022-06-24 06:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:43:59 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:13:59 --> Total execution time: 0.0334
DEBUG - 2022-06-24 06:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:14:12 --> Total execution time: 0.0387
DEBUG - 2022-06-24 06:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:14:56 --> Total execution time: 0.0619
DEBUG - 2022-06-24 06:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:15:02 --> Total execution time: 0.1193
DEBUG - 2022-06-24 06:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:15:10 --> Total execution time: 0.0555
DEBUG - 2022-06-24 06:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:15:15 --> Total execution time: 0.0671
DEBUG - 2022-06-24 06:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:15:26 --> Total execution time: 0.0826
DEBUG - 2022-06-24 06:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:45:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:15:40 --> Total execution time: 0.0581
DEBUG - 2022-06-24 06:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:15:55 --> Total execution time: 0.0740
DEBUG - 2022-06-24 06:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:46:04 --> Total execution time: 0.0640
DEBUG - 2022-06-24 06:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:46:06 --> Total execution time: 0.0594
DEBUG - 2022-06-24 06:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:46:06 --> Total execution time: 0.0851
DEBUG - 2022-06-24 06:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:46:09 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:16:09 --> Total execution time: 0.1258
DEBUG - 2022-06-24 06:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:46:11 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:16:11 --> Total execution time: 0.0575
DEBUG - 2022-06-24 06:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:16:12 --> Total execution time: 0.1550
DEBUG - 2022-06-24 06:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:16:15 --> Total execution time: 0.0517
DEBUG - 2022-06-24 06:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:46:22 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:16:22 --> Total execution time: 0.0564
DEBUG - 2022-06-24 06:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:16:25 --> Total execution time: 0.1100
DEBUG - 2022-06-24 06:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:16:43 --> Total execution time: 0.1508
DEBUG - 2022-06-24 06:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:16:53 --> Total execution time: 0.0508
DEBUG - 2022-06-24 06:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:16:58 --> Total execution time: 0.0514
DEBUG - 2022-06-24 06:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:17:05 --> Total execution time: 0.0581
DEBUG - 2022-06-24 06:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:17:33 --> Total execution time: 0.0548
DEBUG - 2022-06-24 06:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:17:35 --> Total execution time: 0.0543
DEBUG - 2022-06-24 06:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:17:50 --> Total execution time: 0.0530
DEBUG - 2022-06-24 06:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:18:19 --> Total execution time: 0.0495
DEBUG - 2022-06-24 06:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:18:24 --> Total execution time: 0.0708
DEBUG - 2022-06-24 06:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:18:29 --> Total execution time: 0.0478
DEBUG - 2022-06-24 06:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:18:41 --> Total execution time: 0.1154
DEBUG - 2022-06-24 06:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:48:44 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:18:44 --> Total execution time: 0.0719
DEBUG - 2022-06-24 06:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:18:50 --> Total execution time: 0.0445
DEBUG - 2022-06-24 06:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:48:57 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:18:57 --> Total execution time: 0.0455
DEBUG - 2022-06-24 06:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:49:04 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:19:04 --> Total execution time: 0.0480
DEBUG - 2022-06-24 06:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:49:11 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:19:12 --> Total execution time: 0.1092
DEBUG - 2022-06-24 06:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:49:15 --> Total execution time: 0.0475
DEBUG - 2022-06-24 06:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:49:17 --> Total execution time: 0.0519
DEBUG - 2022-06-24 06:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:19:17 --> Total execution time: 0.0535
DEBUG - 2022-06-24 06:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:49:17 --> Total execution time: 0.0975
DEBUG - 2022-06-24 06:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:49:24 --> Total execution time: 0.0456
DEBUG - 2022-06-24 06:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:49:28 --> Total execution time: 0.0539
DEBUG - 2022-06-24 06:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:20:10 --> Total execution time: 0.0586
DEBUG - 2022-06-24 06:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:20:38 --> Total execution time: 0.0464
DEBUG - 2022-06-24 06:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:21:15 --> Total execution time: 0.0501
DEBUG - 2022-06-24 06:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:21:23 --> Total execution time: 0.0459
DEBUG - 2022-06-24 06:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:21:36 --> Total execution time: 0.0971
DEBUG - 2022-06-24 06:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:22:06 --> Total execution time: 0.0602
DEBUG - 2022-06-24 06:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:22:11 --> Total execution time: 0.1166
DEBUG - 2022-06-24 06:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:22:22 --> Total execution time: 0.0618
DEBUG - 2022-06-24 06:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:22:36 --> Total execution time: 0.0586
DEBUG - 2022-06-24 06:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:22:41 --> Total execution time: 0.0587
DEBUG - 2022-06-24 06:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:22:51 --> Total execution time: 0.0565
DEBUG - 2022-06-24 06:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:23:01 --> Total execution time: 0.0532
DEBUG - 2022-06-24 06:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:53:11 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:23:11 --> Total execution time: 0.0512
DEBUG - 2022-06-24 06:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:53:49 --> No URI present. Default controller set.
DEBUG - 2022-06-24 06:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:23:49 --> Total execution time: 0.0544
DEBUG - 2022-06-24 06:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:24:28 --> Total execution time: 0.1032
DEBUG - 2022-06-24 06:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:24:52 --> Total execution time: 0.0625
DEBUG - 2022-06-24 06:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:25:07 --> Total execution time: 0.1612
DEBUG - 2022-06-24 06:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:25:09 --> Total execution time: 0.0530
DEBUG - 2022-06-24 06:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:25:14 --> Total execution time: 0.0981
DEBUG - 2022-06-24 06:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:25:17 --> Total execution time: 0.0634
DEBUG - 2022-06-24 06:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:25:25 --> Total execution time: 0.1040
DEBUG - 2022-06-24 06:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:25:42 --> Total execution time: 0.0728
DEBUG - 2022-06-24 06:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:26:08 --> Total execution time: 0.0320
DEBUG - 2022-06-24 06:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:26:14 --> Total execution time: 0.0530
DEBUG - 2022-06-24 06:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:26:23 --> Total execution time: 0.0451
DEBUG - 2022-06-24 06:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:26:30 --> Total execution time: 0.0538
DEBUG - 2022-06-24 06:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:26:33 --> Total execution time: 0.0539
DEBUG - 2022-06-24 06:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:26:39 --> Total execution time: 0.0615
DEBUG - 2022-06-24 06:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 06:56:40 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 06:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:26:43 --> Total execution time: 0.0645
DEBUG - 2022-06-24 06:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:26:45 --> Total execution time: 0.0497
DEBUG - 2022-06-24 06:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:26:59 --> Total execution time: 0.0759
DEBUG - 2022-06-24 06:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:27:07 --> Total execution time: 0.0935
DEBUG - 2022-06-24 06:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:28:05 --> Total execution time: 0.0474
DEBUG - 2022-06-24 06:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:28:20 --> Total execution time: 0.0840
DEBUG - 2022-06-24 06:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:28:59 --> Total execution time: 0.0843
DEBUG - 2022-06-24 06:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:29:02 --> Total execution time: 0.0830
DEBUG - 2022-06-24 06:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 06:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:29:29 --> Total execution time: 0.0469
DEBUG - 2022-06-24 06:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:29:31 --> Total execution time: 0.0603
DEBUG - 2022-06-24 06:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:29:34 --> Total execution time: 0.0681
DEBUG - 2022-06-24 06:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:29:35 --> Total execution time: 0.1299
DEBUG - 2022-06-24 06:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:29:44 --> Total execution time: 0.0651
DEBUG - 2022-06-24 06:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:29:46 --> Total execution time: 0.0782
DEBUG - 2022-06-24 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:30:03 --> Total execution time: 0.1839
DEBUG - 2022-06-24 07:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 07:01:06 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-24 07:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:01:06 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:31:06 --> Total execution time: 0.0803
DEBUG - 2022-06-24 07:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 07:01:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 07:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:32:08 --> Total execution time: 0.1532
DEBUG - 2022-06-24 07:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:02:19 --> Total execution time: 0.0461
DEBUG - 2022-06-24 07:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:02:28 --> Total execution time: 0.0702
DEBUG - 2022-06-24 07:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:02:58 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:32:58 --> Total execution time: 0.0477
DEBUG - 2022-06-24 07:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:33:04 --> Total execution time: 0.0418
DEBUG - 2022-06-24 07:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:33:09 --> Total execution time: 0.0733
DEBUG - 2022-06-24 07:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:33:16 --> Total execution time: 0.0535
DEBUG - 2022-06-24 07:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:33:28 --> Total execution time: 0.0513
DEBUG - 2022-06-24 07:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:33:30 --> Total execution time: 0.0728
DEBUG - 2022-06-24 07:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:33:42 --> Total execution time: 0.0474
DEBUG - 2022-06-24 07:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:33:46 --> Total execution time: 0.0765
DEBUG - 2022-06-24 07:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:33:46 --> Total execution time: 0.0804
DEBUG - 2022-06-24 07:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:33:53 --> Total execution time: 0.0794
DEBUG - 2022-06-24 07:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:04:01 --> Total execution time: 0.0643
DEBUG - 2022-06-24 07:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:34:07 --> Total execution time: 0.0534
DEBUG - 2022-06-24 07:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:34:11 --> Total execution time: 0.0623
DEBUG - 2022-06-24 07:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:34:16 --> Total execution time: 0.1105
DEBUG - 2022-06-24 07:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:35:02 --> Total execution time: 0.0691
DEBUG - 2022-06-24 07:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:35:05 --> Total execution time: 0.1098
DEBUG - 2022-06-24 07:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:35:06 --> Total execution time: 0.0542
DEBUG - 2022-06-24 07:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:35:06 --> Total execution time: 0.0702
DEBUG - 2022-06-24 07:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:36:45 --> Total execution time: 0.0646
DEBUG - 2022-06-24 07:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:36:52 --> Total execution time: 0.0584
DEBUG - 2022-06-24 07:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:36:54 --> Total execution time: 0.0761
DEBUG - 2022-06-24 07:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:36:59 --> Total execution time: 0.0639
DEBUG - 2022-06-24 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:37:03 --> Total execution time: 0.0928
DEBUG - 2022-06-24 07:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:07:16 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:37:16 --> Total execution time: 0.0712
DEBUG - 2022-06-24 07:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:37:33 --> Total execution time: 0.0815
DEBUG - 2022-06-24 07:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:37:40 --> Total execution time: 0.0872
DEBUG - 2022-06-24 07:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:38:03 --> Total execution time: 0.0789
DEBUG - 2022-06-24 07:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:38:22 --> Total execution time: 0.0812
DEBUG - 2022-06-24 07:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:38:32 --> Total execution time: 0.0868
DEBUG - 2022-06-24 07:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:38:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 07:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:38:50 --> Total execution time: 0.0693
DEBUG - 2022-06-24 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:08:59 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:38:59 --> Total execution time: 0.0271
DEBUG - 2022-06-24 07:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:39:00 --> Total execution time: 0.0921
DEBUG - 2022-06-24 07:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:39:13 --> Total execution time: 0.0838
DEBUG - 2022-06-24 07:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:39:36 --> Total execution time: 0.0625
DEBUG - 2022-06-24 07:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:39:41 --> Total execution time: 0.0527
DEBUG - 2022-06-24 07:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:40:17 --> Total execution time: 0.0479
DEBUG - 2022-06-24 07:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:40:41 --> Total execution time: 0.0487
DEBUG - 2022-06-24 07:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:40:51 --> Total execution time: 0.0564
DEBUG - 2022-06-24 07:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:41:34 --> Total execution time: 0.0670
DEBUG - 2022-06-24 07:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:12:21 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:42:21 --> Total execution time: 0.0638
DEBUG - 2022-06-24 07:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:42:32 --> Total execution time: 0.0490
DEBUG - 2022-06-24 07:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:42:37 --> Total execution time: 0.0592
DEBUG - 2022-06-24 07:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:42:45 --> Total execution time: 0.0768
DEBUG - 2022-06-24 07:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:43:16 --> Total execution time: 0.0586
DEBUG - 2022-06-24 07:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:13:55 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:43:55 --> Total execution time: 0.0378
DEBUG - 2022-06-24 07:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:43:57 --> Total execution time: 0.0412
DEBUG - 2022-06-24 07:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:44:02 --> Total execution time: 0.0376
DEBUG - 2022-06-24 07:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:44:04 --> Total execution time: 0.0387
DEBUG - 2022-06-24 07:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:44:05 --> Total execution time: 0.0360
DEBUG - 2022-06-24 07:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:44:06 --> Total execution time: 0.0457
DEBUG - 2022-06-24 07:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:44:07 --> Total execution time: 0.0476
DEBUG - 2022-06-24 07:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:44:14 --> Total execution time: 0.0456
DEBUG - 2022-06-24 07:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:44:31 --> Total execution time: 0.0522
DEBUG - 2022-06-24 07:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:44:32 --> Total execution time: 0.0617
DEBUG - 2022-06-24 07:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:44:53 --> Total execution time: 0.0552
DEBUG - 2022-06-24 07:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:44:56 --> Total execution time: 0.0439
DEBUG - 2022-06-24 07:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:44:59 --> Total execution time: 0.0522
DEBUG - 2022-06-24 07:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:45:01 --> Total execution time: 0.0543
DEBUG - 2022-06-24 07:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:45:04 --> Total execution time: 0.0931
DEBUG - 2022-06-24 07:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:45:05 --> Total execution time: 0.0402
DEBUG - 2022-06-24 07:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:45:22 --> Total execution time: 0.0438
DEBUG - 2022-06-24 07:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:45:26 --> Total execution time: 0.0556
DEBUG - 2022-06-24 07:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:47:35 --> Total execution time: 0.1856
DEBUG - 2022-06-24 07:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:47:36 --> Total execution time: 0.0820
DEBUG - 2022-06-24 07:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:48:02 --> Total execution time: 0.0754
DEBUG - 2022-06-24 07:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:18:06 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:48:06 --> Total execution time: 0.1084
DEBUG - 2022-06-24 07:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:48:09 --> Total execution time: 0.0486
DEBUG - 2022-06-24 07:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:48:15 --> Total execution time: 0.0580
DEBUG - 2022-06-24 07:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:48:24 --> Total execution time: 0.0885
DEBUG - 2022-06-24 07:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:48:37 --> Total execution time: 0.0666
DEBUG - 2022-06-24 07:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:18:46 --> Total execution time: 0.0627
DEBUG - 2022-06-24 07:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:48:49 --> Total execution time: 0.0532
DEBUG - 2022-06-24 07:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:48:50 --> Total execution time: 0.0847
DEBUG - 2022-06-24 07:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:48:52 --> Total execution time: 0.0555
DEBUG - 2022-06-24 07:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:48:56 --> Total execution time: 0.0699
DEBUG - 2022-06-24 07:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:49:13 --> Total execution time: 0.0599
DEBUG - 2022-06-24 07:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:49:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 07:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:49:16 --> Total execution time: 0.0535
DEBUG - 2022-06-24 07:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:49:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 17:49:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 17:49:17 --> Total execution time: 0.2116
DEBUG - 2022-06-24 07:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:49:26 --> Total execution time: 0.0499
DEBUG - 2022-06-24 07:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:49:31 --> Total execution time: 0.1195
DEBUG - 2022-06-24 07:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:49:41 --> Total execution time: 0.0665
DEBUG - 2022-06-24 07:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:49:55 --> Total execution time: 0.0696
DEBUG - 2022-06-24 07:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:49:56 --> Total execution time: 0.0810
DEBUG - 2022-06-24 07:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:50:01 --> Total execution time: 0.0745
DEBUG - 2022-06-24 07:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:50:13 --> Total execution time: 0.0776
DEBUG - 2022-06-24 07:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:50:59 --> Total execution time: 0.1026
DEBUG - 2022-06-24 07:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:51:36 --> Total execution time: 0.0433
DEBUG - 2022-06-24 07:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:51:57 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 07:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:51:58 --> Total execution time: 0.0504
DEBUG - 2022-06-24 07:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:52:01 --> Total execution time: 0.1143
DEBUG - 2022-06-24 07:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:52:02 --> Total execution time: 0.0966
DEBUG - 2022-06-24 07:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:52:18 --> Total execution time: 0.0815
DEBUG - 2022-06-24 07:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:52:59 --> Total execution time: 0.1419
DEBUG - 2022-06-24 07:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:53:07 --> Total execution time: 0.0564
DEBUG - 2022-06-24 07:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:54:04 --> Total execution time: 0.0508
DEBUG - 2022-06-24 07:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:54:19 --> Total execution time: 0.0923
DEBUG - 2022-06-24 07:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:54:26 --> Total execution time: 0.0533
DEBUG - 2022-06-24 07:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:54:58 --> Total execution time: 0.0970
DEBUG - 2022-06-24 07:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:55:00 --> Total execution time: 0.0885
DEBUG - 2022-06-24 07:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:55:05 --> Total execution time: 0.0665
DEBUG - 2022-06-24 07:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:55:13 --> Total execution time: 0.1378
DEBUG - 2022-06-24 07:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:55:25 --> Total execution time: 0.0446
DEBUG - 2022-06-24 07:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:25:28 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:55:28 --> Total execution time: 0.0361
DEBUG - 2022-06-24 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:25:31 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:55:31 --> Total execution time: 0.0536
DEBUG - 2022-06-24 07:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:55:37 --> Total execution time: 0.0597
DEBUG - 2022-06-24 07:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:55:45 --> Total execution time: 0.0490
DEBUG - 2022-06-24 07:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:55:54 --> Total execution time: 0.0425
DEBUG - 2022-06-24 07:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:56:02 --> Total execution time: 0.0638
DEBUG - 2022-06-24 07:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:26:03 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:56:03 --> Total execution time: 0.1138
DEBUG - 2022-06-24 07:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:56:05 --> Total execution time: 0.0750
DEBUG - 2022-06-24 07:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:56:06 --> Total execution time: 0.0554
DEBUG - 2022-06-24 07:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:56:10 --> Total execution time: 0.0721
DEBUG - 2022-06-24 07:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:56:14 --> Total execution time: 0.0673
DEBUG - 2022-06-24 07:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:56:33 --> Total execution time: 0.0735
DEBUG - 2022-06-24 07:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:56:34 --> Total execution time: 0.0464
DEBUG - 2022-06-24 07:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:56:34 --> Total execution time: 0.0539
DEBUG - 2022-06-24 07:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:56:41 --> Total execution time: 0.0807
DEBUG - 2022-06-24 07:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:56:47 --> Total execution time: 0.0589
DEBUG - 2022-06-24 07:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:57:00 --> Total execution time: 0.0986
DEBUG - 2022-06-24 07:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:57:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 07:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:57:07 --> Total execution time: 0.0487
DEBUG - 2022-06-24 07:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:57:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 17:57:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 17:57:08 --> Total execution time: 0.2196
DEBUG - 2022-06-24 07:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:57:39 --> Total execution time: 0.0557
DEBUG - 2022-06-24 07:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:58:15 --> Total execution time: 0.0485
DEBUG - 2022-06-24 07:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:58:48 --> Total execution time: 0.0522
DEBUG - 2022-06-24 07:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:29:57 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:59:57 --> Total execution time: 0.0425
DEBUG - 2022-06-24 07:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:00:04 --> Total execution time: 0.0491
DEBUG - 2022-06-24 07:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:00:27 --> Total execution time: 0.1310
DEBUG - 2022-06-24 07:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:00:36 --> Total execution time: 0.0539
DEBUG - 2022-06-24 07:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:00:45 --> Total execution time: 0.0566
DEBUG - 2022-06-24 07:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:01:07 --> Total execution time: 0.0525
DEBUG - 2022-06-24 07:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:01:22 --> Total execution time: 0.0448
DEBUG - 2022-06-24 07:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:01:38 --> Total execution time: 0.1193
DEBUG - 2022-06-24 07:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:01:42 --> Total execution time: 0.0592
DEBUG - 2022-06-24 07:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:03:48 --> Total execution time: 0.1611
DEBUG - 2022-06-24 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:35:27 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:05:28 --> Total execution time: 0.0664
DEBUG - 2022-06-24 07:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:05:31 --> Total execution time: 0.0437
DEBUG - 2022-06-24 07:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:05:44 --> Total execution time: 0.0518
DEBUG - 2022-06-24 07:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:06:12 --> Total execution time: 0.0493
DEBUG - 2022-06-24 07:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:06:15 --> Total execution time: 0.0413
DEBUG - 2022-06-24 07:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:06:19 --> Total execution time: 0.0460
DEBUG - 2022-06-24 07:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:06:45 --> Total execution time: 0.0499
DEBUG - 2022-06-24 07:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:06:54 --> Total execution time: 0.0651
DEBUG - 2022-06-24 07:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:06:59 --> Total execution time: 0.0519
DEBUG - 2022-06-24 07:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:07:02 --> Total execution time: 0.0573
DEBUG - 2022-06-24 07:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:07:28 --> Total execution time: 0.0536
DEBUG - 2022-06-24 07:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:07:29 --> Total execution time: 0.0539
DEBUG - 2022-06-24 07:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:07:29 --> Total execution time: 0.0839
DEBUG - 2022-06-24 07:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:08:20 --> Total execution time: 0.0888
DEBUG - 2022-06-24 07:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:40:58 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:10:58 --> Total execution time: 0.1071
DEBUG - 2022-06-24 07:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:10:59 --> Total execution time: 0.0505
DEBUG - 2022-06-24 07:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:11:02 --> Total execution time: 0.0428
DEBUG - 2022-06-24 07:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:11:07 --> Total execution time: 0.0589
DEBUG - 2022-06-24 07:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:11:13 --> Total execution time: 0.0676
DEBUG - 2022-06-24 07:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:11:21 --> Total execution time: 0.0513
DEBUG - 2022-06-24 07:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:11:30 --> Total execution time: 0.0305
DEBUG - 2022-06-24 07:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:11:41 --> Total execution time: 0.0491
DEBUG - 2022-06-24 07:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:41:55 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:11:55 --> Total execution time: 0.0510
DEBUG - 2022-06-24 07:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:41:56 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:11:56 --> Total execution time: 0.0709
DEBUG - 2022-06-24 07:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:12:04 --> Total execution time: 0.0352
DEBUG - 2022-06-24 07:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:42:26 --> Total execution time: 0.0622
DEBUG - 2022-06-24 07:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:12:30 --> Total execution time: 0.0661
DEBUG - 2022-06-24 07:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:12:34 --> Total execution time: 0.0659
DEBUG - 2022-06-24 07:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:42:34 --> Total execution time: 0.1174
DEBUG - 2022-06-24 07:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:12:39 --> Total execution time: 0.0656
DEBUG - 2022-06-24 07:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:13:04 --> Total execution time: 0.0509
DEBUG - 2022-06-24 07:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:13:06 --> Total execution time: 0.0527
DEBUG - 2022-06-24 07:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:14:16 --> Total execution time: 0.0897
DEBUG - 2022-06-24 07:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:15:13 --> Total execution time: 0.0444
DEBUG - 2022-06-24 07:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:15:54 --> Total execution time: 0.0914
DEBUG - 2022-06-24 07:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:15:55 --> Total execution time: 0.1076
DEBUG - 2022-06-24 07:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:16:10 --> Total execution time: 0.0623
DEBUG - 2022-06-24 07:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:16:15 --> Total execution time: 0.0534
DEBUG - 2022-06-24 07:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:16:19 --> Total execution time: 0.0867
DEBUG - 2022-06-24 07:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:16:27 --> Total execution time: 0.0444
DEBUG - 2022-06-24 07:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:16:33 --> Total execution time: 0.0431
DEBUG - 2022-06-24 07:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:17:31 --> Total execution time: 0.0469
DEBUG - 2022-06-24 07:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:17:45 --> Total execution time: 0.0462
DEBUG - 2022-06-24 07:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:49:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 07:49:11 --> 404 Page Not Found: My-account/index
DEBUG - 2022-06-24 07:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:49:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 07:49:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 07:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:19:38 --> Total execution time: 0.0559
DEBUG - 2022-06-24 07:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:50:35 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:20:36 --> Total execution time: 0.1210
DEBUG - 2022-06-24 07:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:20:46 --> Total execution time: 0.0485
DEBUG - 2022-06-24 07:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:20:47 --> Total execution time: 0.0727
DEBUG - 2022-06-24 07:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:20:51 --> Total execution time: 0.0461
DEBUG - 2022-06-24 07:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:21:09 --> Total execution time: 0.0551
DEBUG - 2022-06-24 07:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:21:29 --> Total execution time: 0.0470
DEBUG - 2022-06-24 07:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:21:34 --> Total execution time: 0.0560
DEBUG - 2022-06-24 07:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:21:53 --> Total execution time: 0.0500
DEBUG - 2022-06-24 07:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:22:00 --> Total execution time: 0.0655
DEBUG - 2022-06-24 07:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:22:01 --> Total execution time: 0.0965
DEBUG - 2022-06-24 07:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:52:04 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:22:04 --> Total execution time: 0.0480
DEBUG - 2022-06-24 07:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:22:14 --> Total execution time: 0.0544
DEBUG - 2022-06-24 07:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:22:28 --> Total execution time: 0.0672
DEBUG - 2022-06-24 07:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:22:32 --> Total execution time: 0.0618
DEBUG - 2022-06-24 07:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:22:38 --> Total execution time: 0.0521
DEBUG - 2022-06-24 07:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:52:42 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:22:42 --> Total execution time: 0.0333
DEBUG - 2022-06-24 07:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:22:46 --> Total execution time: 0.0645
DEBUG - 2022-06-24 07:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:23:06 --> Total execution time: 0.1431
DEBUG - 2022-06-24 07:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:23:12 --> Total execution time: 0.0532
DEBUG - 2022-06-24 07:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:23:14 --> Total execution time: 0.0629
DEBUG - 2022-06-24 07:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:23:17 --> Total execution time: 0.0602
DEBUG - 2022-06-24 07:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:23:33 --> Total execution time: 0.0482
DEBUG - 2022-06-24 07:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:23:35 --> Total execution time: 0.0656
DEBUG - 2022-06-24 07:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:23:38 --> Total execution time: 0.0603
DEBUG - 2022-06-24 07:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:23:52 --> Total execution time: 0.0440
DEBUG - 2022-06-24 07:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:23:54 --> Total execution time: 0.0574
DEBUG - 2022-06-24 07:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:24:45 --> Total execution time: 0.0583
DEBUG - 2022-06-24 07:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:24:52 --> Total execution time: 0.0547
DEBUG - 2022-06-24 07:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:25:11 --> Total execution time: 0.0982
DEBUG - 2022-06-24 07:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:25:15 --> Total execution time: 0.0594
DEBUG - 2022-06-24 07:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:55:38 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:25:38 --> Total execution time: 0.0533
DEBUG - 2022-06-24 07:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:26:01 --> Total execution time: 0.0610
DEBUG - 2022-06-24 07:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:26:08 --> Total execution time: 0.0609
DEBUG - 2022-06-24 07:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:26:14 --> Total execution time: 0.0510
DEBUG - 2022-06-24 07:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:26:17 --> Total execution time: 0.0515
DEBUG - 2022-06-24 07:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:56:47 --> No URI present. Default controller set.
DEBUG - 2022-06-24 07:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:26:47 --> Total execution time: 0.1806
DEBUG - 2022-06-24 07:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:27:06 --> Total execution time: 0.0547
DEBUG - 2022-06-24 07:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:27:13 --> Total execution time: 0.0492
DEBUG - 2022-06-24 07:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 07:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:29:34 --> Total execution time: 0.0603
DEBUG - 2022-06-24 07:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 07:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:29:50 --> Total execution time: 0.0676
DEBUG - 2022-06-24 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:30:02 --> Total execution time: 0.0550
DEBUG - 2022-06-24 08:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:30:05 --> Total execution time: 0.1083
DEBUG - 2022-06-24 08:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:30:19 --> Total execution time: 2.0810
DEBUG - 2022-06-24 08:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:31:37 --> Total execution time: 0.1432
DEBUG - 2022-06-24 08:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:33:29 --> Total execution time: 0.0554
DEBUG - 2022-06-24 08:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:34:43 --> Total execution time: 0.1542
DEBUG - 2022-06-24 08:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:34:49 --> Total execution time: 0.0465
DEBUG - 2022-06-24 08:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:34:57 --> Total execution time: 0.0506
DEBUG - 2022-06-24 08:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:05:26 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:35:27 --> Total execution time: 0.0999
DEBUG - 2022-06-24 08:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:36:45 --> Total execution time: 0.0637
DEBUG - 2022-06-24 08:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:37:05 --> Total execution time: 0.1297
DEBUG - 2022-06-24 08:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:07:13 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:37:13 --> Total execution time: 0.0532
DEBUG - 2022-06-24 08:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:37:23 --> Total execution time: 0.0498
DEBUG - 2022-06-24 08:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:07:45 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:37:45 --> Total execution time: 0.1526
DEBUG - 2022-06-24 08:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:07:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 08:07:52 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 08:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:39:01 --> Total execution time: 0.0991
DEBUG - 2022-06-24 08:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:39:14 --> Total execution time: 0.0627
DEBUG - 2022-06-24 08:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:10:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 08:10:23 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 08:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:40:24 --> Total execution time: 0.0640
DEBUG - 2022-06-24 08:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:41:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 18:41:58 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-06-24 08:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:41:59 --> Total execution time: 0.0613
DEBUG - 2022-06-24 08:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:12:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 08:12:32 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 08:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:15:34 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:45:34 --> Total execution time: 0.1025
DEBUG - 2022-06-24 08:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:16:23 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:46:23 --> Total execution time: 0.0584
DEBUG - 2022-06-24 08:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:46:30 --> Total execution time: 0.0510
DEBUG - 2022-06-24 08:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:47:25 --> Total execution time: 0.0613
DEBUG - 2022-06-24 08:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:47:32 --> Total execution time: 0.0641
DEBUG - 2022-06-24 08:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:47:42 --> Total execution time: 0.0727
DEBUG - 2022-06-24 08:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:47:43 --> Total execution time: 0.0718
DEBUG - 2022-06-24 08:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:47:43 --> Total execution time: 0.0749
DEBUG - 2022-06-24 08:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:47:43 --> Total execution time: 0.0969
DEBUG - 2022-06-24 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:18:20 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:48:20 --> Total execution time: 0.0356
DEBUG - 2022-06-24 08:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:56:18 --> Total execution time: 0.0508
DEBUG - 2022-06-24 08:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:27:32 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:57:32 --> Total execution time: 0.0671
DEBUG - 2022-06-24 08:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:57:36 --> Total execution time: 0.0364
DEBUG - 2022-06-24 08:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:57:59 --> Total execution time: 0.0612
DEBUG - 2022-06-24 08:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:58:17 --> Total execution time: 0.0431
DEBUG - 2022-06-24 08:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:58:24 --> Total execution time: 0.0515
DEBUG - 2022-06-24 08:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:58:28 --> Total execution time: 0.0476
DEBUG - 2022-06-24 08:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:58:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 08:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:58:29 --> Total execution time: 0.0599
DEBUG - 2022-06-24 08:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:00:13 --> Total execution time: 0.0705
DEBUG - 2022-06-24 08:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:00:56 --> Total execution time: 0.0668
DEBUG - 2022-06-24 08:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:00:58 --> Total execution time: 0.0771
DEBUG - 2022-06-24 08:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:01:07 --> Total execution time: 0.1162
DEBUG - 2022-06-24 08:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:31:27 --> Total execution time: 0.0648
DEBUG - 2022-06-24 08:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:01:32 --> Total execution time: 0.0837
DEBUG - 2022-06-24 08:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:01:34 --> Total execution time: 0.0557
DEBUG - 2022-06-24 08:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:01:35 --> Total execution time: 0.0479
DEBUG - 2022-06-24 08:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:01:38 --> Total execution time: 0.0434
DEBUG - 2022-06-24 08:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:01:38 --> Total execution time: 0.0572
DEBUG - 2022-06-24 08:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:01:49 --> Total execution time: 0.0957
DEBUG - 2022-06-24 08:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:01:53 --> Total execution time: 0.0734
DEBUG - 2022-06-24 08:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:02:05 --> Total execution time: 0.1034
DEBUG - 2022-06-24 08:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:02:23 --> Total execution time: 0.2150
DEBUG - 2022-06-24 08:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:02:32 --> Total execution time: 0.1158
DEBUG - 2022-06-24 08:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:02:36 --> Total execution time: 0.0475
DEBUG - 2022-06-24 08:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:02:38 --> Total execution time: 0.0887
DEBUG - 2022-06-24 08:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:02:40 --> Total execution time: 0.0747
DEBUG - 2022-06-24 08:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:02:44 --> Total execution time: 0.0590
DEBUG - 2022-06-24 08:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:32:51 --> Total execution time: 0.0548
DEBUG - 2022-06-24 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:32:52 --> Total execution time: 0.0578
DEBUG - 2022-06-24 08:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:32:52 --> Total execution time: 0.1149
DEBUG - 2022-06-24 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:02:54 --> Total execution time: 0.0856
DEBUG - 2022-06-24 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:02:55 --> Total execution time: 0.0612
DEBUG - 2022-06-24 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:33:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:03:05 --> Total execution time: 0.0518
DEBUG - 2022-06-24 08:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:03:05 --> Total execution time: 0.0929
DEBUG - 2022-06-24 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:34:29 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:04:29 --> Total execution time: 0.0499
DEBUG - 2022-06-24 08:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 08:35:46 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 08:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:38:27 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:08:27 --> Total execution time: 0.0870
DEBUG - 2022-06-24 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:08:38 --> Total execution time: 0.0454
DEBUG - 2022-06-24 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:08:46 --> Total execution time: 0.0617
DEBUG - 2022-06-24 08:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:38:50 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:08:50 --> Total execution time: 0.0475
DEBUG - 2022-06-24 08:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:10:07 --> Total execution time: 0.1223
DEBUG - 2022-06-24 08:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:41:13 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:11:13 --> Total execution time: 0.0348
DEBUG - 2022-06-24 08:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:41:46 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:11:46 --> Total execution time: 0.0347
DEBUG - 2022-06-24 08:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:12:01 --> Total execution time: 0.0429
DEBUG - 2022-06-24 08:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:42:17 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:12:17 --> Total execution time: 0.0719
DEBUG - 2022-06-24 08:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:45:55 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:15:55 --> Total execution time: 0.0876
DEBUG - 2022-06-24 08:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:46:01 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:16:01 --> Total execution time: 0.0528
DEBUG - 2022-06-24 08:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:46:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:16:05 --> Total execution time: 0.0348
DEBUG - 2022-06-24 08:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:46:06 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:16:06 --> Total execution time: 0.0494
DEBUG - 2022-06-24 08:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:46:38 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:16:38 --> Total execution time: 0.0474
DEBUG - 2022-06-24 08:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:47:07 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:17:07 --> Total execution time: 0.0525
DEBUG - 2022-06-24 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:51:13 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:21:13 --> Total execution time: 0.1113
DEBUG - 2022-06-24 08:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:52:11 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:22:11 --> Total execution time: 0.0556
DEBUG - 2022-06-24 08:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:52:27 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:22:27 --> Total execution time: 0.0320
DEBUG - 2022-06-24 08:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:58:29 --> No URI present. Default controller set.
DEBUG - 2022-06-24 08:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:28:29 --> Total execution time: 0.1308
DEBUG - 2022-06-24 08:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:28:31 --> Total execution time: 0.0448
DEBUG - 2022-06-24 08:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 08:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 08:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 08:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:28:33 --> Total execution time: 0.0435
DEBUG - 2022-06-24 09:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:00:23 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:30:23 --> Total execution time: 0.0925
DEBUG - 2022-06-24 09:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:30:49 --> Total execution time: 0.1426
DEBUG - 2022-06-24 09:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:30:50 --> Total execution time: 0.1309
DEBUG - 2022-06-24 09:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:31:03 --> Total execution time: 0.0949
DEBUG - 2022-06-24 09:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:31:08 --> Total execution time: 0.1677
DEBUG - 2022-06-24 09:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:31:21 --> Total execution time: 0.1885
DEBUG - 2022-06-24 09:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:31:21 --> Total execution time: 0.1380
DEBUG - 2022-06-24 09:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:02:19 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:32:19 --> Total execution time: 0.3328
DEBUG - 2022-06-24 09:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:32:29 --> Total execution time: 0.1588
DEBUG - 2022-06-24 09:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:32:35 --> Total execution time: 0.2743
DEBUG - 2022-06-24 09:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:32:37 --> Total execution time: 0.2320
DEBUG - 2022-06-24 09:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:32:41 --> Total execution time: 0.1561
DEBUG - 2022-06-24 09:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:02:42 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:32:42 --> Total execution time: 0.1923
DEBUG - 2022-06-24 09:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:02:43 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:32:43 --> Total execution time: 0.1834
DEBUG - 2022-06-24 09:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:02:45 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:32:46 --> Total execution time: 0.1868
DEBUG - 2022-06-24 09:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:33:42 --> Total execution time: 0.0608
DEBUG - 2022-06-24 09:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:34:10 --> Total execution time: 0.0952
DEBUG - 2022-06-24 09:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:34:27 --> Total execution time: 0.0774
DEBUG - 2022-06-24 09:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:36:37 --> Total execution time: 0.0697
DEBUG - 2022-06-24 09:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:37:00 --> Total execution time: 0.0461
DEBUG - 2022-06-24 09:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:38:04 --> Total execution time: 0.0579
DEBUG - 2022-06-24 09:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:38:10 --> Total execution time: 0.0698
DEBUG - 2022-06-24 09:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:38:30 --> Total execution time: 0.0460
DEBUG - 2022-06-24 09:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:38:34 --> Total execution time: 0.0580
DEBUG - 2022-06-24 09:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:09:39 --> Total execution time: 0.0568
DEBUG - 2022-06-24 09:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:09:47 --> Total execution time: 0.1033
DEBUG - 2022-06-24 09:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:40:12 --> Total execution time: 0.1181
DEBUG - 2022-06-24 09:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:40:23 --> Total execution time: 0.0592
DEBUG - 2022-06-24 09:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:40:32 --> Total execution time: 0.0566
DEBUG - 2022-06-24 09:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:40:32 --> Total execution time: 0.0513
DEBUG - 2022-06-24 09:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:40:33 --> Total execution time: 0.0465
DEBUG - 2022-06-24 09:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:40:38 --> Total execution time: 0.0994
DEBUG - 2022-06-24 09:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:41:04 --> Total execution time: 0.0610
DEBUG - 2022-06-24 09:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:41:15 --> Total execution time: 0.0827
DEBUG - 2022-06-24 09:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:11:28 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:41:29 --> Total execution time: 0.1873
DEBUG - 2022-06-24 09:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:43:05 --> Total execution time: 0.1672
DEBUG - 2022-06-24 09:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:43:14 --> Total execution time: 0.0653
DEBUG - 2022-06-24 09:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:43:18 --> Total execution time: 0.0763
DEBUG - 2022-06-24 09:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:43:25 --> Total execution time: 0.0538
DEBUG - 2022-06-24 09:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:43:36 --> Total execution time: 0.0578
DEBUG - 2022-06-24 09:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:14:15 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:44:15 --> Total execution time: 0.0408
DEBUG - 2022-06-24 09:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:14:48 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:44:48 --> Total execution time: 0.0583
DEBUG - 2022-06-24 09:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:45:10 --> Total execution time: 0.0429
DEBUG - 2022-06-24 09:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:16:34 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:46:34 --> Total execution time: 0.0404
DEBUG - 2022-06-24 09:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:17:17 --> Total execution time: 0.0368
DEBUG - 2022-06-24 09:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:17:20 --> Total execution time: 0.0496
DEBUG - 2022-06-24 09:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:17:20 --> Total execution time: 0.1479
DEBUG - 2022-06-24 09:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:17:45 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:47:45 --> Total execution time: 0.0312
DEBUG - 2022-06-24 09:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:47:51 --> Total execution time: 0.0299
DEBUG - 2022-06-24 09:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:47:58 --> Total execution time: 0.0512
DEBUG - 2022-06-24 09:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:48:12 --> Total execution time: 0.1135
DEBUG - 2022-06-24 09:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:18:17 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:48:18 --> Total execution time: 0.0358
DEBUG - 2022-06-24 09:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:19:10 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:49:10 --> Total execution time: 0.0617
DEBUG - 2022-06-24 09:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:52:29 --> Total execution time: 0.0981
DEBUG - 2022-06-24 09:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:26:07 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:56:07 --> Total execution time: 0.1062
DEBUG - 2022-06-24 09:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:26:08 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:56:08 --> Total execution time: 0.0303
DEBUG - 2022-06-24 09:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:26:15 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:56:15 --> Total execution time: 0.0385
DEBUG - 2022-06-24 09:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:26:25 --> Total execution time: 0.0424
DEBUG - 2022-06-24 09:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:26:27 --> Total execution time: 0.0475
DEBUG - 2022-06-24 09:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:26:27 --> Total execution time: 0.0980
DEBUG - 2022-06-24 09:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:26:48 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:56:48 --> Total execution time: 0.0461
DEBUG - 2022-06-24 09:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:28:54 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:58:54 --> Total execution time: 0.0892
DEBUG - 2022-06-24 09:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:30:06 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:00:06 --> Total execution time: 0.0683
DEBUG - 2022-06-24 09:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:32:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:06 --> Total execution time: 0.0387
DEBUG - 2022-06-24 09:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:12 --> Total execution time: 0.0705
DEBUG - 2022-06-24 09:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:21 --> Total execution time: 0.0526
DEBUG - 2022-06-24 09:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:29 --> Total execution time: 0.0566
DEBUG - 2022-06-24 09:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:03:02 --> Total execution time: 0.1624
DEBUG - 2022-06-24 09:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:03:21 --> Total execution time: 0.0516
DEBUG - 2022-06-24 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:03:28 --> Total execution time: 0.1306
DEBUG - 2022-06-24 09:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:03:36 --> Total execution time: 0.0640
DEBUG - 2022-06-24 09:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:41:24 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:11:24 --> Total execution time: 0.1162
DEBUG - 2022-06-24 09:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:46:51 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:16:51 --> Total execution time: 0.1107
DEBUG - 2022-06-24 09:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:47:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 09:47:37 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 09:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:49:22 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:19:22 --> Total execution time: 0.1502
DEBUG - 2022-06-24 09:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:19:46 --> Total execution time: 0.1146
DEBUG - 2022-06-24 09:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:49:47 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:19:47 --> Total execution time: 0.0361
DEBUG - 2022-06-24 09:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 09:50:10 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 09:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:51:59 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:21:59 --> Total execution time: 0.0354
DEBUG - 2022-06-24 09:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:51:59 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:21:59 --> Total execution time: 0.0373
DEBUG - 2022-06-24 09:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 09:52:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 09:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:52:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 09:52:21 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 09:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:56:34 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:26:34 --> Total execution time: 0.1579
DEBUG - 2022-06-24 09:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:58:21 --> No URI present. Default controller set.
DEBUG - 2022-06-24 09:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:28:21 --> Total execution time: 0.0421
DEBUG - 2022-06-24 09:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:28:37 --> Total execution time: 0.0445
DEBUG - 2022-06-24 09:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 09:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:28:48 --> Total execution time: 0.0737
DEBUG - 2022-06-24 09:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:28:57 --> Total execution time: 0.0664
DEBUG - 2022-06-24 09:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 09:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:29:02 --> Total execution time: 0.0633
DEBUG - 2022-06-24 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:30:02 --> Total execution time: 0.0677
DEBUG - 2022-06-24 10:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:00:48 --> No URI present. Default controller set.
DEBUG - 2022-06-24 10:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:30:48 --> Total execution time: 0.0395
DEBUG - 2022-06-24 10:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 10:00:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 10:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:31:57 --> Total execution time: 0.0725
DEBUG - 2022-06-24 10:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:31:58 --> Total execution time: 0.0618
DEBUG - 2022-06-24 10:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:32:10 --> Total execution time: 0.0487
DEBUG - 2022-06-24 10:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:02:18 --> No URI present. Default controller set.
DEBUG - 2022-06-24 10:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:32:18 --> Total execution time: 0.0521
DEBUG - 2022-06-24 10:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:33:53 --> Total execution time: 0.0514
DEBUG - 2022-06-24 10:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:03:59 --> No URI present. Default controller set.
DEBUG - 2022-06-24 10:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:33:59 --> Total execution time: 0.1095
DEBUG - 2022-06-24 10:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:06:02 --> Total execution time: 0.0901
DEBUG - 2022-06-24 10:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:36:07 --> Total execution time: 0.1147
DEBUG - 2022-06-24 10:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:06:08 --> Total execution time: 0.0525
DEBUG - 2022-06-24 10:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:06:08 --> Total execution time: 0.0591
DEBUG - 2022-06-24 10:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:37:34 --> Total execution time: 0.0532
DEBUG - 2022-06-24 10:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 10:08:18 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-24 10:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:38:25 --> Total execution time: 0.0574
DEBUG - 2022-06-24 10:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:08:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 10:08:30 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-24 10:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:08:36 --> No URI present. Default controller set.
DEBUG - 2022-06-24 10:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:38:36 --> Total execution time: 0.0714
DEBUG - 2022-06-24 10:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:38:37 --> Total execution time: 0.0496
DEBUG - 2022-06-24 10:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:38:39 --> Total execution time: 0.0717
DEBUG - 2022-06-24 10:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:39:28 --> Total execution time: 0.0643
DEBUG - 2022-06-24 10:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:39:53 --> Total execution time: 0.0558
DEBUG - 2022-06-24 10:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:40:02 --> Total execution time: 0.1503
DEBUG - 2022-06-24 10:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:40:15 --> Total execution time: 0.0759
DEBUG - 2022-06-24 10:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:40:27 --> Total execution time: 0.0702
DEBUG - 2022-06-24 10:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:40:31 --> Total execution time: 0.0517
DEBUG - 2022-06-24 10:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:40:42 --> Total execution time: 0.0559
DEBUG - 2022-06-24 10:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:42:21 --> Total execution time: 0.1098
DEBUG - 2022-06-24 10:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:42:41 --> Total execution time: 0.1133
DEBUG - 2022-06-24 10:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:43:34 --> Total execution time: 0.0457
DEBUG - 2022-06-24 10:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:43:52 --> Total execution time: 0.0485
DEBUG - 2022-06-24 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:43:54 --> Total execution time: 0.0449
DEBUG - 2022-06-24 10:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:14:03 --> No URI present. Default controller set.
DEBUG - 2022-06-24 10:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:44:03 --> Total execution time: 0.0336
DEBUG - 2022-06-24 10:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:44:44 --> Total execution time: 0.0498
DEBUG - 2022-06-24 10:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:15:57 --> No URI present. Default controller set.
DEBUG - 2022-06-24 10:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:45:57 --> Total execution time: 0.1017
DEBUG - 2022-06-24 10:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:16:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 10:16:11 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 10:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:49:57 --> Total execution time: 0.1702
DEBUG - 2022-06-24 10:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:50:01 --> Total execution time: 0.0518
DEBUG - 2022-06-24 10:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:50:23 --> Total execution time: 0.0540
DEBUG - 2022-06-24 10:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:50:27 --> Total execution time: 0.0504
DEBUG - 2022-06-24 10:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:50:46 --> Total execution time: 0.0493
DEBUG - 2022-06-24 10:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:50:53 --> Total execution time: 0.0465
DEBUG - 2022-06-24 10:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:26:07 --> No URI present. Default controller set.
DEBUG - 2022-06-24 10:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:56:07 --> Total execution time: 0.1219
DEBUG - 2022-06-24 10:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:26:16 --> No URI present. Default controller set.
DEBUG - 2022-06-24 10:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:56:16 --> Total execution time: 0.0430
DEBUG - 2022-06-24 10:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:58:00 --> Total execution time: 0.0568
DEBUG - 2022-06-24 10:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:59:57 --> Total execution time: 0.0464
DEBUG - 2022-06-24 10:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:30:08 --> No URI present. Default controller set.
DEBUG - 2022-06-24 10:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:00:08 --> Total execution time: 0.0857
DEBUG - 2022-06-24 10:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:30:49 --> No URI present. Default controller set.
DEBUG - 2022-06-24 10:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:00:49 --> Total execution time: 0.0600
DEBUG - 2022-06-24 10:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:01:05 --> Total execution time: 0.0452
DEBUG - 2022-06-24 10:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:01:21 --> Total execution time: 0.0692
DEBUG - 2022-06-24 10:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:01:36 --> Total execution time: 0.0682
DEBUG - 2022-06-24 10:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:01:48 --> Total execution time: 0.0527
DEBUG - 2022-06-24 10:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:01:48 --> Total execution time: 0.0653
DEBUG - 2022-06-24 10:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:35:32 --> No URI present. Default controller set.
DEBUG - 2022-06-24 10:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:05:32 --> Total execution time: 0.0875
DEBUG - 2022-06-24 10:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:11:25 --> Total execution time: 0.0955
DEBUG - 2022-06-24 10:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:15:57 --> Total execution time: 0.0903
DEBUG - 2022-06-24 10:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:16:40 --> Total execution time: 0.0524
DEBUG - 2022-06-24 10:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:17:47 --> Total execution time: 0.1222
DEBUG - 2022-06-24 10:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:19:17 --> Total execution time: 0.0453
DEBUG - 2022-06-24 10:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 10:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:19:25 --> Total execution time: 0.0529
DEBUG - 2022-06-24 10:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:19:43 --> Total execution time: 0.0632
DEBUG - 2022-06-24 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:19:53 --> Total execution time: 0.0523
DEBUG - 2022-06-24 10:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:20:08 --> Total execution time: 0.0506
DEBUG - 2022-06-24 10:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:53:17 --> No URI present. Default controller set.
DEBUG - 2022-06-24 10:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:23:17 --> Total execution time: 0.1025
DEBUG - 2022-06-24 10:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:53:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 10:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:23:40 --> Total execution time: 0.0438
DEBUG - 2022-06-24 10:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:53:53 --> No URI present. Default controller set.
DEBUG - 2022-06-24 10:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:23:53 --> Total execution time: 0.0637
DEBUG - 2022-06-24 10:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 10:54:03 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-24 10:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:55:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 10:55:22 --> 404 Page Not Found: Wp-content/app.php
DEBUG - 2022-06-24 10:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 10:55:49 --> 404 Page Not Found: Assets/global
DEBUG - 2022-06-24 10:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 10:59:44 --> 404 Page Not Found: Toolphp/index
DEBUG - 2022-06-24 10:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:59:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 10:59:51 --> 404 Page Not Found: Wp-admin/tool.php
DEBUG - 2022-06-24 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:30:02 --> Total execution time: 0.2676
DEBUG - 2022-06-24 11:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:00:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:00:56 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-24 11:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:02:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:02:28 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-06-24 11:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:02:52 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:32:52 --> Total execution time: 0.0480
DEBUG - 2022-06-24 11:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:02:52 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:32:52 --> Total execution time: 0.0313
DEBUG - 2022-06-24 11:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:33:02 --> Total execution time: 0.0320
DEBUG - 2022-06-24 11:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:03:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:03:09 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-06-24 11:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:03:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:03:20 --> 404 Page Not Found: Authorizephp/index
DEBUG - 2022-06-24 11:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:03:34 --> 404 Page Not Found: Wp-admin/include.php
DEBUG - 2022-06-24 11:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:33:50 --> Total execution time: 0.0505
DEBUG - 2022-06-24 11:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:04:07 --> 404 Page Not Found: Wp-content/cache.php
DEBUG - 2022-06-24 11:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:34:26 --> Total execution time: 0.0361
DEBUG - 2022-06-24 11:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:04:36 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:34:36 --> Total execution time: 0.0574
DEBUG - 2022-06-24 11:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:08:32 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:38:32 --> Total execution time: 0.0991
DEBUG - 2022-06-24 11:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:08:52 --> Total execution time: 0.0551
DEBUG - 2022-06-24 11:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:08:54 --> Total execution time: 0.0661
DEBUG - 2022-06-24 11:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:08:54 --> Total execution time: 0.0869
DEBUG - 2022-06-24 11:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:09:37 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:39:37 --> Total execution time: 0.0623
DEBUG - 2022-06-24 11:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:09:48 --> Total execution time: 0.0471
DEBUG - 2022-06-24 11:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:10:00 --> Total execution time: 0.0794
DEBUG - 2022-06-24 11:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:10:00 --> Total execution time: 0.1460
DEBUG - 2022-06-24 11:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:10:31 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:40:31 --> Total execution time: 0.0585
DEBUG - 2022-06-24 11:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:40:33 --> Total execution time: 0.0464
DEBUG - 2022-06-24 11:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:40:41 --> Total execution time: 0.0578
DEBUG - 2022-06-24 11:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:40:50 --> Total execution time: 0.0774
DEBUG - 2022-06-24 11:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:41:01 --> Total execution time: 0.0901
DEBUG - 2022-06-24 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:41:13 --> Total execution time: 0.0594
DEBUG - 2022-06-24 11:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:41:27 --> Total execution time: 0.0613
DEBUG - 2022-06-24 11:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:41:31 --> Total execution time: 0.0534
DEBUG - 2022-06-24 11:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:41:34 --> Total execution time: 0.0479
DEBUG - 2022-06-24 11:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:41:35 --> Total execution time: 0.0629
DEBUG - 2022-06-24 11:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:41:39 --> Total execution time: 0.0682
DEBUG - 2022-06-24 11:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:41:46 --> Total execution time: 0.0799
DEBUG - 2022-06-24 11:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:41:58 --> Total execution time: 0.1264
DEBUG - 2022-06-24 11:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:42:08 --> Total execution time: 0.0484
DEBUG - 2022-06-24 11:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:12:21 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:42:21 --> Total execution time: 0.0432
DEBUG - 2022-06-24 11:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:42:25 --> Total execution time: 0.1376
DEBUG - 2022-06-24 11:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:42:30 --> Total execution time: 0.0711
DEBUG - 2022-06-24 11:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:12:51 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:42:51 --> Total execution time: 0.0462
DEBUG - 2022-06-24 11:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:42:55 --> Total execution time: 0.0381
DEBUG - 2022-06-24 11:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:13:19 --> Total execution time: 0.0452
DEBUG - 2022-06-24 11:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:13:27 --> Total execution time: 0.0430
DEBUG - 2022-06-24 11:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:13:28 --> Total execution time: 0.0404
DEBUG - 2022-06-24 11:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:43:32 --> Total execution time: 0.0598
DEBUG - 2022-06-24 11:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:13:35 --> Total execution time: 0.0375
DEBUG - 2022-06-24 11:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:43:45 --> Total execution time: 0.0492
DEBUG - 2022-06-24 11:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:43:46 --> Total execution time: 0.0486
DEBUG - 2022-06-24 11:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:13:47 --> Total execution time: 0.0480
DEBUG - 2022-06-24 11:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:13:49 --> Total execution time: 0.0510
DEBUG - 2022-06-24 11:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:43:59 --> Total execution time: 0.0856
DEBUG - 2022-06-24 11:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:14:08 --> Total execution time: 0.0419
DEBUG - 2022-06-24 11:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:44:11 --> Total execution time: 0.0584
DEBUG - 2022-06-24 11:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:14:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:44:14 --> Total execution time: 0.1165
DEBUG - 2022-06-24 11:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:44:22 --> Total execution time: 0.0488
DEBUG - 2022-06-24 11:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:44:31 --> Total execution time: 0.0603
DEBUG - 2022-06-24 11:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:14:34 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:44:34 --> Total execution time: 0.0461
DEBUG - 2022-06-24 11:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:45:06 --> Total execution time: 0.0346
DEBUG - 2022-06-24 11:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:45:32 --> Total execution time: 0.0803
DEBUG - 2022-06-24 11:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:15:35 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:45:35 --> Total execution time: 0.0567
DEBUG - 2022-06-24 11:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:46:44 --> Total execution time: 0.0366
DEBUG - 2022-06-24 11:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:47:22 --> Total execution time: 0.0736
DEBUG - 2022-06-24 11:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:47:30 --> Total execution time: 0.0533
DEBUG - 2022-06-24 11:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:47:39 --> Total execution time: 0.0585
DEBUG - 2022-06-24 11:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:48:59 --> Total execution time: 0.0511
DEBUG - 2022-06-24 11:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:49:05 --> Total execution time: 0.0450
DEBUG - 2022-06-24 11:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:52:30 --> Total execution time: 0.1204
DEBUG - 2022-06-24 11:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:52:36 --> Total execution time: 0.0590
DEBUG - 2022-06-24 11:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:52:38 --> Total execution time: 0.0564
DEBUG - 2022-06-24 11:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:52:40 --> Total execution time: 0.0897
DEBUG - 2022-06-24 11:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:52:47 --> Total execution time: 0.0817
DEBUG - 2022-06-24 11:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:53:16 --> Total execution time: 0.0967
DEBUG - 2022-06-24 11:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:53:18 --> Total execution time: 0.0581
DEBUG - 2022-06-24 11:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:25:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:55:40 --> Total execution time: 0.0877
DEBUG - 2022-06-24 11:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:56:00 --> Total execution time: 0.0588
DEBUG - 2022-06-24 11:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:26:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:26:10 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-06-24 11:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:10 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:26:10 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-06-24 11:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:56:10 --> Total execution time: 0.0475
DEBUG - 2022-06-24 11:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:56:10 --> Total execution time: 0.0483
DEBUG - 2022-06-24 11:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:26:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 11:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:56:11 --> Total execution time: 0.0443
DEBUG - 2022-06-24 11:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:56:11 --> Total execution time: 0.1485
DEBUG - 2022-06-24 11:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:26:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 11:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:56:13 --> Total execution time: 0.0595
DEBUG - 2022-06-24 11:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:56:14 --> Total execution time: 0.0521
DEBUG - 2022-06-24 11:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:56:17 --> Total execution time: 0.0536
DEBUG - 2022-06-24 11:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:56:25 --> Total execution time: 0.0505
DEBUG - 2022-06-24 11:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:56:27 --> Total execution time: 0.0426
DEBUG - 2022-06-24 11:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:56:37 --> Total execution time: 0.1091
DEBUG - 2022-06-24 11:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:56:52 --> Total execution time: 0.0455
DEBUG - 2022-06-24 11:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:27:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:27:27 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 11:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:57:28 --> Total execution time: 0.0502
DEBUG - 2022-06-24 11:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:57:36 --> Total execution time: 0.0429
DEBUG - 2022-06-24 11:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:57:54 --> Total execution time: 0.0827
DEBUG - 2022-06-24 11:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:57:59 --> Total execution time: 0.0431
DEBUG - 2022-06-24 11:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:58:15 --> Total execution time: 0.0722
DEBUG - 2022-06-24 11:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:58:18 --> Total execution time: 0.1070
DEBUG - 2022-06-24 11:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:58:24 --> Total execution time: 0.0445
DEBUG - 2022-06-24 11:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:58:39 --> Total execution time: 0.0447
DEBUG - 2022-06-24 11:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:59:25 --> Total execution time: 0.0637
DEBUG - 2022-06-24 11:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:29:54 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 11:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:32:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:32:04 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 11:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:32:32 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:02:32 --> Total execution time: 0.0756
DEBUG - 2022-06-24 11:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:05:14 --> Total execution time: 0.0938
DEBUG - 2022-06-24 11:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:35:24 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:05:24 --> Total execution time: 0.0415
DEBUG - 2022-06-24 11:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:35:37 --> Total execution time: 0.0856
DEBUG - 2022-06-24 11:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:35:38 --> Total execution time: 0.0444
DEBUG - 2022-06-24 11:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:35:38 --> Total execution time: 0.0431
DEBUG - 2022-06-24 11:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:35:40 --> Total execution time: 0.0662
DEBUG - 2022-06-24 11:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:35:40 --> Total execution time: 0.1216
DEBUG - 2022-06-24 11:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:36:57 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:06:57 --> Total execution time: 0.0525
DEBUG - 2022-06-24 11:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:37:12 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:12 --> Total execution time: 0.0352
DEBUG - 2022-06-24 11:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:37:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:14 --> Total execution time: 0.0406
DEBUG - 2022-06-24 11:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:19 --> Total execution time: 0.0567
DEBUG - 2022-06-24 11:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:31 --> Total execution time: 0.0554
DEBUG - 2022-06-24 11:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:32 --> Total execution time: 0.0497
DEBUG - 2022-06-24 11:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:36 --> Total execution time: 0.0695
DEBUG - 2022-06-24 11:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:43 --> Total execution time: 0.0740
DEBUG - 2022-06-24 11:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:00 --> Total execution time: 0.0430
DEBUG - 2022-06-24 11:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:03 --> Total execution time: 0.0400
DEBUG - 2022-06-24 11:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:38:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 11:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:06 --> Total execution time: 1.9452
DEBUG - 2022-06-24 11:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:38:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 11:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:10 --> Total execution time: 0.0513
DEBUG - 2022-06-24 11:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:30 --> Total execution time: 0.1932
DEBUG - 2022-06-24 11:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:34 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:34 --> Total execution time: 0.1119
DEBUG - 2022-06-24 11:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:35 --> Total execution time: 0.0486
DEBUG - 2022-06-24 11:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:37 --> Total execution time: 0.0576
DEBUG - 2022-06-24 11:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 11:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:39 --> Total execution time: 0.0485
DEBUG - 2022-06-24 11:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:39 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:39 --> Total execution time: 0.0604
DEBUG - 2022-06-24 11:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:40 --> Total execution time: 0.0481
DEBUG - 2022-06-24 11:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 22:08:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 22:08:42 --> Total execution time: 0.1993
DEBUG - 2022-06-24 11:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:43 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:43 --> Total execution time: 0.0392
DEBUG - 2022-06-24 11:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:44 --> Total execution time: 0.0437
DEBUG - 2022-06-24 11:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:08:54 --> Total execution time: 0.0708
DEBUG - 2022-06-24 11:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:09:02 --> Total execution time: 0.0524
DEBUG - 2022-06-24 11:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:09:02 --> Total execution time: 0.1050
DEBUG - 2022-06-24 11:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:09:05 --> Total execution time: 0.0826
DEBUG - 2022-06-24 11:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:09:10 --> Total execution time: 0.0680
DEBUG - 2022-06-24 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:09:12 --> Total execution time: 0.0438
DEBUG - 2022-06-24 11:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:09:13 --> Total execution time: 0.0494
DEBUG - 2022-06-24 11:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:09:19 --> Total execution time: 0.0713
DEBUG - 2022-06-24 11:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:09:29 --> Total execution time: 0.0610
DEBUG - 2022-06-24 11:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:40:02 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:10:02 --> Total execution time: 0.1937
DEBUG - 2022-06-24 11:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:10:03 --> Total execution time: 0.0705
DEBUG - 2022-06-24 11:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:10:05 --> Total execution time: 0.0502
DEBUG - 2022-06-24 11:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:10:16 --> Total execution time: 0.0356
DEBUG - 2022-06-24 11:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:41:35 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:11:35 --> Total execution time: 0.1103
DEBUG - 2022-06-24 11:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:11:55 --> Total execution time: 0.0327
DEBUG - 2022-06-24 11:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:12:10 --> Total execution time: 0.0559
DEBUG - 2022-06-24 11:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:12:16 --> Total execution time: 0.0576
DEBUG - 2022-06-24 11:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:12:33 --> Total execution time: 0.0579
DEBUG - 2022-06-24 11:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:12:37 --> Total execution time: 0.0518
DEBUG - 2022-06-24 11:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:12:51 --> Total execution time: 0.0526
DEBUG - 2022-06-24 11:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:12:56 --> Total execution time: 0.1021
DEBUG - 2022-06-24 11:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:13:06 --> Total execution time: 0.0564
DEBUG - 2022-06-24 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:13:11 --> Total execution time: 0.0623
DEBUG - 2022-06-24 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:13:12 --> Total execution time: 0.0517
DEBUG - 2022-06-24 11:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:13:15 --> Total execution time: 0.0616
DEBUG - 2022-06-24 11:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:43:19 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:13:19 --> Total execution time: 0.0542
DEBUG - 2022-06-24 11:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:43:46 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:13:46 --> Total execution time: 0.0463
DEBUG - 2022-06-24 11:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:44:26 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:14:26 --> Total execution time: 0.0539
DEBUG - 2022-06-24 11:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:14:28 --> Total execution time: 0.0458
DEBUG - 2022-06-24 11:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:45:59 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:15:59 --> Total execution time: 0.0459
DEBUG - 2022-06-24 11:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:45:59 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:15:59 --> Total execution time: 0.0489
DEBUG - 2022-06-24 11:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:46:22 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:16:22 --> Total execution time: 0.0691
DEBUG - 2022-06-24 11:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:16:56 --> Total execution time: 0.0491
DEBUG - 2022-06-24 22:16:57 --> Total execution time: 1.5043
DEBUG - 2022-06-24 11:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:47:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:47:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 11:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:47:38 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:17:39 --> Total execution time: 0.1199
DEBUG - 2022-06-24 11:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:47:41 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:17:41 --> Total execution time: 0.0483
DEBUG - 2022-06-24 11:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:17:57 --> Total execution time: 0.0479
DEBUG - 2022-06-24 11:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:18:06 --> Total execution time: 0.0446
DEBUG - 2022-06-24 11:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:18:12 --> Total execution time: 0.0750
DEBUG - 2022-06-24 11:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:18:24 --> Total execution time: 0.0580
DEBUG - 2022-06-24 11:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:18:29 --> Total execution time: 0.0470
DEBUG - 2022-06-24 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:18:37 --> Total execution time: 0.0425
DEBUG - 2022-06-24 11:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:18:50 --> Total execution time: 0.0470
DEBUG - 2022-06-24 11:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:18:55 --> Total execution time: 0.0478
DEBUG - 2022-06-24 11:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:04 --> Total execution time: 0.1062
DEBUG - 2022-06-24 11:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:18 --> Total execution time: 0.0434
DEBUG - 2022-06-24 11:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:21 --> Total execution time: 0.0437
DEBUG - 2022-06-24 11:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:24 --> Total execution time: 0.0465
DEBUG - 2022-06-24 11:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:26 --> Total execution time: 0.0438
DEBUG - 2022-06-24 11:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:49:29 --> Total execution time: 0.0437
DEBUG - 2022-06-24 11:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:49:48 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:19:48 --> Total execution time: 0.0329
DEBUG - 2022-06-24 11:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:19:52 --> Total execution time: 0.0723
DEBUG - 2022-06-24 11:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:19:55 --> Total execution time: 0.0337
DEBUG - 2022-06-24 11:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:20:13 --> Total execution time: 0.0531
DEBUG - 2022-06-24 11:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:20:24 --> Total execution time: 0.1953
DEBUG - 2022-06-24 11:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:20:37 --> Total execution time: 0.0478
DEBUG - 2022-06-24 11:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:50:48 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:20:48 --> Total execution time: 0.0376
DEBUG - 2022-06-24 11:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:50:55 --> Total execution time: 0.0603
DEBUG - 2022-06-24 11:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:50:57 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:20:57 --> Total execution time: 0.0341
DEBUG - 2022-06-24 11:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:50:59 --> Total execution time: 0.0464
DEBUG - 2022-06-24 11:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:50:59 --> Total execution time: 0.0732
DEBUG - 2022-06-24 11:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:22:08 --> Total execution time: 0.1058
DEBUG - 2022-06-24 11:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:52:45 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:22:45 --> Total execution time: 0.0520
DEBUG - 2022-06-24 11:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:52:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 11:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:22:48 --> Total execution time: 1.5437
DEBUG - 2022-06-24 11:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:53:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 11:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:53:32 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:23:32 --> Total execution time: 0.0491
DEBUG - 2022-06-24 11:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:23:44 --> Total execution time: 0.0465
DEBUG - 2022-06-24 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:54:28 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:24:28 --> Total execution time: 0.0382
DEBUG - 2022-06-24 11:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:54:53 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:24:53 --> Total execution time: 0.0395
DEBUG - 2022-06-24 11:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:54:57 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:24:57 --> Total execution time: 0.0435
DEBUG - 2022-06-24 11:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:25:07 --> Total execution time: 0.0474
DEBUG - 2022-06-24 11:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:55:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 11:55:11 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 11:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:25:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 11:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:25:15 --> Total execution time: 0.0509
DEBUG - 2022-06-24 11:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:25:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 22:25:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 22:25:16 --> Total execution time: 0.2225
DEBUG - 2022-06-24 11:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:25:26 --> Total execution time: 0.0609
DEBUG - 2022-06-24 11:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:25:26 --> Total execution time: 0.1151
DEBUG - 2022-06-24 11:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:55:33 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:25:33 --> Total execution time: 0.0465
DEBUG - 2022-06-24 11:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:25:47 --> Total execution time: 0.0695
DEBUG - 2022-06-24 11:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:55:51 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:25:51 --> Total execution time: 0.0483
DEBUG - 2022-06-24 11:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:25:56 --> Total execution time: 0.0466
DEBUG - 2022-06-24 11:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:26:09 --> Total execution time: 0.0438
DEBUG - 2022-06-24 11:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:26:31 --> Total execution time: 0.0630
DEBUG - 2022-06-24 11:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:26:36 --> Total execution time: 0.0487
DEBUG - 2022-06-24 11:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:26:39 --> Total execution time: 0.0681
DEBUG - 2022-06-24 11:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:26:45 --> Total execution time: 0.0438
DEBUG - 2022-06-24 11:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:57:04 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:27:04 --> Total execution time: 0.0348
DEBUG - 2022-06-24 11:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:57:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:27:05 --> Total execution time: 0.0352
DEBUG - 2022-06-24 11:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:57:09 --> No URI present. Default controller set.
DEBUG - 2022-06-24 11:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:27:09 --> Total execution time: 0.0358
DEBUG - 2022-06-24 11:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:27:13 --> Total execution time: 0.1004
DEBUG - 2022-06-24 11:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:27:16 --> Total execution time: 0.0435
DEBUG - 2022-06-24 11:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:27:32 --> Total execution time: 0.0552
DEBUG - 2022-06-24 11:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:27:34 --> Total execution time: 0.0695
DEBUG - 2022-06-24 11:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:27:38 --> Total execution time: 0.0717
DEBUG - 2022-06-24 11:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:28:55 --> Total execution time: 0.1258
DEBUG - 2022-06-24 11:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:29:03 --> Total execution time: 0.0609
DEBUG - 2022-06-24 11:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 11:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:29:04 --> Total execution time: 0.0546
DEBUG - 2022-06-24 11:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 11:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:29:09 --> Total execution time: 0.0730
DEBUG - 2022-06-24 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:30:03 --> Total execution time: 0.0493
DEBUG - 2022-06-24 12:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:00:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 12:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:30:05 --> Total execution time: 0.0429
DEBUG - 2022-06-24 12:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:30:12 --> Total execution time: 0.0472
DEBUG - 2022-06-24 12:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:30:16 --> Total execution time: 0.0629
DEBUG - 2022-06-24 12:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:30:27 --> Total execution time: 0.0647
DEBUG - 2022-06-24 12:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:00:27 --> No URI present. Default controller set.
DEBUG - 2022-06-24 12:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:30:27 --> Total execution time: 0.0760
DEBUG - 2022-06-24 12:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:30:40 --> Total execution time: 0.0470
DEBUG - 2022-06-24 12:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:30:43 --> Total execution time: 0.0550
DEBUG - 2022-06-24 12:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:30:52 --> Total execution time: 0.0494
DEBUG - 2022-06-24 12:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:31:02 --> Total execution time: 0.0924
DEBUG - 2022-06-24 12:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:31:19 --> Total execution time: 0.0825
DEBUG - 2022-06-24 12:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:31:22 --> Total execution time: 0.0420
DEBUG - 2022-06-24 12:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:31:26 --> Total execution time: 0.0568
DEBUG - 2022-06-24 12:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:31:30 --> Total execution time: 0.1056
DEBUG - 2022-06-24 12:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:31:30 --> Total execution time: 0.0577
DEBUG - 2022-06-24 12:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:31:35 --> Total execution time: 0.0559
DEBUG - 2022-06-24 12:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:31:41 --> Total execution time: 0.0683
DEBUG - 2022-06-24 12:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:32:05 --> Total execution time: 0.0604
DEBUG - 2022-06-24 12:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:32:16 --> Total execution time: 0.0622
DEBUG - 2022-06-24 12:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:33:16 --> Total execution time: 0.0435
DEBUG - 2022-06-24 12:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:33:46 --> Total execution time: 0.0530
DEBUG - 2022-06-24 12:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:33:57 --> Total execution time: 0.1268
DEBUG - 2022-06-24 12:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:34:01 --> Total execution time: 0.0481
DEBUG - 2022-06-24 12:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:34:12 --> Total execution time: 0.1003
DEBUG - 2022-06-24 12:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:34:18 --> Total execution time: 0.0466
DEBUG - 2022-06-24 12:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:34:32 --> Total execution time: 0.0497
DEBUG - 2022-06-24 12:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:34:34 --> Total execution time: 0.0502
DEBUG - 2022-06-24 12:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:34:39 --> Total execution time: 0.0559
DEBUG - 2022-06-24 12:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:34:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 12:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:34:40 --> Total execution time: 0.0533
DEBUG - 2022-06-24 12:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:34:41 --> Total execution time: 0.0442
DEBUG - 2022-06-24 12:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:34:52 --> Total execution time: 0.0632
DEBUG - 2022-06-24 12:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:35:12 --> Total execution time: 0.0647
DEBUG - 2022-06-24 12:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:35:24 --> Total execution time: 0.0557
DEBUG - 2022-06-24 12:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:35:24 --> Total execution time: 0.0446
DEBUG - 2022-06-24 12:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:35:32 --> Total execution time: 0.0836
DEBUG - 2022-06-24 12:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:35:35 --> Total execution time: 0.0540
DEBUG - 2022-06-24 12:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:35:42 --> Total execution time: 0.0533
DEBUG - 2022-06-24 12:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:35:49 --> Total execution time: 0.0532
DEBUG - 2022-06-24 12:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:36:01 --> Total execution time: 0.0692
DEBUG - 2022-06-24 12:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:36:06 --> Total execution time: 0.0945
DEBUG - 2022-06-24 12:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:00 --> Total execution time: 0.0616
DEBUG - 2022-06-24 12:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:01 --> Total execution time: 0.0733
DEBUG - 2022-06-24 12:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:04 --> Total execution time: 0.0636
DEBUG - 2022-06-24 12:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:09 --> Total execution time: 0.0633
DEBUG - 2022-06-24 12:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:38:04 --> Total execution time: 0.0461
DEBUG - 2022-06-24 12:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:38:06 --> Total execution time: 0.0525
DEBUG - 2022-06-24 12:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:38:16 --> Total execution time: 0.0798
DEBUG - 2022-06-24 12:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:38:30 --> Total execution time: 0.0526
DEBUG - 2022-06-24 12:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:38:43 --> Total execution time: 0.0564
DEBUG - 2022-06-24 12:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:38:43 --> Total execution time: 0.0574
DEBUG - 2022-06-24 12:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:38:44 --> Total execution time: 0.0473
DEBUG - 2022-06-24 12:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 12:09:10 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-24 12:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:10:03 --> No URI present. Default controller set.
DEBUG - 2022-06-24 12:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:40:03 --> Total execution time: 0.0565
DEBUG - 2022-06-24 12:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:40:08 --> Total execution time: 0.0577
DEBUG - 2022-06-24 12:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:40:16 --> Total execution time: 0.0642
DEBUG - 2022-06-24 12:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:40:18 --> Total execution time: 0.0572
DEBUG - 2022-06-24 12:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:40:21 --> Total execution time: 0.0528
DEBUG - 2022-06-24 12:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:40:30 --> Total execution time: 0.0599
DEBUG - 2022-06-24 12:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:11:26 --> No URI present. Default controller set.
DEBUG - 2022-06-24 12:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:41:26 --> Total execution time: 0.0377
DEBUG - 2022-06-24 12:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:11:27 --> No URI present. Default controller set.
DEBUG - 2022-06-24 12:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:41:27 --> Total execution time: 0.0259
DEBUG - 2022-06-24 12:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:41:37 --> Total execution time: 0.0319
DEBUG - 2022-06-24 12:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:41:39 --> Total execution time: 0.0301
DEBUG - 2022-06-24 12:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:12:41 --> No URI present. Default controller set.
DEBUG - 2022-06-24 12:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:42:41 --> Total execution time: 0.0457
DEBUG - 2022-06-24 12:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:42:58 --> Total execution time: 0.0466
DEBUG - 2022-06-24 12:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:13:01 --> No URI present. Default controller set.
DEBUG - 2022-06-24 12:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:43:01 --> Total execution time: 0.0633
DEBUG - 2022-06-24 12:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:13:32 --> No URI present. Default controller set.
DEBUG - 2022-06-24 12:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:43:32 --> Total execution time: 0.0328
DEBUG - 2022-06-24 12:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:43:35 --> Total execution time: 0.0448
DEBUG - 2022-06-24 12:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:43:55 --> Total execution time: 0.0509
DEBUG - 2022-06-24 12:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:43:58 --> Total execution time: 0.0815
DEBUG - 2022-06-24 12:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:44:15 --> Total execution time: 0.1196
DEBUG - 2022-06-24 12:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:44:29 --> Total execution time: 0.0431
DEBUG - 2022-06-24 12:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:46:07 --> Total execution time: 0.1230
DEBUG - 2022-06-24 12:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:46:46 --> Total execution time: 0.0450
DEBUG - 2022-06-24 12:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:16:56 --> No URI present. Default controller set.
DEBUG - 2022-06-24 12:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:46:56 --> Total execution time: 0.0292
DEBUG - 2022-06-24 12:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:47:09 --> Total execution time: 0.0431
DEBUG - 2022-06-24 12:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:47:14 --> Total execution time: 0.1242
DEBUG - 2022-06-24 12:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:18:53 --> Total execution time: 0.0460
DEBUG - 2022-06-24 12:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:19:04 --> Total execution time: 0.0357
DEBUG - 2022-06-24 12:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:19:06 --> Total execution time: 0.0555
DEBUG - 2022-06-24 12:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:19:06 --> Total execution time: 0.0871
DEBUG - 2022-06-24 12:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:49:52 --> Total execution time: 0.0412
DEBUG - 2022-06-24 12:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:19:57 --> Total execution time: 0.0614
DEBUG - 2022-06-24 12:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:50:04 --> Total execution time: 0.1542
DEBUG - 2022-06-24 12:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:20:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 12:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:50:14 --> Total execution time: 0.0407
DEBUG - 2022-06-24 12:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:20:15 --> No URI present. Default controller set.
DEBUG - 2022-06-24 12:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:50:15 --> Total execution time: 0.0400
DEBUG - 2022-06-24 12:20:15 --> Total execution time: 0.0640
DEBUG - 2022-06-24 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:50:21 --> Total execution time: 0.0312
DEBUG - 2022-06-24 12:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:50:22 --> Total execution time: 0.0386
DEBUG - 2022-06-24 12:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:50:29 --> Total execution time: 0.0441
DEBUG - 2022-06-24 12:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:50:41 --> Total execution time: 0.0435
DEBUG - 2022-06-24 12:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:50:46 --> Total execution time: 0.0457
DEBUG - 2022-06-24 12:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:50:47 --> Total execution time: 0.0462
DEBUG - 2022-06-24 12:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:20:59 --> No URI present. Default controller set.
DEBUG - 2022-06-24 12:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:50:59 --> Total execution time: 0.1267
DEBUG - 2022-06-24 12:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:04 --> Total execution time: 0.0429
DEBUG - 2022-06-24 12:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:06 --> Total execution time: 0.0524
DEBUG - 2022-06-24 12:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:08 --> Total execution time: 0.1137
DEBUG - 2022-06-24 12:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:12 --> Total execution time: 0.0578
DEBUG - 2022-06-24 12:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:12 --> Total execution time: 0.0738
DEBUG - 2022-06-24 12:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:14 --> Total execution time: 0.0722
DEBUG - 2022-06-24 12:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:17 --> Total execution time: 0.0638
DEBUG - 2022-06-24 12:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:26 --> Total execution time: 0.0526
DEBUG - 2022-06-24 12:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:30 --> Total execution time: 0.0561
DEBUG - 2022-06-24 12:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:34 --> Total execution time: 0.0427
DEBUG - 2022-06-24 12:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:36 --> Total execution time: 0.0575
DEBUG - 2022-06-24 12:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:59 --> Total execution time: 0.0838
DEBUG - 2022-06-24 12:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:52:06 --> Total execution time: 0.0603
DEBUG - 2022-06-24 12:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:52:08 --> Total execution time: 0.0513
DEBUG - 2022-06-24 12:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:52:11 --> Total execution time: 0.0496
DEBUG - 2022-06-24 12:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:52:14 --> Total execution time: 0.0537
DEBUG - 2022-06-24 12:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:52:39 --> Total execution time: 0.0473
DEBUG - 2022-06-24 12:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:22:48 --> Total execution time: 0.0991
DEBUG - 2022-06-24 12:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:22:53 --> Total execution time: 0.0515
DEBUG - 2022-06-24 12:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:52:55 --> Total execution time: 0.0430
DEBUG - 2022-06-24 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:22:58 --> Total execution time: 0.0437
DEBUG - 2022-06-24 12:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:22:58 --> Total execution time: 0.0455
DEBUG - 2022-06-24 12:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:01 --> Total execution time: 0.0497
DEBUG - 2022-06-24 12:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:05 --> Total execution time: 0.0558
DEBUG - 2022-06-24 12:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:05 --> Total execution time: 0.0470
DEBUG - 2022-06-24 12:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:11 --> Total execution time: 0.0567
DEBUG - 2022-06-24 12:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:13 --> Total execution time: 0.0520
DEBUG - 2022-06-24 12:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:17 --> Total execution time: 0.0522
DEBUG - 2022-06-24 12:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:19 --> Total execution time: 0.0607
DEBUG - 2022-06-24 12:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:22 --> Total execution time: 0.0520
DEBUG - 2022-06-24 12:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:23 --> Total execution time: 0.0511
DEBUG - 2022-06-24 12:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:24 --> Total execution time: 0.0554
DEBUG - 2022-06-24 12:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:25 --> Total execution time: 0.0791
DEBUG - 2022-06-24 12:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:26 --> Total execution time: 0.0704
DEBUG - 2022-06-24 12:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:26 --> Total execution time: 0.0527
DEBUG - 2022-06-24 12:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:26 --> Total execution time: 0.0490
DEBUG - 2022-06-24 12:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:26 --> Total execution time: 0.0489
DEBUG - 2022-06-24 12:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:28 --> Total execution time: 0.0686
DEBUG - 2022-06-24 12:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:58:33 --> Total execution time: 0.1125
DEBUG - 2022-06-24 12:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:58:42 --> Total execution time: 0.1421
DEBUG - 2022-06-24 12:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:59:47 --> Total execution time: 0.0928
DEBUG - 2022-06-24 12:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:29:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 12:29:52 --> 404 Page Not Found: Login/index
DEBUG - 2022-06-24 12:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:30:37 --> Total execution time: 0.0472
DEBUG - 2022-06-24 12:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:02:53 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 12:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:02:53 --> Total execution time: 0.0781
DEBUG - 2022-06-24 12:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:03:13 --> Total execution time: 0.0897
DEBUG - 2022-06-24 12:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:03:37 --> Total execution time: 0.0514
DEBUG - 2022-06-24 12:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:08:58 --> Total execution time: 0.0597
DEBUG - 2022-06-24 12:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:09:27 --> Total execution time: 0.0330
DEBUG - 2022-06-24 12:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:09:44 --> Total execution time: 0.1382
DEBUG - 2022-06-24 12:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:12:22 --> Total execution time: 0.0562
DEBUG - 2022-06-24 12:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:13:02 --> Total execution time: 0.0622
DEBUG - 2022-06-24 12:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:43:46 --> No URI present. Default controller set.
DEBUG - 2022-06-24 12:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:13:46 --> Total execution time: 0.1069
DEBUG - 2022-06-24 12:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:43:59 --> Total execution time: 0.0514
DEBUG - 2022-06-24 12:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:44:13 --> Total execution time: 0.0476
DEBUG - 2022-06-24 12:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:44:13 --> Total execution time: 0.0639
DEBUG - 2022-06-24 12:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:14:20 --> Total execution time: 0.0476
DEBUG - 2022-06-24 12:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:15:18 --> Total execution time: 0.1098
DEBUG - 2022-06-24 12:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:16:32 --> Total execution time: 0.0531
DEBUG - 2022-06-24 12:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:49:02 --> Total execution time: 0.0578
DEBUG - 2022-06-24 12:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:19:13 --> Total execution time: 0.0534
DEBUG - 2022-06-24 12:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:21:13 --> Total execution time: 0.1165
DEBUG - 2022-06-24 12:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:21:22 --> Total execution time: 0.0937
DEBUG - 2022-06-24 12:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:21:34 --> Total execution time: 0.0874
DEBUG - 2022-06-24 12:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:23:04 --> Total execution time: 0.0907
DEBUG - 2022-06-24 12:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:53:48 --> No URI present. Default controller set.
DEBUG - 2022-06-24 12:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:23:48 --> Total execution time: 0.0532
DEBUG - 2022-06-24 12:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:23:53 --> Total execution time: 0.0455
DEBUG - 2022-06-24 12:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:23:57 --> Total execution time: 0.0298
DEBUG - 2022-06-24 12:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:23:58 --> Total execution time: 0.0619
DEBUG - 2022-06-24 12:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:24:01 --> Total execution time: 0.0502
DEBUG - 2022-06-24 12:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 12:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:24:05 --> Total execution time: 0.0604
DEBUG - 2022-06-24 12:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:24:12 --> Total execution time: 0.0690
DEBUG - 2022-06-24 12:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:24:19 --> Total execution time: 0.0494
DEBUG - 2022-06-24 12:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:24:21 --> Total execution time: 0.0627
DEBUG - 2022-06-24 12:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:24:56 --> Total execution time: 0.0507
DEBUG - 2022-06-24 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:25:05 --> Total execution time: 0.0522
DEBUG - 2022-06-24 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:25:12 --> Total execution time: 0.0507
DEBUG - 2022-06-24 12:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:25:17 --> Total execution time: 0.0631
DEBUG - 2022-06-24 12:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:25:21 --> Total execution time: 0.0523
DEBUG - 2022-06-24 12:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 12:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 12:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:25:24 --> Total execution time: 0.0488
DEBUG - 2022-06-24 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:03 --> Total execution time: 0.1444
DEBUG - 2022-06-24 13:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:03:10 --> Total execution time: 0.1761
DEBUG - 2022-06-24 13:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:03:12 --> Total execution time: 0.0723
DEBUG - 2022-06-24 13:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:03:12 --> Total execution time: 0.1084
DEBUG - 2022-06-24 13:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:33:28 --> Total execution time: 0.0447
DEBUG - 2022-06-24 13:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:33:33 --> Total execution time: 0.0423
DEBUG - 2022-06-24 13:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:33:39 --> Total execution time: 0.0505
DEBUG - 2022-06-24 13:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:33:48 --> Total execution time: 0.3098
DEBUG - 2022-06-24 13:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:33:49 --> Total execution time: 0.2628
DEBUG - 2022-06-24 13:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 13:05:42 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 13:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 13:08:09 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 13:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:38:24 --> Total execution time: 0.2058
DEBUG - 2022-06-24 13:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:09:11 --> No URI present. Default controller set.
DEBUG - 2022-06-24 13:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:39:11 --> Total execution time: 0.0509
DEBUG - 2022-06-24 13:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:39:28 --> Total execution time: 0.0494
DEBUG - 2022-06-24 13:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:10:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 13:10:13 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 13:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:40:43 --> Total execution time: 0.0381
DEBUG - 2022-06-24 13:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:41:23 --> Total execution time: 0.1069
DEBUG - 2022-06-24 13:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:41:31 --> Total execution time: 0.0375
DEBUG - 2022-06-24 13:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:41:33 --> Total execution time: 0.0425
DEBUG - 2022-06-24 13:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:41:52 --> Total execution time: 0.0447
DEBUG - 2022-06-24 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:41:58 --> Total execution time: 0.0887
DEBUG - 2022-06-24 13:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:42:12 --> Total execution time: 0.0930
DEBUG - 2022-06-24 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:42:14 --> Total execution time: 0.0441
DEBUG - 2022-06-24 13:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:42:31 --> Total execution time: 0.0539
DEBUG - 2022-06-24 13:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:42:33 --> Total execution time: 0.0382
DEBUG - 2022-06-24 13:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:42:36 --> Total execution time: 0.0526
DEBUG - 2022-06-24 13:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:44:06 --> Total execution time: 0.0744
DEBUG - 2022-06-24 13:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:44:54 --> Total execution time: 0.0439
DEBUG - 2022-06-24 13:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:15:15 --> No URI present. Default controller set.
DEBUG - 2022-06-24 13:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:45:15 --> Total execution time: 0.0464
DEBUG - 2022-06-24 13:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:45:36 --> Total execution time: 0.1103
DEBUG - 2022-06-24 13:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:46:06 --> Total execution time: 0.0913
DEBUG - 2022-06-24 13:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:46:12 --> Total execution time: 0.0513
DEBUG - 2022-06-24 13:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:46:33 --> Total execution time: 0.0728
DEBUG - 2022-06-24 13:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:47:34 --> Total execution time: 0.0461
DEBUG - 2022-06-24 13:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:48:12 --> Total execution time: 0.1230
DEBUG - 2022-06-24 13:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:48:22 --> Total execution time: 0.0737
DEBUG - 2022-06-24 13:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:48:28 --> Total execution time: 0.0580
DEBUG - 2022-06-24 13:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:48:48 --> Total execution time: 0.0532
DEBUG - 2022-06-24 13:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:49:02 --> Total execution time: 0.0427
DEBUG - 2022-06-24 13:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:49:11 --> Total execution time: 0.0449
DEBUG - 2022-06-24 13:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:51:20 --> Total execution time: 0.1586
DEBUG - 2022-06-24 13:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:51:24 --> Total execution time: 0.0530
DEBUG - 2022-06-24 13:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:56:36 --> Total execution time: 0.1653
DEBUG - 2022-06-24 13:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:33:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 13:33:07 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:36:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 13:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:47:49 --> No URI present. Default controller set.
DEBUG - 2022-06-24 13:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 13:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 13:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 13:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 14:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 14:08:09 --> No URI present. Default controller set.
DEBUG - 2022-06-24 14:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 14:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 14:10:51 --> No URI present. Default controller set.
DEBUG - 2022-06-24 14:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 14:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 14:11:36 --> No URI present. Default controller set.
DEBUG - 2022-06-24 14:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 14:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 14:17:01 --> No URI present. Default controller set.
DEBUG - 2022-06-24 14:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 14:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 14:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 14:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 14:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 14:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 14:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 14:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 14:37:27 --> No URI present. Default controller set.
DEBUG - 2022-06-24 14:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 14:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 14:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 14:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 14:38:19 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-24 14:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 14:42:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 14:42:49 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 14:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 14:45:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 14:45:20 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 14:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 14:47:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 14:47:26 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 15:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 15:10:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 15:10:01 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 15:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 15:41:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 15:41:54 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-24 15:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 15:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 15:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 15:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 15:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 15:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 15:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 15:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 15:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 15:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 15:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 15:48:00 --> No URI present. Default controller set.
DEBUG - 2022-06-24 15:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 15:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 15:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 15:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 15:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 15:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:48:03 --> Total execution time: 0.0598
DEBUG - 2022-06-24 15:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 15:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 15:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 15:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 15:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 15:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 16:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 16:18:56 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 16:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 16:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 16:21:20 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 16:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 16:23:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 16:23:22 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 16:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 16:46:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 16:46:20 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 16:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 16:58:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 16:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 16:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 16:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 16:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 16:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 16:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 16:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 16:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 16:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 17:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 17:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 17:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 17:22:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 17:22:38 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-24 17:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 17:54:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 17:54:16 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 17:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 17:56:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 17:56:37 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 17:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 17:58:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 17:58:47 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 18:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 18:21:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 18:21:11 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 18:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 18:22:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 18:22:42 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-24 18:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 18:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 18:38:22 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-24 18:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 18:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 18:50:27 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-24 18:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 18:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 18:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:06:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 19:06:49 --> 404 Page Not Found: Wp-includes/index
DEBUG - 2022-06-24 19:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:08:39 --> No URI present. Default controller set.
DEBUG - 2022-06-24 19:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:30:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 19:30:28 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 19:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 19:32:55 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 19:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:35:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 19:35:05 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 19:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:35:32 --> No URI present. Default controller set.
DEBUG - 2022-06-24 19:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:49:19 --> No URI present. Default controller set.
DEBUG - 2022-06-24 19:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:53:22 --> Total execution time: 0.0421
DEBUG - 2022-06-24 19:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 19:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 19:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 19:57:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 19:57:33 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 20:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:19:25 --> No URI present. Default controller set.
DEBUG - 2022-06-24 20:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:19:30 --> Total execution time: 0.0917
DEBUG - 2022-06-24 20:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:19:31 --> Total execution time: 0.0545
DEBUG - 2022-06-24 20:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:19:31 --> Total execution time: 0.0995
DEBUG - 2022-06-24 20:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:19:35 --> No URI present. Default controller set.
DEBUG - 2022-06-24 20:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:19:50 --> No URI present. Default controller set.
DEBUG - 2022-06-24 20:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:19:51 --> No URI present. Default controller set.
DEBUG - 2022-06-24 20:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:40:57 --> No URI present. Default controller set.
DEBUG - 2022-06-24 20:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:45:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 20:45:23 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-24 20:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:45:48 --> No URI present. Default controller set.
DEBUG - 2022-06-24 20:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:45:48 --> No URI present. Default controller set.
DEBUG - 2022-06-24 20:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:45:48 --> No URI present. Default controller set.
DEBUG - 2022-06-24 20:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:48:59 --> No URI present. Default controller set.
DEBUG - 2022-06-24 20:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:49:51 --> No URI present. Default controller set.
DEBUG - 2022-06-24 20:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:49:57 --> No URI present. Default controller set.
DEBUG - 2022-06-24 20:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 20:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 20:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 20:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 21:05:00 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 21:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:07:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 21:07:20 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 21:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:09:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 21:09:18 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 21:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 21:14:42 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-24 21:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:14:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 21:14:47 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-24 21:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 21:18:10 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-24 21:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:18:10 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:18:10 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:18:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 21:18:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 21:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:21:49 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:22:24 --> Total execution time: 0.0493
DEBUG - 2022-06-24 21:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:22:26 --> Total execution time: 0.0702
DEBUG - 2022-06-24 21:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:22:26 --> Total execution time: 0.0511
DEBUG - 2022-06-24 21:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:22:39 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:25:23 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:28:16 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:28:43 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:31:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 21:31:01 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 21:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:40:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:42:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 21:42:49 --> 404 Page Not Found: Membership-account/membership-checkout
DEBUG - 2022-06-24 21:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:43:25 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:45:33 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 21:46:59 --> 404 Page Not Found: My-account/index
DEBUG - 2022-06-24 21:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 21:47:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 21:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:47:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 21:47:04 --> 404 Page Not Found: My-account/index
DEBUG - 2022-06-24 21:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:47:06 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:47:12 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:47:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:49:07 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:49:35 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:50:47 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:51:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 21:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 21:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 21:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 21:54:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 21:54:57 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-24 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:06:54 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:07:03 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:07:19 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:44 --> Total execution time: 0.0439
DEBUG - 2022-06-24 22:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:46 --> Total execution time: 0.0443
DEBUG - 2022-06-24 22:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:46 --> Total execution time: 0.0915
DEBUG - 2022-06-24 22:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:07:56 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:10:44 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:11:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:22:39 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:24:21 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:32:04 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:32:36 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:32:39 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:32:49 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:34:17 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:34:55 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:35:53 --> Total execution time: 0.0507
DEBUG - 2022-06-24 22:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:35:55 --> Total execution time: 0.0447
DEBUG - 2022-06-24 22:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:35:55 --> Total execution time: 0.1057
DEBUG - 2022-06-24 22:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:36:00 --> Total execution time: 0.0462
DEBUG - 2022-06-24 22:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:36:02 --> Total execution time: 0.1320
DEBUG - 2022-06-24 22:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 22:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:37:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 22:37:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 22:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:37:16 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:49 --> Total execution time: 0.0597
DEBUG - 2022-06-24 22:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:50 --> Total execution time: 0.0525
DEBUG - 2022-06-24 22:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:37:50 --> Total execution time: 0.0929
DEBUG - 2022-06-24 22:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:39:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 22:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 22:39:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 22:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:40:21 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:41:00 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:43:18 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:43:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 22:43:25 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-24 22:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:44:51 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:44:51 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 22:46:05 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-24 22:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:48:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 22:48:19 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-24 22:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:50:26 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:03 --> Total execution time: 0.0661
DEBUG - 2022-06-24 22:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:04 --> Total execution time: 0.0506
DEBUG - 2022-06-24 22:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:51:04 --> Total execution time: 0.1167
DEBUG - 2022-06-24 22:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:51:12 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:53:05 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:54:22 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:54:31 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 22:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 22:57:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 22:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 22:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:05:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:06:15 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:08:26 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:10:25 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:10:46 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:12:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 23:12:43 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-24 23:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:21:28 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:22:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:24:14 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:24:22 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:24:27 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:24:30 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:26:11 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:27:12 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:28:57 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:02 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:18 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:27 --> Total execution time: 0.0475
DEBUG - 2022-06-24 23:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:29 --> Total execution time: 0.0518
DEBUG - 2022-06-24 23:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:29 --> Total execution time: 0.1137
DEBUG - 2022-06-24 23:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:47 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:31:41 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:34:04 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:34:11 --> Total execution time: 0.0465
DEBUG - 2022-06-24 23:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:34:12 --> Total execution time: 0.0460
DEBUG - 2022-06-24 23:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:34:12 --> Total execution time: 0.0982
DEBUG - 2022-06-24 23:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:40:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 23:40:18 --> 404 Page Not Found: Teacher/harry-j-bryant
DEBUG - 2022-06-24 23:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:42:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:42:40 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:43:25 --> Total execution time: 0.0370
DEBUG - 2022-06-24 23:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:43:27 --> Total execution time: 0.0496
DEBUG - 2022-06-24 23:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:43:27 --> Total execution time: 0.1056
DEBUG - 2022-06-24 23:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:43:43 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:44:26 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:47:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 23:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:47:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-24 23:47:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-24 23:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:49:21 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:56:51 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:56:54 --> No URI present. Default controller set.
DEBUG - 2022-06-24 23:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-24 23:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 23:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 23:59:20 --> Encryption: Auto-configured driver 'openssl'.
