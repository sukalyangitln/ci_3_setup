<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-30 14:00:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 14:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 14:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-30 14:00:17 --> Total execution time: 3.1272
DEBUG - 2021-11-30 14:00:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 14:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 14:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-30 14:00:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 14:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 14:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-30 18:30:19 --> Total execution time: 0.1070
DEBUG - 2021-11-30 14:01:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 14:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 14:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-30 18:31:02 --> Total execution time: 0.1230
DEBUG - 2021-11-30 14:01:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 14:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 14:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-30 18:31:06 --> Total execution time: 0.1281
DEBUG - 2021-11-30 14:01:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 14:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 14:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-30 18:31:09 --> Total execution time: 0.0883
DEBUG - 2021-11-30 14:01:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 14:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 14:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-30 18:31:11 --> Total execution time: 0.0723
DEBUG - 2021-11-30 14:01:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 14:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 14:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-30 18:31:13 --> Total execution time: 0.0541
DEBUG - 2021-11-30 14:02:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 14:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 14:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-30 18:32:52 --> Total execution time: 0.0672
DEBUG - 2021-11-30 14:02:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 14:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 14:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-30 18:32:54 --> Total execution time: 0.1036
