<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-11-20 00:00:52 --> Total execution time: 0.7352
DEBUG - 2022-11-20 00:02:14 --> Total execution time: 0.1826
DEBUG - 2022-11-20 00:02:37 --> Total execution time: 0.2125
DEBUG - 2022-11-20 00:02:47 --> Total execution time: 0.4694
DEBUG - 2022-11-20 00:02:52 --> Total execution time: 0.1853
DEBUG - 2022-11-20 00:02:55 --> Total execution time: 0.1728
DEBUG - 2022-11-20 00:03:07 --> Total execution time: 0.1971
DEBUG - 2022-11-20 00:03:08 --> Total execution time: 0.1791
DEBUG - 2022-11-20 00:03:09 --> Total execution time: 0.1748
DEBUG - 2022-11-20 00:03:16 --> Total execution time: 0.3716
DEBUG - 2022-11-20 00:03:23 --> Total execution time: 0.1932
DEBUG - 2022-11-20 00:03:28 --> Total execution time: 0.1826
DEBUG - 2022-11-20 00:03:31 --> Total execution time: 0.1775
DEBUG - 2022-11-20 00:03:38 --> Total execution time: 0.1799
DEBUG - 2022-11-20 00:03:39 --> Total execution time: 0.1986
DEBUG - 2022-11-20 00:03:39 --> Total execution time: 0.1841
DEBUG - 2022-11-20 00:03:44 --> Total execution time: 0.1836
DEBUG - 2022-11-20 00:03:57 --> Total execution time: 0.1788
DEBUG - 2022-11-20 00:04:00 --> Total execution time: 0.2012
DEBUG - 2022-11-20 00:06:06 --> Total execution time: 0.1502
DEBUG - 2022-11-20 00:09:24 --> Total execution time: 0.7051
DEBUG - 2022-11-20 00:09:26 --> Total execution time: 0.1087
DEBUG - 2022-11-20 00:11:40 --> Total execution time: 0.2111
DEBUG - 2022-11-20 00:11:50 --> Total execution time: 0.2302
DEBUG - 2022-11-20 00:11:55 --> Total execution time: 0.4610
DEBUG - 2022-11-20 00:12:12 --> Total execution time: 0.1914
DEBUG - 2022-11-20 00:15:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-20 00:15:38 --> Total execution time: 0.2107
DEBUG - 2022-11-20 00:18:06 --> Total execution time: 0.2032
DEBUG - 2022-11-20 00:19:37 --> Total execution time: 0.1101
DEBUG - 2022-11-20 00:19:38 --> Total execution time: 0.1084
DEBUG - 2022-11-20 00:19:38 --> Total execution time: 0.1092
DEBUG - 2022-11-20 00:19:38 --> Total execution time: 0.1114
DEBUG - 2022-11-20 00:19:38 --> Total execution time: 0.1070
DEBUG - 2022-11-20 00:19:38 --> Total execution time: 0.1229
DEBUG - 2022-11-20 00:19:39 --> Total execution time: 0.1214
DEBUG - 2022-11-20 00:19:39 --> Total execution time: 0.1166
DEBUG - 2022-11-20 00:19:39 --> Total execution time: 0.1167
DEBUG - 2022-11-20 00:22:18 --> Total execution time: 0.2370
DEBUG - 2022-11-20 00:22:24 --> Total execution time: 0.1160
DEBUG - 2022-11-20 00:22:32 --> Total execution time: 0.2092
DEBUG - 2022-11-20 00:22:39 --> Total execution time: 0.2295
DEBUG - 2022-11-20 00:22:42 --> Total execution time: 0.2096
DEBUG - 2022-11-20 00:22:47 --> Total execution time: 0.2104
DEBUG - 2022-11-20 00:23:42 --> Total execution time: 0.2410
DEBUG - 2022-11-20 00:23:53 --> Total execution time: 0.1844
DEBUG - 2022-11-20 00:24:03 --> Total execution time: 0.1949
DEBUG - 2022-11-20 00:24:07 --> Total execution time: 0.1826
DEBUG - 2022-11-20 00:25:34 --> Total execution time: 0.1849
DEBUG - 2022-11-20 00:25:44 --> Total execution time: 0.1825
DEBUG - 2022-11-20 00:26:48 --> Total execution time: 0.1115
DEBUG - 2022-11-20 00:26:51 --> Total execution time: 0.1909
DEBUG - 2022-11-20 00:29:41 --> Total execution time: 0.6949
DEBUG - 2022-11-20 00:29:51 --> Total execution time: 0.1883
DEBUG - 2022-11-20 00:29:55 --> Total execution time: 0.2184
DEBUG - 2022-11-20 00:30:00 --> Total execution time: 0.1995
DEBUG - 2022-11-20 00:30:03 --> Total execution time: 0.3142
DEBUG - 2022-11-20 00:33:24 --> Total execution time: 0.2138
DEBUG - 2022-11-20 00:35:22 --> Total execution time: 0.1269
DEBUG - 2022-11-20 00:36:33 --> Total execution time: 0.1906
DEBUG - 2022-11-20 00:36:44 --> Total execution time: 0.1806
DEBUG - 2022-11-20 00:37:09 --> Total execution time: 0.1783
DEBUG - 2022-11-20 00:37:47 --> Total execution time: 0.2446
DEBUG - 2022-11-20 00:37:59 --> Total execution time: 0.2614
DEBUG - 2022-11-20 00:38:43 --> Total execution time: 0.2300
DEBUG - 2022-11-20 00:38:50 --> Total execution time: 0.1839
DEBUG - 2022-11-20 00:39:03 --> Total execution time: 0.2141
DEBUG - 2022-11-20 00:39:41 --> Total execution time: 0.1918
DEBUG - 2022-11-20 00:39:55 --> Total execution time: 0.2112
DEBUG - 2022-11-20 00:40:01 --> Total execution time: 0.1878
DEBUG - 2022-11-20 00:41:09 --> Total execution time: 0.2470
DEBUG - 2022-11-20 00:41:15 --> Total execution time: 0.1806
DEBUG - 2022-11-20 00:41:23 --> Total execution time: 0.2184
DEBUG - 2022-11-20 00:41:27 --> Total execution time: 0.1939
DEBUG - 2022-11-20 00:41:57 --> Total execution time: 0.4566
DEBUG - 2022-11-20 00:42:07 --> Total execution time: 0.1110
DEBUG - 2022-11-20 00:42:10 --> Total execution time: 0.2496
DEBUG - 2022-11-20 00:43:24 --> Total execution time: 0.1763
DEBUG - 2022-11-20 00:43:32 --> Total execution time: 0.2493
DEBUG - 2022-11-20 00:43:59 --> Total execution time: 0.2131
DEBUG - 2022-11-20 00:44:12 --> Total execution time: 0.1975
DEBUG - 2022-11-20 00:44:22 --> Total execution time: 0.2052
DEBUG - 2022-11-20 00:44:25 --> Total execution time: 0.1988
DEBUG - 2022-11-20 00:44:28 --> Total execution time: 0.2079
DEBUG - 2022-11-20 00:44:37 --> Total execution time: 0.1812
DEBUG - 2022-11-20 00:44:50 --> Total execution time: 0.1918
DEBUG - 2022-11-20 00:44:57 --> Total execution time: 0.1877
DEBUG - 2022-11-20 00:45:08 --> Total execution time: 0.2156
DEBUG - 2022-11-20 00:45:16 --> Total execution time: 0.1752
DEBUG - 2022-11-20 00:45:21 --> Total execution time: 0.1769
DEBUG - 2022-11-20 00:45:29 --> Total execution time: 0.1903
DEBUG - 2022-11-20 00:45:38 --> Total execution time: 0.1789
DEBUG - 2022-11-20 00:45:43 --> Total execution time: 0.1758
DEBUG - 2022-11-20 00:45:49 --> Total execution time: 0.2444
DEBUG - 2022-11-20 00:45:52 --> Total execution time: 0.1798
DEBUG - 2022-11-20 00:46:09 --> Total execution time: 0.1790
DEBUG - 2022-11-20 00:46:16 --> Total execution time: 0.1792
DEBUG - 2022-11-20 00:46:28 --> Total execution time: 0.2066
DEBUG - 2022-11-20 00:47:24 --> Total execution time: 0.1758
DEBUG - 2022-11-20 00:47:28 --> Total execution time: 0.2211
DEBUG - 2022-11-20 00:48:15 --> Total execution time: 0.2057
DEBUG - 2022-11-20 00:48:18 --> Total execution time: 0.2091
DEBUG - 2022-11-20 00:48:20 --> Total execution time: 0.1160
DEBUG - 2022-11-20 00:48:31 --> Total execution time: 0.1780
DEBUG - 2022-11-20 00:55:02 --> Total execution time: 1.1323
DEBUG - 2022-11-20 00:56:44 --> Total execution time: 0.1914
DEBUG - 2022-11-20 00:57:30 --> Total execution time: 0.1111
DEBUG - 2022-11-20 01:04:38 --> Total execution time: 0.5752
DEBUG - 2022-11-20 01:04:38 --> Total execution time: 0.1170
DEBUG - 2022-11-20 01:05:54 --> Total execution time: 0.1184
DEBUG - 2022-11-20 01:08:41 --> Total execution time: 0.1970
DEBUG - 2022-11-20 01:08:43 --> Total execution time: 0.1196
DEBUG - 2022-11-20 01:13:33 --> Total execution time: 0.6194
DEBUG - 2022-11-20 01:14:12 --> Total execution time: 0.6315
DEBUG - 2022-11-20 01:14:16 --> Total execution time: 0.1087
DEBUG - 2022-11-20 01:27:15 --> Total execution time: 0.6127
DEBUG - 2022-11-20 01:30:03 --> Total execution time: 0.2418
DEBUG - 2022-11-20 01:40:13 --> Total execution time: 0.7772
DEBUG - 2022-11-20 01:42:14 --> Total execution time: 0.1096
DEBUG - 2022-11-20 01:42:14 --> Total execution time: 0.1269
DEBUG - 2022-11-20 01:42:59 --> Total execution time: 0.1101
DEBUG - 2022-11-20 01:49:38 --> Total execution time: 0.6152
DEBUG - 2022-11-20 01:49:39 --> Total execution time: 0.1167
DEBUG - 2022-11-20 01:53:04 --> Total execution time: 0.1735
DEBUG - 2022-11-20 02:10:37 --> Total execution time: 0.7129
DEBUG - 2022-11-20 02:11:12 --> Total execution time: 0.1171
DEBUG - 2022-11-20 02:17:42 --> Total execution time: 0.6926
DEBUG - 2022-11-20 02:18:47 --> Total execution time: 0.1128
DEBUG - 2022-11-20 02:27:16 --> Total execution time: 0.5739
DEBUG - 2022-11-20 02:27:16 --> Total execution time: 0.6076
DEBUG - 2022-11-20 02:30:03 --> Total execution time: 0.1781
DEBUG - 2022-11-20 02:31:38 --> Total execution time: 0.1194
DEBUG - 2022-11-20 02:34:37 --> Total execution time: 0.1684
DEBUG - 2022-11-20 02:34:38 --> Total execution time: 0.1069
DEBUG - 2022-11-20 02:34:38 --> Total execution time: 0.1080
DEBUG - 2022-11-20 02:34:38 --> Total execution time: 0.1104
DEBUG - 2022-11-20 02:34:38 --> Total execution time: 0.1092
DEBUG - 2022-11-20 02:34:39 --> Total execution time: 0.1172
DEBUG - 2022-11-20 02:34:39 --> Total execution time: 0.1050
DEBUG - 2022-11-20 02:34:39 --> Total execution time: 0.1066
DEBUG - 2022-11-20 02:37:32 --> Total execution time: 0.1657
DEBUG - 2022-11-20 02:44:30 --> Total execution time: 0.6261
DEBUG - 2022-11-20 02:57:21 --> Total execution time: 0.6229
DEBUG - 2022-11-20 03:00:34 --> Total execution time: 0.1685
DEBUG - 2022-11-20 03:10:13 --> Total execution time: 0.6001
DEBUG - 2022-11-20 03:12:20 --> Total execution time: 2.0401
DEBUG - 2022-11-20 03:12:20 --> Total execution time: 2.3030
DEBUG - 2022-11-20 03:15:25 --> Total execution time: 0.5771
DEBUG - 2022-11-20 03:16:02 --> Total execution time: 0.8285
DEBUG - 2022-11-20 03:18:36 --> Total execution time: 0.1505
DEBUG - 2022-11-20 03:18:39 --> Total execution time: 0.1690
DEBUG - 2022-11-20 03:19:37 --> Total execution time: 0.1115
DEBUG - 2022-11-20 03:19:38 --> Total execution time: 0.1117
DEBUG - 2022-11-20 03:19:38 --> Total execution time: 0.1213
DEBUG - 2022-11-20 03:19:38 --> Total execution time: 0.1251
DEBUG - 2022-11-20 03:19:39 --> Total execution time: 0.1181
DEBUG - 2022-11-20 03:19:39 --> Total execution time: 0.1194
DEBUG - 2022-11-20 03:23:06 --> Total execution time: 1.6128
DEBUG - 2022-11-20 03:30:04 --> Total execution time: 1.6881
DEBUG - 2022-11-20 03:35:56 --> Total execution time: 0.7384
DEBUG - 2022-11-20 04:04:39 --> Total execution time: 0.1385
DEBUG - 2022-11-20 04:04:39 --> Total execution time: 0.6147
DEBUG - 2022-11-20 04:29:30 --> Total execution time: 0.5644
DEBUG - 2022-11-20 04:30:02 --> Total execution time: 0.1760
DEBUG - 2022-11-20 04:49:38 --> Total execution time: 0.5998
DEBUG - 2022-11-20 04:49:38 --> Total execution time: 0.4355
DEBUG - 2022-11-20 04:51:54 --> Total execution time: 0.1579
DEBUG - 2022-11-20 05:21:24 --> Total execution time: 1.3364
DEBUG - 2022-11-20 05:23:04 --> Total execution time: 0.1323
DEBUG - 2022-11-20 05:27:17 --> Total execution time: 0.1613
DEBUG - 2022-11-20 05:30:03 --> Total execution time: 0.3250
DEBUG - 2022-11-20 05:34:39 --> Total execution time: 0.9334
DEBUG - 2022-11-20 05:34:39 --> Total execution time: 0.1800
DEBUG - 2022-11-20 05:34:39 --> Total execution time: 0.5542
DEBUG - 2022-11-20 05:37:40 --> Total execution time: 0.6017
DEBUG - 2022-11-20 05:37:41 --> Total execution time: 0.1176
DEBUG - 2022-11-20 05:37:41 --> Total execution time: 0.1153
DEBUG - 2022-11-20 05:38:43 --> Total execution time: 0.1164
DEBUG - 2022-11-20 05:41:25 --> Total execution time: 0.1612
DEBUG - 2022-11-20 05:42:08 --> Total execution time: 0.1732
DEBUG - 2022-11-20 05:44:43 --> Total execution time: 0.5893
DEBUG - 2022-11-20 05:45:35 --> Total execution time: 1.7876
DEBUG - 2022-11-20 05:53:05 --> Total execution time: 0.6958
DEBUG - 2022-11-20 05:55:04 --> Total execution time: 1.5843
DEBUG - 2022-11-20 05:55:27 --> Total execution time: 0.1851
DEBUG - 2022-11-20 05:56:01 --> Total execution time: 0.2764
DEBUG - 2022-11-20 05:56:22 --> Total execution time: 0.2520
DEBUG - 2022-11-20 05:56:28 --> Total execution time: 0.3103
DEBUG - 2022-11-20 05:56:31 --> Total execution time: 0.3201
DEBUG - 2022-11-20 05:57:02 --> Total execution time: 0.4534
DEBUG - 2022-11-20 05:57:13 --> Total execution time: 0.4021
DEBUG - 2022-11-20 05:57:29 --> Total execution time: 0.2298
DEBUG - 2022-11-20 05:57:35 --> Total execution time: 0.3592
DEBUG - 2022-11-20 05:57:58 --> Total execution time: 0.2206
DEBUG - 2022-11-20 06:00:34 --> Total execution time: 0.1985
DEBUG - 2022-11-20 06:03:52 --> Total execution time: 0.2155
DEBUG - 2022-11-20 06:03:57 --> Total execution time: 0.1129
DEBUG - 2022-11-20 06:04:04 --> Total execution time: 0.2256
DEBUG - 2022-11-20 06:04:11 --> Total execution time: 0.1824
DEBUG - 2022-11-20 06:04:15 --> Total execution time: 0.2087
DEBUG - 2022-11-20 06:04:29 --> Total execution time: 0.2292
DEBUG - 2022-11-20 06:08:05 --> Total execution time: 1.6967
DEBUG - 2022-11-20 06:08:53 --> Total execution time: 1.9694
DEBUG - 2022-11-20 06:08:54 --> Total execution time: 0.2879
DEBUG - 2022-11-20 06:09:12 --> Total execution time: 0.1513
DEBUG - 2022-11-20 06:09:35 --> Total execution time: 0.1222
DEBUG - 2022-11-20 06:09:53 --> Total execution time: 0.2180
DEBUG - 2022-11-20 06:15:34 --> Total execution time: 0.8671
DEBUG - 2022-11-20 06:17:51 --> Total execution time: 0.2081
DEBUG - 2022-11-20 06:18:41 --> Total execution time: 0.1547
DEBUG - 2022-11-20 06:19:13 --> Total execution time: 0.2118
DEBUG - 2022-11-20 06:19:36 --> Total execution time: 0.5712
DEBUG - 2022-11-20 06:19:37 --> Total execution time: 0.1175
DEBUG - 2022-11-20 06:19:37 --> Total execution time: 0.1497
DEBUG - 2022-11-20 06:19:45 --> Total execution time: 0.8990
DEBUG - 2022-11-20 06:20:09 --> Total execution time: 0.2520
DEBUG - 2022-11-20 06:20:14 --> Total execution time: 0.3488
DEBUG - 2022-11-20 06:20:28 --> Total execution time: 0.3133
DEBUG - 2022-11-20 06:20:35 --> Total execution time: 0.1821
DEBUG - 2022-11-20 06:20:40 --> Total execution time: 1.0586
DEBUG - 2022-11-20 06:21:58 --> Total execution time: 0.1663
DEBUG - 2022-11-20 06:22:07 --> Total execution time: 0.2977
DEBUG - 2022-11-20 06:22:09 --> Total execution time: 0.3713
DEBUG - 2022-11-20 06:22:22 --> Total execution time: 0.5355
DEBUG - 2022-11-20 06:22:35 --> Total execution time: 0.2427
DEBUG - 2022-11-20 06:22:39 --> Total execution time: 0.1149
DEBUG - 2022-11-20 06:22:40 --> Total execution time: 0.1533
DEBUG - 2022-11-20 06:22:51 --> Total execution time: 0.6465
DEBUG - 2022-11-20 06:22:57 --> Total execution time: 0.5586
DEBUG - 2022-11-20 06:23:08 --> Total execution time: 0.4223
DEBUG - 2022-11-20 06:23:09 --> Total execution time: 0.5262
DEBUG - 2022-11-20 06:23:11 --> Total execution time: 0.5238
DEBUG - 2022-11-20 06:23:16 --> Total execution time: 0.4735
DEBUG - 2022-11-20 06:23:26 --> Total execution time: 0.8922
DEBUG - 2022-11-20 06:23:33 --> Total execution time: 0.9182
DEBUG - 2022-11-20 06:25:29 --> Total execution time: 0.8562
DEBUG - 2022-11-20 06:25:34 --> Total execution time: 0.2971
DEBUG - 2022-11-20 06:25:44 --> Total execution time: 0.9076
DEBUG - 2022-11-20 06:25:48 --> Total execution time: 0.5754
DEBUG - 2022-11-20 06:25:57 --> Total execution time: 0.1744
DEBUG - 2022-11-20 06:28:34 --> Total execution time: 0.3149
DEBUG - 2022-11-20 06:28:40 --> Total execution time: 0.1797
DEBUG - 2022-11-20 06:29:19 --> Total execution time: 0.1782
DEBUG - 2022-11-20 06:29:40 --> Total execution time: 0.2184
DEBUG - 2022-11-20 06:29:46 --> Total execution time: 0.2026
DEBUG - 2022-11-20 06:30:02 --> Total execution time: 0.6978
DEBUG - 2022-11-20 06:30:04 --> Total execution time: 0.3588
DEBUG - 2022-11-20 06:30:25 --> Total execution time: 0.2503
DEBUG - 2022-11-20 06:30:34 --> Total execution time: 0.2360
DEBUG - 2022-11-20 06:30:41 --> Total execution time: 0.4569
DEBUG - 2022-11-20 06:30:42 --> Total execution time: 0.6466
DEBUG - 2022-11-20 06:30:42 --> Total execution time: 0.6805
DEBUG - 2022-11-20 06:30:43 --> Total execution time: 0.9755
DEBUG - 2022-11-20 06:30:43 --> Total execution time: 1.0546
DEBUG - 2022-11-20 06:32:55 --> Total execution time: 0.2350
DEBUG - 2022-11-20 06:36:56 --> Total execution time: 0.2442
DEBUG - 2022-11-20 06:37:01 --> Total execution time: 0.2205
DEBUG - 2022-11-20 06:37:05 --> Total execution time: 0.1792
DEBUG - 2022-11-20 06:37:10 --> Total execution time: 0.1691
DEBUG - 2022-11-20 06:37:46 --> Total execution time: 0.1795
DEBUG - 2022-11-20 06:37:54 --> Total execution time: 0.1906
DEBUG - 2022-11-20 06:38:02 --> Total execution time: 0.1767
DEBUG - 2022-11-20 06:38:06 --> Total execution time: 0.1169
DEBUG - 2022-11-20 06:38:07 --> Total execution time: 0.1731
DEBUG - 2022-11-20 06:41:51 --> Total execution time: 0.1833
DEBUG - 2022-11-20 06:42:08 --> Total execution time: 0.1910
DEBUG - 2022-11-20 06:42:19 --> Total execution time: 0.2043
DEBUG - 2022-11-20 06:42:35 --> Total execution time: 0.1864
DEBUG - 2022-11-20 06:42:46 --> Total execution time: 0.1737
DEBUG - 2022-11-20 06:43:29 --> Total execution time: 0.1151
DEBUG - 2022-11-20 06:44:10 --> Total execution time: 0.1243
DEBUG - 2022-11-20 06:44:11 --> Total execution time: 0.1146
DEBUG - 2022-11-20 06:44:44 --> Total execution time: 0.1201
DEBUG - 2022-11-20 06:45:18 --> Total execution time: 0.1888
DEBUG - 2022-11-20 06:45:31 --> Total execution time: 0.1835
DEBUG - 2022-11-20 06:45:34 --> Total execution time: 0.1088
DEBUG - 2022-11-20 06:45:38 --> Total execution time: 0.2390
DEBUG - 2022-11-20 06:46:02 --> Total execution time: 0.2285
DEBUG - 2022-11-20 06:48:34 --> Total execution time: 0.2500
DEBUG - 2022-11-20 06:49:36 --> Total execution time: 0.4798
DEBUG - 2022-11-20 06:49:37 --> Total execution time: 0.1778
DEBUG - 2022-11-20 06:49:39 --> Total execution time: 0.1823
DEBUG - 2022-11-20 06:49:43 --> Total execution time: 0.1798
DEBUG - 2022-11-20 06:49:44 --> Total execution time: 0.1923
DEBUG - 2022-11-20 06:49:49 --> Total execution time: 0.1337
DEBUG - 2022-11-20 06:53:04 --> Total execution time: 0.1684
DEBUG - 2022-11-20 06:57:11 --> Total execution time: 0.7161
DEBUG - 2022-11-20 07:00:35 --> Total execution time: 0.6480
DEBUG - 2022-11-20 07:02:05 --> Total execution time: 0.1970
DEBUG - 2022-11-20 07:02:10 --> Total execution time: 0.2068
DEBUG - 2022-11-20 07:02:13 --> Total execution time: 0.1690
DEBUG - 2022-11-20 07:04:00 --> Total execution time: 0.1819
DEBUG - 2022-11-20 07:04:09 --> Total execution time: 0.1937
DEBUG - 2022-11-20 07:04:22 --> Total execution time: 0.1755
DEBUG - 2022-11-20 07:04:37 --> Total execution time: 0.1196
DEBUG - 2022-11-20 07:04:39 --> Total execution time: 0.1253
DEBUG - 2022-11-20 07:07:39 --> Total execution time: 0.1114
DEBUG - 2022-11-20 07:07:40 --> Total execution time: 0.1147
DEBUG - 2022-11-20 07:08:04 --> Total execution time: 0.1088
DEBUG - 2022-11-20 07:09:14 --> Total execution time: 0.4694
DEBUG - 2022-11-20 07:11:14 --> Total execution time: 0.1102
DEBUG - 2022-11-20 07:14:31 --> Total execution time: 0.1601
DEBUG - 2022-11-20 07:14:40 --> Total execution time: 0.1050
DEBUG - 2022-11-20 07:14:54 --> Total execution time: 0.1127
DEBUG - 2022-11-20 07:14:56 --> Total execution time: 0.1113
DEBUG - 2022-11-20 07:15:17 --> Total execution time: 0.2006
DEBUG - 2022-11-20 07:15:34 --> Total execution time: 0.1063
DEBUG - 2022-11-20 07:15:39 --> Total execution time: 0.2617
DEBUG - 2022-11-20 07:16:06 --> Total execution time: 0.1918
DEBUG - 2022-11-20 07:16:24 --> Total execution time: 0.1917
DEBUG - 2022-11-20 07:16:32 --> Total execution time: 0.1772
DEBUG - 2022-11-20 07:16:39 --> Total execution time: 0.1804
DEBUG - 2022-11-20 07:16:41 --> Total execution time: 0.1062
DEBUG - 2022-11-20 07:16:49 --> Total execution time: 0.1710
DEBUG - 2022-11-20 07:16:56 --> Total execution time: 0.1773
DEBUG - 2022-11-20 07:17:13 --> Total execution time: 0.1806
DEBUG - 2022-11-20 07:17:44 --> Total execution time: 0.1693
DEBUG - 2022-11-20 07:17:48 --> Total execution time: 0.1065
DEBUG - 2022-11-20 07:17:54 --> Total execution time: 0.0998
DEBUG - 2022-11-20 07:18:01 --> Total execution time: 0.2343
DEBUG - 2022-11-20 07:18:02 --> Total execution time: 0.1787
DEBUG - 2022-11-20 07:18:11 --> Total execution time: 0.1906
DEBUG - 2022-11-20 07:18:16 --> Total execution time: 0.1782
DEBUG - 2022-11-20 07:18:28 --> Total execution time: 0.1847
DEBUG - 2022-11-20 07:20:22 --> Total execution time: 0.1132
DEBUG - 2022-11-20 07:22:01 --> Total execution time: 0.1695
DEBUG - 2022-11-20 07:23:04 --> Total execution time: 0.1108
DEBUG - 2022-11-20 07:25:17 --> Total execution time: 0.1954
DEBUG - 2022-11-20 07:26:24 --> Total execution time: 0.2504
DEBUG - 2022-11-20 07:28:21 --> Total execution time: 0.5757
DEBUG - 2022-11-20 07:28:34 --> Total execution time: 0.1761
DEBUG - 2022-11-20 07:30:02 --> Total execution time: 0.1560
DEBUG - 2022-11-20 07:30:34 --> Total execution time: 0.1125
DEBUG - 2022-11-20 07:32:09 --> Total execution time: 0.1705
DEBUG - 2022-11-20 07:32:13 --> Total execution time: 0.1604
DEBUG - 2022-11-20 07:37:28 --> Total execution time: 0.1800
DEBUG - 2022-11-20 07:40:19 --> Total execution time: 0.1758
DEBUG - 2022-11-20 07:42:53 --> Total execution time: 0.8322
DEBUG - 2022-11-20 07:43:21 --> Total execution time: 0.8942
DEBUG - 2022-11-20 07:43:58 --> Total execution time: 0.6468
DEBUG - 2022-11-20 07:44:05 --> Total execution time: 0.1717
DEBUG - 2022-11-20 07:44:42 --> Total execution time: 0.2032
DEBUG - 2022-11-20 07:44:47 --> Total execution time: 0.1847
DEBUG - 2022-11-20 07:44:56 --> Total execution time: 0.2032
DEBUG - 2022-11-20 07:45:04 --> Total execution time: 0.2584
DEBUG - 2022-11-20 07:45:10 --> Total execution time: 0.1731
DEBUG - 2022-11-20 07:45:31 --> Total execution time: 0.1710
DEBUG - 2022-11-20 07:45:41 --> Total execution time: 0.1099
DEBUG - 2022-11-20 07:45:55 --> Total execution time: 0.1073
DEBUG - 2022-11-20 07:45:57 --> Total execution time: 0.1240
DEBUG - 2022-11-20 07:46:16 --> Total execution time: 0.1042
DEBUG - 2022-11-20 07:46:41 --> Total execution time: 0.1952
DEBUG - 2022-11-20 07:47:02 --> Total execution time: 0.3355
DEBUG - 2022-11-20 07:47:27 --> Total execution time: 0.1205
DEBUG - 2022-11-20 07:47:29 --> Total execution time: 0.1873
DEBUG - 2022-11-20 07:47:35 --> Total execution time: 0.4534
DEBUG - 2022-11-20 07:47:36 --> Total execution time: 0.1070
DEBUG - 2022-11-20 07:47:42 --> Total execution time: 0.2487
DEBUG - 2022-11-20 07:47:49 --> Total execution time: 0.1755
DEBUG - 2022-11-20 07:47:51 --> Total execution time: 0.2150
DEBUG - 2022-11-20 07:47:52 --> Total execution time: 0.1689
DEBUG - 2022-11-20 07:47:53 --> Total execution time: 0.1669
DEBUG - 2022-11-20 07:49:59 --> Total execution time: 0.1710
DEBUG - 2022-11-20 07:57:56 --> Total execution time: 0.6706
DEBUG - 2022-11-20 08:00:57 --> Total execution time: 0.1599
DEBUG - 2022-11-20 08:01:05 --> Total execution time: 0.2098
DEBUG - 2022-11-20 08:01:07 --> Total execution time: 0.1781
DEBUG - 2022-11-20 08:01:10 --> Total execution time: 0.1185
DEBUG - 2022-11-20 08:01:15 --> Total execution time: 0.2090
DEBUG - 2022-11-20 08:01:21 --> Total execution time: 0.1931
DEBUG - 2022-11-20 08:01:42 --> Total execution time: 0.1817
DEBUG - 2022-11-20 08:01:56 --> Total execution time: 0.1835
DEBUG - 2022-11-20 08:02:00 --> Total execution time: 0.1910
DEBUG - 2022-11-20 08:02:09 --> Total execution time: 0.1890
DEBUG - 2022-11-20 08:02:19 --> Total execution time: 0.1769
DEBUG - 2022-11-20 08:04:50 --> Total execution time: 0.2136
DEBUG - 2022-11-20 08:05:12 --> Total execution time: 0.1762
DEBUG - 2022-11-20 08:05:39 --> Total execution time: 0.2471
DEBUG - 2022-11-20 08:06:00 --> Total execution time: 0.1809
DEBUG - 2022-11-20 08:06:22 --> Total execution time: 0.1776
DEBUG - 2022-11-20 08:06:42 --> Total execution time: 0.1833
DEBUG - 2022-11-20 08:06:47 --> Total execution time: 0.1735
DEBUG - 2022-11-20 08:09:20 --> Total execution time: 0.6452
DEBUG - 2022-11-20 08:09:42 --> Total execution time: 0.5199
DEBUG - 2022-11-20 08:09:52 --> Total execution time: 0.2002
DEBUG - 2022-11-20 08:10:18 --> Total execution time: 0.1841
DEBUG - 2022-11-20 08:10:54 --> Total execution time: 0.1728
DEBUG - 2022-11-20 08:11:52 --> Total execution time: 0.1792
DEBUG - 2022-11-20 08:12:22 --> Total execution time: 0.2030
DEBUG - 2022-11-20 08:12:50 --> Total execution time: 0.1995
DEBUG - 2022-11-20 08:12:55 --> Total execution time: 0.1809
DEBUG - 2022-11-20 08:13:33 --> Total execution time: 0.1779
DEBUG - 2022-11-20 08:16:01 --> Total execution time: 4.4331
DEBUG - 2022-11-20 08:23:42 --> Total execution time: 0.6720
DEBUG - 2022-11-20 08:24:10 --> Total execution time: 0.1141
DEBUG - 2022-11-20 08:26:37 --> Total execution time: 2.8868
DEBUG - 2022-11-20 08:27:05 --> Total execution time: 2.0731
DEBUG - 2022-11-20 08:27:31 --> Total execution time: 0.2072
DEBUG - 2022-11-20 08:28:32 --> Total execution time: 2.4879
DEBUG - 2022-11-20 08:30:05 --> Total execution time: 2.0944
DEBUG - 2022-11-20 08:33:37 --> Total execution time: 1.0275
DEBUG - 2022-11-20 08:34:13 --> Total execution time: 0.1826
DEBUG - 2022-11-20 08:35:25 --> Total execution time: 0.2567
DEBUG - 2022-11-20 08:35:53 --> Total execution time: 0.1987
DEBUG - 2022-11-20 08:36:04 --> Total execution time: 0.1951
DEBUG - 2022-11-20 08:36:42 --> Total execution time: 0.1774
DEBUG - 2022-11-20 08:36:50 --> Total execution time: 0.1091
DEBUG - 2022-11-20 08:36:57 --> Total execution time: 0.1772
DEBUG - 2022-11-20 08:37:10 --> Total execution time: 0.1917
DEBUG - 2022-11-20 08:37:14 --> Total execution time: 0.2144
DEBUG - 2022-11-20 08:37:23 --> Total execution time: 0.1968
DEBUG - 2022-11-20 08:40:37 --> Total execution time: 3.4606
DEBUG - 2022-11-20 08:40:45 --> Total execution time: 0.1226
DEBUG - 2022-11-20 08:41:03 --> Total execution time: 0.2341
DEBUG - 2022-11-20 08:41:09 --> Total execution time: 0.2221
DEBUG - 2022-11-20 08:41:14 --> Total execution time: 0.2086
DEBUG - 2022-11-20 08:42:08 --> Total execution time: 0.5870
DEBUG - 2022-11-20 08:42:15 --> Total execution time: 0.3485
DEBUG - 2022-11-20 08:42:19 --> Total execution time: 0.2070
DEBUG - 2022-11-20 08:42:33 --> Total execution time: 0.2148
DEBUG - 2022-11-20 08:42:44 --> Total execution time: 0.1690
DEBUG - 2022-11-20 08:42:57 --> Total execution time: 0.2225
DEBUG - 2022-11-20 08:43:43 --> Total execution time: 0.1728
DEBUG - 2022-11-20 08:43:57 --> Total execution time: 0.1159
DEBUG - 2022-11-20 08:46:02 --> Total execution time: 0.1210
DEBUG - 2022-11-20 08:47:46 --> Total execution time: 0.8683
DEBUG - 2022-11-20 08:49:53 --> Total execution time: 0.5962
DEBUG - 2022-11-20 08:50:03 --> Total execution time: 0.1723
DEBUG - 2022-11-20 08:50:57 --> Total execution time: 0.8442
DEBUG - 2022-11-20 08:51:04 --> Total execution time: 0.2500
DEBUG - 2022-11-20 08:51:05 --> Total execution time: 0.1786
DEBUG - 2022-11-20 08:51:14 --> Total execution time: 0.2345
DEBUG - 2022-11-20 08:51:22 --> Total execution time: 0.1834
DEBUG - 2022-11-20 08:51:26 --> Total execution time: 0.1757
DEBUG - 2022-11-20 08:51:41 --> Total execution time: 0.1742
DEBUG - 2022-11-20 08:51:43 --> Total execution time: 0.1801
DEBUG - 2022-11-20 08:51:54 --> Total execution time: 0.1890
DEBUG - 2022-11-20 08:52:12 --> Total execution time: 0.2083
DEBUG - 2022-11-20 08:52:28 --> Total execution time: 0.1932
DEBUG - 2022-11-20 08:52:50 --> Total execution time: 0.1095
DEBUG - 2022-11-20 08:52:54 --> Total execution time: 0.1078
DEBUG - 2022-11-20 08:52:58 --> Total execution time: 0.4935
DEBUG - 2022-11-20 08:53:01 --> Total execution time: 0.1773
DEBUG - 2022-11-20 08:53:07 --> Total execution time: 0.2300
DEBUG - 2022-11-20 08:53:21 --> Total execution time: 0.1758
DEBUG - 2022-11-20 08:53:25 --> Total execution time: 0.1827
DEBUG - 2022-11-20 08:53:29 --> Total execution time: 0.1809
DEBUG - 2022-11-20 08:53:37 --> Total execution time: 0.1712
DEBUG - 2022-11-20 08:53:53 --> Total execution time: 0.2149
DEBUG - 2022-11-20 08:54:05 --> Total execution time: 0.1972
DEBUG - 2022-11-20 08:54:41 --> Total execution time: 0.2219
DEBUG - 2022-11-20 08:55:07 --> Total execution time: 0.2623
DEBUG - 2022-11-20 08:55:20 --> Total execution time: 0.2135
DEBUG - 2022-11-20 08:55:32 --> Total execution time: 0.2095
DEBUG - 2022-11-20 08:55:39 --> Total execution time: 0.1123
DEBUG - 2022-11-20 08:57:05 --> Total execution time: 0.1176
DEBUG - 2022-11-20 08:57:05 --> Total execution time: 0.4701
DEBUG - 2022-11-20 08:57:37 --> Total execution time: 0.1148
DEBUG - 2022-11-20 08:57:43 --> Total execution time: 0.1764
DEBUG - 2022-11-20 08:57:54 --> Total execution time: 0.1058
DEBUG - 2022-11-20 08:57:55 --> Total execution time: 0.1747
DEBUG - 2022-11-20 08:57:57 --> Total execution time: 0.1711
DEBUG - 2022-11-20 08:58:15 --> Total execution time: 0.1831
DEBUG - 2022-11-20 08:58:16 --> Total execution time: 0.1114
DEBUG - 2022-11-20 08:58:17 --> Total execution time: 0.1092
DEBUG - 2022-11-20 08:58:25 --> Total execution time: 0.1804
DEBUG - 2022-11-20 08:58:44 --> Total execution time: 0.1753
DEBUG - 2022-11-20 08:58:46 --> Total execution time: 0.1077
DEBUG - 2022-11-20 08:59:04 --> Total execution time: 0.1884
DEBUG - 2022-11-20 08:59:10 --> Total execution time: 0.1825
DEBUG - 2022-11-20 08:59:14 --> Total execution time: 0.2258
DEBUG - 2022-11-20 08:59:19 --> Total execution time: 0.1367
DEBUG - 2022-11-20 08:59:30 --> Total execution time: 0.2485
DEBUG - 2022-11-20 09:01:54 --> Total execution time: 0.6179
DEBUG - 2022-11-20 09:01:58 --> Total execution time: 0.4378
DEBUG - 2022-11-20 09:02:00 --> Total execution time: 0.2928
DEBUG - 2022-11-20 09:02:01 --> Total execution time: 0.4596
DEBUG - 2022-11-20 09:02:03 --> Total execution time: 0.2052
DEBUG - 2022-11-20 09:04:16 --> Total execution time: 0.1743
DEBUG - 2022-11-20 09:04:26 --> Total execution time: 0.1909
DEBUG - 2022-11-20 09:05:05 --> Total execution time: 0.1867
DEBUG - 2022-11-20 09:05:19 --> Total execution time: 0.2513
DEBUG - 2022-11-20 09:05:23 --> Total execution time: 0.1189
DEBUG - 2022-11-20 09:05:30 --> Total execution time: 0.1121
DEBUG - 2022-11-20 09:10:19 --> Total execution time: 0.7435
DEBUG - 2022-11-20 09:12:27 --> Total execution time: 0.8561
DEBUG - 2022-11-20 09:12:29 --> Total execution time: 0.1871
DEBUG - 2022-11-20 09:16:45 --> Total execution time: 0.6271
DEBUG - 2022-11-20 09:16:46 --> Total execution time: 0.1312
DEBUG - 2022-11-20 09:18:02 --> Total execution time: 0.3548
DEBUG - 2022-11-20 09:18:10 --> Total execution time: 0.1726
DEBUG - 2022-11-20 09:18:25 --> Total execution time: 0.1998
DEBUG - 2022-11-20 09:18:30 --> Total execution time: 0.2761
DEBUG - 2022-11-20 09:19:03 --> Total execution time: 0.1987
DEBUG - 2022-11-20 09:19:10 --> Total execution time: 0.1988
DEBUG - 2022-11-20 09:19:14 --> Total execution time: 0.1784
DEBUG - 2022-11-20 09:19:36 --> Total execution time: 0.4737
DEBUG - 2022-11-20 09:21:29 --> Total execution time: 0.7538
DEBUG - 2022-11-20 09:21:29 --> Total execution time: 0.1832
DEBUG - 2022-11-20 09:23:34 --> Total execution time: 0.1735
DEBUG - 2022-11-20 09:23:43 --> Total execution time: 0.1811
DEBUG - 2022-11-20 09:23:44 --> Total execution time: 0.1159
DEBUG - 2022-11-20 09:23:48 --> Total execution time: 0.2535
DEBUG - 2022-11-20 09:24:33 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-20 09:24:34 --> Total execution time: 0.2558
DEBUG - 2022-11-20 09:25:02 --> Total execution time: 0.2156
DEBUG - 2022-11-20 09:25:03 --> Total execution time: 0.2433
DEBUG - 2022-11-20 09:25:04 --> Total execution time: 0.1821
DEBUG - 2022-11-20 09:25:13 --> Total execution time: 0.1938
DEBUG - 2022-11-20 09:25:27 --> Total execution time: 0.1110
DEBUG - 2022-11-20 09:26:27 --> Total execution time: 0.1735
DEBUG - 2022-11-20 09:28:13 --> Total execution time: 0.5321
DEBUG - 2022-11-20 09:28:48 --> Total execution time: 0.1726
DEBUG - 2022-11-20 09:28:51 --> Total execution time: 0.1751
DEBUG - 2022-11-20 09:28:58 --> Total execution time: 0.1182
DEBUG - 2022-11-20 09:30:02 --> Total execution time: 0.2326
DEBUG - 2022-11-20 09:30:55 --> Total execution time: 0.1684
DEBUG - 2022-11-20 09:31:32 --> Total execution time: 0.1106
DEBUG - 2022-11-20 09:33:01 --> Total execution time: 0.1732
DEBUG - 2022-11-20 09:33:15 --> Total execution time: 0.1799
DEBUG - 2022-11-20 09:33:33 --> Total execution time: 0.4871
DEBUG - 2022-11-20 09:34:00 --> Total execution time: 0.1793
DEBUG - 2022-11-20 09:34:32 --> Total execution time: 0.1832
DEBUG - 2022-11-20 09:34:45 --> Total execution time: 0.1155
DEBUG - 2022-11-20 09:35:25 --> Total execution time: 0.1798
DEBUG - 2022-11-20 09:36:35 --> Total execution time: 0.2214
DEBUG - 2022-11-20 09:38:07 --> Total execution time: 0.2086
DEBUG - 2022-11-20 09:38:20 --> Total execution time: 0.1809
DEBUG - 2022-11-20 09:38:36 --> Total execution time: 0.1858
DEBUG - 2022-11-20 09:40:32 --> Total execution time: 0.1165
DEBUG - 2022-11-20 09:40:45 --> Total execution time: 0.1169
DEBUG - 2022-11-20 09:40:47 --> Total execution time: 0.1695
DEBUG - 2022-11-20 09:41:06 --> Total execution time: 0.2004
DEBUG - 2022-11-20 09:41:22 --> Total execution time: 0.1738
DEBUG - 2022-11-20 09:41:31 --> Total execution time: 0.1957
DEBUG - 2022-11-20 09:41:32 --> Total execution time: 0.1746
DEBUG - 2022-11-20 09:41:36 --> Total execution time: 0.1762
DEBUG - 2022-11-20 09:41:40 --> Total execution time: 0.1082
DEBUG - 2022-11-20 09:41:52 --> Total execution time: 0.1685
DEBUG - 2022-11-20 09:42:08 --> Total execution time: 0.1716
DEBUG - 2022-11-20 09:42:09 --> Total execution time: 0.1148
DEBUG - 2022-11-20 09:42:27 --> Total execution time: 0.1812
DEBUG - 2022-11-20 09:42:31 --> Total execution time: 0.1717
DEBUG - 2022-11-20 09:42:43 --> Total execution time: 0.1672
DEBUG - 2022-11-20 09:42:51 --> Total execution time: 0.1710
DEBUG - 2022-11-20 09:43:12 --> Total execution time: 0.1746
DEBUG - 2022-11-20 09:43:29 --> Total execution time: 0.1741
DEBUG - 2022-11-20 09:43:44 --> Total execution time: 0.2006
DEBUG - 2022-11-20 09:43:49 --> Total execution time: 0.1779
DEBUG - 2022-11-20 09:43:56 --> Total execution time: 0.1711
DEBUG - 2022-11-20 09:44:10 --> Total execution time: 0.1907
DEBUG - 2022-11-20 09:44:15 --> Total execution time: 0.1748
DEBUG - 2022-11-20 09:44:29 --> Total execution time: 0.1148
DEBUG - 2022-11-20 09:45:17 --> Total execution time: 0.1822
DEBUG - 2022-11-20 09:45:22 --> Total execution time: 0.1759
DEBUG - 2022-11-20 09:46:12 --> Total execution time: 0.1764
DEBUG - 2022-11-20 09:47:50 --> Total execution time: 0.1706
DEBUG - 2022-11-20 09:49:58 --> Total execution time: 0.1902
DEBUG - 2022-11-20 09:50:38 --> Total execution time: 0.1852
DEBUG - 2022-11-20 09:52:47 --> Total execution time: 0.1793
DEBUG - 2022-11-20 09:53:42 --> Total execution time: 2.4983
DEBUG - 2022-11-20 09:54:21 --> Total execution time: 0.1187
DEBUG - 2022-11-20 09:54:59 --> Total execution time: 3.0820
DEBUG - 2022-11-20 09:56:11 --> Total execution time: 0.6245
DEBUG - 2022-11-20 09:56:31 --> Total execution time: 0.6660
DEBUG - 2022-11-20 09:56:36 --> Total execution time: 0.1702
DEBUG - 2022-11-20 09:56:42 --> Total execution time: 0.2028
DEBUG - 2022-11-20 09:56:48 --> Total execution time: 0.2028
DEBUG - 2022-11-20 09:56:59 --> Total execution time: 0.1889
DEBUG - 2022-11-20 09:57:20 --> Total execution time: 0.1684
DEBUG - 2022-11-20 09:58:17 --> Total execution time: 0.1856
DEBUG - 2022-11-20 09:58:31 --> Total execution time: 0.1083
DEBUG - 2022-11-20 10:00:17 --> Total execution time: 0.4851
DEBUG - 2022-11-20 10:00:25 --> Total execution time: 0.1809
DEBUG - 2022-11-20 10:00:35 --> Total execution time: 0.4544
DEBUG - 2022-11-20 10:00:42 --> Total execution time: 0.2044
DEBUG - 2022-11-20 10:00:54 --> Total execution time: 0.1815
DEBUG - 2022-11-20 10:01:25 --> Total execution time: 0.1997
DEBUG - 2022-11-20 10:01:55 --> Total execution time: 0.1684
DEBUG - 2022-11-20 10:02:03 --> Total execution time: 0.1752
DEBUG - 2022-11-20 10:02:33 --> Total execution time: 0.1669
DEBUG - 2022-11-20 10:02:46 --> Total execution time: 0.1744
DEBUG - 2022-11-20 10:03:37 --> Total execution time: 0.4679
DEBUG - 2022-11-20 10:03:40 --> Total execution time: 0.1985
DEBUG - 2022-11-20 10:03:45 --> Total execution time: 0.2016
DEBUG - 2022-11-20 10:03:56 --> Total execution time: 0.1785
DEBUG - 2022-11-20 10:04:18 --> Total execution time: 0.1098
DEBUG - 2022-11-20 10:10:06 --> Total execution time: 0.1798
DEBUG - 2022-11-20 10:10:14 --> Total execution time: 0.2111
DEBUG - 2022-11-20 10:10:16 --> Total execution time: 0.1248
DEBUG - 2022-11-20 10:10:17 --> Total execution time: 0.1113
DEBUG - 2022-11-20 10:10:31 --> Total execution time: 0.3254
DEBUG - 2022-11-20 10:11:10 --> Total execution time: 0.1164
DEBUG - 2022-11-20 10:11:16 --> Total execution time: 0.1069
DEBUG - 2022-11-20 10:11:42 --> Total execution time: 0.1825
DEBUG - 2022-11-20 10:12:10 --> Total execution time: 0.2178
DEBUG - 2022-11-20 10:12:50 --> Total execution time: 0.1477
DEBUG - 2022-11-20 10:13:24 --> Total execution time: 0.1189
DEBUG - 2022-11-20 10:14:53 --> Total execution time: 0.1761
DEBUG - 2022-11-20 10:15:05 --> Total execution time: 0.4825
DEBUG - 2022-11-20 10:15:19 --> Total execution time: 0.1802
DEBUG - 2022-11-20 10:15:39 --> Total execution time: 0.1728
DEBUG - 2022-11-20 10:15:49 --> Total execution time: 0.1844
DEBUG - 2022-11-20 10:15:53 --> Total execution time: 0.1739
DEBUG - 2022-11-20 10:15:56 --> Total execution time: 0.1692
DEBUG - 2022-11-20 10:15:59 --> Total execution time: 0.1793
DEBUG - 2022-11-20 10:16:00 --> Total execution time: 0.1837
DEBUG - 2022-11-20 10:16:38 --> Total execution time: 0.1696
DEBUG - 2022-11-20 10:16:42 --> Total execution time: 0.1974
DEBUG - 2022-11-20 10:16:52 --> Total execution time: 0.1843
DEBUG - 2022-11-20 10:16:53 --> Total execution time: 0.1735
DEBUG - 2022-11-20 10:17:09 --> Total execution time: 0.1873
DEBUG - 2022-11-20 10:17:14 --> Total execution time: 0.1904
DEBUG - 2022-11-20 10:17:26 --> Total execution time: 0.1893
DEBUG - 2022-11-20 10:17:34 --> Total execution time: 0.1750
DEBUG - 2022-11-20 10:17:37 --> Total execution time: 0.1737
DEBUG - 2022-11-20 10:17:42 --> Total execution time: 0.1955
DEBUG - 2022-11-20 10:17:51 --> Total execution time: 0.2081
DEBUG - 2022-11-20 10:17:55 --> Total execution time: 0.1777
DEBUG - 2022-11-20 10:18:22 --> Total execution time: 0.1871
DEBUG - 2022-11-20 10:18:27 --> Total execution time: 0.2596
DEBUG - 2022-11-20 10:18:57 --> Total execution time: 0.1079
DEBUG - 2022-11-20 10:19:04 --> Total execution time: 0.1931
DEBUG - 2022-11-20 10:19:11 --> Total execution time: 0.2165
DEBUG - 2022-11-20 10:19:13 --> Total execution time: 0.1814
DEBUG - 2022-11-20 10:19:30 --> Total execution time: 0.2396
DEBUG - 2022-11-20 10:19:38 --> Total execution time: 0.1752
DEBUG - 2022-11-20 10:19:39 --> Total execution time: 0.1762
DEBUG - 2022-11-20 10:19:40 --> Total execution time: 0.4595
DEBUG - 2022-11-20 10:19:42 --> Total execution time: 0.2309
DEBUG - 2022-11-20 10:19:45 --> Total execution time: 0.1064
DEBUG - 2022-11-20 10:19:45 --> Total execution time: 0.1248
DEBUG - 2022-11-20 10:19:56 --> Total execution time: 0.1700
DEBUG - 2022-11-20 10:22:25 --> Total execution time: 0.1855
DEBUG - 2022-11-20 10:22:39 --> Total execution time: 0.1149
DEBUG - 2022-11-20 10:22:39 --> Total execution time: 0.1102
DEBUG - 2022-11-20 10:22:48 --> Total execution time: 0.1827
DEBUG - 2022-11-20 10:22:49 --> Total execution time: 0.1011
DEBUG - 2022-11-20 10:23:05 --> Total execution time: 0.2315
DEBUG - 2022-11-20 10:23:12 --> Total execution time: 0.1739
DEBUG - 2022-11-20 10:23:20 --> Total execution time: 0.2244
DEBUG - 2022-11-20 10:23:54 --> Total execution time: 0.1705
DEBUG - 2022-11-20 10:24:05 --> Total execution time: 0.2237
DEBUG - 2022-11-20 10:24:11 --> Total execution time: 0.1747
DEBUG - 2022-11-20 10:24:29 --> Total execution time: 0.1087
DEBUG - 2022-11-20 10:24:34 --> Total execution time: 0.1731
DEBUG - 2022-11-20 10:25:02 --> Total execution time: 0.1690
DEBUG - 2022-11-20 10:25:34 --> Total execution time: 0.2077
DEBUG - 2022-11-20 10:25:45 --> Total execution time: 0.1802
DEBUG - 2022-11-20 10:25:49 --> Total execution time: 0.1788
DEBUG - 2022-11-20 10:25:51 --> Total execution time: 0.1775
DEBUG - 2022-11-20 10:25:59 --> Total execution time: 0.1715
DEBUG - 2022-11-20 10:26:13 --> Total execution time: 0.1822
DEBUG - 2022-11-20 10:26:14 --> Total execution time: 0.1871
DEBUG - 2022-11-20 10:26:24 --> Total execution time: 0.1111
DEBUG - 2022-11-20 10:26:26 --> Total execution time: 0.1710
DEBUG - 2022-11-20 10:26:41 --> Total execution time: 2.0888
DEBUG - 2022-11-20 10:27:07 --> Total execution time: 0.1834
DEBUG - 2022-11-20 10:27:13 --> Total execution time: 0.1717
DEBUG - 2022-11-20 10:27:15 --> Total execution time: 0.1755
DEBUG - 2022-11-20 10:27:30 --> Total execution time: 0.1783
DEBUG - 2022-11-20 10:28:35 --> Total execution time: 0.4559
DEBUG - 2022-11-20 10:28:39 --> Total execution time: 0.1767
DEBUG - 2022-11-20 10:28:40 --> Total execution time: 0.1692
DEBUG - 2022-11-20 10:28:45 --> Total execution time: 0.1914
DEBUG - 2022-11-20 10:28:51 --> Total execution time: 0.1907
DEBUG - 2022-11-20 10:28:55 --> Total execution time: 0.1792
DEBUG - 2022-11-20 10:28:59 --> Total execution time: 0.1952
DEBUG - 2022-11-20 10:29:03 --> Total execution time: 0.1760
DEBUG - 2022-11-20 10:29:07 --> Total execution time: 0.1855
DEBUG - 2022-11-20 10:29:11 --> Total execution time: 0.1884
DEBUG - 2022-11-20 10:29:18 --> Total execution time: 0.1789
DEBUG - 2022-11-20 10:30:02 --> Total execution time: 0.1706
DEBUG - 2022-11-20 10:30:54 --> Total execution time: 0.5778
DEBUG - 2022-11-20 10:31:05 --> Total execution time: 0.1969
DEBUG - 2022-11-20 10:31:06 --> Total execution time: 0.2731
DEBUG - 2022-11-20 10:31:08 --> Total execution time: 0.2155
DEBUG - 2022-11-20 10:31:13 --> Total execution time: 0.1759
DEBUG - 2022-11-20 10:31:21 --> Total execution time: 0.2795
DEBUG - 2022-11-20 10:31:46 --> Total execution time: 0.1772
DEBUG - 2022-11-20 10:33:07 --> Total execution time: 1.1376
DEBUG - 2022-11-20 10:33:18 --> Total execution time: 0.2696
DEBUG - 2022-11-20 10:33:29 --> Total execution time: 0.2693
DEBUG - 2022-11-20 10:33:42 --> Total execution time: 0.2234
DEBUG - 2022-11-20 10:33:43 --> Total execution time: 0.1969
DEBUG - 2022-11-20 10:33:51 --> Total execution time: 0.1119
DEBUG - 2022-11-20 10:33:57 --> Total execution time: 0.1748
DEBUG - 2022-11-20 10:36:46 --> Total execution time: 0.5599
DEBUG - 2022-11-20 10:36:46 --> Total execution time: 0.6776
DEBUG - 2022-11-20 10:36:46 --> Total execution time: 0.7278
DEBUG - 2022-11-20 10:36:47 --> Total execution time: 0.2124
DEBUG - 2022-11-20 10:36:47 --> Total execution time: 0.3967
DEBUG - 2022-11-20 10:36:48 --> Total execution time: 0.3477
DEBUG - 2022-11-20 10:36:48 --> Total execution time: 0.3720
DEBUG - 2022-11-20 10:36:57 --> Total execution time: 0.1841
DEBUG - 2022-11-20 10:37:54 --> Total execution time: 0.2133
DEBUG - 2022-11-20 10:38:16 --> Total execution time: 0.1770
DEBUG - 2022-11-20 10:38:21 --> Total execution time: 0.1768
DEBUG - 2022-11-20 10:38:29 --> Total execution time: 0.2163
DEBUG - 2022-11-20 10:38:47 --> Total execution time: 0.1709
DEBUG - 2022-11-20 10:42:06 --> Total execution time: 1.0177
DEBUG - 2022-11-20 10:42:16 --> Total execution time: 0.1096
DEBUG - 2022-11-20 10:42:53 --> Total execution time: 0.1240
DEBUG - 2022-11-20 10:43:21 --> Total execution time: 0.1838
DEBUG - 2022-11-20 10:43:32 --> Total execution time: 0.1762
DEBUG - 2022-11-20 10:43:33 --> Total execution time: 0.1676
DEBUG - 2022-11-20 10:43:33 --> Total execution time: 0.1697
DEBUG - 2022-11-20 10:43:44 --> Total execution time: 0.1700
DEBUG - 2022-11-20 10:43:52 --> Total execution time: 0.1752
DEBUG - 2022-11-20 10:43:59 --> Total execution time: 0.1876
DEBUG - 2022-11-20 10:44:19 --> Total execution time: 0.1162
DEBUG - 2022-11-20 10:44:38 --> Total execution time: 0.4553
DEBUG - 2022-11-20 10:45:46 --> Total execution time: 0.1757
DEBUG - 2022-11-20 10:46:11 --> Total execution time: 0.1050
DEBUG - 2022-11-20 10:46:16 --> Total execution time: 0.2319
DEBUG - 2022-11-20 10:46:40 --> Total execution time: 0.1861
DEBUG - 2022-11-20 10:47:00 --> Total execution time: 0.1880
DEBUG - 2022-11-20 10:47:25 --> Total execution time: 0.4697
DEBUG - 2022-11-20 10:47:40 --> Total execution time: 0.1753
DEBUG - 2022-11-20 10:47:46 --> Total execution time: 0.2301
DEBUG - 2022-11-20 10:47:53 --> Total execution time: 0.1752
DEBUG - 2022-11-20 10:48:01 --> Total execution time: 0.1859
DEBUG - 2022-11-20 10:48:13 --> Total execution time: 0.1787
DEBUG - 2022-11-20 10:48:24 --> Total execution time: 0.1817
DEBUG - 2022-11-20 10:48:28 --> Total execution time: 0.1762
DEBUG - 2022-11-20 10:48:41 --> Total execution time: 0.2481
DEBUG - 2022-11-20 10:49:00 --> Total execution time: 0.1986
DEBUG - 2022-11-20 10:49:08 --> Total execution time: 0.2264
DEBUG - 2022-11-20 10:49:10 --> Total execution time: 0.1783
DEBUG - 2022-11-20 10:49:13 --> Total execution time: 0.1751
DEBUG - 2022-11-20 10:49:23 --> Total execution time: 0.2178
DEBUG - 2022-11-20 10:49:28 --> Total execution time: 0.2293
DEBUG - 2022-11-20 10:49:36 --> Total execution time: 0.1803
DEBUG - 2022-11-20 10:49:44 --> Total execution time: 0.2138
DEBUG - 2022-11-20 10:49:48 --> Total execution time: 0.4877
DEBUG - 2022-11-20 10:49:53 --> Total execution time: 0.2300
DEBUG - 2022-11-20 10:49:54 --> Total execution time: 0.1779
DEBUG - 2022-11-20 10:50:02 --> Total execution time: 0.2413
DEBUG - 2022-11-20 10:50:02 --> Total execution time: 0.2079
DEBUG - 2022-11-20 10:50:08 --> Total execution time: 0.2133
DEBUG - 2022-11-20 10:50:11 --> Total execution time: 0.2755
DEBUG - 2022-11-20 10:50:12 --> Total execution time: 0.1868
DEBUG - 2022-11-20 10:50:16 --> Total execution time: 0.1768
DEBUG - 2022-11-20 10:50:19 --> Total execution time: 0.1779
DEBUG - 2022-11-20 10:50:21 --> Total execution time: 0.1840
DEBUG - 2022-11-20 10:50:37 --> Total execution time: 0.1719
DEBUG - 2022-11-20 10:50:56 --> Total execution time: 2.2466
DEBUG - 2022-11-20 10:51:07 --> Total execution time: 0.1785
DEBUG - 2022-11-20 10:51:15 --> Total execution time: 1.7274
DEBUG - 2022-11-20 10:51:23 --> Total execution time: 0.1700
DEBUG - 2022-11-20 10:51:41 --> Total execution time: 0.1086
DEBUG - 2022-11-20 10:52:40 --> Total execution time: 0.1079
DEBUG - 2022-11-20 10:53:42 --> Total execution time: 1.7783
DEBUG - 2022-11-20 10:59:05 --> Total execution time: 0.6087
DEBUG - 2022-11-20 11:03:26 --> Total execution time: 0.6948
DEBUG - 2022-11-20 11:03:41 --> Total execution time: 2.0237
DEBUG - 2022-11-20 11:04:46 --> Total execution time: 0.1108
DEBUG - 2022-11-20 11:04:50 --> Total execution time: 1.9392
DEBUG - 2022-11-20 11:04:51 --> Total execution time: 0.2201
DEBUG - 2022-11-20 11:05:06 --> Total execution time: 0.2515
DEBUG - 2022-11-20 11:05:11 --> Total execution time: 0.2000
DEBUG - 2022-11-20 11:05:15 --> Total execution time: 0.2104
DEBUG - 2022-11-20 11:05:21 --> Total execution time: 0.1844
DEBUG - 2022-11-20 11:05:25 --> Total execution time: 0.2155
DEBUG - 2022-11-20 11:05:31 --> Total execution time: 0.1772
DEBUG - 2022-11-20 11:05:36 --> Total execution time: 0.1779
DEBUG - 2022-11-20 11:05:51 --> Total execution time: 0.1772
DEBUG - 2022-11-20 11:06:01 --> Total execution time: 0.2602
DEBUG - 2022-11-20 11:06:07 --> Total execution time: 0.1705
DEBUG - 2022-11-20 11:06:32 --> Total execution time: 0.2081
DEBUG - 2022-11-20 11:06:38 --> Total execution time: 0.1825
DEBUG - 2022-11-20 11:06:43 --> Total execution time: 0.1772
DEBUG - 2022-11-20 11:06:53 --> Total execution time: 0.1787
DEBUG - 2022-11-20 11:06:55 --> Total execution time: 2.1064
DEBUG - 2022-11-20 11:06:55 --> Total execution time: 0.1784
DEBUG - 2022-11-20 11:06:56 --> Total execution time: 0.1758
DEBUG - 2022-11-20 11:07:07 --> Total execution time: 1.8158
DEBUG - 2022-11-20 11:07:28 --> Total execution time: 0.1884
DEBUG - 2022-11-20 11:07:29 --> Total execution time: 0.1757
DEBUG - 2022-11-20 11:07:40 --> Total execution time: 0.2034
DEBUG - 2022-11-20 11:07:41 --> Total execution time: 0.1871
DEBUG - 2022-11-20 11:07:42 --> Total execution time: 0.1836
DEBUG - 2022-11-20 11:07:53 --> Total execution time: 0.1808
DEBUG - 2022-11-20 11:08:03 --> Total execution time: 0.1823
DEBUG - 2022-11-20 11:08:08 --> Total execution time: 0.1785
DEBUG - 2022-11-20 11:08:16 --> Total execution time: 0.1195
DEBUG - 2022-11-20 11:08:23 --> Total execution time: 0.1855
DEBUG - 2022-11-20 11:08:28 --> Total execution time: 0.5203
DEBUG - 2022-11-20 11:08:38 --> Total execution time: 0.2038
DEBUG - 2022-11-20 11:09:33 --> Total execution time: 0.1871
DEBUG - 2022-11-20 11:12:26 --> Total execution time: 0.6425
DEBUG - 2022-11-20 11:12:37 --> Total execution time: 0.2442
DEBUG - 2022-11-20 11:12:48 --> Total execution time: 0.2403
DEBUG - 2022-11-20 11:12:55 --> Total execution time: 0.1769
DEBUG - 2022-11-20 11:12:59 --> Total execution time: 0.1716
DEBUG - 2022-11-20 11:13:02 --> Total execution time: 0.2141
DEBUG - 2022-11-20 11:13:14 --> Total execution time: 0.1981
DEBUG - 2022-11-20 11:16:45 --> Total execution time: 0.1764
DEBUG - 2022-11-20 11:16:54 --> Total execution time: 0.2571
DEBUG - 2022-11-20 11:16:59 --> Total execution time: 0.2406
DEBUG - 2022-11-20 11:17:22 --> Total execution time: 0.2228
DEBUG - 2022-11-20 11:17:33 --> Total execution time: 0.1225
DEBUG - 2022-11-20 11:19:54 --> Total execution time: 0.1089
DEBUG - 2022-11-20 11:20:37 --> Total execution time: 0.1733
DEBUG - 2022-11-20 11:20:55 --> Total execution time: 0.1177
DEBUG - 2022-11-20 11:21:31 --> Total execution time: 0.1349
DEBUG - 2022-11-20 11:26:04 --> Total execution time: 0.2563
DEBUG - 2022-11-20 11:27:16 --> Total execution time: 0.1242
DEBUG - 2022-11-20 11:27:34 --> Total execution time: 0.4640
DEBUG - 2022-11-20 11:27:56 --> Total execution time: 0.1979
DEBUG - 2022-11-20 11:28:03 --> Total execution time: 0.2204
DEBUG - 2022-11-20 11:28:17 --> Total execution time: 0.2522
DEBUG - 2022-11-20 11:28:17 --> Total execution time: 0.2412
DEBUG - 2022-11-20 11:28:18 --> Total execution time: 0.4619
DEBUG - 2022-11-20 11:28:18 --> Total execution time: 0.3044
DEBUG - 2022-11-20 11:28:18 --> Total execution time: 0.4649
DEBUG - 2022-11-20 11:28:19 --> Total execution time: 0.6233
DEBUG - 2022-11-20 11:28:19 --> Total execution time: 0.5000
DEBUG - 2022-11-20 11:28:22 --> Total execution time: 0.1737
DEBUG - 2022-11-20 11:28:22 --> Total execution time: 0.1822
DEBUG - 2022-11-20 11:28:31 --> Total execution time: 0.1142
DEBUG - 2022-11-20 11:28:31 --> Total execution time: 0.1732
DEBUG - 2022-11-20 11:28:42 --> Total execution time: 0.1748
DEBUG - 2022-11-20 11:29:00 --> Total execution time: 0.2509
DEBUG - 2022-11-20 11:29:09 --> Total execution time: 0.1967
DEBUG - 2022-11-20 11:29:41 --> Total execution time: 0.2079
DEBUG - 2022-11-20 11:29:57 --> Total execution time: 0.1875
DEBUG - 2022-11-20 00:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:30:03 --> Total execution time: 0.1628
DEBUG - 2022-11-20 00:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:30:09 --> Total execution time: 0.2290
DEBUG - 2022-11-20 00:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:30:10 --> Total execution time: 0.2245
DEBUG - 2022-11-20 00:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:30:51 --> Total execution time: 0.1907
DEBUG - 2022-11-20 00:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:32:13 --> Total execution time: 0.1765
DEBUG - 2022-11-20 00:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:32:19 --> Total execution time: 0.1785
DEBUG - 2022-11-20 00:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:32:36 --> Total execution time: 0.1692
DEBUG - 2022-11-20 00:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:32:55 --> Total execution time: 0.1778
DEBUG - 2022-11-20 00:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:33:27 --> Total execution time: 0.1684
DEBUG - 2022-11-20 00:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:03:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:33:38 --> Total execution time: 0.1315
DEBUG - 2022-11-20 00:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:03:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:33:38 --> Total execution time: 0.1072
DEBUG - 2022-11-20 00:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:03:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:33:38 --> Total execution time: 0.1172
DEBUG - 2022-11-20 00:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:03:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 00:03:38 --> 404 Page Not Found: Gucci-ace-hearts-sneakers-women-40-us-95-207386html/index
DEBUG - 2022-11-20 00:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:03:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:03:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 00:03:38 --> 404 Page Not Found: Vintage-mid-century-modern-spaghetti-planter-string-art-mcm-1235136html/index
DEBUG - 2022-11-20 00:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:33:38 --> Total execution time: 0.1101
DEBUG - 2022-11-20 00:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:03:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:33:39 --> Total execution time: 0.1173
DEBUG - 2022-11-20 00:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:03:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:33:39 --> Total execution time: 0.1115
DEBUG - 2022-11-20 00:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:03:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 00:03:39 --> 404 Page Not Found: Girls39-star-wars-the-child-baby-yoda-hooded-cosplay-tutu-dress-greenoffwhite-1094476html/index
DEBUG - 2022-11-20 00:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:03:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:33:39 --> Total execution time: 0.1143
DEBUG - 2022-11-20 00:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:33:55 --> Total execution time: 0.1814
DEBUG - 2022-11-20 00:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:04:01 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:34:01 --> Total execution time: 0.1200
DEBUG - 2022-11-20 00:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:34:08 --> Total execution time: 0.1747
DEBUG - 2022-11-20 00:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:04:12 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:34:12 --> Total execution time: 0.1717
DEBUG - 2022-11-20 00:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:34:17 --> Total execution time: 0.1807
DEBUG - 2022-11-20 00:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:34:28 --> Total execution time: 0.2053
DEBUG - 2022-11-20 00:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:34:33 --> Total execution time: 0.2337
DEBUG - 2022-11-20 00:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:34:37 --> Total execution time: 0.1890
DEBUG - 2022-11-20 00:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:34:42 --> Total execution time: 0.2136
DEBUG - 2022-11-20 00:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:36:07 --> Total execution time: 0.4829
DEBUG - 2022-11-20 00:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:36:13 --> Total execution time: 0.1806
DEBUG - 2022-11-20 00:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:36:18 --> Total execution time: 0.2171
DEBUG - 2022-11-20 00:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:36:42 --> Total execution time: 0.1885
DEBUG - 2022-11-20 00:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:36:47 --> Total execution time: 0.2114
DEBUG - 2022-11-20 00:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:36:54 --> Total execution time: 0.1828
DEBUG - 2022-11-20 00:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:37:02 --> Total execution time: 0.2612
DEBUG - 2022-11-20 00:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:37:08 --> Total execution time: 0.1733
DEBUG - 2022-11-20 00:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:37:15 --> Total execution time: 0.1775
DEBUG - 2022-11-20 00:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:37:18 --> Total execution time: 0.1878
DEBUG - 2022-11-20 00:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:37:21 --> Total execution time: 0.1805
DEBUG - 2022-11-20 00:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:37:31 --> Total execution time: 0.2154
DEBUG - 2022-11-20 00:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:37:34 --> Total execution time: 0.1765
DEBUG - 2022-11-20 00:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:37:44 --> Total execution time: 0.1735
DEBUG - 2022-11-20 00:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:08:26 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:38:26 --> Total execution time: 0.1090
DEBUG - 2022-11-20 00:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:41:45 --> Total execution time: 0.2647
DEBUG - 2022-11-20 00:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 00:19:45 --> 404 Page Not Found: 3rd-generation-bluetooth-headphones-noise-cancelling-headphones-312919html/index
DEBUG - 2022-11-20 00:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:50:44 --> Total execution time: 0.8180
DEBUG - 2022-11-20 00:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:51:58 --> Total execution time: 0.1762
DEBUG - 2022-11-20 00:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:52:13 --> Total execution time: 0.1694
DEBUG - 2022-11-20 00:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:52:32 --> Total execution time: 0.2217
DEBUG - 2022-11-20 00:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:52:38 --> Total execution time: 0.2332
DEBUG - 2022-11-20 00:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:52:43 --> Total execution time: 0.1835
DEBUG - 2022-11-20 00:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:52:55 --> Total execution time: 0.1716
DEBUG - 2022-11-20 00:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:23:53 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:53:54 --> Total execution time: 0.9211
DEBUG - 2022-11-20 00:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:26:10 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:56:11 --> Total execution time: 0.9037
DEBUG - 2022-11-20 00:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:57:55 --> Total execution time: 0.9256
DEBUG - 2022-11-20 00:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:58:58 --> Total execution time: 0.5157
DEBUG - 2022-11-20 00:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:59:03 --> Total execution time: 0.2033
DEBUG - 2022-11-20 00:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:59:56 --> Total execution time: 0.1121
DEBUG - 2022-11-20 00:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:00:20 --> Total execution time: 0.1870
DEBUG - 2022-11-20 00:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:00:22 --> Total execution time: 0.1703
DEBUG - 2022-11-20 00:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:03:04 --> Total execution time: 0.2691
DEBUG - 2022-11-20 00:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:03:05 --> Total execution time: 0.1835
DEBUG - 2022-11-20 00:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:03:11 --> Total execution time: 0.4976
DEBUG - 2022-11-20 00:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:04:06 --> Total execution time: 0.1826
DEBUG - 2022-11-20 00:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:04:46 --> Total execution time: 0.2353
DEBUG - 2022-11-20 00:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:04:54 --> Total execution time: 0.2094
DEBUG - 2022-11-20 00:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:05:03 --> Total execution time: 0.4926
DEBUG - 2022-11-20 00:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:05:13 --> Total execution time: 0.1838
DEBUG - 2022-11-20 00:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:05:25 --> Total execution time: 0.2197
DEBUG - 2022-11-20 00:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:05:41 --> Total execution time: 0.1833
DEBUG - 2022-11-20 00:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:05:56 --> Total execution time: 0.2123
DEBUG - 2022-11-20 00:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:06:00 --> Total execution time: 0.1849
DEBUG - 2022-11-20 00:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:06:26 --> Total execution time: 0.2081
DEBUG - 2022-11-20 00:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:06:29 --> Total execution time: 0.1746
DEBUG - 2022-11-20 00:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:37:08 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:07:08 --> Total execution time: 0.1161
DEBUG - 2022-11-20 00:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:07:11 --> Total execution time: 0.1918
DEBUG - 2022-11-20 00:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:08:42 --> Total execution time: 0.1462
DEBUG - 2022-11-20 00:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:08:42 --> Total execution time: 0.1763
DEBUG - 2022-11-20 00:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:08:49 --> Total execution time: 0.1934
DEBUG - 2022-11-20 00:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:08:51 --> Total execution time: 0.1767
DEBUG - 2022-11-20 00:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:09:02 --> Total execution time: 0.1953
DEBUG - 2022-11-20 00:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:09:09 --> Total execution time: 0.2887
DEBUG - 2022-11-20 00:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:40:02 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:10:02 --> Total execution time: 0.3288
DEBUG - 2022-11-20 00:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:10:06 --> Total execution time: 0.1178
DEBUG - 2022-11-20 00:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:40:15 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:10:16 --> Total execution time: 0.1783
DEBUG - 2022-11-20 00:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:10:25 --> Total execution time: 0.2062
DEBUG - 2022-11-20 00:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:10:32 --> Total execution time: 0.2026
DEBUG - 2022-11-20 00:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:10:41 --> Total execution time: 0.2344
DEBUG - 2022-11-20 00:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:10:45 --> Total execution time: 0.1915
DEBUG - 2022-11-20 00:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:10:54 --> Total execution time: 0.1771
DEBUG - 2022-11-20 00:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:11:16 --> Total execution time: 0.1795
DEBUG - 2022-11-20 00:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:42:01 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:12:01 --> Total execution time: 0.1296
DEBUG - 2022-11-20 00:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:12:07 --> Total execution time: 0.4919
DEBUG - 2022-11-20 00:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:12:08 --> Total execution time: 0.1768
DEBUG - 2022-11-20 00:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:12:08 --> Total execution time: 0.1835
DEBUG - 2022-11-20 00:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:12:23 --> Total execution time: 0.1924
DEBUG - 2022-11-20 00:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:15:09 --> Total execution time: 0.2038
DEBUG - 2022-11-20 00:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:15:27 --> Total execution time: 0.1919
DEBUG - 2022-11-20 00:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:15:32 --> Total execution time: 0.2106
DEBUG - 2022-11-20 00:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:15:36 --> Total execution time: 0.1780
DEBUG - 2022-11-20 00:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:15:48 --> Total execution time: 0.1777
DEBUG - 2022-11-20 00:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:15:54 --> Total execution time: 0.1778
DEBUG - 2022-11-20 00:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:16:49 --> Total execution time: 0.1126
DEBUG - 2022-11-20 00:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:16:52 --> Total execution time: 0.1841
DEBUG - 2022-11-20 00:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:16:58 --> Total execution time: 0.1755
DEBUG - 2022-11-20 00:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:17:02 --> Total execution time: 0.2263
DEBUG - 2022-11-20 00:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:47:54 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:17:54 --> Total execution time: 0.1119
DEBUG - 2022-11-20 00:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:48:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:18:38 --> Total execution time: 0.1198
DEBUG - 2022-11-20 00:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:48:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:18:38 --> Total execution time: 0.1058
DEBUG - 2022-11-20 00:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:48:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:18:38 --> Total execution time: 0.1210
DEBUG - 2022-11-20 00:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:48:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:18:38 --> Total execution time: 0.1056
DEBUG - 2022-11-20 00:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:48:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:18:38 --> Total execution time: 0.1030
DEBUG - 2022-11-20 00:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:48:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:18:38 --> Total execution time: 0.1090
DEBUG - 2022-11-20 00:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:48:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 00:48:38 --> 404 Page Not Found: New-nike-air-jordan-5-retro-oreo-2021-mens-12-moonlight-ct4838-011-fast-ship-1333289html/index
DEBUG - 2022-11-20 00:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:48:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:18:39 --> Total execution time: 0.1096
DEBUG - 2022-11-20 00:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 00:48:39 --> 404 Page Not Found: Reebok-classics-energy-q4-velour-zipup-sweatshirt-womens-624075html/index
DEBUG - 2022-11-20 00:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 00:48:39 --> 404 Page Not Found: Poster-print-boulevard-nights-590811html/index
DEBUG - 2022-11-20 00:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:49:59 --> Total execution time: 0.2027
DEBUG - 2022-11-20 00:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:50:05 --> Total execution time: 0.1703
DEBUG - 2022-11-20 00:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:50:05 --> Total execution time: 0.3911
DEBUG - 2022-11-20 00:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:50:15 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:20:16 --> Total execution time: 0.1761
DEBUG - 2022-11-20 00:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 00:52:55 --> 404 Page Not Found: Courses/index
DEBUG - 2022-11-20 00:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:52:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 00:52:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 00:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:24:08 --> Total execution time: 0.1733
DEBUG - 2022-11-20 00:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:25:05 --> Total execution time: 0.1346
DEBUG - 2022-11-20 00:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:25:17 --> Total execution time: 0.2152
DEBUG - 2022-11-20 00:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:25:19 --> Total execution time: 0.1998
DEBUG - 2022-11-20 00:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:25:23 --> Total execution time: 0.1869
DEBUG - 2022-11-20 00:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:25:31 --> Total execution time: 0.1816
DEBUG - 2022-11-20 00:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:25:49 --> Total execution time: 0.1769
DEBUG - 2022-11-20 00:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 00:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:26:16 --> Total execution time: 0.1691
DEBUG - 2022-11-20 00:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:26:57 --> Total execution time: 0.1712
DEBUG - 2022-11-20 00:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:27:22 --> Total execution time: 0.4841
DEBUG - 2022-11-20 00:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:27:27 --> Total execution time: 0.1976
DEBUG - 2022-11-20 00:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:27:30 --> Total execution time: 0.1817
DEBUG - 2022-11-20 00:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:27:44 --> Total execution time: 0.1762
DEBUG - 2022-11-20 00:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:27:50 --> Total execution time: 0.1742
DEBUG - 2022-11-20 00:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:28:00 --> Total execution time: 0.1785
DEBUG - 2022-11-20 00:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:59:16 --> No URI present. Default controller set.
DEBUG - 2022-11-20 00:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 00:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:29:16 --> Total execution time: 0.1229
DEBUG - 2022-11-20 00:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 00:59:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 00:59:17 --> 404 Page Not Found: Nintendo-switch-oled-whiteblack-joycons-free-fast-shipping-700292html/index
DEBUG - 2022-11-20 01:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:30:02 --> Total execution time: 0.2566
DEBUG - 2022-11-20 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:30:03 --> Total execution time: 0.1581
DEBUG - 2022-11-20 01:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:00:05 --> Total execution time: 0.2250
DEBUG - 2022-11-20 01:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:00:07 --> Total execution time: 0.2381
DEBUG - 2022-11-20 01:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:30:07 --> Total execution time: 0.1988
DEBUG - 2022-11-20 01:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:00:07 --> Total execution time: 0.1789
DEBUG - 2022-11-20 01:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:30:12 --> Total execution time: 0.1926
DEBUG - 2022-11-20 01:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:30:30 --> Total execution time: 0.1764
DEBUG - 2022-11-20 01:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:00:42 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:30:42 --> Total execution time: 0.1758
DEBUG - 2022-11-20 01:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:01:22 --> Total execution time: 0.2130
DEBUG - 2022-11-20 01:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:01:24 --> Total execution time: 0.1929
DEBUG - 2022-11-20 01:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:01:24 --> Total execution time: 0.1762
DEBUG - 2022-11-20 01:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:02:08 --> Total execution time: 0.1692
DEBUG - 2022-11-20 01:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:02:10 --> Total execution time: 0.1837
DEBUG - 2022-11-20 01:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:02:10 --> Total execution time: 0.4141
DEBUG - 2022-11-20 01:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:02:28 --> Total execution time: 0.4763
DEBUG - 2022-11-20 01:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:02:28 --> Total execution time: 0.2245
DEBUG - 2022-11-20 01:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:33:19 --> Total execution time: 0.1944
DEBUG - 2022-11-20 01:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:33:43 --> Total execution time: 0.1708
DEBUG - 2022-11-20 01:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:34:31 --> Total execution time: 0.4703
DEBUG - 2022-11-20 01:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:04:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 01:04:44 --> 404 Page Not Found: Laurel-burch-crossbody-tote-with-cats-896816html/index
DEBUG - 2022-11-20 01:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:04:45 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:34:45 --> Total execution time: 0.1499
DEBUG - 2022-11-20 01:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:36:03 --> Total execution time: 0.1805
DEBUG - 2022-11-20 01:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:36:48 --> Total execution time: 0.4969
DEBUG - 2022-11-20 01:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:37:04 --> Total execution time: 0.2052
DEBUG - 2022-11-20 01:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:37:06 --> Total execution time: 0.1742
DEBUG - 2022-11-20 01:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:37:06 --> Total execution time: 0.1792
DEBUG - 2022-11-20 01:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 01:07:53 --> 404 Page Not Found: Matilda-jane-and-joana-gaines-dress-619541html/index
DEBUG - 2022-11-20 01:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:08:46 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:38:48 --> Total execution time: 2.3216
DEBUG - 2022-11-20 01:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:10:31 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:40:34 --> Total execution time: 3.9717
DEBUG - 2022-11-20 01:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:40:35 --> Total execution time: 0.1207
DEBUG - 2022-11-20 01:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:41:22 --> Total execution time: 0.5786
DEBUG - 2022-11-20 01:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:11:25 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:41:25 --> Total execution time: 0.1336
DEBUG - 2022-11-20 01:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:41:39 --> Total execution time: 0.1812
DEBUG - 2022-11-20 01:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:41:56 --> Total execution time: 0.2165
DEBUG - 2022-11-20 01:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:41:59 --> Total execution time: 0.2283
DEBUG - 2022-11-20 01:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:42:03 --> Total execution time: 0.1980
DEBUG - 2022-11-20 01:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:42:16 --> Total execution time: 0.1719
DEBUG - 2022-11-20 01:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:12:49 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:42:50 --> Total execution time: 0.1226
DEBUG - 2022-11-20 01:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:43:02 --> Total execution time: 0.1922
DEBUG - 2022-11-20 01:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:43:06 --> Total execution time: 0.1740
DEBUG - 2022-11-20 01:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:13:17 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:43:17 --> Total execution time: 0.1314
DEBUG - 2022-11-20 01:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:43:20 --> Total execution time: 0.1785
DEBUG - 2022-11-20 01:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:43:23 --> Total execution time: 0.2210
DEBUG - 2022-11-20 01:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:43:31 --> Total execution time: 0.1802
DEBUG - 2022-11-20 01:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:44:06 --> Total execution time: 0.1338
DEBUG - 2022-11-20 01:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:14:18 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:44:18 --> Total execution time: 0.1723
DEBUG - 2022-11-20 01:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:14:26 --> Total execution time: 0.1906
DEBUG - 2022-11-20 01:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:14:29 --> Total execution time: 0.1851
DEBUG - 2022-11-20 01:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:14:30 --> Total execution time: 0.1726
DEBUG - 2022-11-20 01:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:45:29 --> Total execution time: 2.3000
DEBUG - 2022-11-20 01:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:15:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 01:15:33 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 01:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:15:36 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:45:36 --> Total execution time: 0.1221
DEBUG - 2022-11-20 01:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:18:53 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:48:54 --> Total execution time: 0.4715
DEBUG - 2022-11-20 01:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:48:55 --> Total execution time: 2.0089
DEBUG - 2022-11-20 01:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:53:15 --> Total execution time: 2.1372
DEBUG - 2022-11-20 01:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:54:04 --> Total execution time: 1.9894
DEBUG - 2022-11-20 01:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:24:43 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:54:43 --> Total execution time: 0.1355
DEBUG - 2022-11-20 01:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:55:10 --> Total execution time: 0.1798
DEBUG - 2022-11-20 01:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:55:52 --> Total execution time: 0.4130
DEBUG - 2022-11-20 01:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:55:53 --> Total execution time: 0.1837
DEBUG - 2022-11-20 01:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:55:58 --> Total execution time: 1.9248
DEBUG - 2022-11-20 01:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:55:58 --> Total execution time: 0.2102
DEBUG - 2022-11-20 01:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:56:02 --> Total execution time: 0.1787
DEBUG - 2022-11-20 01:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:26:07 --> Total execution time: 0.1915
DEBUG - 2022-11-20 01:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:26:12 --> Total execution time: 0.2134
DEBUG - 2022-11-20 01:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:56:12 --> Total execution time: 0.1731
DEBUG - 2022-11-20 01:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:26:12 --> Total execution time: 0.1720
DEBUG - 2022-11-20 01:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:26:33 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:56:33 --> Total execution time: 0.2076
DEBUG - 2022-11-20 01:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:57:27 --> Total execution time: 1.1973
DEBUG - 2022-11-20 01:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:57:41 --> Total execution time: 0.1082
DEBUG - 2022-11-20 01:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:59:50 --> Total execution time: 0.2558
DEBUG - 2022-11-20 01:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:29:54 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:59:54 --> Total execution time: 0.1134
DEBUG - 2022-11-20 01:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:29:56 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:59:56 --> Total execution time: 0.1747
DEBUG - 2022-11-20 01:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:29:56 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:59:57 --> Total execution time: 0.1830
DEBUG - 2022-11-20 01:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:00:03 --> Total execution time: 0.1091
DEBUG - 2022-11-20 01:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:00:19 --> Total execution time: 0.1979
DEBUG - 2022-11-20 01:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:00:31 --> Total execution time: 0.2645
DEBUG - 2022-11-20 01:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:02:42 --> Total execution time: 0.2106
DEBUG - 2022-11-20 01:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:02:50 --> Total execution time: 0.1862
DEBUG - 2022-11-20 01:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:02:54 --> Total execution time: 0.2667
DEBUG - 2022-11-20 01:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:03:08 --> Total execution time: 0.2889
DEBUG - 2022-11-20 01:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:33:26 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:03:26 --> Total execution time: 0.1150
DEBUG - 2022-11-20 01:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:33:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:03:38 --> Total execution time: 0.1123
DEBUG - 2022-11-20 01:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:33:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:33:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:03:38 --> Total execution time: 0.1167
DEBUG - 2022-11-20 01:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:03:38 --> Total execution time: 0.1084
DEBUG - 2022-11-20 01:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:33:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 01:33:38 --> 404 Page Not Found: Shirt-720542html/index
DEBUG - 2022-11-20 01:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:33:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:03:38 --> Total execution time: 0.1111
DEBUG - 2022-11-20 01:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:33:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:03:38 --> Total execution time: 0.1365
DEBUG - 2022-11-20 01:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:33:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 01:33:38 --> 404 Page Not Found: Casual-limited-edition-1995-ceramic-floral-music-and-trinket-jewelry-box-966340html/index
DEBUG - 2022-11-20 01:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:33:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:03:39 --> Total execution time: 0.1396
DEBUG - 2022-11-20 01:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:33:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:03:39 --> Total execution time: 0.1113
DEBUG - 2022-11-20 01:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:33:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 01:33:39 --> 404 Page Not Found: Jeffree-star-cosmetics-exclusive-faux-leather-halloween-bat-make-up-bag-690246html/index
DEBUG - 2022-11-20 01:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:34:16 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:04:16 --> Total execution time: 0.1198
DEBUG - 2022-11-20 01:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:04:19 --> Total execution time: 0.4970
DEBUG - 2022-11-20 01:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:06:09 --> Total execution time: 0.4591
DEBUG - 2022-11-20 01:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:36:30 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:06:30 --> Total execution time: 0.1139
DEBUG - 2022-11-20 01:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:06:40 --> Total execution time: 0.1971
DEBUG - 2022-11-20 01:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:07:11 --> Total execution time: 0.6817
DEBUG - 2022-11-20 01:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:07:24 --> Total execution time: 0.1920
DEBUG - 2022-11-20 01:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:07:30 --> Total execution time: 0.1771
DEBUG - 2022-11-20 01:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:07:46 --> Total execution time: 0.1704
DEBUG - 2022-11-20 01:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:08:12 --> Total execution time: 0.1666
DEBUG - 2022-11-20 01:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:08:51 --> Total execution time: 0.1107
DEBUG - 2022-11-20 01:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:08:58 --> Total execution time: 0.4700
DEBUG - 2022-11-20 01:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:09:02 --> Total execution time: 0.1825
DEBUG - 2022-11-20 01:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:09:12 --> Total execution time: 0.1921
DEBUG - 2022-11-20 01:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:09:13 --> Total execution time: 0.1743
DEBUG - 2022-11-20 01:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:09:20 --> Total execution time: 0.2001
DEBUG - 2022-11-20 01:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:09:26 --> Total execution time: 0.2159
DEBUG - 2022-11-20 01:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:09:45 --> Total execution time: 0.1879
DEBUG - 2022-11-20 01:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:49 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:09:49 --> Total execution time: 0.4656
DEBUG - 2022-11-20 01:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:09:54 --> Total execution time: 0.1845
DEBUG - 2022-11-20 01:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:09:56 --> Total execution time: 0.2164
DEBUG - 2022-11-20 01:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:39:57 --> Total execution time: 0.1743
DEBUG - 2022-11-20 01:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:39:59 --> Total execution time: 0.1936
DEBUG - 2022-11-20 01:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:39:59 --> Total execution time: 0.2055
DEBUG - 2022-11-20 01:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:10:02 --> Total execution time: 0.2643
DEBUG - 2022-11-20 01:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:10:06 --> Total execution time: 0.1768
DEBUG - 2022-11-20 01:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:10:16 --> Total execution time: 0.1722
DEBUG - 2022-11-20 01:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:40:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:10:37 --> Total execution time: 0.1825
DEBUG - 2022-11-20 01:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:12:28 --> Total execution time: 0.1270
DEBUG - 2022-11-20 01:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:14:09 --> Total execution time: 0.2194
DEBUG - 2022-11-20 01:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:14:14 --> Total execution time: 0.1980
DEBUG - 2022-11-20 01:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:44:14 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:14:14 --> Total execution time: 0.1288
DEBUG - 2022-11-20 01:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:14:19 --> Total execution time: 0.1810
DEBUG - 2022-11-20 01:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:14:36 --> Total execution time: 0.1970
DEBUG - 2022-11-20 01:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:45:03 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:15:04 --> Total execution time: 0.1651
DEBUG - 2022-11-20 01:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:18:44 --> Total execution time: 0.2439
DEBUG - 2022-11-20 01:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:18:44 --> Total execution time: 0.1984
DEBUG - 2022-11-20 01:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:18:47 --> Total execution time: 0.1851
DEBUG - 2022-11-20 01:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:49:10 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:19:10 --> Total execution time: 0.1169
DEBUG - 2022-11-20 01:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:19:15 --> Total execution time: 0.1730
DEBUG - 2022-11-20 01:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:49:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 01:49:44 --> 404 Page Not Found: Disney-cars-2-lot-973017html/index
DEBUG - 2022-11-20 01:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:21:13 --> Total execution time: 1.0616
DEBUG - 2022-11-20 01:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:21:14 --> Total execution time: 0.1915
DEBUG - 2022-11-20 01:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:21:53 --> Total execution time: 0.1828
DEBUG - 2022-11-20 01:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:51:55 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:21:56 --> Total execution time: 0.1270
DEBUG - 2022-11-20 01:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:22:07 --> Total execution time: 0.1824
DEBUG - 2022-11-20 01:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:23:11 --> Total execution time: 0.1737
DEBUG - 2022-11-20 01:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:53:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:23:37 --> Total execution time: 0.1122
DEBUG - 2022-11-20 01:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:53:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 01:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:23:38 --> Total execution time: 0.1089
DEBUG - 2022-11-20 01:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:23:55 --> Total execution time: 0.1773
DEBUG - 2022-11-20 01:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:23:56 --> Total execution time: 0.2050
DEBUG - 2022-11-20 01:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:24:04 --> Total execution time: 0.1854
DEBUG - 2022-11-20 01:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:24:07 --> Total execution time: 0.1837
DEBUG - 2022-11-20 01:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:24:19 --> Total execution time: 0.1856
DEBUG - 2022-11-20 01:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:24:30 --> Total execution time: 0.2154
DEBUG - 2022-11-20 01:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:24:48 --> Total execution time: 0.2086
DEBUG - 2022-11-20 01:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:24:55 --> Total execution time: 0.1912
DEBUG - 2022-11-20 01:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:25:08 --> Total execution time: 0.1874
DEBUG - 2022-11-20 01:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:25:14 --> Total execution time: 0.1785
DEBUG - 2022-11-20 01:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 01:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:25:38 --> Total execution time: 0.1866
DEBUG - 2022-11-20 01:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:26:08 --> Total execution time: 0.4951
DEBUG - 2022-11-20 01:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:27:55 --> Total execution time: 1.0946
DEBUG - 2022-11-20 01:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:28:02 --> Total execution time: 0.1925
DEBUG - 2022-11-20 01:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:28:06 --> Total execution time: 0.1959
DEBUG - 2022-11-20 01:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:28:13 --> Total execution time: 0.1858
DEBUG - 2022-11-20 01:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:28:22 --> Total execution time: 0.2456
DEBUG - 2022-11-20 01:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:28:37 --> Total execution time: 0.1796
DEBUG - 2022-11-20 01:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:28:48 --> Total execution time: 0.4889
DEBUG - 2022-11-20 01:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:28:48 --> Total execution time: 0.1797
DEBUG - 2022-11-20 01:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:28:53 --> Total execution time: 0.2547
DEBUG - 2022-11-20 01:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:29:18 --> Total execution time: 0.2183
DEBUG - 2022-11-20 01:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:29:25 --> Total execution time: 0.2519
DEBUG - 2022-11-20 01:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:29:26 --> Total execution time: 0.2124
DEBUG - 2022-11-20 01:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:29:29 --> Total execution time: 0.1831
DEBUG - 2022-11-20 01:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:29:34 --> Total execution time: 0.2077
DEBUG - 2022-11-20 01:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 01:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 01:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:29:52 --> Total execution time: 0.1974
DEBUG - 2022-11-20 02:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:30:02 --> Total execution time: 0.2133
DEBUG - 2022-11-20 02:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:30:10 --> Total execution time: 0.1931
DEBUG - 2022-11-20 02:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:30:10 --> Total execution time: 0.1849
DEBUG - 2022-11-20 02:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:30:21 --> Total execution time: 0.1807
DEBUG - 2022-11-20 02:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:30:57 --> Total execution time: 0.4703
DEBUG - 2022-11-20 02:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:31:13 --> Total execution time: 0.2361
DEBUG - 2022-11-20 02:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:31:18 --> Total execution time: 0.1862
DEBUG - 2022-11-20 02:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:01:35 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:31:35 --> Total execution time: 0.1223
DEBUG - 2022-11-20 02:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:03:19 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:33:20 --> Total execution time: 0.7202
DEBUG - 2022-11-20 02:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:33:39 --> Total execution time: 0.1792
DEBUG - 2022-11-20 02:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:03:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 02:03:41 --> 404 Page Not Found: Well-known/traffic-advice
DEBUG - 2022-11-20 02:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:33:42 --> Total execution time: 0.1328
DEBUG - 2022-11-20 02:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:33:44 --> Total execution time: 0.1172
DEBUG - 2022-11-20 02:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:33:47 --> Total execution time: 0.1100
DEBUG - 2022-11-20 02:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:34:02 --> Total execution time: 0.3233
DEBUG - 2022-11-20 02:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:04:12 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:34:13 --> Total execution time: 0.1124
DEBUG - 2022-11-20 02:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:34:40 --> Total execution time: 0.1077
DEBUG - 2022-11-20 02:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:34:41 --> Total execution time: 0.1041
DEBUG - 2022-11-20 02:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:34:41 --> Total execution time: 0.1200
DEBUG - 2022-11-20 02:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:34:41 --> Total execution time: 0.1163
DEBUG - 2022-11-20 02:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:34:42 --> Total execution time: 0.1058
DEBUG - 2022-11-20 02:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:34:42 --> Total execution time: 0.1139
DEBUG - 2022-11-20 02:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:37:43 --> Total execution time: 0.9779
DEBUG - 2022-11-20 02:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:37:54 --> Total execution time: 0.1722
DEBUG - 2022-11-20 02:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:08:02 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:38:02 --> Total execution time: 0.1514
DEBUG - 2022-11-20 02:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:38:11 --> Total execution time: 0.1810
DEBUG - 2022-11-20 02:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:38:24 --> Total execution time: 0.2008
DEBUG - 2022-11-20 02:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:38:28 --> Total execution time: 0.2118
DEBUG - 2022-11-20 02:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:08:44 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:38:44 --> Total execution time: 0.1370
DEBUG - 2022-11-20 02:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:39:07 --> Total execution time: 0.5467
DEBUG - 2022-11-20 02:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:39:08 --> Total execution time: 0.2149
DEBUG - 2022-11-20 02:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:39:09 --> Total execution time: 0.1851
DEBUG - 2022-11-20 02:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:39:15 --> Total execution time: 0.3026
DEBUG - 2022-11-20 02:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:09:18 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:39:18 --> Total execution time: 0.1254
DEBUG - 2022-11-20 02:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:39:54 --> Total execution time: 0.1894
DEBUG - 2022-11-20 02:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:40:01 --> Total execution time: 0.1820
DEBUG - 2022-11-20 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:40:13 --> Total execution time: 0.1965
DEBUG - 2022-11-20 02:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:40:15 --> Total execution time: 0.1704
DEBUG - 2022-11-20 02:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:40:22 --> Total execution time: 0.1738
DEBUG - 2022-11-20 02:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:40:42 --> Total execution time: 0.1872
DEBUG - 2022-11-20 02:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:40:49 --> Total execution time: 0.1710
DEBUG - 2022-11-20 02:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:40:56 --> Total execution time: 0.1865
DEBUG - 2022-11-20 02:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:41:10 --> Total execution time: 0.1929
DEBUG - 2022-11-20 02:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:41:22 --> Total execution time: 0.1725
DEBUG - 2022-11-20 02:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:41:25 --> Total execution time: 0.2169
DEBUG - 2022-11-20 02:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:41:26 --> Total execution time: 0.1980
DEBUG - 2022-11-20 02:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:41:54 --> Total execution time: 0.1838
DEBUG - 2022-11-20 02:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:41:58 --> Total execution time: 0.1781
DEBUG - 2022-11-20 02:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:42:09 --> Total execution time: 0.2221
DEBUG - 2022-11-20 02:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:44:16 --> Total execution time: 0.2542
DEBUG - 2022-11-20 02:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:17:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 02:17:25 --> 404 Page Not Found: Category/education
DEBUG - 2022-11-20 02:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:18:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:18:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:48:38 --> Total execution time: 0.6316
DEBUG - 2022-11-20 13:48:38 --> Total execution time: 0.3198
DEBUG - 2022-11-20 02:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:48:38 --> Total execution time: 0.1177
DEBUG - 2022-11-20 02:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:18:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:48:38 --> Total execution time: 0.1197
DEBUG - 2022-11-20 02:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:50:26 --> Total execution time: 0.8521
DEBUG - 2022-11-20 02:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:21:20 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:51:20 --> Total execution time: 0.5101
DEBUG - 2022-11-20 02:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:21:21 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:51:21 --> Total execution time: 0.1239
DEBUG - 2022-11-20 02:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:51:36 --> Total execution time: 0.1207
DEBUG - 2022-11-20 02:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:52:03 --> Total execution time: 0.1089
DEBUG - 2022-11-20 02:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:22:45 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:52:45 --> Total execution time: 0.1162
DEBUG - 2022-11-20 02:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:57:11 --> Total execution time: 0.2033
DEBUG - 2022-11-20 02:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:57:19 --> Total execution time: 0.2040
DEBUG - 2022-11-20 02:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:57:29 --> Total execution time: 0.2084
DEBUG - 2022-11-20 02:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:57:37 --> Total execution time: 0.1866
DEBUG - 2022-11-20 02:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:57:38 --> Total execution time: 0.2221
DEBUG - 2022-11-20 02:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:57:47 --> Total execution time: 0.1922
DEBUG - 2022-11-20 02:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:57:59 --> Total execution time: 0.1835
DEBUG - 2022-11-20 02:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:58:00 --> Total execution time: 0.1742
DEBUG - 2022-11-20 02:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:58:04 --> Total execution time: 0.2379
DEBUG - 2022-11-20 02:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:58:52 --> Total execution time: 0.2610
DEBUG - 2022-11-20 02:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:58:53 --> Total execution time: 0.2401
DEBUG - 2022-11-20 02:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:59:56 --> Total execution time: 0.2195
DEBUG - 2022-11-20 02:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:12 --> Total execution time: 0.2306
DEBUG - 2022-11-20 02:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:13 --> Total execution time: 0.2395
DEBUG - 2022-11-20 02:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:15 --> Total execution time: 0.1696
DEBUG - 2022-11-20 02:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:21 --> Total execution time: 0.1844
DEBUG - 2022-11-20 02:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:22 --> Total execution time: 0.4596
DEBUG - 2022-11-20 02:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:26 --> Total execution time: 0.1843
DEBUG - 2022-11-20 02:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:30 --> Total execution time: 0.1763
DEBUG - 2022-11-20 02:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:32 --> Total execution time: 0.1849
DEBUG - 2022-11-20 02:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:32 --> Total execution time: 0.1762
DEBUG - 2022-11-20 02:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:39 --> Total execution time: 0.1720
DEBUG - 2022-11-20 02:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:43 --> Total execution time: 0.1769
DEBUG - 2022-11-20 02:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:59 --> Total execution time: 0.2682
DEBUG - 2022-11-20 02:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:59 --> Total execution time: 0.2447
DEBUG - 2022-11-20 02:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:01:51 --> Total execution time: 0.1732
DEBUG - 2022-11-20 02:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:31:54 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:01:54 --> Total execution time: 0.1157
DEBUG - 2022-11-20 02:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:31:55 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:01:55 --> Total execution time: 0.1161
DEBUG - 2022-11-20 02:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:01:58 --> Total execution time: 0.1665
DEBUG - 2022-11-20 02:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:02:00 --> Total execution time: 0.1637
DEBUG - 2022-11-20 02:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:32:00 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:02:00 --> Total execution time: 0.1722
DEBUG - 2022-11-20 02:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:02:06 --> Total execution time: 0.1678
DEBUG - 2022-11-20 02:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:02:07 --> Total execution time: 0.1635
DEBUG - 2022-11-20 02:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 02:32:33 --> 404 Page Not Found: Course/premium-level-program
DEBUG - 2022-11-20 02:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:02:34 --> Total execution time: 0.1119
DEBUG - 2022-11-20 02:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:33:18 --> Total execution time: 0.1442
DEBUG - 2022-11-20 02:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:33:23 --> Total execution time: 0.2833
DEBUG - 2022-11-20 02:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:33:23 --> Total execution time: 0.1337
DEBUG - 2022-11-20 02:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:34:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:04:37 --> Total execution time: 0.1120
DEBUG - 2022-11-20 02:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 02:34:44 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 02:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:04:51 --> Total execution time: 0.1698
DEBUG - 2022-11-20 02:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:04:58 --> Total execution time: 0.1915
DEBUG - 2022-11-20 02:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:05:05 --> Total execution time: 0.2123
DEBUG - 2022-11-20 02:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:35:20 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:05:20 --> Total execution time: 0.1248
DEBUG - 2022-11-20 02:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:35:21 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:05:21 --> Total execution time: 0.1158
DEBUG - 2022-11-20 02:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:35:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:05:39 --> Total execution time: 0.1116
DEBUG - 2022-11-20 02:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:35:55 --> Total execution time: 0.1770
DEBUG - 2022-11-20 02:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:35:57 --> Total execution time: 0.1792
DEBUG - 2022-11-20 02:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:35:58 --> Total execution time: 0.1802
DEBUG - 2022-11-20 02:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:35:59 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:05:59 --> Total execution time: 0.1185
DEBUG - 2022-11-20 02:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:36:06 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:06:06 --> Total execution time: 0.1813
DEBUG - 2022-11-20 02:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:07:03 --> Total execution time: 0.3854
DEBUG - 2022-11-20 02:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:07:03 --> Total execution time: 1.3155
DEBUG - 2022-11-20 02:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:38:52 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:08:53 --> Total execution time: 0.5862
DEBUG - 2022-11-20 02:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:08:55 --> Total execution time: 0.2121
DEBUG - 2022-11-20 02:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:42:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 02:42:58 --> 404 Page Not Found: 15-649193html/index
DEBUG - 2022-11-20 02:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:43:00 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:13:00 --> Total execution time: 0.1845
DEBUG - 2022-11-20 02:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:43:05 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:13:05 --> Total execution time: 0.1148
DEBUG - 2022-11-20 02:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:13:18 --> Total execution time: 0.1137
DEBUG - 2022-11-20 02:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:13:45 --> Total execution time: 0.1935
DEBUG - 2022-11-20 02:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:14:49 --> Total execution time: 0.1953
DEBUG - 2022-11-20 02:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:16:19 --> Total execution time: 0.1341
DEBUG - 2022-11-20 02:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:47:59 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:17:59 --> Total execution time: 0.1208
DEBUG - 2022-11-20 02:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:18:30 --> Total execution time: 0.4592
DEBUG - 2022-11-20 02:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:19:24 --> Total execution time: 0.4701
DEBUG - 2022-11-20 02:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:19:24 --> Total execution time: 0.1896
DEBUG - 2022-11-20 02:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:20:04 --> Total execution time: 0.1862
DEBUG - 2022-11-20 02:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:20:24 --> Total execution time: 0.2088
DEBUG - 2022-11-20 02:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:20:24 --> Total execution time: 0.1889
DEBUG - 2022-11-20 02:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:20:28 --> Total execution time: 0.1960
DEBUG - 2022-11-20 02:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:20:34 --> Total execution time: 0.1874
DEBUG - 2022-11-20 02:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:21:06 --> Total execution time: 0.3890
DEBUG - 2022-11-20 02:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:21:59 --> Total execution time: 0.1087
DEBUG - 2022-11-20 02:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 02:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:22:05 --> Total execution time: 0.1948
DEBUG - 2022-11-20 02:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:22:13 --> Total execution time: 0.3133
DEBUG - 2022-11-20 02:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:22:22 --> Total execution time: 0.2012
DEBUG - 2022-11-20 02:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:53:22 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:23:22 --> Total execution time: 0.1125
DEBUG - 2022-11-20 02:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:53:23 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:23:23 --> Total execution time: 0.1147
DEBUG - 2022-11-20 02:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:54:12 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:24:14 --> Total execution time: 1.6080
DEBUG - 2022-11-20 02:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:54:24 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:24:24 --> Total execution time: 0.1970
DEBUG - 2022-11-20 02:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:25:55 --> Total execution time: 2.4931
DEBUG - 2022-11-20 02:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:25:56 --> Total execution time: 0.5253
DEBUG - 2022-11-20 02:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:26:03 --> Total execution time: 0.5005
DEBUG - 2022-11-20 02:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:26:09 --> Total execution time: 0.2095
DEBUG - 2022-11-20 02:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:26:15 --> Total execution time: 0.3210
DEBUG - 2022-11-20 02:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:56:20 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:26:20 --> Total execution time: 0.1146
DEBUG - 2022-11-20 02:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:26:36 --> Total execution time: 0.7579
DEBUG - 2022-11-20 02:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:58:52 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:28:53 --> Total execution time: 0.7320
DEBUG - 2022-11-20 02:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 02:58:59 --> No URI present. Default controller set.
DEBUG - 2022-11-20 02:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 02:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:28:59 --> Total execution time: 0.1176
DEBUG - 2022-11-20 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:30:03 --> Total execution time: 0.7096
DEBUG - 2022-11-20 03:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:30:29 --> Total execution time: 0.1995
DEBUG - 2022-11-20 03:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:31:51 --> Total execution time: 0.1721
DEBUG - 2022-11-20 03:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:33:06 --> Total execution time: 0.2458
DEBUG - 2022-11-20 03:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:03:36 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:33:36 --> Total execution time: 0.1155
DEBUG - 2022-11-20 03:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:33:38 --> Total execution time: 0.1076
DEBUG - 2022-11-20 03:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:33:41 --> Total execution time: 0.1273
DEBUG - 2022-11-20 03:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:33:49 --> Total execution time: 0.1788
DEBUG - 2022-11-20 03:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:33:50 --> Total execution time: 0.2685
DEBUG - 2022-11-20 03:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:33:55 --> Total execution time: 0.1918
DEBUG - 2022-11-20 03:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:33:59 --> Total execution time: 0.3088
DEBUG - 2022-11-20 03:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:34:00 --> Total execution time: 0.1892
DEBUG - 2022-11-20 03:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:34:07 --> Total execution time: 0.2388
DEBUG - 2022-11-20 03:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:34:09 --> Total execution time: 0.4691
DEBUG - 2022-11-20 03:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:34:15 --> Total execution time: 0.1993
DEBUG - 2022-11-20 03:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:34:25 --> Total execution time: 0.1906
DEBUG - 2022-11-20 03:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:34:27 --> Total execution time: 0.1806
DEBUG - 2022-11-20 03:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:04:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:34:37 --> Total execution time: 0.2082
DEBUG - 2022-11-20 03:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 03:04:38 --> 404 Page Not Found: Dyson-airwrap-complete-styler-version-2-453347html/index
DEBUG - 2022-11-20 03:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:04:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:34:39 --> Total execution time: 0.1332
DEBUG - 2022-11-20 03:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:04:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 03:04:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 03:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:35:11 --> Total execution time: 0.1739
DEBUG - 2022-11-20 03:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:35:25 --> Total execution time: 0.1746
DEBUG - 2022-11-20 03:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:35:33 --> Total execution time: 0.3003
DEBUG - 2022-11-20 03:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:07:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 03:07:20 --> 404 Page Not Found: Samsung-galaxy-z-flip-3-5g-256-gb-unlocked-732219html/index
DEBUG - 2022-11-20 03:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:10:15 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:40:15 --> Total execution time: 0.1884
DEBUG - 2022-11-20 03:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:10:21 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:40:21 --> Total execution time: 0.1788
DEBUG - 2022-11-20 03:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:41:40 --> Total execution time: 0.1772
DEBUG - 2022-11-20 03:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:13:07 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:43:07 --> Total execution time: 0.4605
DEBUG - 2022-11-20 03:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:13:13 --> Total execution time: 0.1784
DEBUG - 2022-11-20 03:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:13:15 --> Total execution time: 0.1780
DEBUG - 2022-11-20 03:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:13:15 --> Total execution time: 0.1896
DEBUG - 2022-11-20 03:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:13:34 --> Total execution time: 0.1910
DEBUG - 2022-11-20 03:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:13:49 --> Total execution time: 0.1830
DEBUG - 2022-11-20 03:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:13:51 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:43:52 --> Total execution time: 0.1748
DEBUG - 2022-11-20 03:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:46:15 --> Total execution time: 0.1128
DEBUG - 2022-11-20 03:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:17:07 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:47:07 --> Total execution time: 0.1122
DEBUG - 2022-11-20 03:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:18:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:48:37 --> Total execution time: 0.1108
DEBUG - 2022-11-20 03:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:48:44 --> Total execution time: 0.1836
DEBUG - 2022-11-20 03:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:48:51 --> Total execution time: 0.5083
DEBUG - 2022-11-20 03:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:48:57 --> Total execution time: 0.1843
DEBUG - 2022-11-20 03:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:49:02 --> Total execution time: 0.1815
DEBUG - 2022-11-20 03:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:49:03 --> Total execution time: 0.1852
DEBUG - 2022-11-20 03:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:19:15 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:49:15 --> Total execution time: 0.4652
DEBUG - 2022-11-20 03:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:49:34 --> Total execution time: 0.4713
DEBUG - 2022-11-20 03:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:21:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 03:21:40 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-11-20 03:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:22:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 03:22:42 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-11-20 03:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:25:27 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:55:28 --> Total execution time: 0.6571
DEBUG - 2022-11-20 03:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:25:42 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:55:42 --> Total execution time: 0.1084
DEBUG - 2022-11-20 03:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:56:23 --> Total execution time: 0.1347
DEBUG - 2022-11-20 03:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:26:29 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:56:30 --> Total execution time: 0.1128
DEBUG - 2022-11-20 03:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:56:36 --> Total execution time: 0.1267
DEBUG - 2022-11-20 03:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:56:42 --> Total execution time: 0.1726
DEBUG - 2022-11-20 03:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:57:08 --> Total execution time: 0.2178
DEBUG - 2022-11-20 03:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:57:09 --> Total execution time: 0.1917
DEBUG - 2022-11-20 03:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:57:16 --> Total execution time: 0.2201
DEBUG - 2022-11-20 03:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:57:17 --> Total execution time: 0.2547
DEBUG - 2022-11-20 03:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:57:22 --> Total execution time: 0.2341
DEBUG - 2022-11-20 03:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:57:28 --> Total execution time: 0.1882
DEBUG - 2022-11-20 03:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:57:33 --> Total execution time: 0.2174
DEBUG - 2022-11-20 03:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:57:36 --> Total execution time: 0.1845
DEBUG - 2022-11-20 03:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:57:49 --> Total execution time: 0.1737
DEBUG - 2022-11-20 03:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:57:56 --> Total execution time: 0.2181
DEBUG - 2022-11-20 03:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 03:29:55 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-20 03:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:01:06 --> Total execution time: 0.7043
DEBUG - 2022-11-20 03:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:32:35 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:02:36 --> Total execution time: 0.6207
DEBUG - 2022-11-20 03:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:02:37 --> Total execution time: 0.1742
DEBUG - 2022-11-20 03:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:32:57 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:02:58 --> Total execution time: 0.1998
DEBUG - 2022-11-20 03:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:03:17 --> Total execution time: 0.1852
DEBUG - 2022-11-20 03:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:03:45 --> Total execution time: 0.1696
DEBUG - 2022-11-20 03:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:03:58 --> Total execution time: 0.1150
DEBUG - 2022-11-20 03:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:04:06 --> Total execution time: 0.1948
DEBUG - 2022-11-20 03:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:04:13 --> Total execution time: 0.1965
DEBUG - 2022-11-20 03:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:04:18 --> Total execution time: 0.1891
DEBUG - 2022-11-20 03:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:04:28 --> Total execution time: 0.1697
DEBUG - 2022-11-20 03:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:11:40 --> Total execution time: 1.2345
DEBUG - 2022-11-20 03:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:11:41 --> Total execution time: 0.1862
DEBUG - 2022-11-20 03:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:12:40 --> Total execution time: 0.1985
DEBUG - 2022-11-20 03:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:42:50 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:12:50 --> Total execution time: 0.2016
DEBUG - 2022-11-20 03:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:14:14 --> Total execution time: 0.1813
DEBUG - 2022-11-20 03:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:18:15 --> Total execution time: 0.6108
DEBUG - 2022-11-20 03:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:48:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:18:39 --> Total execution time: 0.1296
DEBUG - 2022-11-20 03:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:49:59 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:19:59 --> Total execution time: 0.1206
DEBUG - 2022-11-20 03:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:50:26 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:20:26 --> Total execution time: 0.1164
DEBUG - 2022-11-20 03:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:50:32 --> Total execution time: 0.1953
DEBUG - 2022-11-20 03:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:50:44 --> Total execution time: 0.1992
DEBUG - 2022-11-20 03:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:50:45 --> Total execution time: 0.2455
DEBUG - 2022-11-20 03:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:51:14 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:21:14 --> Total execution time: 0.1173
DEBUG - 2022-11-20 03:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:21:20 --> Total execution time: 0.1199
DEBUG - 2022-11-20 03:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:21:41 --> Total execution time: 0.1405
DEBUG - 2022-11-20 03:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:21:45 --> Total execution time: 0.2015
DEBUG - 2022-11-20 03:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:21:53 --> Total execution time: 0.2891
DEBUG - 2022-11-20 03:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:22:05 --> Total execution time: 0.6538
DEBUG - 2022-11-20 03:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:22:18 --> Total execution time: 0.1873
DEBUG - 2022-11-20 03:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:22:27 --> Total execution time: 0.2111
DEBUG - 2022-11-20 03:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:52:31 --> Total execution time: 0.1786
DEBUG - 2022-11-20 03:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:22:33 --> Total execution time: 0.1927
DEBUG - 2022-11-20 03:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:52:34 --> Total execution time: 0.1834
DEBUG - 2022-11-20 03:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:52:34 --> Total execution time: 0.1881
DEBUG - 2022-11-20 03:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:22:39 --> Total execution time: 0.2085
DEBUG - 2022-11-20 03:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:22:48 --> Total execution time: 0.1700
DEBUG - 2022-11-20 03:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:22:54 --> Total execution time: 0.2474
DEBUG - 2022-11-20 03:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:23:27 --> Total execution time: 2.4331
DEBUG - 2022-11-20 03:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:53:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 03:53:33 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 03:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:23:49 --> Total execution time: 0.1937
DEBUG - 2022-11-20 03:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:54:21 --> Total execution time: 0.1737
DEBUG - 2022-11-20 03:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:28:20 --> Total execution time: 0.4988
DEBUG - 2022-11-20 03:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:58:54 --> No URI present. Default controller set.
DEBUG - 2022-11-20 03:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:28:54 --> Total execution time: 0.1239
DEBUG - 2022-11-20 03:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:58:56 --> Total execution time: 0.1946
DEBUG - 2022-11-20 03:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:29:09 --> Total execution time: 0.1079
DEBUG - 2022-11-20 03:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:59:10 --> Total execution time: 0.2135
DEBUG - 2022-11-20 03:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:29:17 --> Total execution time: 0.2027
DEBUG - 2022-11-20 03:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 03:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:29:19 --> Total execution time: 0.1850
DEBUG - 2022-11-20 03:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:29:30 --> Total execution time: 0.2365
DEBUG - 2022-11-20 03:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 03:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 03:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:29:40 --> Total execution time: 0.2321
DEBUG - 2022-11-20 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:30:02 --> Total execution time: 0.1742
DEBUG - 2022-11-20 04:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:31:16 --> Total execution time: 0.1876
DEBUG - 2022-11-20 04:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:31:40 --> Total execution time: 0.2258
DEBUG - 2022-11-20 04:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:02:26 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:32:26 --> Total execution time: 0.2437
DEBUG - 2022-11-20 04:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:32:44 --> Total execution time: 0.1890
DEBUG - 2022-11-20 04:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:33:04 --> Total execution time: 0.1803
DEBUG - 2022-11-20 04:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:33:05 --> Total execution time: 0.1752
DEBUG - 2022-11-20 04:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:03:30 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:33:30 --> Total execution time: 0.1466
DEBUG - 2022-11-20 04:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:03:48 --> Total execution time: 0.1936
DEBUG - 2022-11-20 04:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:03:56 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:33:57 --> Total execution time: 0.1748
DEBUG - 2022-11-20 04:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:03:59 --> Total execution time: 0.2228
DEBUG - 2022-11-20 04:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:34:00 --> Total execution time: 0.1088
DEBUG - 2022-11-20 04:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:34:06 --> Total execution time: 0.1763
DEBUG - 2022-11-20 04:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:34:12 --> Total execution time: 0.1821
DEBUG - 2022-11-20 04:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:34:16 --> Total execution time: 0.1796
DEBUG - 2022-11-20 04:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:34:19 --> Total execution time: 0.1886
DEBUG - 2022-11-20 04:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:34:43 --> Total execution time: 0.1932
DEBUG - 2022-11-20 04:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:04:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 04:04:44 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 04:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:34:45 --> Total execution time: 0.2140
DEBUG - 2022-11-20 04:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:34:57 --> Total execution time: 0.1976
DEBUG - 2022-11-20 04:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:04:58 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:34:59 --> Total execution time: 0.4636
DEBUG - 2022-11-20 04:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:35:14 --> Total execution time: 0.1732
DEBUG - 2022-11-20 04:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:35:37 --> Total execution time: 0.2282
DEBUG - 2022-11-20 04:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:35:55 --> Total execution time: 0.3742
DEBUG - 2022-11-20 04:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:36:19 --> Total execution time: 0.5020
DEBUG - 2022-11-20 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:37:16 --> Total execution time: 0.1824
DEBUG - 2022-11-20 04:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:07:43 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:37:43 --> Total execution time: 0.4642
DEBUG - 2022-11-20 04:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:37:54 --> Total execution time: 0.1905
DEBUG - 2022-11-20 04:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:07:54 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:37:54 --> Total execution time: 0.1282
DEBUG - 2022-11-20 04:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:37:59 --> Total execution time: 0.2308
DEBUG - 2022-11-20 04:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:38:03 --> Total execution time: 0.1846
DEBUG - 2022-11-20 04:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:38:12 --> Total execution time: 0.1731
DEBUG - 2022-11-20 04:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:08:25 --> Total execution time: 0.1766
DEBUG - 2022-11-20 04:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:08:38 --> Total execution time: 0.2944
DEBUG - 2022-11-20 04:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:38:43 --> Total execution time: 0.1428
DEBUG - 2022-11-20 04:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:08:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 04:08:46 --> 404 Page Not Found: Author/admin
DEBUG - 2022-11-20 04:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:08:47 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 04:08:47 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 04:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:38:47 --> Total execution time: 0.1567
DEBUG - 2022-11-20 04:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:39:04 --> Total execution time: 0.1981
DEBUG - 2022-11-20 04:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:39:07 --> Total execution time: 0.1913
DEBUG - 2022-11-20 04:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:39:17 --> Total execution time: 0.1846
DEBUG - 2022-11-20 04:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:39:21 --> Total execution time: 0.1840
DEBUG - 2022-11-20 04:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:39:27 --> Total execution time: 0.2193
DEBUG - 2022-11-20 04:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:39:28 --> Total execution time: 0.1884
DEBUG - 2022-11-20 04:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:39:29 --> Total execution time: 0.1737
DEBUG - 2022-11-20 04:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:10:46 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:40:46 --> Total execution time: 0.5050
DEBUG - 2022-11-20 04:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:40:47 --> Total execution time: 0.1697
DEBUG - 2022-11-20 04:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:41:49 --> Total execution time: 0.2064
DEBUG - 2022-11-20 04:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:41:57 --> Total execution time: 0.2149
DEBUG - 2022-11-20 04:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:43:03 --> Total execution time: 0.1875
DEBUG - 2022-11-20 04:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:43:03 --> Total execution time: 0.4798
DEBUG - 2022-11-20 04:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:43:07 --> Total execution time: 0.1952
DEBUG - 2022-11-20 04:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:43:15 --> Total execution time: 0.2286
DEBUG - 2022-11-20 04:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:13:19 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:43:20 --> Total execution time: 0.4591
DEBUG - 2022-11-20 04:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:43:20 --> Total execution time: 0.1827
DEBUG - 2022-11-20 04:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:43:26 --> Total execution time: 0.1837
DEBUG - 2022-11-20 04:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:43:29 --> Total execution time: 0.1759
DEBUG - 2022-11-20 04:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:43:50 --> Total execution time: 0.1916
DEBUG - 2022-11-20 04:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:44:10 --> Total execution time: 0.1839
DEBUG - 2022-11-20 04:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:44:22 --> Total execution time: 0.1808
DEBUG - 2022-11-20 04:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:44:34 --> Total execution time: 0.2214
DEBUG - 2022-11-20 04:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:16:01 --> Total execution time: 0.4957
DEBUG - 2022-11-20 04:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:46:03 --> Total execution time: 0.1796
DEBUG - 2022-11-20 04:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:46:08 --> Total execution time: 0.2640
DEBUG - 2022-11-20 04:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:46:10 --> Total execution time: 0.2238
DEBUG - 2022-11-20 04:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:46:13 --> Total execution time: 0.2069
DEBUG - 2022-11-20 04:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:46:16 --> Total execution time: 0.1096
DEBUG - 2022-11-20 04:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:46:27 --> Total execution time: 0.2651
DEBUG - 2022-11-20 04:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:46:40 --> Total execution time: 0.1078
DEBUG - 2022-11-20 04:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:46:49 --> Total execution time: 0.1774
DEBUG - 2022-11-20 04:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:46:55 --> Total execution time: 0.2251
DEBUG - 2022-11-20 04:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:47:02 --> Total execution time: 0.2140
DEBUG - 2022-11-20 04:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:47:06 --> Total execution time: 0.2064
DEBUG - 2022-11-20 04:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:47:14 --> Total execution time: 0.1691
DEBUG - 2022-11-20 04:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:48:28 --> Total execution time: 0.1084
DEBUG - 2022-11-20 04:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:48:37 --> Total execution time: 0.1687
DEBUG - 2022-11-20 04:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:48:57 --> Total execution time: 0.1740
DEBUG - 2022-11-20 04:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:49:17 --> Total execution time: 0.1779
DEBUG - 2022-11-20 04:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:49:20 --> Total execution time: 0.2018
DEBUG - 2022-11-20 04:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:49:23 --> Total execution time: 0.1867
DEBUG - 2022-11-20 04:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:49:28 --> Total execution time: 0.1095
DEBUG - 2022-11-20 04:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:49:29 --> Total execution time: 0.1175
DEBUG - 2022-11-20 04:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:49:29 --> Total execution time: 0.1144
DEBUG - 2022-11-20 04:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:49:34 --> Total execution time: 0.2346
DEBUG - 2022-11-20 04:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:49:54 --> Total execution time: 0.1813
DEBUG - 2022-11-20 04:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:50:14 --> Total execution time: 0.1921
DEBUG - 2022-11-20 04:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:50:17 --> Total execution time: 0.1754
DEBUG - 2022-11-20 04:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:50:17 --> Total execution time: 0.1099
DEBUG - 2022-11-20 04:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:50:18 --> Total execution time: 0.1804
DEBUG - 2022-11-20 04:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:50:23 --> Total execution time: 0.1928
DEBUG - 2022-11-20 04:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:50:35 --> Total execution time: 0.1692
DEBUG - 2022-11-20 04:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:50:35 --> Total execution time: 0.1927
DEBUG - 2022-11-20 04:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:50:40 --> Total execution time: 0.2069
DEBUG - 2022-11-20 04:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:50:42 --> Total execution time: 0.1754
DEBUG - 2022-11-20 04:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:50:52 --> Total execution time: 0.2164
DEBUG - 2022-11-20 04:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:50:52 --> Total execution time: 0.4899
DEBUG - 2022-11-20 04:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:50:52 --> Total execution time: 0.5329
DEBUG - 2022-11-20 04:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:50:53 --> Total execution time: 0.6004
DEBUG - 2022-11-20 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:50:59 --> Total execution time: 0.1852
DEBUG - 2022-11-20 04:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:51:07 --> Total execution time: 0.1783
DEBUG - 2022-11-20 04:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:51:08 --> Total execution time: 0.1855
DEBUG - 2022-11-20 04:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:21:45 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:51:45 --> Total execution time: 0.1219
DEBUG - 2022-11-20 04:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:21:56 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:51:57 --> Total execution time: 0.4678
DEBUG - 2022-11-20 04:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:52:45 --> Total execution time: 0.5398
DEBUG - 2022-11-20 04:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:52:45 --> Total execution time: 0.1775
DEBUG - 2022-11-20 04:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:52:48 --> Total execution time: 0.1803
DEBUG - 2022-11-20 04:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:22:58 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:52:58 --> Total execution time: 0.1097
DEBUG - 2022-11-20 04:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:53:10 --> Total execution time: 0.1858
DEBUG - 2022-11-20 04:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:53:14 --> Total execution time: 0.2547
DEBUG - 2022-11-20 04:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:55:16 --> Total execution time: 0.8579
DEBUG - 2022-11-20 04:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:55:23 --> Total execution time: 0.5015
DEBUG - 2022-11-20 04:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:55:25 --> Total execution time: 0.2480
DEBUG - 2022-11-20 04:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:55:38 --> Total execution time: 0.5470
DEBUG - 2022-11-20 04:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:55:57 --> Total execution time: 0.1743
DEBUG - 2022-11-20 04:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:25:59 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:55:59 --> Total execution time: 0.1145
DEBUG - 2022-11-20 04:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:56:06 --> Total execution time: 0.1827
DEBUG - 2022-11-20 04:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:56:14 --> Total execution time: 0.2164
DEBUG - 2022-11-20 04:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:56:25 --> Total execution time: 0.1966
DEBUG - 2022-11-20 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:56:27 --> Total execution time: 0.1701
DEBUG - 2022-11-20 04:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:26:32 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:56:32 --> Total execution time: 0.4579
DEBUG - 2022-11-20 04:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:56:45 --> Total execution time: 0.1985
DEBUG - 2022-11-20 04:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:56:51 --> Total execution time: 0.2136
DEBUG - 2022-11-20 04:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:57:07 --> Total execution time: 0.1893
DEBUG - 2022-11-20 04:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:27:13 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:57:13 --> Total execution time: 0.1090
DEBUG - 2022-11-20 04:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:57:32 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-20 04:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:57:33 --> Total execution time: 0.1899
DEBUG - 2022-11-20 04:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:57:45 --> Total execution time: 0.1990
DEBUG - 2022-11-20 04:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:58:01 --> Total execution time: 0.1860
DEBUG - 2022-11-20 04:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:28:29 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:58:29 --> Total execution time: 0.4593
DEBUG - 2022-11-20 04:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:58:34 --> Total execution time: 0.1801
DEBUG - 2022-11-20 04:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:58:39 --> Total execution time: 0.2010
DEBUG - 2022-11-20 04:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:58:42 --> Total execution time: 0.1895
DEBUG - 2022-11-20 04:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:58:50 --> Total execution time: 0.1908
DEBUG - 2022-11-20 04:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:59:11 --> Total execution time: 0.1862
DEBUG - 2022-11-20 04:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 04:29:18 --> 404 Page Not Found: Aspinal-trunk-bag-305047html/index
DEBUG - 2022-11-20 04:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:30:30 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:00:30 --> Total execution time: 0.1173
DEBUG - 2022-11-20 04:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:00:34 --> Total execution time: 0.1704
DEBUG - 2022-11-20 04:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:30:58 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:00:58 --> Total execution time: 0.1136
DEBUG - 2022-11-20 04:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:01:04 --> Total execution time: 0.1163
DEBUG - 2022-11-20 04:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:01:08 --> Total execution time: 0.1632
DEBUG - 2022-11-20 04:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:01:16 --> Total execution time: 0.2175
DEBUG - 2022-11-20 04:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 04:31:16 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 04:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:01:24 --> Total execution time: 0.2145
DEBUG - 2022-11-20 04:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:01:24 --> Total execution time: 0.2342
DEBUG - 2022-11-20 04:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:01:24 --> Total execution time: 0.2994
DEBUG - 2022-11-20 04:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:01:25 --> Total execution time: 0.3763
DEBUG - 2022-11-20 04:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:01:33 --> Total execution time: 0.1953
DEBUG - 2022-11-20 04:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:01:36 --> Total execution time: 0.1963
DEBUG - 2022-11-20 04:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:01:41 --> Total execution time: 0.1794
DEBUG - 2022-11-20 04:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:01:41 --> Total execution time: 0.1942
DEBUG - 2022-11-20 04:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:01:56 --> Total execution time: 0.2815
DEBUG - 2022-11-20 04:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:02:42 --> Total execution time: 0.1797
DEBUG - 2022-11-20 04:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:03:01 --> Total execution time: 0.2415
DEBUG - 2022-11-20 04:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:03:50 --> Total execution time: 0.4781
DEBUG - 2022-11-20 04:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:03:59 --> Total execution time: 0.1153
DEBUG - 2022-11-20 04:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:34:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:04:38 --> Total execution time: 0.1137
DEBUG - 2022-11-20 04:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 04:34:38 --> 404 Page Not Found: David-yurman-bracelet-moonstone-gold-7mm-297468html/index
DEBUG - 2022-11-20 04:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 04:34:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 04:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:37:05 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:07:06 --> Total execution time: 0.1912
DEBUG - 2022-11-20 04:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:41:44 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:11:45 --> Total execution time: 0.6263
DEBUG - 2022-11-20 04:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:46:35 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:16:36 --> Total execution time: 0.6206
DEBUG - 2022-11-20 04:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:16:48 --> Total execution time: 0.1907
DEBUG - 2022-11-20 04:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:17:15 --> Total execution time: 0.2036
DEBUG - 2022-11-20 04:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:17:23 --> Total execution time: 0.2370
DEBUG - 2022-11-20 04:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:17:43 --> Total execution time: 0.1966
DEBUG - 2022-11-20 04:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:17:53 --> Total execution time: 0.1877
DEBUG - 2022-11-20 04:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:47:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 04:47:55 --> 404 Page Not Found: Contact/index
DEBUG - 2022-11-20 04:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:48:00 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:18:00 --> Total execution time: 0.1208
DEBUG - 2022-11-20 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:19:21 --> Total execution time: 0.1099
DEBUG - 2022-11-20 04:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:19:41 --> Total execution time: 0.1748
DEBUG - 2022-11-20 04:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:49:50 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:19:50 --> Total execution time: 0.1740
DEBUG - 2022-11-20 04:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:20:13 --> Total execution time: 0.4711
DEBUG - 2022-11-20 04:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:20:23 --> Total execution time: 0.1824
DEBUG - 2022-11-20 04:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:50:29 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:20:29 --> Total execution time: 0.1793
DEBUG - 2022-11-20 04:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:22:23 --> Total execution time: 0.1681
DEBUG - 2022-11-20 04:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:52:46 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:22:47 --> Total execution time: 0.1340
DEBUG - 2022-11-20 04:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:22:51 --> Total execution time: 0.1088
DEBUG - 2022-11-20 04:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:23:10 --> Total execution time: 0.1690
DEBUG - 2022-11-20 04:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:23:20 --> Total execution time: 0.1708
DEBUG - 2022-11-20 04:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:23:31 --> Total execution time: 0.1918
DEBUG - 2022-11-20 04:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:23:40 --> Total execution time: 0.2220
DEBUG - 2022-11-20 04:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:23:42 --> Total execution time: 0.1815
DEBUG - 2022-11-20 04:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 04:53:46 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 04:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:23:59 --> Total execution time: 0.2044
DEBUG - 2022-11-20 04:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:24:02 --> Total execution time: 0.3527
DEBUG - 2022-11-20 04:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:24:09 --> Total execution time: 0.1777
DEBUG - 2022-11-20 04:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:24:11 --> Total execution time: 0.1849
DEBUG - 2022-11-20 04:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:24:13 --> Total execution time: 0.1661
DEBUG - 2022-11-20 04:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:24:29 --> Total execution time: 0.2194
DEBUG - 2022-11-20 04:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:24:34 --> Total execution time: 0.1886
DEBUG - 2022-11-20 04:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:24:38 --> Total execution time: 0.2490
DEBUG - 2022-11-20 04:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:25:17 --> Total execution time: 0.2641
DEBUG - 2022-11-20 04:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:55:21 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:25:22 --> Total execution time: 0.1299
DEBUG - 2022-11-20 04:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:25:30 --> Total execution time: 0.1106
DEBUG - 2022-11-20 04:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:25:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-20 04:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 16:25:38 --> Total execution time: 0.1997
DEBUG - 2022-11-20 04:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:25:38 --> Total execution time: 0.1766
DEBUG - 2022-11-20 04:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:25:43 --> Total execution time: 0.6093
DEBUG - 2022-11-20 04:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:25:47 --> Total execution time: 0.2037
DEBUG - 2022-11-20 04:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:55:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 04:55:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 04:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:25:55 --> Total execution time: 0.2134
DEBUG - 2022-11-20 04:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:25:57 --> Total execution time: 0.1788
DEBUG - 2022-11-20 04:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:58:04 --> No URI present. Default controller set.
DEBUG - 2022-11-20 04:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:28:04 --> Total execution time: 0.1173
DEBUG - 2022-11-20 04:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:58:13 --> Total execution time: 0.1760
DEBUG - 2022-11-20 04:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:58:15 --> Total execution time: 0.1996
DEBUG - 2022-11-20 04:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:58:15 --> Total execution time: 0.4223
DEBUG - 2022-11-20 04:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:58:16 --> Total execution time: 0.1815
DEBUG - 2022-11-20 04:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:58:16 --> Total execution time: 0.1800
DEBUG - 2022-11-20 04:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:58:17 --> Total execution time: 0.1697
DEBUG - 2022-11-20 04:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:58:18 --> Total execution time: 0.3658
DEBUG - 2022-11-20 04:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:59:31 --> Total execution time: 0.1681
DEBUG - 2022-11-20 04:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:59:45 --> Total execution time: 0.1795
DEBUG - 2022-11-20 04:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:59:51 --> Total execution time: 0.1670
DEBUG - 2022-11-20 04:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 04:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 04:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 04:59:56 --> Total execution time: 0.1742
DEBUG - 2022-11-20 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:30:02 --> Total execution time: 0.2177
DEBUG - 2022-11-20 05:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:37:04 --> Total execution time: 0.1937
DEBUG - 2022-11-20 05:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:40:06 --> Total execution time: 2.2285
DEBUG - 2022-11-20 05:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:40:11 --> Total execution time: 0.6684
DEBUG - 2022-11-20 05:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:10:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:40:40 --> Total execution time: 0.1125
DEBUG - 2022-11-20 05:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:13:46 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:43:46 --> Total execution time: 0.2581
DEBUG - 2022-11-20 05:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:14:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 05:14:18 --> 404 Page Not Found: Two-2-target-gumball-machine-decorative-jars-1004681html/index
DEBUG - 2022-11-20 05:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:45:25 --> Total execution time: 0.1088
DEBUG - 2022-11-20 05:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:15:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:45:40 --> Total execution time: 0.1806
DEBUG - 2022-11-20 05:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:46:40 --> Total execution time: 0.1756
DEBUG - 2022-11-20 05:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:46:40 --> Total execution time: 0.2001
DEBUG - 2022-11-20 05:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:46:50 --> Total execution time: 0.1875
DEBUG - 2022-11-20 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:46:57 --> Total execution time: 0.2320
DEBUG - 2022-11-20 05:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:21:10 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:51:11 --> Total execution time: 0.6458
DEBUG - 2022-11-20 05:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:21:12 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:51:12 --> Total execution time: 0.1146
DEBUG - 2022-11-20 05:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:21:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:51:37 --> Total execution time: 0.1781
DEBUG - 2022-11-20 05:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:22:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 05:22:38 --> 404 Page Not Found: Shark-ultracyclone-pro-cordless-handheld-vacuum-with-xl-dust-cup-green-1243410html/index
DEBUG - 2022-11-20 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 05:23:34 --> 404 Page Not Found: Nintendo-switch-console-268273html/index
DEBUG - 2022-11-20 05:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:24:23 --> Total execution time: 0.1174
DEBUG - 2022-11-20 05:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:24:27 --> Total execution time: 0.2261
DEBUG - 2022-11-20 05:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:24:28 --> Total execution time: 0.2269
DEBUG - 2022-11-20 05:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:56:50 --> Total execution time: 1.1742
DEBUG - 2022-11-20 05:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:56:50 --> Total execution time: 0.1756
DEBUG - 2022-11-20 05:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:57:11 --> Total execution time: 0.1969
DEBUG - 2022-11-20 05:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:57:15 --> Total execution time: 0.1124
DEBUG - 2022-11-20 05:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:57:22 --> Total execution time: 0.2118
DEBUG - 2022-11-20 05:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:57:26 --> Total execution time: 0.2988
DEBUG - 2022-11-20 05:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:57:40 --> Total execution time: 0.1738
DEBUG - 2022-11-20 05:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:27:49 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:57:49 --> Total execution time: 0.1205
DEBUG - 2022-11-20 05:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:27:53 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:57:54 --> Total execution time: 0.1700
DEBUG - 2022-11-20 05:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:28:02 --> Total execution time: 0.1824
DEBUG - 2022-11-20 05:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:28:04 --> Total execution time: 0.2301
DEBUG - 2022-11-20 05:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:28:04 --> Total execution time: 0.1775
DEBUG - 2022-11-20 05:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:09 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:58:09 --> Total execution time: 0.1109
DEBUG - 2022-11-20 05:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:58:22 --> Total execution time: 0.1124
DEBUG - 2022-11-20 05:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:58:29 --> Total execution time: 0.1825
DEBUG - 2022-11-20 05:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:28:31 --> Total execution time: 0.1735
DEBUG - 2022-11-20 05:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:28:33 --> Total execution time: 0.1795
DEBUG - 2022-11-20 05:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:28:33 --> Total execution time: 0.4269
DEBUG - 2022-11-20 05:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:28:36 --> Total execution time: 0.1745
DEBUG - 2022-11-20 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:58:38 --> Total execution time: 0.1080
DEBUG - 2022-11-20 05:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:44 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:58:45 --> Total execution time: 0.1091
DEBUG - 2022-11-20 05:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:58:57 --> Total execution time: 0.2073
DEBUG - 2022-11-20 05:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:59:02 --> Total execution time: 0.1979
DEBUG - 2022-11-20 05:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:59:33 --> Total execution time: 0.1790
DEBUG - 2022-11-20 05:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:30:52 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:00:52 --> Total execution time: 0.1166
DEBUG - 2022-11-20 05:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:00:59 --> Total execution time: 0.1079
DEBUG - 2022-11-20 05:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:01:25 --> Total execution time: 0.1725
DEBUG - 2022-11-20 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:02:16 --> Total execution time: 0.1761
DEBUG - 2022-11-20 05:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:02:29 --> Total execution time: 0.4935
DEBUG - 2022-11-20 05:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:02:29 --> Total execution time: 0.1836
DEBUG - 2022-11-20 05:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:02:30 --> Total execution time: 0.1817
DEBUG - 2022-11-20 05:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:02:34 --> Total execution time: 0.1875
DEBUG - 2022-11-20 05:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:02:34 --> Total execution time: 0.1767
DEBUG - 2022-11-20 05:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:02:35 --> Total execution time: 0.2137
DEBUG - 2022-11-20 05:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:02:35 --> Total execution time: 0.1827
DEBUG - 2022-11-20 05:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:02:36 --> Total execution time: 0.1757
DEBUG - 2022-11-20 05:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:02:36 --> Total execution time: 0.1889
DEBUG - 2022-11-20 05:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:02:37 --> Total execution time: 0.1824
DEBUG - 2022-11-20 05:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:41 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:02:41 --> Total execution time: 0.1080
DEBUG - 2022-11-20 05:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:02:42 --> Total execution time: 0.1783
DEBUG - 2022-11-20 05:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:02:58 --> Total execution time: 0.1794
DEBUG - 2022-11-20 05:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:03:07 --> Total execution time: 0.1979
DEBUG - 2022-11-20 05:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:03:28 --> Total execution time: 0.1727
DEBUG - 2022-11-20 05:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:03:39 --> Total execution time: 0.1804
DEBUG - 2022-11-20 05:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:03:50 --> Total execution time: 0.1913
DEBUG - 2022-11-20 05:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:04:07 --> Total execution time: 0.1968
DEBUG - 2022-11-20 05:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:34:11 --> Total execution time: 0.1770
DEBUG - 2022-11-20 05:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:34:17 --> Total execution time: 0.1722
DEBUG - 2022-11-20 05:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:34:32 --> Total execution time: 0.2342
DEBUG - 2022-11-20 05:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:34:33 --> Total execution time: 0.4550
DEBUG - 2022-11-20 05:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:04:33 --> Total execution time: 0.2743
DEBUG - 2022-11-20 05:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 05:34:44 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 05:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:35:03 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:05:03 --> Total execution time: 0.1114
DEBUG - 2022-11-20 05:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:35:08 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:05:08 --> Total execution time: 0.1756
DEBUG - 2022-11-20 05:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:05:26 --> Total execution time: 2.5200
DEBUG - 2022-11-20 05:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 05:35:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 05:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:35:44 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:05:44 --> Total execution time: 0.1822
DEBUG - 2022-11-20 05:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:05:49 --> Total execution time: 0.1856
DEBUG - 2022-11-20 05:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:36:02 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:06:02 --> Total execution time: 0.1897
DEBUG - 2022-11-20 05:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:06:09 --> Total execution time: 0.1692
DEBUG - 2022-11-20 05:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:36:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 05:36:26 --> 404 Page Not Found: Well-known/traffic-advice
DEBUG - 2022-11-20 05:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:36:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 05:36:26 --> 404 Page Not Found: Well-known/traffic-advice
DEBUG - 2022-11-20 05:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:36:33 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:06:33 --> Total execution time: 0.1826
DEBUG - 2022-11-20 05:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:06:37 --> Total execution time: 0.1981
DEBUG - 2022-11-20 05:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:36:45 --> Total execution time: 0.1959
DEBUG - 2022-11-20 05:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:36:46 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:06:46 --> Total execution time: 0.1173
DEBUG - 2022-11-20 05:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:06:46 --> Total execution time: 0.1999
DEBUG - 2022-11-20 05:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:36:48 --> Total execution time: 0.1775
DEBUG - 2022-11-20 05:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:36:48 --> Total execution time: 0.1756
DEBUG - 2022-11-20 05:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:06:54 --> Total execution time: 0.2016
DEBUG - 2022-11-20 05:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:07:01 --> Total execution time: 0.1723
DEBUG - 2022-11-20 05:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:07:25 --> Total execution time: 0.1784
DEBUG - 2022-11-20 05:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:07:29 --> Total execution time: 1.6178
DEBUG - 2022-11-20 05:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:07:31 --> Total execution time: 0.1850
DEBUG - 2022-11-20 05:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:37:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 05:37:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 05:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:08:09 --> Total execution time: 2.2839
DEBUG - 2022-11-20 05:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:08:25 --> Total execution time: 1.8874
DEBUG - 2022-11-20 05:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:38:27 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:08:27 --> Total execution time: 0.1788
DEBUG - 2022-11-20 05:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:38:33 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:08:33 --> Total execution time: 0.1708
DEBUG - 2022-11-20 05:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:09:03 --> Total execution time: 0.1924
DEBUG - 2022-11-20 05:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:09:43 --> Total execution time: 0.4585
DEBUG - 2022-11-20 05:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:09:43 --> Total execution time: 0.1779
DEBUG - 2022-11-20 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:10:14 --> Total execution time: 0.1843
DEBUG - 2022-11-20 05:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:40:28 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:10:28 --> Total execution time: 0.1086
DEBUG - 2022-11-20 05:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:40:32 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:10:32 --> Total execution time: 0.1238
DEBUG - 2022-11-20 05:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:10:49 --> Total execution time: 0.1767
DEBUG - 2022-11-20 05:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:42:28 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:12:28 --> Total execution time: 0.1257
DEBUG - 2022-11-20 05:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:12:33 --> Total execution time: 0.1076
DEBUG - 2022-11-20 05:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:12:39 --> Total execution time: 0.1685
DEBUG - 2022-11-20 05:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:12:46 --> Total execution time: 0.1740
DEBUG - 2022-11-20 05:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:43:20 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:13:21 --> Total execution time: 0.1213
DEBUG - 2022-11-20 05:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:43:42 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:13:42 --> Total execution time: 0.1840
DEBUG - 2022-11-20 05:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:13:47 --> Total execution time: 0.1045
DEBUG - 2022-11-20 05:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:13:54 --> Total execution time: 0.1714
DEBUG - 2022-11-20 05:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:44:15 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:14:15 --> Total execution time: 0.1625
DEBUG - 2022-11-20 05:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:14:22 --> Total execution time: 0.5044
DEBUG - 2022-11-20 05:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:14:22 --> Total execution time: 0.1793
DEBUG - 2022-11-20 05:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:14:23 --> Total execution time: 0.1796
DEBUG - 2022-11-20 05:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:14:35 --> Total execution time: 0.2062
DEBUG - 2022-11-20 05:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:14:43 --> Total execution time: 0.2004
DEBUG - 2022-11-20 05:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:15:14 --> Total execution time: 0.1796
DEBUG - 2022-11-20 05:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:15:18 --> Total execution time: 0.1914
DEBUG - 2022-11-20 05:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:15:19 --> Total execution time: 0.1769
DEBUG - 2022-11-20 05:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:15:26 --> Total execution time: 0.1821
DEBUG - 2022-11-20 05:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:15:30 --> Total execution time: 0.1798
DEBUG - 2022-11-20 05:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:15:37 --> Total execution time: 0.1710
DEBUG - 2022-11-20 05:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:45:47 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:15:48 --> Total execution time: 0.4802
DEBUG - 2022-11-20 05:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:15:48 --> Total execution time: 0.1723
DEBUG - 2022-11-20 05:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:16:02 --> Total execution time: 0.1721
DEBUG - 2022-11-20 05:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:16:22 --> Total execution time: 0.1994
DEBUG - 2022-11-20 05:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:47:25 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:17:25 --> Total execution time: 0.1101
DEBUG - 2022-11-20 05:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:49:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 05:49:31 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 05:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:20:50 --> Total execution time: 0.1760
DEBUG - 2022-11-20 05:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:50:56 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:20:56 --> Total execution time: 0.1343
DEBUG - 2022-11-20 05:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:21:01 --> Total execution time: 0.1082
DEBUG - 2022-11-20 05:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:21:29 --> Total execution time: 0.1726
DEBUG - 2022-11-20 05:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:51:56 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:21:56 --> Total execution time: 0.1216
DEBUG - 2022-11-20 05:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:22:01 --> Total execution time: 0.2007
DEBUG - 2022-11-20 05:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:22:06 --> Total execution time: 0.1083
DEBUG - 2022-11-20 05:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:22:13 --> Total execution time: 0.1826
DEBUG - 2022-11-20 05:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:22:37 --> Total execution time: 0.4866
DEBUG - 2022-11-20 05:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:22:38 --> Total execution time: 0.1815
DEBUG - 2022-11-20 05:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:22:41 --> Total execution time: 0.1963
DEBUG - 2022-11-20 05:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:22:46 --> Total execution time: 0.1751
DEBUG - 2022-11-20 05:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:22:48 --> Total execution time: 0.1745
DEBUG - 2022-11-20 05:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:22:59 --> Total execution time: 0.1698
DEBUG - 2022-11-20 05:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:23:08 --> Total execution time: 0.2153
DEBUG - 2022-11-20 05:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:23:20 --> Total execution time: 0.1936
DEBUG - 2022-11-20 05:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:23:24 --> Total execution time: 0.1751
DEBUG - 2022-11-20 05:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:53:27 --> No URI present. Default controller set.
DEBUG - 2022-11-20 05:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:23:27 --> Total execution time: 0.1920
DEBUG - 2022-11-20 05:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:26:57 --> Total execution time: 0.1845
DEBUG - 2022-11-20 05:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:27:53 --> Total execution time: 0.1717
DEBUG - 2022-11-20 05:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:28:01 --> Total execution time: 0.1895
DEBUG - 2022-11-20 05:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:28:10 --> Total execution time: 0.1802
DEBUG - 2022-11-20 05:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:28:11 --> Total execution time: 0.1771
DEBUG - 2022-11-20 05:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:28:17 --> Total execution time: 0.1856
DEBUG - 2022-11-20 05:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:28:21 --> Total execution time: 0.1817
DEBUG - 2022-11-20 05:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:28:29 --> Total execution time: 0.1728
DEBUG - 2022-11-20 05:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 05:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:28:43 --> Total execution time: 0.4776
DEBUG - 2022-11-20 05:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 05:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:28:43 --> Total execution time: 0.1797
DEBUG - 2022-11-20 05:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 05:59:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 05:59:18 --> 404 Page Not Found: Frozen-frozen-2-anna-deluxe-child-costume-1388868html/index
DEBUG - 2022-11-20 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:30:02 --> Total execution time: 0.1787
DEBUG - 2022-11-20 06:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:04:06 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:34:06 --> Total execution time: 0.2149
DEBUG - 2022-11-20 06:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:34:28 --> Total execution time: 0.1265
DEBUG - 2022-11-20 06:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:04:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:34:38 --> Total execution time: 0.1209
DEBUG - 2022-11-20 06:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 06:04:38 --> 404 Page Not Found: Sharper-image-ultrasonic-wave-jewelery-cleaner-930313html/index
DEBUG - 2022-11-20 06:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:04:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 06:04:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 06:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:35:42 --> Total execution time: 0.1242
DEBUG - 2022-11-20 06:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:35:46 --> Total execution time: 0.1709
DEBUG - 2022-11-20 06:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:35:53 --> Total execution time: 0.2245
DEBUG - 2022-11-20 06:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:35:59 --> Total execution time: 0.1842
DEBUG - 2022-11-20 06:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:36:06 --> Total execution time: 0.1763
DEBUG - 2022-11-20 06:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:20 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:36:20 --> Total execution time: 0.1846
DEBUG - 2022-11-20 06:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:06:37 --> Total execution time: 0.1724
DEBUG - 2022-11-20 06:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:36:41 --> Total execution time: 0.1811
DEBUG - 2022-11-20 06:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:36:42 --> Total execution time: 0.1811
DEBUG - 2022-11-20 06:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:36:46 --> Total execution time: 0.2035
DEBUG - 2022-11-20 06:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:36:47 --> Total execution time: 0.1857
DEBUG - 2022-11-20 06:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:36:47 --> Total execution time: 0.1806
DEBUG - 2022-11-20 06:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:36:47 --> Total execution time: 0.1829
DEBUG - 2022-11-20 06:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:06:48 --> Total execution time: 0.1788
DEBUG - 2022-11-20 06:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:06:48 --> Total execution time: 0.3102
DEBUG - 2022-11-20 06:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:36:49 --> Total execution time: 0.1804
DEBUG - 2022-11-20 06:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:36:52 --> Total execution time: 0.1774
DEBUG - 2022-11-20 06:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:07:02 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:37:02 --> Total execution time: 0.1951
DEBUG - 2022-11-20 06:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:37:02 --> Total execution time: 0.1695
DEBUG - 2022-11-20 06:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:37:05 --> Total execution time: 0.2454
DEBUG - 2022-11-20 06:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:37:59 --> Total execution time: 0.1866
DEBUG - 2022-11-20 06:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:38:02 --> Total execution time: 0.1778
DEBUG - 2022-11-20 06:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:38:19 --> Total execution time: 0.1767
DEBUG - 2022-11-20 06:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 06:08:39 --> 404 Page Not Found: Cuisinart-pasta-maker-attachment-dlc054-accessories-for-dlc7-food-processor-538987html/index
DEBUG - 2022-11-20 06:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:08:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:38:39 --> Total execution time: 0.1218
DEBUG - 2022-11-20 06:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:08:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 06:08:40 --> 404 Page Not Found: Tahoe-bed-usb-turbo-charger-afi-1264303html/index
DEBUG - 2022-11-20 06:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:08:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 06:08:40 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 06:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:08:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:38:40 --> Total execution time: 0.1269
DEBUG - 2022-11-20 06:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:08:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 06:08:40 --> 404 Page Not Found: Pre-owned-precious-inspirations-bead-box-by-the-beadery-1169937html/index
DEBUG - 2022-11-20 06:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:08:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:08:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:38:40 --> Total execution time: 0.1108
DEBUG - 2022-11-20 06:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 17:38:40 --> Total execution time: 0.2671
DEBUG - 2022-11-20 06:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:38:40 --> Total execution time: 0.1347
DEBUG - 2022-11-20 06:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:38:40 --> Total execution time: 0.2621
DEBUG - 2022-11-20 06:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:38:42 --> Total execution time: 0.1789
DEBUG - 2022-11-20 06:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:08:59 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:38:59 --> Total execution time: 0.1131
DEBUG - 2022-11-20 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:12:29 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:42:29 --> Total execution time: 0.5973
DEBUG - 2022-11-20 06:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:42:30 --> Total execution time: 0.7751
DEBUG - 2022-11-20 06:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:12:30 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:42:31 --> Total execution time: 0.1085
DEBUG - 2022-11-20 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:42:34 --> Total execution time: 0.1796
DEBUG - 2022-11-20 06:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:43:47 --> Total execution time: 0.1729
DEBUG - 2022-11-20 06:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:14:01 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:44:01 --> Total execution time: 0.1767
DEBUG - 2022-11-20 06:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:14:22 --> Total execution time: 0.1103
DEBUG - 2022-11-20 06:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:14:24 --> Total execution time: 0.1883
DEBUG - 2022-11-20 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:14:25 --> Total execution time: 0.1764
DEBUG - 2022-11-20 06:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:44:28 --> Total execution time: 0.1760
DEBUG - 2022-11-20 06:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:44:34 --> Total execution time: 0.1836
DEBUG - 2022-11-20 06:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:44:35 --> Total execution time: 0.1701
DEBUG - 2022-11-20 06:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:44:36 --> Total execution time: 0.1811
DEBUG - 2022-11-20 06:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:14:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:44:39 --> Total execution time: 0.1852
DEBUG - 2022-11-20 06:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:47:50 --> Total execution time: 0.2111
DEBUG - 2022-11-20 06:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:18:14 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:48:14 --> Total execution time: 0.1202
DEBUG - 2022-11-20 06:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:48:21 --> Total execution time: 0.1139
DEBUG - 2022-11-20 06:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:48:29 --> Total execution time: 0.1997
DEBUG - 2022-11-20 06:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:48:36 --> Total execution time: 0.1987
DEBUG - 2022-11-20 06:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:48:39 --> Total execution time: 0.1783
DEBUG - 2022-11-20 06:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:48:42 --> Total execution time: 0.2321
DEBUG - 2022-11-20 06:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:48:54 --> Total execution time: 0.1767
DEBUG - 2022-11-20 06:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:23:46 --> Total execution time: 0.1704
DEBUG - 2022-11-20 06:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:53:50 --> Total execution time: 0.1812
DEBUG - 2022-11-20 06:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:53:59 --> Total execution time: 0.2308
DEBUG - 2022-11-20 06:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:54:01 --> Total execution time: 0.2321
DEBUG - 2022-11-20 06:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:54:05 --> Total execution time: 0.2465
DEBUG - 2022-11-20 06:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:54:09 --> Total execution time: 0.2276
DEBUG - 2022-11-20 06:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:54:22 --> Total execution time: 0.4368
DEBUG - 2022-11-20 06:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:54:23 --> Total execution time: 0.1809
DEBUG - 2022-11-20 06:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:54:27 --> Total execution time: 0.2296
DEBUG - 2022-11-20 06:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:54:34 --> Total execution time: 0.1849
DEBUG - 2022-11-20 06:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:54:44 --> Total execution time: 0.1728
DEBUG - 2022-11-20 06:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:55:00 --> Total execution time: 0.1772
DEBUG - 2022-11-20 06:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:55:46 --> Total execution time: 0.3111
DEBUG - 2022-11-20 06:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:57:19 --> Total execution time: 0.4677
DEBUG - 2022-11-20 06:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:57:32 --> Total execution time: 0.1174
DEBUG - 2022-11-20 06:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:57:38 --> Total execution time: 0.1898
DEBUG - 2022-11-20 06:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:57:43 --> Total execution time: 0.2301
DEBUG - 2022-11-20 06:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:58:13 --> Total execution time: 0.1098
DEBUG - 2022-11-20 06:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:58:23 --> Total execution time: 0.1729
DEBUG - 2022-11-20 06:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:58:23 --> Total execution time: 0.1085
DEBUG - 2022-11-20 06:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:59:00 --> Total execution time: 0.1722
DEBUG - 2022-11-20 06:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:29:01 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:59:01 --> Total execution time: 0.1880
DEBUG - 2022-11-20 06:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:59:02 --> Total execution time: 0.1746
DEBUG - 2022-11-20 06:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:00:01 --> Total execution time: 0.2557
DEBUG - 2022-11-20 06:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:00:02 --> Total execution time: 0.2876
DEBUG - 2022-11-20 06:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:00:22 --> Total execution time: 0.1989
DEBUG - 2022-11-20 06:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:00:33 --> Total execution time: 0.1881
DEBUG - 2022-11-20 06:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:31:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 06:31:09 --> 404 Page Not Found: Freddy-funko-as-thor-metallic-1287036html/index
DEBUG - 2022-11-20 06:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:31:09 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:01:09 --> Total execution time: 0.1160
DEBUG - 2022-11-20 06:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:04:40 --> Total execution time: 0.1980
DEBUG - 2022-11-20 06:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:37:26 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:07:30 --> Total execution time: 3.7491
DEBUG - 2022-11-20 06:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:37:44 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:07:46 --> Total execution time: 2.3336
DEBUG - 2022-11-20 06:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:07:50 --> Total execution time: 0.1902
DEBUG - 2022-11-20 06:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:07:57 --> Total execution time: 0.3742
DEBUG - 2022-11-20 06:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:08:07 --> Total execution time: 0.3082
DEBUG - 2022-11-20 06:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:08:15 --> Total execution time: 0.1872
DEBUG - 2022-11-20 06:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:08:15 --> Total execution time: 0.1950
DEBUG - 2022-11-20 06:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:08:18 --> Total execution time: 0.1808
DEBUG - 2022-11-20 06:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:08:22 --> Total execution time: 0.9206
DEBUG - 2022-11-20 06:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:09:07 --> Total execution time: 0.5531
DEBUG - 2022-11-20 06:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:09:51 --> Total execution time: 0.1926
DEBUG - 2022-11-20 06:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:42:19 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:12:20 --> Total execution time: 0.7016
DEBUG - 2022-11-20 06:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:12:26 --> Total execution time: 0.1105
DEBUG - 2022-11-20 06:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:12:29 --> Total execution time: 0.1790
DEBUG - 2022-11-20 06:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:12:29 --> Total execution time: 0.1803
DEBUG - 2022-11-20 06:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:12:37 --> Total execution time: 0.2128
DEBUG - 2022-11-20 06:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:12:48 --> Total execution time: 0.2500
DEBUG - 2022-11-20 06:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:04 --> Total execution time: 0.1915
DEBUG - 2022-11-20 06:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:16 --> Total execution time: 0.2131
DEBUG - 2022-11-20 06:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:17 --> Total execution time: 0.1818
DEBUG - 2022-11-20 06:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:27 --> Total execution time: 0.1897
DEBUG - 2022-11-20 06:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:31 --> Total execution time: 0.1191
DEBUG - 2022-11-20 06:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:32 --> Total execution time: 0.1712
DEBUG - 2022-11-20 06:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:39 --> Total execution time: 0.1726
DEBUG - 2022-11-20 06:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:41 --> Total execution time: 0.1720
DEBUG - 2022-11-20 06:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:48 --> Total execution time: 0.1822
DEBUG - 2022-11-20 06:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:53 --> Total execution time: 0.1850
DEBUG - 2022-11-20 06:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:14:01 --> Total execution time: 0.1762
DEBUG - 2022-11-20 06:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:44:23 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:14:24 --> Total execution time: 0.7189
DEBUG - 2022-11-20 06:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:14:31 --> Total execution time: 0.2073
DEBUG - 2022-11-20 06:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:14:37 --> Total execution time: 0.1813
DEBUG - 2022-11-20 06:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:14:40 --> Total execution time: 0.2957
DEBUG - 2022-11-20 06:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:14:44 --> Total execution time: 0.3067
DEBUG - 2022-11-20 06:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:14:46 --> Total execution time: 0.1982
DEBUG - 2022-11-20 06:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:14:50 --> Total execution time: 0.2252
DEBUG - 2022-11-20 06:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:14:53 --> Total execution time: 0.1882
DEBUG - 2022-11-20 06:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:14:57 --> Total execution time: 0.1982
DEBUG - 2022-11-20 06:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:45:03 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:15:03 --> Total execution time: 0.1198
DEBUG - 2022-11-20 06:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:45:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:15:41 --> Total execution time: 3.0359
DEBUG - 2022-11-20 06:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:45:56 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:15:59 --> Total execution time: 3.2524
DEBUG - 2022-11-20 06:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:16:04 --> Total execution time: 0.1073
DEBUG - 2022-11-20 06:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:16:11 --> Total execution time: 0.2223
DEBUG - 2022-11-20 06:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:16:33 --> Total execution time: 0.2187
DEBUG - 2022-11-20 06:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:16:36 --> Total execution time: 0.1757
DEBUG - 2022-11-20 06:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:16:41 --> Total execution time: 0.2087
DEBUG - 2022-11-20 06:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:47:05 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:17:05 --> Total execution time: 0.1145
DEBUG - 2022-11-20 06:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:47:57 --> Total execution time: 0.7926
DEBUG - 2022-11-20 06:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:48:00 --> Total execution time: 0.3430
DEBUG - 2022-11-20 06:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:48:00 --> Total execution time: 0.2274
DEBUG - 2022-11-20 06:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:18:42 --> Total execution time: 0.1081
DEBUG - 2022-11-20 06:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:18:47 --> Total execution time: 2.7354
DEBUG - 2022-11-20 06:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:19:49 --> Total execution time: 0.2254
DEBUG - 2022-11-20 06:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:20:45 --> Total execution time: 0.1995
DEBUG - 2022-11-20 06:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:20:59 --> Total execution time: 0.1844
DEBUG - 2022-11-20 06:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:51:25 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:21:25 --> Total execution time: 0.1082
DEBUG - 2022-11-20 06:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:22:52 --> Total execution time: 0.4677
DEBUG - 2022-11-20 06:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:22:53 --> Total execution time: 0.1811
DEBUG - 2022-11-20 06:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:22:54 --> Total execution time: 0.1788
DEBUG - 2022-11-20 06:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 06:53:34 --> 404 Page Not Found: The-worthy-dog-plaid-bow-tie-adjustable-collar-attachment-accessory-615784html/index
DEBUG - 2022-11-20 06:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:53:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:23:39 --> Total execution time: 0.1165
DEBUG - 2022-11-20 06:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:53:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 06:53:39 --> 404 Page Not Found: Hair-wraps-790508html/index
DEBUG - 2022-11-20 06:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:53:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 06:53:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 06:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:53:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:23:39 --> Total execution time: 0.1157
DEBUG - 2022-11-20 06:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:53:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 06:53:39 --> 404 Page Not Found: Garmin-forerunner-945-47-mm-smartwatch-160945html/index
DEBUG - 2022-11-20 06:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:53:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:23:40 --> Total execution time: 0.1178
DEBUG - 2022-11-20 06:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:53:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 06:53:40 --> 404 Page Not Found: Goodle-home-speaker-1108510html/index
DEBUG - 2022-11-20 06:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:23:41 --> Total execution time: 0.1939
DEBUG - 2022-11-20 06:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:53:58 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:23:58 --> Total execution time: 0.1106
DEBUG - 2022-11-20 06:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:24:05 --> Total execution time: 0.1137
DEBUG - 2022-11-20 06:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:25:23 --> Total execution time: 0.1115
DEBUG - 2022-11-20 06:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:25:26 --> Total execution time: 0.1775
DEBUG - 2022-11-20 06:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:26:20 --> Total execution time: 0.2251
DEBUG - 2022-11-20 06:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:26:27 --> Total execution time: 0.1961
DEBUG - 2022-11-20 06:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:26:32 --> Total execution time: 0.1781
DEBUG - 2022-11-20 06:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:26:40 --> Total execution time: 0.2206
DEBUG - 2022-11-20 06:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:27:08 --> Total execution time: 0.1830
DEBUG - 2022-11-20 06:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:27:10 --> Total execution time: 0.1867
DEBUG - 2022-11-20 06:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:57:17 --> No URI present. Default controller set.
DEBUG - 2022-11-20 06:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:27:17 --> Total execution time: 0.1923
DEBUG - 2022-11-20 06:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:28:07 --> Total execution time: 0.4217
DEBUG - 2022-11-20 06:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 06:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:28:08 --> Total execution time: 0.1780
DEBUG - 2022-11-20 06:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:28:28 --> Total execution time: 0.2276
DEBUG - 2022-11-20 06:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:28:29 --> Total execution time: 0.2319
DEBUG - 2022-11-20 06:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:28:29 --> Total execution time: 0.2542
DEBUG - 2022-11-20 06:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:28:35 --> Total execution time: 0.1742
DEBUG - 2022-11-20 06:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:29:04 --> Total execution time: 0.1831
DEBUG - 2022-11-20 06:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 06:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 06:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:29:04 --> Total execution time: 0.1733
DEBUG - 2022-11-20 07:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:30:02 --> Total execution time: 0.1329
DEBUG - 2022-11-20 07:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:04:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:04:45 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 07:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:06:30 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:36:31 --> Total execution time: 0.5349
DEBUG - 2022-11-20 07:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:08:31 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:38:31 --> Total execution time: 0.5867
DEBUG - 2022-11-20 07:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:09:55 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:39:56 --> Total execution time: 0.5853
DEBUG - 2022-11-20 07:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:40:21 --> Total execution time: 2.4285
DEBUG - 2022-11-20 07:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:40:27 --> Total execution time: 0.1088
DEBUG - 2022-11-20 07:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:43:00 --> Total execution time: 0.6139
DEBUG - 2022-11-20 07:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:13:36 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:43:36 --> Total execution time: 0.1171
DEBUG - 2022-11-20 07:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:13:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:43:37 --> Total execution time: 0.1805
DEBUG - 2022-11-20 07:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:43:39 --> Total execution time: 0.1872
DEBUG - 2022-11-20 07:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:43:42 --> Total execution time: 0.3527
DEBUG - 2022-11-20 07:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:43:44 --> Total execution time: 0.1212
DEBUG - 2022-11-20 07:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:43:57 --> Total execution time: 0.2071
DEBUG - 2022-11-20 07:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:44:20 --> Total execution time: 0.1857
DEBUG - 2022-11-20 07:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:44:28 --> Total execution time: 0.2208
DEBUG - 2022-11-20 07:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:45:05 --> Total execution time: 0.4735
DEBUG - 2022-11-20 07:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:45:24 --> Total execution time: 0.1767
DEBUG - 2022-11-20 07:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:16:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:16:09 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 07:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:46:09 --> Total execution time: 0.1883
DEBUG - 2022-11-20 07:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:16:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:16:09 --> 404 Page Not Found: Cabana-cbn660-power-loomed-rug-safavieh-963083html/index
DEBUG - 2022-11-20 07:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:46:16 --> Total execution time: 0.1709
DEBUG - 2022-11-20 07:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:46:33 --> Total execution time: 0.8247
DEBUG - 2022-11-20 07:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:46:44 --> Total execution time: 0.5130
DEBUG - 2022-11-20 07:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:18:52 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:48:53 --> Total execution time: 0.8414
DEBUG - 2022-11-20 07:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:20:47 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:50:47 --> Total execution time: 0.6744
DEBUG - 2022-11-20 07:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:21:19 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:51:19 --> Total execution time: 0.1125
DEBUG - 2022-11-20 07:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:03 --> Total execution time: 0.5538
DEBUG - 2022-11-20 07:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:07 --> Total execution time: 0.1206
DEBUG - 2022-11-20 07:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:24:41 --> Total execution time: 0.4574
DEBUG - 2022-11-20 07:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:24:43 --> Total execution time: 0.2277
DEBUG - 2022-11-20 07:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:24:43 --> Total execution time: 0.1739
DEBUG - 2022-11-20 07:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:45 --> Total execution time: 0.1773
DEBUG - 2022-11-20 07:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:25:00 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:55:00 --> Total execution time: 0.4997
DEBUG - 2022-11-20 07:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:55:00 --> Total execution time: 0.1388
DEBUG - 2022-11-20 07:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:25:07 --> Total execution time: 0.1380
DEBUG - 2022-11-20 07:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:25:17 --> Total execution time: 0.1754
DEBUG - 2022-11-20 07:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:25:19 --> Total execution time: 0.1961
DEBUG - 2022-11-20 07:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:25:19 --> Total execution time: 0.1796
DEBUG - 2022-11-20 07:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:55:41 --> Total execution time: 0.1849
DEBUG - 2022-11-20 07:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:55:48 --> Total execution time: 0.2400
DEBUG - 2022-11-20 07:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:55:49 --> Total execution time: 0.1810
DEBUG - 2022-11-20 07:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:55:57 --> Total execution time: 0.1737
DEBUG - 2022-11-20 07:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:56:02 --> Total execution time: 0.2667
DEBUG - 2022-11-20 07:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:56:13 --> Total execution time: 0.2206
DEBUG - 2022-11-20 07:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:57:57 --> Total execution time: 0.1866
DEBUG - 2022-11-20 07:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:57:59 --> Total execution time: 0.1990
DEBUG - 2022-11-20 07:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:29:18 --> 404 Page Not Found: Epson-252-single-2pk-3pk-4pk-ink-cartridges-black-multicolor-444697html/index
DEBUG - 2022-11-20 07:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:29:27 --> 404 Page Not Found: Walt-disney-world-664844html/index
DEBUG - 2022-11-20 07:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:59:35 --> Total execution time: 0.1129
DEBUG - 2022-11-20 07:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:59:55 --> Total execution time: 0.1827
DEBUG - 2022-11-20 07:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:00:09 --> Total execution time: 0.4834
DEBUG - 2022-11-20 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:00:10 --> Total execution time: 0.1850
DEBUG - 2022-11-20 07:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:30:14 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:00:15 --> Total execution time: 0.4613
DEBUG - 2022-11-20 07:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:00:22 --> Total execution time: 0.1671
DEBUG - 2022-11-20 07:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:00:43 --> Total execution time: 0.1757
DEBUG - 2022-11-20 07:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:00:53 --> Total execution time: 0.2083
DEBUG - 2022-11-20 07:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:01:03 --> Total execution time: 0.1854
DEBUG - 2022-11-20 07:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:01:11 --> Total execution time: 0.2125
DEBUG - 2022-11-20 07:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:01:24 --> Total execution time: 0.1856
DEBUG - 2022-11-20 07:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:01:55 --> Total execution time: 0.2205
DEBUG - 2022-11-20 07:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:02:02 --> Total execution time: 0.3188
DEBUG - 2022-11-20 07:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:02:07 --> Total execution time: 0.1906
DEBUG - 2022-11-20 07:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:02:15 --> Total execution time: 0.1970
DEBUG - 2022-11-20 07:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:02:18 --> Total execution time: 0.1769
DEBUG - 2022-11-20 07:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:02:21 --> Total execution time: 0.1757
DEBUG - 2022-11-20 07:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:21 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:02:21 --> Total execution time: 0.1248
DEBUG - 2022-11-20 07:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:22 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:02:22 --> Total execution time: 0.1153
DEBUG - 2022-11-20 07:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:02:28 --> Total execution time: 0.1302
DEBUG - 2022-11-20 07:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:02:31 --> Total execution time: 0.1932
DEBUG - 2022-11-20 07:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:45 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:02:45 --> Total execution time: 0.1201
DEBUG - 2022-11-20 07:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:32:52 --> Total execution time: 0.1761
DEBUG - 2022-11-20 07:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:32:54 --> Total execution time: 0.1713
DEBUG - 2022-11-20 07:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:02:55 --> Total execution time: 0.1755
DEBUG - 2022-11-20 07:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:02:55 --> Total execution time: 0.1802
DEBUG - 2022-11-20 07:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:32:57 --> Total execution time: 0.1747
DEBUG - 2022-11-20 07:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:32:57 --> Total execution time: 0.1765
DEBUG - 2022-11-20 07:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:03:00 --> Total execution time: 0.2653
DEBUG - 2022-11-20 07:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:33:03 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:03:04 --> Total execution time: 0.1749
DEBUG - 2022-11-20 07:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:03:05 --> Total execution time: 0.2024
DEBUG - 2022-11-20 07:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:33:17 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:03:17 --> Total execution time: 0.1099
DEBUG - 2022-11-20 07:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:03:22 --> Total execution time: 0.2216
DEBUG - 2022-11-20 07:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:03:24 --> Total execution time: 0.1824
DEBUG - 2022-11-20 07:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:03:27 --> Total execution time: 0.1823
DEBUG - 2022-11-20 07:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:03:29 --> Total execution time: 0.1867
DEBUG - 2022-11-20 07:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:03:31 --> Total execution time: 0.2228
DEBUG - 2022-11-20 07:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:03:32 --> Total execution time: 0.2091
DEBUG - 2022-11-20 07:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:04:30 --> Total execution time: 0.5919
DEBUG - 2022-11-20 07:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:04:32 --> Total execution time: 0.1703
DEBUG - 2022-11-20 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:04:35 --> Total execution time: 0.1715
DEBUG - 2022-11-20 07:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:34:38 --> 404 Page Not Found: Pokemon-v-bundle-1044548html/index
DEBUG - 2022-11-20 07:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:34:38 --> 404 Page Not Found: Mizuno-mp25-mp-25-irons-iron-set-5pw-kbs-stiff-flex-rh-1314889html/index
DEBUG - 2022-11-20 07:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:34:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 07:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:04:54 --> Total execution time: 0.2164
DEBUG - 2022-11-20 07:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:04:56 --> Total execution time: 0.1711
DEBUG - 2022-11-20 07:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:05:14 --> Total execution time: 0.1770
DEBUG - 2022-11-20 07:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:05:17 --> Total execution time: 0.2095
DEBUG - 2022-11-20 07:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:05:17 --> Total execution time: 0.1704
DEBUG - 2022-11-20 07:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:05:18 --> Total execution time: 0.1695
DEBUG - 2022-11-20 07:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:05:18 --> Total execution time: 0.2597
DEBUG - 2022-11-20 07:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:05:22 --> Total execution time: 0.2139
DEBUG - 2022-11-20 07:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:05:24 --> Total execution time: 0.1916
DEBUG - 2022-11-20 07:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:05:25 --> Total execution time: 0.2253
DEBUG - 2022-11-20 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:35:51 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:05:51 --> Total execution time: 0.1761
DEBUG - 2022-11-20 07:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:35:59 --> Total execution time: 0.1869
DEBUG - 2022-11-20 07:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:36:01 --> Total execution time: 0.2081
DEBUG - 2022-11-20 07:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:36:02 --> Total execution time: 0.2273
DEBUG - 2022-11-20 07:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:06:08 --> Total execution time: 0.4920
DEBUG - 2022-11-20 07:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:06:56 --> Total execution time: 0.4628
DEBUG - 2022-11-20 07:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:07:02 --> Total execution time: 0.1825
DEBUG - 2022-11-20 07:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:07:06 --> Total execution time: 0.2227
DEBUG - 2022-11-20 07:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:07:27 --> Total execution time: 0.1924
DEBUG - 2022-11-20 07:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:07:31 --> Total execution time: 0.2433
DEBUG - 2022-11-20 07:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:07:34 --> Total execution time: 0.2135
DEBUG - 2022-11-20 07:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:07:41 --> Total execution time: 0.1725
DEBUG - 2022-11-20 07:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:08:01 --> Total execution time: 2.1938
DEBUG - 2022-11-20 07:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:38:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:38:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 07:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:08:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-20 07:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:38:39 --> 404 Page Not Found: Hu-nmd-animal-print-adidas-1130834html/index
DEBUG - 2022-11-20 07:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:38:39 --> 404 Page Not Found: Minnie-mouse-heels-991123html/index
DEBUG - 2022-11-20 07:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:38:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:08:40 --> Total execution time: 0.1045
DEBUG - 2022-11-20 07:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:38:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:38:40 --> 404 Page Not Found: Nintendo-switch-oled-white-594917html/index
DEBUG - 2022-11-20 07:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:38:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:38:40 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 07:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:38:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:38:40 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 07:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:38:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:08:40 --> Total execution time: 0.1027
DEBUG - 2022-11-20 07:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:08:45 --> Total execution time: 0.2077
DEBUG - 2022-11-20 07:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:08:47 --> Total execution time: 0.3702
DEBUG - 2022-11-20 07:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:08:56 --> Total execution time: 0.1674
DEBUG - 2022-11-20 07:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:09:00 --> Total execution time: 0.1766
DEBUG - 2022-11-20 07:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:09:02 --> Total execution time: 0.1877
DEBUG - 2022-11-20 07:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:09:06 --> Total execution time: 0.2046
DEBUG - 2022-11-20 07:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:39:30 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:09:31 --> Total execution time: 0.2673
DEBUG - 2022-11-20 07:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:09:32 --> Total execution time: 0.2970
DEBUG - 2022-11-20 07:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:39:33 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:09:33 --> Total execution time: 0.2265
DEBUG - 2022-11-20 07:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:09:34 --> Total execution time: 0.2709
DEBUG - 2022-11-20 07:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:09:38 --> Total execution time: 0.2105
DEBUG - 2022-11-20 07:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:09:40 --> Total execution time: 0.1888
DEBUG - 2022-11-20 07:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:09:52 --> Total execution time: 0.1821
DEBUG - 2022-11-20 07:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:09:53 --> Total execution time: 0.2012
DEBUG - 2022-11-20 07:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:10:03 --> Total execution time: 0.1819
DEBUG - 2022-11-20 07:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:10:14 --> Total execution time: 0.1822
DEBUG - 2022-11-20 07:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:40:14 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:10:14 --> Total execution time: 0.1196
DEBUG - 2022-11-20 07:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:10:15 --> Total execution time: 0.2128
DEBUG - 2022-11-20 07:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:40:55 --> Total execution time: 0.1882
DEBUG - 2022-11-20 07:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:41:14 --> Total execution time: 0.1910
DEBUG - 2022-11-20 07:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:41:15 --> Total execution time: 0.4052
DEBUG - 2022-11-20 07:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:13:21 --> Total execution time: 0.1896
DEBUG - 2022-11-20 07:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:14:31 --> Total execution time: 0.1995
DEBUG - 2022-11-20 07:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:14:41 --> Total execution time: 0.2057
DEBUG - 2022-11-20 07:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:14:50 --> Total execution time: 0.2865
DEBUG - 2022-11-20 07:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:15:02 --> Total execution time: 1.9955
DEBUG - 2022-11-20 07:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:45:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 07:45:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 07:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:15:41 --> Total execution time: 0.2134
DEBUG - 2022-11-20 07:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:46:41 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:16:41 --> Total execution time: 0.2023
DEBUG - 2022-11-20 07:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:19:52 --> Total execution time: 0.1789
DEBUG - 2022-11-20 07:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:20:16 --> Total execution time: 0.4762
DEBUG - 2022-11-20 07:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:52:34 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:22:34 --> Total execution time: 0.2141
DEBUG - 2022-11-20 07:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 07:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:24:58 --> Total execution time: 0.1921
DEBUG - 2022-11-20 07:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:25:07 --> Total execution time: 0.2164
DEBUG - 2022-11-20 07:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:25:17 --> Total execution time: 0.1808
DEBUG - 2022-11-20 07:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:25:30 --> Total execution time: 0.1740
DEBUG - 2022-11-20 07:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:27:51 --> Total execution time: 0.3155
DEBUG - 2022-11-20 07:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:27:52 --> Total execution time: 0.2427
DEBUG - 2022-11-20 07:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:27:53 --> Total execution time: 0.2615
DEBUG - 2022-11-20 07:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:27:54 --> Total execution time: 0.2498
DEBUG - 2022-11-20 07:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:58:35 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:28:35 --> Total execution time: 0.1361
DEBUG - 2022-11-20 07:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 07:59:54 --> No URI present. Default controller set.
DEBUG - 2022-11-20 07:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 07:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:29:54 --> Total execution time: 0.1217
DEBUG - 2022-11-20 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:30:02 --> Total execution time: 0.2137
DEBUG - 2022-11-20 08:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:30:31 --> Total execution time: 0.1772
DEBUG - 2022-11-20 08:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:00:34 --> Total execution time: 0.1758
DEBUG - 2022-11-20 08:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:00:36 --> Total execution time: 0.2255
DEBUG - 2022-11-20 08:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:00:36 --> Total execution time: 0.2223
DEBUG - 2022-11-20 08:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:30:39 --> Total execution time: 0.1785
DEBUG - 2022-11-20 08:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:30:43 --> Total execution time: 0.1743
DEBUG - 2022-11-20 08:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:00:43 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:30:43 --> Total execution time: 0.1914
DEBUG - 2022-11-20 08:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:30:45 --> Total execution time: 0.1918
DEBUG - 2022-11-20 08:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:30:55 --> Total execution time: 0.1734
DEBUG - 2022-11-20 08:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:31:05 --> Total execution time: 0.1766
DEBUG - 2022-11-20 08:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:01:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 08:01:09 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 08:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:01:09 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:31:09 --> Total execution time: 0.1079
DEBUG - 2022-11-20 08:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:31:26 --> Total execution time: 0.1728
DEBUG - 2022-11-20 08:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:31:32 --> Total execution time: 0.2123
DEBUG - 2022-11-20 08:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:31:39 --> Total execution time: 0.1820
DEBUG - 2022-11-20 08:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:31:41 --> Total execution time: 0.1695
DEBUG - 2022-11-20 08:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:32:21 --> Total execution time: 0.2825
DEBUG - 2022-11-20 08:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:32:37 --> Total execution time: 0.1684
DEBUG - 2022-11-20 08:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:02:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:32:40 --> Total execution time: 0.1119
DEBUG - 2022-11-20 08:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:32:40 --> Total execution time: 0.1761
DEBUG - 2022-11-20 08:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:32:43 --> Total execution time: 0.1785
DEBUG - 2022-11-20 08:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:32:52 --> Total execution time: 0.1837
DEBUG - 2022-11-20 08:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:04:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 08:04:10 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 08:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:35:19 --> Total execution time: 0.1245
DEBUG - 2022-11-20 08:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:05:23 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:35:23 --> Total execution time: 0.1269
DEBUG - 2022-11-20 08:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:35:32 --> Total execution time: 0.2007
DEBUG - 2022-11-20 08:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:35:40 --> Total execution time: 0.1811
DEBUG - 2022-11-20 08:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 08:05:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 08:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:06:02 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:36:02 --> Total execution time: 0.5118
DEBUG - 2022-11-20 08:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:36:07 --> Total execution time: 0.2140
DEBUG - 2022-11-20 08:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:36:16 --> Total execution time: 0.1729
DEBUG - 2022-11-20 08:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:36:27 --> Total execution time: 0.1842
DEBUG - 2022-11-20 08:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:36:29 --> Total execution time: 0.1712
DEBUG - 2022-11-20 08:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:36:33 --> Total execution time: 0.2990
DEBUG - 2022-11-20 08:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:36:47 --> Total execution time: 0.2172
DEBUG - 2022-11-20 08:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:36:52 --> Total execution time: 0.1701
DEBUG - 2022-11-20 08:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:07:06 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:37:06 --> Total execution time: 0.1308
DEBUG - 2022-11-20 08:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:37:08 --> Total execution time: 0.2933
DEBUG - 2022-11-20 08:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:37:08 --> Total execution time: 0.1977
DEBUG - 2022-11-20 08:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:07:11 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:37:11 --> Total execution time: 0.1808
DEBUG - 2022-11-20 08:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:37:12 --> Total execution time: 0.1982
DEBUG - 2022-11-20 08:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:07:13 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:37:13 --> Total execution time: 0.1770
DEBUG - 2022-11-20 08:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:37:16 --> Total execution time: 0.1702
DEBUG - 2022-11-20 08:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:37:16 --> Total execution time: 0.1138
DEBUG - 2022-11-20 08:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:37:45 --> Total execution time: 0.1786
DEBUG - 2022-11-20 08:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:38:14 --> Total execution time: 0.1743
DEBUG - 2022-11-20 08:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:38:33 --> Total execution time: 0.1701
DEBUG - 2022-11-20 08:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:38:39 --> Total execution time: 0.1736
DEBUG - 2022-11-20 08:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:39:25 --> Total execution time: 0.2588
DEBUG - 2022-11-20 08:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:40:09 --> Total execution time: 0.1687
DEBUG - 2022-11-20 08:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:40:17 --> Total execution time: 0.2059
DEBUG - 2022-11-20 08:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:40:26 --> Total execution time: 0.4693
DEBUG - 2022-11-20 08:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:40:29 --> Total execution time: 0.1762
DEBUG - 2022-11-20 08:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:40:31 --> Total execution time: 0.1702
DEBUG - 2022-11-20 08:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:40:31 --> Total execution time: 0.2172
DEBUG - 2022-11-20 08:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:40:36 --> Total execution time: 0.2116
DEBUG - 2022-11-20 08:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:40:43 --> Total execution time: 0.1734
DEBUG - 2022-11-20 08:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:40:45 --> Total execution time: 0.2656
DEBUG - 2022-11-20 08:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:40:46 --> Total execution time: 0.1847
DEBUG - 2022-11-20 08:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:40:56 --> Total execution time: 0.2064
DEBUG - 2022-11-20 08:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:41:15 --> Total execution time: 0.1778
DEBUG - 2022-11-20 08:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:41:17 --> Total execution time: 0.1781
DEBUG - 2022-11-20 08:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:11:21 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:41:21 --> Total execution time: 0.1145
DEBUG - 2022-11-20 08:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:42:14 --> Total execution time: 0.1873
DEBUG - 2022-11-20 08:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:12:24 --> Total execution time: 0.1698
DEBUG - 2022-11-20 08:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:12:26 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:42:26 --> Total execution time: 0.1109
DEBUG - 2022-11-20 08:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:42:33 --> Total execution time: 0.4955
DEBUG - 2022-11-20 08:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:12:36 --> Total execution time: 0.1831
DEBUG - 2022-11-20 08:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:12:36 --> Total execution time: 0.4191
DEBUG - 2022-11-20 08:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:42:52 --> Total execution time: 0.2164
DEBUG - 2022-11-20 08:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:42:59 --> Total execution time: 0.1789
DEBUG - 2022-11-20 08:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:43:00 --> Total execution time: 0.4603
DEBUG - 2022-11-20 08:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:43:17 --> Total execution time: 0.1881
DEBUG - 2022-11-20 08:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:13:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:43:39 --> Total execution time: 0.1106
DEBUG - 2022-11-20 08:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:43:45 --> Total execution time: 0.1723
DEBUG - 2022-11-20 08:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:14:05 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:44:05 --> Total execution time: 0.1117
DEBUG - 2022-11-20 08:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:44:05 --> Total execution time: 0.1832
DEBUG - 2022-11-20 08:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:44:13 --> Total execution time: 0.1807
DEBUG - 2022-11-20 08:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:44:20 --> Total execution time: 0.1864
DEBUG - 2022-11-20 08:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:44:55 --> Total execution time: 0.2220
DEBUG - 2022-11-20 08:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:44:56 --> Total execution time: 0.1710
DEBUG - 2022-11-20 08:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:45:06 --> Total execution time: 0.1942
DEBUG - 2022-11-20 08:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:45:11 --> Total execution time: 0.2162
DEBUG - 2022-11-20 08:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:15:12 --> Total execution time: 0.1222
DEBUG - 2022-11-20 08:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:45:14 --> Total execution time: 0.2031
DEBUG - 2022-11-20 08:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:15:31 --> Total execution time: 0.1121
DEBUG - 2022-11-20 08:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:15:44 --> Total execution time: 0.1216
DEBUG - 2022-11-20 08:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:16:15 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:46:15 --> Total execution time: 0.1134
DEBUG - 2022-11-20 08:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:46:25 --> Total execution time: 0.2001
DEBUG - 2022-11-20 08:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:46:26 --> Total execution time: 0.2254
DEBUG - 2022-11-20 08:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:46:27 --> Total execution time: 0.2003
DEBUG - 2022-11-20 08:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:47:12 --> Total execution time: 2.3895
DEBUG - 2022-11-20 08:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:17:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 08:17:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 08:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:17:30 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:47:31 --> Total execution time: 0.2114
DEBUG - 2022-11-20 08:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:47:47 --> Total execution time: 0.2003
DEBUG - 2022-11-20 08:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:47:54 --> Total execution time: 0.4626
DEBUG - 2022-11-20 08:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:18:02 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:48:02 --> Total execution time: 0.1843
DEBUG - 2022-11-20 08:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:18:59 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:49:01 --> Total execution time: 2.2703
DEBUG - 2022-11-20 08:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:49:07 --> Total execution time: 0.1712
DEBUG - 2022-11-20 08:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:49:11 --> Total execution time: 0.6807
DEBUG - 2022-11-20 08:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:49:12 --> Total execution time: 0.1759
DEBUG - 2022-11-20 08:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:49:31 --> Total execution time: 0.1768
DEBUG - 2022-11-20 08:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:49:39 --> Total execution time: 0.2459
DEBUG - 2022-11-20 08:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:49:45 --> Total execution time: 0.2057
DEBUG - 2022-11-20 08:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:50:01 --> Total execution time: 0.1762
DEBUG - 2022-11-20 08:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:50:24 --> Total execution time: 0.1783
DEBUG - 2022-11-20 08:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:50:52 --> Total execution time: 0.2150
DEBUG - 2022-11-20 08:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:51:31 --> Total execution time: 0.1905
DEBUG - 2022-11-20 08:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:21:32 --> Total execution time: 0.1094
DEBUG - 2022-11-20 08:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:21:35 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:51:35 --> Total execution time: 0.1326
DEBUG - 2022-11-20 08:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:51:36 --> Total execution time: 0.2372
DEBUG - 2022-11-20 08:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:21:37 --> Total execution time: 0.1718
DEBUG - 2022-11-20 08:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:21:42 --> Total execution time: 0.1772
DEBUG - 2022-11-20 08:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:52:01 --> Total execution time: 0.2119
DEBUG - 2022-11-20 08:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:52:06 --> Total execution time: 0.2096
DEBUG - 2022-11-20 08:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:52:12 --> Total execution time: 0.1734
DEBUG - 2022-11-20 08:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:52:30 --> Total execution time: 0.1825
DEBUG - 2022-11-20 08:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 08:23:34 --> 404 Page Not Found: Lego-bionicle-8560-pahrak-bohrokfigure-no-manual-no-canister-484790html/index
DEBUG - 2022-11-20 08:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:23:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 08:23:39 --> 404 Page Not Found: Automatic-toastmaster-2lb-bread-box-maker-machine-1142-fast-bake-horizontal-used-96081html/index
DEBUG - 2022-11-20 08:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:53:39 --> Total execution time: 0.1359
DEBUG - 2022-11-20 08:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 08:23:39 --> 404 Page Not Found: Dime-835531html/index
DEBUG - 2022-11-20 08:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:23:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:53:39 --> Total execution time: 0.1178
DEBUG - 2022-11-20 08:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 08:23:39 --> 404 Page Not Found: Sylvania-dvc840g-dvdvcr-player-no-remote-or-av-cables-638951html/index
DEBUG - 2022-11-20 08:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:23:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 08:23:40 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 08:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:23:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 08:23:40 --> 404 Page Not Found: Zilli-60050-c02-eyeglasses-for-men-full-rime-titanium-eyewear-acetate-frame-353621html/index
DEBUG - 2022-11-20 08:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:25:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 08:25:24 --> 404 Page Not Found: Lessons/instagram-profile-optimization
DEBUG - 2022-11-20 08:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:25:43 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:55:45 --> Total execution time: 1.9159
DEBUG - 2022-11-20 08:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:28:09 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:58:12 --> Total execution time: 3.1266
DEBUG - 2022-11-20 08:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:58:20 --> Total execution time: 0.2070
DEBUG - 2022-11-20 08:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:58:31 --> Total execution time: 0.2268
DEBUG - 2022-11-20 08:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:58:41 --> Total execution time: 0.2606
DEBUG - 2022-11-20 08:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:58:48 --> Total execution time: 0.2321
DEBUG - 2022-11-20 08:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:59:00 --> Total execution time: 0.1768
DEBUG - 2022-11-20 08:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:31:13 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:01:13 --> Total execution time: 0.1859
DEBUG - 2022-11-20 08:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:32:46 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:02:46 --> Total execution time: 0.1449
DEBUG - 2022-11-20 08:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:03:15 --> Total execution time: 0.1203
DEBUG - 2022-11-20 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:33:45 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:03:45 --> Total execution time: 0.1280
DEBUG - 2022-11-20 08:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:03:58 --> Total execution time: 0.1855
DEBUG - 2022-11-20 08:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:04:11 --> Total execution time: 0.2349
DEBUG - 2022-11-20 08:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:34:33 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:04:33 --> Total execution time: 0.1114
DEBUG - 2022-11-20 08:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:04:33 --> Total execution time: 0.2100
DEBUG - 2022-11-20 08:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:04:37 --> Total execution time: 0.1806
DEBUG - 2022-11-20 08:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 08:34:44 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 08:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:04:46 --> Total execution time: 0.1752
DEBUG - 2022-11-20 08:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:34:59 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:04:59 --> Total execution time: 0.1162
DEBUG - 2022-11-20 08:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:05:14 --> Total execution time: 0.1757
DEBUG - 2022-11-20 08:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:36:06 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:06:06 --> Total execution time: 0.1271
DEBUG - 2022-11-20 08:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:06:23 --> Total execution time: 0.1778
DEBUG - 2022-11-20 08:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:38:43 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:08:43 --> Total execution time: 0.1387
DEBUG - 2022-11-20 08:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:38:45 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:08:45 --> Total execution time: 0.1490
DEBUG - 2022-11-20 08:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:09:03 --> Total execution time: 0.1416
DEBUG - 2022-11-20 08:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:09:13 --> Total execution time: 0.1977
DEBUG - 2022-11-20 08:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:09:14 --> Total execution time: 0.2438
DEBUG - 2022-11-20 08:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:09:22 --> Total execution time: 0.1814
DEBUG - 2022-11-20 08:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:09:31 --> Total execution time: 0.1956
DEBUG - 2022-11-20 08:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:09:38 --> Total execution time: 0.2225
DEBUG - 2022-11-20 08:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:10:03 --> Total execution time: 0.2417
DEBUG - 2022-11-20 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:40:17 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:10:17 --> Total execution time: 0.1169
DEBUG - 2022-11-20 08:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:10:19 --> Total execution time: 0.2180
DEBUG - 2022-11-20 08:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:40:52 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:10:52 --> Total execution time: 0.1158
DEBUG - 2022-11-20 08:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:41:00 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:11:00 --> Total execution time: 0.1717
DEBUG - 2022-11-20 08:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:11:40 --> Total execution time: 0.4619
DEBUG - 2022-11-20 08:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:11:58 --> Total execution time: 0.1879
DEBUG - 2022-11-20 08:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:12:44 --> Total execution time: 0.3102
DEBUG - 2022-11-20 08:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:12:46 --> Total execution time: 0.2951
DEBUG - 2022-11-20 08:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:13:04 --> Total execution time: 0.1791
DEBUG - 2022-11-20 08:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:43:12 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:13:13 --> Total execution time: 0.4806
DEBUG - 2022-11-20 08:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:13:26 --> Total execution time: 0.1914
DEBUG - 2022-11-20 08:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:13:33 --> Total execution time: 0.1816
DEBUG - 2022-11-20 08:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:13:36 --> Total execution time: 0.1907
DEBUG - 2022-11-20 08:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:14:05 --> Total execution time: 0.1775
DEBUG - 2022-11-20 08:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:14:44 --> Total execution time: 0.1969
DEBUG - 2022-11-20 08:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:44:48 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:14:48 --> Total execution time: 0.1134
DEBUG - 2022-11-20 08:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:44:48 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:14:48 --> Total execution time: 0.1444
DEBUG - 2022-11-20 08:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:14:51 --> Total execution time: 0.1753
DEBUG - 2022-11-20 08:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:14:56 --> Total execution time: 0.1797
DEBUG - 2022-11-20 08:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:15:02 --> Total execution time: 0.2823
DEBUG - 2022-11-20 08:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:45:03 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:15:03 --> Total execution time: 0.1386
DEBUG - 2022-11-20 08:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:15:26 --> Total execution time: 0.1141
DEBUG - 2022-11-20 08:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:45:39 --> Total execution time: 0.1817
DEBUG - 2022-11-20 08:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:45:42 --> Total execution time: 0.1817
DEBUG - 2022-11-20 08:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:45:42 --> Total execution time: 0.1882
DEBUG - 2022-11-20 08:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:46:42 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:16:42 --> Total execution time: 0.2092
DEBUG - 2022-11-20 08:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:16:54 --> Total execution time: 0.2760
DEBUG - 2022-11-20 08:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:17:11 --> Total execution time: 0.2309
DEBUG - 2022-11-20 08:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:17:22 --> Total execution time: 0.2651
DEBUG - 2022-11-20 08:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:47:30 --> Total execution time: 0.1800
DEBUG - 2022-11-20 08:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:17:31 --> Total execution time: 0.1962
DEBUG - 2022-11-20 08:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:47:32 --> Total execution time: 0.2040
DEBUG - 2022-11-20 08:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:47:33 --> Total execution time: 0.2315
DEBUG - 2022-11-20 08:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:17:46 --> Total execution time: 0.7852
DEBUG - 2022-11-20 08:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:18:01 --> Total execution time: 0.2165
DEBUG - 2022-11-20 08:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:18:28 --> Total execution time: 0.4763
DEBUG - 2022-11-20 08:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:48:33 --> Total execution time: 0.1221
DEBUG - 2022-11-20 08:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:18:45 --> Total execution time: 2.5186
DEBUG - 2022-11-20 08:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:48:49 --> Total execution time: 0.1762
DEBUG - 2022-11-20 08:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:48:49 --> Total execution time: 0.1979
DEBUG - 2022-11-20 08:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 08:48:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 08:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:49:23 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:19:23 --> Total execution time: 0.1245
DEBUG - 2022-11-20 08:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:49:26 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:19:27 --> Total execution time: 0.9089
DEBUG - 2022-11-20 08:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:19:31 --> Total execution time: 0.1146
DEBUG - 2022-11-20 08:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:19:42 --> Total execution time: 0.8322
DEBUG - 2022-11-20 08:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:19:44 --> Total execution time: 0.1971
DEBUG - 2022-11-20 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:19:47 --> Total execution time: 0.1975
DEBUG - 2022-11-20 08:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:19:48 --> Total execution time: 0.2075
DEBUG - 2022-11-20 08:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:19:49 --> Total execution time: 0.2499
DEBUG - 2022-11-20 08:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:19:56 --> Total execution time: 0.2101
DEBUG - 2022-11-20 08:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:20:00 --> Total execution time: 0.2178
DEBUG - 2022-11-20 08:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:50:08 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:20:08 --> Total execution time: 0.1980
DEBUG - 2022-11-20 08:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:20:16 --> Total execution time: 0.2194
DEBUG - 2022-11-20 08:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:20:17 --> Total execution time: 0.1991
DEBUG - 2022-11-20 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:20:21 --> Total execution time: 0.1820
DEBUG - 2022-11-20 08:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:20:23 --> Total execution time: 0.1840
DEBUG - 2022-11-20 08:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:50:29 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:20:29 --> Total execution time: 0.1813
DEBUG - 2022-11-20 08:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:20:32 --> Total execution time: 0.1706
DEBUG - 2022-11-20 08:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:50:44 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:20:44 --> Total execution time: 0.2231
DEBUG - 2022-11-20 08:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:21:02 --> Total execution time: 0.2477
DEBUG - 2022-11-20 08:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:03 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:21:03 --> Total execution time: 0.1388
DEBUG - 2022-11-20 08:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:21:06 --> Total execution time: 0.2022
DEBUG - 2022-11-20 08:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:21:06 --> Total execution time: 0.1856
DEBUG - 2022-11-20 08:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:21:11 --> Total execution time: 0.2360
DEBUG - 2022-11-20 08:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:51:17 --> Total execution time: 0.2004
DEBUG - 2022-11-20 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:21:19 --> Total execution time: 0.2515
DEBUG - 2022-11-20 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:51:19 --> Total execution time: 0.1951
DEBUG - 2022-11-20 08:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:51:20 --> Total execution time: 0.3009
DEBUG - 2022-11-20 08:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:21:30 --> Total execution time: 0.1750
DEBUG - 2022-11-20 08:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:33 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:21:33 --> Total execution time: 0.1761
DEBUG - 2022-11-20 08:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:21:40 --> Total execution time: 0.1855
DEBUG - 2022-11-20 08:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:21:43 --> Total execution time: 0.2285
DEBUG - 2022-11-20 08:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:21:58 --> Total execution time: 0.2380
DEBUG - 2022-11-20 08:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:22:03 --> Total execution time: 0.4856
DEBUG - 2022-11-20 08:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:52:09 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:22:09 --> Total execution time: 0.1230
DEBUG - 2022-11-20 08:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:52:22 --> Total execution time: 0.1718
DEBUG - 2022-11-20 08:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:52:24 --> Total execution time: 0.1714
DEBUG - 2022-11-20 08:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 08:52:24 --> Total execution time: 0.1769
DEBUG - 2022-11-20 08:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:22:52 --> Total execution time: 0.4938
DEBUG - 2022-11-20 08:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:22:57 --> Total execution time: 0.1776
DEBUG - 2022-11-20 08:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:57:18 --> No URI present. Default controller set.
DEBUG - 2022-11-20 08:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 08:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:27:18 --> Total execution time: 0.7132
DEBUG - 2022-11-20 08:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 08:59:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 08:59:18 --> 404 Page Not Found: Antique-glass-eye-wash-cup-67647html/index
DEBUG - 2022-11-20 09:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:00:00 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:30:01 --> Total execution time: 0.8213
DEBUG - 2022-11-20 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:30:02 --> Total execution time: 0.1866
DEBUG - 2022-11-20 09:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:00:06 --> Total execution time: 0.5063
DEBUG - 2022-11-20 09:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:00:08 --> Total execution time: 0.3261
DEBUG - 2022-11-20 09:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:00:08 --> Total execution time: 0.2147
DEBUG - 2022-11-20 09:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:31:10 --> Total execution time: 0.6023
DEBUG - 2022-11-20 09:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:31:20 --> Total execution time: 0.1794
DEBUG - 2022-11-20 09:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:32:25 --> Total execution time: 0.4838
DEBUG - 2022-11-20 09:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:32:43 --> Total execution time: 0.5988
DEBUG - 2022-11-20 09:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:32:50 --> Total execution time: 0.2162
DEBUG - 2022-11-20 09:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:32:54 --> Total execution time: 0.2020
DEBUG - 2022-11-20 09:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:33:03 --> Total execution time: 0.1836
DEBUG - 2022-11-20 09:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:03:10 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:33:10 --> Total execution time: 0.1334
DEBUG - 2022-11-20 09:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:03:11 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-11-20 09:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:33:52 --> Total execution time: 3.3329
DEBUG - 2022-11-20 09:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:33:57 --> Total execution time: 0.2770
DEBUG - 2022-11-20 09:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:04:38 --> 404 Page Not Found: Cobra-kai-strike-first-hard-no-mercy-johnny-little-caesars-parody-8x12-wall-sign-939715html/index
DEBUG - 2022-11-20 09:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:04:38 --> 404 Page Not Found: New-in-boxblackweb-wireless-charging-mouse-pad-244646html/index
DEBUG - 2022-11-20 09:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:04:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:04:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 09:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:35:18 --> Total execution time: 0.2137
DEBUG - 2022-11-20 09:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:35:34 --> Total execution time: 0.1925
DEBUG - 2022-11-20 09:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:37:09 --> Total execution time: 8.3302
DEBUG - 2022-11-20 09:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:38:05 --> Total execution time: 0.2455
DEBUG - 2022-11-20 09:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:38:15 --> Total execution time: 0.2646
DEBUG - 2022-11-20 09:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:38:25 --> Total execution time: 0.2601
DEBUG - 2022-11-20 09:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:38:37 --> Total execution time: 0.5562
DEBUG - 2022-11-20 09:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:08:39 --> 404 Page Not Found: Appalooza-the-holy-of-holies-971546html/index
DEBUG - 2022-11-20 09:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:38:39 --> Total execution time: 0.1889
DEBUG - 2022-11-20 09:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:08:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:38:40 --> Total execution time: 0.1304
DEBUG - 2022-11-20 09:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:08:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:08:40 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 09:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:08:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:08:40 --> 404 Page Not Found: Nourison-grafix-grf03-blue-indoor-area-rug-985059html/index
DEBUG - 2022-11-20 09:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:08:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:08:40 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 09:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:08:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:38:40 --> Total execution time: 0.1242
DEBUG - 2022-11-20 09:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:08:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:38:40 --> Total execution time: 0.1149
DEBUG - 2022-11-20 09:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:14:18 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:44:18 --> Total execution time: 0.6134
DEBUG - 2022-11-20 09:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:44:20 --> Total execution time: 0.1095
DEBUG - 2022-11-20 09:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:44:20 --> Total execution time: 0.1694
DEBUG - 2022-11-20 09:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:44:30 --> Total execution time: 0.2106
DEBUG - 2022-11-20 09:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:44:40 --> Total execution time: 0.2233
DEBUG - 2022-11-20 09:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:44:44 --> Total execution time: 0.1864
DEBUG - 2022-11-20 09:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:44:51 --> Total execution time: 0.1750
DEBUG - 2022-11-20 09:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:45:06 --> Total execution time: 0.1814
DEBUG - 2022-11-20 09:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:18:52 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:48:52 --> Total execution time: 0.4705
DEBUG - 2022-11-20 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:49:58 --> Total execution time: 0.1740
DEBUG - 2022-11-20 09:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:20:49 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:50:50 --> Total execution time: 0.4775
DEBUG - 2022-11-20 09:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:21:03 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:51:03 --> Total execution time: 0.1761
DEBUG - 2022-11-20 09:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:21:50 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:51:50 --> Total execution time: 0.1769
DEBUG - 2022-11-20 09:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:22:06 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:52:06 --> Total execution time: 0.1151
DEBUG - 2022-11-20 09:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:22:07 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:52:07 --> Total execution time: 0.1328
DEBUG - 2022-11-20 09:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:22:15 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:52:15 --> Total execution time: 0.1107
DEBUG - 2022-11-20 09:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:22:19 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:52:19 --> Total execution time: 0.1177
DEBUG - 2022-11-20 09:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:25:07 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:55:08 --> Total execution time: 0.1343
DEBUG - 2022-11-20 09:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:27:25 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:57:29 --> Total execution time: 4.2942
DEBUG - 2022-11-20 09:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:28:15 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:58:16 --> Total execution time: 0.2163
DEBUG - 2022-11-20 09:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:58:23 --> Total execution time: 0.1089
DEBUG - 2022-11-20 09:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:59:11 --> Total execution time: 0.1076
DEBUG - 2022-11-20 09:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:59:12 --> Total execution time: 0.1105
DEBUG - 2022-11-20 09:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:59:37 --> Total execution time: 0.2117
DEBUG - 2022-11-20 09:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:59:42 --> Total execution time: 0.2115
DEBUG - 2022-11-20 09:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:59:42 --> Total execution time: 0.1811
DEBUG - 2022-11-20 09:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:59:43 --> Total execution time: 0.1795
DEBUG - 2022-11-20 09:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:59:43 --> Total execution time: 0.2023
DEBUG - 2022-11-20 09:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:59:48 --> Total execution time: 0.1887
DEBUG - 2022-11-20 09:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:59:49 --> Total execution time: 0.1763
DEBUG - 2022-11-20 09:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:00:00 --> Total execution time: 0.1713
DEBUG - 2022-11-20 09:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:00:01 --> Total execution time: 0.2553
DEBUG - 2022-11-20 09:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:00:08 --> Total execution time: 0.1841
DEBUG - 2022-11-20 09:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:00:20 --> Total execution time: 0.1700
DEBUG - 2022-11-20 09:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:01:46 --> Total execution time: 0.1836
DEBUG - 2022-11-20 09:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:02:52 --> Total execution time: 0.1593
DEBUG - 2022-11-20 09:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:36:29 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:06:29 --> Total execution time: 0.1238
DEBUG - 2022-11-20 09:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:38:27 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:08:28 --> Total execution time: 0.1152
DEBUG - 2022-11-20 09:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:38:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:08:38 --> Total execution time: 0.1111
DEBUG - 2022-11-20 09:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:08:49 --> Total execution time: 0.1859
DEBUG - 2022-11-20 09:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:38:53 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:08:54 --> Total execution time: 0.1900
DEBUG - 2022-11-20 09:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:39:11 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:09:11 --> Total execution time: 0.1780
DEBUG - 2022-11-20 09:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:39:25 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:09:25 --> Total execution time: 0.1762
DEBUG - 2022-11-20 09:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:09:30 --> Total execution time: 0.1111
DEBUG - 2022-11-20 09:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:39:32 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:09:32 --> Total execution time: 0.1753
DEBUG - 2022-11-20 09:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:09:42 --> Total execution time: 0.1699
DEBUG - 2022-11-20 09:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:39:46 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:09:46 --> Total execution time: 0.1716
DEBUG - 2022-11-20 09:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:39:52 --> Total execution time: 0.1714
DEBUG - 2022-11-20 09:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:39:56 --> Total execution time: 0.1725
DEBUG - 2022-11-20 09:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:39:57 --> Total execution time: 0.2122
DEBUG - 2022-11-20 09:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:40:07 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:10:07 --> Total execution time: 0.1804
DEBUG - 2022-11-20 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:40:14 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:10:14 --> Total execution time: 0.1429
DEBUG - 2022-11-20 09:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:40:15 --> Total execution time: 0.1779
DEBUG - 2022-11-20 09:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:40:22 --> Total execution time: 0.1724
DEBUG - 2022-11-20 09:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:40:28 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:10:29 --> Total execution time: 0.1797
DEBUG - 2022-11-20 09:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:40:29 --> Total execution time: 0.1659
DEBUG - 2022-11-20 09:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:40:32 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:10:32 --> Total execution time: 0.1695
DEBUG - 2022-11-20 09:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:10:43 --> Total execution time: 0.1663
DEBUG - 2022-11-20 09:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:40:44 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:10:45 --> Total execution time: 0.1682
DEBUG - 2022-11-20 09:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:40:47 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:10:48 --> Total execution time: 0.1871
DEBUG - 2022-11-20 09:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:40:51 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:10:51 --> Total execution time: 0.1699
DEBUG - 2022-11-20 09:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:40:58 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:10:58 --> Total execution time: 0.1791
DEBUG - 2022-11-20 09:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:11:02 --> Total execution time: 0.1665
DEBUG - 2022-11-20 09:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:41:08 --> Total execution time: 0.1633
DEBUG - 2022-11-20 09:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:11:09 --> Total execution time: 0.2120
DEBUG - 2022-11-20 09:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:11:12 --> Total execution time: 0.2025
DEBUG - 2022-11-20 09:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:11:15 --> Total execution time: 0.1891
DEBUG - 2022-11-20 09:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:11:17 --> Total execution time: 0.2140
DEBUG - 2022-11-20 09:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:11:20 --> Total execution time: 0.1718
DEBUG - 2022-11-20 09:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:11:25 --> Total execution time: 0.1775
DEBUG - 2022-11-20 09:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:42:44 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:12:44 --> Total execution time: 0.1255
DEBUG - 2022-11-20 09:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:13:08 --> Total execution time: 0.1793
DEBUG - 2022-11-20 09:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:13:19 --> Total execution time: 0.1912
DEBUG - 2022-11-20 09:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:14:10 --> Total execution time: 0.1767
DEBUG - 2022-11-20 09:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:44:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:14:37 --> Total execution time: 0.5007
DEBUG - 2022-11-20 09:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:15:25 --> Total execution time: 0.1745
DEBUG - 2022-11-20 09:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:15:42 --> Total execution time: 0.4970
DEBUG - 2022-11-20 09:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:45:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:45:43 --> 404 Page Not Found: Nike-studio-leg-warmers-945599html/index
DEBUG - 2022-11-20 09:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:15:47 --> Total execution time: 0.1825
DEBUG - 2022-11-20 09:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:15:48 --> Total execution time: 0.4693
DEBUG - 2022-11-20 09:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:48:08 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:18:08 --> Total execution time: 0.2204
DEBUG - 2022-11-20 09:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:18:11 --> Total execution time: 0.3968
DEBUG - 2022-11-20 09:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:18:19 --> Total execution time: 0.1791
DEBUG - 2022-11-20 09:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:18:26 --> Total execution time: 0.2363
DEBUG - 2022-11-20 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:18:27 --> Total execution time: 0.2133
DEBUG - 2022-11-20 09:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:18:33 --> Total execution time: 0.1905
DEBUG - 2022-11-20 09:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:18:37 --> Total execution time: 0.1978
DEBUG - 2022-11-20 09:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:48:43 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:18:43 --> Total execution time: 0.1748
DEBUG - 2022-11-20 09:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:18:50 --> Total execution time: 0.1785
DEBUG - 2022-11-20 09:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:18:54 --> Total execution time: 0.1785
DEBUG - 2022-11-20 09:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:18:57 --> Total execution time: 0.1913
DEBUG - 2022-11-20 09:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:05 --> Total execution time: 0.5213
DEBUG - 2022-11-20 09:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:06 --> Total execution time: 0.1755
DEBUG - 2022-11-20 09:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:12 --> Total execution time: 0.3278
DEBUG - 2022-11-20 09:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:13 --> Total execution time: 0.2437
DEBUG - 2022-11-20 09:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:14 --> Total execution time: 0.1925
DEBUG - 2022-11-20 09:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:23 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:23 --> Total execution time: 0.1202
DEBUG - 2022-11-20 09:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:28 --> Total execution time: 0.1905
DEBUG - 2022-11-20 09:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:32 --> Total execution time: 0.1930
DEBUG - 2022-11-20 09:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:36 --> Total execution time: 0.1993
DEBUG - 2022-11-20 09:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:41 --> Total execution time: 0.1768
DEBUG - 2022-11-20 09:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:45 --> Total execution time: 0.2192
DEBUG - 2022-11-20 09:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:47 --> Total execution time: 0.1826
DEBUG - 2022-11-20 09:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:48 --> Total execution time: 0.1786
DEBUG - 2022-11-20 09:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:51 --> Total execution time: 0.1845
DEBUG - 2022-11-20 09:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:55 --> Total execution time: 0.1827
DEBUG - 2022-11-20 09:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:55 --> Total execution time: 0.1701
DEBUG - 2022-11-20 09:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:50:19 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:20:19 --> Total execution time: 0.1130
DEBUG - 2022-11-20 09:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:51:11 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:21:11 --> Total execution time: 0.1793
DEBUG - 2022-11-20 09:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:51:49 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:21:50 --> Total execution time: 0.1156
DEBUG - 2022-11-20 09:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:51:50 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:21:50 --> Total execution time: 0.1133
DEBUG - 2022-11-20 09:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:22:01 --> Total execution time: 0.1779
DEBUG - 2022-11-20 09:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:52:07 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:22:07 --> Total execution time: 0.1823
DEBUG - 2022-11-20 09:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:22:08 --> Total execution time: 0.1689
DEBUG - 2022-11-20 09:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:52:27 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:22:27 --> Total execution time: 0.1738
DEBUG - 2022-11-20 09:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:52:31 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:22:31 --> Total execution time: 0.2127
DEBUG - 2022-11-20 09:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:53:34 --> 404 Page Not Found: %EF%B8%8Fmaurices-black-polka-dot-print-lacy-sleeveless-buttoned-blouse-880926html/index
DEBUG - 2022-11-20 09:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:53:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:53:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 09:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:53:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:53:39 --> 404 Page Not Found: 30-geller-modern-barstool-in-geometric-project-62%E2%84%A2-425649html/index
DEBUG - 2022-11-20 09:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:53:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:23:39 --> Total execution time: 0.1219
DEBUG - 2022-11-20 09:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:53:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:53:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 09:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:53:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:53:39 --> 404 Page Not Found: Crocs-590819html/index
DEBUG - 2022-11-20 09:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:53:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:23:40 --> Total execution time: 0.1244
DEBUG - 2022-11-20 09:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:53:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:23:40 --> Total execution time: 0.1095
DEBUG - 2022-11-20 09:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:23:42 --> Total execution time: 0.1825
DEBUG - 2022-11-20 09:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:53:59 --> Total execution time: 0.1718
DEBUG - 2022-11-20 21:24:00 --> Total execution time: 2.3327
DEBUG - 2022-11-20 09:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:54:01 --> Total execution time: 0.2407
DEBUG - 2022-11-20 09:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:54:02 --> Total execution time: 0.2102
DEBUG - 2022-11-20 09:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:54:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 09:54:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 09:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:54:12 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:24:12 --> Total execution time: 0.4742
DEBUG - 2022-11-20 09:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:24:24 --> Total execution time: 0.1752
DEBUG - 2022-11-20 09:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:24:26 --> Total execution time: 0.2278
DEBUG - 2022-11-20 09:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:54:44 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:24:44 --> Total execution time: 0.1184
DEBUG - 2022-11-20 09:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:54:47 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:24:47 --> Total execution time: 0.1122
DEBUG - 2022-11-20 09:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:24:55 --> Total execution time: 0.1871
DEBUG - 2022-11-20 09:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:55:02 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:02 --> Total execution time: 0.1789
DEBUG - 2022-11-20 09:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:55:02 --> Total execution time: 0.1800
DEBUG - 2022-11-20 09:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:05 --> Total execution time: 0.1725
DEBUG - 2022-11-20 09:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:55:05 --> Total execution time: 0.1945
DEBUG - 2022-11-20 09:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:55:05 --> Total execution time: 0.1732
DEBUG - 2022-11-20 09:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:24 --> Total execution time: 0.1868
DEBUG - 2022-11-20 09:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:55:25 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:26 --> Total execution time: 0.1798
DEBUG - 2022-11-20 09:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:31 --> Total execution time: 0.2086
DEBUG - 2022-11-20 09:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:35 --> Total execution time: 0.2036
DEBUG - 2022-11-20 09:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:39 --> Total execution time: 0.2064
DEBUG - 2022-11-20 09:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:55:56 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:56 --> Total execution time: 0.1760
DEBUG - 2022-11-20 09:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:56:03 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:26:03 --> Total execution time: 0.1838
DEBUG - 2022-11-20 09:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:56:25 --> Total execution time: 0.4548
DEBUG - 2022-11-20 09:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:56:26 --> Total execution time: 0.1729
DEBUG - 2022-11-20 09:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:56:29 --> Total execution time: 0.1846
DEBUG - 2022-11-20 09:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:56:29 --> Total execution time: 0.1842
DEBUG - 2022-11-20 09:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:26:52 --> Total execution time: 0.1982
DEBUG - 2022-11-20 09:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:56:56 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:26:56 --> Total execution time: 0.1742
DEBUG - 2022-11-20 09:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:57:49 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:27:50 --> Total execution time: 0.1129
DEBUG - 2022-11-20 09:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:57:54 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:27:54 --> Total execution time: 0.1765
DEBUG - 2022-11-20 09:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:28:00 --> Total execution time: 1.6662
DEBUG - 2022-11-20 09:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:58:12 --> No URI present. Default controller set.
DEBUG - 2022-11-20 09:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:28:12 --> Total execution time: 0.1954
DEBUG - 2022-11-20 09:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:28:30 --> Total execution time: 0.1222
DEBUG - 2022-11-20 09:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:29:00 --> Total execution time: 0.1788
DEBUG - 2022-11-20 09:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 09:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 09:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 09:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:29:29 --> Total execution time: 0.2056
DEBUG - 2022-11-20 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:30:02 --> Total execution time: 0.1441
DEBUG - 2022-11-20 10:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:30:54 --> Total execution time: 0.2095
DEBUG - 2022-11-20 10:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:31:04 --> Total execution time: 0.1856
DEBUG - 2022-11-20 10:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:31:18 --> Total execution time: 1.8349
DEBUG - 2022-11-20 10:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:31:20 --> Total execution time: 0.1442
DEBUG - 2022-11-20 10:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 10:01:24 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 10:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:31:36 --> Total execution time: 0.1757
DEBUG - 2022-11-20 10:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:31:42 --> Total execution time: 0.2308
DEBUG - 2022-11-20 10:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:31:56 --> Total execution time: 0.3703
DEBUG - 2022-11-20 10:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:32:37 --> Total execution time: 0.1772
DEBUG - 2022-11-20 10:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:33:25 --> Total execution time: 0.1786
DEBUG - 2022-11-20 10:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:03:29 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:33:30 --> Total execution time: 0.4828
DEBUG - 2022-11-20 10:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:33:38 --> Total execution time: 0.1795
DEBUG - 2022-11-20 10:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:34:21 --> Total execution time: 0.1070
DEBUG - 2022-11-20 10:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:04:27 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:34:27 --> Total execution time: 0.1748
DEBUG - 2022-11-20 10:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:04:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 10:04:44 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 10:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:34:45 --> Total execution time: 0.1930
DEBUG - 2022-11-20 10:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:35:22 --> Total execution time: 0.1782
DEBUG - 2022-11-20 10:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:35:25 --> Total execution time: 0.1710
DEBUG - 2022-11-20 10:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:05:30 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:35:31 --> Total execution time: 0.1724
DEBUG - 2022-11-20 10:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:35:36 --> Total execution time: 0.1791
DEBUG - 2022-11-20 10:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:35:39 --> Total execution time: 0.1730
DEBUG - 2022-11-20 10:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:35:45 --> Total execution time: 1.7337
DEBUG - 2022-11-20 10:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:06:20 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:36:20 --> Total execution time: 0.1841
DEBUG - 2022-11-20 10:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:07:54 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:37:54 --> Total execution time: 0.1346
DEBUG - 2022-11-20 10:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:38:32 --> Total execution time: 0.5283
DEBUG - 2022-11-20 10:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:09:13 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:39:13 --> Total execution time: 0.1779
DEBUG - 2022-11-20 10:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:09:22 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:39:22 --> Total execution time: 0.2048
DEBUG - 2022-11-20 10:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:39:41 --> Total execution time: 0.1853
DEBUG - 2022-11-20 10:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:09:53 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:39:53 --> Total execution time: 0.1731
DEBUG - 2022-11-20 10:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:14:27 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:44:28 --> Total execution time: 0.5942
DEBUG - 2022-11-20 10:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:14:45 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:44:45 --> Total execution time: 0.1174
DEBUG - 2022-11-20 10:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:16:33 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:46:33 --> Total execution time: 0.1548
DEBUG - 2022-11-20 10:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:16:35 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:16:35 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:46:35 --> Total execution time: 0.1361
DEBUG - 2022-11-20 10:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:46:35 --> Total execution time: 0.1188
DEBUG - 2022-11-20 10:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:16:36 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:46:37 --> Total execution time: 0.1137
DEBUG - 2022-11-20 10:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:16:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:46:37 --> Total execution time: 0.1106
DEBUG - 2022-11-20 10:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:16:58 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:46:58 --> Total execution time: 0.1491
DEBUG - 2022-11-20 10:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:47:47 --> Total execution time: 0.1782
DEBUG - 2022-11-20 10:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:48:13 --> Total execution time: 0.1751
DEBUG - 2022-11-20 10:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:48:43 --> Total execution time: 0.1687
DEBUG - 2022-11-20 10:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:48:45 --> Total execution time: 0.2015
DEBUG - 2022-11-20 10:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:48:48 --> Total execution time: 0.1744
DEBUG - 2022-11-20 10:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:48:52 --> Total execution time: 0.1715
DEBUG - 2022-11-20 10:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:48:58 --> Total execution time: 0.1699
DEBUG - 2022-11-20 10:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:49:02 --> Total execution time: 0.1701
DEBUG - 2022-11-20 10:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:49:03 --> Total execution time: 0.1778
DEBUG - 2022-11-20 10:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:19:18 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:49:18 --> Total execution time: 0.1133
DEBUG - 2022-11-20 10:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:19:32 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:49:32 --> Total execution time: 0.1122
DEBUG - 2022-11-20 10:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:19:56 --> Total execution time: 0.1170
DEBUG - 2022-11-20 10:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:50:15 --> Total execution time: 0.1780
DEBUG - 2022-11-20 10:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:40 --> Total execution time: 0.1790
DEBUG - 2022-11-20 10:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:21:45 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:21:45 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:45 --> Total execution time: 0.1236
DEBUG - 2022-11-20 10:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:45 --> Total execution time: 0.1245
DEBUG - 2022-11-20 10:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:21:47 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:47 --> Total execution time: 0.1098
DEBUG - 2022-11-20 10:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:21:50 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:51 --> Total execution time: 0.4603
DEBUG - 2022-11-20 10:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:21:51 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:51 --> Total execution time: 0.1714
DEBUG - 2022-11-20 10:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:21:59 --> Total execution time: 0.1963
DEBUG - 2022-11-20 10:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:22:01 --> Total execution time: 0.2280
DEBUG - 2022-11-20 10:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:22:01 --> Total execution time: 0.2010
DEBUG - 2022-11-20 10:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:52:22 --> Total execution time: 0.1782
DEBUG - 2022-11-20 10:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:52:34 --> Total execution time: 0.1729
DEBUG - 2022-11-20 10:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:52:40 --> Total execution time: 0.2867
DEBUG - 2022-11-20 10:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:52:46 --> Total execution time: 0.2394
DEBUG - 2022-11-20 10:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:53:00 --> Total execution time: 0.1983
DEBUG - 2022-11-20 10:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:53:08 --> Total execution time: 2.2826
DEBUG - 2022-11-20 10:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:53:09 --> Total execution time: 0.2263
DEBUG - 2022-11-20 10:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:23:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 10:23:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 10:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:53:19 --> Total execution time: 0.1831
DEBUG - 2022-11-20 10:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:53:41 --> Total execution time: 0.2148
DEBUG - 2022-11-20 10:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:53:45 --> Total execution time: 0.2228
DEBUG - 2022-11-20 10:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:53:51 --> Total execution time: 0.2271
DEBUG - 2022-11-20 10:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:53:56 --> Total execution time: 0.2132
DEBUG - 2022-11-20 10:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:54:01 --> Total execution time: 0.3015
DEBUG - 2022-11-20 10:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:54:03 --> Total execution time: 0.1796
DEBUG - 2022-11-20 10:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:54:06 --> Total execution time: 0.3675
DEBUG - 2022-11-20 10:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:54:07 --> Total execution time: 0.2146
DEBUG - 2022-11-20 10:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:54:48 --> Total execution time: 0.1882
DEBUG - 2022-11-20 10:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:24:54 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:54:55 --> Total execution time: 0.1225
DEBUG - 2022-11-20 10:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:55:03 --> Total execution time: 0.1124
DEBUG - 2022-11-20 10:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:55:04 --> Total execution time: 0.2087
DEBUG - 2022-11-20 10:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:25:12 --> Total execution time: 0.1968
DEBUG - 2022-11-20 10:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:25:15 --> Total execution time: 0.1946
DEBUG - 2022-11-20 10:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:25:15 --> Total execution time: 0.1823
DEBUG - 2022-11-20 10:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:55:17 --> Total execution time: 0.1781
DEBUG - 2022-11-20 10:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:55:21 --> Total execution time: 0.1793
DEBUG - 2022-11-20 10:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:55:32 --> Total execution time: 0.2213
DEBUG - 2022-11-20 10:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:29:05 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:59:08 --> Total execution time: 2.4133
DEBUG - 2022-11-20 10:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 10:29:18 --> 404 Page Not Found: Costway-7in1-kids-baby-tricycle-folding-steer-stroller-w-rotatable-seat-971089html/index
DEBUG - 2022-11-20 10:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:00:25 --> Total execution time: 0.1844
DEBUG - 2022-11-20 10:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:00:41 --> Total execution time: 0.8204
DEBUG - 2022-11-20 10:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:00:55 --> Total execution time: 0.2044
DEBUG - 2022-11-20 10:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:01:02 --> Total execution time: 0.1722
DEBUG - 2022-11-20 10:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:01:22 --> Total execution time: 0.2094
DEBUG - 2022-11-20 10:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:01:26 --> Total execution time: 0.3328
DEBUG - 2022-11-20 10:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:02:20 --> Total execution time: 0.4611
DEBUG - 2022-11-20 10:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:02:55 --> Total execution time: 0.1805
DEBUG - 2022-11-20 10:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:33:27 --> Total execution time: 0.1816
DEBUG - 2022-11-20 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:33:29 --> Total execution time: 0.2413
DEBUG - 2022-11-20 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:33:29 --> Total execution time: 0.1917
DEBUG - 2022-11-20 10:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:34:01 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:04:01 --> Total execution time: 0.1297
DEBUG - 2022-11-20 10:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:04:09 --> Total execution time: 0.1788
DEBUG - 2022-11-20 10:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:04:27 --> Total execution time: 0.2331
DEBUG - 2022-11-20 10:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:04:32 --> Total execution time: 0.2372
DEBUG - 2022-11-20 10:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 10:34:38 --> 404 Page Not Found: Bundle-of-pure-romance-products-221310html/index
DEBUG - 2022-11-20 10:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 10:34:38 --> 404 Page Not Found: Buffalo-bills-tie-dye-963761html/index
DEBUG - 2022-11-20 10:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 10:34:39 --> 404 Page Not Found: Vtg-hollywood-regency-diamond-point-crystal-12-pedestal-dish-w-lid-gold-base-257691html/index
DEBUG - 2022-11-20 10:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:04:54 --> Total execution time: 0.4904
DEBUG - 2022-11-20 10:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:04:55 --> Total execution time: 0.1881
DEBUG - 2022-11-20 10:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:04:59 --> Total execution time: 0.2610
DEBUG - 2022-11-20 10:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:05:04 --> Total execution time: 0.1927
DEBUG - 2022-11-20 10:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:05:11 --> Total execution time: 0.1800
DEBUG - 2022-11-20 10:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:05:47 --> Total execution time: 0.5059
DEBUG - 2022-11-20 10:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:36:05 --> Total execution time: 0.1959
DEBUG - 2022-11-20 10:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:36:10 --> Total execution time: 0.2261
DEBUG - 2022-11-20 10:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:06:48 --> Total execution time: 0.1763
DEBUG - 2022-11-20 10:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:07:09 --> Total execution time: 0.2281
DEBUG - 2022-11-20 10:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:37:17 --> Total execution time: 0.1801
DEBUG - 2022-11-20 10:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:37:21 --> Total execution time: 0.1835
DEBUG - 2022-11-20 10:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:07:26 --> Total execution time: 0.2011
DEBUG - 2022-11-20 10:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:07:46 --> Total execution time: 0.1875
DEBUG - 2022-11-20 10:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:07:51 --> Total execution time: 0.3630
DEBUG - 2022-11-20 10:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:07:54 --> Total execution time: 0.1902
DEBUG - 2022-11-20 10:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:07:59 --> Total execution time: 0.2479
DEBUG - 2022-11-20 10:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 10:38:39 --> 404 Page Not Found: Kate-quinn-2-sun-suits-mango-suns-green-crop-top-bloomers-organic-cotton-804121html/index
DEBUG - 2022-11-20 10:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:38:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:08:39 --> Total execution time: 0.1260
DEBUG - 2022-11-20 10:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:38:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 10:38:40 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 10:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:38:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:08:40 --> Total execution time: 0.1136
DEBUG - 2022-11-20 10:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:38:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:08:40 --> Total execution time: 0.1133
DEBUG - 2022-11-20 10:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:08:46 --> Total execution time: 0.1789
DEBUG - 2022-11-20 10:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:08:51 --> Total execution time: 0.1771
DEBUG - 2022-11-20 10:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:08:59 --> Total execution time: 0.2017
DEBUG - 2022-11-20 10:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:39:03 --> Total execution time: 0.1904
DEBUG - 2022-11-20 10:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:39:06 --> Total execution time: 0.1837
DEBUG - 2022-11-20 10:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:39:17 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:09:17 --> Total execution time: 0.1106
DEBUG - 2022-11-20 10:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:10:04 --> Total execution time: 0.2005
DEBUG - 2022-11-20 10:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:11:06 --> Total execution time: 0.2005
DEBUG - 2022-11-20 10:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:11:13 --> Total execution time: 0.1851
DEBUG - 2022-11-20 10:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:11:18 --> Total execution time: 0.2111
DEBUG - 2022-11-20 10:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:11:26 --> Total execution time: 0.1922
DEBUG - 2022-11-20 10:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:11:31 --> Total execution time: 0.1828
DEBUG - 2022-11-20 10:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:11:32 --> Total execution time: 0.2729
DEBUG - 2022-11-20 10:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:12:20 --> Total execution time: 0.4834
DEBUG - 2022-11-20 10:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:14:17 --> Total execution time: 0.3231
DEBUG - 2022-11-20 10:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:44:21 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:14:21 --> Total execution time: 0.1124
DEBUG - 2022-11-20 10:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:44:22 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:14:23 --> Total execution time: 0.1052
DEBUG - 2022-11-20 10:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:14:23 --> Total execution time: 0.4501
DEBUG - 2022-11-20 10:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:14:38 --> Total execution time: 0.4900
DEBUG - 2022-11-20 10:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:44:40 --> Total execution time: 0.1716
DEBUG - 2022-11-20 10:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:44:42 --> Total execution time: 0.1749
DEBUG - 2022-11-20 10:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:44:43 --> Total execution time: 0.1778
DEBUG - 2022-11-20 10:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:14:49 --> Total execution time: 0.1795
DEBUG - 2022-11-20 10:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:14:55 --> Total execution time: 0.1867
DEBUG - 2022-11-20 10:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:14:57 --> Total execution time: 0.2041
DEBUG - 2022-11-20 10:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:45:07 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:15:07 --> Total execution time: 0.1195
DEBUG - 2022-11-20 22:15:07 --> Total execution time: 0.2742
DEBUG - 2022-11-20 10:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:45:08 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:15:08 --> Total execution time: 0.1176
DEBUG - 2022-11-20 10:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:15:12 --> Total execution time: 0.2809
DEBUG - 2022-11-20 10:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:45:31 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:15:31 --> Total execution time: 0.1232
DEBUG - 2022-11-20 10:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:16:06 --> Total execution time: 0.1916
DEBUG - 2022-11-20 10:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:16:21 --> Total execution time: 0.1786
DEBUG - 2022-11-20 10:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:16:30 --> Total execution time: 0.1891
DEBUG - 2022-11-20 10:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:46:32 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:16:32 --> Total execution time: 0.1791
DEBUG - 2022-11-20 10:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:46:36 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:16:36 --> Total execution time: 0.1092
DEBUG - 2022-11-20 10:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:46:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:16:38 --> Total execution time: 0.1314
DEBUG - 2022-11-20 10:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:16:41 --> Total execution time: 0.1831
DEBUG - 2022-11-20 10:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:16:57 --> Total execution time: 0.2259
DEBUG - 2022-11-20 10:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:17:09 --> Total execution time: 0.2284
DEBUG - 2022-11-20 10:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:17:13 --> Total execution time: 0.2140
DEBUG - 2022-11-20 10:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:17:17 --> Total execution time: 2.1984
DEBUG - 2022-11-20 10:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:17:19 --> Total execution time: 0.1709
DEBUG - 2022-11-20 10:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 10:47:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 10:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:17:32 --> Total execution time: 0.2123
DEBUG - 2022-11-20 10:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:17:32 --> Total execution time: 0.1788
DEBUG - 2022-11-20 10:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:47:33 --> Total execution time: 0.1081
DEBUG - 2022-11-20 10:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:47:35 --> Total execution time: 0.1923
DEBUG - 2022-11-20 10:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:47:35 --> Total execution time: 0.1893
DEBUG - 2022-11-20 10:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:17:37 --> Total execution time: 0.1780
DEBUG - 2022-11-20 10:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:17:38 --> Total execution time: 0.2865
DEBUG - 2022-11-20 10:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:47:43 --> Total execution time: 0.1694
DEBUG - 2022-11-20 10:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:17:43 --> Total execution time: 0.1757
DEBUG - 2022-11-20 10:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:17:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-20 22:17:51 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-11-20 10:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:17:52 --> Total execution time: 0.1981
DEBUG - 2022-11-20 10:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:18:04 --> Total execution time: 0.2234
DEBUG - 2022-11-20 10:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:18:18 --> Total execution time: 0.1997
DEBUG - 2022-11-20 10:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:18:18 --> Total execution time: 0.1850
DEBUG - 2022-11-20 10:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:18:22 --> Total execution time: 1.7964
DEBUG - 2022-11-20 10:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:48:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 10:48:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 10:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:18:46 --> Total execution time: 0.1784
DEBUG - 2022-11-20 10:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:18:48 --> Total execution time: 0.3667
DEBUG - 2022-11-20 10:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:18:50 --> Total execution time: 0.1994
DEBUG - 2022-11-20 10:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:48:51 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:18:51 --> Total execution time: 0.1698
DEBUG - 2022-11-20 10:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:18:54 --> Total execution time: 0.2029
DEBUG - 2022-11-20 10:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:19:16 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-20 22:19:16 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-11-20 10:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:19:17 --> Total execution time: 0.1984
DEBUG - 2022-11-20 10:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:19:28 --> Total execution time: 0.5466
DEBUG - 2022-11-20 10:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:19:34 --> Total execution time: 0.2345
DEBUG - 2022-11-20 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:19:54 --> Total execution time: 0.2162
DEBUG - 2022-11-20 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 10:49:59 --> 404 Page Not Found: Apple-iphone-11-64-gb-in-product-red-for-tmobile-952854html/index
DEBUG - 2022-11-20 10:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:20:39 --> Total execution time: 0.1856
DEBUG - 2022-11-20 10:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:20:47 --> Total execution time: 0.1936
DEBUG - 2022-11-20 10:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:51:01 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:21:01 --> Total execution time: 0.1401
DEBUG - 2022-11-20 10:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:51:02 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:21:02 --> Total execution time: 0.1081
DEBUG - 2022-11-20 10:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:21:05 --> Total execution time: 0.1758
DEBUG - 2022-11-20 10:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:21:18 --> Total execution time: 0.1077
DEBUG - 2022-11-20 10:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:21:20 --> Total execution time: 0.1691
DEBUG - 2022-11-20 10:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:21:57 --> Total execution time: 0.1775
DEBUG - 2022-11-20 10:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:22:04 --> Total execution time: 0.1733
DEBUG - 2022-11-20 10:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:22:07 --> Total execution time: 0.1729
DEBUG - 2022-11-20 10:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:22:22 --> Total execution time: 0.2007
DEBUG - 2022-11-20 10:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:22:46 --> Total execution time: 0.2012
DEBUG - 2022-11-20 10:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:52:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 10:52:50 --> 404 Page Not Found: Lp-profile/index
DEBUG - 2022-11-20 10:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:22:57 --> Total execution time: 0.2118
DEBUG - 2022-11-20 10:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:23:08 --> Total execution time: 0.4718
DEBUG - 2022-11-20 10:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:23:17 --> Total execution time: 0.1775
DEBUG - 2022-11-20 10:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:24:39 --> Total execution time: 0.1771
DEBUG - 2022-11-20 10:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:25:26 --> Total execution time: 0.1787
DEBUG - 2022-11-20 10:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:25:34 --> Total execution time: 0.2332
DEBUG - 2022-11-20 10:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:55:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:25:39 --> Total execution time: 0.1127
DEBUG - 2022-11-20 10:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:25:47 --> Total execution time: 0.1162
DEBUG - 2022-11-20 10:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:26:03 --> Total execution time: 0.1796
DEBUG - 2022-11-20 10:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:26:10 --> Total execution time: 0.1971
DEBUG - 2022-11-20 10:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 10:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:26:11 --> Total execution time: 0.1774
DEBUG - 2022-11-20 10:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:26:20 --> Total execution time: 0.4721
DEBUG - 2022-11-20 10:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:26:37 --> Total execution time: 0.1138
DEBUG - 2022-11-20 10:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:26:44 --> Total execution time: 0.1872
DEBUG - 2022-11-20 10:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:26:58 --> Total execution time: 0.2009
DEBUG - 2022-11-20 10:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:57:20 --> No URI present. Default controller set.
DEBUG - 2022-11-20 10:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:27:20 --> Total execution time: 0.1192
DEBUG - 2022-11-20 10:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:27:45 --> Total execution time: 0.2021
DEBUG - 2022-11-20 10:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:27:54 --> Total execution time: 0.1861
DEBUG - 2022-11-20 10:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:27:58 --> Total execution time: 0.1782
DEBUG - 2022-11-20 10:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:28:03 --> Total execution time: 0.2219
DEBUG - 2022-11-20 10:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:28:06 --> Total execution time: 0.1803
DEBUG - 2022-11-20 10:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:28:24 --> Total execution time: 0.1951
DEBUG - 2022-11-20 10:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:28:28 --> Total execution time: 0.1914
DEBUG - 2022-11-20 10:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:28:38 --> Total execution time: 0.1828
DEBUG - 2022-11-20 10:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:29:13 --> Total execution time: 0.1749
DEBUG - 2022-11-20 10:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 10:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 10:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:29:28 --> Total execution time: 0.1777
DEBUG - 2022-11-20 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:30:02 --> Total execution time: 0.1929
DEBUG - 2022-11-20 11:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:30:07 --> Total execution time: 0.3097
DEBUG - 2022-11-20 11:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:30:49 --> Total execution time: 0.1771
DEBUG - 2022-11-20 11:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:32:30 --> Total execution time: 0.6643
DEBUG - 2022-11-20 11:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:32:40 --> Total execution time: 0.2301
DEBUG - 2022-11-20 11:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:32:57 --> Total execution time: 0.2140
DEBUG - 2022-11-20 11:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:08 --> Total execution time: 0.1805
DEBUG - 2022-11-20 11:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:25 --> Total execution time: 0.5096
DEBUG - 2022-11-20 11:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:35 --> Total execution time: 0.1753
DEBUG - 2022-11-20 11:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:34:41 --> Total execution time: 0.1886
DEBUG - 2022-11-20 11:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:34:57 --> Total execution time: 0.1868
DEBUG - 2022-11-20 11:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:36:17 --> Total execution time: 0.1844
DEBUG - 2022-11-20 11:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:36:24 --> Total execution time: 0.1102
DEBUG - 2022-11-20 11:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:36:55 --> Total execution time: 0.1826
DEBUG - 2022-11-20 11:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:38:51 --> Total execution time: 1.0557
DEBUG - 2022-11-20 11:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:39:24 --> Total execution time: 0.2174
DEBUG - 2022-11-20 11:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:40:23 --> Total execution time: 0.2114
DEBUG - 2022-11-20 11:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:10:43 --> No URI present. Default controller set.
DEBUG - 2022-11-20 11:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:40:44 --> Total execution time: 0.1252
DEBUG - 2022-11-20 11:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:40:51 --> Total execution time: 0.1104
DEBUG - 2022-11-20 11:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:04 --> Total execution time: 0.1855
DEBUG - 2022-11-20 11:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:05 --> Total execution time: 0.1825
DEBUG - 2022-11-20 11:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:12 --> Total execution time: 0.1863
DEBUG - 2022-11-20 11:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:22 --> Total execution time: 0.1791
DEBUG - 2022-11-20 11:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:23 --> Total execution time: 0.1754
DEBUG - 2022-11-20 11:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:27 --> Total execution time: 0.1761
DEBUG - 2022-11-20 11:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:40 --> Total execution time: 0.1793
DEBUG - 2022-11-20 11:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:52 --> Total execution time: 0.2633
DEBUG - 2022-11-20 11:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:11:55 --> No URI present. Default controller set.
DEBUG - 2022-11-20 11:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:56 --> Total execution time: 0.1169
DEBUG - 2022-11-20 11:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:59 --> Total execution time: 2.7594
DEBUG - 2022-11-20 11:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:42:16 --> Total execution time: 0.1804
DEBUG - 2022-11-20 11:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:13:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 11:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:43:40 --> Total execution time: 0.5729
DEBUG - 2022-11-20 11:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:44:10 --> Total execution time: 1.0537
DEBUG - 2022-11-20 11:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:45:27 --> Total execution time: 0.1738
DEBUG - 2022-11-20 11:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:17:34 --> No URI present. Default controller set.
DEBUG - 2022-11-20 11:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:47:34 --> Total execution time: 0.1127
DEBUG - 2022-11-20 11:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:17:49 --> No URI present. Default controller set.
DEBUG - 2022-11-20 11:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:47:49 --> Total execution time: 0.1851
DEBUG - 2022-11-20 11:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:17:58 --> Total execution time: 0.1774
DEBUG - 2022-11-20 11:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:18:00 --> Total execution time: 0.2602
DEBUG - 2022-11-20 11:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:18:01 --> Total execution time: 0.2122
DEBUG - 2022-11-20 11:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:49:02 --> Total execution time: 1.6860
DEBUG - 2022-11-20 11:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:19:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 11:19:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 11:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:19:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 11:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:49:38 --> Total execution time: 0.1856
DEBUG - 2022-11-20 11:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:49:39 --> Total execution time: 0.1794
DEBUG - 2022-11-20 11:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:49:41 --> Total execution time: 0.3354
DEBUG - 2022-11-20 11:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:49:46 --> Total execution time: 0.1850
DEBUG - 2022-11-20 11:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:19:48 --> No URI present. Default controller set.
DEBUG - 2022-11-20 11:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:49:48 --> Total execution time: 0.1116
DEBUG - 2022-11-20 11:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:49:51 --> Total execution time: 1.8413
DEBUG - 2022-11-20 11:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:49:51 --> Total execution time: 0.8522
DEBUG - 2022-11-20 11:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:49:59 --> Total execution time: 0.1810
DEBUG - 2022-11-20 11:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:50:08 --> Total execution time: 0.1750
DEBUG - 2022-11-20 11:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:50:16 --> Total execution time: 0.2178
DEBUG - 2022-11-20 11:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:50:27 --> Total execution time: 0.1860
DEBUG - 2022-11-20 11:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:50:34 --> Total execution time: 0.1724
DEBUG - 2022-11-20 11:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:50:59 --> Total execution time: 0.1847
DEBUG - 2022-11-20 11:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:52:17 --> Total execution time: 0.1720
DEBUG - 2022-11-20 11:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:52:52 --> Total execution time: 0.1732
DEBUG - 2022-11-20 11:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:53:22 --> Total execution time: 0.1974
DEBUG - 2022-11-20 11:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:53:27 --> Total execution time: 0.2972
DEBUG - 2022-11-20 11:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 11:23:34 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 11:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:23:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 11:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:53:39 --> Total execution time: 0.1132
DEBUG - 2022-11-20 11:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:53:57 --> Total execution time: 0.1805
DEBUG - 2022-11-20 11:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:54:01 --> Total execution time: 0.2572
DEBUG - 2022-11-20 11:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:54:08 --> Total execution time: 0.2324
DEBUG - 2022-11-20 11:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:54:14 --> Total execution time: 0.1812
DEBUG - 2022-11-20 11:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:54:24 --> Total execution time: 0.1770
DEBUG - 2022-11-20 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:24:27 --> No URI present. Default controller set.
DEBUG - 2022-11-20 11:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:54:27 --> Total execution time: 0.1521
DEBUG - 2022-11-20 11:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:54:41 --> Total execution time: 0.1379
DEBUG - 2022-11-20 11:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:54:47 --> Total execution time: 0.1793
DEBUG - 2022-11-20 11:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:54:47 --> Total execution time: 0.1806
DEBUG - 2022-11-20 11:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:54:54 --> Total execution time: 0.1805
DEBUG - 2022-11-20 11:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:55:01 --> Total execution time: 0.1770
DEBUG - 2022-11-20 11:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:55:02 --> Total execution time: 0.3051
DEBUG - 2022-11-20 11:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:55:18 --> Total execution time: 0.1677
DEBUG - 2022-11-20 11:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:55:21 --> Total execution time: 0.1775
DEBUG - 2022-11-20 11:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:55:25 --> Total execution time: 0.1780
DEBUG - 2022-11-20 11:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:26:15 --> No URI present. Default controller set.
DEBUG - 2022-11-20 11:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:56:15 --> Total execution time: 0.1099
DEBUG - 2022-11-20 11:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:26:16 --> No URI present. Default controller set.
DEBUG - 2022-11-20 11:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:56:16 --> Total execution time: 0.1095
DEBUG - 2022-11-20 11:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:56:23 --> Total execution time: 0.1803
DEBUG - 2022-11-20 11:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:56:58 --> Total execution time: 0.1761
DEBUG - 2022-11-20 11:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:27:48 --> No URI present. Default controller set.
DEBUG - 2022-11-20 11:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:57:48 --> Total execution time: 0.1135
DEBUG - 2022-11-20 11:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:58:26 --> Total execution time: 0.1796
DEBUG - 2022-11-20 11:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:58:40 --> Total execution time: 0.1986
DEBUG - 2022-11-20 11:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:58:53 --> Total execution time: 0.2141
DEBUG - 2022-11-20 11:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:59:05 --> Total execution time: 0.1805
DEBUG - 2022-11-20 11:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:59:15 --> Total execution time: 0.1937
DEBUG - 2022-11-20 11:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:59:27 --> Total execution time: 0.2263
DEBUG - 2022-11-20 11:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:59:42 --> Total execution time: 0.1815
DEBUG - 2022-11-20 11:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:59:51 --> Total execution time: 0.1940
DEBUG - 2022-11-20 11:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:00:07 --> Total execution time: 0.1795
DEBUG - 2022-11-20 11:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:00:36 --> Total execution time: 0.1713
DEBUG - 2022-11-20 11:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:00:59 --> Total execution time: 0.1738
DEBUG - 2022-11-20 11:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:32:13 --> No URI present. Default controller set.
DEBUG - 2022-11-20 11:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:02:13 --> Total execution time: 0.1377
DEBUG - 2022-11-20 11:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 11:32:52 --> 404 Page Not Found: Bonfoto-b690a-camera-tripod-for-travellightweight-aluminum-portable-dslr-tripod-214834html/index
DEBUG - 2022-11-20 11:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 11:34:44 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 11:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:08:17 --> Total execution time: 0.1093
DEBUG - 2022-11-20 11:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:08:31 --> Total execution time: 0.1744
DEBUG - 2022-11-20 11:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:08:53 --> Total execution time: 0.2287
DEBUG - 2022-11-20 11:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:39:32 --> Total execution time: 0.1808
DEBUG - 2022-11-20 11:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:09:39 --> Total execution time: 0.1940
DEBUG - 2022-11-20 11:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:09:48 --> Total execution time: 0.1884
DEBUG - 2022-11-20 11:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:12:43 --> Total execution time: 0.1706
DEBUG - 2022-11-20 11:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:44:36 --> No URI present. Default controller set.
DEBUG - 2022-11-20 11:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:14:36 --> Total execution time: 0.1393
DEBUG - 2022-11-20 11:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:15:17 --> Total execution time: 0.2112
DEBUG - 2022-11-20 11:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:15:32 --> Total execution time: 0.1984
DEBUG - 2022-11-20 11:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:16:08 --> Total execution time: 0.1810
DEBUG - 2022-11-20 11:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:16:24 --> Total execution time: 0.1787
DEBUG - 2022-11-20 11:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:47:46 --> Total execution time: 0.1118
DEBUG - 2022-11-20 11:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:17:51 --> Total execution time: 0.1751
DEBUG - 2022-11-20 11:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:47:52 --> Total execution time: 0.1806
DEBUG - 2022-11-20 11:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:18:00 --> Total execution time: 0.1704
DEBUG - 2022-11-20 11:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:18:03 --> Total execution time: 0.2054
DEBUG - 2022-11-20 11:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:18:10 --> Total execution time: 0.2704
DEBUG - 2022-11-20 11:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:18:13 --> Total execution time: 0.2174
DEBUG - 2022-11-20 11:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:18:15 --> Total execution time: 0.2378
DEBUG - 2022-11-20 11:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:18:15 --> Total execution time: 0.2059
DEBUG - 2022-11-20 11:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:18:16 --> Total execution time: 0.2325
DEBUG - 2022-11-20 11:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:18:16 --> Total execution time: 0.3003
DEBUG - 2022-11-20 11:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:18:17 --> Total execution time: 0.2066
DEBUG - 2022-11-20 11:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:18:17 --> Total execution time: 0.2240
DEBUG - 2022-11-20 11:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:18:48 --> Total execution time: 0.1816
DEBUG - 2022-11-20 11:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:18:58 --> Total execution time: 0.2250
DEBUG - 2022-11-20 11:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:04 --> Total execution time: 0.1799
DEBUG - 2022-11-20 11:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:09 --> Total execution time: 0.2102
DEBUG - 2022-11-20 11:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:10 --> Total execution time: 0.2259
DEBUG - 2022-11-20 11:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:10 --> Total execution time: 0.2243
DEBUG - 2022-11-20 11:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:11 --> Total execution time: 0.2155
DEBUG - 2022-11-20 11:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:11 --> Total execution time: 0.2124
DEBUG - 2022-11-20 11:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:12 --> Total execution time: 0.2129
DEBUG - 2022-11-20 11:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:14 --> Total execution time: 0.2146
DEBUG - 2022-11-20 11:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:14 --> Total execution time: 0.2072
DEBUG - 2022-11-20 11:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:15 --> Total execution time: 0.2144
DEBUG - 2022-11-20 11:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:16 --> Total execution time: 0.1873
DEBUG - 2022-11-20 11:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:18 --> Total execution time: 0.1884
DEBUG - 2022-11-20 11:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:18 --> Total execution time: 0.2052
DEBUG - 2022-11-20 11:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:19 --> Total execution time: 0.2101
DEBUG - 2022-11-20 11:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:36 --> Total execution time: 0.1109
DEBUG - 2022-11-20 11:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 11:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:20:09 --> Total execution time: 0.2016
DEBUG - 2022-11-20 11:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:20:16 --> Total execution time: 0.2159
DEBUG - 2022-11-20 11:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:20:18 --> Total execution time: 0.4894
DEBUG - 2022-11-20 11:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:21:54 --> Total execution time: 0.2388
DEBUG - 2022-11-20 11:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:11 --> Total execution time: 0.4875
DEBUG - 2022-11-20 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:36 --> Total execution time: 0.2095
DEBUG - 2022-11-20 11:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:58 --> Total execution time: 0.1799
DEBUG - 2022-11-20 11:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:24:33 --> Total execution time: 0.2115
DEBUG - 2022-11-20 11:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:25:30 --> Total execution time: 0.1897
DEBUG - 2022-11-20 11:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:26:22 --> Total execution time: 0.2301
DEBUG - 2022-11-20 11:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:26:30 --> Total execution time: 0.1710
DEBUG - 2022-11-20 11:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:26:49 --> Total execution time: 0.2415
DEBUG - 2022-11-20 11:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:27:45 --> Total execution time: 0.5108
DEBUG - 2022-11-20 11:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:27:49 --> Total execution time: 0.2196
DEBUG - 2022-11-20 11:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 11:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:29:11 --> Total execution time: 0.4625
DEBUG - 2022-11-20 11:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 11:59:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 11:59:18 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 12:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:30:02 --> Total execution time: 0.1676
DEBUG - 2022-11-20 12:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:30:34 --> Total execution time: 0.1897
DEBUG - 2022-11-20 12:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:30:42 --> Total execution time: 0.1735
DEBUG - 2022-11-20 12:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:30:52 --> Total execution time: 0.2203
DEBUG - 2022-11-20 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:31:43 --> Total execution time: 0.1768
DEBUG - 2022-11-20 12:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:32:14 --> Total execution time: 0.2157
DEBUG - 2022-11-20 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:04:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 12:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:34:38 --> Total execution time: 0.1322
DEBUG - 2022-11-20 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 12:04:38 --> 404 Page Not Found: Boys-hurley-size-5-sweater-knit-joggers-540288html/index
DEBUG - 2022-11-20 12:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:04:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 12:04:39 --> 404 Page Not Found: Microsoft-windows-10-pro-64bit-dvd-key-1065726html/index
DEBUG - 2022-11-20 12:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:08:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 12:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:38:39 --> Total execution time: 0.2019
DEBUG - 2022-11-20 12:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 12:08:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 12:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 12:08:39 --> 404 Page Not Found: Vince-camuto-womens-geometric-black-white-ruched-sides-size-small-dress-keyhole-906555html/index
DEBUG - 2022-11-20 12:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:08:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 12:08:40 --> 404 Page Not Found: Hempz-bathing-beauty-cleanse-hydrate-4947html/index
DEBUG - 2022-11-20 12:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:08:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 12:08:40 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 12:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:38:55 --> Total execution time: 0.1105
DEBUG - 2022-11-20 12:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:09:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 12:09:06 --> 404 Page Not Found: Coca-cola-merry-christmas-santa-train-jim-shore-637336html/index
DEBUG - 2022-11-20 12:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:39:09 --> Total execution time: 0.2266
DEBUG - 2022-11-20 12:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:39:10 --> Total execution time: 0.1885
DEBUG - 2022-11-20 12:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:39:18 --> Total execution time: 0.2070
DEBUG - 2022-11-20 12:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:39:29 --> Total execution time: 0.1889
DEBUG - 2022-11-20 12:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:41:10 --> Total execution time: 0.5200
DEBUG - 2022-11-20 12:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:14:06 --> No URI present. Default controller set.
DEBUG - 2022-11-20 12:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:44:07 --> Total execution time: 0.6103
DEBUG - 2022-11-20 12:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 12:14:07 --> 404 Page Not Found: Nume-pink-hair-curling-wand-25mm-1250427html/index
DEBUG - 2022-11-20 12:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:16:14 --> No URI present. Default controller set.
DEBUG - 2022-11-20 12:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:14 --> Total execution time: 0.1152
DEBUG - 2022-11-20 12:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:17:51 --> No URI present. Default controller set.
DEBUG - 2022-11-20 12:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:47:51 --> Total execution time: 0.1098
DEBUG - 2022-11-20 12:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:18:20 --> Total execution time: 0.1764
DEBUG - 2022-11-20 12:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:18:23 --> Total execution time: 0.2132
DEBUG - 2022-11-20 12:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:18:23 --> Total execution time: 0.1680
DEBUG - 2022-11-20 12:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:18:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 12:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:18:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 12:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:48:38 --> Total execution time: 0.1937
DEBUG - 2022-11-20 12:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:48:38 --> Total execution time: 0.1119
DEBUG - 2022-11-20 12:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:19:03 --> Total execution time: 0.1109
DEBUG - 2022-11-20 12:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:19:05 --> Total execution time: 0.1809
DEBUG - 2022-11-20 12:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:19:05 --> Total execution time: 0.1693
DEBUG - 2022-11-20 12:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:19:07 --> No URI present. Default controller set.
DEBUG - 2022-11-20 12:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:07 --> Total execution time: 0.1846
DEBUG - 2022-11-20 12:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:19:18 --> No URI present. Default controller set.
DEBUG - 2022-11-20 12:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:18 --> Total execution time: 0.1659
DEBUG - 2022-11-20 12:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:23 --> Total execution time: 0.1930
DEBUG - 2022-11-20 12:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:41 --> Total execution time: 0.1706
DEBUG - 2022-11-20 12:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:42 --> Total execution time: 0.1792
DEBUG - 2022-11-20 12:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:50:02 --> Total execution time: 0.3064
DEBUG - 2022-11-20 12:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:50:08 --> Total execution time: 0.1635
DEBUG - 2022-11-20 12:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:20:13 --> Total execution time: 0.1922
DEBUG - 2022-11-20 12:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:20:15 --> Total execution time: 0.1694
DEBUG - 2022-11-20 12:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:20:15 --> Total execution time: 0.3787
DEBUG - 2022-11-20 12:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:50:18 --> Total execution time: 0.1738
DEBUG - 2022-11-20 12:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:50:24 --> Total execution time: 0.1890
DEBUG - 2022-11-20 12:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:50:31 --> Total execution time: 0.1814
DEBUG - 2022-11-20 12:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:50:33 --> Total execution time: 0.1683
DEBUG - 2022-11-20 12:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:50:33 --> Total execution time: 0.1810
DEBUG - 2022-11-20 12:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:50:43 --> Total execution time: 0.1725
DEBUG - 2022-11-20 12:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:51:10 --> Total execution time: 0.1769
DEBUG - 2022-11-20 12:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:51:13 --> Total execution time: 0.2042
DEBUG - 2022-11-20 12:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:51:20 --> Total execution time: 0.2129
DEBUG - 2022-11-20 12:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:51:30 --> Total execution time: 0.1885
DEBUG - 2022-11-20 12:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:52:31 --> Total execution time: 0.4869
DEBUG - 2022-11-20 12:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:52:31 --> Total execution time: 0.1723
DEBUG - 2022-11-20 12:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:52:41 --> Total execution time: 0.1924
DEBUG - 2022-11-20 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:52:57 --> Total execution time: 0.2055
DEBUG - 2022-11-20 12:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:26:26 --> No URI present. Default controller set.
DEBUG - 2022-11-20 12:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:56:27 --> Total execution time: 0.1900
DEBUG - 2022-11-20 12:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:26:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 12:26:29 --> 404 Page Not Found: Contact/index
DEBUG - 2022-11-20 12:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:56:47 --> Total execution time: 0.1867
DEBUG - 2022-11-20 12:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:56:58 --> Total execution time: 0.1798
DEBUG - 2022-11-20 12:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:57:31 --> Total execution time: 0.1823
DEBUG - 2022-11-20 12:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:57:40 --> Total execution time: 0.4667
DEBUG - 2022-11-20 12:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:57:50 --> Total execution time: 0.2266
DEBUG - 2022-11-20 12:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:58:01 --> Total execution time: 0.2113
DEBUG - 2022-11-20 12:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:58:23 --> Total execution time: 0.2111
DEBUG - 2022-11-20 12:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:58:27 --> Total execution time: 0.2181
DEBUG - 2022-11-20 12:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:58:54 --> Total execution time: 0.2663
DEBUG - 2022-11-20 12:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:59:49 --> Total execution time: 0.2236
DEBUG - 2022-11-20 12:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:59:57 --> Total execution time: 0.1866
DEBUG - 2022-11-20 12:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:30:03 --> Total execution time: 0.2239
DEBUG - 2022-11-20 12:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:32:22 --> Total execution time: 0.1773
DEBUG - 2022-11-20 12:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:34:45 --> No URI present. Default controller set.
DEBUG - 2022-11-20 12:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:43:08 --> No URI present. Default controller set.
DEBUG - 2022-11-20 12:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:43:44 --> No URI present. Default controller set.
DEBUG - 2022-11-20 12:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:53:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 12:53:06 --> 404 Page Not Found: Teacher/subhash-chhabra
DEBUG - 2022-11-20 12:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 12:53:34 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 12:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:53:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 12:53:39 --> 404 Page Not Found: Coach-purse-816525html/index
DEBUG - 2022-11-20 12:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:55:27 --> No URI present. Default controller set.
DEBUG - 2022-11-20 12:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 12:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 12:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 12:59:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 12:59:07 --> 404 Page Not Found: Dell-latitude-5410-notebook-474479html/index
DEBUG - 2022-11-20 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:04:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 13:04:44 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 13:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:07:44 --> No URI present. Default controller set.
DEBUG - 2022-11-20 13:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 13:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:19:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 13:19:03 --> 404 Page Not Found: Hp-check-printer-225737html/index
DEBUG - 2022-11-20 13:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:20:00 --> No URI present. Default controller set.
DEBUG - 2022-11-20 13:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 13:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 13:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:29:18 --> No URI present. Default controller set.
DEBUG - 2022-11-20 13:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 13:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:34:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 13:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 13:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:34:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 13:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 13:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 13:34:39 --> 404 Page Not Found: 18-watercolor-pencils-plus-half-pan-metallic-gold-620855html/index
DEBUG - 2022-11-20 13:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:37:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 13:37:12 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 13:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:38:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 13:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 13:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:38:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 13:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 13:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:38:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 13:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 13:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 13:38:39 --> 404 Page Not Found: Read-mini-rodini-panda-sweater-9298-934552html/index
DEBUG - 2022-11-20 13:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:44:06 --> No URI present. Default controller set.
DEBUG - 2022-11-20 13:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 13:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 13:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 13:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 13:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 13:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:00:25 --> No URI present. Default controller set.
DEBUG - 2022-11-20 14:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:01:01 --> No URI present. Default controller set.
DEBUG - 2022-11-20 14:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:03:34 --> No URI present. Default controller set.
DEBUG - 2022-11-20 14:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:03:34 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 14:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:09:54 --> No URI present. Default controller set.
DEBUG - 2022-11-20 14:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:10:22 --> No URI present. Default controller set.
DEBUG - 2022-11-20 14:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:10:43 --> No URI present. Default controller set.
DEBUG - 2022-11-20 14:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:13:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:13:35 --> 404 Page Not Found: Grey-white-fur-poncho-988258html/index
DEBUG - 2022-11-20 14:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:23:34 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 14:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:23:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 14:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:23:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 14:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:34:44 --> No URI present. Default controller set.
DEBUG - 2022-11-20 14:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:38:09 --> No URI present. Default controller set.
DEBUG - 2022-11-20 14:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:40:49 --> No URI present. Default controller set.
DEBUG - 2022-11-20 14:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:41:25 --> No URI present. Default controller set.
DEBUG - 2022-11-20 14:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:44:34 --> No URI present. Default controller set.
DEBUG - 2022-11-20 14:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:48:34 --> No URI present. Default controller set.
DEBUG - 2022-11-20 14:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:52:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:52:35 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-11-20 14:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:52:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:52:35 --> 404 Page Not Found: Tips-to-developing-a-quality-discussion/esalestrix.in
DEBUG - 2022-11-20 14:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:52:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:52:42 --> 404 Page Not Found: Cart/esalestrix.in
DEBUG - 2022-11-20 14:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:52:43 --> No URI present. Default controller set.
DEBUG - 2022-11-20 14:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 14:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:52:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:52:43 --> 404 Page Not Found: Event/ted-talks-at-ucf-college-of-education
DEBUG - 2022-11-20 14:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 14:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:52:46 --> 404 Page Not Found: Author/admin
DEBUG - 2022-11-20 14:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:52:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:52:47 --> 404 Page Not Found: Teacher_cat/teacher
DEBUG - 2022-11-20 14:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:52:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:52:47 --> 404 Page Not Found: Wp-admin/index
DEBUG - 2022-11-20 14:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:52:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:52:52 --> 404 Page Not Found: Membership-account/membership-checkout
DEBUG - 2022-11-20 14:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:52:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:52:52 --> 404 Page Not Found: Product-category/uncategorized
DEBUG - 2022-11-20 14:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:52:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:52:57 --> 404 Page Not Found: Esalestrixin/index
DEBUG - 2022-11-20 14:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:53:03 --> 404 Page Not Found: Xmlrpcphp/index
DEBUG - 2022-11-20 14:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:53:03 --> 404 Page Not Found: Event/service-tuesday-cradles-to-crayons-school-kits
DEBUG - 2022-11-20 14:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:53:03 --> 404 Page Not Found: Category/academics
DEBUG - 2022-11-20 14:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:53:04 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-11-20 14:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:53:04 --> 404 Page Not Found: Events/page
DEBUG - 2022-11-20 14:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 14:59:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 14:59:18 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:04:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 15:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 15:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 15:04:38 --> 404 Page Not Found: Nct-127-2-baddies-album-714127html/index
DEBUG - 2022-11-20 15:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:04:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 15:04:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 15:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:05:14 --> No URI present. Default controller set.
DEBUG - 2022-11-20 15:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 15:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:07:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 15:07:09 --> 404 Page Not Found: Fossil-green-leather-crossbody-bag-813886html/index
DEBUG - 2022-11-20 15:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 15:08:39 --> 404 Page Not Found: Silver-rhinestone-pave-crystal-heart-pendant-toggle-closure-chain-190358html/index
DEBUG - 2022-11-20 15:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 15:08:39 --> 404 Page Not Found: Dave-fetty-fenton-vases-121389html/index
DEBUG - 2022-11-20 15:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:08:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 15:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 15:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:14:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 15:14:06 --> 404 Page Not Found: Maison-francis-kurkdjian-paris-oud-silk-mood-extrait-de-parfum-full-24oz-423092html/index
DEBUG - 2022-11-20 15:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:33:34 --> No URI present. Default controller set.
DEBUG - 2022-11-20 15:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 15:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:34:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 15:34:34 --> 404 Page Not Found: Terms/index
DEBUG - 2022-11-20 15:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:47:43 --> No URI present. Default controller set.
DEBUG - 2022-11-20 15:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 15:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 15:53:34 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 15:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:53:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 15:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 15:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:53:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 15:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 15:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:57:04 --> No URI present. Default controller set.
DEBUG - 2022-11-20 15:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 15:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 15:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 15:57:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 15:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 15:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 16:00:43 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 16:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 16:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:04:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 16:04:44 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 16:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:04:46 --> No URI present. Default controller set.
DEBUG - 2022-11-20 16:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 16:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 16:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 16:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 16:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 16:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 16:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 16:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 16:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:14:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 16:14:47 --> 404 Page Not Found: Justice-backpack-291877html/index
DEBUG - 2022-11-20 16:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:14:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 16:14:47 --> 404 Page Not Found: Onix-stryker-4-graphite-pickleball-paddle-544595html/index
DEBUG - 2022-11-20 16:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 16:34:38 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 16:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 16:34:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 16:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 16:34:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 16:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:37:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 16:37:17 --> 404 Page Not Found: Kids-games-new-watch-ya39-mouth-throwdown-edition-4-or-more-players-game-ages-8-591141html/index
DEBUG - 2022-11-20 16:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 16:38:39 --> 404 Page Not Found: Abercrombie-kids-boys-gray-sweatpants-boys-1112-127210html/index
DEBUG - 2022-11-20 16:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:43:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 16:43:55 --> 404 Page Not Found: Squishmallows-12-wade-the-werewolfskeleton-halloween-2022-new-select-series-366024html/index
DEBUG - 2022-11-20 16:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 16:45:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 16:45:45 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 17:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 17:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 17:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 17:04:11 --> No URI present. Default controller set.
DEBUG - 2022-11-20 17:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 17:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 17:04:46 --> No URI present. Default controller set.
DEBUG - 2022-11-20 17:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 17:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 17:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 17:14:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 17:14:18 --> 404 Page Not Found: Bathbodyworks-golden-sunflower-fragrance-mist-body-cream-403061html/index
DEBUG - 2022-11-20 17:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 17:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 17:16:18 --> 404 Page Not Found: Blue-rose-polish-pottery-851-zaklady-large-serving-bowl-565836html/index
DEBUG - 2022-11-20 17:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 17:30:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 17:30:48 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 17:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 17:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 17:34:44 --> 404 Page Not Found: Apple-iphone-xs-space-gray-64gb-a1920-unlocked-557238html/index
DEBUG - 2022-11-20 17:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 17:59:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 17:59:18 --> 404 Page Not Found: Listed-italian-american-artist-frederick-massa-429114html/index
DEBUG - 2022-11-20 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:04:38 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 18:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:04:38 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 18:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:04:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:04:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 18:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:06:01 --> No URI present. Default controller set.
DEBUG - 2022-11-20 18:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:08:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 18:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:13:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:13:40 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 18:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:13:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:13:40 --> 404 Page Not Found: Rainbow-adventurer-rainbow-glowing-dice-1238358html/index
DEBUG - 2022-11-20 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:13:41 --> No URI present. Default controller set.
DEBUG - 2022-11-20 18:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:13:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:13:41 --> 404 Page Not Found: Louisville-slugger-youth-baseball-mitt-210164html/index
DEBUG - 2022-11-20 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:13:41 --> No URI present. Default controller set.
DEBUG - 2022-11-20 18:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:13:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:13:41 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:13:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:13:41 --> 404 Page Not Found: Belana-squishmallow-97971html/index
DEBUG - 2022-11-20 18:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:14:51 --> 404 Page Not Found: Primark-exclusive-disney-monsters-inc-sulley-christmas-ornament-bauble-832005html/index
DEBUG - 2022-11-20 18:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:24:22 --> No URI present. Default controller set.
DEBUG - 2022-11-20 18:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:36:10 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 18:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:53:04 --> No URI present. Default controller set.
DEBUG - 2022-11-20 18:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:05 --> No URI present. Default controller set.
DEBUG - 2022-11-20 18:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:58:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:58:40 --> 404 Page Not Found: American-eagle-jegging-jeans-tie-dye-2-62014html/index
DEBUG - 2022-11-20 18:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:58:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:58:41 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 18:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:58:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:58:41 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 18:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:58:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:58:41 --> 404 Page Not Found: 2021-prizm-hype-inserts-justin-herbert-joe-burrow-tua-tagovailoa-734239html/index
DEBUG - 2022-11-20 18:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:58:41 --> No URI present. Default controller set.
DEBUG - 2022-11-20 18:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 18:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 18:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 18:58:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 18:58:41 --> 404 Page Not Found: Abercrombie-kids-sparkly-shirt-723887html/index
DEBUG - 2022-11-20 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:02:24 --> No URI present. Default controller set.
DEBUG - 2022-11-20 19:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:04:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 19:04:44 --> 404 Page Not Found: Landour-reversible-percale-cotton-comforter-set-yellow-heirlooms-of-india-271510html/index
DEBUG - 2022-11-20 19:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:12:51 --> No URI present. Default controller set.
DEBUG - 2022-11-20 19:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:13:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 19:13:24 --> 404 Page Not Found: 10-lululemon-shorts-with-liner-1043810html/index
DEBUG - 2022-11-20 19:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:16:02 --> No URI present. Default controller set.
DEBUG - 2022-11-20 19:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:16:20 --> Total execution time: 0.1819
DEBUG - 2022-11-20 19:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:16:21 --> Total execution time: 0.1855
DEBUG - 2022-11-20 19:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:16:22 --> Total execution time: 0.1692
DEBUG - 2022-11-20 19:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:16:24 --> Total execution time: 0.3253
DEBUG - 2022-11-20 19:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:16:24 --> Total execution time: 0.5595
DEBUG - 2022-11-20 19:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:17:12 --> Total execution time: 0.2092
DEBUG - 2022-11-20 19:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:17:14 --> Total execution time: 0.2175
DEBUG - 2022-11-20 19:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:17:14 --> Total execution time: 0.1707
DEBUG - 2022-11-20 19:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:17:56 --> No URI present. Default controller set.
DEBUG - 2022-11-20 19:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 19:18:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-20 19:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 19:21:10 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 19:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:24:54 --> No URI present. Default controller set.
DEBUG - 2022-11-20 19:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:26:23 --> No URI present. Default controller set.
DEBUG - 2022-11-20 19:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:28:02 --> Total execution time: 0.1132
DEBUG - 2022-11-20 19:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:28:04 --> Total execution time: 0.2524
DEBUG - 2022-11-20 19:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:28:05 --> Total execution time: 0.1908
DEBUG - 2022-11-20 19:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:28:17 --> No URI present. Default controller set.
DEBUG - 2022-11-20 19:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 19:29:18 --> 404 Page Not Found: Adidas-sneakers-for-boys-712255html/index
DEBUG - 2022-11-20 19:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 19:34:38 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 19:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 19:34:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 19:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 19:34:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 19:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:38:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 19:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 19:38:39 --> 404 Page Not Found: Back-pack-355953html/index
DEBUG - 2022-11-20 19:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:38:40 --> Total execution time: 0.1896
DEBUG - 2022-11-20 19:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:38:42 --> Total execution time: 0.2223
DEBUG - 2022-11-20 19:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:38:42 --> Total execution time: 0.4433
DEBUG - 2022-11-20 19:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:38:54 --> Total execution time: 0.1780
DEBUG - 2022-11-20 19:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:38:56 --> Total execution time: 0.1733
DEBUG - 2022-11-20 19:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:38:56 --> Total execution time: 0.4286
DEBUG - 2022-11-20 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:42:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 19:42:32 --> 404 Page Not Found: Everything-everywhere-all-at-once-769636html/index
DEBUG - 2022-11-20 19:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:43:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 19:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:43:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 19:43:40 --> 404 Page Not Found: Boots-67380html/index
DEBUG - 2022-11-20 19:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:43:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 19:43:41 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 19:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 19:44:07 --> 404 Page Not Found: Icp-bundle-for-gage-884178html/index
DEBUG - 2022-11-20 19:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:47:52 --> No URI present. Default controller set.
DEBUG - 2022-11-20 19:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:48:49 --> No URI present. Default controller set.
DEBUG - 2022-11-20 19:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:51:10 --> No URI present. Default controller set.
DEBUG - 2022-11-20 19:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:52:23 --> No URI present. Default controller set.
DEBUG - 2022-11-20 19:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:57:30 --> No URI present. Default controller set.
DEBUG - 2022-11-20 19:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 19:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 19:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 19:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 20:02:01 --> 404 Page Not Found: Clutch-wallets-for-women-179497html/index
DEBUG - 2022-11-20 20:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:02:45 --> No URI present. Default controller set.
DEBUG - 2022-11-20 20:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:03:56 --> No URI present. Default controller set.
DEBUG - 2022-11-20 20:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:09:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 20:09:53 --> 404 Page Not Found: Horimiya-vol-15-1041618html/index
DEBUG - 2022-11-20 20:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:11:30 --> No URI present. Default controller set.
DEBUG - 2022-11-20 20:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:23:46 --> No URI present. Default controller set.
DEBUG - 2022-11-20 20:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:33:34 --> No URI present. Default controller set.
DEBUG - 2022-11-20 20:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 20:34:44 --> 404 Page Not Found: Jackson-softec-sport-ice-skates-with-carrying-bag-629871html/index
DEBUG - 2022-11-20 20:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:41:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 20:41:03 --> 404 Page Not Found: Nintendo-switch-oled-whiteblack-joycons-free-fast-shipping-700292html/index
DEBUG - 2022-11-20 20:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:49:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 20:49:54 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-11-20 20:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:49:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 20:49:54 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-11-20 20:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:50:34 --> No URI present. Default controller set.
DEBUG - 2022-11-20 20:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:50:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 20:50:37 --> 404 Page Not Found: Matilda-jane-and-joana-gaines-dress-619541html/index
DEBUG - 2022-11-20 20:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 20:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 20:59:18 --> No URI present. Default controller set.
DEBUG - 2022-11-20 20:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 20:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:00:05 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:00:20 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:00:42 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:01:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:01:48 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:03:56 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 21:04:38 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 21:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:04:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 21:04:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 21:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:04:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 21:04:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 21:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:05:05 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:06:32 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:08:04 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:08:35 --> Total execution time: 0.1756
DEBUG - 2022-11-20 21:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 21:08:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 21:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:08:45 --> Total execution time: 0.2290
DEBUG - 2022-11-20 21:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:14:52 --> Total execution time: 0.6921
DEBUG - 2022-11-20 21:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:15:00 --> Total execution time: 0.2456
DEBUG - 2022-11-20 21:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 21:19:57 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-11-20 21:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:24:03 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:27:22 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:27:34 --> Total execution time: 0.2208
DEBUG - 2022-11-20 21:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:27:36 --> Total execution time: 0.1843
DEBUG - 2022-11-20 21:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:27:36 --> Total execution time: 0.1808
DEBUG - 2022-11-20 21:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:27:48 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:33:04 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:38:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:38:38 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:38:57 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:39:52 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:40:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:42:58 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:51:02 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:53:55 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:53:55 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:55:18 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:58:18 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 21:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 21:58:39 --> No URI present. Default controller set.
DEBUG - 2022-11-20 21:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 21:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:02:53 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:03:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 22:03:23 --> 404 Page Not Found: Horimiya-vol-15-1041618html/index
DEBUG - 2022-11-20 22:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:04:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 22:04:44 --> 404 Page Not Found: Longchamp-le-pliage-tote-pink-658611html/index
DEBUG - 2022-11-20 22:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:06:04 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:06:05 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:07:23 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:07:24 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:07:35 --> Total execution time: 0.1171
DEBUG - 2022-11-20 22:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:07:37 --> Total execution time: 0.1791
DEBUG - 2022-11-20 22:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:07:38 --> Total execution time: 0.1708
DEBUG - 2022-11-20 22:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:07:43 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:07:54 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:08:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 22:08:21 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 22:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:11:31 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:14:29 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:23:06 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 22:24:09 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-20 22:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 22:24:09 --> 404 Page Not Found: Humanstxt/index
DEBUG - 2022-11-20 22:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 22:24:10 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-11-20 22:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:24:10 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:24:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 22:24:36 --> 404 Page Not Found: 15-649193html/index
DEBUG - 2022-11-20 22:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:29:18 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:30:16 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:03 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:47 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 22:34:38 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 22:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 22:34:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 22:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 22:38:39 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-20 22:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:39:18 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:41:15 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:47:34 --> No URI present. Default controller set.
DEBUG - 2022-11-20 22:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 22:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 22:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 22:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 22:54:59 --> 404 Page Not Found: Samsung-galaxy-z-flip-3-5g-256-gb-unlocked-732219html/index
DEBUG - 2022-11-20 23:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:08:33 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:09:51 --> Total execution time: 0.1164
DEBUG - 2022-11-20 23:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:12:00 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:12:02 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:16:14 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:20:37 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:21:10 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:08 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:40 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:48 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:14 --> Total execution time: 0.1794
DEBUG - 2022-11-20 23:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:27:58 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:30:29 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:31:02 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:31:11 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:36:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 23:36:29 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-20 23:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:40:42 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:42:30 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:43:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 23:43:18 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-11-20 23:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:45:15 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:51:27 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:52:03 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:53:21 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:53:36 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:53:46 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:53:50 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:55:03 --> No URI present. Default controller set.
DEBUG - 2022-11-20 23:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-20 23:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-20 23:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-20 23:59:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-20 23:59:18 --> 404 Page Not Found: Xbox-one-s-500gb-bundle-394987html/index
