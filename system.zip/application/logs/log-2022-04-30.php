<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-30 00:38:28 --> Total execution time: 0.9260
DEBUG - 2022-04-30 00:38:37 --> Total execution time: 0.0281
DEBUG - 2022-04-30 00:39:10 --> Total execution time: 0.0631
DEBUG - 2022-04-30 00:39:12 --> Total execution time: 0.0297
DEBUG - 2022-04-30 00:39:35 --> Total execution time: 0.0318
DEBUG - 2022-04-30 00:40:00 --> Total execution time: 0.0317
DEBUG - 2022-04-30 00:40:16 --> Total execution time: 0.0775
DEBUG - 2022-04-30 00:40:47 --> Total execution time: 0.0309
DEBUG - 2022-04-30 00:40:49 --> Total execution time: 0.0462
DEBUG - 2022-04-30 00:40:55 --> Total execution time: 0.0425
DEBUG - 2022-04-30 00:41:10 --> Total execution time: 0.0488
DEBUG - 2022-04-30 00:41:15 --> Total execution time: 0.0344
DEBUG - 2022-04-30 00:41:30 --> Total execution time: 0.0434
DEBUG - 2022-04-30 00:41:36 --> Total execution time: 0.0312
DEBUG - 2022-04-30 00:41:45 --> Total execution time: 0.0369
DEBUG - 2022-04-30 00:41:48 --> Total execution time: 0.0316
DEBUG - 2022-04-30 00:41:51 --> Total execution time: 0.0330
DEBUG - 2022-04-30 00:41:57 --> Total execution time: 0.0334
DEBUG - 2022-04-30 00:42:16 --> Total execution time: 0.0310
DEBUG - 2022-04-30 00:42:20 --> Total execution time: 0.0354
DEBUG - 2022-04-30 00:42:36 --> Total execution time: 0.0351
DEBUG - 2022-04-30 00:42:50 --> Total execution time: 0.0319
DEBUG - 2022-04-30 00:43:03 --> Total execution time: 0.0321
DEBUG - 2022-04-30 00:43:05 --> Total execution time: 0.0303
DEBUG - 2022-04-30 00:43:10 --> Total execution time: 0.0335
DEBUG - 2022-04-30 00:43:36 --> Total execution time: 0.0317
DEBUG - 2022-04-30 00:43:39 --> Total execution time: 0.0377
DEBUG - 2022-04-30 01:12:18 --> Total execution time: 0.8961
DEBUG - 2022-04-30 01:37:21 --> Total execution time: 1.5279
DEBUG - 2022-04-30 02:29:56 --> Total execution time: 0.8433
DEBUG - 2022-04-30 02:30:56 --> Total execution time: 0.0300
DEBUG - 2022-04-30 02:31:28 --> Total execution time: 0.0299
DEBUG - 2022-04-30 02:32:57 --> Total execution time: 0.0700
DEBUG - 2022-04-30 02:33:42 --> Total execution time: 0.0378
DEBUG - 2022-04-30 02:37:41 --> Total execution time: 0.0707
DEBUG - 2022-04-30 02:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:05:11 --> No URI present. Default controller set.
DEBUG - 2022-04-30 02:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:35:12 --> Total execution time: 1.0920
DEBUG - 2022-04-30 02:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:35:22 --> Total execution time: 0.0484
DEBUG - 2022-04-30 02:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:35:27 --> Total execution time: 0.0984
DEBUG - 2022-04-30 02:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 02:05:33 --> 404 Page Not Found: User/leaderboard
DEBUG - 2022-04-30 02:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:43:17 --> Total execution time: 0.8242
DEBUG - 2022-04-30 02:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:47:11 --> Total execution time: 0.0321
DEBUG - 2022-04-30 02:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:50:19 --> Total execution time: 0.0387
DEBUG - 2022-04-30 02:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:53:20 --> Total execution time: 0.8251
DEBUG - 2022-04-30 02:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:54:08 --> Total execution time: 0.8251
DEBUG - 2022-04-30 02:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:35:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-30 08:05:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*' at line 2 - Invalid query: SELECT `com_FK_ul_id`, select_sum(com_commission_by)
FROM *
DEBUG - 2022-04-30 02:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:37:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-30 08:07:24 --> Severity: error --> Exception: Using $this when not in object context /home/gvprods/public_html/v1/gvv3/application/helpers/two_tier_helper.php 29
DEBUG - 2022-04-30 02:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:37:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-30 08:07:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*' at line 2 - Invalid query: SELECT SUM(`com_amount`) AS `com_amount`, `com_FK_ul_id`, `com_amount`
FROM *
DEBUG - 2022-04-30 02:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:38:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-30 08:08:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*' at line 2 - Invalid query: SELECT SUM(`com_amount`) AS `com_amount`
FROM *
DEBUG - 2022-04-30 02:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:16:46 --> Total execution time: 0.8211
DEBUG - 2022-04-30 02:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 02:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:25:28 --> Total execution time: 0.0580
DEBUG - 2022-04-30 02:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:25:45 --> Total execution time: 0.0309
DEBUG - 2022-04-30 02:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:27:35 --> Total execution time: 0.0374
DEBUG - 2022-04-30 02:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 02:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 02:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:28:42 --> Total execution time: 0.2634
DEBUG - 2022-04-30 03:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:32:25 --> Total execution time: 0.0336
DEBUG - 2022-04-30 03:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:02:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:02:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:02:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:02:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:02:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:02:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:02:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:02:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:02:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:02:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:02:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:02:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:02:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:02:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-30 03:02:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:33:45 --> Total execution time: 0.0428
DEBUG - 2022-04-30 03:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:34:14 --> Total execution time: 0.0398
DEBUG - 2022-04-30 03:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:04:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:04:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:04:34 --> UTF-8 Support Enabled
ERROR - 2022-04-30 03:04:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:04:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:04:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:04:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:04:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:04:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:36:31 --> Total execution time: 0.0388
DEBUG - 2022-04-30 03:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:06:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:06:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:06:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:06:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:06:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:06:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:06:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:06:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:06:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:06:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:06:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:06:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-30 03:06:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:06:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:06:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 03:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:36:52 --> Total execution time: 0.0343
DEBUG - 2022-04-30 03:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:37:23 --> Total execution time: 0.0324
DEBUG - 2022-04-30 03:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:39:06 --> Total execution time: 0.0447
DEBUG - 2022-04-30 03:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:39:33 --> Total execution time: 0.0322
DEBUG - 2022-04-30 03:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:40:45 --> Total execution time: 0.0315
DEBUG - 2022-04-30 03:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:41:30 --> Total execution time: 0.0321
DEBUG - 2022-04-30 03:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:11:36 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:41:36 --> Total execution time: 0.0822
DEBUG - 2022-04-30 03:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:13:39 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:43:39 --> Total execution time: 0.0315
DEBUG - 2022-04-30 03:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:15:59 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:45:59 --> Total execution time: 0.0339
DEBUG - 2022-04-30 03:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:17:14 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:47:14 --> Total execution time: 0.0290
DEBUG - 2022-04-30 03:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:21:22 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:51:22 --> Total execution time: 0.0319
DEBUG - 2022-04-30 03:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:21:24 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:51:24 --> Total execution time: 0.0320
DEBUG - 2022-04-30 03:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:21:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 03:21:25 --> 404 Page Not Found: Gvv3/assets
DEBUG - 2022-04-30 03:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:25:36 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:55:37 --> Total execution time: 0.8051
DEBUG - 2022-04-30 03:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:26:08 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:56:08 --> Total execution time: 0.0310
DEBUG - 2022-04-30 03:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:26:31 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:56:31 --> Total execution time: 0.0313
DEBUG - 2022-04-30 03:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:26:49 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:56:49 --> Total execution time: 0.0296
DEBUG - 2022-04-30 03:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:27:07 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:57:07 --> Total execution time: 0.0327
DEBUG - 2022-04-30 03:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:27:15 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:57:15 --> Total execution time: 0.0322
DEBUG - 2022-04-30 03:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:28:13 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:58:13 --> Total execution time: 0.0308
DEBUG - 2022-04-30 03:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:28:47 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:58:48 --> Total execution time: 0.0380
DEBUG - 2022-04-30 03:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:29:08 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:59:08 --> Total execution time: 0.0322
DEBUG - 2022-04-30 03:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:30:20 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:00:20 --> Total execution time: 0.0312
DEBUG - 2022-04-30 03:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:31:00 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:01:00 --> Total execution time: 0.0299
DEBUG - 2022-04-30 03:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:31:45 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:01:45 --> Total execution time: 0.0321
DEBUG - 2022-04-30 03:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:33:57 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:03:57 --> Total execution time: 0.0318
DEBUG - 2022-04-30 03:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:43:30 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:13:31 --> Total execution time: 0.8052
DEBUG - 2022-04-30 03:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:45:26 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:15:26 --> Total execution time: 0.0310
DEBUG - 2022-04-30 03:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:47:49 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:17:49 --> Total execution time: 0.7963
DEBUG - 2022-04-30 03:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:48:45 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:18:45 --> Total execution time: 0.5569
DEBUG - 2022-04-30 03:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:49:00 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:19:00 --> Total execution time: 0.4855
DEBUG - 2022-04-30 03:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:51:22 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:21:23 --> Total execution time: 0.9180
DEBUG - 2022-04-30 03:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:54:08 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:24:08 --> Total execution time: 0.8131
DEBUG - 2022-04-30 03:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:57:11 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:27:12 --> Total execution time: 0.8770
DEBUG - 2022-04-30 03:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:57:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-30 03:57:34 --> Severity: Notice --> Trying to access array offset on value of type null /home/gvprods/public_html/v1/gvv3/application/core/DB_Controller.php 49
ERROR - 2022-04-30 03:57:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/helpers/url_helper.php 564
DEBUG - 2022-04-30 03:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:57:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-30 03:57:57 --> Severity: Notice --> Trying to access array offset on value of type null /home/gvprods/public_html/v1/gvv3/application/core/DB_Controller.php 49
ERROR - 2022-04-30 03:57:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/helpers/url_helper.php 564
DEBUG - 2022-04-30 03:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 03:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:28:51 --> Total execution time: 0.0558
DEBUG - 2022-04-30 03:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 03:59:01 --> No URI present. Default controller set.
DEBUG - 2022-04-30 03:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 03:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:29:01 --> Total execution time: 0.0560
DEBUG - 2022-04-30 04:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:03:52 --> No URI present. Default controller set.
DEBUG - 2022-04-30 04:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:33:53 --> Total execution time: 1.0060
DEBUG - 2022-04-30 04:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:27:23 --> No URI present. Default controller set.
DEBUG - 2022-04-30 04:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:57:24 --> Total execution time: 0.9410
DEBUG - 2022-04-30 04:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:28:37 --> No URI present. Default controller set.
DEBUG - 2022-04-30 04:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:58:37 --> Total execution time: 0.0300
DEBUG - 2022-04-30 04:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:58:55 --> Total execution time: 0.0328
DEBUG - 2022-04-30 04:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:31:10 --> No URI present. Default controller set.
DEBUG - 2022-04-30 04:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:01:11 --> Total execution time: 0.8041
DEBUG - 2022-04-30 04:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:33:25 --> No URI present. Default controller set.
DEBUG - 2022-04-30 04:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:03:25 --> Total execution time: 0.0607
DEBUG - 2022-04-30 04:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:34:27 --> No URI present. Default controller set.
DEBUG - 2022-04-30 04:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:04:27 --> Total execution time: 0.0305
DEBUG - 2022-04-30 04:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:34:49 --> No URI present. Default controller set.
DEBUG - 2022-04-30 04:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:04:49 --> Total execution time: 0.0319
DEBUG - 2022-04-30 04:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:35:47 --> No URI present. Default controller set.
DEBUG - 2022-04-30 04:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:05:47 --> Total execution time: 0.0308
DEBUG - 2022-04-30 04:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:36:30 --> No URI present. Default controller set.
DEBUG - 2022-04-30 04:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:06:30 --> Total execution time: 0.0300
DEBUG - 2022-04-30 04:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:36:51 --> No URI present. Default controller set.
DEBUG - 2022-04-30 04:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:06:51 --> Total execution time: 0.0304
DEBUG - 2022-04-30 04:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:41:48 --> No URI present. Default controller set.
DEBUG - 2022-04-30 04:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:11:49 --> Total execution time: 0.8051
DEBUG - 2022-04-30 04:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:43:25 --> No URI present. Default controller set.
DEBUG - 2022-04-30 04:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:13:25 --> Total execution time: 0.0303
DEBUG - 2022-04-30 04:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:43:57 --> No URI present. Default controller set.
DEBUG - 2022-04-30 04:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:13:58 --> Total execution time: 0.0315
DEBUG - 2022-04-30 04:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 04:59:56 --> No URI present. Default controller set.
DEBUG - 2022-04-30 04:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 04:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:29:57 --> Total execution time: 0.8052
DEBUG - 2022-04-30 05:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:03:26 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:33:27 --> Total execution time: 0.8042
DEBUG - 2022-04-30 05:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:04:25 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:34:25 --> Total execution time: 0.0357
DEBUG - 2022-04-30 05:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:05:04 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:35:04 --> Total execution time: 0.0469
DEBUG - 2022-04-30 05:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:07:24 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:37:24 --> Total execution time: 0.5872
DEBUG - 2022-04-30 05:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:09:00 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:39:00 --> Total execution time: 0.0307
DEBUG - 2022-04-30 05:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:10:00 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:40:00 --> Total execution time: 0.0299
DEBUG - 2022-04-30 05:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:10:13 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:40:13 --> Total execution time: 0.0331
DEBUG - 2022-04-30 05:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:11:15 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:41:15 --> Total execution time: 0.0336
DEBUG - 2022-04-30 05:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:12:14 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:42:14 --> Total execution time: 0.0292
DEBUG - 2022-04-30 05:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:13:43 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:43:43 --> Total execution time: 0.0326
DEBUG - 2022-04-30 05:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:15:06 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:45:06 --> Total execution time: 0.0425
DEBUG - 2022-04-30 05:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:15:29 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:45:29 --> Total execution time: 0.0341
DEBUG - 2022-04-30 05:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:15:37 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:45:37 --> Total execution time: 0.0310
DEBUG - 2022-04-30 05:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:17:36 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:47:37 --> Total execution time: 0.8051
DEBUG - 2022-04-30 05:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:17:39 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:47:39 --> Total execution time: 0.0315
DEBUG - 2022-04-30 05:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:18:17 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:48:17 --> Total execution time: 0.0321
DEBUG - 2022-04-30 05:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 05:18:43 --> No URI present. Default controller set.
DEBUG - 2022-04-30 05:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 05:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:48:43 --> Total execution time: 0.0306
DEBUG - 2022-04-30 06:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 06:10:43 --> No URI present. Default controller set.
DEBUG - 2022-04-30 06:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 06:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 11:40:44 --> Total execution time: 0.8331
DEBUG - 2022-04-30 06:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 06:24:50 --> No URI present. Default controller set.
DEBUG - 2022-04-30 06:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 06:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 11:54:50 --> Total execution time: 0.8331
DEBUG - 2022-04-30 06:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 06:25:00 --> No URI present. Default controller set.
DEBUG - 2022-04-30 06:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 06:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 11:55:00 --> Total execution time: 0.0309
DEBUG - 2022-04-30 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 06:33:16 --> No URI present. Default controller set.
DEBUG - 2022-04-30 06:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 06:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:03:17 --> Total execution time: 0.8321
DEBUG - 2022-04-30 06:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 06:34:23 --> No URI present. Default controller set.
DEBUG - 2022-04-30 06:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 06:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:04:24 --> Total execution time: 0.5464
DEBUG - 2022-04-30 07:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:16:44 --> No URI present. Default controller set.
DEBUG - 2022-04-30 07:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:46:45 --> Total execution time: 1.0430
DEBUG - 2022-04-30 07:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:49:17 --> Total execution time: 0.0444
DEBUG - 2022-04-30 07:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:49:21 --> Total execution time: 0.0923
DEBUG - 2022-04-30 07:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:50:12 --> Total execution time: 0.0303
DEBUG - 2022-04-30 07:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:21:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:21:15 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-30 07:21:15 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-30 07:21:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 07:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:21:15 --> UTF-8 Support Enabled
ERROR - 2022-04-30 07:21:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 07:21:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:21:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 07:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:21:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:21:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 07:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:21:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:21:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 07:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:21:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:21:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 07:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:51:42 --> Total execution time: 0.6169
DEBUG - 2022-04-30 07:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:52:47 --> Total execution time: 0.0314
DEBUG - 2022-04-30 07:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:23:03 --> Total execution time: 0.0512
DEBUG - 2022-04-30 07:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:23:06 --> Total execution time: 0.0290
DEBUG - 2022-04-30 07:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:23:06 --> Total execution time: 0.0309
DEBUG - 2022-04-30 07:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:58:10 --> Total execution time: 0.8281
DEBUG - 2022-04-30 07:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:28:17 --> Total execution time: 0.0485
DEBUG - 2022-04-30 07:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:28:18 --> Total execution time: 0.0292
DEBUG - 2022-04-30 07:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:28:18 --> Total execution time: 0.0776
DEBUG - 2022-04-30 07:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:28:38 --> Total execution time: 0.0292
DEBUG - 2022-04-30 07:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:28:41 --> Total execution time: 0.0419
DEBUG - 2022-04-30 07:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:58:53 --> Total execution time: 2.0007
DEBUG - 2022-04-30 07:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:59:29 --> Total execution time: 0.0339
DEBUG - 2022-04-30 07:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:59:30 --> Total execution time: 0.0369
DEBUG - 2022-04-30 07:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:59:38 --> Total execution time: 0.0368
DEBUG - 2022-04-30 07:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:59:41 --> Total execution time: 0.0456
DEBUG - 2022-04-30 07:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:59:47 --> Total execution time: 0.0384
DEBUG - 2022-04-30 07:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:59:58 --> Total execution time: 0.0307
DEBUG - 2022-04-30 07:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:59:59 --> Total execution time: 0.0280
DEBUG - 2022-04-30 07:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:01:08 --> Total execution time: 0.0305
DEBUG - 2022-04-30 07:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:01:09 --> Total execution time: 0.0289
DEBUG - 2022-04-30 07:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:01:36 --> Total execution time: 0.0324
DEBUG - 2022-04-30 07:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:01:39 --> Total execution time: 0.0287
DEBUG - 2022-04-30 07:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:01:58 --> Total execution time: 0.0305
DEBUG - 2022-04-30 07:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:02:00 --> Total execution time: 0.0277
DEBUG - 2022-04-30 07:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:02:27 --> Total execution time: 0.0312
DEBUG - 2022-04-30 07:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:02:30 --> Total execution time: 0.0281
DEBUG - 2022-04-30 07:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:02:43 --> Total execution time: 0.0608
DEBUG - 2022-04-30 07:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:02:48 --> Total execution time: 0.0298
DEBUG - 2022-04-30 07:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:02:50 --> Total execution time: 0.0290
DEBUG - 2022-04-30 07:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:03:00 --> Total execution time: 0.0287
DEBUG - 2022-04-30 07:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:33:01 --> No URI present. Default controller set.
DEBUG - 2022-04-30 07:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:03:01 --> Total execution time: 0.0403
DEBUG - 2022-04-30 07:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:33:46 --> No URI present. Default controller set.
DEBUG - 2022-04-30 07:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:03:46 --> Total execution time: 0.1575
DEBUG - 2022-04-30 07:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:03:58 --> Total execution time: 1.7845
DEBUG - 2022-04-30 07:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:04:27 --> Total execution time: 0.0328
DEBUG - 2022-04-30 07:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:04:31 --> Total execution time: 0.0303
DEBUG - 2022-04-30 07:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:05:32 --> Total execution time: 0.8921
DEBUG - 2022-04-30 07:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:05:44 --> Total execution time: 0.0775
DEBUG - 2022-04-30 07:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:05:45 --> Total execution time: 0.0461
DEBUG - 2022-04-30 07:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:05:49 --> Total execution time: 0.0310
DEBUG - 2022-04-30 07:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:05:59 --> Total execution time: 0.0308
DEBUG - 2022-04-30 07:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:06:11 --> Total execution time: 0.0305
DEBUG - 2022-04-30 07:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:06:55 --> Total execution time: 1.0301
DEBUG - 2022-04-30 07:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:37:57 --> Total execution time: 0.0457
DEBUG - 2022-04-30 07:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:38:01 --> Total execution time: 0.0329
DEBUG - 2022-04-30 07:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:38:01 --> Total execution time: 0.0418
DEBUG - 2022-04-30 07:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:40:12 --> Total execution time: 0.8112
DEBUG - 2022-04-30 07:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:40:15 --> Total execution time: 0.0462
DEBUG - 2022-04-30 07:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:40:16 --> Total execution time: 0.0862
DEBUG - 2022-04-30 07:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:40:16 --> Total execution time: 0.0735
DEBUG - 2022-04-30 07:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:42:19 --> Total execution time: 0.7983
DEBUG - 2022-04-30 07:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:42:27 --> Total execution time: 0.0295
DEBUG - 2022-04-30 07:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:12:38 --> Total execution time: 1.8078
DEBUG - 2022-04-30 07:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:13:28 --> Total execution time: 0.0487
DEBUG - 2022-04-30 07:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:13:29 --> Total execution time: 0.0360
DEBUG - 2022-04-30 07:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:13:34 --> Total execution time: 0.0618
DEBUG - 2022-04-30 07:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:13:53 --> Total execution time: 0.0380
DEBUG - 2022-04-30 07:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:13:57 --> Total execution time: 0.0313
DEBUG - 2022-04-30 07:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:14:26 --> Total execution time: 0.5325
DEBUG - 2022-04-30 07:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:16:34 --> Total execution time: 0.9023
DEBUG - 2022-04-30 07:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:47:00 --> No URI present. Default controller set.
DEBUG - 2022-04-30 07:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:17:00 --> Total execution time: 0.0850
DEBUG - 2022-04-30 07:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:47:02 --> No URI present. Default controller set.
DEBUG - 2022-04-30 07:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:17:02 --> Total execution time: 0.0312
DEBUG - 2022-04-30 07:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:17:06 --> Total execution time: 0.0420
DEBUG - 2022-04-30 07:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:47:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:47:11 --> 404 Page Not Found: User/forgot-password.html
DEBUG - 2022-04-30 07:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:17:15 --> Total execution time: 0.0309
DEBUG - 2022-04-30 07:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:18:37 --> Total execution time: 0.5747
DEBUG - 2022-04-30 07:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:19:11 --> Total execution time: 0.0425
DEBUG - 2022-04-30 07:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:49:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:49:16 --> 404 Page Not Found: Forgot-password/index
DEBUG - 2022-04-30 07:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:19:17 --> Total execution time: 0.2128
DEBUG - 2022-04-30 07:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:19:46 --> Total execution time: 0.0477
DEBUG - 2022-04-30 07:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:19:50 --> Total execution time: 0.0533
DEBUG - 2022-04-30 07:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:20:01 --> Total execution time: 0.0322
DEBUG - 2022-04-30 07:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:20:41 --> Total execution time: 0.0644
DEBUG - 2022-04-30 07:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:20:56 --> Total execution time: 0.0561
DEBUG - 2022-04-30 07:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:21:10 --> Total execution time: 0.0570
DEBUG - 2022-04-30 07:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:52:07 --> No URI present. Default controller set.
DEBUG - 2022-04-30 07:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:22:08 --> Total execution time: 0.9451
DEBUG - 2022-04-30 07:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:22:10 --> Total execution time: 0.0506
DEBUG - 2022-04-30 07:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:52:13 --> Total execution time: 0.0311
DEBUG - 2022-04-30 07:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:52:14 --> Total execution time: 0.0308
DEBUG - 2022-04-30 07:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:52:14 --> Total execution time: 0.0794
DEBUG - 2022-04-30 07:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:52:19 --> Total execution time: 0.8087
DEBUG - 2022-04-30 07:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:22:41 --> Total execution time: 0.8041
DEBUG - 2022-04-30 07:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:52:57 --> No URI present. Default controller set.
DEBUG - 2022-04-30 07:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:22:57 --> Total execution time: 0.2187
DEBUG - 2022-04-30 07:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:23:23 --> Total execution time: 0.0305
DEBUG - 2022-04-30 07:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:23:42 --> Total execution time: 0.5700
DEBUG - 2022-04-30 07:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:24:15 --> Total execution time: 0.8051
DEBUG - 2022-04-30 07:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:54:20 --> Total execution time: 0.0295
DEBUG - 2022-04-30 07:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:24:31 --> Total execution time: 1.8578
DEBUG - 2022-04-30 07:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:24:42 --> Total execution time: 0.0306
DEBUG - 2022-04-30 07:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:25:08 --> Total execution time: 0.0594
DEBUG - 2022-04-30 07:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:25:09 --> Total execution time: 0.0596
DEBUG - 2022-04-30 07:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:25:18 --> Total execution time: 0.3341
DEBUG - 2022-04-30 07:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:26:21 --> Total execution time: 0.8401
DEBUG - 2022-04-30 07:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:26:24 --> Total execution time: 0.0458
DEBUG - 2022-04-30 07:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:26:32 --> Total execution time: 0.8131
DEBUG - 2022-04-30 07:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:56:38 --> No URI present. Default controller set.
DEBUG - 2022-04-30 07:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:26:38 --> Total execution time: 0.8291
DEBUG - 2022-04-30 07:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:56:57 --> Total execution time: 0.0317
DEBUG - 2022-04-30 07:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:27:10 --> Total execution time: 0.8012
DEBUG - 2022-04-30 07:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:27:35 --> Total execution time: 0.0649
DEBUG - 2022-04-30 07:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:27:39 --> Total execution time: 0.0308
DEBUG - 2022-04-30 07:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:27:50 --> Total execution time: 0.0827
DEBUG - 2022-04-30 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:28:12 --> Total execution time: 0.8326
DEBUG - 2022-04-30 07:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:28:29 --> Total execution time: 0.0428
DEBUG - 2022-04-30 07:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:58:48 --> Total execution time: 0.0298
DEBUG - 2022-04-30 07:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:58:49 --> Total execution time: 0.0288
DEBUG - 2022-04-30 07:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 07:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:28:55 --> Total execution time: 0.0524
DEBUG - 2022-04-30 07:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:29:00 --> Total execution time: 0.0512
DEBUG - 2022-04-30 07:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:29:05 --> Total execution time: 0.0392
DEBUG - 2022-04-30 07:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:29:20 --> Total execution time: 0.8361
DEBUG - 2022-04-30 07:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:29:22 --> Total execution time: 0.0354
DEBUG - 2022-04-30 07:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:29:38 --> Total execution time: 0.8251
DEBUG - 2022-04-30 07:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:29:43 --> Total execution time: 0.0410
DEBUG - 2022-04-30 07:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:29:46 --> Total execution time: 0.0408
DEBUG - 2022-04-30 07:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:29:51 --> Total execution time: 0.0447
DEBUG - 2022-04-30 07:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:59:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 07:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:59:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 07:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:59:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 07:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:59:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 07:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:59:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 07:59:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:59:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 07:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:59:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 07:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 07:59:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 07:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 07:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 07:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:29:58 --> Total execution time: 0.0297
DEBUG - 2022-04-30 08:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:30:07 --> Total execution time: 0.7705
DEBUG - 2022-04-30 08:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:00:09 --> No URI present. Default controller set.
DEBUG - 2022-04-30 08:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:30:09 --> Total execution time: 0.0732
DEBUG - 2022-04-30 08:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:30:59 --> Total execution time: 0.8131
DEBUG - 2022-04-30 08:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:31:03 --> Total execution time: 0.0283
DEBUG - 2022-04-30 08:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:33:03 --> Total execution time: 0.8591
DEBUG - 2022-04-30 08:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:33:17 --> Total execution time: 0.4801
DEBUG - 2022-04-30 08:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:34:40 --> Total execution time: 0.8211
DEBUG - 2022-04-30 08:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:04:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-30 13:34:44 --> Severity: Warning --> json_encode() expects at least 1 parameter, 0 given /home/gvprods/public_html/v1/gvv3/application/controllers/User/ForgotPass_Controller.php 45
DEBUG - 2022-04-30 13:34:44 --> Total execution time: 0.0406
DEBUG - 2022-04-30 08:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:35:01 --> Total execution time: 0.0333
DEBUG - 2022-04-30 08:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:37:14 --> Total execution time: 0.8052
DEBUG - 2022-04-30 08:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:08:00 --> No URI present. Default controller set.
DEBUG - 2022-04-30 08:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:38:00 --> Total execution time: 0.0709
DEBUG - 2022-04-30 08:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:38:14 --> Total execution time: 0.2270
DEBUG - 2022-04-30 08:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:38:15 --> Total execution time: 0.0305
DEBUG - 2022-04-30 08:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:38:21 --> Total execution time: 0.0599
DEBUG - 2022-04-30 08:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:38:50 --> Total execution time: 0.0296
DEBUG - 2022-04-30 08:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:38:54 --> Total execution time: 0.0292
DEBUG - 2022-04-30 08:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:38:59 --> Total execution time: 0.0312
DEBUG - 2022-04-30 08:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 08:08:59 --> 404 Page Not Found: User/forgot-password-email-otp
DEBUG - 2022-04-30 08:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:41:06 --> Total execution time: 0.2509
DEBUG - 2022-04-30 08:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:41:09 --> Total execution time: 0.0285
DEBUG - 2022-04-30 08:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:41:13 --> Total execution time: 0.0301
DEBUG - 2022-04-30 08:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:11:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 08:11:13 --> 404 Page Not Found: User/forgot-password-email-otp
DEBUG - 2022-04-30 08:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:41:34 --> Total execution time: 0.0288
DEBUG - 2022-04-30 08:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:41:36 --> Total execution time: 0.0306
DEBUG - 2022-04-30 08:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:41:45 --> Total execution time: 0.0318
DEBUG - 2022-04-30 08:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:41:45 --> Total execution time: 0.0279
DEBUG - 2022-04-30 08:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:42:31 --> Total execution time: 0.0326
DEBUG - 2022-04-30 08:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:44:17 --> Total execution time: 0.0313
DEBUG - 2022-04-30 08:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:44:19 --> Total execution time: 0.0303
DEBUG - 2022-04-30 08:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:44:21 --> Total execution time: 0.0297
DEBUG - 2022-04-30 08:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:44:24 --> Total execution time: 0.0275
DEBUG - 2022-04-30 08:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:44:26 --> Total execution time: 0.0287
DEBUG - 2022-04-30 08:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:17:40 --> No URI present. Default controller set.
DEBUG - 2022-04-30 08:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:47:40 --> Total execution time: 0.0729
DEBUG - 2022-04-30 08:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:49:05 --> Total execution time: 0.0697
DEBUG - 2022-04-30 08:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:49:26 --> Total execution time: 0.0321
DEBUG - 2022-04-30 08:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:49:35 --> Total execution time: 0.0323
DEBUG - 2022-04-30 08:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:49:42 --> Total execution time: 0.0302
DEBUG - 2022-04-30 08:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 08:20:01 --> 404 Page Not Found: User/reset-new-password
DEBUG - 2022-04-30 08:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:50:14 --> Total execution time: 0.0467
DEBUG - 2022-04-30 08:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:50:28 --> Total execution time: 0.0308
DEBUG - 2022-04-30 08:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:51:16 --> Total execution time: 0.0302
DEBUG - 2022-04-30 08:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:52:56 --> Total execution time: 0.0307
DEBUG - 2022-04-30 08:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:54:03 --> Total execution time: 0.0319
DEBUG - 2022-04-30 08:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:54:27 --> Total execution time: 0.0290
DEBUG - 2022-04-30 08:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:54:47 --> Total execution time: 0.0320
DEBUG - 2022-04-30 08:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:55:31 --> Total execution time: 0.0312
DEBUG - 2022-04-30 08:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:56:54 --> Total execution time: 0.0330
DEBUG - 2022-04-30 08:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:57:12 --> Total execution time: 0.0302
DEBUG - 2022-04-30 08:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:57:37 --> Total execution time: 0.0287
DEBUG - 2022-04-30 08:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:57:51 --> Total execution time: 0.0292
DEBUG - 2022-04-30 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:57:55 --> Total execution time: 0.0287
DEBUG - 2022-04-30 08:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:58:06 --> Total execution time: 0.0284
DEBUG - 2022-04-30 08:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:58:25 --> Total execution time: 0.0290
DEBUG - 2022-04-30 08:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:00:14 --> Total execution time: 0.0356
DEBUG - 2022-04-30 08:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:00:35 --> Total execution time: 0.0284
DEBUG - 2022-04-30 08:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:01:44 --> Total execution time: 0.0292
DEBUG - 2022-04-30 08:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:01:52 --> Total execution time: 0.0305
DEBUG - 2022-04-30 08:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:01:56 --> Total execution time: 0.0280
DEBUG - 2022-04-30 08:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:01:57 --> Total execution time: 0.0288
DEBUG - 2022-04-30 08:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:02:58 --> Total execution time: 0.0317
DEBUG - 2022-04-30 08:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:03:23 --> Total execution time: 0.0288
DEBUG - 2022-04-30 08:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 08:33:23 --> 404 Page Not Found: User/reset-new-password
DEBUG - 2022-04-30 08:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:03:26 --> Total execution time: 0.0298
DEBUG - 2022-04-30 08:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:04:45 --> Total execution time: 0.0389
DEBUG - 2022-04-30 08:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:05:43 --> Total execution time: 0.0289
DEBUG - 2022-04-30 08:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:06:17 --> Total execution time: 0.0315
DEBUG - 2022-04-30 08:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:06:50 --> Total execution time: 0.0287
DEBUG - 2022-04-30 08:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 08:36:50 --> 404 Page Not Found: User/reset-new-password
DEBUG - 2022-04-30 08:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:07:39 --> Total execution time: 0.0318
DEBUG - 2022-04-30 08:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:09:26 --> Total execution time: 0.0300
DEBUG - 2022-04-30 08:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:12:39 --> Total execution time: 0.0439
DEBUG - 2022-04-30 08:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:13:20 --> Total execution time: 0.0305
DEBUG - 2022-04-30 08:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:13:33 --> Total execution time: 0.0312
DEBUG - 2022-04-30 08:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:15:48 --> Total execution time: 0.0422
DEBUG - 2022-04-30 08:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:15:54 --> Total execution time: 0.0337
DEBUG - 2022-04-30 08:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:15:57 --> Total execution time: 0.0288
DEBUG - 2022-04-30 08:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:16:02 --> Total execution time: 0.0293
DEBUG - 2022-04-30 08:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:16:03 --> Total execution time: 0.0320
DEBUG - 2022-04-30 08:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:16:20 --> Total execution time: 0.0285
DEBUG - 2022-04-30 08:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:16:21 --> Total execution time: 0.0291
DEBUG - 2022-04-30 08:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:16:33 --> Total execution time: 0.0288
DEBUG - 2022-04-30 08:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:20:08 --> Total execution time: 0.7465
DEBUG - 2022-04-30 08:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:21:17 --> Total execution time: 0.0289
DEBUG - 2022-04-30 08:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:21:30 --> Total execution time: 0.0301
DEBUG - 2022-04-30 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:21:50 --> Total execution time: 0.0287
DEBUG - 2022-04-30 08:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:23:22 --> Total execution time: 0.0626
DEBUG - 2022-04-30 08:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:23:24 --> Total execution time: 0.0288
DEBUG - 2022-04-30 08:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:23:28 --> Total execution time: 0.0282
DEBUG - 2022-04-30 08:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:23:29 --> Total execution time: 0.0382
DEBUG - 2022-04-30 08:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:23:53 --> Total execution time: 0.0315
DEBUG - 2022-04-30 08:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:24:03 --> Total execution time: 0.0293
DEBUG - 2022-04-30 08:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:24:04 --> Total execution time: 0.0303
DEBUG - 2022-04-30 08:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:24:55 --> Total execution time: 0.0285
DEBUG - 2022-04-30 08:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:24:59 --> Total execution time: 0.0288
DEBUG - 2022-04-30 08:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:25:03 --> Total execution time: 0.0583
DEBUG - 2022-04-30 08:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:25:04 --> Total execution time: 0.0304
DEBUG - 2022-04-30 08:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:25:23 --> Total execution time: 0.0285
DEBUG - 2022-04-30 08:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 08:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 08:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 08:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:25:24 --> Total execution time: 0.0308
DEBUG - 2022-04-30 09:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 09:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 09:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 09:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 09:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 09:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 15:24:17 --> Total execution time: 0.0694
DEBUG - 2022-04-30 10:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 10:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 10:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 15:49:52 --> Total execution time: 0.8091
DEBUG - 2022-04-30 10:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 10:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 10:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 15:50:06 --> Total execution time: 0.0304
DEBUG - 2022-04-30 10:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 10:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 10:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 10:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 10:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 15:50:21 --> Total execution time: 0.0294
DEBUG - 2022-04-30 10:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 10:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 10:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 10:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 10:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 10:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 15:50:38 --> Total execution time: 0.0315
DEBUG - 2022-04-30 11:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 11:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 11:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 11:54:25 --> Total execution time: 1.1514
DEBUG - 2022-04-30 11:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 11:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 11:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 11:54:35 --> Total execution time: 0.0297
DEBUG - 2022-04-30 11:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 11:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 11:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 11:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 11:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 11:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:24:52 --> Total execution time: 0.0965
DEBUG - 2022-04-30 11:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 11:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 11:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:25:29 --> Total execution time: 1.0549
DEBUG - 2022-04-30 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 11:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 11:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 11:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 11:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 11:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:26:06 --> Total execution time: 0.0290
DEBUG - 2022-04-30 11:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 11:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 11:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:26:10 --> Total execution time: 0.0286
DEBUG - 2022-04-30 11:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 11:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 11:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:26:19 --> Total execution time: 0.0714
DEBUG - 2022-04-30 11:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 11:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 11:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:26:50 --> Total execution time: 0.0588
DEBUG - 2022-04-30 11:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 11:57:12 --> No URI present. Default controller set.
DEBUG - 2022-04-30 11:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 11:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:27:12 --> Total execution time: 0.0738
DEBUG - 2022-04-30 11:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 11:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 11:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:28:21 --> Total execution time: 0.0296
DEBUG - 2022-04-30 11:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 11:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 11:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 11:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 11:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 11:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:28:49 --> Total execution time: 0.0301
DEBUG - 2022-04-30 12:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:35:49 --> Total execution time: 0.8392
DEBUG - 2022-04-30 12:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:05:52 --> No URI present. Default controller set.
DEBUG - 2022-04-30 12:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:35:52 --> Total execution time: 0.0591
DEBUG - 2022-04-30 12:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:06:25 --> No URI present. Default controller set.
DEBUG - 2022-04-30 12:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:36:25 --> Total execution time: 0.3481
DEBUG - 2022-04-30 12:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:16:57 --> No URI present. Default controller set.
DEBUG - 2022-04-30 12:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:46:57 --> Total execution time: 1.0311
DEBUG - 2022-04-30 12:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:47:01 --> Total execution time: 0.0457
DEBUG - 2022-04-30 12:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:47:13 --> Total execution time: 0.1376
DEBUG - 2022-04-30 12:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:47:32 --> Total execution time: 0.9181
DEBUG - 2022-04-30 12:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:47:57 --> Total execution time: 0.8600
DEBUG - 2022-04-30 12:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:48:01 --> Total execution time: 0.5726
DEBUG - 2022-04-30 12:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:48:05 --> Total execution time: 0.1663
DEBUG - 2022-04-30 12:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:48:09 --> Total execution time: 0.8291
DEBUG - 2022-04-30 12:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:48:39 --> Total execution time: 0.8251
DEBUG - 2022-04-30 12:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:49:00 --> Total execution time: 0.0610
DEBUG - 2022-04-30 12:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:49:07 --> Total execution time: 0.0722
DEBUG - 2022-04-30 12:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:49:41 --> Total execution time: 0.8381
DEBUG - 2022-04-30 12:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:49:45 --> Total execution time: 0.0497
DEBUG - 2022-04-30 12:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 17:50:02 --> Total execution time: 0.8256
DEBUG - 2022-04-30 12:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 18:11:24 --> Total execution time: 0.8551
DEBUG - 2022-04-30 12:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:45:16 --> Total execution time: 0.8053
DEBUG - 2022-04-30 12:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 12:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 18:15:24 --> Total execution time: 0.1433
DEBUG - 2022-04-30 12:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 18:15:31 --> Total execution time: 0.0519
DEBUG - 2022-04-30 12:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 18:21:15 --> Total execution time: 0.8321
DEBUG - 2022-04-30 12:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:51:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:51:17 --> 404 Page Not Found: Admin/assets
DEBUG - 2022-04-30 12:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:51:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:51:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:51:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:51:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:51:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:51:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:51:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-30 12:51:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 18:23:10 --> Total execution time: 0.8595
DEBUG - 2022-04-30 12:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:53:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:53:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:53:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:53:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:53:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:53:12 --> UTF-8 Support Enabled
ERROR - 2022-04-30 12:53:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:53:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:53:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 18:25:56 --> Total execution time: 0.8672
DEBUG - 2022-04-30 12:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:55:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:55:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:55:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:55:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:55:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:55:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 12:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:55:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-30 12:55:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:55:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 12:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 12:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 12:55:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 18:31:49 --> Total execution time: 0.8442
DEBUG - 2022-04-30 13:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:01:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:01:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:01:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:01:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:01:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:01:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:01:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:01:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 18:33:27 --> Total execution time: 0.1112
DEBUG - 2022-04-30 13:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:03:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:03:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:03:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:03:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:03:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:03:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:03:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:03:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:03:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:03:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:03:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:03:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:03:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 18:39:31 --> Total execution time: 0.8242
DEBUG - 2022-04-30 13:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:09:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 18:40:04 --> Total execution time: 0.0332
DEBUG - 2022-04-30 13:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:10:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:10:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:10:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:10:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:10:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:10:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:10:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:10:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:10:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-30 13:10:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:10:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-30 13:10:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-30 13:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:00:25 --> Total execution time: 0.9263
DEBUG - 2022-04-30 13:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:20:17 --> Total execution time: 0.8612
DEBUG - 2022-04-30 13:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:20:32 --> Total execution time: 0.0293
DEBUG - 2022-04-30 13:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:20:57 --> Total execution time: 0.0303
DEBUG - 2022-04-30 13:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:21:20 --> Total execution time: 0.0639
DEBUG - 2022-04-30 13:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:21:46 --> Total execution time: 0.0429
DEBUG - 2022-04-30 13:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:22:17 --> Total execution time: 0.0486
DEBUG - 2022-04-30 13:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:24:16 --> Total execution time: 0.0319
DEBUG - 2022-04-30 13:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:24:20 --> Total execution time: 0.0319
DEBUG - 2022-04-30 13:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:24:20 --> Total execution time: 0.0288
DEBUG - 2022-04-30 13:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:24:28 --> Total execution time: 0.0298
DEBUG - 2022-04-30 13:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:54:35 --> No URI present. Default controller set.
DEBUG - 2022-04-30 13:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:24:35 --> Total execution time: 0.0704
DEBUG - 2022-04-30 13:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:24:35 --> Total execution time: 0.0282
DEBUG - 2022-04-30 13:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 13:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:24:51 --> Total execution time: 0.0308
DEBUG - 2022-04-30 13:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:24:59 --> Total execution time: 0.0306
DEBUG - 2022-04-30 13:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:26:56 --> Total execution time: 0.0314
DEBUG - 2022-04-30 13:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:27:33 --> Total execution time: 0.0318
DEBUG - 2022-04-30 13:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:27:40 --> Total execution time: 0.0308
DEBUG - 2022-04-30 13:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:28:47 --> Total execution time: 0.0317
DEBUG - 2022-04-30 13:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:29:13 --> Total execution time: 0.0322
DEBUG - 2022-04-30 13:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 13:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 13:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:29:42 --> Total execution time: 0.0461
DEBUG - 2022-04-30 14:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:30:15 --> Total execution time: 0.0321
DEBUG - 2022-04-30 14:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:40:41 --> Total execution time: 0.9314
DEBUG - 2022-04-30 14:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:40:59 --> Total execution time: 0.0322
DEBUG - 2022-04-30 14:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:41:35 --> Total execution time: 0.0402
DEBUG - 2022-04-30 14:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:41:51 --> Total execution time: 0.0308
DEBUG - 2022-04-30 14:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:48:31 --> Total execution time: 0.8901
DEBUG - 2022-04-30 14:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:48:46 --> Total execution time: 0.0753
DEBUG - 2022-04-30 14:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:48:49 --> Total execution time: 0.0337
DEBUG - 2022-04-30 14:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:48:55 --> Total execution time: 0.0307
DEBUG - 2022-04-30 14:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:49:55 --> Total execution time: 0.0680
DEBUG - 2022-04-30 14:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:52:27 --> Total execution time: 0.0390
DEBUG - 2022-04-30 14:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:56:37 --> Total execution time: 0.0434
DEBUG - 2022-04-30 14:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:56:47 --> Total execution time: 0.1649
DEBUG - 2022-04-30 14:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:56:56 --> Total execution time: 0.0925
DEBUG - 2022-04-30 14:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:58:12 --> Total execution time: 0.0469
DEBUG - 2022-04-30 14:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 19:58:17 --> Total execution time: 0.0485
DEBUG - 2022-04-30 14:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:00:22 --> Total execution time: 0.1816
DEBUG - 2022-04-30 14:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:01:03 --> Total execution time: 0.0356
DEBUG - 2022-04-30 14:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:02:58 --> Total execution time: 0.5495
DEBUG - 2022-04-30 14:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:03:21 --> Total execution time: 0.0667
DEBUG - 2022-04-30 14:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:04:06 --> Total execution time: 0.0312
DEBUG - 2022-04-30 14:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:08:38 --> Total execution time: 0.8401
DEBUG - 2022-04-30 14:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:09:00 --> Total execution time: 0.0320
DEBUG - 2022-04-30 14:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:09:08 --> Total execution time: 0.0456
DEBUG - 2022-04-30 14:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:09:11 --> Total execution time: 0.0341
DEBUG - 2022-04-30 14:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:09:17 --> Total execution time: 0.0311
DEBUG - 2022-04-30 14:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:11:44 --> Total execution time: 0.8870
DEBUG - 2022-04-30 14:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:17:41 --> Total execution time: 0.8751
DEBUG - 2022-04-30 14:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 14:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:17:45 --> Total execution time: 0.0566
DEBUG - 2022-04-30 14:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:22:46 --> Total execution time: 1.1411
DEBUG - 2022-04-30 14:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 14:54:00 --> No URI present. Default controller set.
DEBUG - 2022-04-30 14:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 14:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:24:01 --> Total execution time: 0.9543
DEBUG - 2022-04-30 16:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 16:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 16:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 22:07:50 --> Total execution time: 1.1490
DEBUG - 2022-04-30 20:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 20:08:39 --> No URI present. Default controller set.
DEBUG - 2022-04-30 20:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 20:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 20:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 20:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 20:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 20:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 20:09:01 --> No URI present. Default controller set.
DEBUG - 2022-04-30 20:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 20:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-30 20:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-30 20:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-30 20:09:05 --> Encryption: Auto-configured driver 'openssl'.
