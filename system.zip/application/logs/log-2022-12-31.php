<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-31 00:07:56 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 14
ERROR - 2022-12-31 00:07:56 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 16
ERROR - 2022-12-31 00:07:56 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 16
ERROR - 2022-12-31 00:07:56 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 6
ERROR - 2022-12-31 00:07:56 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 8
DEBUG - 2022-12-31 00:07:56 --> Total execution time: 0.0830
ERROR - 2022-12-31 00:08:25 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 14
ERROR - 2022-12-31 00:08:25 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 16
ERROR - 2022-12-31 00:08:25 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 16
ERROR - 2022-12-31 00:08:25 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 6
ERROR - 2022-12-31 00:08:25 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 8
DEBUG - 2022-12-31 00:08:25 --> Total execution time: 0.0812
DEBUG - 2022-12-31 00:09:47 --> Total execution time: 0.0593
ERROR - 2022-12-31 00:12:50 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 14
ERROR - 2022-12-31 00:12:50 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 16
ERROR - 2022-12-31 00:12:50 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 16
ERROR - 2022-12-31 00:12:50 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 6
ERROR - 2022-12-31 00:12:50 --> Severity: Notice --> Trying to get property 'ul_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 8
DEBUG - 2022-12-31 00:12:50 --> Total execution time: 0.1005
ERROR - 2022-12-31 00:13:04 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 14
ERROR - 2022-12-31 00:13:04 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 16
ERROR - 2022-12-31 00:13:04 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 16
ERROR - 2022-12-31 00:13:04 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 6
ERROR - 2022-12-31 00:13:04 --> Severity: Notice --> Trying to get property 'ul_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 8
DEBUG - 2022-12-31 00:13:04 --> Total execution time: 0.1908
ERROR - 2022-12-31 00:14:34 --> Severity: error --> Exception: Too few arguments to function get_admin_img(), 0 passed in C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\inc\header.php on line 59 and exactly 1 expected C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 10
ERROR - 2022-12-31 00:15:15 --> Severity: error --> Exception: Too few arguments to function get_admin_img(), 0 passed in C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\inc\header.php on line 59 and exactly 1 expected C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 10
ERROR - 2022-12-31 00:15:16 --> Severity: error --> Exception: Too few arguments to function get_admin_img(), 0 passed in C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\inc\header.php on line 59 and exactly 1 expected C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 10
ERROR - 2022-12-31 00:15:36 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 16
ERROR - 2022-12-31 00:15:36 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 16
DEBUG - 2022-12-31 00:15:36 --> Total execution time: 0.0784
DEBUG - 2022-12-31 00:16:36 --> Total execution time: 0.0634
DEBUG - 2022-12-31 00:16:38 --> Total execution time: 0.0700
DEBUG - 2022-12-31 00:16:47 --> Total execution time: 0.0620
DEBUG - 2022-12-31 00:17:18 --> Total execution time: 0.0902
DEBUG - 2022-12-31 00:18:47 --> Total execution time: 0.1081
DEBUG - 2022-12-31 00:20:10 --> Total execution time: 0.1123
DEBUG - 2022-12-31 00:21:01 --> Total execution time: 0.0757
DEBUG - 2022-12-31 00:21:10 --> Total execution time: 0.0633
DEBUG - 2022-12-31 00:28:42 --> Total execution time: 0.0686
DEBUG - 2022-12-31 00:28:48 --> Total execution time: 0.0749
DEBUG - 2022-12-31 00:30:01 --> Total execution time: 0.0633
DEBUG - 2022-12-31 00:32:49 --> Total execution time: 0.0796
DEBUG - 2022-12-31 00:35:37 --> Total execution time: 0.0665
DEBUG - 2022-12-31 00:35:55 --> Total execution time: 0.0681
DEBUG - 2022-12-31 00:38:00 --> Total execution time: 0.0834
DEBUG - 2022-12-31 02:17:04 --> Total execution time: 0.0754
DEBUG - 2022-12-31 02:17:13 --> Total execution time: 0.0672
DEBUG - 2022-12-31 02:17:15 --> Total execution time: 0.0751
DEBUG - 2022-12-31 02:17:27 --> Total execution time: 0.0631
DEBUG - 2022-12-31 02:17:53 --> Total execution time: 0.0617
DEBUG - 2022-12-31 02:18:03 --> Total execution time: 0.1099
DEBUG - 2022-12-31 02:18:07 --> Total execution time: 0.0628
DEBUG - 2022-12-31 16:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 16:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 16:47:26 --> Total execution time: 0.0732
DEBUG - 2022-12-31 16:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 16:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 16:47:27 --> Total execution time: 0.0466
DEBUG - 2022-12-31 16:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 16:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:17:36 --> Total execution time: 0.0476
DEBUG - 2022-12-31 16:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:47:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 16:47:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 16:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:47:42 --> No URI present. Default controller set.
DEBUG - 2022-12-31 16:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:17:42 --> Total execution time: 0.0759
DEBUG - 2022-12-31 16:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:17:45 --> Total execution time: 0.0487
DEBUG - 2022-12-31 16:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:17:48 --> Total execution time: 0.1737
DEBUG - 2022-12-31 16:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:47:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 16:47:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 16:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 16:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:18:12 --> Total execution time: 0.1101
DEBUG - 2022-12-31 16:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:48:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 16:48:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 16:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 16:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 16:49:23 --> Total execution time: 0.0455
DEBUG - 2022-12-31 16:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 16:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:19:28 --> Total execution time: 0.0508
DEBUG - 2022-12-31 16:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:49:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 16:49:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 16:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 16:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 16:49:31 --> Total execution time: 0.0491
DEBUG - 2022-12-31 16:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 16:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 16:49:37 --> Total execution time: 0.0475
DEBUG - 2022-12-31 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:49:41 --> No URI present. Default controller set.
DEBUG - 2022-12-31 16:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:19:41 --> Total execution time: 0.0625
DEBUG - 2022-12-31 16:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:19:43 --> Total execution time: 0.0531
DEBUG - 2022-12-31 16:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 16:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:19:46 --> Total execution time: 0.0505
DEBUG - 2022-12-31 16:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 16:49:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 16:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:20:13 --> Total execution time: 0.0707
DEBUG - 2022-12-31 16:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:50:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 16:50:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 16:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:20:17 --> Total execution time: 0.1430
DEBUG - 2022-12-31 16:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:50:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 16:50:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 16:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:23:52 --> Total execution time: 0.0767
DEBUG - 2022-12-31 16:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:53:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 16:53:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 16:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:24:02 --> Total execution time: 0.0856
DEBUG - 2022-12-31 16:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 16:54:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 16:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:25:35 --> Total execution time: 0.0713
DEBUG - 2022-12-31 16:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 16:55:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 16:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:25:42 --> Total execution time: 0.0672
DEBUG - 2022-12-31 16:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:55:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 16:55:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 16:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:28:33 --> Total execution time: 0.0820
DEBUG - 2022-12-31 16:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:58:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 16:58:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 16:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 16:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 16:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:28:35 --> Total execution time: 0.0848
DEBUG - 2022-12-31 16:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 16:58:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 16:58:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:31:48 --> Total execution time: 0.0880
DEBUG - 2022-12-31 17:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:01:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:01:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:32:42 --> Total execution time: 0.0575
DEBUG - 2022-12-31 17:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:02:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:02:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:32:57 --> Total execution time: 0.0549
DEBUG - 2022-12-31 17:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:02:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:33:05 --> Total execution time: 0.0589
DEBUG - 2022-12-31 17:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:03:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:03:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:33:27 --> Total execution time: 0.0751
DEBUG - 2022-12-31 17:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:03:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:03:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:33:29 --> Total execution time: 0.0641
DEBUG - 2022-12-31 17:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:03:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:03:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:34:04 --> Total execution time: 0.0681
DEBUG - 2022-12-31 17:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:04:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:35:48 --> Total execution time: 0.0908
DEBUG - 2022-12-31 17:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:05:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:35:49 --> Total execution time: 0.0501
DEBUG - 2022-12-31 17:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:08:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-31 21:38:33 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\inc\header.php 59
ERROR - 2022-12-31 21:38:33 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 16
ERROR - 2022-12-31 21:38:33 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 16
ERROR - 2022-12-31 21:38:33 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\inc\header.php 61
ERROR - 2022-12-31 21:38:33 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 8
ERROR - 2022-12-31 21:38:33 --> Severity: Notice --> Undefined property: stdClass::$Admin_Name C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 55
ERROR - 2022-12-31 21:38:33 --> Severity: Notice --> Undefined property: stdClass::$Admin_Email C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 61
ERROR - 2022-12-31 21:38:33 --> Severity: Notice --> Undefined property: stdClass::$Admin_Phone C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 67
ERROR - 2022-12-31 21:38:33 --> Severity: Notice --> Undefined property: stdClass::$Admin_Whatsapp C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 73
ERROR - 2022-12-31 21:38:33 --> Severity: Notice --> Undefined property: stdClass::$Admin_Address C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 81
ERROR - 2022-12-31 21:38:33 --> Severity: Notice --> Undefined property: stdClass::$Admin_Profile_Image C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 86
ERROR - 2022-12-31 21:38:33 --> Severity: Notice --> Undefined property: stdClass::$Admin_Profile_Image_Path C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 87
ERROR - 2022-12-31 21:38:33 --> Severity: Notice --> Undefined property: stdClass::$Admin_Profile_Image C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 87
DEBUG - 2022-12-31 21:38:33 --> Total execution time: 0.1237
DEBUG - 2022-12-31 17:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:08:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:08:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:08:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-31 21:38:54 --> Severity: Notice --> Undefined property: stdClass::$Admin_Name C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 55
ERROR - 2022-12-31 21:38:54 --> Severity: Notice --> Undefined property: stdClass::$Admin_Email C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 61
ERROR - 2022-12-31 21:38:54 --> Severity: Notice --> Undefined property: stdClass::$Admin_Phone C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 67
ERROR - 2022-12-31 21:38:54 --> Severity: Notice --> Undefined property: stdClass::$Admin_Whatsapp C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 73
ERROR - 2022-12-31 21:38:54 --> Severity: Notice --> Undefined property: stdClass::$Admin_Address C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 81
ERROR - 2022-12-31 21:38:54 --> Severity: Notice --> Undefined property: stdClass::$Admin_Profile_Image C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 86
ERROR - 2022-12-31 21:38:54 --> Severity: Notice --> Undefined property: stdClass::$Admin_Profile_Image_Path C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 87
ERROR - 2022-12-31 21:38:54 --> Severity: Notice --> Undefined property: stdClass::$Admin_Profile_Image C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 87
DEBUG - 2022-12-31 21:38:54 --> Total execution time: 0.0870
DEBUG - 2022-12-31 17:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:08:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:10:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-31 21:40:40 --> Severity: Notice --> Undefined property: stdClass::$Admin_Profile_Image C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 80
ERROR - 2022-12-31 21:40:40 --> Severity: Notice --> Undefined property: stdClass::$Admin_Profile_Image_Path C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 81
ERROR - 2022-12-31 21:40:40 --> Severity: Notice --> Undefined property: stdClass::$Admin_Profile_Image C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 81
DEBUG - 2022-12-31 21:40:40 --> Total execution time: 0.0945
DEBUG - 2022-12-31 17:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:10:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:10:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:41:36 --> Total execution time: 0.0701
DEBUG - 2022-12-31 17:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:11:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:41:49 --> Total execution time: 0.0878
DEBUG - 2022-12-31 17:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:11:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:11:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:41:52 --> Total execution time: 0.0968
DEBUG - 2022-12-31 17:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:11:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:11:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:14:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:26 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:27 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:28 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
DEBUG - 2022-12-31 21:44:28 --> Total execution time: 2.2183
DEBUG - 2022-12-31 17:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:14:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:14:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:14:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:50 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:51 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:52 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:44:53 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
DEBUG - 2022-12-31 21:44:53 --> Total execution time: 3.0446
DEBUG - 2022-12-31 17:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:14:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:14:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:15:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-31 21:45:09 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:09 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:09 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:09 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:09 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:09 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:09 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:10 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:11 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:12 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:13 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
DEBUG - 2022-12-31 21:45:13 --> Total execution time: 3.8060
DEBUG - 2022-12-31 17:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:15:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:15:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:15:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:16 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:17 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:18 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:19 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Undefined variable: detail C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
ERROR - 2022-12-31 21:45:20 --> Severity: Notice --> Trying to get property 'ul_country' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-profile.php 79
DEBUG - 2022-12-31 21:45:20 --> Total execution time: 4.5279
DEBUG - 2022-12-31 17:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:46:07 --> Total execution time: 0.0912
DEBUG - 2022-12-31 17:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:46:09 --> Total execution time: 0.0951
DEBUG - 2022-12-31 17:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:16:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:16:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:46:27 --> Total execution time: 0.0907
DEBUG - 2022-12-31 17:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:16:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:16:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:46:44 --> Total execution time: 0.0995
DEBUG - 2022-12-31 17:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:16:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:16:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:47:36 --> Total execution time: 0.0920
DEBUG - 2022-12-31 17:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:17:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:17:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:17:46 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:17:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:17:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:17:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:17:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:17:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:17:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:17:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:17:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:49:16 --> Total execution time: 0.0935
DEBUG - 2022-12-31 17:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:19:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:19:23 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:19:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:19:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:19:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:19:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:19:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:19:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:19:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:19:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:19:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:19:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:19:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:49:56 --> Total execution time: 0.0996
DEBUG - 2022-12-31 17:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:19:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:19:56 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:19:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:19:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:19:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:19:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:19:57 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:19:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:19:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:19:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:19:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:19:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:19:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:50:24 --> Total execution time: 0.0875
DEBUG - 2022-12-31 17:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:20:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:20:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:20:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:20:24 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:20:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:20:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:20:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:20:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:20:24 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:20:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:20:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:20:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:51:40 --> Total execution time: 0.0979
DEBUG - 2022-12-31 17:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:21:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:21:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:51:47 --> Total execution time: 0.0799
DEBUG - 2022-12-31 17:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:21:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:21:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:52:41 --> Total execution time: 0.1004
DEBUG - 2022-12-31 17:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:22:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:22:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:22:44 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:22:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:22:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:22:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:22:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:22:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:22:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:22:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:54:58 --> Total execution time: 0.1016
DEBUG - 2022-12-31 17:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:24:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:24:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:24:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:24:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:24:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:24:58 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:24:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:24:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:24:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:24:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:25:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:04 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:25:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:25:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:25:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:25:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:25:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:25:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:25:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:55:50 --> Total execution time: 0.0961
DEBUG - 2022-12-31 17:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:25:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:25:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:25:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:25:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:25:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:51 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:25:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:25:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:25:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:25:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:55:56 --> Total execution time: 0.0801
DEBUG - 2022-12-31 17:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:55:58 --> Total execution time: 0.0793
DEBUG - 2022-12-31 17:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:58 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:25:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:25:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:25:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:25:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:25:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:25:59 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:25:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:25:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:25:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:25:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:56:34 --> Total execution time: 0.2202
DEBUG - 2022-12-31 17:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:57:02 --> Total execution time: 0.0931
DEBUG - 2022-12-31 17:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:27:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:03 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:27:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:27:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:03 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:27:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:57:04 --> Total execution time: 0.0866
DEBUG - 2022-12-31 17:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:57:07 --> Total execution time: 0.0803
DEBUG - 2022-12-31 17:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:27:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:07 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:27:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:27:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:57:37 --> Total execution time: 0.0836
DEBUG - 2022-12-31 17:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:37 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:27:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:27:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:27:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:27:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:27:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:57:52 --> Total execution time: 0.1047
DEBUG - 2022-12-31 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:52 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:27:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:27:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:27:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:58:15 --> Total execution time: 0.1826
DEBUG - 2022-12-31 17:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:28:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:28:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:28:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:28:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:28:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:28:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:28:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:28:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:28:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:28:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:58:28 --> Total execution time: 0.1714
DEBUG - 2022-12-31 17:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:28:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:28:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:28:28 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:28:28 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:28:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:28:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:28:28 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:28:28 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:28:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:28:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:28:28 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:28:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:04:20 --> Total execution time: 0.1299
DEBUG - 2022-12-31 17:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:34:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:21 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:34:21 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:34:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:34:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:34:21 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-31 17:34:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:34:21 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:34:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:34:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:34:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:34:21 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:34:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:04:28 --> Total execution time: 0.1091
DEBUG - 2022-12-31 17:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:34:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:04:32 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-31 22:04:32 --> You did not select a file to upload.
DEBUG - 2022-12-31 17:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:04:32 --> Total execution time: 0.0816
DEBUG - 2022-12-31 17:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:34:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:04:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-31 22:04:39 --> You did not select a file to upload.
DEBUG - 2022-12-31 17:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:04:39 --> Total execution time: 0.0784
DEBUG - 2022-12-31 17:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:34:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:04:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-31 22:04:48 --> You did not select a file to upload.
DEBUG - 2022-12-31 17:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:04:48 --> Total execution time: 0.0824
DEBUG - 2022-12-31 17:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:34:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:34:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 17:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:05:02 --> Total execution time: 0.0848
DEBUG - 2022-12-31 17:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:35:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:05:42 --> Total execution time: 0.1127
DEBUG - 2022-12-31 17:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:35:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:05:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-31 22:05:52 --> You did not select a file to upload.
DEBUG - 2022-12-31 17:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:05:52 --> Total execution time: 0.0859
DEBUG - 2022-12-31 17:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:35:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:35:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:11:46 --> Total execution time: 0.0966
DEBUG - 2022-12-31 17:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:41:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:41:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:12:09 --> Total execution time: 0.1102
DEBUG - 2022-12-31 17:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:42:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:42:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:12:24 --> Total execution time: 0.1007
DEBUG - 2022-12-31 17:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:42:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:42:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:13:42 --> Total execution time: 0.0985
DEBUG - 2022-12-31 17:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:43:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:43:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:43:45 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:43:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:43:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:43:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:43:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:43:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:43:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:43:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:43:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:14:56 --> Total execution time: 0.0928
DEBUG - 2022-12-31 17:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:44:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:44:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:44:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:44:57 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:44:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:44:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:44:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:44:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:44:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:44:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:44:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:15:13 --> Total execution time: 0.0751
DEBUG - 2022-12-31 17:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:15:33 --> Total execution time: 0.1001
DEBUG - 2022-12-31 17:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:45:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:45:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:15:35 --> Total execution time: 0.0858
DEBUG - 2022-12-31 17:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:45:49 --> UTF-8 Support Enabled
ERROR - 2022-12-31 17:45:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:45:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:45:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:45:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:45:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:45:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:45:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:45:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:45:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:45:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:45:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:16:47 --> Total execution time: 0.0857
DEBUG - 2022-12-31 17:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:16:52 --> Total execution time: 0.0776
DEBUG - 2022-12-31 17:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:17:13 --> Total execution time: 0.1117
DEBUG - 2022-12-31 17:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:17:26 --> Total execution time: 0.1157
DEBUG - 2022-12-31 17:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:17:36 --> Total execution time: 0.0851
DEBUG - 2022-12-31 17:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:47:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:47:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:47:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:47:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:47:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:47:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:47:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:47:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:47:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:47:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:47:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:47:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 17:47:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 17:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:17:53 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-31 22:17:53 --> You did not select a file to upload.
DEBUG - 2022-12-31 17:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:17:53 --> Total execution time: 0.0811
DEBUG - 2022-12-31 17:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:47:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:19:31 --> Total execution time: 0.0969
DEBUG - 2022-12-31 17:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:49:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:49:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:19:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-31 17:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:19:38 --> Total execution time: 0.0800
DEBUG - 2022-12-31 17:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:49:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:20:22 --> Total execution time: 0.0880
DEBUG - 2022-12-31 17:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:50:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:50:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 17:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 17:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 17:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:20:24 --> Total execution time: 0.0918
DEBUG - 2022-12-31 17:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 17:50:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 17:50:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:31:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:31:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:31:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:31:59 --> UTF-8 Support Enabled
ERROR - 2022-12-31 18:31:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:31:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:31:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:31:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:31:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:31:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:31:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:31:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:05:20 --> Total execution time: 0.0850
DEBUG - 2022-12-31 18:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:35:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:35:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:07:42 --> Total execution time: 0.1054
DEBUG - 2022-12-31 18:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:37:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:37:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:09:43 --> Total execution time: 0.1010
DEBUG - 2022-12-31 18:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:39:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:39:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:11:24 --> Total execution time: 0.0987
DEBUG - 2022-12-31 18:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:41:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:42:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-31 23:12:24 --> Severity: Notice --> Undefined property: CI_Loader::$Commercial_owners_details C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-kyc.php 50
ERROR - 2022-12-31 23:12:24 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\fundraiser-kyc.php 50
DEBUG - 2022-12-31 18:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:42:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:42:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:13:33 --> Total execution time: 0.0965
DEBUG - 2022-12-31 18:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:43:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:43:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:43:42 --> UTF-8 Support Enabled
ERROR - 2022-12-31 18:43:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:43:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:43:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:43:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:43:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:43:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:43:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:43:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:43:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:43:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:43:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:43:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:14:53 --> Total execution time: 0.1176
DEBUG - 2022-12-31 18:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:44:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:44:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:44:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:44:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:44:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:44:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:44:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:44:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:44:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:44:53 --> UTF-8 Support Enabled
ERROR - 2022-12-31 18:44:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:44:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:44:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:44:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:44:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:44:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:16:16 --> Total execution time: 0.1025
DEBUG - 2022-12-31 18:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:46:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:46:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:19:32 --> Total execution time: 0.0843
DEBUG - 2022-12-31 18:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:49:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:49:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:23:20 --> Total execution time: 0.0923
DEBUG - 2022-12-31 18:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:53:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 18:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:24:27 --> Total execution time: 0.0898
DEBUG - 2022-12-31 18:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:54:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:54:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:24:58 --> Total execution time: 0.1053
DEBUG - 2022-12-31 18:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:54:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 18:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:25:54 --> Total execution time: 0.0845
DEBUG - 2022-12-31 18:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:55:59 --> UTF-8 Support Enabled
ERROR - 2022-12-31 18:55:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:55:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:55:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:55:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:55:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:55:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:55:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:55:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 18:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:26:28 --> Total execution time: 0.1231
DEBUG - 2022-12-31 18:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:56:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:56:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:56:28 --> UTF-8 Support Enabled
ERROR - 2022-12-31 18:56:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:56:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:56:29 --> UTF-8 Support Enabled
ERROR - 2022-12-31 18:56:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:56:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:56:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:56:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:56:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:27:52 --> Total execution time: 0.0922
DEBUG - 2022-12-31 18:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:57:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:57:52 --> UTF-8 Support Enabled
ERROR - 2022-12-31 18:57:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:57:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:57:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:57:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 18:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:57:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:57:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:57:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 18:57:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 18:57:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 18:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 18:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 18:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 18:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:28:25 --> Upload class already loaded. Second attempt ignored.
ERROR - 2022-12-31 23:28:25 --> Severity: Notice --> Trying to get property 'kyc_document_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Profile_Controller.php 160
ERROR - 2022-12-31 23:28:25 --> Severity: Notice --> Trying to get property 'kyc_document_file' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Profile_Controller.php 160
ERROR - 2022-12-31 23:28:25 --> Severity: Notice --> Trying to get property 'kyc_logo_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Profile_Controller.php 169
ERROR - 2022-12-31 23:28:25 --> Severity: Notice --> Trying to get property 'kyc_logo' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Profile_Controller.php 169
ERROR - 2022-12-31 23:28:25 --> Query error: Column 'kyc_status' cannot be null - Invalid query: INSERT INTO `kyc` (`kyc_FK_ul_id`, `kyc_type`, `kyc_document_id`, `kyc_document_path`, `kyc_document_file`, `kyc_logo_path`, `kyc_logo`, `kyc_status`, `kyc_request_date`, `kyc_approve_date`) VALUES ('4', 'C', '65165564654', 'assets/uploads/kyc/', 't8gpjhenk17u7jacmb0q.jpg', 'assets/uploads/kyc/', 't8gpjhenk17u7jacmb0q1.jpg', NULL, '2022-12-31 23:28:25', '2022-12-31 23:28:25')
DEBUG - 2022-12-31 19:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:31:46 --> Total execution time: 0.0971
DEBUG - 2022-12-31 19:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:01:46 --> UTF-8 Support Enabled
ERROR - 2022-12-31 19:01:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:01:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:01:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:01:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:01:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:01:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:01:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:01:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:31:55 --> Upload class already loaded. Second attempt ignored.
ERROR - 2022-12-31 23:31:55 --> Query error: Column 'kyc_status' cannot be null - Invalid query: INSERT INTO `kyc` (`kyc_FK_ul_id`, `kyc_type`, `kyc_document_id`, `kyc_document_path`, `kyc_document_file`, `kyc_logo_path`, `kyc_logo`, `kyc_status`, `kyc_request_date`, `kyc_approve_date`) VALUES ('4', 'C', '65165564654', 'assets/uploads/kyc/', 'zd0d7zwl3kx58pfk67io.jpg', 'assets/uploads/kyc/', 'zd0d7zwl3kx58pfk67io1.jpg', NULL, '2022-12-31 23:31:55', '2022-12-31 23:31:55')
DEBUG - 2022-12-31 19:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:33:04 --> Total execution time: 0.0906
DEBUG - 2022-12-31 19:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:33:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-31 19:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:33:09 --> Total execution time: 0.0839
DEBUG - 2022-12-31 19:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:03:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:03:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:33:39 --> Total execution time: 0.1015
DEBUG - 2022-12-31 19:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:03:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:03:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:33:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-31 23:33:47 --> You did not select a file to upload.
DEBUG - 2022-12-31 23:33:47 --> You did not select a file to upload.
DEBUG - 2022-12-31 19:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:33:47 --> Total execution time: 0.0871
DEBUG - 2022-12-31 19:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:03:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:03:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:34:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-31 23:34:21 --> You did not select a file to upload.
DEBUG - 2022-12-31 23:34:21 --> You did not select a file to upload.
DEBUG - 2022-12-31 19:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:34:21 --> Total execution time: 0.0868
DEBUG - 2022-12-31 19:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:04:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:34:26 --> Total execution time: 0.1010
DEBUG - 2022-12-31 19:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:04:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:35:18 --> Total execution time: 0.0995
DEBUG - 2022-12-31 19:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:05:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:05:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:35:31 --> Total execution time: 0.1020
DEBUG - 2022-12-31 19:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:05:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:05:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:49:01 --> Total execution time: 0.0962
DEBUG - 2022-12-31 19:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:19:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:19:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:19:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:19:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:19:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:19:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:19:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:19:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:19:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:19:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:19:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:19:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:19:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:51:03 --> Total execution time: 0.1309
DEBUG - 2022-12-31 19:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:21:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:21:04 --> UTF-8 Support Enabled
ERROR - 2022-12-31 19:21:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:21:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:21:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:21:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:21:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:21:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:21:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:21:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:51:17 --> Total execution time: 0.1190
DEBUG - 2022-12-31 19:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:21:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:21:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:21:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:21:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:21:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:21:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:21:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:21:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:21:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:21:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:55:08 --> Total execution time: 0.1184
DEBUG - 2022-12-31 19:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:25:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:25:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:55:16 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-31 23:55:16 --> You did not select a file to upload.
DEBUG - 2022-12-31 23:55:16 --> You did not select a file to upload.
DEBUG - 2022-12-31 19:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:55:16 --> Total execution time: 0.0905
DEBUG - 2022-12-31 19:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:25:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:25:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:55:18 --> Total execution time: 0.1037
DEBUG - 2022-12-31 19:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:25:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:25:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 23:59:19 --> Total execution time: 0.1049
DEBUG - 2022-12-31 19:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:29:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:29:38 --> UTF-8 Support Enabled
ERROR - 2022-12-31 19:29:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:29:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:29:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:29:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:29:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:29:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:29:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:29:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:29:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:29:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:30:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:30:02 --> UTF-8 Support Enabled
ERROR - 2022-12-31 19:30:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:30:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:30:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:30:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:30:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:30:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:30:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:30:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:30:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:30:03 --> UTF-8 Support Enabled
ERROR - 2022-12-31 19:30:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:30:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:30:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:30:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:30:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:30:34 --> UTF-8 Support Enabled
ERROR - 2022-12-31 19:30:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:30:34 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:30:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:30:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:30:34 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:30:34 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:30:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:30:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:31:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:31:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:31:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:31:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:31:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:32:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:32:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:32:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:32:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:32:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:32:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:33:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:36:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:36:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:36:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:36:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:36:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:36:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:37:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:37:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:37:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:37:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:37:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:37:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:38:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:38:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:39:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:39:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:39:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:39:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:39:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:39:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:39:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:39:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:41:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:41:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:41:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:42:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:42:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:43:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:44:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:44:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:54:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:55:16 --> UTF-8 Support Enabled
ERROR - 2022-12-31 19:55:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:55:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:55:16 --> UTF-8 Support Enabled
ERROR - 2022-12-31 19:55:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:55:16 --> UTF-8 Support Enabled
ERROR - 2022-12-31 19:55:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:55:16 --> UTF-8 Support Enabled
ERROR - 2022-12-31 19:55:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:55:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:55:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:55:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:55:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:55:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:55:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:55:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:55:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:55:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:55:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:55:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:55:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:56:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:56:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:56:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:56:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:56:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:56:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:56:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:56:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:56:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:56:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:56:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:56:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:57:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:57:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:57:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:57:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:57:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:57:06 --> UTF-8 Support Enabled
ERROR - 2022-12-31 19:57:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:57:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:57:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:57:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 19:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 19:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:59:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 19:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:59:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:59:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:59:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:59:47 --> UTF-8 Support Enabled
ERROR - 2022-12-31 19:59:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:59:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 19:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:59:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 19:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 19:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 19:59:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 19:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:00:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:00:15 --> UTF-8 Support Enabled
ERROR - 2022-12-31 20:00:15 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:00:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:00:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:00:15 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:00:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:00:15 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:00:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:00:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:01:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:01:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:01:27 --> UTF-8 Support Enabled
ERROR - 2022-12-31 20:01:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:01:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:01:27 --> UTF-8 Support Enabled
ERROR - 2022-12-31 20:01:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:01:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:01:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:01:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:01:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:01:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:01:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:01:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:01:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:01:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:01:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:01:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:01:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:01:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:02:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:02:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:02:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:02:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:02:18 --> UTF-8 Support Enabled
ERROR - 2022-12-31 20:02:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:02:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:02:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:02:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:02:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:03:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:03:18 --> UTF-8 Support Enabled
ERROR - 2022-12-31 20:03:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:03:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:03:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:03:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:03:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:03:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:03:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:03:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:03:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:03:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:03:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:03:19 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:03:19 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:03:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:03:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:03:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:03:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:03:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:03:19 --> UTF-8 Support Enabled
ERROR - 2022-12-31 20:03:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:03:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:03:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:03:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:03:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:03:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:03:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:03:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:03:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:03:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:03:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:04:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:04:08 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:04:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:04:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:04:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:04:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:04:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:04:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:04:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:04:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:04:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:04:35 --> UTF-8 Support Enabled
ERROR - 2022-12-31 20:04:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:04:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:04:35 --> UTF-8 Support Enabled
ERROR - 2022-12-31 20:04:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:04:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:35 --> UTF-8 Support Enabled
ERROR - 2022-12-31 20:04:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:04:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:04:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:04:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:06:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:06:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:06:03 --> UTF-8 Support Enabled
ERROR - 2022-12-31 20:06:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:06:03 --> UTF-8 Support Enabled
ERROR - 2022-12-31 20:06:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:06:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:06:03 --> UTF-8 Support Enabled
ERROR - 2022-12-31 20:06:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:06:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:06:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:06:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-31 20:06:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:06:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:06:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-31 20:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:06:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:06:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:07:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:12:38 --> Total execution time: 0.1440
DEBUG - 2022-12-31 20:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:12:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:12:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:12:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:12:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:12:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:14:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:14:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:14:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:14:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:15:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:15:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:15:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:15:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:22:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:23:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:23:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:26:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:27:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:27:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:29:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:29:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:32:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:32:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:32:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:32:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:32:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:32:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:33:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:33:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:34:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:34:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:35:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:35:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:35:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:36:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:36:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:36:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:36:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:36:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:36:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:36:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:36:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:36:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:41:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:41:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:41:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:43:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:43:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:48:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:48:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:48:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:48:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:48:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:48:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:48:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:48:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:48:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:49:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:49:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:49:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:49:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:49:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:51:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:51:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:51:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:51:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:51:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:51:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:51:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:51:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:51:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:51:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:51:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:52:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 20:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 20:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 20:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 20:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 20:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 20:57:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:17:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:17:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:17:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:17:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:38:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:38:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:38:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:38:49 --> 404 Page Not Found: admin/Fundraiser-kyc-list/index
DEBUG - 2022-12-31 21:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:39:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:39:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:39:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:39:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:39:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:39:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:39:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:39:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:40:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:40:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:44:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:44:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:44:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:44:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:44:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:44:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:44:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:45:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:45:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:45:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:46:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:46:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:47:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:47:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:47:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:47:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:47:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:47:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:47:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:47:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:47:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:47:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:47:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:47:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:48:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:48:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:50:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 21:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 21:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 21:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 21:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 21:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 21:53:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:02:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:02:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:02:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:02:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:02:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:02:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:03:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:03:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:04:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:04:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:08:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:08:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:08:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:09:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:09:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:09:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:09:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:09:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:10:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:10:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:10:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:10:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:10:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:10:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:12:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:12:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:12:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:12:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:12:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:13:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:13:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:13:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:13:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:13:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:15:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:15:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:16:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:17:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:17:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:17:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:17:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:17:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:18:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:18:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:18:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:18:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:18:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:18:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:18:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:18:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:18:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:18:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:18:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:18:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:18:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:19:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:19:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:19:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:19:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:19:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:19:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:19:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:21:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:21:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:21:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:21:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:21:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:22:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:22:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:23:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:23:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:23:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:24:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:24:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:24:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:24:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:24:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:24:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:24:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:25:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:25:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:25:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:25:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:25:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:25:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:25:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:25:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:25:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:25:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:26:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:29:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:29:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:30:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:30:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-31 22:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 22:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-31 22:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-31 22:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 22:31:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-31 22:31:12 --> 404 Page Not Found: Assets/website_esa
