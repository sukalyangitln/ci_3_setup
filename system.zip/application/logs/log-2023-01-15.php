<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-15 12:46:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:46:58 --> No URI present. Default controller set.
DEBUG - 2023-01-15 12:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 12:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 12:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 17:16:59 --> Total execution time: 0.6771
DEBUG - 2023-01-15 12:47:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 12:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 12:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 17:17:08 --> Total execution time: 0.0960
DEBUG - 2023-01-15 12:47:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 12:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 12:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 17:17:12 --> Total execution time: 0.0744
DEBUG - 2023-01-15 12:54:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:54:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 12:54:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 12:54:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:54:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 12:54:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 12:54:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:54:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 12:54:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 12:54:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:54:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 12:54:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 12:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 12:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 17:26:36 --> Total execution time: 0.8123
DEBUG - 2023-01-15 12:56:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:56:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 12:56:37 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 12:56:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:56:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 12:56:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 12:56:37 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 12:56:37 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 12:56:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:56:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 12:56:37 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 12:57:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 12:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 12:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 17:27:47 --> Total execution time: 0.0486
DEBUG - 2023-01-15 12:57:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 12:57:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 12:57:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 12:57:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 12:57:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 12:57:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 12:57:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 12:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 12:57:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:03:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:03:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:03:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:03:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:03:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:03:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:03:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:03:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:03:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:03:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:03:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:03:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:04:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 17:34:16 --> Total execution time: 0.0819
DEBUG - 2023-01-15 13:04:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:04:16 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:04:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:04:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:04:16 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 13:04:16 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:04:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:04:16 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:07:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 17:37:25 --> Total execution time: 0.0515
DEBUG - 2023-01-15 13:08:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 17:38:55 --> Total execution time: 0.0708
DEBUG - 2023-01-15 13:08:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:08:59 --> 404 Page Not Found: Post-comment/index
DEBUG - 2023-01-15 13:09:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 17:39:00 --> Total execution time: 0.0451
DEBUG - 2023-01-15 13:34:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:04:58 --> Total execution time: 0.0596
DEBUG - 2023-01-15 13:35:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:35:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:35:00 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 13:35:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:35:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:35:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:35:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:35:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:35:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:05:13 --> Total execution time: 0.0586
DEBUG - 2023-01-15 13:35:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:05:41 --> Total execution time: 0.0713
DEBUG - 2023-01-15 13:35:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:35:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:35:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:35:41 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 13:35:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:35:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:35:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:35:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:05:46 --> Total execution time: 0.0630
DEBUG - 2023-01-15 13:35:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:05:46 --> Total execution time: 0.0930
DEBUG - 2023-01-15 13:35:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:35:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:35:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:35:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:35:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:35:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:35:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:35:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:35:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:36:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:06:22 --> Total execution time: 0.0751
DEBUG - 2023-01-15 13:36:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:06:26 --> Total execution time: 0.0398
DEBUG - 2023-01-15 13:36:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:06:26 --> Total execution time: 0.0419
DEBUG - 2023-01-15 13:36:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:36:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:36:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:36:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:36:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:36:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:36:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:36:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:36:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:36:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:36:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:36:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:37:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:07:12 --> Total execution time: 0.0618
DEBUG - 2023-01-15 13:37:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:37:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:37:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:37:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:37:12 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 13:37:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:37:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:37:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:37:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:07:13 --> Total execution time: 0.0602
DEBUG - 2023-01-15 13:37:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:37:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:37:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:37:13 --> UTF-8 Support Enabled
ERROR - 2023-01-15 13:37:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:37:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:37:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:37:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:37:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:07:18 --> Total execution time: 0.0384
DEBUG - 2023-01-15 13:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:07:18 --> Total execution time: 0.0426
DEBUG - 2023-01-15 13:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:37:18 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:37:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:37:18 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 13:37:18 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:37:18 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:37:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:37:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:37:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:37:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:37:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:37:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:37:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:38:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:08:06 --> Total execution time: 0.0733
DEBUG - 2023-01-15 13:38:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 13:38:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:08:09 --> Total execution time: 0.0738
DEBUG - 2023-01-15 13:38:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:08:16 --> Total execution time: 0.0500
DEBUG - 2023-01-15 13:38:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:08:21 --> Total execution time: 0.0664
DEBUG - 2023-01-15 13:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:38:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:38:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:38:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:38:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:08:46 --> Total execution time: 0.0674
DEBUG - 2023-01-15 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:38:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:38:46 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 13:38:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:38:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:38:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:08:55 --> Total execution time: 0.0541
DEBUG - 2023-01-15 13:39:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:09:19 --> Total execution time: 0.0697
DEBUG - 2023-01-15 13:41:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:11:43 --> Total execution time: 0.0431
DEBUG - 2023-01-15 13:44:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:14:03 --> Total execution time: 0.0704
DEBUG - 2023-01-15 13:44:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:14:26 --> Total execution time: 0.0470
DEBUG - 2023-01-15 13:44:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:44:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:44:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:44:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:44:26 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 13:44:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:44:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:44:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:44:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:14:33 --> Total execution time: 0.0614
DEBUG - 2023-01-15 13:49:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:20:00 --> Total execution time: 0.0538
DEBUG - 2023-01-15 13:50:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:50:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:50:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:50:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:50:00 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 13:50:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:50:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:50:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:20:14 --> Total execution time: 0.0673
DEBUG - 2023-01-15 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:50:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:50:14 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 13:50:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:50:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:50:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:50:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:51:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 13:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:21:07 --> Total execution time: 0.0469
DEBUG - 2023-01-15 13:51:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:51:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:51:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:51:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:51:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 13:51:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:51:07 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 13:51:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 13:51:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 13:51:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 13:51:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:04:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:34:12 --> Total execution time: 0.0505
DEBUG - 2023-01-15 14:04:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:04:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:04:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:04:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:04:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:04:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:04:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:04:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:04:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:04:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:04:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:04:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:04:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:34:20 --> Total execution time: 0.0661
DEBUG - 2023-01-15 14:04:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:34:57 --> Total execution time: 0.0653
DEBUG - 2023-01-15 14:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:36:09 --> Total execution time: 0.0637
DEBUG - 2023-01-15 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:06:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:06:10 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 14:06:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:06:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:06:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:36:20 --> Total execution time: 0.0450
DEBUG - 2023-01-15 14:06:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:36:23 --> Total execution time: 0.0645
DEBUG - 2023-01-15 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:41:19 --> Total execution time: 0.0689
DEBUG - 2023-01-15 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:11:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:11:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:11:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:11:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:41:33 --> Total execution time: 0.0459
DEBUG - 2023-01-15 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:11:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:11:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:11:33 --> UTF-8 Support Enabled
ERROR - 2023-01-15 14:11:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:11:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:11:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:11:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:11:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:43:57 --> Total execution time: 0.0600
DEBUG - 2023-01-15 14:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:13:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:13:57 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 14:13:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:13:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:14:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:44:03 --> Total execution time: 0.0493
DEBUG - 2023-01-15 14:14:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:44:08 --> Total execution time: 0.0508
DEBUG - 2023-01-15 14:14:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:44:36 --> Total execution time: 0.0467
DEBUG - 2023-01-15 14:14:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:14:36 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:14:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:14:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:14:36 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:14:36 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:14:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:14:36 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:44:44 --> Total execution time: 0.0502
DEBUG - 2023-01-15 14:14:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:44:51 --> Total execution time: 0.0724
DEBUG - 2023-01-15 14:14:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:44:54 --> Total execution time: 0.0453
DEBUG - 2023-01-15 14:14:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:44:57 --> Total execution time: 0.0455
DEBUG - 2023-01-15 14:15:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:45:14 --> Total execution time: 0.0464
DEBUG - 2023-01-15 14:16:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:46:07 --> Total execution time: 0.0457
DEBUG - 2023-01-15 14:17:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:47:28 --> Total execution time: 0.0668
DEBUG - 2023-01-15 14:17:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:17:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:17:50 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:17:50 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:17:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:17:50 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:17:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:17:50 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:48:36 --> Total execution time: 0.0723
DEBUG - 2023-01-15 14:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:18:36 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:18:36 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 14:18:36 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:18:36 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:19:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:49:54 --> Total execution time: 0.0655
DEBUG - 2023-01-15 14:19:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:19:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:19:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:19:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:19:55 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 14:19:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:19:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:19:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:20:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:20:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:20:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:20:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:21:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 18:51:27 --> Total execution time: 0.0432
DEBUG - 2023-01-15 14:21:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:21:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:21:27 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:21:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:21:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:21:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:21:27 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 14:21:27 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:21:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:21:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:21:27 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:22:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:22:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:22:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:22:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:22:35 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 14:22:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:22:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:22:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:31:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:01:01 --> Total execution time: 0.0535
DEBUG - 2023-01-15 14:32:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:02:01 --> Total execution time: 0.0487
DEBUG - 2023-01-15 14:33:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:03:22 --> Total execution time: 0.0514
DEBUG - 2023-01-15 14:35:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:05:30 --> Total execution time: 0.0724
DEBUG - 2023-01-15 14:35:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:05:53 --> Total execution time: 0.0762
DEBUG - 2023-01-15 14:36:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:06:03 --> Total execution time: 0.0755
DEBUG - 2023-01-15 14:40:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:10:15 --> Total execution time: 0.0763
DEBUG - 2023-01-15 14:40:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:10:49 --> Total execution time: 0.0743
DEBUG - 2023-01-15 14:40:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:40:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:40:53 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 14:40:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:40:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:40:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:40:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 14:40:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 14:44:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:14:13 --> Total execution time: 0.0808
DEBUG - 2023-01-15 14:49:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:19:51 --> Total execution time: 0.0584
DEBUG - 2023-01-15 14:55:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 14:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 14:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 14:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:25:44 --> Total execution time: 0.0600
DEBUG - 2023-01-15 15:02:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:02:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:02:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:02:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:02:44 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 15:02:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:02:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:02:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:02:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:32:46 --> Total execution time: 0.0794
DEBUG - 2023-01-15 15:02:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:02:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:02:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:02:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:02:46 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 15:02:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:02:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:02:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:02:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:02:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-15 19:32:51 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 84
ERROR - 2023-01-15 19:32:51 --> Severity: Notice --> Trying to get property 'p_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 84
DEBUG - 2023-01-15 19:32:51 --> Total execution time: 0.0773
DEBUG - 2023-01-15 15:04:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:34:15 --> Total execution time: 0.0687
DEBUG - 2023-01-15 15:04:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:34:32 --> Total execution time: 0.0539
DEBUG - 2023-01-15 15:05:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:35:21 --> Total execution time: 0.0843
DEBUG - 2023-01-15 15:05:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:05:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:05:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:05:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:05:22 --> UTF-8 Support Enabled
ERROR - 2023-01-15 15:05:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:05:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:05:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:05:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:05:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:05:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:05:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:35:27 --> Total execution time: 0.0694
DEBUG - 2023-01-15 15:05:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:35:34 --> Total execution time: 0.0518
DEBUG - 2023-01-15 15:05:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:35:49 --> Total execution time: 0.0740
DEBUG - 2023-01-15 15:15:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:45:28 --> Total execution time: 0.0598
DEBUG - 2023-01-15 15:15:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:15:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:15:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:15:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:15:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:15:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:15:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:15:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:15:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:15:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'cm_time' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 88
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 104
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'dntrs_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'dntrs_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 109
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'cm_message' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 110
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 113
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'cm_time' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 88
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 104
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'dntrs_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'dntrs_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 109
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'cm_message' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 110
ERROR - 2023-01-15 19:45:32 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 113
DEBUG - 2023-01-15 19:45:32 --> Total execution time: 0.0607
DEBUG - 2023-01-15 15:15:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:15:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'cm_time' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 88
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 104
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'dntrs_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'dntrs_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 109
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'cm_message' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 110
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 113
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'cm_time' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 88
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 104
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'dntrs_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'dntrs_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 109
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'cm_message' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 110
ERROR - 2023-01-15 19:45:34 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 113
DEBUG - 2023-01-15 19:45:34 --> Total execution time: 0.0815
DEBUG - 2023-01-15 15:15:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:15:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'cm_time' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 88
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 104
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'dntrs_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'dntrs_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 109
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'cm_message' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 110
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 113
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'cm_time' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 88
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 104
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'dntrs_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'dntrs_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 109
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'cm_message' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 110
ERROR - 2023-01-15 19:45:35 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 113
DEBUG - 2023-01-15 19:45:35 --> Total execution time: 0.0829
DEBUG - 2023-01-15 15:16:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:16:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'cm_time' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 88
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 104
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'dntrs_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'dntrs_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 109
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'cm_message' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 110
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 113
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'cm_time' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 88
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 104
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'dntrs_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'dntrs_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 106
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'dntrs_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 109
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'cm_message' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 110
ERROR - 2023-01-15 19:46:14 --> Severity: Notice --> Trying to get property 'cm_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 113
DEBUG - 2023-01-15 19:46:14 --> Total execution time: 0.0634
DEBUG - 2023-01-15 15:16:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:46:31 --> Total execution time: 0.0728
DEBUG - 2023-01-15 15:16:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:46:42 --> Total execution time: 0.0504
DEBUG - 2023-01-15 15:16:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:46:48 --> Total execution time: 0.0574
DEBUG - 2023-01-15 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:47:24 --> Total execution time: 0.0798
DEBUG - 2023-01-15 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:17:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:17:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:17:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:17:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:17:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:47:31 --> Total execution time: 0.0713
DEBUG - 2023-01-15 15:17:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:17:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:17:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:17:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:17:31 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 15:17:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:17:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:17:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:17:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:47:50 --> Total execution time: 0.1145
DEBUG - 2023-01-15 15:17:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:17:50 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:17:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:17:50 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 15:17:50 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:17:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:17:50 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:17:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:47:55 --> Total execution time: 0.0665
DEBUG - 2023-01-15 15:18:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:48:00 --> Total execution time: 0.0398
DEBUG - 2023-01-15 15:18:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:18:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:18:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:18:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:18:22 --> UTF-8 Support Enabled
ERROR - 2023-01-15 15:18:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:18:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:18:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:18:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:18:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:18:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:18:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:18:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:18:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:18:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:18:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:18:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:18:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:18:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:18:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:48:58 --> Total execution time: 0.0888
DEBUG - 2023-01-15 15:19:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:49:00 --> Total execution time: 0.0634
DEBUG - 2023-01-15 15:19:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:49:01 --> Total execution time: 0.0905
DEBUG - 2023-01-15 15:19:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:19:03 --> No URI present. Default controller set.
DEBUG - 2023-01-15 15:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:49:03 --> Total execution time: 0.1040
DEBUG - 2023-01-15 15:19:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:49:05 --> Total execution time: 0.0460
DEBUG - 2023-01-15 15:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:49:06 --> Total execution time: 0.0412
DEBUG - 2023-01-15 15:20:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:50:09 --> Total execution time: 0.0731
DEBUG - 2023-01-15 15:20:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:20:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:20:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:20:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:20:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:20:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:20:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:20:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:24:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:54:02 --> Total execution time: 0.0768
DEBUG - 2023-01-15 15:27:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:57:47 --> Total execution time: 0.0780
DEBUG - 2023-01-15 15:27:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:57:51 --> Total execution time: 0.0561
DEBUG - 2023-01-15 15:27:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:27:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:27:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:27:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:27:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:27:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:27:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:27:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:27:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:28:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:58:22 --> Total execution time: 0.0505
DEBUG - 2023-01-15 15:28:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:58:35 --> Total execution time: 0.0628
DEBUG - 2023-01-15 15:28:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:28:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:28:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:28:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:28:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:28:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:28:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:28:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:28:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:28:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:28:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:28:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:28:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:58:42 --> Total execution time: 0.0643
DEBUG - 2023-01-15 15:29:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:59:04 --> Total execution time: 0.0842
DEBUG - 2023-01-15 15:29:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:29:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:29:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:29:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:29:04 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 15:29:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:29:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:29:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:29:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:59:24 --> Total execution time: 0.0619
DEBUG - 2023-01-15 15:29:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:29:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:29:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:29:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:29:24 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 15:29:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:29:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:29:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:29:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 19:59:31 --> Total execution time: 0.0531
DEBUG - 2023-01-15 15:31:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:01:58 --> Total execution time: 0.0769
DEBUG - 2023-01-15 15:31:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:31:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:31:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:31:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:31:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:31:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:31:58 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 15:31:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:31:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:31:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:31:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:32:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:02:04 --> Total execution time: 0.0406
DEBUG - 2023-01-15 15:32:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:02:06 --> Total execution time: 0.0741
DEBUG - 2023-01-15 15:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:02:08 --> Total execution time: 0.0418
DEBUG - 2023-01-15 15:32:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:02:14 --> Total execution time: 0.0786
DEBUG - 2023-01-15 15:32:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 15:32:41 --> Total execution time: 0.0569
DEBUG - 2023-01-15 15:32:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 15:32:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:02:43 --> Total execution time: 0.1136
DEBUG - 2023-01-15 15:32:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:02:48 --> Total execution time: 0.0976
DEBUG - 2023-01-15 15:32:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:02:52 --> Total execution time: 0.1357
DEBUG - 2023-01-15 15:53:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:23:28 --> Total execution time: 0.0626
DEBUG - 2023-01-15 15:53:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:53:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:53:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:53:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:53:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:53:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:53:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 15:53:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 15:53:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:23:43 --> Total execution time: 0.0495
DEBUG - 2023-01-15 15:54:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:24:18 --> Total execution time: 0.0580
DEBUG - 2023-01-15 15:54:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:24:28 --> Total execution time: 0.0802
DEBUG - 2023-01-15 15:54:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:24:35 --> Total execution time: 0.0875
DEBUG - 2023-01-15 15:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:24:41 --> Total execution time: 0.0798
DEBUG - 2023-01-15 15:54:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:24:51 --> Total execution time: 0.0587
DEBUG - 2023-01-15 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:24:58 --> Total execution time: 0.0890
DEBUG - 2023-01-15 15:59:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:29:43 --> Total execution time: 0.0506
DEBUG - 2023-01-15 15:59:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 15:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 15:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 15:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:29:58 --> Total execution time: 0.0682
DEBUG - 2023-01-15 16:00:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:00:32 --> No URI present. Default controller set.
DEBUG - 2023-01-15 16:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:30:32 --> Total execution time: 0.0684
DEBUG - 2023-01-15 16:00:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:30:33 --> Total execution time: 0.0872
DEBUG - 2023-01-15 16:00:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:30:36 --> Total execution time: 0.0577
DEBUG - 2023-01-15 16:00:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:30:47 --> Total execution time: 0.2408
DEBUG - 2023-01-15 16:00:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 16:00:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:30:53 --> Total execution time: 0.0433
DEBUG - 2023-01-15 16:01:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 16:01:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:31:06 --> Total execution time: 0.1104
DEBUG - 2023-01-15 16:01:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:31:15 --> Total execution time: 0.0849
DEBUG - 2023-01-15 16:01:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:31:17 --> Total execution time: 0.1220
DEBUG - 2023-01-15 16:02:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:32:01 --> Total execution time: 0.0476
DEBUG - 2023-01-15 16:03:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 16:03:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:33:16 --> Total execution time: 0.0513
DEBUG - 2023-01-15 16:03:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:03:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 16:03:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-15 16:03:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-15 16:03:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 16:03:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-15 16:03:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:33:55 --> Total execution time: 0.0487
DEBUG - 2023-01-15 16:04:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:34:10 --> Total execution time: 0.0764
DEBUG - 2023-01-15 16:04:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:34:16 --> Total execution time: 0.0559
DEBUG - 2023-01-15 16:05:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:35:52 --> Total execution time: 0.0603
DEBUG - 2023-01-15 16:05:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:35:57 --> Total execution time: 0.0590
DEBUG - 2023-01-15 16:06:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:36:13 --> Total execution time: 0.0725
DEBUG - 2023-01-15 16:11:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:41:36 --> Total execution time: 0.0615
DEBUG - 2023-01-15 16:12:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:12:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 16:12:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 16:12:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:12:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:12:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 16:12:27 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-15 16:12:27 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 16:12:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:12:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 16:12:27 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 16:12:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:42:48 --> Total execution time: 0.0483
DEBUG - 2023-01-15 16:13:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:43:24 --> Total execution time: 0.0590
DEBUG - 2023-01-15 16:14:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:44:55 --> Total execution time: 0.0452
DEBUG - 2023-01-15 16:17:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:47:21 --> Total execution time: 0.0488
DEBUG - 2023-01-15 16:17:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:47:35 --> Total execution time: 0.0824
DEBUG - 2023-01-15 16:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:47:43 --> Total execution time: 0.0670
DEBUG - 2023-01-15 16:17:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:47:52 --> Total execution time: 0.0464
DEBUG - 2023-01-15 16:18:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:48:59 --> Total execution time: 0.0665
DEBUG - 2023-01-15 16:20:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:50:01 --> Total execution time: 0.0465
DEBUG - 2023-01-15 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:51:07 --> Total execution time: 0.0709
DEBUG - 2023-01-15 16:28:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:28:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 16:28:27 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 303
DEBUG - 2023-01-15 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:28:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-15 20:58:34 --> Severity: Notice --> Undefined variable: p_id C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 318
ERROR - 2023-01-15 20:58:34 --> Severity: Notice --> Undefined variable: limit C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 319
DEBUG - 2023-01-15 20:58:34 --> Total execution time: 0.0877
DEBUG - 2023-01-15 16:28:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:28:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-15 20:58:59 --> Severity: Notice --> Undefined variable: p_id C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 318
ERROR - 2023-01-15 20:58:59 --> Severity: Notice --> Undefined variable: limit C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 319
DEBUG - 2023-01-15 20:58:59 --> Total execution time: 0.0493
DEBUG - 2023-01-15 16:29:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:29:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-15 20:59:08 --> Severity: Notice --> Undefined variable: limit C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 319
DEBUG - 2023-01-15 20:59:08 --> Total execution time: 0.0865
DEBUG - 2023-01-15 16:29:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 16:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 16:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 16:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 20:59:15 --> Total execution time: 0.0651
DEBUG - 2023-01-15 17:02:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:32:59 --> Total execution time: 0.0556
DEBUG - 2023-01-15 17:03:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-15 17:03:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-15 17:03:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:03:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-15 17:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-15 17:03:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-15 17:03:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:03:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:03:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-15 17:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:03:04 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-15 17:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-15 17:04:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:34:23 --> Total execution time: 0.0567
DEBUG - 2023-01-15 17:13:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:43:41 --> Total execution time: 0.0568
DEBUG - 2023-01-15 17:13:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:43:43 --> Total execution time: 0.0447
DEBUG - 2023-01-15 17:13:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:43:44 --> Total execution time: 0.0633
DEBUG - 2023-01-15 17:14:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:44:01 --> Total execution time: 0.0599
DEBUG - 2023-01-15 17:14:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:44:03 --> Total execution time: 0.0765
DEBUG - 2023-01-15 17:15:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:45:11 --> Total execution time: 0.0862
DEBUG - 2023-01-15 17:15:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:45:17 --> Total execution time: 0.0707
DEBUG - 2023-01-15 17:17:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:47:42 --> Total execution time: 0.0526
DEBUG - 2023-01-15 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:48:36 --> Total execution time: 0.0752
DEBUG - 2023-01-15 17:19:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:49:52 --> Total execution time: 0.0776
DEBUG - 2023-01-15 17:19:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:19:54 --> 404 Page Not Found: fundraiser/Campaign_Controller/comment_status_update
DEBUG - 2023-01-15 17:19:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:19:55 --> 404 Page Not Found: fundraiser/Campaign_Controller/comment_status_update
DEBUG - 2023-01-15 17:20:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:50:02 --> Total execution time: 0.0787
DEBUG - 2023-01-15 17:20:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:50:04 --> Total execution time: 0.0414
DEBUG - 2023-01-15 17:20:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:50:06 --> Total execution time: 0.0532
DEBUG - 2023-01-15 17:20:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:50:07 --> Total execution time: 0.0636
DEBUG - 2023-01-15 17:20:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:50:08 --> Total execution time: 0.0651
DEBUG - 2023-01-15 17:23:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:53:15 --> Total execution time: 0.0686
DEBUG - 2023-01-15 17:24:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:54:20 --> Total execution time: 0.0645
DEBUG - 2023-01-15 17:28:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:58:20 --> Total execution time: 0.0618
DEBUG - 2023-01-15 17:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:28:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 17:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:28:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 17:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:28:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 17:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:28:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 17:29:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:59:31 --> Total execution time: 0.0467
DEBUG - 2023-01-15 17:29:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:59:34 --> Total execution time: 0.0816
DEBUG - 2023-01-15 17:29:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:59:34 --> Total execution time: 0.0439
DEBUG - 2023-01-15 17:29:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:59:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-15 21:59:52 --> You did not select a file to upload.
DEBUG - 2023-01-15 21:59:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-15 21:59:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-15 21:59:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-15 21:59:52 --> You did not select a file to upload.
DEBUG - 2023-01-15 21:59:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-15 21:59:52 --> You did not select a file to upload.
DEBUG - 2023-01-15 17:29:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:59:52 --> Total execution time: 0.0638
DEBUG - 2023-01-15 17:29:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 21:59:52 --> Total execution time: 0.0540
DEBUG - 2023-01-15 17:30:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 22:00:01 --> Total execution time: 0.0586
DEBUG - 2023-01-15 17:30:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 22:00:26 --> Total execution time: 0.0789
DEBUG - 2023-01-15 17:30:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 22:00:39 --> Total execution time: 0.0716
DEBUG - 2023-01-15 17:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 22:01:03 --> Total execution time: 0.0577
DEBUG - 2023-01-15 17:38:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:38:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-15 22:08:32 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting ';' or ',' C:\xampp\htdocs\gopal\crowd_funding\application\views\website\donate-view.php 120
DEBUG - 2023-01-15 17:38:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 22:08:41 --> Total execution time: 0.0924
DEBUG - 2023-01-15 17:38:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:38:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:38:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:38:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 17:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:38:49 --> UTF-8 Support Enabled
ERROR - 2023-01-15 17:38:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 17:38:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:38:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 17:38:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:38:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-15 17:38:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-15 17:39:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 22:09:59 --> Total execution time: 0.0775
DEBUG - 2023-01-15 17:40:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 22:10:50 --> Total execution time: 0.0538
DEBUG - 2023-01-15 17:40:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 22:10:55 --> Total execution time: 0.0607
DEBUG - 2023-01-15 17:40:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 22:10:56 --> Total execution time: 0.0594
DEBUG - 2023-01-15 17:40:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-15 17:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-15 17:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-15 17:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-15 22:10:59 --> Total execution time: 0.0580
