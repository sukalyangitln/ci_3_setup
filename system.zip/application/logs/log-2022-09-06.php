<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-09-06 00:01:49 --> Total execution time: 0.1200
DEBUG - 2022-09-06 00:05:00 --> Total execution time: 0.2569
DEBUG - 2022-09-06 00:05:38 --> Total execution time: 0.0673
DEBUG - 2022-09-06 00:06:04 --> Total execution time: 0.0695
DEBUG - 2022-09-06 00:07:33 --> Total execution time: 0.0749
DEBUG - 2022-09-06 00:10:08 --> Total execution time: 0.1052
DEBUG - 2022-09-06 00:11:35 --> Total execution time: 0.0995
DEBUG - 2022-09-06 00:14:21 --> Total execution time: 0.1037
DEBUG - 2022-09-06 00:14:35 --> Total execution time: 0.0979
DEBUG - 2022-09-06 00:14:39 --> Total execution time: 0.1304
DEBUG - 2022-09-06 00:14:48 --> Total execution time: 0.1215
DEBUG - 2022-09-06 00:15:03 --> Total execution time: 0.1358
DEBUG - 2022-09-06 00:15:41 --> Total execution time: 0.1354
DEBUG - 2022-09-06 00:15:50 --> Total execution time: 0.1034
DEBUG - 2022-09-06 00:15:56 --> Total execution time: 0.1302
DEBUG - 2022-09-06 00:17:30 --> Total execution time: 0.1214
DEBUG - 2022-09-06 00:24:45 --> Total execution time: 0.1179
DEBUG - 2022-09-06 00:27:37 --> Total execution time: 0.1218
DEBUG - 2022-09-06 00:28:56 --> Total execution time: 0.0813
DEBUG - 2022-09-06 00:30:02 --> Total execution time: 0.2616
DEBUG - 2022-09-06 00:36:29 --> Total execution time: 0.1333
DEBUG - 2022-09-06 00:36:39 --> Total execution time: 0.0989
DEBUG - 2022-09-06 00:36:54 --> Total execution time: 0.0654
DEBUG - 2022-09-06 00:37:16 --> Total execution time: 0.0982
DEBUG - 2022-09-06 00:44:15 --> Total execution time: 0.1350
DEBUG - 2022-09-06 00:48:01 --> Total execution time: 0.2412
DEBUG - 2022-09-06 00:48:03 --> Total execution time: 0.0969
DEBUG - 2022-09-06 00:48:03 --> Total execution time: 0.0937
DEBUG - 2022-09-06 00:48:47 --> Total execution time: 0.1211
DEBUG - 2022-09-06 00:50:45 --> Total execution time: 0.0967
DEBUG - 2022-09-06 00:54:44 --> Total execution time: 0.0651
DEBUG - 2022-09-06 01:13:05 --> Total execution time: 0.3188
DEBUG - 2022-09-06 01:15:36 --> Total execution time: 0.1120
DEBUG - 2022-09-06 01:15:46 --> Total execution time: 0.1558
DEBUG - 2022-09-06 01:15:53 --> Total execution time: 0.1161
DEBUG - 2022-09-06 01:15:57 --> Total execution time: 0.1159
DEBUG - 2022-09-06 01:16:06 --> Total execution time: 0.0905
DEBUG - 2022-09-06 01:22:50 --> Total execution time: 0.1494
DEBUG - 2022-09-06 01:24:44 --> Total execution time: 0.0900
DEBUG - 2022-09-06 01:27:26 --> Total execution time: 0.2510
DEBUG - 2022-09-06 01:30:03 --> Total execution time: 0.1242
DEBUG - 2022-09-06 01:31:01 --> Total execution time: 0.0702
DEBUG - 2022-09-06 01:31:03 --> Total execution time: 0.0950
DEBUG - 2022-09-06 01:41:06 --> Total execution time: 0.1423
DEBUG - 2022-09-06 01:48:45 --> Total execution time: 0.1362
DEBUG - 2022-09-06 01:49:06 --> Total execution time: 0.1001
DEBUG - 2022-09-06 01:49:17 --> Total execution time: 0.0936
DEBUG - 2022-09-06 02:12:52 --> Total execution time: 0.0991
DEBUG - 2022-09-06 02:18:11 --> Total execution time: 0.1192
DEBUG - 2022-09-06 02:19:34 --> Total execution time: 0.0711
DEBUG - 2022-09-06 02:24:07 --> Total execution time: 0.1299
DEBUG - 2022-09-06 02:24:27 --> Total execution time: 0.1151
DEBUG - 2022-09-06 02:24:40 --> Total execution time: 0.1060
DEBUG - 2022-09-06 02:25:02 --> Total execution time: 0.1062
DEBUG - 2022-09-06 02:30:02 --> Total execution time: 0.1718
DEBUG - 2022-09-06 02:30:25 --> Total execution time: 0.0663
DEBUG - 2022-09-06 02:33:40 --> Total execution time: 0.3524
DEBUG - 2022-09-06 02:59:53 --> Total execution time: 0.1695
DEBUG - 2022-09-06 03:17:25 --> Total execution time: 0.3111
DEBUG - 2022-09-06 03:30:03 --> Total execution time: 0.4971
DEBUG - 2022-09-06 04:07:25 --> Total execution time: 0.3382
DEBUG - 2022-09-06 04:10:15 --> Total execution time: 0.1612
DEBUG - 2022-09-06 04:16:32 --> Total execution time: 0.1511
DEBUG - 2022-09-06 04:17:19 --> Total execution time: 0.0977
DEBUG - 2022-09-06 04:17:54 --> Total execution time: 0.0970
DEBUG - 2022-09-06 04:17:54 --> Total execution time: 0.0630
DEBUG - 2022-09-06 04:17:55 --> Total execution time: 0.1135
DEBUG - 2022-09-06 04:30:03 --> Total execution time: 0.2249
DEBUG - 2022-09-06 05:08:36 --> Total execution time: 0.3272
DEBUG - 2022-09-06 05:08:57 --> Total execution time: 0.0970
DEBUG - 2022-09-06 05:10:02 --> Total execution time: 0.1375
DEBUG - 2022-09-06 05:10:49 --> Total execution time: 0.1157
DEBUG - 2022-09-06 05:10:58 --> Total execution time: 0.0999
DEBUG - 2022-09-06 05:11:03 --> Total execution time: 0.0993
DEBUG - 2022-09-06 05:11:34 --> Total execution time: 0.1191
DEBUG - 2022-09-06 05:11:37 --> Total execution time: 0.1256
DEBUG - 2022-09-06 05:11:52 --> Total execution time: 0.1459
DEBUG - 2022-09-06 05:11:59 --> Total execution time: 0.0996
DEBUG - 2022-09-06 05:12:02 --> Total execution time: 0.1048
DEBUG - 2022-09-06 05:16:16 --> Total execution time: 0.3396
DEBUG - 2022-09-06 05:16:19 --> Total execution time: 0.0639
DEBUG - 2022-09-06 05:16:34 --> Total execution time: 0.0964
DEBUG - 2022-09-06 05:16:39 --> Total execution time: 0.1066
DEBUG - 2022-09-06 05:16:42 --> Total execution time: 0.1079
DEBUG - 2022-09-06 05:16:47 --> Total execution time: 0.1141
DEBUG - 2022-09-06 05:17:26 --> Total execution time: 0.1100
DEBUG - 2022-09-06 05:23:58 --> Total execution time: 0.1247
DEBUG - 2022-09-06 05:27:53 --> Total execution time: 0.2611
DEBUG - 2022-09-06 05:27:53 --> Total execution time: 0.1051
DEBUG - 2022-09-06 05:27:54 --> Total execution time: 0.1015
DEBUG - 2022-09-06 05:28:24 --> Total execution time: 0.1123
DEBUG - 2022-09-06 05:30:02 --> Total execution time: 0.0791
DEBUG - 2022-09-06 05:51:37 --> Total execution time: 0.2804
DEBUG - 2022-09-06 05:51:38 --> Total execution time: 0.0756
DEBUG - 2022-09-06 05:51:43 --> Total execution time: 0.0612
DEBUG - 2022-09-06 05:51:52 --> Total execution time: 0.1179
DEBUG - 2022-09-06 05:51:57 --> Total execution time: 0.1402
DEBUG - 2022-09-06 05:52:04 --> Total execution time: 0.1334
DEBUG - 2022-09-06 05:52:20 --> Total execution time: 0.0997
DEBUG - 2022-09-06 05:52:31 --> Total execution time: 0.1040
DEBUG - 2022-09-06 05:52:49 --> Total execution time: 0.1026
DEBUG - 2022-09-06 05:53:09 --> Total execution time: 0.1442
DEBUG - 2022-09-06 05:53:36 --> Total execution time: 0.1549
DEBUG - 2022-09-06 05:54:12 --> Total execution time: 0.0681
DEBUG - 2022-09-06 06:04:34 --> Total execution time: 0.1399
DEBUG - 2022-09-06 06:04:35 --> Total execution time: 0.1156
DEBUG - 2022-09-06 06:04:45 --> Total execution time: 0.1117
DEBUG - 2022-09-06 06:05:23 --> Total execution time: 0.0703
DEBUG - 2022-09-06 06:21:18 --> Total execution time: 0.2564
DEBUG - 2022-09-06 06:23:32 --> Total execution time: 0.3989
DEBUG - 2022-09-06 06:25:33 --> Total execution time: 0.0644
DEBUG - 2022-09-06 06:26:12 --> Total execution time: 0.0940
DEBUG - 2022-09-06 06:27:01 --> Total execution time: 0.1232
DEBUG - 2022-09-06 06:27:25 --> Total execution time: 0.0652
DEBUG - 2022-09-06 06:27:26 --> Total execution time: 0.1337
DEBUG - 2022-09-06 06:27:26 --> Total execution time: 0.0634
DEBUG - 2022-09-06 06:28:25 --> Total execution time: 0.0640
DEBUG - 2022-09-06 06:28:54 --> Total execution time: 0.1100
DEBUG - 2022-09-06 06:30:02 --> Total execution time: 0.1040
DEBUG - 2022-09-06 06:30:31 --> Total execution time: 0.0636
DEBUG - 2022-09-06 06:30:49 --> Total execution time: 0.2686
DEBUG - 2022-09-06 06:30:53 --> Total execution time: 0.0996
DEBUG - 2022-09-06 06:30:57 --> Total execution time: 0.1429
DEBUG - 2022-09-06 06:31:03 --> Total execution time: 0.1076
DEBUG - 2022-09-06 06:31:08 --> Total execution time: 0.1085
DEBUG - 2022-09-06 06:31:16 --> Total execution time: 0.1116
DEBUG - 2022-09-06 06:31:34 --> Total execution time: 0.0954
DEBUG - 2022-09-06 06:34:07 --> Total execution time: 0.1124
DEBUG - 2022-09-06 06:34:39 --> Total execution time: 0.1162
DEBUG - 2022-09-06 06:34:53 --> Total execution time: 0.1255
DEBUG - 2022-09-06 06:35:05 --> Total execution time: 0.1202
DEBUG - 2022-09-06 06:35:12 --> Total execution time: 0.1362
DEBUG - 2022-09-06 06:35:35 --> Total execution time: 0.1019
DEBUG - 2022-09-06 06:40:14 --> Total execution time: 0.1750
DEBUG - 2022-09-06 06:40:51 --> Total execution time: 0.0943
DEBUG - 2022-09-06 06:41:25 --> Total execution time: 0.1637
DEBUG - 2022-09-06 06:41:30 --> Total execution time: 0.1198
DEBUG - 2022-09-06 06:41:33 --> Total execution time: 0.1382
DEBUG - 2022-09-06 06:41:41 --> Total execution time: 0.1059
DEBUG - 2022-09-06 06:42:25 --> Total execution time: 0.0605
DEBUG - 2022-09-06 06:43:09 --> Total execution time: 0.1260
DEBUG - 2022-09-06 06:47:56 --> Total execution time: 0.1693
DEBUG - 2022-09-06 06:49:29 --> Total execution time: 0.2730
DEBUG - 2022-09-06 06:49:35 --> Total execution time: 0.1152
DEBUG - 2022-09-06 06:49:43 --> Total execution time: 0.1082
DEBUG - 2022-09-06 06:58:07 --> Total execution time: 0.1500
DEBUG - 2022-09-06 06:58:16 --> Total execution time: 0.0777
DEBUG - 2022-09-06 06:58:54 --> Total execution time: 0.3017
DEBUG - 2022-09-06 06:58:54 --> Total execution time: 0.1062
DEBUG - 2022-09-06 06:59:06 --> Total execution time: 0.1167
DEBUG - 2022-09-06 06:59:11 --> Total execution time: 0.1188
DEBUG - 2022-09-06 07:06:24 --> Total execution time: 0.1021
DEBUG - 2022-09-06 07:07:45 --> Total execution time: 0.1046
DEBUG - 2022-09-06 07:07:51 --> Total execution time: 0.0724
DEBUG - 2022-09-06 07:08:01 --> Total execution time: 0.2126
DEBUG - 2022-09-06 07:08:06 --> Total execution time: 0.1706
DEBUG - 2022-09-06 07:09:47 --> Total execution time: 0.0769
DEBUG - 2022-09-06 07:10:27 --> Total execution time: 0.0668
DEBUG - 2022-09-06 07:19:30 --> Total execution time: 0.1405
DEBUG - 2022-09-06 07:19:35 --> Total execution time: 0.0963
DEBUG - 2022-09-06 07:19:35 --> Total execution time: 0.0960
DEBUG - 2022-09-06 07:19:46 --> Total execution time: 0.1113
DEBUG - 2022-09-06 07:19:53 --> Total execution time: 0.1203
DEBUG - 2022-09-06 07:20:00 --> Total execution time: 0.1170
DEBUG - 2022-09-06 07:20:20 --> Total execution time: 0.0963
DEBUG - 2022-09-06 07:26:00 --> Total execution time: 0.1278
DEBUG - 2022-09-06 07:26:01 --> Total execution time: 0.0948
DEBUG - 2022-09-06 07:26:35 --> Total execution time: 0.0680
DEBUG - 2022-09-06 07:27:18 --> Total execution time: 2.3405
DEBUG - 2022-09-06 07:28:00 --> Total execution time: 0.1115
DEBUG - 2022-09-06 07:28:06 --> Total execution time: 0.1098
DEBUG - 2022-09-06 07:28:13 --> Total execution time: 0.1287
DEBUG - 2022-09-06 07:28:22 --> Total execution time: 0.1316
DEBUG - 2022-09-06 07:30:02 --> Total execution time: 0.0760
DEBUG - 2022-09-06 07:31:20 --> Total execution time: 0.1077
DEBUG - 2022-09-06 07:32:07 --> Total execution time: 0.1024
DEBUG - 2022-09-06 07:32:14 --> Total execution time: 0.1070
DEBUG - 2022-09-06 07:32:29 --> Total execution time: 0.1055
DEBUG - 2022-09-06 07:32:57 --> Total execution time: 0.1352
DEBUG - 2022-09-06 07:33:15 --> Total execution time: 0.1031
DEBUG - 2022-09-06 07:33:17 --> Total execution time: 0.1292
DEBUG - 2022-09-06 07:33:31 --> Total execution time: 0.1426
DEBUG - 2022-09-06 07:33:46 --> Total execution time: 0.1265
DEBUG - 2022-09-06 07:34:25 --> Total execution time: 0.2592
DEBUG - 2022-09-06 07:34:43 --> Total execution time: 0.1036
DEBUG - 2022-09-06 07:34:52 --> Total execution time: 0.0985
DEBUG - 2022-09-06 07:35:03 --> Total execution time: 0.1890
DEBUG - 2022-09-06 07:35:04 --> Total execution time: 0.1003
DEBUG - 2022-09-06 07:35:23 --> Total execution time: 1.8183
DEBUG - 2022-09-06 07:36:21 --> Total execution time: 0.0980
DEBUG - 2022-09-06 07:36:31 --> Total execution time: 0.3229
DEBUG - 2022-09-06 07:36:39 --> Total execution time: 0.1211
DEBUG - 2022-09-06 07:36:40 --> Total execution time: 0.1074
DEBUG - 2022-09-06 07:36:57 --> Total execution time: 0.1105
DEBUG - 2022-09-06 07:37:01 --> Total execution time: 0.1313
DEBUG - 2022-09-06 07:37:02 --> Total execution time: 0.1064
DEBUG - 2022-09-06 07:37:07 --> Total execution time: 0.0639
DEBUG - 2022-09-06 07:37:09 --> Total execution time: 0.1085
DEBUG - 2022-09-06 07:37:26 --> Total execution time: 0.1142
DEBUG - 2022-09-06 07:37:31 --> Total execution time: 0.1404
DEBUG - 2022-09-06 07:37:32 --> Total execution time: 0.1729
DEBUG - 2022-09-06 07:37:34 --> Total execution time: 0.2601
DEBUG - 2022-09-06 07:37:40 --> Total execution time: 0.1042
DEBUG - 2022-09-06 07:37:42 --> Total execution time: 0.1382
DEBUG - 2022-09-06 07:37:55 --> Total execution time: 0.1716
DEBUG - 2022-09-06 07:37:56 --> Total execution time: 0.1107
DEBUG - 2022-09-06 07:38:07 --> Total execution time: 0.1043
DEBUG - 2022-09-06 07:38:07 --> Total execution time: 0.1640
DEBUG - 2022-09-06 07:38:21 --> Total execution time: 0.1197
DEBUG - 2022-09-06 07:38:25 --> Total execution time: 0.1014
DEBUG - 2022-09-06 07:38:26 --> Total execution time: 0.1044
DEBUG - 2022-09-06 07:38:32 --> Total execution time: 0.1070
DEBUG - 2022-09-06 07:38:35 --> Total execution time: 0.1599
DEBUG - 2022-09-06 07:38:36 --> Total execution time: 0.1284
DEBUG - 2022-09-06 07:38:37 --> Total execution time: 0.1355
DEBUG - 2022-09-06 07:38:40 --> Total execution time: 0.1130
DEBUG - 2022-09-06 07:38:40 --> Total execution time: 0.1209
DEBUG - 2022-09-06 07:38:47 --> Total execution time: 0.1233
DEBUG - 2022-09-06 07:39:11 --> Total execution time: 0.0997
DEBUG - 2022-09-06 07:39:19 --> Total execution time: 0.1069
DEBUG - 2022-09-06 07:39:23 --> Total execution time: 0.0958
DEBUG - 2022-09-06 07:39:25 --> Total execution time: 0.0943
DEBUG - 2022-09-06 07:39:28 --> Total execution time: 0.0980
DEBUG - 2022-09-06 07:39:38 --> Total execution time: 0.1245
DEBUG - 2022-09-06 07:39:45 --> Total execution time: 0.1047
DEBUG - 2022-09-06 07:39:45 --> Total execution time: 0.1476
DEBUG - 2022-09-06 07:40:06 --> Total execution time: 0.1077
DEBUG - 2022-09-06 07:40:49 --> Total execution time: 0.0638
DEBUG - 2022-09-06 07:40:50 --> Total execution time: 0.0640
DEBUG - 2022-09-06 07:41:01 --> Total execution time: 0.0627
DEBUG - 2022-09-06 07:42:49 --> Total execution time: 0.0970
DEBUG - 2022-09-06 07:42:55 --> Total execution time: 0.0949
DEBUG - 2022-09-06 07:42:58 --> Total execution time: 0.0600
DEBUG - 2022-09-06 07:42:58 --> Total execution time: 0.0564
DEBUG - 2022-09-06 07:43:00 --> Total execution time: 0.0947
DEBUG - 2022-09-06 07:43:28 --> Total execution time: 0.0642
DEBUG - 2022-09-06 07:43:30 --> Total execution time: 0.1287
DEBUG - 2022-09-06 07:43:36 --> Total execution time: 0.0641
DEBUG - 2022-09-06 07:43:58 --> Total execution time: 0.1166
DEBUG - 2022-09-06 07:43:59 --> Total execution time: 0.1177
DEBUG - 2022-09-06 07:44:13 --> Total execution time: 0.1071
DEBUG - 2022-09-06 07:44:17 --> Total execution time: 0.1063
DEBUG - 2022-09-06 07:44:23 --> Total execution time: 0.1212
DEBUG - 2022-09-06 07:44:53 --> Total execution time: 0.0713
DEBUG - 2022-09-06 07:48:38 --> Total execution time: 0.3252
DEBUG - 2022-09-06 07:49:51 --> Total execution time: 0.0789
DEBUG - 2022-09-06 07:50:00 --> Total execution time: 0.0757
DEBUG - 2022-09-06 07:50:29 --> Total execution time: 0.1042
DEBUG - 2022-09-06 07:51:30 --> Total execution time: 0.1030
DEBUG - 2022-09-06 07:51:35 --> Total execution time: 0.0943
DEBUG - 2022-09-06 07:52:05 --> Total execution time: 0.1126
DEBUG - 2022-09-06 07:52:07 --> Total execution time: 0.1084
DEBUG - 2022-09-06 07:52:20 --> Total execution time: 0.0977
DEBUG - 2022-09-06 07:52:55 --> Total execution time: 0.1019
DEBUG - 2022-09-06 07:53:20 --> Total execution time: 0.1062
DEBUG - 2022-09-06 07:56:44 --> Total execution time: 0.1114
DEBUG - 2022-09-06 07:56:54 --> Total execution time: 0.0722
DEBUG - 2022-09-06 07:56:55 --> Total execution time: 0.0904
DEBUG - 2022-09-06 07:56:56 --> Total execution time: 0.0638
DEBUG - 2022-09-06 07:57:05 --> Total execution time: 0.0669
DEBUG - 2022-09-06 07:57:09 --> Total execution time: 0.0617
DEBUG - 2022-09-06 07:57:10 --> Total execution time: 0.0634
DEBUG - 2022-09-06 07:57:36 --> Total execution time: 0.0604
DEBUG - 2022-09-06 07:57:51 --> Total execution time: 0.1047
DEBUG - 2022-09-06 07:57:53 --> Total execution time: 0.0774
DEBUG - 2022-09-06 07:58:10 --> Total execution time: 0.0601
DEBUG - 2022-09-06 07:58:21 --> Total execution time: 0.1272
DEBUG - 2022-09-06 07:58:37 --> Total execution time: 0.1527
DEBUG - 2022-09-06 07:58:57 --> Total execution time: 0.1187
DEBUG - 2022-09-06 07:59:14 --> Total execution time: 0.0969
DEBUG - 2022-09-06 07:59:25 --> Total execution time: 0.0968
DEBUG - 2022-09-06 07:59:53 --> Total execution time: 0.3252
DEBUG - 2022-09-06 08:00:02 --> Total execution time: 0.1204
DEBUG - 2022-09-06 08:01:32 --> Total execution time: 0.1273
DEBUG - 2022-09-06 08:01:35 --> Total execution time: 0.1324
DEBUG - 2022-09-06 08:01:51 --> Total execution time: 0.0860
DEBUG - 2022-09-06 08:01:54 --> Total execution time: 0.1025
DEBUG - 2022-09-06 08:03:14 --> Total execution time: 0.0635
DEBUG - 2022-09-06 08:03:15 --> Total execution time: 0.0966
DEBUG - 2022-09-06 08:03:21 --> Total execution time: 0.0605
DEBUG - 2022-09-06 08:03:40 --> Total execution time: 0.1048
DEBUG - 2022-09-06 08:03:50 --> Total execution time: 0.1163
DEBUG - 2022-09-06 08:04:05 --> Total execution time: 0.1107
DEBUG - 2022-09-06 08:04:06 --> Total execution time: 0.1026
DEBUG - 2022-09-06 08:05:26 --> Total execution time: 0.0843
DEBUG - 2022-09-06 08:10:38 --> Total execution time: 0.1401
DEBUG - 2022-09-06 08:10:40 --> Total execution time: 0.0568
DEBUG - 2022-09-06 08:11:07 --> Total execution time: 0.0659
DEBUG - 2022-09-06 08:13:36 --> Total execution time: 0.1236
DEBUG - 2022-09-06 08:13:40 --> Total execution time: 0.2642
DEBUG - 2022-09-06 08:13:45 --> Total execution time: 0.2504
DEBUG - 2022-09-06 08:14:39 --> Total execution time: 0.1077
DEBUG - 2022-09-06 08:15:06 --> Total execution time: 0.0714
DEBUG - 2022-09-06 08:15:07 --> Total execution time: 0.0965
DEBUG - 2022-09-06 08:15:21 --> Total execution time: 0.0986
DEBUG - 2022-09-06 08:15:32 --> Total execution time: 0.0989
DEBUG - 2022-09-06 08:15:33 --> Total execution time: 0.1069
DEBUG - 2022-09-06 08:15:43 --> Total execution time: 0.0928
DEBUG - 2022-09-06 08:15:59 --> Total execution time: 0.0950
DEBUG - 2022-09-06 08:16:01 --> Total execution time: 0.0932
DEBUG - 2022-09-06 08:16:19 --> Total execution time: 0.2756
DEBUG - 2022-09-06 08:16:20 --> Total execution time: 0.1192
DEBUG - 2022-09-06 08:17:13 --> Total execution time: 0.1048
DEBUG - 2022-09-06 08:17:16 --> Total execution time: 0.1083
DEBUG - 2022-09-06 08:17:57 --> Total execution time: 0.0999
DEBUG - 2022-09-06 08:18:00 --> Total execution time: 0.1147
DEBUG - 2022-09-06 08:18:09 --> Total execution time: 0.1476
DEBUG - 2022-09-06 08:18:13 --> Total execution time: 0.0638
DEBUG - 2022-09-06 08:18:15 --> Total execution time: 0.0653
DEBUG - 2022-09-06 08:18:36 --> Total execution time: 0.0979
DEBUG - 2022-09-06 08:18:38 --> Total execution time: 0.1079
DEBUG - 2022-09-06 08:19:09 --> Total execution time: 0.2644
DEBUG - 2022-09-06 08:19:26 --> Total execution time: 0.1088
DEBUG - 2022-09-06 08:19:37 --> Total execution time: 0.1493
DEBUG - 2022-09-06 08:19:37 --> Total execution time: 0.1666
DEBUG - 2022-09-06 08:19:41 --> Total execution time: 0.0946
DEBUG - 2022-09-06 08:19:43 --> Total execution time: 0.0967
DEBUG - 2022-09-06 08:19:51 --> Total execution time: 0.0966
DEBUG - 2022-09-06 08:19:52 --> Total execution time: 0.1018
DEBUG - 2022-09-06 08:19:58 --> Total execution time: 0.0962
DEBUG - 2022-09-06 08:20:05 --> Total execution time: 0.1021
DEBUG - 2022-09-06 08:20:15 --> Total execution time: 0.2760
DEBUG - 2022-09-06 08:20:20 --> Total execution time: 0.1350
DEBUG - 2022-09-06 08:20:29 --> Total execution time: 0.0942
DEBUG - 2022-09-06 08:20:33 --> Total execution time: 0.1004
DEBUG - 2022-09-06 08:20:35 --> Total execution time: 0.0922
DEBUG - 2022-09-06 08:20:38 --> Total execution time: 0.0914
DEBUG - 2022-09-06 08:20:39 --> Total execution time: 0.1003
DEBUG - 2022-09-06 08:20:44 --> Total execution time: 0.1038
DEBUG - 2022-09-06 08:20:46 --> Total execution time: 0.0748
DEBUG - 2022-09-06 08:20:52 --> Total execution time: 0.1026
DEBUG - 2022-09-06 08:20:59 --> Total execution time: 0.0963
DEBUG - 2022-09-06 08:21:04 --> Total execution time: 0.1101
DEBUG - 2022-09-06 08:21:07 --> Total execution time: 0.1060
DEBUG - 2022-09-06 08:21:21 --> Total execution time: 0.1286
DEBUG - 2022-09-06 08:21:25 --> Total execution time: 0.1018
DEBUG - 2022-09-06 08:23:04 --> Total execution time: 0.0992
DEBUG - 2022-09-06 08:23:20 --> Total execution time: 0.1041
DEBUG - 2022-09-06 08:23:37 --> Total execution time: 0.1092
DEBUG - 2022-09-06 08:23:50 --> Total execution time: 0.1297
DEBUG - 2022-09-06 08:23:52 --> Total execution time: 0.1018
DEBUG - 2022-09-06 08:24:04 --> Total execution time: 0.1159
DEBUG - 2022-09-06 08:25:31 --> Total execution time: 0.2610
DEBUG - 2022-09-06 08:25:45 --> Total execution time: 0.1005
DEBUG - 2022-09-06 08:25:49 --> Total execution time: 0.0954
DEBUG - 2022-09-06 08:26:44 --> Total execution time: 0.0948
DEBUG - 2022-09-06 08:26:58 --> Total execution time: 0.1019
DEBUG - 2022-09-06 08:27:15 --> Total execution time: 0.0909
DEBUG - 2022-09-06 08:27:18 --> Total execution time: 0.0990
DEBUG - 2022-09-06 08:27:19 --> Total execution time: 0.0936
DEBUG - 2022-09-06 08:27:24 --> Total execution time: 0.0970
DEBUG - 2022-09-06 08:27:25 --> Total execution time: 0.0938
DEBUG - 2022-09-06 08:27:44 --> Total execution time: 0.0969
DEBUG - 2022-09-06 08:27:47 --> Total execution time: 0.0982
DEBUG - 2022-09-06 08:27:52 --> Total execution time: 0.1097
DEBUG - 2022-09-06 08:28:11 --> Total execution time: 0.2694
DEBUG - 2022-09-06 08:28:45 --> Total execution time: 0.1002
DEBUG - 2022-09-06 08:28:57 --> Total execution time: 0.1193
DEBUG - 2022-09-06 08:29:01 --> Total execution time: 0.1085
DEBUG - 2022-09-06 08:29:03 --> Total execution time: 0.0952
DEBUG - 2022-09-06 08:29:10 --> Total execution time: 0.1130
DEBUG - 2022-09-06 08:29:37 --> Total execution time: 0.0966
DEBUG - 2022-09-06 08:30:02 --> Total execution time: 0.1039
DEBUG - 2022-09-06 08:30:16 --> Total execution time: 0.1135
DEBUG - 2022-09-06 08:30:30 --> Total execution time: 0.1227
DEBUG - 2022-09-06 08:31:07 --> Total execution time: 0.0965
DEBUG - 2022-09-06 08:33:26 --> Total execution time: 0.3675
DEBUG - 2022-09-06 08:33:30 --> Total execution time: 0.1083
DEBUG - 2022-09-06 08:34:26 --> Total execution time: 0.2680
DEBUG - 2022-09-06 08:34:31 --> Total execution time: 0.1081
DEBUG - 2022-09-06 08:34:32 --> Total execution time: 0.2568
DEBUG - 2022-09-06 08:34:43 --> Total execution time: 0.1078
DEBUG - 2022-09-06 08:35:10 --> Total execution time: 0.1094
DEBUG - 2022-09-06 08:36:25 --> Total execution time: 0.1293
DEBUG - 2022-09-06 08:36:31 --> Total execution time: 0.1027
DEBUG - 2022-09-06 08:36:50 --> Total execution time: 0.0675
DEBUG - 2022-09-06 08:36:52 --> Total execution time: 0.0656
DEBUG - 2022-09-06 08:37:09 --> Total execution time: 0.0578
DEBUG - 2022-09-06 08:37:09 --> Total execution time: 0.0956
DEBUG - 2022-09-06 08:37:14 --> Total execution time: 0.1066
DEBUG - 2022-09-06 08:37:15 --> Total execution time: 0.1068
DEBUG - 2022-09-06 08:37:17 --> Total execution time: 0.1139
DEBUG - 2022-09-06 08:37:20 --> Total execution time: 0.0978
DEBUG - 2022-09-06 08:37:23 --> Total execution time: 0.1039
DEBUG - 2022-09-06 08:37:25 --> Total execution time: 0.1399
DEBUG - 2022-09-06 08:37:25 --> Total execution time: 0.1454
DEBUG - 2022-09-06 08:37:29 --> Total execution time: 0.0997
DEBUG - 2022-09-06 08:37:31 --> Total execution time: 0.0975
DEBUG - 2022-09-06 08:37:58 --> Total execution time: 0.1041
DEBUG - 2022-09-06 08:37:58 --> Total execution time: 0.1191
DEBUG - 2022-09-06 08:38:05 --> Total execution time: 0.0968
DEBUG - 2022-09-06 08:38:15 --> Total execution time: 0.1052
DEBUG - 2022-09-06 08:38:54 --> Total execution time: 0.1065
DEBUG - 2022-09-06 08:39:10 --> Total execution time: 0.2712
DEBUG - 2022-09-06 08:39:20 --> Total execution time: 0.1093
DEBUG - 2022-09-06 08:40:01 --> Total execution time: 0.2754
DEBUG - 2022-09-06 08:40:05 --> Total execution time: 0.0728
DEBUG - 2022-09-06 08:40:22 --> Total execution time: 0.1059
DEBUG - 2022-09-06 08:40:36 --> Total execution time: 0.1022
DEBUG - 2022-09-06 08:40:40 --> Total execution time: 0.0990
DEBUG - 2022-09-06 08:40:42 --> Total execution time: 0.1006
DEBUG - 2022-09-06 08:40:50 --> Total execution time: 0.0891
DEBUG - 2022-09-06 08:40:53 --> Total execution time: 0.0650
DEBUG - 2022-09-06 08:41:07 --> Total execution time: 0.0714
DEBUG - 2022-09-06 08:41:19 --> Total execution time: 0.0985
DEBUG - 2022-09-06 08:41:36 --> Total execution time: 0.1364
DEBUG - 2022-09-06 08:41:38 --> Total execution time: 0.1020
DEBUG - 2022-09-06 08:41:49 --> Total execution time: 0.1263
DEBUG - 2022-09-06 08:41:54 --> Total execution time: 0.1033
DEBUG - 2022-09-06 08:41:55 --> Total execution time: 0.1228
DEBUG - 2022-09-06 08:41:59 --> Total execution time: 0.1382
DEBUG - 2022-09-06 08:42:01 --> Total execution time: 0.1136
DEBUG - 2022-09-06 08:42:12 --> Total execution time: 0.0689
DEBUG - 2022-09-06 08:42:56 --> Total execution time: 0.0666
DEBUG - 2022-09-06 08:45:02 --> Total execution time: 0.1673
DEBUG - 2022-09-06 08:45:11 --> Total execution time: 0.0670
DEBUG - 2022-09-06 08:46:31 --> Total execution time: 0.1033
DEBUG - 2022-09-06 08:46:39 --> Total execution time: 0.2879
DEBUG - 2022-09-06 08:46:45 --> Total execution time: 0.1105
DEBUG - 2022-09-06 08:46:51 --> Total execution time: 0.1174
DEBUG - 2022-09-06 08:59:53 --> Total execution time: 0.1468
DEBUG - 2022-09-06 09:00:27 --> Total execution time: 0.3124
DEBUG - 2022-09-06 09:00:28 --> Total execution time: 0.0670
DEBUG - 2022-09-06 09:00:37 --> Total execution time: 0.1325
DEBUG - 2022-09-06 09:00:44 --> Total execution time: 0.1034
DEBUG - 2022-09-06 09:05:12 --> Total execution time: 0.1799
DEBUG - 2022-09-06 09:05:25 --> Total execution time: 0.0717
DEBUG - 2022-09-06 09:05:33 --> Total execution time: 0.1397
DEBUG - 2022-09-06 09:05:49 --> Total execution time: 0.1436
DEBUG - 2022-09-06 09:05:50 --> Total execution time: 0.1141
DEBUG - 2022-09-06 09:06:31 --> Total execution time: 0.1031
DEBUG - 2022-09-06 09:06:33 --> Total execution time: 0.1280
DEBUG - 2022-09-06 09:06:44 --> Total execution time: 0.1372
DEBUG - 2022-09-06 09:06:51 --> Total execution time: 0.0887
DEBUG - 2022-09-06 09:07:08 --> Total execution time: 0.0999
DEBUG - 2022-09-06 09:07:18 --> Total execution time: 0.1047
DEBUG - 2022-09-06 09:07:25 --> Total execution time: 0.1048
DEBUG - 2022-09-06 09:07:29 --> Total execution time: 0.1361
DEBUG - 2022-09-06 09:08:27 --> Total execution time: 0.0955
DEBUG - 2022-09-06 09:08:34 --> Total execution time: 0.1007
DEBUG - 2022-09-06 09:08:41 --> Total execution time: 0.1069
DEBUG - 2022-09-06 09:08:45 --> Total execution time: 0.1072
DEBUG - 2022-09-06 09:09:00 --> Total execution time: 0.1003
DEBUG - 2022-09-06 09:09:23 --> Total execution time: 0.0632
DEBUG - 2022-09-06 09:09:51 --> Total execution time: 0.0997
DEBUG - 2022-09-06 09:10:58 --> Total execution time: 0.0686
DEBUG - 2022-09-06 09:11:38 --> Total execution time: 0.1057
DEBUG - 2022-09-06 09:13:12 --> Total execution time: 0.1071
DEBUG - 2022-09-06 09:13:14 --> Total execution time: 0.1225
DEBUG - 2022-09-06 09:13:28 --> Total execution time: 0.0984
DEBUG - 2022-09-06 09:14:06 --> Total execution time: 0.0686
DEBUG - 2022-09-06 09:18:33 --> Total execution time: 0.1708
DEBUG - 2022-09-06 09:21:32 --> Total execution time: 0.3463
DEBUG - 2022-09-06 09:21:35 --> Total execution time: 0.1522
DEBUG - 2022-09-06 09:21:48 --> Total execution time: 0.1822
DEBUG - 2022-09-06 09:21:52 --> Total execution time: 0.1290
DEBUG - 2022-09-06 09:22:00 --> Total execution time: 0.1313
DEBUG - 2022-09-06 09:22:40 --> Total execution time: 0.1549
DEBUG - 2022-09-06 09:27:03 --> Total execution time: 0.3724
DEBUG - 2022-09-06 09:27:05 --> Total execution time: 0.1388
DEBUG - 2022-09-06 09:27:14 --> Total execution time: 0.0887
DEBUG - 2022-09-06 09:27:31 --> Total execution time: 0.1102
DEBUG - 2022-09-06 09:27:35 --> Total execution time: 0.0977
DEBUG - 2022-09-06 09:28:04 --> Total execution time: 0.1714
DEBUG - 2022-09-06 09:29:05 --> Total execution time: 0.0783
DEBUG - 2022-09-06 09:30:02 --> Total execution time: 0.1319
DEBUG - 2022-09-06 09:31:41 --> Total execution time: 0.0602
DEBUG - 2022-09-06 09:35:08 --> Total execution time: 0.1080
DEBUG - 2022-09-06 09:35:14 --> Total execution time: 0.0988
DEBUG - 2022-09-06 09:35:19 --> Total execution time: 0.1107
DEBUG - 2022-09-06 09:35:52 --> Total execution time: 0.1046
DEBUG - 2022-09-06 09:35:54 --> Total execution time: 0.0733
DEBUG - 2022-09-06 09:36:55 --> Total execution time: 0.2573
DEBUG - 2022-09-06 09:37:03 --> Total execution time: 0.1305
DEBUG - 2022-09-06 09:37:22 --> Total execution time: 0.1096
DEBUG - 2022-09-06 09:37:28 --> Total execution time: 0.1129
DEBUG - 2022-09-06 09:37:40 --> Total execution time: 0.1046
DEBUG - 2022-09-06 09:41:00 --> Total execution time: 0.1562
DEBUG - 2022-09-06 09:41:33 --> Total execution time: 0.0995
DEBUG - 2022-09-06 09:44:31 --> Total execution time: 0.3333
DEBUG - 2022-09-06 09:45:01 --> Total execution time: 0.1152
DEBUG - 2022-09-06 09:45:19 --> Total execution time: 0.1480
DEBUG - 2022-09-06 09:53:10 --> Total execution time: 0.0618
DEBUG - 2022-09-06 09:54:51 --> Total execution time: 0.0850
DEBUG - 2022-09-06 09:55:11 --> Total execution time: 0.2658
DEBUG - 2022-09-06 09:55:42 --> Total execution time: 0.1130
DEBUG - 2022-09-06 09:55:52 --> Total execution time: 0.0954
DEBUG - 2022-09-06 09:55:59 --> Total execution time: 0.1254
DEBUG - 2022-09-06 09:56:08 --> Total execution time: 0.1060
DEBUG - 2022-09-06 09:56:12 --> Total execution time: 0.1149
DEBUG - 2022-09-06 09:56:20 --> Total execution time: 0.0969
DEBUG - 2022-09-06 09:59:49 --> Total execution time: 0.1052
DEBUG - 2022-09-06 10:00:32 --> Total execution time: 0.3416
DEBUG - 2022-09-06 10:00:38 --> Total execution time: 0.1141
DEBUG - 2022-09-06 10:00:47 --> Total execution time: 0.1202
DEBUG - 2022-09-06 10:00:50 --> Total execution time: 0.1117
DEBUG - 2022-09-06 10:01:01 --> Total execution time: 0.1258
DEBUG - 2022-09-06 10:04:55 --> Total execution time: 0.1228
DEBUG - 2022-09-06 10:05:22 --> Total execution time: 0.1055
DEBUG - 2022-09-06 10:07:34 --> Total execution time: 0.2851
DEBUG - 2022-09-06 10:08:45 --> Total execution time: 0.1141
DEBUG - 2022-09-06 10:11:56 --> Total execution time: 0.1099
DEBUG - 2022-09-06 10:12:02 --> Total execution time: 0.1303
DEBUG - 2022-09-06 10:12:11 --> Total execution time: 0.1055
DEBUG - 2022-09-06 10:12:19 --> Total execution time: 0.1295
DEBUG - 2022-09-06 10:15:31 --> Total execution time: 0.0620
DEBUG - 2022-09-06 10:20:10 --> Total execution time: 0.1646
DEBUG - 2022-09-06 10:21:11 --> Total execution time: 0.1078
DEBUG - 2022-09-06 10:21:23 --> Total execution time: 0.1468
DEBUG - 2022-09-06 10:21:56 --> Total execution time: 0.0977
DEBUG - 2022-09-06 10:22:16 --> Total execution time: 0.1109
DEBUG - 2022-09-06 10:24:10 --> Total execution time: 0.1041
DEBUG - 2022-09-06 10:24:24 --> Total execution time: 0.1015
DEBUG - 2022-09-06 10:24:29 --> Total execution time: 0.1154
DEBUG - 2022-09-06 10:24:33 --> Total execution time: 0.1080
DEBUG - 2022-09-06 10:24:39 --> Total execution time: 0.1333
DEBUG - 2022-09-06 10:25:01 --> Total execution time: 0.1037
DEBUG - 2022-09-06 10:25:12 --> Total execution time: 0.1028
DEBUG - 2022-09-06 10:25:25 --> Total execution time: 0.0981
DEBUG - 2022-09-06 10:26:03 --> Total execution time: 0.2837
DEBUG - 2022-09-06 10:26:40 --> Total execution time: 0.1307
DEBUG - 2022-09-06 10:26:41 --> Total execution time: 0.0943
DEBUG - 2022-09-06 10:26:41 --> Total execution time: 0.1011
DEBUG - 2022-09-06 10:26:42 --> Total execution time: 0.0990
DEBUG - 2022-09-06 10:26:42 --> Total execution time: 0.1039
DEBUG - 2022-09-06 10:26:46 --> Total execution time: 0.1158
DEBUG - 2022-09-06 10:27:17 --> Total execution time: 0.0937
DEBUG - 2022-09-06 10:27:31 --> Total execution time: 0.1095
DEBUG - 2022-09-06 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:30:02 --> Total execution time: 0.1253
DEBUG - 2022-09-06 00:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:01:51 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:31:52 --> Total execution time: 0.0770
DEBUG - 2022-09-06 00:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 00:02:25 --> 404 Page Not Found: Lessons/paid-method-for-unlimited-leads
DEBUG - 2022-09-06 00:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:07:21 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:37:21 --> Total execution time: 0.3342
DEBUG - 2022-09-06 00:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:40:59 --> Total execution time: 0.0987
DEBUG - 2022-09-06 00:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:41:02 --> Total execution time: 0.0996
DEBUG - 2022-09-06 00:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:41:11 --> Total execution time: 0.1066
DEBUG - 2022-09-06 00:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:41:25 --> Total execution time: 0.1172
DEBUG - 2022-09-06 00:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:41:28 --> Total execution time: 0.0985
DEBUG - 2022-09-06 00:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:41:33 --> Total execution time: 0.1519
DEBUG - 2022-09-06 00:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:19:08 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:49:08 --> Total execution time: 0.1463
DEBUG - 2022-09-06 00:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:49:12 --> Total execution time: 0.0626
DEBUG - 2022-09-06 00:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:51:12 --> Total execution time: 0.1320
DEBUG - 2022-09-06 00:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:52:58 --> Total execution time: 0.1134
DEBUG - 2022-09-06 00:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:53:04 --> Total execution time: 0.0970
DEBUG - 2022-09-06 00:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:23:10 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:53:10 --> Total execution time: 0.0993
DEBUG - 2022-09-06 00:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:23:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 00:23:10 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-09-06 00:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:26:45 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:56:45 --> Total execution time: 0.0742
DEBUG - 2022-09-06 00:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:59:02 --> Total execution time: 0.1400
DEBUG - 2022-09-06 00:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:29:31 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:59:31 --> Total execution time: 0.0723
DEBUG - 2022-09-06 00:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:30:42 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:00:43 --> Total execution time: 0.2868
DEBUG - 2022-09-06 00:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:01:30 --> Total execution time: 0.1211
DEBUG - 2022-09-06 00:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:01:49 --> Total execution time: 0.1024
DEBUG - 2022-09-06 00:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:02:02 --> Total execution time: 0.2164
DEBUG - 2022-09-06 00:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:18 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:02:18 --> Total execution time: 0.1167
DEBUG - 2022-09-06 00:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:19 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:02:19 --> Total execution time: 0.0768
DEBUG - 2022-09-06 00:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:19 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:02:19 --> Total execution time: 0.0970
DEBUG - 2022-09-06 00:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:19 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:02:20 --> Total execution time: 0.0885
DEBUG - 2022-09-06 00:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:02:24 --> Total execution time: 0.0566
DEBUG - 2022-09-06 00:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:02:31 --> Total execution time: 0.1039
DEBUG - 2022-09-06 00:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:02:32 --> Total execution time: 0.0650
DEBUG - 2022-09-06 00:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:02:39 --> Total execution time: 0.1589
DEBUG - 2022-09-06 00:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:02:50 --> Total execution time: 0.0983
DEBUG - 2022-09-06 00:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:02:51 --> Total execution time: 0.1188
DEBUG - 2022-09-06 00:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:02:57 --> Total execution time: 0.1049
DEBUG - 2022-09-06 00:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:03:05 --> Total execution time: 0.1092
DEBUG - 2022-09-06 00:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:03:11 --> Total execution time: 0.0944
DEBUG - 2022-09-06 00:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:03:16 --> Total execution time: 0.1915
DEBUG - 2022-09-06 00:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:03:28 --> Total execution time: 0.1144
DEBUG - 2022-09-06 00:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:03:30 --> Total execution time: 0.1007
DEBUG - 2022-09-06 00:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:33:50 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:03:50 --> Total execution time: 0.0694
DEBUG - 2022-09-06 00:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:34:42 --> Total execution time: 0.0991
DEBUG - 2022-09-06 00:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:34:46 --> Total execution time: 0.1173
DEBUG - 2022-09-06 00:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:34:46 --> Total execution time: 0.1004
DEBUG - 2022-09-06 00:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:05:19 --> Total execution time: 0.0697
DEBUG - 2022-09-06 00:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:05:25 --> Total execution time: 0.1114
DEBUG - 2022-09-06 00:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:05:30 --> Total execution time: 0.1078
DEBUG - 2022-09-06 00:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:05:40 --> Total execution time: 0.1307
DEBUG - 2022-09-06 00:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:05:54 --> Total execution time: 2.3862
DEBUG - 2022-09-06 00:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:35:55 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:05:56 --> Total execution time: 0.0997
DEBUG - 2022-09-06 00:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:35:56 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:05:56 --> Total execution time: 0.0712
DEBUG - 2022-09-06 00:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 00:35:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 00:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:07:36 --> Total execution time: 0.0894
DEBUG - 2022-09-06 00:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:07:56 --> Total execution time: 0.1148
DEBUG - 2022-09-06 00:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:08:00 --> Total execution time: 0.1098
DEBUG - 2022-09-06 00:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:08:04 --> Total execution time: 0.1134
DEBUG - 2022-09-06 00:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:08:12 --> Total execution time: 0.0976
DEBUG - 2022-09-06 00:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:09:06 --> Total execution time: 0.3117
DEBUG - 2022-09-06 00:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:39:42 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:09:42 --> Total execution time: 0.0714
DEBUG - 2022-09-06 00:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:39:43 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:09:43 --> Total execution time: 0.0659
DEBUG - 2022-09-06 00:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:41:57 --> Total execution time: 0.1061
DEBUG - 2022-09-06 00:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:12:12 --> Total execution time: 0.1074
DEBUG - 2022-09-06 00:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:42:14 --> Total execution time: 0.1006
DEBUG - 2022-09-06 00:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:42:25 --> Total execution time: 0.0953
DEBUG - 2022-09-06 00:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:42:26 --> Total execution time: 0.0939
DEBUG - 2022-09-06 00:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:42:26 --> Total execution time: 0.0949
DEBUG - 2022-09-06 00:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:43:56 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:13:57 --> Total execution time: 0.2881
DEBUG - 2022-09-06 00:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:14:02 --> Total execution time: 0.1488
DEBUG - 2022-09-06 00:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:14:11 --> Total execution time: 0.1152
DEBUG - 2022-09-06 00:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:44:51 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:14:51 --> Total execution time: 0.1002
DEBUG - 2022-09-06 00:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:14:55 --> Total execution time: 0.0982
DEBUG - 2022-09-06 00:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:15:08 --> Total execution time: 0.1417
DEBUG - 2022-09-06 00:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:15:16 --> Total execution time: 0.1530
DEBUG - 2022-09-06 00:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:15:32 --> Total execution time: 0.1736
DEBUG - 2022-09-06 00:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:16:14 --> Total execution time: 0.1369
DEBUG - 2022-09-06 00:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:48:34 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:18:34 --> Total execution time: 0.1411
DEBUG - 2022-09-06 00:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:18:46 --> Total execution time: 0.0991
DEBUG - 2022-09-06 00:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:18:46 --> Total execution time: 0.0609
DEBUG - 2022-09-06 00:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:19:29 --> Total execution time: 0.1008
DEBUG - 2022-09-06 00:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:49:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:19:30 --> Total execution time: 0.0751
DEBUG - 2022-09-06 00:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:19:38 --> Total execution time: 0.0617
DEBUG - 2022-09-06 00:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:19:51 --> Total execution time: 0.1041
DEBUG - 2022-09-06 00:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:19:51 --> Total execution time: 0.1142
DEBUG - 2022-09-06 00:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:19:55 --> Total execution time: 0.1623
DEBUG - 2022-09-06 00:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:20:02 --> Total execution time: 0.2651
DEBUG - 2022-09-06 00:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:20:19 --> Total execution time: 0.1844
DEBUG - 2022-09-06 00:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:20:30 --> Total execution time: 0.0991
DEBUG - 2022-09-06 00:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:20:31 --> Total execution time: 0.1006
DEBUG - 2022-09-06 00:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:51:25 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:21:25 --> Total execution time: 0.1023
DEBUG - 2022-09-06 00:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:21:30 --> Total execution time: 0.1062
DEBUG - 2022-09-06 00:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:22:25 --> Total execution time: 0.0991
DEBUG - 2022-09-06 00:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:52:44 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:22:44 --> Total execution time: 0.0752
DEBUG - 2022-09-06 00:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:52:46 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:22:46 --> Total execution time: 0.1035
DEBUG - 2022-09-06 00:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:23:15 --> Total execution time: 0.1136
DEBUG - 2022-09-06 00:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:23:38 --> Total execution time: 0.1021
DEBUG - 2022-09-06 00:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:24:03 --> Total execution time: 0.3395
DEBUG - 2022-09-06 00:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:24:05 --> Total execution time: 0.1239
DEBUG - 2022-09-06 00:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:24:11 --> Total execution time: 0.1884
DEBUG - 2022-09-06 00:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:24:15 --> Total execution time: 0.1398
DEBUG - 2022-09-06 00:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:24:24 --> Total execution time: 0.1260
DEBUG - 2022-09-06 00:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:24:26 --> Total execution time: 0.1007
DEBUG - 2022-09-06 00:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:25:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-06 00:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:25:14 --> Total execution time: 0.1349
DEBUG - 2022-09-06 00:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:55:43 --> Total execution time: 0.1027
DEBUG - 2022-09-06 00:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:25:43 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-06 00:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:25:44 --> Total execution time: 0.1315
DEBUG - 2022-09-06 00:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:26:02 --> Total execution time: 0.1257
DEBUG - 2022-09-06 00:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:56:17 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:26:17 --> Total execution time: 0.0727
DEBUG - 2022-09-06 00:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:26:17 --> Total execution time: 0.3128
DEBUG - 2022-09-06 00:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:26:28 --> Total execution time: 0.1250
DEBUG - 2022-09-06 00:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:26:28 --> Total execution time: 0.0630
DEBUG - 2022-09-06 00:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:26:40 --> Total execution time: 0.1110
DEBUG - 2022-09-06 00:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:26:49 --> Total execution time: 0.1146
DEBUG - 2022-09-06 00:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:26:57 --> Total execution time: 0.1222
DEBUG - 2022-09-06 00:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:57:02 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:27:02 --> Total execution time: 0.0665
DEBUG - 2022-09-06 00:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:27:16 --> Total execution time: 0.1095
DEBUG - 2022-09-06 00:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:27:23 --> Total execution time: 0.0941
DEBUG - 2022-09-06 00:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:57:30 --> Total execution time: 0.0777
DEBUG - 2022-09-06 00:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:57:32 --> Total execution time: 0.0784
DEBUG - 2022-09-06 00:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:57:33 --> Total execution time: 0.0716
DEBUG - 2022-09-06 00:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:57:50 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:27:51 --> Total execution time: 0.0818
DEBUG - 2022-09-06 00:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:58:09 --> Total execution time: 0.1005
DEBUG - 2022-09-06 00:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:28:11 --> Total execution time: 0.0696
DEBUG - 2022-09-06 00:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:58:24 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:28:24 --> Total execution time: 0.0788
DEBUG - 2022-09-06 00:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:58:24 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:28:24 --> Total execution time: 0.1048
DEBUG - 2022-09-06 00:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:28:28 --> Total execution time: 0.0624
DEBUG - 2022-09-06 00:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:58:40 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:28:40 --> Total execution time: 0.0764
DEBUG - 2022-09-06 00:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:28:48 --> Total execution time: 0.0685
DEBUG - 2022-09-06 00:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:28:52 --> Total execution time: 0.0694
DEBUG - 2022-09-06 00:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:29:01 --> Total execution time: 0.0741
DEBUG - 2022-09-06 00:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:29:25 --> Total execution time: 0.0639
DEBUG - 2022-09-06 00:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:59:32 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:29:32 --> Total execution time: 0.0676
DEBUG - 2022-09-06 00:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:59:33 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:29:33 --> Total execution time: 0.0605
DEBUG - 2022-09-06 00:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:59:33 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:29:33 --> Total execution time: 0.0589
DEBUG - 2022-09-06 00:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:59:33 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:29:33 --> Total execution time: 0.0641
DEBUG - 2022-09-06 00:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:59:40 --> No URI present. Default controller set.
DEBUG - 2022-09-06 00:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:29:40 --> Total execution time: 0.0720
DEBUG - 2022-09-06 00:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:29:43 --> Total execution time: 0.0644
DEBUG - 2022-09-06 00:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:29:44 --> Total execution time: 0.0789
DEBUG - 2022-09-06 00:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 00:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 00:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 00:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:29:54 --> Total execution time: 0.1192
DEBUG - 2022-09-06 01:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:30:02 --> Total execution time: 0.1241
DEBUG - 2022-09-06 01:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:30:15 --> Total execution time: 0.1179
DEBUG - 2022-09-06 01:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:00:21 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:30:21 --> Total execution time: 0.2615
DEBUG - 2022-09-06 01:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:30:22 --> Total execution time: 0.1016
DEBUG - 2022-09-06 01:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:30:30 --> Total execution time: 0.1369
DEBUG - 2022-09-06 01:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:30:41 --> Total execution time: 0.1139
DEBUG - 2022-09-06 01:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:30:47 --> Total execution time: 0.1376
DEBUG - 2022-09-06 01:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:30:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-06 01:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:30:53 --> Total execution time: 0.1440
DEBUG - 2022-09-06 01:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:00:57 --> Total execution time: 0.1220
DEBUG - 2022-09-06 01:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:31:10 --> Total execution time: 0.1587
DEBUG - 2022-09-06 01:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:31:14 --> Total execution time: 0.1053
DEBUG - 2022-09-06 01:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:31:16 --> Total execution time: 0.1036
DEBUG - 2022-09-06 01:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:01:17 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:31:17 --> Total execution time: 0.0995
DEBUG - 2022-09-06 01:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:31:20 --> Total execution time: 0.2581
DEBUG - 2022-09-06 01:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:31:27 --> Total execution time: 0.1398
DEBUG - 2022-09-06 01:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:31:33 --> Total execution time: 0.1352
DEBUG - 2022-09-06 01:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:31:54 --> Total execution time: 0.1052
DEBUG - 2022-09-06 01:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:32:01 --> Total execution time: 0.1094
DEBUG - 2022-09-06 01:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:32:11 --> Total execution time: 0.1025
DEBUG - 2022-09-06 01:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:32:11 --> Total execution time: 0.1053
DEBUG - 2022-09-06 01:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:32:14 --> Total execution time: 0.1217
DEBUG - 2022-09-06 01:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:32:15 --> Total execution time: 0.0981
DEBUG - 2022-09-06 01:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:32:37 --> Total execution time: 0.2032
DEBUG - 2022-09-06 01:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:02:49 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:32:49 --> Total execution time: 0.1048
DEBUG - 2022-09-06 01:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:32:55 --> Total execution time: 0.0988
DEBUG - 2022-09-06 01:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:33:00 --> Total execution time: 0.2057
DEBUG - 2022-09-06 01:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:33:29 --> Total execution time: 0.1038
DEBUG - 2022-09-06 01:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:35:02 --> Total execution time: 0.1423
DEBUG - 2022-09-06 01:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:35:08 --> Total execution time: 0.1009
DEBUG - 2022-09-06 01:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:35:29 --> Total execution time: 0.1402
DEBUG - 2022-09-06 01:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:36:01 --> Total execution time: 0.1128
DEBUG - 2022-09-06 01:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:06:06 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:36:07 --> Total execution time: 0.3046
DEBUG - 2022-09-06 01:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:36:11 --> Total execution time: 0.1028
DEBUG - 2022-09-06 01:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:36:19 --> Total execution time: 0.1191
DEBUG - 2022-09-06 01:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:06:25 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:36:25 --> Total execution time: 0.0957
DEBUG - 2022-09-06 01:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:06:29 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:36:29 --> Total execution time: 0.1185
DEBUG - 2022-09-06 01:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:08:00 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:38:00 --> Total execution time: 0.0699
DEBUG - 2022-09-06 01:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:09:22 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:39:22 --> Total execution time: 0.0991
DEBUG - 2022-09-06 01:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:39:27 --> Total execution time: 0.1034
DEBUG - 2022-09-06 01:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:39:35 --> Total execution time: 0.1074
DEBUG - 2022-09-06 01:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:11:44 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:41:45 --> Total execution time: 0.2805
DEBUG - 2022-09-06 01:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:11:46 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:41:46 --> Total execution time: 0.2636
DEBUG - 2022-09-06 01:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:11:48 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:41:48 --> Total execution time: 0.0961
DEBUG - 2022-09-06 01:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:41:58 --> Total execution time: 0.1416
DEBUG - 2022-09-06 01:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:44:28 --> Total execution time: 0.4016
DEBUG - 2022-09-06 01:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:44:32 --> Total execution time: 0.1259
DEBUG - 2022-09-06 01:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:17:40 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:47:40 --> Total execution time: 0.2757
DEBUG - 2022-09-06 01:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:17:40 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:47:41 --> Total execution time: 0.2801
DEBUG - 2022-09-06 01:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:47:49 --> Total execution time: 0.1229
DEBUG - 2022-09-06 01:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:48:05 --> Total execution time: 0.1107
DEBUG - 2022-09-06 01:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:48:25 --> Total execution time: 0.1098
DEBUG - 2022-09-06 01:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:18:28 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:48:28 --> Total execution time: 0.1108
DEBUG - 2022-09-06 01:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:48:30 --> Total execution time: 0.1064
DEBUG - 2022-09-06 01:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:48:32 --> Total execution time: 0.1062
DEBUG - 2022-09-06 01:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:48:48 --> Total execution time: 0.1309
DEBUG - 2022-09-06 01:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:48:53 --> Total execution time: 0.1495
DEBUG - 2022-09-06 01:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:49:05 --> Total execution time: 0.1048
DEBUG - 2022-09-06 01:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:49:08 --> Total execution time: 0.1135
DEBUG - 2022-09-06 01:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:49:44 --> Total execution time: 0.1085
DEBUG - 2022-09-06 01:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:19:51 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:49:51 --> Total execution time: 0.1158
DEBUG - 2022-09-06 01:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:50:00 --> Total execution time: 0.1836
DEBUG - 2022-09-06 01:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:50:03 --> Total execution time: 0.2043
DEBUG - 2022-09-06 01:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:20:15 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:50:15 --> Total execution time: 0.0720
DEBUG - 2022-09-06 01:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:20:42 --> Total execution time: 0.0974
DEBUG - 2022-09-06 01:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:20:44 --> Total execution time: 0.1020
DEBUG - 2022-09-06 01:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:20:45 --> Total execution time: 0.1021
DEBUG - 2022-09-06 01:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:20:55 --> Total execution time: 0.1236
DEBUG - 2022-09-06 01:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:51:00 --> Total execution time: 0.1062
DEBUG - 2022-09-06 01:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:51:15 --> Total execution time: 0.1180
DEBUG - 2022-09-06 01:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:51:18 --> Total execution time: 0.1656
DEBUG - 2022-09-06 01:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:21:24 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:51:24 --> Total execution time: 0.1164
DEBUG - 2022-09-06 01:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:21:35 --> Total execution time: 0.0984
DEBUG - 2022-09-06 01:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:21:35 --> Total execution time: 0.0942
DEBUG - 2022-09-06 01:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:21:38 --> Total execution time: 0.1048
DEBUG - 2022-09-06 01:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:21:39 --> Total execution time: 0.1625
DEBUG - 2022-09-06 01:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:51:53 --> Total execution time: 0.1363
DEBUG - 2022-09-06 01:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:52:02 --> Total execution time: 2.6609
DEBUG - 2022-09-06 01:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:52:06 --> Total execution time: 0.1108
DEBUG - 2022-09-06 01:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 01:22:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 01:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:23:11 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:53:11 --> Total execution time: 0.2714
DEBUG - 2022-09-06 01:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:23:25 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:53:25 --> Total execution time: 0.0940
DEBUG - 2022-09-06 01:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:53:36 --> Total execution time: 0.2503
DEBUG - 2022-09-06 01:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:54:51 --> Total execution time: 0.0924
DEBUG - 2022-09-06 01:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:55:06 --> Total execution time: 0.1143
DEBUG - 2022-09-06 01:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:55:10 --> Total execution time: 0.1129
DEBUG - 2022-09-06 01:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:55:14 --> Total execution time: 0.1113
DEBUG - 2022-09-06 01:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:55:25 --> Total execution time: 0.1651
DEBUG - 2022-09-06 01:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:55:33 --> Total execution time: 0.1054
DEBUG - 2022-09-06 01:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:55:52 --> Total execution time: 0.1081
DEBUG - 2022-09-06 01:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:55:56 --> Total execution time: 0.1100
DEBUG - 2022-09-06 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:56:00 --> Total execution time: 0.1315
DEBUG - 2022-09-06 01:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:56:26 --> Total execution time: 0.1317
DEBUG - 2022-09-06 01:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:56:57 --> Total execution time: 0.1011
DEBUG - 2022-09-06 01:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:57:17 --> Total execution time: 0.1596
DEBUG - 2022-09-06 01:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:27:45 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:57:45 --> Total execution time: 0.1017
DEBUG - 2022-09-06 01:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:57:52 --> Total execution time: 0.1032
DEBUG - 2022-09-06 01:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:13 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:14 --> Total execution time: 0.2626
DEBUG - 2022-09-06 01:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:14 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:14 --> Total execution time: 0.1041
DEBUG - 2022-09-06 01:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:15 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:15 --> Total execution time: 0.1111
DEBUG - 2022-09-06 01:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:16 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:16 --> Total execution time: 0.0994
DEBUG - 2022-09-06 01:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:16 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:16 --> Total execution time: 0.1370
DEBUG - 2022-09-06 01:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:16 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:16 --> Total execution time: 0.1610
DEBUG - 2022-09-06 01:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:16 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:17 --> Total execution time: 0.1108
DEBUG - 2022-09-06 01:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:18 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:18 --> Total execution time: 0.1267
DEBUG - 2022-09-06 01:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:18 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:18 --> Total execution time: 0.1040
DEBUG - 2022-09-06 01:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:19 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:19 --> Total execution time: 0.1118
DEBUG - 2022-09-06 01:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:21 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:21 --> Total execution time: 0.1119
DEBUG - 2022-09-06 01:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:39 --> Total execution time: 0.1084
DEBUG - 2022-09-06 01:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:52 --> Total execution time: 0.0966
DEBUG - 2022-09-06 01:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:53 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:53 --> Total execution time: 0.0957
DEBUG - 2022-09-06 01:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:54 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:54 --> Total execution time: 0.0945
DEBUG - 2022-09-06 01:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:54 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:54 --> Total execution time: 0.0972
DEBUG - 2022-09-06 01:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:55 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:55 --> Total execution time: 0.1075
DEBUG - 2022-09-06 01:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:55 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:55 --> Total execution time: 0.0939
DEBUG - 2022-09-06 01:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:56 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:56 --> Total execution time: 0.1002
DEBUG - 2022-09-06 01:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:56 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:56 --> Total execution time: 0.0976
DEBUG - 2022-09-06 01:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:59:57 --> Total execution time: 0.0929
DEBUG - 2022-09-06 01:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:30:06 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:00:06 --> Total execution time: 0.0999
DEBUG - 2022-09-06 01:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:30:07 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:00:07 --> Total execution time: 0.0966
DEBUG - 2022-09-06 01:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:30:31 --> Total execution time: 0.1105
DEBUG - 2022-09-06 01:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:30:37 --> Total execution time: 0.1194
DEBUG - 2022-09-06 01:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:30:37 --> Total execution time: 0.1797
DEBUG - 2022-09-06 01:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:33:02 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:03:02 --> Total execution time: 0.1065
DEBUG - 2022-09-06 01:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:33:07 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:03:07 --> Total execution time: 0.2837
DEBUG - 2022-09-06 01:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:03:12 --> Total execution time: 0.1022
DEBUG - 2022-09-06 01:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:03:18 --> Total execution time: 0.0976
DEBUG - 2022-09-06 01:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:03:19 --> Total execution time: 0.0936
DEBUG - 2022-09-06 01:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:03:44 --> Total execution time: 0.1151
DEBUG - 2022-09-06 01:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:03:49 --> Total execution time: 0.2976
DEBUG - 2022-09-06 01:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:33:55 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:03:56 --> Total execution time: 0.1005
DEBUG - 2022-09-06 01:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:34:03 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:04:03 --> Total execution time: 0.1023
DEBUG - 2022-09-06 01:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:04:08 --> Total execution time: 0.0986
DEBUG - 2022-09-06 01:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:04:36 --> Total execution time: 0.2689
DEBUG - 2022-09-06 01:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:04:51 --> Total execution time: 0.1101
DEBUG - 2022-09-06 01:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:05:10 --> Total execution time: 0.1453
DEBUG - 2022-09-06 01:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:05:50 --> Total execution time: 0.1122
DEBUG - 2022-09-06 01:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:06:18 --> Total execution time: 0.1495
DEBUG - 2022-09-06 01:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:06:46 --> Total execution time: 0.0913
DEBUG - 2022-09-06 01:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:37:02 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:07:02 --> Total execution time: 0.0657
DEBUG - 2022-09-06 01:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:08:28 --> Total execution time: 0.0729
DEBUG - 2022-09-06 01:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:38:34 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:08:35 --> Total execution time: 0.2614
DEBUG - 2022-09-06 01:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:08:46 --> Total execution time: 0.0961
DEBUG - 2022-09-06 01:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:08:57 --> Total execution time: 0.1551
DEBUG - 2022-09-06 01:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:10 --> Total execution time: 0.1020
DEBUG - 2022-09-06 01:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:12 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:12 --> Total execution time: 0.1155
DEBUG - 2022-09-06 01:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:12 --> Total execution time: 0.1106
DEBUG - 2022-09-06 01:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:16 --> Total execution time: 0.1242
DEBUG - 2022-09-06 01:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:31 --> Total execution time: 0.1229
DEBUG - 2022-09-06 01:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:38 --> Total execution time: 0.1182
DEBUG - 2022-09-06 01:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:38 --> Total execution time: 0.1015
DEBUG - 2022-09-06 01:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:09:54 --> Total execution time: 0.1183
DEBUG - 2022-09-06 01:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:54 --> Total execution time: 0.1337
DEBUG - 2022-09-06 01:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:54 --> Total execution time: 0.1103
DEBUG - 2022-09-06 01:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:54 --> Total execution time: 0.1134
DEBUG - 2022-09-06 01:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:54 --> Total execution time: 0.1644
DEBUG - 2022-09-06 01:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:55 --> Total execution time: 0.1018
DEBUG - 2022-09-06 01:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:55 --> Total execution time: 0.1126
DEBUG - 2022-09-06 01:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:55 --> Total execution time: 0.1158
DEBUG - 2022-09-06 01:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:39:56 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:09:57 --> Total execution time: 0.2691
DEBUG - 2022-09-06 01:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:00 --> Total execution time: 0.1114
DEBUG - 2022-09-06 01:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:02 --> Total execution time: 0.1546
DEBUG - 2022-09-06 01:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:06 --> Total execution time: 0.1150
DEBUG - 2022-09-06 01:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:07 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:07 --> Total execution time: 0.1048
DEBUG - 2022-09-06 01:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:11 --> Total execution time: 0.1281
DEBUG - 2022-09-06 01:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:12 --> Total execution time: 0.1120
DEBUG - 2022-09-06 01:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:13 --> Total execution time: 0.0998
DEBUG - 2022-09-06 01:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:13 --> Total execution time: 0.1108
DEBUG - 2022-09-06 01:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:13 --> Total execution time: 0.1368
DEBUG - 2022-09-06 01:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:15 --> Total execution time: 0.1038
DEBUG - 2022-09-06 01:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:15 --> Total execution time: 0.1255
DEBUG - 2022-09-06 01:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:16 --> Total execution time: 0.1035
DEBUG - 2022-09-06 01:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:24 --> Total execution time: 0.1120
DEBUG - 2022-09-06 01:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:29 --> Total execution time: 0.1161
DEBUG - 2022-09-06 01:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:39 --> Total execution time: 0.1431
DEBUG - 2022-09-06 01:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:10:41 --> Total execution time: 0.2552
DEBUG - 2022-09-06 01:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:11:03 --> Total execution time: 0.1033
DEBUG - 2022-09-06 01:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:11:57 --> Total execution time: 0.1282
DEBUG - 2022-09-06 01:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:13:26 --> Total execution time: 0.0981
DEBUG - 2022-09-06 01:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:43:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 01:43:56 --> 404 Page Not Found: Teacher/subhash-chhabra
DEBUG - 2022-09-06 01:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:14:03 --> Total execution time: 0.1047
DEBUG - 2022-09-06 01:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:14:58 --> Total execution time: 0.1034
DEBUG - 2022-09-06 01:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:15:30 --> Total execution time: 0.2599
DEBUG - 2022-09-06 01:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:15:37 --> Total execution time: 0.0608
DEBUG - 2022-09-06 01:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:16:03 --> Total execution time: 0.1623
DEBUG - 2022-09-06 01:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:16:20 --> Total execution time: 0.1338
DEBUG - 2022-09-06 01:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:16:25 --> Total execution time: 0.2671
DEBUG - 2022-09-06 01:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:16:28 --> Total execution time: 0.1051
DEBUG - 2022-09-06 01:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:16:34 --> Total execution time: 0.1460
DEBUG - 2022-09-06 01:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:16:45 --> Total execution time: 0.1037
DEBUG - 2022-09-06 01:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:17:01 --> Total execution time: 0.1422
DEBUG - 2022-09-06 01:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:17:53 --> Total execution time: 0.1040
DEBUG - 2022-09-06 01:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:48:03 --> Total execution time: 0.1106
DEBUG - 2022-09-06 01:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:48:05 --> Total execution time: 0.1002
DEBUG - 2022-09-06 01:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:48:06 --> Total execution time: 0.0981
DEBUG - 2022-09-06 01:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:18:18 --> Total execution time: 0.1033
DEBUG - 2022-09-06 01:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:18:23 --> Total execution time: 0.0996
DEBUG - 2022-09-06 01:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:20:21 --> Total execution time: 0.1161
DEBUG - 2022-09-06 01:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:20:21 --> Total execution time: 0.1250
DEBUG - 2022-09-06 01:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:20:42 --> Total execution time: 0.0973
DEBUG - 2022-09-06 01:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:20:44 --> Total execution time: 0.1327
DEBUG - 2022-09-06 01:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:21:07 --> Total execution time: 0.1190
DEBUG - 2022-09-06 01:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:51:29 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:21:29 --> Total execution time: 0.0737
DEBUG - 2022-09-06 01:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:21:49 --> Total execution time: 0.0770
DEBUG - 2022-09-06 01:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:22:04 --> Total execution time: 0.1131
DEBUG - 2022-09-06 01:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:22:10 --> Total execution time: 0.1279
DEBUG - 2022-09-06 01:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:52:46 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:22:46 --> Total execution time: 0.0706
DEBUG - 2022-09-06 01:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:23:06 --> Total execution time: 0.0948
DEBUG - 2022-09-06 01:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:23:13 --> Total execution time: 0.1081
DEBUG - 2022-09-06 01:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:23:26 --> Total execution time: 0.1038
DEBUG - 2022-09-06 01:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:23:39 --> Total execution time: 0.1023
DEBUG - 2022-09-06 01:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:23:59 --> Total execution time: 0.1730
DEBUG - 2022-09-06 01:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:24:03 --> Total execution time: 0.1458
DEBUG - 2022-09-06 01:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:24:05 --> Total execution time: 0.1049
DEBUG - 2022-09-06 01:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:24:11 --> Total execution time: 0.1120
DEBUG - 2022-09-06 01:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:24:20 --> Total execution time: 0.1108
DEBUG - 2022-09-06 01:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:24:23 --> Total execution time: 0.1020
DEBUG - 2022-09-06 01:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:24:31 --> Total execution time: 0.1072
DEBUG - 2022-09-06 01:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:24:36 --> Total execution time: 0.0984
DEBUG - 2022-09-06 01:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:24:36 --> Total execution time: 0.1044
DEBUG - 2022-09-06 01:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:24:48 --> Total execution time: 0.1320
DEBUG - 2022-09-06 01:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:24:58 --> Total execution time: 0.1180
DEBUG - 2022-09-06 01:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:55:00 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:25:00 --> Total execution time: 0.1057
DEBUG - 2022-09-06 01:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:25:01 --> Total execution time: 0.1272
DEBUG - 2022-09-06 01:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:25:26 --> Total execution time: 0.3020
DEBUG - 2022-09-06 01:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:26:05 --> Total execution time: 0.0934
DEBUG - 2022-09-06 01:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:26:36 --> Total execution time: 0.1084
DEBUG - 2022-09-06 01:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:27:05 --> Total execution time: 0.0958
DEBUG - 2022-09-06 01:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:27:09 --> Total execution time: 0.1918
DEBUG - 2022-09-06 01:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:58:36 --> Total execution time: 0.0649
DEBUG - 2022-09-06 01:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:58:40 --> Total execution time: 0.1085
DEBUG - 2022-09-06 01:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:58:40 --> Total execution time: 0.0945
DEBUG - 2022-09-06 01:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:58:46 --> Total execution time: 0.1246
DEBUG - 2022-09-06 01:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:28:53 --> Total execution time: 0.1053
DEBUG - 2022-09-06 01:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:59:03 --> Total execution time: 0.1119
DEBUG - 2022-09-06 01:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:59:10 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:29:10 --> Total execution time: 0.1367
DEBUG - 2022-09-06 01:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:29:12 --> Total execution time: 0.0979
DEBUG - 2022-09-06 01:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:59:57 --> No URI present. Default controller set.
DEBUG - 2022-09-06 01:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:29:57 --> Total execution time: 0.1167
DEBUG - 2022-09-06 01:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 01:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 01:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 01:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:29:57 --> Total execution time: 0.1015
DEBUG - 2022-09-06 02:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:30:02 --> Total execution time: 0.1156
DEBUG - 2022-09-06 02:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:30:05 --> Total execution time: 0.1478
DEBUG - 2022-09-06 02:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:30:06 --> Total execution time: 0.1116
DEBUG - 2022-09-06 02:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:30:12 --> Total execution time: 0.0708
DEBUG - 2022-09-06 02:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:00:19 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:30:19 --> Total execution time: 0.0658
DEBUG - 2022-09-06 02:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:30:27 --> Total execution time: 0.1030
DEBUG - 2022-09-06 02:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:30:43 --> Total execution time: 0.1030
DEBUG - 2022-09-06 02:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:30:53 --> Total execution time: 0.1052
DEBUG - 2022-09-06 02:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:00:53 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:30:53 --> Total execution time: 0.0742
DEBUG - 2022-09-06 02:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:01:54 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:31:54 --> Total execution time: 0.0800
DEBUG - 2022-09-06 02:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:33:23 --> Total execution time: 0.2913
DEBUG - 2022-09-06 02:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:34:42 --> Total execution time: 0.0975
DEBUG - 2022-09-06 02:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:36:06 --> Total execution time: 0.1062
DEBUG - 2022-09-06 02:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:09:27 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:39:27 --> Total execution time: 0.3420
DEBUG - 2022-09-06 02:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:39:32 --> Total execution time: 0.1280
DEBUG - 2022-09-06 02:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:39:41 --> Total execution time: 0.1281
DEBUG - 2022-09-06 02:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:43:11 --> Total execution time: 0.1317
DEBUG - 2022-09-06 02:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:43:37 --> Total execution time: 0.1068
DEBUG - 2022-09-06 02:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:43:47 --> Total execution time: 0.1151
DEBUG - 2022-09-06 02:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:44:01 --> Total execution time: 0.1406
DEBUG - 2022-09-06 02:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:44:05 --> Total execution time: 0.1546
DEBUG - 2022-09-06 02:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:44:18 --> Total execution time: 0.1123
DEBUG - 2022-09-06 02:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:44:30 --> Total execution time: 0.1091
DEBUG - 2022-09-06 02:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:44:46 --> Total execution time: 0.1039
DEBUG - 2022-09-06 02:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:14:55 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:44:55 --> Total execution time: 0.0664
DEBUG - 2022-09-06 02:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:44:57 --> Total execution time: 0.1104
DEBUG - 2022-09-06 02:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:45:06 --> Total execution time: 0.1047
DEBUG - 2022-09-06 02:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:45:07 --> Total execution time: 0.1180
DEBUG - 2022-09-06 02:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:45:16 --> Total execution time: 0.1159
DEBUG - 2022-09-06 02:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:45:18 --> Total execution time: 0.1302
DEBUG - 2022-09-06 02:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:45:26 --> Total execution time: 0.2579
DEBUG - 2022-09-06 02:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:45:32 --> Total execution time: 0.1034
DEBUG - 2022-09-06 02:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:45:43 --> Total execution time: 0.1189
DEBUG - 2022-09-06 02:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:45:46 --> Total execution time: 0.1099
DEBUG - 2022-09-06 02:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:45:46 --> Total execution time: 0.1328
DEBUG - 2022-09-06 02:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:45:48 --> Total execution time: 0.1799
DEBUG - 2022-09-06 02:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:45:51 --> Total execution time: 0.1253
DEBUG - 2022-09-06 02:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:45:54 --> Total execution time: 0.1323
DEBUG - 2022-09-06 02:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:46:01 --> Total execution time: 0.1464
DEBUG - 2022-09-06 02:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:46:02 --> Total execution time: 0.1217
DEBUG - 2022-09-06 02:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:46:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-06 02:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:46:11 --> Total execution time: 0.1714
DEBUG - 2022-09-06 02:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:46:11 --> Total execution time: 0.1369
DEBUG - 2022-09-06 02:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:46:12 --> Total execution time: 0.1372
DEBUG - 2022-09-06 02:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:46:28 --> Total execution time: 0.1058
DEBUG - 2022-09-06 02:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:46:28 --> Total execution time: 0.1119
DEBUG - 2022-09-06 02:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:46:39 --> Total execution time: 0.1175
DEBUG - 2022-09-06 02:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:16:42 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:46:42 --> Total execution time: 0.1022
DEBUG - 2022-09-06 02:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:17:13 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:47:13 --> Total execution time: 0.1099
DEBUG - 2022-09-06 02:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:17:13 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:47:13 --> Total execution time: 0.1019
DEBUG - 2022-09-06 02:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:18:26 --> Total execution time: 0.0970
DEBUG - 2022-09-06 02:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:18:28 --> Total execution time: 0.1482
DEBUG - 2022-09-06 02:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:18:29 --> Total execution time: 0.1044
DEBUG - 2022-09-06 02:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:49:21 --> Total execution time: 2.4424
DEBUG - 2022-09-06 02:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:19:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 02:19:24 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 02:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:21:09 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:51:09 --> Total execution time: 0.0730
DEBUG - 2022-09-06 02:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:51:16 --> Total execution time: 0.0808
DEBUG - 2022-09-06 02:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:51:29 --> Total execution time: 0.0991
DEBUG - 2022-09-06 02:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:51:36 --> Total execution time: 0.1061
DEBUG - 2022-09-06 02:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:52:00 --> Total execution time: 0.2716
DEBUG - 2022-09-06 02:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:22:21 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:52:21 --> Total execution time: 0.0668
DEBUG - 2022-09-06 02:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:22:21 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:52:21 --> Total execution time: 0.1285
DEBUG - 2022-09-06 02:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:53:21 --> Total execution time: 0.1001
DEBUG - 2022-09-06 02:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:53:21 --> Total execution time: 0.1034
DEBUG - 2022-09-06 02:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:53:33 --> Total execution time: 0.0605
DEBUG - 2022-09-06 02:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:53:36 --> Total execution time: 0.1156
DEBUG - 2022-09-06 02:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:53:42 --> Total execution time: 0.1108
DEBUG - 2022-09-06 02:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:53:48 --> Total execution time: 0.1497
DEBUG - 2022-09-06 02:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:53:58 --> Total execution time: 0.1098
DEBUG - 2022-09-06 02:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:53:58 --> Total execution time: 0.0914
DEBUG - 2022-09-06 02:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:23:59 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:53:59 --> Total execution time: 0.2549
DEBUG - 2022-09-06 02:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:54:02 --> Total execution time: 0.0985
DEBUG - 2022-09-06 02:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:54:07 --> Total execution time: 0.0973
DEBUG - 2022-09-06 02:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:54:13 --> Total execution time: 0.0967
DEBUG - 2022-09-06 02:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:54:17 --> Total execution time: 0.0997
DEBUG - 2022-09-06 02:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:54:21 --> Total execution time: 0.1050
DEBUG - 2022-09-06 02:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:54:22 --> Total execution time: 0.0964
DEBUG - 2022-09-06 02:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:54:23 --> Total execution time: 0.1896
DEBUG - 2022-09-06 02:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:54:23 --> Total execution time: 0.1618
DEBUG - 2022-09-06 02:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:54:27 --> Total execution time: 0.1189
DEBUG - 2022-09-06 02:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:54:31 --> Total execution time: 0.1180
DEBUG - 2022-09-06 02:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:54:42 --> Total execution time: 0.1020
DEBUG - 2022-09-06 02:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:54:43 --> Total execution time: 0.1107
DEBUG - 2022-09-06 02:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:54:54 --> Total execution time: 0.1024
DEBUG - 2022-09-06 02:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:55:01 --> Total execution time: 0.1115
DEBUG - 2022-09-06 02:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:55:05 --> Total execution time: 0.1020
DEBUG - 2022-09-06 02:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:55:07 --> Total execution time: 0.1426
DEBUG - 2022-09-06 02:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:26:07 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:56:07 --> Total execution time: 0.0813
DEBUG - 2022-09-06 02:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:56:52 --> Total execution time: 0.1672
DEBUG - 2022-09-06 02:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:56:54 --> Total execution time: 0.1231
DEBUG - 2022-09-06 02:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:57:07 --> Total execution time: 0.1045
DEBUG - 2022-09-06 02:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:57:12 --> Total execution time: 0.2553
DEBUG - 2022-09-06 02:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:27:20 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:57:20 --> Total execution time: 0.0669
DEBUG - 2022-09-06 02:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:27:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:57:30 --> Total execution time: 0.0788
DEBUG - 2022-09-06 02:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:27:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:57:30 --> Total execution time: 0.0743
DEBUG - 2022-09-06 02:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:57:30 --> Total execution time: 0.1367
DEBUG - 2022-09-06 02:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:57:35 --> Total execution time: 0.1019
DEBUG - 2022-09-06 02:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:27:37 --> Total execution time: 0.0978
DEBUG - 2022-09-06 02:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:27:39 --> Total execution time: 0.1054
DEBUG - 2022-09-06 02:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:27:40 --> Total execution time: 0.1055
DEBUG - 2022-09-06 02:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:27:41 --> Total execution time: 0.1008
DEBUG - 2022-09-06 02:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:58:15 --> Total execution time: 1.9017
DEBUG - 2022-09-06 02:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:28:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 02:28:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 02:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:28:48 --> Total execution time: 0.2540
DEBUG - 2022-09-06 02:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:29:01 --> Total execution time: 0.2561
DEBUG - 2022-09-06 02:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:59:03 --> Total execution time: 0.1016
DEBUG - 2022-09-06 02:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:59:10 --> Total execution time: 0.1159
DEBUG - 2022-09-06 02:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:59:14 --> Total execution time: 0.1040
DEBUG - 2022-09-06 02:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:59:25 --> Total execution time: 0.1058
DEBUG - 2022-09-06 02:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:59:26 --> Total execution time: 0.1056
DEBUG - 2022-09-06 02:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:59:27 --> Total execution time: 0.1502
DEBUG - 2022-09-06 02:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:59:29 --> Total execution time: 0.1040
DEBUG - 2022-09-06 02:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:59:49 --> Total execution time: 0.2718
DEBUG - 2022-09-06 02:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:59:56 --> Total execution time: 0.2761
DEBUG - 2022-09-06 02:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:59:57 --> Total execution time: 0.1222
DEBUG - 2022-09-06 02:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:00:06 --> Total execution time: 0.1090
DEBUG - 2022-09-06 02:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:00:15 --> Total execution time: 0.1151
DEBUG - 2022-09-06 02:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:00:28 --> Total execution time: 0.1053
DEBUG - 2022-09-06 02:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:00:30 --> Total execution time: 0.1124
DEBUG - 2022-09-06 02:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:00:35 --> Total execution time: 0.1021
DEBUG - 2022-09-06 02:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:00:50 --> Total execution time: 0.1060
DEBUG - 2022-09-06 02:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:00:55 --> Total execution time: 0.1280
DEBUG - 2022-09-06 02:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:01:03 --> Total execution time: 0.1181
DEBUG - 2022-09-06 02:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:01:04 --> Total execution time: 0.2167
DEBUG - 2022-09-06 02:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:01:05 --> Total execution time: 0.1584
DEBUG - 2022-09-06 02:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:01:32 --> Total execution time: 0.1074
DEBUG - 2022-09-06 02:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:01:33 --> Total execution time: 0.1388
DEBUG - 2022-09-06 02:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:02:46 --> Total execution time: 0.1024
DEBUG - 2022-09-06 02:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:02:52 --> Total execution time: 0.1036
DEBUG - 2022-09-06 02:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:03:23 --> Total execution time: 0.1332
DEBUG - 2022-09-06 02:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:03:24 --> Total execution time: 0.1355
DEBUG - 2022-09-06 02:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:03:24 --> Total execution time: 0.1565
DEBUG - 2022-09-06 02:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:04:06 --> Total execution time: 0.2028
DEBUG - 2022-09-06 13:04:06 --> Total execution time: 0.3201
DEBUG - 2022-09-06 02:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:04:07 --> Total execution time: 0.1317
DEBUG - 2022-09-06 02:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:04:46 --> Total execution time: 0.2996
DEBUG - 2022-09-06 02:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:04:55 --> Total execution time: 0.1103
DEBUG - 2022-09-06 02:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:05:27 --> Total execution time: 0.1297
DEBUG - 2022-09-06 02:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:05:29 --> Total execution time: 0.1305
DEBUG - 2022-09-06 02:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:05:39 --> Total execution time: 0.0961
DEBUG - 2022-09-06 02:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:05:45 --> Total execution time: 0.1425
DEBUG - 2022-09-06 02:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:05:49 --> Total execution time: 0.1077
DEBUG - 2022-09-06 02:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:05:52 --> Total execution time: 0.1324
DEBUG - 2022-09-06 02:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:06:10 --> Total execution time: 0.1324
DEBUG - 2022-09-06 02:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:06:18 --> Total execution time: 0.1139
DEBUG - 2022-09-06 02:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:06:20 --> Total execution time: 0.2575
DEBUG - 2022-09-06 02:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:06:25 --> Total execution time: 0.1123
DEBUG - 2022-09-06 02:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:06:27 --> Total execution time: 0.1213
DEBUG - 2022-09-06 02:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:06:32 --> Total execution time: 0.1072
DEBUG - 2022-09-06 02:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:06:39 --> Total execution time: 0.1002
DEBUG - 2022-09-06 02:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:06:40 --> Total execution time: 0.1327
DEBUG - 2022-09-06 02:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:06:45 --> Total execution time: 0.0973
DEBUG - 2022-09-06 02:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:06:56 --> Total execution time: 0.1140
DEBUG - 2022-09-06 02:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:07:01 --> Total execution time: 0.1028
DEBUG - 2022-09-06 02:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:07:03 --> Total execution time: 0.1018
DEBUG - 2022-09-06 02:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:07:12 --> Total execution time: 0.0981
DEBUG - 2022-09-06 02:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:07:42 --> Total execution time: 0.1572
DEBUG - 2022-09-06 02:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:37:47 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:07:47 --> Total execution time: 0.1084
DEBUG - 2022-09-06 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:38:22 --> Total execution time: 0.0917
DEBUG - 2022-09-06 02:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:38:24 --> Total execution time: 0.1072
DEBUG - 2022-09-06 02:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:38:24 --> Total execution time: 0.0966
DEBUG - 2022-09-06 02:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:38:34 --> Total execution time: 0.1236
DEBUG - 2022-09-06 02:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:08:38 --> Total execution time: 0.1452
DEBUG - 2022-09-06 02:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:38:40 --> Total execution time: 0.1014
DEBUG - 2022-09-06 02:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:08:48 --> Total execution time: 0.1055
DEBUG - 2022-09-06 02:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:09:18 --> Total execution time: 0.1236
DEBUG - 2022-09-06 02:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:09:22 --> Total execution time: 0.1172
DEBUG - 2022-09-06 02:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:09:46 --> Total execution time: 0.1088
DEBUG - 2022-09-06 02:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:09:59 --> Total execution time: 0.0978
DEBUG - 2022-09-06 02:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:10:39 --> Total execution time: 0.0985
DEBUG - 2022-09-06 02:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:10:58 --> Total execution time: 0.0964
DEBUG - 2022-09-06 02:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:11:17 --> Total execution time: 0.1148
DEBUG - 2022-09-06 02:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:11:29 --> Total execution time: 0.1187
DEBUG - 2022-09-06 02:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:12:44 --> Total execution time: 0.1237
DEBUG - 2022-09-06 02:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:12:56 --> Total execution time: 0.1326
DEBUG - 2022-09-06 02:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:13:19 --> Total execution time: 0.1395
DEBUG - 2022-09-06 02:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:13:19 --> Total execution time: 0.1370
DEBUG - 2022-09-06 02:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:13:32 --> Total execution time: 0.1642
DEBUG - 2022-09-06 02:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:13:36 --> Total execution time: 0.0692
DEBUG - 2022-09-06 02:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:14:27 --> Total execution time: 0.1302
DEBUG - 2022-09-06 02:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:14:47 --> Total execution time: 0.1096
DEBUG - 2022-09-06 02:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:15:07 --> Total execution time: 0.1012
DEBUG - 2022-09-06 02:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:15:29 --> Total execution time: 0.1102
DEBUG - 2022-09-06 02:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:15:30 --> Total execution time: 0.1809
DEBUG - 2022-09-06 02:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:15:31 --> Total execution time: 0.0542
DEBUG - 2022-09-06 02:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:15:32 --> Total execution time: 0.1799
DEBUG - 2022-09-06 02:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:15:39 --> Total execution time: 0.1076
DEBUG - 2022-09-06 02:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:15:39 --> Total execution time: 0.1012
DEBUG - 2022-09-06 02:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:15:45 --> Total execution time: 0.1331
DEBUG - 2022-09-06 02:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:16:35 --> Total execution time: 0.1080
DEBUG - 2022-09-06 02:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:16:41 --> Total execution time: 0.1070
DEBUG - 2022-09-06 02:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:17:09 --> Total execution time: 0.2715
DEBUG - 2022-09-06 02:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:17:10 --> Total execution time: 0.2013
DEBUG - 2022-09-06 02:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:17:15 --> Total execution time: 0.1866
DEBUG - 2022-09-06 02:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:17:16 --> Total execution time: 0.0981
DEBUG - 2022-09-06 02:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:17:16 --> Total execution time: 0.0969
DEBUG - 2022-09-06 02:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:17:20 --> Total execution time: 0.1440
DEBUG - 2022-09-06 02:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:17:21 --> Total execution time: 0.1149
DEBUG - 2022-09-06 02:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:17:22 --> Total execution time: 0.1113
DEBUG - 2022-09-06 02:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:17:22 --> Total execution time: 0.1116
DEBUG - 2022-09-06 02:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:17:23 --> Total execution time: 0.1165
DEBUG - 2022-09-06 02:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:20:43 --> Total execution time: 0.3366
DEBUG - 2022-09-06 02:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:51:25 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:21:25 --> Total execution time: 0.2848
DEBUG - 2022-09-06 02:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:51:59 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:21:59 --> Total execution time: 0.3011
DEBUG - 2022-09-06 02:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 02:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:22:10 --> Total execution time: 0.1013
DEBUG - 2022-09-06 02:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:22:13 --> Total execution time: 0.1195
DEBUG - 2022-09-06 02:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:22:19 --> Total execution time: 0.1173
DEBUG - 2022-09-06 02:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:22:26 --> Total execution time: 0.1106
DEBUG - 2022-09-06 02:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:55:25 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:25:25 --> Total execution time: 0.0743
DEBUG - 2022-09-06 02:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:55:40 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:25:40 --> Total execution time: 0.0664
DEBUG - 2022-09-06 02:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:26:36 --> Total execution time: 0.1168
DEBUG - 2022-09-06 02:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:27:16 --> Total execution time: 0.0978
DEBUG - 2022-09-06 02:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:57:41 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:27:41 --> Total execution time: 0.0667
DEBUG - 2022-09-06 02:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 02:58:26 --> No URI present. Default controller set.
DEBUG - 2022-09-06 02:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 02:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:28:26 --> Total execution time: 0.0854
DEBUG - 2022-09-06 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:30:02 --> Total execution time: 0.0753
DEBUG - 2022-09-06 03:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:30:54 --> Total execution time: 0.2944
DEBUG - 2022-09-06 03:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:30:54 --> Total execution time: 0.1039
DEBUG - 2022-09-06 03:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:30:55 --> Total execution time: 0.1027
DEBUG - 2022-09-06 03:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:30:56 --> Total execution time: 0.1079
DEBUG - 2022-09-06 03:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:31:04 --> Total execution time: 0.1622
DEBUG - 2022-09-06 03:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:31:27 --> Total execution time: 0.1163
DEBUG - 2022-09-06 03:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:01:37 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:31:38 --> Total execution time: 0.0675
DEBUG - 2022-09-06 03:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:31:42 --> Total execution time: 0.0903
DEBUG - 2022-09-06 03:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:31:49 --> Total execution time: 0.1077
DEBUG - 2022-09-06 03:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:31:55 --> Total execution time: 0.0967
DEBUG - 2022-09-06 03:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:32:08 --> Total execution time: 0.1283
DEBUG - 2022-09-06 03:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:32:17 --> Total execution time: 0.1379
DEBUG - 2022-09-06 03:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:32:21 --> Total execution time: 0.1607
DEBUG - 2022-09-06 03:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:32:21 --> Total execution time: 0.1303
DEBUG - 2022-09-06 03:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:32:26 --> Total execution time: 0.1396
DEBUG - 2022-09-06 03:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:32:27 --> Total execution time: 0.1074
DEBUG - 2022-09-06 03:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:02:37 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:32:37 --> Total execution time: 0.1579
DEBUG - 2022-09-06 03:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:32:40 --> Total execution time: 0.1297
DEBUG - 2022-09-06 03:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:03:25 --> Total execution time: 0.0686
DEBUG - 2022-09-06 03:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:03:27 --> Total execution time: 0.1249
DEBUG - 2022-09-06 03:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:03:27 --> Total execution time: 0.1170
DEBUG - 2022-09-06 03:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:33:59 --> Total execution time: 0.1037
DEBUG - 2022-09-06 03:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:34:54 --> Total execution time: 0.1730
DEBUG - 2022-09-06 03:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:34:58 --> Total execution time: 0.1143
DEBUG - 2022-09-06 03:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:34:59 --> Total execution time: 0.1231
DEBUG - 2022-09-06 03:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:35:10 --> Total execution time: 0.1066
DEBUG - 2022-09-06 03:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:35:14 --> Total execution time: 0.1046
DEBUG - 2022-09-06 03:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:35:14 --> Total execution time: 0.1021
DEBUG - 2022-09-06 03:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:35:16 --> Total execution time: 0.1047
DEBUG - 2022-09-06 03:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:35:25 --> Total execution time: 0.1537
DEBUG - 2022-09-06 03:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:35:29 --> Total execution time: 0.1536
DEBUG - 2022-09-06 03:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:36:04 --> Total execution time: 0.1103
DEBUG - 2022-09-06 03:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:36:14 --> Total execution time: 0.1148
DEBUG - 2022-09-06 03:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:36:36 --> Total execution time: 0.1959
DEBUG - 2022-09-06 03:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:06:56 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:36:56 --> Total execution time: 0.2787
DEBUG - 2022-09-06 03:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:37:03 --> Total execution time: 0.1763
DEBUG - 2022-09-06 03:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:37:10 --> Total execution time: 0.1030
DEBUG - 2022-09-06 03:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:37:15 --> Total execution time: 0.1041
DEBUG - 2022-09-06 03:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:39:38 --> Total execution time: 0.4076
DEBUG - 2022-09-06 03:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:09:46 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:39:46 --> Total execution time: 0.1276
DEBUG - 2022-09-06 03:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:39:50 --> Total execution time: 0.1145
DEBUG - 2022-09-06 03:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:40:28 --> Total execution time: 0.1120
DEBUG - 2022-09-06 03:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:43:44 --> Total execution time: 0.1275
DEBUG - 2022-09-06 03:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:13:48 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:43:48 --> Total execution time: 0.0801
DEBUG - 2022-09-06 03:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:14:00 --> Total execution time: 0.1473
DEBUG - 2022-09-06 03:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:14:02 --> Total execution time: 0.1077
DEBUG - 2022-09-06 03:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:14:02 --> Total execution time: 0.2014
DEBUG - 2022-09-06 03:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:44:06 --> Total execution time: 0.1124
DEBUG - 2022-09-06 03:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:14:22 --> Total execution time: 0.1069
DEBUG - 2022-09-06 03:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:14:24 --> Total execution time: 0.1249
DEBUG - 2022-09-06 03:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:14:24 --> Total execution time: 0.1052
DEBUG - 2022-09-06 03:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:14:28 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:44:29 --> Total execution time: 0.0980
DEBUG - 2022-09-06 03:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:44:51 --> Total execution time: 0.1042
DEBUG - 2022-09-06 03:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:44:56 --> Total execution time: 0.1010
DEBUG - 2022-09-06 03:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:45:10 --> Total execution time: 0.1091
DEBUG - 2022-09-06 03:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:45:19 --> Total execution time: 0.1123
DEBUG - 2022-09-06 03:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:45:25 --> Total execution time: 0.1073
DEBUG - 2022-09-06 03:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:45:31 --> Total execution time: 0.1187
DEBUG - 2022-09-06 03:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:45:34 --> Total execution time: 0.1139
DEBUG - 2022-09-06 03:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:45:37 --> Total execution time: 0.1679
DEBUG - 2022-09-06 03:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:46:03 --> Total execution time: 0.1140
DEBUG - 2022-09-06 03:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:47:12 --> Total execution time: 0.1085
DEBUG - 2022-09-06 03:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:47:48 --> Total execution time: 0.2572
DEBUG - 2022-09-06 03:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:48:07 --> Total execution time: 0.0914
DEBUG - 2022-09-06 03:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:49:38 --> Total execution time: 0.1402
DEBUG - 2022-09-06 03:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:49:48 --> Total execution time: 0.1640
DEBUG - 2022-09-06 03:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:19:54 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:49:55 --> Total execution time: 0.2577
DEBUG - 2022-09-06 03:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:49:57 --> Total execution time: 0.0998
DEBUG - 2022-09-06 03:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:50:03 --> Total execution time: 0.1411
DEBUG - 2022-09-06 03:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:50:08 --> Total execution time: 0.2075
DEBUG - 2022-09-06 03:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:50:22 --> Total execution time: 0.2856
DEBUG - 2022-09-06 03:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:50:30 --> Total execution time: 0.1044
DEBUG - 2022-09-06 03:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:50:41 --> Total execution time: 0.1078
DEBUG - 2022-09-06 03:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:50:43 --> Total execution time: 0.1025
DEBUG - 2022-09-06 03:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:50:44 --> Total execution time: 0.1028
DEBUG - 2022-09-06 03:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:50:48 --> Total execution time: 0.1098
DEBUG - 2022-09-06 03:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:50:49 --> Total execution time: 0.1166
DEBUG - 2022-09-06 03:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:50:49 --> Total execution time: 0.1010
DEBUG - 2022-09-06 03:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:51:02 --> Total execution time: 0.1393
DEBUG - 2022-09-06 03:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:51:16 --> Total execution time: 0.1024
DEBUG - 2022-09-06 03:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:51:21 --> Total execution time: 0.1085
DEBUG - 2022-09-06 03:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:21:27 --> Total execution time: 0.1112
DEBUG - 2022-09-06 03:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:51:33 --> Total execution time: 0.1117
DEBUG - 2022-09-06 03:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:51:39 --> Total execution time: 0.1037
DEBUG - 2022-09-06 03:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:51:43 --> Total execution time: 0.1042
DEBUG - 2022-09-06 03:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:51:55 --> Total execution time: 0.1183
DEBUG - 2022-09-06 03:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:52:01 --> Total execution time: 0.1640
DEBUG - 2022-09-06 03:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:52:01 --> Total execution time: 0.2005
DEBUG - 2022-09-06 03:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:52:04 --> Total execution time: 0.1112
DEBUG - 2022-09-06 03:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:52:11 --> Total execution time: 0.1260
DEBUG - 2022-09-06 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:52:21 --> Total execution time: 0.1184
DEBUG - 2022-09-06 03:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:52:29 --> Total execution time: 0.1668
DEBUG - 2022-09-06 03:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:52:38 --> Total execution time: 0.1178
DEBUG - 2022-09-06 03:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:54:00 --> Total execution time: 0.2954
DEBUG - 2022-09-06 03:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:24:44 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:54:44 --> Total execution time: 0.0663
DEBUG - 2022-09-06 03:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:54:55 --> Total execution time: 0.0647
DEBUG - 2022-09-06 03:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:55:21 --> Total execution time: 0.1593
DEBUG - 2022-09-06 03:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:55:21 --> Total execution time: 0.1010
DEBUG - 2022-09-06 03:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:57:18 --> Total execution time: 0.1233
DEBUG - 2022-09-06 03:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:00:13 --> Total execution time: 0.1761
DEBUG - 2022-09-06 03:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:00:39 --> Total execution time: 0.1130
DEBUG - 2022-09-06 03:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:00:58 --> Total execution time: 0.1429
DEBUG - 2022-09-06 03:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:01:00 --> Total execution time: 0.0987
DEBUG - 2022-09-06 03:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:31:03 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:01:03 --> Total execution time: 0.0704
DEBUG - 2022-09-06 03:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:01:51 --> Total execution time: 0.0976
DEBUG - 2022-09-06 03:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:32:08 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:02:08 --> Total execution time: 0.1020
DEBUG - 2022-09-06 03:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:32:50 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:02:50 --> Total execution time: 0.1141
DEBUG - 2022-09-06 03:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:04:02 --> Total execution time: 0.2847
DEBUG - 2022-09-06 03:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:05:06 --> Total execution time: 0.0970
DEBUG - 2022-09-06 03:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:05:24 --> Total execution time: 0.0979
DEBUG - 2022-09-06 03:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:06:31 --> Total execution time: 0.1015
DEBUG - 2022-09-06 03:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:07:13 --> Total execution time: 0.1064
DEBUG - 2022-09-06 03:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:08:05 --> Total execution time: 0.1054
DEBUG - 2022-09-06 03:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:08:25 --> Total execution time: 0.1111
DEBUG - 2022-09-06 03:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:40:20 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:10:20 --> Total execution time: 0.0685
DEBUG - 2022-09-06 03:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:40:21 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:10:21 --> Total execution time: 0.0819
DEBUG - 2022-09-06 03:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:10:26 --> Total execution time: 0.0606
DEBUG - 2022-09-06 03:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:10:35 --> Total execution time: 0.1067
DEBUG - 2022-09-06 03:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:10:47 --> Total execution time: 0.1191
DEBUG - 2022-09-06 03:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:10:52 --> Total execution time: 0.1021
DEBUG - 2022-09-06 03:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:11:05 --> Total execution time: 0.0951
DEBUG - 2022-09-06 03:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:42:03 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:12:03 --> Total execution time: 0.0651
DEBUG - 2022-09-06 03:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:42:04 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:12:04 --> Total execution time: 0.0654
DEBUG - 2022-09-06 03:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:12:05 --> Total execution time: 0.0727
DEBUG - 2022-09-06 03:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:42:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 03:42:16 --> 404 Page Not Found: Event/importance-of-research-seminar
DEBUG - 2022-09-06 03:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:12:58 --> Total execution time: 0.1103
DEBUG - 2022-09-06 03:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:14:30 --> Total execution time: 0.1108
DEBUG - 2022-09-06 03:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:15:27 --> Total execution time: 0.3306
DEBUG - 2022-09-06 03:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:48:11 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:18:11 --> Total execution time: 0.1483
DEBUG - 2022-09-06 03:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:48:28 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:18:28 --> Total execution time: 0.0634
DEBUG - 2022-09-06 03:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:18:29 --> Total execution time: 0.0622
DEBUG - 2022-09-06 03:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:48:38 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:18:38 --> Total execution time: 0.0626
DEBUG - 2022-09-06 03:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:18:48 --> Total execution time: 0.2737
DEBUG - 2022-09-06 03:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:48:57 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:18:57 --> Total execution time: 0.1102
DEBUG - 2022-09-06 03:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:49:00 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:19:00 --> Total execution time: 0.1127
DEBUG - 2022-09-06 03:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:19:06 --> Total execution time: 0.0981
DEBUG - 2022-09-06 03:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:19:14 --> Total execution time: 0.0979
DEBUG - 2022-09-06 03:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:19:35 --> Total execution time: 0.1038
DEBUG - 2022-09-06 03:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:19:41 --> Total execution time: 0.1038
DEBUG - 2022-09-06 03:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:19:41 --> Total execution time: 0.0997
DEBUG - 2022-09-06 03:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:54:46 --> No URI present. Default controller set.
DEBUG - 2022-09-06 03:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:24:46 --> Total execution time: 0.1502
DEBUG - 2022-09-06 03:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:25:50 --> Total execution time: 0.0781
DEBUG - 2022-09-06 03:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 03:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:26:13 --> Total execution time: 0.1452
DEBUG - 2022-09-06 03:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:26:52 --> Total execution time: 0.3202
DEBUG - 2022-09-06 03:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:26:56 --> Total execution time: 0.1073
DEBUG - 2022-09-06 03:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:27:25 --> Total execution time: 0.1341
DEBUG - 2022-09-06 03:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:27:44 --> Total execution time: 0.1462
DEBUG - 2022-09-06 03:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:27:47 --> Total execution time: 0.1106
DEBUG - 2022-09-06 03:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:27:57 --> Total execution time: 0.1130
DEBUG - 2022-09-06 03:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:57:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 03:57:58 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-06 03:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:28:07 --> Total execution time: 0.1082
DEBUG - 2022-09-06 03:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:28:08 --> Total execution time: 0.0998
DEBUG - 2022-09-06 03:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:28:12 --> Total execution time: 0.1076
DEBUG - 2022-09-06 03:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:28:20 --> Total execution time: 0.1145
DEBUG - 2022-09-06 03:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:28:31 --> Total execution time: 0.1023
DEBUG - 2022-09-06 03:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:28:38 --> Total execution time: 0.1030
DEBUG - 2022-09-06 03:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:28:44 --> Total execution time: 0.1398
DEBUG - 2022-09-06 03:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:29:06 --> Total execution time: 0.2797
DEBUG - 2022-09-06 03:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:29:26 --> Total execution time: 0.1121
DEBUG - 2022-09-06 03:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:29:37 --> Total execution time: 0.1233
DEBUG - 2022-09-06 03:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 03:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 03:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:29:43 --> Total execution time: 0.1572
DEBUG - 2022-09-06 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:30:02 --> Total execution time: 0.1512
DEBUG - 2022-09-06 04:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:30:34 --> Total execution time: 0.1103
DEBUG - 2022-09-06 04:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:30:38 --> Total execution time: 0.1147
DEBUG - 2022-09-06 04:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:30:46 --> Total execution time: 0.1059
DEBUG - 2022-09-06 04:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:30:54 --> Total execution time: 0.2689
DEBUG - 2022-09-06 04:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:31:06 --> Total execution time: 0.1056
DEBUG - 2022-09-06 04:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:31:15 --> Total execution time: 0.1101
DEBUG - 2022-09-06 04:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:33:13 --> Total execution time: 0.2650
DEBUG - 2022-09-06 04:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:33:37 --> Total execution time: 0.1102
DEBUG - 2022-09-06 04:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:03:54 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:33:54 --> Total execution time: 0.0685
DEBUG - 2022-09-06 04:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:03:55 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:33:55 --> Total execution time: 0.0644
DEBUG - 2022-09-06 04:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:34:01 --> Total execution time: 0.0992
DEBUG - 2022-09-06 04:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:35:03 --> Total execution time: 0.2702
DEBUG - 2022-09-06 04:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:35:10 --> Total execution time: 0.1140
DEBUG - 2022-09-06 04:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:35:41 --> Total execution time: 0.1169
DEBUG - 2022-09-06 04:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:35:48 --> Total execution time: 0.1162
DEBUG - 2022-09-06 04:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:35:52 --> Total execution time: 0.1144
DEBUG - 2022-09-06 04:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:36:58 --> Total execution time: 0.1069
DEBUG - 2022-09-06 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:37:16 --> Total execution time: 0.0974
DEBUG - 2022-09-06 04:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:37:24 --> Total execution time: 0.0979
DEBUG - 2022-09-06 04:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:07:56 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:37:56 --> Total execution time: 0.1998
DEBUG - 2022-09-06 04:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:07:57 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:37:57 --> Total execution time: 0.1892
DEBUG - 2022-09-06 04:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:38:00 --> Total execution time: 0.0824
DEBUG - 2022-09-06 04:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:38:07 --> Total execution time: 0.1786
DEBUG - 2022-09-06 04:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:38:15 --> Total execution time: 0.1110
DEBUG - 2022-09-06 04:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:38:22 --> Total execution time: 0.1651
DEBUG - 2022-09-06 04:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:38:33 --> Total execution time: 0.1715
DEBUG - 2022-09-06 04:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:38:34 --> Total execution time: 0.1826
DEBUG - 2022-09-06 04:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:38:52 --> Total execution time: 0.1700
DEBUG - 2022-09-06 04:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:40:51 --> Total execution time: 0.2720
DEBUG - 2022-09-06 04:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:40:53 --> Total execution time: 0.1817
DEBUG - 2022-09-06 04:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:40:58 --> Total execution time: 0.1888
DEBUG - 2022-09-06 04:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:41:02 --> Total execution time: 0.1896
DEBUG - 2022-09-06 04:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:41:13 --> Total execution time: 0.1370
DEBUG - 2022-09-06 04:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:41:14 --> Total execution time: 0.2606
DEBUG - 2022-09-06 04:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:11:15 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:41:15 --> Total execution time: 0.0738
DEBUG - 2022-09-06 04:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:41:17 --> Total execution time: 0.2958
DEBUG - 2022-09-06 04:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:41:36 --> Total execution time: 0.1049
DEBUG - 2022-09-06 04:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:41:42 --> Total execution time: 0.1076
DEBUG - 2022-09-06 04:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:41:50 --> Total execution time: 0.1311
DEBUG - 2022-09-06 04:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:14:17 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:44:18 --> Total execution time: 0.3361
DEBUG - 2022-09-06 04:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:14:24 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:44:24 --> Total execution time: 0.1148
DEBUG - 2022-09-06 04:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:44:31 --> Total execution time: 0.1071
DEBUG - 2022-09-06 04:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:44:38 --> Total execution time: 0.1447
DEBUG - 2022-09-06 04:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:44:54 --> Total execution time: 0.1111
DEBUG - 2022-09-06 04:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:45:03 --> Total execution time: 0.1396
DEBUG - 2022-09-06 04:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:45:03 --> Total execution time: 0.2615
DEBUG - 2022-09-06 04:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:45:22 --> Total execution time: 0.1137
DEBUG - 2022-09-06 04:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:45:22 --> Total execution time: 0.1063
DEBUG - 2022-09-06 04:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:15:22 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:45:22 --> Total execution time: 0.1216
DEBUG - 2022-09-06 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:45:34 --> Total execution time: 0.1461
DEBUG - 2022-09-06 04:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:45:41 --> Total execution time: 0.1336
DEBUG - 2022-09-06 04:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:45:51 --> Total execution time: 0.1416
DEBUG - 2022-09-06 04:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:45:57 --> Total execution time: 0.1329
DEBUG - 2022-09-06 04:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:46:10 --> Total execution time: 0.1180
DEBUG - 2022-09-06 04:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:46:25 --> Total execution time: 0.1023
DEBUG - 2022-09-06 04:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:46:36 --> Total execution time: 0.1226
DEBUG - 2022-09-06 04:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:46:42 --> Total execution time: 0.1079
DEBUG - 2022-09-06 04:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:46:52 --> Total execution time: 0.1144
DEBUG - 2022-09-06 04:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:47:04 --> Total execution time: 0.1036
DEBUG - 2022-09-06 04:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:18:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:18:29 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-06 04:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:18:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:18:30 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-06 04:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:18:31 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-09-06 04:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:18:31 --> 404 Page Not Found: Apple-app-site-association/index
DEBUG - 2022-09-06 04:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:50:19 --> Total execution time: 0.1364
DEBUG - 2022-09-06 04:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:54:02 --> Total execution time: 0.3516
DEBUG - 2022-09-06 04:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:54:20 --> Total execution time: 0.1020
DEBUG - 2022-09-06 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:56:26 --> Total execution time: 0.1715
DEBUG - 2022-09-06 04:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:29:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:29:08 --> 404 Page Not Found: Wp-json/wp
DEBUG - 2022-09-06 04:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:29:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:29:35 --> 404 Page Not Found: Wp/wp-json
DEBUG - 2022-09-06 04:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:59:58 --> Total execution time: 0.3317
DEBUG - 2022-09-06 04:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:30:10 --> 404 Page Not Found: Wordpress/wp-json
DEBUG - 2022-09-06 04:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:00:11 --> Total execution time: 0.0978
DEBUG - 2022-09-06 04:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:30:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:30:36 --> 404 Page Not Found: Old/wp-json
DEBUG - 2022-09-06 04:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:31:05 --> 404 Page Not Found: New/wp-json
DEBUG - 2022-09-06 04:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:31:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:31:31 --> 404 Page Not Found: Blog/wp-json
DEBUG - 2022-09-06 04:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:02:42 --> Total execution time: 0.0733
DEBUG - 2022-09-06 04:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:04:52 --> Total execution time: 0.1150
DEBUG - 2022-09-06 04:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:04:54 --> Total execution time: 0.1181
DEBUG - 2022-09-06 04:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:04:55 --> Total execution time: 0.2577
DEBUG - 2022-09-06 04:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:05:00 --> Total execution time: 0.1144
DEBUG - 2022-09-06 04:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:05:03 --> Total execution time: 0.1458
DEBUG - 2022-09-06 04:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:05:06 --> Total execution time: 0.1070
DEBUG - 2022-09-06 04:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:05:08 --> Total execution time: 0.1069
DEBUG - 2022-09-06 04:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:05:14 --> Total execution time: 0.1398
DEBUG - 2022-09-06 04:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:05:22 --> Total execution time: 0.1421
DEBUG - 2022-09-06 04:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:05:42 --> Total execution time: 0.2911
DEBUG - 2022-09-06 04:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:05:56 --> Total execution time: 0.1179
DEBUG - 2022-09-06 04:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:06:15 --> Total execution time: 0.1213
DEBUG - 2022-09-06 04:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:12:04 --> Total execution time: 0.3767
DEBUG - 2022-09-06 04:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:12:15 --> Total execution time: 0.1360
DEBUG - 2022-09-06 04:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:12:26 --> Total execution time: 0.1047
DEBUG - 2022-09-06 04:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:12:37 --> Total execution time: 0.2050
DEBUG - 2022-09-06 04:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:12:37 --> Total execution time: 0.1907
DEBUG - 2022-09-06 04:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:12:46 --> Total execution time: 0.1134
DEBUG - 2022-09-06 04:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:12:58 --> Total execution time: 0.1421
DEBUG - 2022-09-06 04:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:13:13 --> Total execution time: 0.2852
DEBUG - 2022-09-06 04:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:13:20 --> Total execution time: 0.1786
DEBUG - 2022-09-06 04:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:13:44 --> Total execution time: 0.1139
DEBUG - 2022-09-06 04:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:13:47 --> Total execution time: 0.1092
DEBUG - 2022-09-06 04:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:13:49 --> Total execution time: 0.1476
DEBUG - 2022-09-06 04:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:14:13 --> Total execution time: 0.1341
DEBUG - 2022-09-06 04:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:14:27 --> Total execution time: 0.1034
DEBUG - 2022-09-06 04:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:44:53 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:14:53 --> Total execution time: 0.0701
DEBUG - 2022-09-06 04:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:14:55 --> Total execution time: 0.1001
DEBUG - 2022-09-06 04:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:14:56 --> Total execution time: 0.1036
DEBUG - 2022-09-06 04:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:00 --> Total execution time: 0.0951
DEBUG - 2022-09-06 04:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:04 --> Total execution time: 0.1216
DEBUG - 2022-09-06 04:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:45:10 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:10 --> Total execution time: 0.1155
DEBUG - 2022-09-06 04:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:45:17 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:17 --> Total execution time: 0.2664
DEBUG - 2022-09-06 04:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:17 --> Total execution time: 0.2770
DEBUG - 2022-09-06 04:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:46:18 --> 404 Page Not Found: Wp-json/wp
DEBUG - 2022-09-06 04:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:16:52 --> Total execution time: 0.1110
DEBUG - 2022-09-06 04:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:46:59 --> 404 Page Not Found: Wp/wp-json
DEBUG - 2022-09-06 04:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:17:12 --> Total execution time: 0.1032
DEBUG - 2022-09-06 04:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:47:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:47:43 --> 404 Page Not Found: Wordpress/wp-json
DEBUG - 2022-09-06 04:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:48:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:48:31 --> 404 Page Not Found: Old/wp-json
DEBUG - 2022-09-06 04:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:19:08 --> Total execution time: 0.1076
DEBUG - 2022-09-06 04:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:49:15 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:19:15 --> Total execution time: 0.2758
DEBUG - 2022-09-06 04:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:19:20 --> Total execution time: 0.1320
DEBUG - 2022-09-06 04:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:50:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:50:03 --> 404 Page Not Found: New/wp-json
DEBUG - 2022-09-06 04:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:50:10 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:20:10 --> Total execution time: 0.1023
DEBUG - 2022-09-06 04:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:20:15 --> Total execution time: 0.1085
DEBUG - 2022-09-06 04:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:20:24 --> Total execution time: 0.1092
DEBUG - 2022-09-06 04:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:50:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:50:54 --> 404 Page Not Found: Blog/wp-json
DEBUG - 2022-09-06 04:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:21:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-06 04:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:21:27 --> Total execution time: 0.1221
DEBUG - 2022-09-06 04:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:22:28 --> Total execution time: 0.0981
DEBUG - 2022-09-06 04:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:25:02 --> Total execution time: 0.1239
DEBUG - 2022-09-06 04:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:25:14 --> Total execution time: 0.1114
DEBUG - 2022-09-06 04:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:25:21 --> Total execution time: 0.2316
DEBUG - 2022-09-06 04:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:25:42 --> Total execution time: 0.1049
DEBUG - 2022-09-06 04:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:25:43 --> Total execution time: 0.1013
DEBUG - 2022-09-06 04:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:25:44 --> Total execution time: 0.1076
DEBUG - 2022-09-06 04:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:25:45 --> Total execution time: 0.1284
DEBUG - 2022-09-06 04:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:25:59 --> Total execution time: 0.1154
DEBUG - 2022-09-06 04:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:26:11 --> Total execution time: 0.1215
DEBUG - 2022-09-06 04:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:26:14 --> Total execution time: 0.1744
DEBUG - 2022-09-06 04:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:56:19 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:26:19 --> Total execution time: 0.0868
DEBUG - 2022-09-06 04:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:56:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 04:56:37 --> 404 Page Not Found: Refund/index
DEBUG - 2022-09-06 04:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:56:53 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:26:53 --> Total execution time: 0.0649
DEBUG - 2022-09-06 04:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:27:12 --> Total execution time: 0.0606
DEBUG - 2022-09-06 04:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:27:28 --> Total execution time: 0.1041
DEBUG - 2022-09-06 04:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 04:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:27:40 --> Total execution time: 0.1076
DEBUG - 2022-09-06 04:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:28:27 --> Total execution time: 0.0989
DEBUG - 2022-09-06 04:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:28:34 --> Total execution time: 0.2605
DEBUG - 2022-09-06 04:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:58:34 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:28:35 --> Total execution time: 0.0984
DEBUG - 2022-09-06 04:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:28:37 --> Total execution time: 0.1409
DEBUG - 2022-09-06 04:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:28:44 --> Total execution time: 0.1044
DEBUG - 2022-09-06 04:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:29:18 --> Total execution time: 0.1501
DEBUG - 2022-09-06 04:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:59:46 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:29:46 --> Total execution time: 0.0666
DEBUG - 2022-09-06 04:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 04:59:46 --> No URI present. Default controller set.
DEBUG - 2022-09-06 04:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 04:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:29:46 --> Total execution time: 0.0643
DEBUG - 2022-09-06 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:30:02 --> Total execution time: 0.1426
DEBUG - 2022-09-06 05:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:30:16 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-06 05:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:30:17 --> Total execution time: 0.1358
DEBUG - 2022-09-06 05:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:00:20 --> Total execution time: 0.0803
DEBUG - 2022-09-06 05:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:00:22 --> Total execution time: 0.1032
DEBUG - 2022-09-06 05:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:00:22 --> Total execution time: 0.0974
DEBUG - 2022-09-06 05:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:30:25 --> Total execution time: 0.0727
DEBUG - 2022-09-06 05:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:30:27 --> Total execution time: 0.1501
DEBUG - 2022-09-06 05:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:29 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:30:29 --> Total execution time: 0.1058
DEBUG - 2022-09-06 05:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:30:32 --> Total execution time: 0.1262
DEBUG - 2022-09-06 05:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:30:35 --> Total execution time: 0.1282
DEBUG - 2022-09-06 05:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:30:35 --> Total execution time: 0.1449
DEBUG - 2022-09-06 05:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:30:42 --> Total execution time: 0.1249
DEBUG - 2022-09-06 05:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:30:43 --> Total execution time: 0.0979
DEBUG - 2022-09-06 05:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:30:51 --> Total execution time: 0.1628
DEBUG - 2022-09-06 05:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:01:43 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:31:43 --> Total execution time: 0.0650
DEBUG - 2022-09-06 05:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:01:46 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:31:46 --> Total execution time: 0.0938
DEBUG - 2022-09-06 05:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:31:57 --> Total execution time: 2.3033
DEBUG - 2022-09-06 05:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:02:32 --> Total execution time: 0.1130
DEBUG - 2022-09-06 05:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:32:55 --> Total execution time: 0.3141
DEBUG - 2022-09-06 05:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:32:56 --> Total execution time: 0.1291
DEBUG - 2022-09-06 05:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:33:05 --> Total execution time: 0.1683
DEBUG - 2022-09-06 05:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:33:15 --> Total execution time: 0.1786
DEBUG - 2022-09-06 05:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:05:52 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:35:52 --> Total execution time: 0.1407
DEBUG - 2022-09-06 05:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:36:12 --> Total execution time: 0.1095
DEBUG - 2022-09-06 05:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:12:42 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:42:42 --> Total execution time: 0.3622
DEBUG - 2022-09-06 05:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:42:42 --> Total execution time: 0.1311
DEBUG - 2022-09-06 05:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:43:24 --> Total execution time: 0.1091
DEBUG - 2022-09-06 05:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:43:31 --> Total execution time: 0.1568
DEBUG - 2022-09-06 05:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:43:42 --> Total execution time: 0.1309
DEBUG - 2022-09-06 05:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:14:16 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:44:16 --> Total execution time: 0.1081
DEBUG - 2022-09-06 05:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:44:54 --> Total execution time: 1.9770
DEBUG - 2022-09-06 05:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:14:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 05:14:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 05:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:45:17 --> Total execution time: 0.0959
DEBUG - 2022-09-06 05:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:15:27 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:45:28 --> Total execution time: 0.1055
DEBUG - 2022-09-06 05:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:15:46 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:45:46 --> Total execution time: 0.0987
DEBUG - 2022-09-06 05:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:15:48 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:45:48 --> Total execution time: 0.0665
DEBUG - 2022-09-06 05:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:15:49 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:45:49 --> Total execution time: 0.0783
DEBUG - 2022-09-06 05:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:45:53 --> Total execution time: 0.0689
DEBUG - 2022-09-06 05:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:45:59 --> Total execution time: 0.1021
DEBUG - 2022-09-06 05:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:46:09 --> Total execution time: 0.1648
DEBUG - 2022-09-06 05:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:16:33 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:46:33 --> Total execution time: 0.1054
DEBUG - 2022-09-06 05:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:46:38 --> Total execution time: 0.0915
DEBUG - 2022-09-06 05:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:16:42 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:46:42 --> Total execution time: 0.0939
DEBUG - 2022-09-06 05:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:46:44 --> Total execution time: 0.1203
DEBUG - 2022-09-06 05:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:18:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:48:30 --> Total execution time: 0.0719
DEBUG - 2022-09-06 05:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:48:40 --> Total execution time: 0.1041
DEBUG - 2022-09-06 05:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:18:44 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:48:45 --> Total execution time: 0.0939
DEBUG - 2022-09-06 05:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:19:11 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:49:11 --> Total execution time: 0.1003
DEBUG - 2022-09-06 05:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:20:41 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:50:41 --> Total execution time: 0.0640
DEBUG - 2022-09-06 05:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:52:55 --> Total execution time: 0.1091
DEBUG - 2022-09-06 05:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:53:02 --> Total execution time: 0.1072
DEBUG - 2022-09-06 05:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:53:09 --> Total execution time: 0.1206
DEBUG - 2022-09-06 05:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:23:11 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:53:11 --> Total execution time: 0.0693
DEBUG - 2022-09-06 05:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:23:12 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:53:12 --> Total execution time: 0.0606
DEBUG - 2022-09-06 05:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:53:22 --> Total execution time: 0.1050
DEBUG - 2022-09-06 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:23:24 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:53:24 --> Total execution time: 0.1031
DEBUG - 2022-09-06 05:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:53:31 --> Total execution time: 0.1320
DEBUG - 2022-09-06 05:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:53:58 --> Total execution time: 0.1350
DEBUG - 2022-09-06 05:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:24:34 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:54:34 --> Total execution time: 0.2722
DEBUG - 2022-09-06 05:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:54:38 --> Total execution time: 0.0972
DEBUG - 2022-09-06 05:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:24:43 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:54:43 --> Total execution time: 0.1107
DEBUG - 2022-09-06 05:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:54:47 --> Total execution time: 0.1019
DEBUG - 2022-09-06 05:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:24:51 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:54:51 --> Total execution time: 0.0997
DEBUG - 2022-09-06 05:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:55:14 --> Total execution time: 0.2985
DEBUG - 2022-09-06 05:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:55:22 --> Total execution time: 0.1087
DEBUG - 2022-09-06 05:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:55:35 --> Total execution time: 0.1116
DEBUG - 2022-09-06 05:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:55:39 --> Total execution time: 0.1015
DEBUG - 2022-09-06 05:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:25:50 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:55:50 --> Total execution time: 0.1182
DEBUG - 2022-09-06 05:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:26:13 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:56:13 --> Total execution time: 0.1067
DEBUG - 2022-09-06 05:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:56:43 --> Total execution time: 0.0961
DEBUG - 2022-09-06 05:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:56:44 --> Total execution time: 0.0627
DEBUG - 2022-09-06 05:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:56:50 --> Total execution time: 0.1034
DEBUG - 2022-09-06 05:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:56:57 --> Total execution time: 0.4081
DEBUG - 2022-09-06 05:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:57:17 --> Total execution time: 0.1166
DEBUG - 2022-09-06 05:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:57:20 --> Total execution time: 0.1153
DEBUG - 2022-09-06 05:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:57:24 --> Total execution time: 0.1062
DEBUG - 2022-09-06 05:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:57:29 --> Total execution time: 0.1036
DEBUG - 2022-09-06 05:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:57:37 --> Total execution time: 0.1153
DEBUG - 2022-09-06 05:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:58:17 --> Total execution time: 0.0997
DEBUG - 2022-09-06 05:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:03:24 --> Total execution time: 0.3801
DEBUG - 2022-09-06 05:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:33:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 05:33:46 --> 404 Page Not Found: Lessons/how-to-find-right-wholeseller
DEBUG - 2022-09-06 05:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:08:10 --> Total execution time: 0.2096
DEBUG - 2022-09-06 05:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:08:45 --> Total execution time: 0.1013
DEBUG - 2022-09-06 05:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:39:39 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:09:40 --> Total execution time: 0.1597
DEBUG - 2022-09-06 05:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:09:45 --> Total execution time: 0.1106
DEBUG - 2022-09-06 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:13 --> Total execution time: 0.3391
DEBUG - 2022-09-06 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:14 --> Total execution time: 0.1189
DEBUG - 2022-09-06 05:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:20 --> Total execution time: 0.1067
DEBUG - 2022-09-06 05:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:26 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:26 --> Total execution time: 0.1006
DEBUG - 2022-09-06 05:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:27 --> Total execution time: 0.1795
DEBUG - 2022-09-06 05:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:28 --> Total execution time: 0.1206
DEBUG - 2022-09-06 05:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:29 --> Total execution time: 0.1545
DEBUG - 2022-09-06 05:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:30 --> Total execution time: 0.1271
DEBUG - 2022-09-06 05:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:30 --> Total execution time: 0.0999
DEBUG - 2022-09-06 05:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:30 --> Total execution time: 0.1278
DEBUG - 2022-09-06 05:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:31 --> Total execution time: 0.1428
DEBUG - 2022-09-06 05:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:32 --> Total execution time: 0.1393
DEBUG - 2022-09-06 05:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:38 --> Total execution time: 0.0969
DEBUG - 2022-09-06 05:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:42 --> Total execution time: 0.1372
DEBUG - 2022-09-06 05:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:40:44 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:10:44 --> Total execution time: 0.1101
DEBUG - 2022-09-06 05:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:43:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 05:43:11 --> 404 Page Not Found: Profile/index
DEBUG - 2022-09-06 05:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:46:32 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:16:33 --> Total execution time: 0.3430
DEBUG - 2022-09-06 05:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:16:38 --> Total execution time: 0.1183
DEBUG - 2022-09-06 05:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:46:44 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:16:44 --> Total execution time: 0.1008
DEBUG - 2022-09-06 05:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:16:48 --> Total execution time: 0.1107
DEBUG - 2022-09-06 05:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:46:52 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:16:52 --> Total execution time: 0.1035
DEBUG - 2022-09-06 05:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:47:35 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:17:35 --> Total execution time: 0.0666
DEBUG - 2022-09-06 05:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:21:17 --> Total execution time: 0.3618
DEBUG - 2022-09-06 05:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:21:26 --> Total execution time: 0.1012
DEBUG - 2022-09-06 05:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:21:27 --> Total execution time: 0.0972
DEBUG - 2022-09-06 05:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:21:34 --> Total execution time: 0.1087
DEBUG - 2022-09-06 05:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:21:45 --> Total execution time: 0.1269
DEBUG - 2022-09-06 05:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:21:48 --> Total execution time: 0.1075
DEBUG - 2022-09-06 05:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:22:37 --> Total execution time: 0.0973
DEBUG - 2022-09-06 05:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:22:40 --> Total execution time: 0.1129
DEBUG - 2022-09-06 05:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:22:59 --> Total execution time: 0.1356
DEBUG - 2022-09-06 05:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:23:25 --> Total execution time: 0.1031
DEBUG - 2022-09-06 05:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:53:36 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:23:36 --> Total execution time: 0.0690
DEBUG - 2022-09-06 05:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:54:20 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:24:20 --> Total execution time: 0.1069
DEBUG - 2022-09-06 05:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:24:27 --> Total execution time: 0.1050
DEBUG - 2022-09-06 05:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:24:28 --> Total execution time: 0.1006
DEBUG - 2022-09-06 05:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:24:37 --> Total execution time: 0.1035
DEBUG - 2022-09-06 05:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:54:44 --> Total execution time: 0.1082
DEBUG - 2022-09-06 05:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:24:45 --> Total execution time: 0.1330
DEBUG - 2022-09-06 05:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:54:46 --> Total execution time: 0.1047
DEBUG - 2022-09-06 05:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 05:54:46 --> Total execution time: 0.0975
DEBUG - 2022-09-06 05:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:25:04 --> Total execution time: 0.1164
DEBUG - 2022-09-06 05:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:25:12 --> Total execution time: 0.1710
DEBUG - 2022-09-06 05:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:25:22 --> Total execution time: 0.1342
DEBUG - 2022-09-06 05:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:55:23 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:25:24 --> Total execution time: 0.3192
DEBUG - 2022-09-06 05:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:25:43 --> Total execution time: 0.1242
DEBUG - 2022-09-06 05:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 05:55:44 --> No URI present. Default controller set.
DEBUG - 2022-09-06 05:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 05:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:25:44 --> Total execution time: 0.1239
DEBUG - 2022-09-06 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:30:02 --> Total execution time: 0.3193
DEBUG - 2022-09-06 06:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:01:35 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:31:35 --> Total execution time: 0.0867
DEBUG - 2022-09-06 06:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:03:22 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:33:22 --> Total execution time: 0.2721
DEBUG - 2022-09-06 06:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:34:20 --> Total execution time: 0.3819
DEBUG - 2022-09-06 06:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:05:41 --> Total execution time: 0.0800
DEBUG - 2022-09-06 06:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:09:08 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:39:08 --> Total execution time: 0.1401
DEBUG - 2022-09-06 06:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:39:19 --> Total execution time: 0.0699
DEBUG - 2022-09-06 06:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:39:35 --> Total execution time: 0.1087
DEBUG - 2022-09-06 06:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:40:08 --> Total execution time: 0.1295
DEBUG - 2022-09-06 06:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:12:05 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:42:05 --> Total execution time: 0.0716
DEBUG - 2022-09-06 06:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:54:06 --> Total execution time: 0.4006
DEBUG - 2022-09-06 06:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:28:12 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:58:12 --> Total execution time: 0.1405
DEBUG - 2022-09-06 06:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:30:58 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:00:58 --> Total execution time: 0.0942
DEBUG - 2022-09-06 06:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:04:51 --> Total execution time: 0.1019
DEBUG - 2022-09-06 06:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:35:44 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:05:44 --> Total execution time: 0.0805
DEBUG - 2022-09-06 06:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:35:46 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:05:46 --> Total execution time: 0.0741
DEBUG - 2022-09-06 06:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:05:52 --> Total execution time: 0.1100
DEBUG - 2022-09-06 06:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:06:10 --> Total execution time: 0.1491
DEBUG - 2022-09-06 06:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:06:27 --> Total execution time: 0.1462
DEBUG - 2022-09-06 06:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:06:31 --> Total execution time: 0.1096
DEBUG - 2022-09-06 06:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:06:31 --> Total execution time: 0.1100
DEBUG - 2022-09-06 06:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:06:32 --> Total execution time: 0.1119
DEBUG - 2022-09-06 06:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:06:33 --> Total execution time: 0.1074
DEBUG - 2022-09-06 06:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:06:33 --> Total execution time: 0.1320
DEBUG - 2022-09-06 06:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:37:29 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:07:29 --> Total execution time: 0.0849
DEBUG - 2022-09-06 06:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:09:33 --> Total execution time: 0.1070
DEBUG - 2022-09-06 06:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:09:46 --> Total execution time: 0.1224
DEBUG - 2022-09-06 06:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:09:54 --> Total execution time: 0.1459
DEBUG - 2022-09-06 06:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:10:12 --> Total execution time: 0.1805
DEBUG - 2022-09-06 06:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:42:26 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:12:26 --> Total execution time: 0.1892
DEBUG - 2022-09-06 06:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:42:47 --> Total execution time: 0.1113
DEBUG - 2022-09-06 06:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:12:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-06 06:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:12:50 --> Total execution time: 0.1409
DEBUG - 2022-09-06 06:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:13:00 --> Total execution time: 0.2471
DEBUG - 2022-09-06 06:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:44:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:14:31 --> Total execution time: 0.0783
DEBUG - 2022-09-06 06:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:45:07 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:15:07 --> Total execution time: 0.0717
DEBUG - 2022-09-06 06:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:45:08 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:15:08 --> Total execution time: 0.0728
DEBUG - 2022-09-06 06:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:15:17 --> Total execution time: 0.0705
DEBUG - 2022-09-06 06:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:15:18 --> Total execution time: 0.0656
DEBUG - 2022-09-06 06:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:45:27 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:15:27 --> Total execution time: 0.1085
DEBUG - 2022-09-06 06:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:45:31 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:15:31 --> Total execution time: 0.0642
DEBUG - 2022-09-06 06:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:45:32 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:15:32 --> Total execution time: 0.0630
DEBUG - 2022-09-06 06:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:15:36 --> Total execution time: 0.0777
DEBUG - 2022-09-06 06:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:15:44 --> Total execution time: 0.1186
DEBUG - 2022-09-06 06:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:15:49 --> Total execution time: 0.1290
DEBUG - 2022-09-06 06:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:45:54 --> Total execution time: 0.0629
DEBUG - 2022-09-06 06:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:45:56 --> Total execution time: 0.1017
DEBUG - 2022-09-06 06:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:45:56 --> Total execution time: 0.1065
DEBUG - 2022-09-06 06:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:16:02 --> Total execution time: 0.1823
DEBUG - 2022-09-06 06:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:16:14 --> Total execution time: 0.0973
DEBUG - 2022-09-06 06:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:46:21 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:16:21 --> Total execution time: 0.1065
DEBUG - 2022-09-06 06:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:46:24 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:16:24 --> Total execution time: 0.0750
DEBUG - 2022-09-06 06:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:46:49 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:16:50 --> Total execution time: 0.1236
DEBUG - 2022-09-06 06:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:16:53 --> Total execution time: 0.1029
DEBUG - 2022-09-06 06:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:46:55 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:16:55 --> Total execution time: 0.0991
DEBUG - 2022-09-06 06:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:47:01 --> Total execution time: 0.1196
DEBUG - 2022-09-06 06:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:47:03 --> Total execution time: 0.1379
DEBUG - 2022-09-06 06:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:47:04 --> Total execution time: 0.1013
DEBUG - 2022-09-06 06:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:17:22 --> Total execution time: 0.0993
DEBUG - 2022-09-06 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:17:49 --> Total execution time: 0.1030
DEBUG - 2022-09-06 06:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:18:00 --> Total execution time: 0.1492
DEBUG - 2022-09-06 06:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:18:01 --> Total execution time: 0.1503
DEBUG - 2022-09-06 06:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:18:32 --> Total execution time: 2.8239
DEBUG - 2022-09-06 06:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:48:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 06:48:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 06:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:18:44 --> Total execution time: 0.4472
DEBUG - 2022-09-06 06:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:19:13 --> Total execution time: 0.1609
DEBUG - 2022-09-06 06:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:19:15 --> Total execution time: 0.3666
DEBUG - 2022-09-06 06:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:19:17 --> Total execution time: 0.1418
DEBUG - 2022-09-06 06:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:19:18 --> Total execution time: 0.1243
DEBUG - 2022-09-06 06:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:20:29 --> Total execution time: 0.3148
DEBUG - 2022-09-06 06:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:20:30 --> Total execution time: 0.1135
DEBUG - 2022-09-06 06:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 17:20:36 --> Total execution time: 0.1172
DEBUG - 2022-09-06 06:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:20:36 --> Total execution time: 0.1696
DEBUG - 2022-09-06 06:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:20:37 --> Total execution time: 0.1030
DEBUG - 2022-09-06 06:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:50:41 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:20:41 --> Total execution time: 0.0706
DEBUG - 2022-09-06 06:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:20:41 --> Total execution time: 0.1348
DEBUG - 2022-09-06 06:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:21:12 --> Total execution time: 0.1264
DEBUG - 2022-09-06 06:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:52:04 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:22:04 --> Total execution time: 0.3437
DEBUG - 2022-09-06 06:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:52:09 --> Total execution time: 0.1215
DEBUG - 2022-09-06 06:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:52:11 --> Total execution time: 0.1285
DEBUG - 2022-09-06 06:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:52:12 --> Total execution time: 0.1565
DEBUG - 2022-09-06 06:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:52:23 --> Total execution time: 0.1003
DEBUG - 2022-09-06 06:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:52:24 --> Total execution time: 0.1065
DEBUG - 2022-09-06 06:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 06:52:24 --> Total execution time: 0.1237
DEBUG - 2022-09-06 06:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:52:29 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:22:29 --> Total execution time: 0.0647
DEBUG - 2022-09-06 06:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 06:52:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 06:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 06:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:22:30 --> Total execution time: 0.1033
DEBUG - 2022-09-06 07:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:30:03 --> Total execution time: 0.2988
DEBUG - 2022-09-06 07:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:00:51 --> No URI present. Default controller set.
DEBUG - 2022-09-06 07:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:30:51 --> Total execution time: 0.0838
DEBUG - 2022-09-06 07:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:00:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 07:00:58 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-06 07:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:30:58 --> Total execution time: 0.0759
DEBUG - 2022-09-06 07:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:01:19 --> Total execution time: 0.1323
DEBUG - 2022-09-06 07:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:01:21 --> Total execution time: 0.1034
DEBUG - 2022-09-06 07:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:01:22 --> Total execution time: 0.1065
DEBUG - 2022-09-06 07:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:32:00 --> Total execution time: 1.9670
DEBUG - 2022-09-06 07:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:02:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 07:02:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:32:27 --> Total execution time: 0.1008
DEBUG - 2022-09-06 07:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:32:46 --> Total execution time: 0.1358
DEBUG - 2022-09-06 07:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:02:46 --> No URI present. Default controller set.
DEBUG - 2022-09-06 07:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:32:47 --> Total execution time: 0.1235
DEBUG - 2022-09-06 07:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:32:52 --> Total execution time: 0.1108
DEBUG - 2022-09-06 07:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:32:53 --> Total execution time: 0.1020
DEBUG - 2022-09-06 07:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:33:00 --> Total execution time: 0.1141
DEBUG - 2022-09-06 07:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:33:07 --> Total execution time: 0.1209
DEBUG - 2022-09-06 07:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:33:14 --> Total execution time: 0.1416
DEBUG - 2022-09-06 07:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:04:18 --> No URI present. Default controller set.
DEBUG - 2022-09-06 07:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:34:18 --> Total execution time: 0.0919
DEBUG - 2022-09-06 07:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:34:20 --> Total execution time: 0.0613
DEBUG - 2022-09-06 07:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:34:24 --> Total execution time: 0.1082
DEBUG - 2022-09-06 07:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:35:04 --> Total execution time: 0.3695
DEBUG - 2022-09-06 07:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:36:03 --> Total execution time: 0.3025
DEBUG - 2022-09-06 07:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:36:10 --> Total execution time: 0.1053
DEBUG - 2022-09-06 07:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:36:18 --> Total execution time: 0.1206
DEBUG - 2022-09-06 07:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:36:41 --> Total execution time: 0.1068
DEBUG - 2022-09-06 07:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:06:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 07:06:55 --> 404 Page Not Found: Wp-config-samplephp/index
DEBUG - 2022-09-06 07:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:07:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 07:07:20 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-09-06 07:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:37:25 --> Total execution time: 0.1027
DEBUG - 2022-09-06 07:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:37:41 --> Total execution time: 0.1034
DEBUG - 2022-09-06 07:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:37:56 --> Total execution time: 0.1116
DEBUG - 2022-09-06 07:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:38:07 --> Total execution time: 0.1051
DEBUG - 2022-09-06 07:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:38:18 --> Total execution time: 0.1024
DEBUG - 2022-09-06 07:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:38:51 --> Total execution time: 0.0743
DEBUG - 2022-09-06 07:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:39:05 --> Total execution time: 0.3625
DEBUG - 2022-09-06 07:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:09:12 --> Total execution time: 0.1125
DEBUG - 2022-09-06 07:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:39:17 --> Total execution time: 0.1318
DEBUG - 2022-09-06 07:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:09:42 --> Total execution time: 0.1296
DEBUG - 2022-09-06 07:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:39:55 --> Total execution time: 0.1643
DEBUG - 2022-09-06 07:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:10:21 --> Total execution time: 0.1735
DEBUG - 2022-09-06 07:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:12:02 --> Total execution time: 0.0716
DEBUG - 2022-09-06 07:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:13:05 --> Total execution time: 0.3056
DEBUG - 2022-09-06 07:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:13:07 --> Total execution time: 0.1333
DEBUG - 2022-09-06 07:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:13:07 --> Total execution time: 0.1082
DEBUG - 2022-09-06 07:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:43:09 --> Total execution time: 0.2901
DEBUG - 2022-09-06 07:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 07:13:11 --> 404 Page Not Found: Teacher/tom-steven
DEBUG - 2022-09-06 07:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:43:18 --> Total execution time: 0.1177
DEBUG - 2022-09-06 07:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:13:24 --> Total execution time: 0.1108
DEBUG - 2022-09-06 07:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:13:24 --> Total execution time: 0.2643
DEBUG - 2022-09-06 07:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:43:30 --> Total execution time: 0.1238
DEBUG - 2022-09-06 07:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:43:34 --> Total execution time: 0.1115
DEBUG - 2022-09-06 07:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:47:15 --> Total execution time: 0.1711
DEBUG - 2022-09-06 07:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:47:42 --> Total execution time: 0.1543
DEBUG - 2022-09-06 07:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:47:49 --> Total execution time: 0.1267
DEBUG - 2022-09-06 07:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:47:56 --> Total execution time: 0.1323
DEBUG - 2022-09-06 07:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:48:05 --> Total execution time: 0.1598
DEBUG - 2022-09-06 07:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:48:23 --> Total execution time: 0.1108
DEBUG - 2022-09-06 07:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:48:26 --> Total execution time: 0.1309
DEBUG - 2022-09-06 07:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:48:30 --> Total execution time: 0.1325
DEBUG - 2022-09-06 07:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:18:40 --> Total execution time: 0.0931
DEBUG - 2022-09-06 07:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:18:59 --> Total execution time: 0.0956
DEBUG - 2022-09-06 07:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:19:17 --> Total execution time: 0.0965
DEBUG - 2022-09-06 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:19:43 --> Total execution time: 0.0984
DEBUG - 2022-09-06 07:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:49:58 --> Total execution time: 0.1110
DEBUG - 2022-09-06 07:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:50:06 --> Total execution time: 0.1569
DEBUG - 2022-09-06 07:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:50:18 --> Total execution time: 0.1801
DEBUG - 2022-09-06 07:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:50:58 --> Total execution time: 0.1201
DEBUG - 2022-09-06 07:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:22:12 --> Total execution time: 0.1153
DEBUG - 2022-09-06 07:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:22:16 --> Total execution time: 0.1568
DEBUG - 2022-09-06 07:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:53:22 --> Total execution time: 0.1360
DEBUG - 2022-09-06 07:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:53:48 --> Total execution time: 0.1328
DEBUG - 2022-09-06 07:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:54:21 --> Total execution time: 0.1291
DEBUG - 2022-09-06 07:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:54:46 --> Total execution time: 0.1291
DEBUG - 2022-09-06 07:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:54:59 --> Total execution time: 0.1541
DEBUG - 2022-09-06 07:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:55:04 --> Total execution time: 0.1435
DEBUG - 2022-09-06 07:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:55:15 --> Total execution time: 0.1117
DEBUG - 2022-09-06 07:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:55:27 --> Total execution time: 0.1895
DEBUG - 2022-09-06 07:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:55:47 --> Total execution time: 0.1042
DEBUG - 2022-09-06 07:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:55:50 --> Total execution time: 0.1363
DEBUG - 2022-09-06 07:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:57:00 --> Total execution time: 0.1031
DEBUG - 2022-09-06 07:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:57:22 --> Total execution time: 0.1099
DEBUG - 2022-09-06 07:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:57:47 --> Total execution time: 0.1226
DEBUG - 2022-09-06 07:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:57:48 --> Total execution time: 0.1178
DEBUG - 2022-09-06 07:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:57:55 --> Total execution time: 0.1078
DEBUG - 2022-09-06 07:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:58:47 --> Total execution time: 0.1435
DEBUG - 2022-09-06 07:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:29:00 --> No URI present. Default controller set.
DEBUG - 2022-09-06 07:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:59:00 --> Total execution time: 0.0991
DEBUG - 2022-09-06 07:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:59:05 --> Total execution time: 0.1363
DEBUG - 2022-09-06 07:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:59:20 --> Total execution time: 0.1339
DEBUG - 2022-09-06 07:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:59:33 --> Total execution time: 0.1039
DEBUG - 2022-09-06 07:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:00:02 --> Total execution time: 0.2083
DEBUG - 2022-09-06 07:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:00:03 --> Total execution time: 0.1376
DEBUG - 2022-09-06 07:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:00:03 --> Total execution time: 0.1594
DEBUG - 2022-09-06 07:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:00:04 --> Total execution time: 0.1812
DEBUG - 2022-09-06 07:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:30:58 --> No URI present. Default controller set.
DEBUG - 2022-09-06 07:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:00:58 --> Total execution time: 0.0745
DEBUG - 2022-09-06 07:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:04:25 --> Total execution time: 0.1058
DEBUG - 2022-09-06 07:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:04:34 --> Total execution time: 0.1125
DEBUG - 2022-09-06 07:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:04:55 --> Total execution time: 0.1082
DEBUG - 2022-09-06 07:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:05:04 --> Total execution time: 0.1118
DEBUG - 2022-09-06 07:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:05:09 --> Total execution time: 0.1115
DEBUG - 2022-09-06 07:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:05:24 --> Total execution time: 0.0996
DEBUG - 2022-09-06 07:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:06:30 --> Total execution time: 0.0966
DEBUG - 2022-09-06 07:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:06:31 --> Total execution time: 0.0987
DEBUG - 2022-09-06 07:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:06:52 --> Total execution time: 0.1015
DEBUG - 2022-09-06 07:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:07:06 --> Total execution time: 0.1078
DEBUG - 2022-09-06 07:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:07:13 --> Total execution time: 0.1380
DEBUG - 2022-09-06 07:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:07:32 --> Total execution time: 0.1006
DEBUG - 2022-09-06 07:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:09:10 --> Total execution time: 0.0991
DEBUG - 2022-09-06 07:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:09:39 --> Total execution time: 0.0635
DEBUG - 2022-09-06 07:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:11:19 --> Total execution time: 0.1084
DEBUG - 2022-09-06 07:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:11:31 --> Total execution time: 0.1390
DEBUG - 2022-09-06 07:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:13:38 --> Total execution time: 0.2056
DEBUG - 2022-09-06 07:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:13:47 --> Total execution time: 0.1154
DEBUG - 2022-09-06 07:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:14:17 --> Total execution time: 0.1037
DEBUG - 2022-09-06 07:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:14:55 --> Total execution time: 0.1055
DEBUG - 2022-09-06 07:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:45:06 --> No URI present. Default controller set.
DEBUG - 2022-09-06 07:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:15:06 --> Total execution time: 0.0707
DEBUG - 2022-09-06 07:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:15:20 --> Total execution time: 0.0604
DEBUG - 2022-09-06 07:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:15:48 --> Total execution time: 0.1065
DEBUG - 2022-09-06 07:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:16:08 --> Total execution time: 0.1040
DEBUG - 2022-09-06 07:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:16:10 --> Total execution time: 0.1277
DEBUG - 2022-09-06 07:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:16:22 --> Total execution time: 0.1130
DEBUG - 2022-09-06 07:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:16:24 --> Total execution time: 0.1105
DEBUG - 2022-09-06 07:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:16:26 --> Total execution time: 0.1059
DEBUG - 2022-09-06 07:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:16:34 --> Total execution time: 0.7966
DEBUG - 2022-09-06 07:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:16:42 --> Total execution time: 0.1261
DEBUG - 2022-09-06 07:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:16:59 --> Total execution time: 0.0994
DEBUG - 2022-09-06 07:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:17:10 --> Total execution time: 0.1329
DEBUG - 2022-09-06 07:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:47:24 --> Total execution time: 0.1036
DEBUG - 2022-09-06 07:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:17:25 --> Total execution time: 0.1038
DEBUG - 2022-09-06 07:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:18:08 --> Total execution time: 0.1097
DEBUG - 2022-09-06 07:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:18:27 --> Total execution time: 0.1044
DEBUG - 2022-09-06 07:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:18:55 --> Total execution time: 0.1050
DEBUG - 2022-09-06 07:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:19:49 --> Total execution time: 0.1074
DEBUG - 2022-09-06 07:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:50:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 07:50:42 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-09-06 07:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:20:47 --> Total execution time: 0.0619
DEBUG - 2022-09-06 07:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:51:22 --> No URI present. Default controller set.
DEBUG - 2022-09-06 07:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:21:22 --> Total execution time: 0.0638
DEBUG - 2022-09-06 07:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:21:23 --> Total execution time: 0.0685
DEBUG - 2022-09-06 07:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:21:33 --> Total execution time: 0.0956
DEBUG - 2022-09-06 07:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:21:42 --> Total execution time: 0.0958
DEBUG - 2022-09-06 07:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:21:50 --> Total execution time: 0.0979
DEBUG - 2022-09-06 07:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:22:01 --> Total execution time: 0.1308
DEBUG - 2022-09-06 07:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:52:09 --> No URI present. Default controller set.
DEBUG - 2022-09-06 07:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:22:09 --> Total execution time: 0.1181
DEBUG - 2022-09-06 07:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:22:58 --> Total execution time: 0.0961
DEBUG - 2022-09-06 07:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:23:19 --> Total execution time: 0.1035
DEBUG - 2022-09-06 07:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:23:28 --> Total execution time: 0.1072
DEBUG - 2022-09-06 07:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:53:31 --> No URI present. Default controller set.
DEBUG - 2022-09-06 07:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:23:31 --> Total execution time: 0.0630
DEBUG - 2022-09-06 07:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:23:36 --> Total execution time: 0.1031
DEBUG - 2022-09-06 07:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:23:38 --> Total execution time: 0.1334
DEBUG - 2022-09-06 07:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:23:55 --> Total execution time: 0.1057
DEBUG - 2022-09-06 07:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:56:58 --> No URI present. Default controller set.
DEBUG - 2022-09-06 07:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:26:58 --> Total execution time: 0.1467
DEBUG - 2022-09-06 07:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:58:09 --> Total execution time: 0.0749
DEBUG - 2022-09-06 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:58:11 --> Total execution time: 0.1512
DEBUG - 2022-09-06 07:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:58:11 --> Total execution time: 0.0919
DEBUG - 2022-09-06 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:58:11 --> Total execution time: 0.0985
DEBUG - 2022-09-06 07:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:58:12 --> Total execution time: 0.1070
DEBUG - 2022-09-06 07:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:58:13 --> Total execution time: 0.0746
DEBUG - 2022-09-06 07:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 07:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 07:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:58:13 --> Total execution time: 0.0986
DEBUG - 2022-09-06 07:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 07:58:14 --> Total execution time: 0.2017
DEBUG - 2022-09-06 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:30:02 --> Total execution time: 0.1474
DEBUG - 2022-09-06 08:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:01:09 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:31:09 --> Total execution time: 0.1072
DEBUG - 2022-09-06 08:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:01:19 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:31:19 --> Total execution time: 0.0627
DEBUG - 2022-09-06 08:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:34:36 --> Total execution time: 0.0996
DEBUG - 2022-09-06 08:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:35:09 --> Total execution time: 0.0940
DEBUG - 2022-09-06 08:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:05:25 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:35:25 --> Total execution time: 0.0756
DEBUG - 2022-09-06 08:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:05:41 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:35:41 --> Total execution time: 0.0988
DEBUG - 2022-09-06 08:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:35:56 --> Total execution time: 0.2769
DEBUG - 2022-09-06 08:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:05:58 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:35:58 --> Total execution time: 0.0643
DEBUG - 2022-09-06 08:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:36:36 --> Total execution time: 0.0635
DEBUG - 2022-09-06 08:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:37:03 --> Total execution time: 0.0937
DEBUG - 2022-09-06 08:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:39:34 --> Total execution time: 0.1106
DEBUG - 2022-09-06 08:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:09:43 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:39:43 --> Total execution time: 0.0996
DEBUG - 2022-09-06 08:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:47:00 --> Total execution time: 0.1954
DEBUG - 2022-09-06 08:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:50:42 --> Total execution time: 0.1420
DEBUG - 2022-09-06 08:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:55:42 --> Total execution time: 0.2684
DEBUG - 2022-09-06 08:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:56:03 --> Total execution time: 0.1126
DEBUG - 2022-09-06 08:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:56:10 --> Total execution time: 0.1263
DEBUG - 2022-09-06 08:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:56:13 --> Total execution time: 0.1320
DEBUG - 2022-09-06 08:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:56:24 --> Total execution time: 0.1199
DEBUG - 2022-09-06 08:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:56:33 --> Total execution time: 0.1175
DEBUG - 2022-09-06 08:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:57:07 --> Total execution time: 0.0643
DEBUG - 2022-09-06 08:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:57:15 --> Total execution time: 0.0964
DEBUG - 2022-09-06 08:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:57:46 --> Total execution time: 0.1114
DEBUG - 2022-09-06 08:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:27:47 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:57:47 --> Total execution time: 0.0672
DEBUG - 2022-09-06 08:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:57:55 --> Total execution time: 2.3073
DEBUG - 2022-09-06 08:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:57:57 --> Total execution time: 3.1635
DEBUG - 2022-09-06 08:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:28:00 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:58:00 --> Total execution time: 0.0953
DEBUG - 2022-09-06 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:28:22 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:58:22 --> Total execution time: 0.0651
DEBUG - 2022-09-06 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:58:22 --> Total execution time: 0.0961
DEBUG - 2022-09-06 08:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:58:24 --> Total execution time: 0.0948
DEBUG - 2022-09-06 08:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:58:35 --> Total execution time: 0.1055
DEBUG - 2022-09-06 08:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:58:50 --> Total execution time: 0.1135
DEBUG - 2022-09-06 08:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:59:00 --> Total execution time: 0.1235
DEBUG - 2022-09-06 08:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:59:03 --> Total execution time: 0.1033
DEBUG - 2022-09-06 08:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:59:08 --> Total execution time: 0.1028
DEBUG - 2022-09-06 08:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:29:56 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:59:56 --> Total execution time: 0.0646
DEBUG - 2022-09-06 08:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:30:09 --> Total execution time: 0.1025
DEBUG - 2022-09-06 08:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:30:11 --> Total execution time: 0.1035
DEBUG - 2022-09-06 08:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:30:11 --> Total execution time: 0.0968
DEBUG - 2022-09-06 08:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:30:40 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:00:40 --> Total execution time: 0.1004
DEBUG - 2022-09-06 08:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:02:03 --> Total execution time: 0.1062
DEBUG - 2022-09-06 08:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:03:56 --> Total execution time: 0.1090
DEBUG - 2022-09-06 08:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:03:58 --> Total execution time: 0.1022
DEBUG - 2022-09-06 08:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:04:00 --> Total execution time: 0.0963
DEBUG - 2022-09-06 08:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:04:15 --> Total execution time: 0.0959
DEBUG - 2022-09-06 08:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:34:25 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:04:25 --> Total execution time: 0.0993
DEBUG - 2022-09-06 08:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:34:26 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:04:26 --> Total execution time: 0.0990
DEBUG - 2022-09-06 08:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:04:39 --> Total execution time: 0.1116
DEBUG - 2022-09-06 08:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:35:16 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:05:16 --> Total execution time: 0.0741
DEBUG - 2022-09-06 08:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:05:33 --> Total execution time: 0.1104
DEBUG - 2022-09-06 08:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:05:49 --> Total execution time: 0.1169
DEBUG - 2022-09-06 08:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:06:03 --> Total execution time: 0.1100
DEBUG - 2022-09-06 08:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:36:16 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:06:16 --> Total execution time: 0.0654
DEBUG - 2022-09-06 08:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:06:17 --> Total execution time: 0.1159
DEBUG - 2022-09-06 08:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:06:23 --> Total execution time: 0.0639
DEBUG - 2022-09-06 08:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:06:43 --> Total execution time: 0.1020
DEBUG - 2022-09-06 08:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:06:53 --> Total execution time: 0.0977
DEBUG - 2022-09-06 08:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:07:24 --> Total execution time: 0.1051
DEBUG - 2022-09-06 08:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:08:04 --> Total execution time: 0.1724
DEBUG - 2022-09-06 08:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:08:15 --> Total execution time: 0.1286
DEBUG - 2022-09-06 08:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:08:29 --> Total execution time: 0.1131
DEBUG - 2022-09-06 08:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:08:50 --> Total execution time: 0.1421
DEBUG - 2022-09-06 08:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:40:15 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:10:15 --> Total execution time: 0.0714
DEBUG - 2022-09-06 08:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:10:42 --> Total execution time: 0.2752
DEBUG - 2022-09-06 08:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:43:35 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:13:35 --> Total execution time: 0.1624
DEBUG - 2022-09-06 08:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:15:48 --> Total execution time: 0.0990
DEBUG - 2022-09-06 08:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 08:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:15:56 --> Total execution time: 0.1050
DEBUG - 2022-09-06 08:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:16:03 --> Total execution time: 0.1163
DEBUG - 2022-09-06 08:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:16:08 --> Total execution time: 0.1270
DEBUG - 2022-09-06 08:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:46:11 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:16:11 --> Total execution time: 0.1000
DEBUG - 2022-09-06 08:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:16:21 --> Total execution time: 2.4554
DEBUG - 2022-09-06 08:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:20:41 --> Total execution time: 0.1219
DEBUG - 2022-09-06 08:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:53:27 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:23:27 --> Total execution time: 0.1139
DEBUG - 2022-09-06 08:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 08:59:16 --> No URI present. Default controller set.
DEBUG - 2022-09-06 08:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 08:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:29:16 --> Total execution time: 0.1202
DEBUG - 2022-09-06 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:30:02 --> Total execution time: 0.0993
DEBUG - 2022-09-06 09:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:32:17 --> Total execution time: 0.0963
DEBUG - 2022-09-06 09:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:03:00 --> Total execution time: 0.1117
DEBUG - 2022-09-06 09:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:03:05 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:33:05 --> Total execution time: 0.1308
DEBUG - 2022-09-06 09:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:03:22 --> Total execution time: 0.1037
DEBUG - 2022-09-06 09:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:03:22 --> Total execution time: 0.0983
DEBUG - 2022-09-06 09:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:03:26 --> Total execution time: 0.1018
DEBUG - 2022-09-06 09:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:03:26 --> Total execution time: 0.0954
DEBUG - 2022-09-06 09:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:03:33 --> Total execution time: 0.1042
DEBUG - 2022-09-06 09:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:03:37 --> Total execution time: 0.0976
DEBUG - 2022-09-06 09:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:03:54 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:33:54 --> Total execution time: 0.0992
DEBUG - 2022-09-06 09:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:35:33 --> Total execution time: 0.0923
DEBUG - 2022-09-06 09:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:16:57 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:46:58 --> Total execution time: 0.1660
DEBUG - 2022-09-06 09:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:17:28 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:47:28 --> Total execution time: 0.0644
DEBUG - 2022-09-06 09:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:47:31 --> Total execution time: 0.0981
DEBUG - 2022-09-06 09:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:47:35 --> Total execution time: 0.0959
DEBUG - 2022-09-06 09:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:17:42 --> Total execution time: 0.0999
DEBUG - 2022-09-06 09:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:17:46 --> Total execution time: 0.1533
DEBUG - 2022-09-06 09:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:17:46 --> Total execution time: 0.1046
DEBUG - 2022-09-06 09:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:47:53 --> Total execution time: 0.1116
DEBUG - 2022-09-06 09:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:48:01 --> Total execution time: 0.1149
DEBUG - 2022-09-06 09:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:18:40 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:48:40 --> Total execution time: 0.0634
DEBUG - 2022-09-06 09:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:21:53 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:51:53 --> Total execution time: 0.0664
DEBUG - 2022-09-06 09:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:52:39 --> Total execution time: 2.6054
DEBUG - 2022-09-06 09:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:23:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 09:23:32 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 09:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:23:52 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:53:52 --> Total execution time: 0.0717
DEBUG - 2022-09-06 09:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:24:04 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:54:04 --> Total execution time: 0.1101
DEBUG - 2022-09-06 09:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:54:20 --> Total execution time: 0.0957
DEBUG - 2022-09-06 09:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:24:48 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:54:48 --> Total execution time: 0.0805
DEBUG - 2022-09-06 09:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:54:55 --> Total execution time: 0.0616
DEBUG - 2022-09-06 09:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:25:02 --> Total execution time: 0.4894
DEBUG - 2022-09-06 09:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:25:13 --> Total execution time: 0.1007
DEBUG - 2022-09-06 09:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:25:13 --> Total execution time: 0.2056
DEBUG - 2022-09-06 09:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:55:16 --> Total execution time: 0.1020
DEBUG - 2022-09-06 09:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:55:24 --> Total execution time: 0.1417
DEBUG - 2022-09-06 09:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:25:29 --> Total execution time: 0.1025
DEBUG - 2022-09-06 09:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:25:38 --> Total execution time: 0.1412
DEBUG - 2022-09-06 09:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:25:41 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:55:41 --> Total execution time: 0.0632
DEBUG - 2022-09-06 09:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:55:45 --> Total execution time: 1.8749
DEBUG - 2022-09-06 09:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:55:47 --> Total execution time: 0.1176
DEBUG - 2022-09-06 09:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:55:52 --> Total execution time: 0.1306
DEBUG - 2022-09-06 09:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:55:56 --> Total execution time: 0.1844
DEBUG - 2022-09-06 09:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:55:56 --> Total execution time: 0.0831
DEBUG - 2022-09-06 09:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:26:06 --> Total execution time: 0.0968
DEBUG - 2022-09-06 09:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:26:06 --> Total execution time: 0.1037
DEBUG - 2022-09-06 09:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:26:10 --> Total execution time: 0.1012
DEBUG - 2022-09-06 09:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:56:10 --> Total execution time: 0.1216
DEBUG - 2022-09-06 09:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:26:10 --> Total execution time: 0.1288
DEBUG - 2022-09-06 09:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:56:16 --> Total execution time: 0.1185
DEBUG - 2022-09-06 09:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:56:23 --> Total execution time: 0.1035
DEBUG - 2022-09-06 09:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:29 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:56:29 --> Total execution time: 0.0995
DEBUG - 2022-09-06 09:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:56:39 --> Total execution time: 0.0986
DEBUG - 2022-09-06 09:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:26:48 --> Total execution time: 0.0906
DEBUG - 2022-09-06 09:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:56:48 --> Total execution time: 0.0918
DEBUG - 2022-09-06 09:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:26:50 --> Total execution time: 0.1046
DEBUG - 2022-09-06 09:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:26:50 --> Total execution time: 0.2255
DEBUG - 2022-09-06 09:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:51 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:56:51 --> Total execution time: 0.0680
DEBUG - 2022-09-06 09:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:56:54 --> Total execution time: 0.0966
DEBUG - 2022-09-06 09:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:57:03 --> Total execution time: 0.0970
DEBUG - 2022-09-06 09:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:57:08 --> Total execution time: 0.1006
DEBUG - 2022-09-06 09:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:57:13 --> Total execution time: 0.1107
DEBUG - 2022-09-06 09:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:57:17 --> Total execution time: 0.0903
DEBUG - 2022-09-06 09:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:27:17 --> Total execution time: 0.0925
DEBUG - 2022-09-06 09:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:27:19 --> Total execution time: 0.0972
DEBUG - 2022-09-06 09:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:27:20 --> Total execution time: 0.1884
DEBUG - 2022-09-06 09:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:57:24 --> Total execution time: 0.0962
DEBUG - 2022-09-06 09:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:57:24 --> Total execution time: 0.1074
DEBUG - 2022-09-06 09:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:57:26 --> Total execution time: 0.0947
DEBUG - 2022-09-06 09:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:27:26 --> Total execution time: 0.1023
DEBUG - 2022-09-06 09:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:57:32 --> Total execution time: 0.1018
DEBUG - 2022-09-06 09:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:57:37 --> Total execution time: 0.1169
DEBUG - 2022-09-06 09:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:27:52 --> Total execution time: 0.0981
DEBUG - 2022-09-06 09:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:27:54 --> Total execution time: 0.1012
DEBUG - 2022-09-06 09:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:27:56 --> Total execution time: 0.1025
DEBUG - 2022-09-06 09:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:27:56 --> Total execution time: 0.0966
DEBUG - 2022-09-06 09:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:57:57 --> Total execution time: 0.1018
DEBUG - 2022-09-06 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:58:02 --> Total execution time: 0.0986
DEBUG - 2022-09-06 09:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 19:58:02 --> Total execution time: 0.1274
DEBUG - 2022-09-06 09:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:58:03 --> Total execution time: 0.1314
DEBUG - 2022-09-06 09:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:58:03 --> Total execution time: 0.1399
DEBUG - 2022-09-06 09:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:58:08 --> Total execution time: 0.1233
DEBUG - 2022-09-06 09:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:28:11 --> Total execution time: 0.0958
DEBUG - 2022-09-06 09:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:28:12 --> Total execution time: 0.0971
DEBUG - 2022-09-06 09:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:28:14 --> Total execution time: 0.0950
DEBUG - 2022-09-06 09:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:28:14 --> Total execution time: 0.1084
DEBUG - 2022-09-06 09:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:58:15 --> Total execution time: 0.0957
DEBUG - 2022-09-06 09:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:58:20 --> Total execution time: 0.1288
DEBUG - 2022-09-06 09:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:58:29 --> Total execution time: 0.1306
DEBUG - 2022-09-06 09:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:58:32 --> Total execution time: 0.0985
DEBUG - 2022-09-06 09:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:58:33 --> Total execution time: 0.0951
DEBUG - 2022-09-06 09:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:58:41 --> Total execution time: 0.1246
DEBUG - 2022-09-06 09:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:58:42 --> Total execution time: 0.1031
DEBUG - 2022-09-06 09:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:58:43 --> Total execution time: 0.0956
DEBUG - 2022-09-06 09:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:58:45 --> Total execution time: 0.0971
DEBUG - 2022-09-06 09:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:59:25 --> Total execution time: 0.1309
DEBUG - 2022-09-06 09:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:59:30 --> Total execution time: 0.0634
DEBUG - 2022-09-06 09:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:31 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:59:31 --> Total execution time: 0.0617
DEBUG - 2022-09-06 09:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:32 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:59:32 --> Total execution time: 0.0634
DEBUG - 2022-09-06 09:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:59:38 --> Total execution time: 0.0702
DEBUG - 2022-09-06 09:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:59:41 --> Total execution time: 0.1413
DEBUG - 2022-09-06 09:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:59:42 --> Total execution time: 0.1303
DEBUG - 2022-09-06 09:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:59:46 --> Total execution time: 0.1100
DEBUG - 2022-09-06 09:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:59:47 --> Total execution time: 0.0606
DEBUG - 2022-09-06 09:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:59:47 --> Total execution time: 0.1391
DEBUG - 2022-09-06 09:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:59:53 --> Total execution time: 0.1311
DEBUG - 2022-09-06 09:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:00:07 --> Total execution time: 0.1096
DEBUG - 2022-09-06 09:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:30:08 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:00:08 --> Total execution time: 0.1025
DEBUG - 2022-09-06 09:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:00:16 --> Total execution time: 0.1317
DEBUG - 2022-09-06 09:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:00:32 --> Total execution time: 0.1094
DEBUG - 2022-09-06 09:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:30:34 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:00:34 --> Total execution time: 0.1376
DEBUG - 2022-09-06 09:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:00:39 --> Total execution time: 0.0957
DEBUG - 2022-09-06 09:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:00:43 --> Total execution time: 0.0971
DEBUG - 2022-09-06 09:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:00:47 --> Total execution time: 0.1581
DEBUG - 2022-09-06 09:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:00:48 --> Total execution time: 0.1285
DEBUG - 2022-09-06 09:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:01:09 --> Total execution time: 0.1015
DEBUG - 2022-09-06 09:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:01:13 --> Total execution time: 0.0960
DEBUG - 2022-09-06 09:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:01:13 --> Total execution time: 0.0967
DEBUG - 2022-09-06 09:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:01:14 --> Total execution time: 0.1076
DEBUG - 2022-09-06 09:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:01:19 --> Total execution time: 0.1011
DEBUG - 2022-09-06 09:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:01:23 --> Total execution time: 0.0971
DEBUG - 2022-09-06 09:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:01:30 --> Total execution time: 0.1276
DEBUG - 2022-09-06 09:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:01:33 --> Total execution time: 0.1422
DEBUG - 2022-09-06 09:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:01:40 --> Total execution time: 0.1059
DEBUG - 2022-09-06 09:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:01:40 --> Total execution time: 0.1098
DEBUG - 2022-09-06 09:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:01:42 --> Total execution time: 0.0992
DEBUG - 2022-09-06 09:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:01:43 --> Total execution time: 0.1184
DEBUG - 2022-09-06 09:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:01:49 --> Total execution time: 0.1193
DEBUG - 2022-09-06 09:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:02:54 --> Total execution time: 0.0652
DEBUG - 2022-09-06 09:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:04 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:03:04 --> Total execution time: 0.0783
DEBUG - 2022-09-06 09:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:03:09 --> Total execution time: 0.0977
DEBUG - 2022-09-06 09:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:03:10 --> Total execution time: 0.1101
DEBUG - 2022-09-06 09:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:10 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:03:10 --> Total execution time: 0.0639
DEBUG - 2022-09-06 09:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:03:12 --> Total execution time: 0.0641
DEBUG - 2022-09-06 09:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:12 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:03:12 --> Total execution time: 0.0971
DEBUG - 2022-09-06 09:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:22 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:03:22 --> Total execution time: 0.1114
DEBUG - 2022-09-06 09:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:23 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:03:23 --> Total execution time: 0.0996
DEBUG - 2022-09-06 09:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:03:25 --> Total execution time: 0.1074
DEBUG - 2022-09-06 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:03:29 --> Total execution time: 0.1012
DEBUG - 2022-09-06 09:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:03:34 --> Total execution time: 0.1828
DEBUG - 2022-09-06 09:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:03:40 --> Total execution time: 0.0966
DEBUG - 2022-09-06 09:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:03:42 --> Total execution time: 0.0976
DEBUG - 2022-09-06 09:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:04:04 --> Total execution time: 0.1651
DEBUG - 2022-09-06 09:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:04:10 --> Total execution time: 0.1262
DEBUG - 2022-09-06 09:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:34:12 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:04:12 --> Total execution time: 0.1027
DEBUG - 2022-09-06 09:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:04:16 --> Total execution time: 0.1012
DEBUG - 2022-09-06 09:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:34:25 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:04:25 --> Total execution time: 0.0986
DEBUG - 2022-09-06 09:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:34:29 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:04:29 --> Total execution time: 0.1032
DEBUG - 2022-09-06 09:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:04:29 --> Total execution time: 0.1309
DEBUG - 2022-09-06 09:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:04:30 --> Total execution time: 0.0964
DEBUG - 2022-09-06 09:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:34:37 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:04:37 --> Total execution time: 0.0713
DEBUG - 2022-09-06 09:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:34:42 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:04:42 --> Total execution time: 0.0945
DEBUG - 2022-09-06 09:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:34:44 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:04:44 --> Total execution time: 0.0575
DEBUG - 2022-09-06 09:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:04:57 --> Total execution time: 0.0902
DEBUG - 2022-09-06 09:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:05:14 --> Total execution time: 0.1040
DEBUG - 2022-09-06 09:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:35:24 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:05:24 --> Total execution time: 0.1057
DEBUG - 2022-09-06 09:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:05:38 --> Total execution time: 0.0647
DEBUG - 2022-09-06 09:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:06:00 --> Total execution time: 0.2901
DEBUG - 2022-09-06 09:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:06:02 --> Total execution time: 0.1434
DEBUG - 2022-09-06 09:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:10 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:06:10 --> Total execution time: 0.0997
DEBUG - 2022-09-06 09:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:06:10 --> Total execution time: 0.1143
DEBUG - 2022-09-06 09:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:06:13 --> Total execution time: 0.0945
DEBUG - 2022-09-06 09:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:36:15 --> Total execution time: 0.0963
DEBUG - 2022-09-06 09:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:15 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:06:15 --> Total execution time: 0.1165
DEBUG - 2022-09-06 09:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:36:17 --> Total execution time: 0.1185
DEBUG - 2022-09-06 09:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:36:17 --> Total execution time: 0.0951
DEBUG - 2022-09-06 09:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:06:22 --> Total execution time: 0.1149
DEBUG - 2022-09-06 09:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:23 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:06:23 --> Total execution time: 0.0977
DEBUG - 2022-09-06 09:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:06:27 --> Total execution time: 0.1063
DEBUG - 2022-09-06 09:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:06:32 --> Total execution time: 0.0667
DEBUG - 2022-09-06 09:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:36:34 --> Total execution time: 0.0614
DEBUG - 2022-09-06 09:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:06:57 --> Total execution time: 0.1092
DEBUG - 2022-09-06 09:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:07:08 --> Total execution time: 0.1212
DEBUG - 2022-09-06 09:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:07:12 --> Total execution time: 0.1297
DEBUG - 2022-09-06 09:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:07:53 --> Total execution time: 0.1464
DEBUG - 2022-09-06 09:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:07:55 --> Total execution time: 0.1251
DEBUG - 2022-09-06 09:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:07:56 --> Total execution time: 0.1512
DEBUG - 2022-09-06 09:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:37:57 --> Total execution time: 0.0994
DEBUG - 2022-09-06 09:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:37:59 --> Total execution time: 0.1202
DEBUG - 2022-09-06 09:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:38:00 --> Total execution time: 0.1076
DEBUG - 2022-09-06 09:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:02 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:08:02 --> Total execution time: 0.0999
DEBUG - 2022-09-06 09:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:03 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:08:03 --> Total execution time: 0.0662
DEBUG - 2022-09-06 09:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:08:11 --> Total execution time: 0.2661
DEBUG - 2022-09-06 09:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:12 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:08:12 --> Total execution time: 0.2634
DEBUG - 2022-09-06 09:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:08:26 --> Total execution time: 0.0983
DEBUG - 2022-09-06 09:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:08:29 --> Total execution time: 0.1119
DEBUG - 2022-09-06 09:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:08:34 --> Total execution time: 0.1144
DEBUG - 2022-09-06 09:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:35 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:08:35 --> Total execution time: 0.1053
DEBUG - 2022-09-06 09:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:38:41 --> Total execution time: 0.1068
DEBUG - 2022-09-06 09:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:38:43 --> Total execution time: 0.1030
DEBUG - 2022-09-06 09:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:38:43 --> Total execution time: 0.1050
DEBUG - 2022-09-06 09:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:08:48 --> Total execution time: 0.0974
DEBUG - 2022-09-06 09:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:09:02 --> Total execution time: 0.1324
DEBUG - 2022-09-06 09:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:09:34 --> Total execution time: 0.1144
DEBUG - 2022-09-06 09:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:09:34 --> Total execution time: 0.1454
DEBUG - 2022-09-06 09:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:39:35 --> Total execution time: 0.1163
DEBUG - 2022-09-06 09:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:09:38 --> Total execution time: 0.1198
DEBUG - 2022-09-06 09:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:39:38 --> Total execution time: 0.1006
DEBUG - 2022-09-06 09:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:39:39 --> Total execution time: 0.1375
DEBUG - 2022-09-06 09:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:09:42 --> Total execution time: 0.1285
DEBUG - 2022-09-06 09:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:09:52 --> Total execution time: 0.0965
DEBUG - 2022-09-06 09:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:10:03 --> Total execution time: 0.1509
DEBUG - 2022-09-06 09:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:10:06 --> Total execution time: 0.1045
DEBUG - 2022-09-06 09:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:10:08 --> Total execution time: 0.2714
DEBUG - 2022-09-06 09:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:10:38 --> Total execution time: 0.0693
DEBUG - 2022-09-06 09:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:40:39 --> Total execution time: 0.1020
DEBUG - 2022-09-06 09:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:40:41 --> Total execution time: 0.1028
DEBUG - 2022-09-06 09:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:40:41 --> Total execution time: 0.1214
DEBUG - 2022-09-06 09:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:10:46 --> Total execution time: 0.1012
DEBUG - 2022-09-06 09:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:10:54 --> Total execution time: 0.1096
DEBUG - 2022-09-06 09:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:10:59 --> Total execution time: 0.1259
DEBUG - 2022-09-06 09:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:41:03 --> Total execution time: 0.1121
DEBUG - 2022-09-06 09:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:41:06 --> Total execution time: 0.0989
DEBUG - 2022-09-06 09:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:41:08 --> Total execution time: 0.1125
DEBUG - 2022-09-06 09:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:41:08 --> Total execution time: 0.2477
DEBUG - 2022-09-06 09:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:41:11 --> Total execution time: 0.1314
DEBUG - 2022-09-06 09:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:11:12 --> Total execution time: 0.1571
DEBUG - 2022-09-06 09:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:41:13 --> Total execution time: 0.1359
DEBUG - 2022-09-06 09:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:41:13 --> Total execution time: 0.2732
DEBUG - 2022-09-06 09:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:11:28 --> Total execution time: 0.1230
DEBUG - 2022-09-06 09:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:11:37 --> Total execution time: 0.1214
DEBUG - 2022-09-06 09:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:11:45 --> Total execution time: 0.1039
DEBUG - 2022-09-06 09:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:42:00 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:12:00 --> Total execution time: 0.1364
DEBUG - 2022-09-06 09:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:42:07 --> Total execution time: 0.1117
DEBUG - 2022-09-06 09:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:42:09 --> Total execution time: 0.1071
DEBUG - 2022-09-06 09:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:42:10 --> Total execution time: 0.1044
DEBUG - 2022-09-06 09:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:42:33 --> Total execution time: 0.1131
DEBUG - 2022-09-06 09:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:42:39 --> Total execution time: 0.1432
DEBUG - 2022-09-06 09:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:42:39 --> Total execution time: 0.2845
DEBUG - 2022-09-06 09:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:12:43 --> Total execution time: 0.1154
DEBUG - 2022-09-06 09:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:13:08 --> Total execution time: 0.1130
DEBUG - 2022-09-06 09:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:13:17 --> Total execution time: 0.2577
DEBUG - 2022-09-06 09:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:13:18 --> Total execution time: 0.1047
DEBUG - 2022-09-06 09:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:43:52 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:13:52 --> Total execution time: 0.0694
DEBUG - 2022-09-06 09:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:43:58 --> Total execution time: 0.0988
DEBUG - 2022-09-06 09:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:44:04 --> Total execution time: 0.1101
DEBUG - 2022-09-06 09:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:44:04 --> Total execution time: 0.2253
DEBUG - 2022-09-06 09:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:14:05 --> Total execution time: 0.1047
DEBUG - 2022-09-06 09:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:44:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 09:44:15 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-09-06 09:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:44:29 --> Total execution time: 0.0983
DEBUG - 2022-09-06 09:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:44:33 --> Total execution time: 0.1069
DEBUG - 2022-09-06 09:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:44:33 --> Total execution time: 0.2278
DEBUG - 2022-09-06 09:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:14:39 --> Total execution time: 0.1164
DEBUG - 2022-09-06 09:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:14:54 --> Total execution time: 0.1221
DEBUG - 2022-09-06 09:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:15:05 --> Total execution time: 0.1148
DEBUG - 2022-09-06 09:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:15:09 --> Total execution time: 0.1339
DEBUG - 2022-09-06 09:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:15:18 --> Total execution time: 0.1068
DEBUG - 2022-09-06 09:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:15:18 --> Total execution time: 0.1025
DEBUG - 2022-09-06 09:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:16:12 --> Total execution time: 0.2805
DEBUG - 2022-09-06 09:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:16:15 --> Total execution time: 0.1236
DEBUG - 2022-09-06 09:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:46:15 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:16:15 --> Total execution time: 0.0747
DEBUG - 2022-09-06 09:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:16:22 --> Total execution time: 0.0960
DEBUG - 2022-09-06 09:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:16:29 --> Total execution time: 0.1154
DEBUG - 2022-09-06 09:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:16:35 --> Total execution time: 0.1906
DEBUG - 2022-09-06 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:46:38 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:16:39 --> Total execution time: 0.0678
DEBUG - 2022-09-06 09:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:16:40 --> Total execution time: 0.1380
DEBUG - 2022-09-06 09:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:46:47 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:16:47 --> Total execution time: 0.1058
DEBUG - 2022-09-06 09:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:46:53 --> Total execution time: 0.1134
DEBUG - 2022-09-06 09:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:46:55 --> Total execution time: 0.1048
DEBUG - 2022-09-06 09:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:46:56 --> Total execution time: 0.1016
DEBUG - 2022-09-06 09:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:47:19 --> Total execution time: 0.1077
DEBUG - 2022-09-06 09:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:47:22 --> Total execution time: 0.1150
DEBUG - 2022-09-06 09:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:47:22 --> Total execution time: 0.2488
DEBUG - 2022-09-06 09:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:17:34 --> Total execution time: 0.1072
DEBUG - 2022-09-06 09:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:17:44 --> Total execution time: 0.0948
DEBUG - 2022-09-06 09:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:17:44 --> Total execution time: 0.1138
DEBUG - 2022-09-06 09:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:18:00 --> Total execution time: 0.1190
DEBUG - 2022-09-06 09:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:49:09 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:19:09 --> Total execution time: 0.0697
DEBUG - 2022-09-06 09:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:19:22 --> Total execution time: 0.0717
DEBUG - 2022-09-06 09:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:19:37 --> Total execution time: 0.2728
DEBUG - 2022-09-06 09:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:05 --> Total execution time: 0.0670
DEBUG - 2022-09-06 09:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:07 --> Total execution time: 0.1712
DEBUG - 2022-09-06 09:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:11 --> Total execution time: 0.1334
DEBUG - 2022-09-06 09:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:21 --> Total execution time: 0.1381
DEBUG - 2022-09-06 09:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:21 --> Total execution time: 0.1706
DEBUG - 2022-09-06 09:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:25 --> Total execution time: 0.1298
DEBUG - 2022-09-06 09:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:25 --> Total execution time: 0.1671
DEBUG - 2022-09-06 09:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:26 --> Total execution time: 0.1652
DEBUG - 2022-09-06 09:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:27 --> Total execution time: 0.1265
DEBUG - 2022-09-06 09:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:27 --> Total execution time: 0.1349
DEBUG - 2022-09-06 09:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:28 --> Total execution time: 0.1281
DEBUG - 2022-09-06 09:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:30 --> Total execution time: 0.1008
DEBUG - 2022-09-06 09:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:30 --> Total execution time: 0.1266
DEBUG - 2022-09-06 09:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:31 --> Total execution time: 0.1316
DEBUG - 2022-09-06 09:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:59 --> Total execution time: 0.1242
DEBUG - 2022-09-06 09:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:21:33 --> Total execution time: 0.2683
DEBUG - 2022-09-06 09:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:21:41 --> Total execution time: 0.1069
DEBUG - 2022-09-06 09:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:21:50 --> Total execution time: 0.1244
DEBUG - 2022-09-06 09:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:11 --> Total execution time: 0.1121
DEBUG - 2022-09-06 09:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:16 --> Total execution time: 0.1184
DEBUG - 2022-09-06 09:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:26 --> Total execution time: 0.1178
DEBUG - 2022-09-06 09:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:34 --> Total execution time: 0.0908
DEBUG - 2022-09-06 09:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:23:22 --> Total execution time: 0.1336
DEBUG - 2022-09-06 09:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:23:31 --> Total execution time: 0.1328
DEBUG - 2022-09-06 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:24:00 --> Total execution time: 0.2649
DEBUG - 2022-09-06 09:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:24:10 --> Total execution time: 0.1094
DEBUG - 2022-09-06 09:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:24:24 --> Total execution time: 0.1414
DEBUG - 2022-09-06 09:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:24:26 --> Total execution time: 0.1043
DEBUG - 2022-09-06 09:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:54:27 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:24:27 --> Total execution time: 0.3008
DEBUG - 2022-09-06 09:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:24:38 --> Total execution time: 0.1325
DEBUG - 2022-09-06 09:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:24:39 --> Total execution time: 0.1022
DEBUG - 2022-09-06 09:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:24:53 --> Total execution time: 0.1080
DEBUG - 2022-09-06 09:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:25:10 --> Total execution time: 0.1314
DEBUG - 2022-09-06 09:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:25:19 --> Total execution time: 0.1168
DEBUG - 2022-09-06 09:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:55:23 --> Total execution time: 0.0979
DEBUG - 2022-09-06 09:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:25:28 --> Total execution time: 0.1185
DEBUG - 2022-09-06 09:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:25:34 --> Total execution time: 0.1063
DEBUG - 2022-09-06 09:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:25:38 --> Total execution time: 0.1041
DEBUG - 2022-09-06 09:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:25:44 --> Total execution time: 0.1349
DEBUG - 2022-09-06 09:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:25:49 --> Total execution time: 0.1130
DEBUG - 2022-09-06 09:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:26:05 --> Total execution time: 0.1671
DEBUG - 2022-09-06 09:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:26:11 --> Total execution time: 0.1045
DEBUG - 2022-09-06 09:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:56:21 --> No URI present. Default controller set.
DEBUG - 2022-09-06 09:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:26:21 --> Total execution time: 0.0684
DEBUG - 2022-09-06 09:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:26:24 --> Total execution time: 0.1081
DEBUG - 2022-09-06 09:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:26:35 --> Total execution time: 0.1070
DEBUG - 2022-09-06 09:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:27:46 --> Total execution time: 0.0621
DEBUG - 2022-09-06 09:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:27:56 --> Total execution time: 0.0601
DEBUG - 2022-09-06 09:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:28:04 --> Total execution time: 0.1030
DEBUG - 2022-09-06 09:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:28:13 --> Total execution time: 0.1811
DEBUG - 2022-09-06 09:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 09:58:28 --> 404 Page Not Found: Admin/.env
DEBUG - 2022-09-06 09:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:28:34 --> Total execution time: 0.1197
DEBUG - 2022-09-06 09:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:29:01 --> Total execution time: 0.1182
DEBUG - 2022-09-06 09:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:29:27 --> Total execution time: 0.1185
DEBUG - 2022-09-06 09:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 09:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 09:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 09:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:29:47 --> Total execution time: 0.1234
DEBUG - 2022-09-06 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:30:02 --> Total execution time: 0.1469
DEBUG - 2022-09-06 10:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:03:52 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:33:52 --> Total execution time: 0.1327
DEBUG - 2022-09-06 10:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:03:53 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:33:53 --> Total execution time: 0.1196
DEBUG - 2022-09-06 10:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:04:36 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:34:36 --> Total execution time: 0.0651
DEBUG - 2022-09-06 10:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:35:29 --> Total execution time: 0.0969
DEBUG - 2022-09-06 10:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:35:33 --> Total execution time: 0.0982
DEBUG - 2022-09-06 10:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:06:02 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:36:02 --> Total execution time: 0.2700
DEBUG - 2022-09-06 10:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:06:09 --> Total execution time: 0.1004
DEBUG - 2022-09-06 10:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:06:11 --> Total execution time: 0.1027
DEBUG - 2022-09-06 10:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:06:11 --> Total execution time: 0.0968
DEBUG - 2022-09-06 10:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:07:03 --> Total execution time: 0.1705
DEBUG - 2022-09-06 10:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:07:06 --> Total execution time: 0.1155
DEBUG - 2022-09-06 10:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:07:06 --> Total execution time: 0.1278
DEBUG - 2022-09-06 10:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:37:46 --> Total execution time: 0.1128
DEBUG - 2022-09-06 10:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:38:41 --> Total execution time: 0.1665
DEBUG - 2022-09-06 10:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:08:46 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:38:46 --> Total execution time: 0.0632
DEBUG - 2022-09-06 10:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:08:47 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:38:47 --> Total execution time: 0.0644
DEBUG - 2022-09-06 10:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:38:56 --> Total execution time: 0.0624
DEBUG - 2022-09-06 10:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:39:04 --> Total execution time: 0.1506
DEBUG - 2022-09-06 10:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:39:07 --> Total execution time: 0.0992
DEBUG - 2022-09-06 10:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:39:09 --> Total execution time: 0.0934
DEBUG - 2022-09-06 10:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:39:09 --> Total execution time: 0.1274
DEBUG - 2022-09-06 10:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:39:35 --> Total execution time: 0.1563
DEBUG - 2022-09-06 10:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:40:24 --> Total execution time: 0.1055
DEBUG - 2022-09-06 10:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:40:39 --> Total execution time: 0.1494
DEBUG - 2022-09-06 10:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:40:47 --> Total execution time: 0.1101
DEBUG - 2022-09-06 10:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:40:54 --> Total execution time: 0.1016
DEBUG - 2022-09-06 10:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:11:02 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:41:02 --> Total execution time: 0.1049
DEBUG - 2022-09-06 10:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:42:28 --> Total execution time: 0.0873
DEBUG - 2022-09-06 10:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:43:20 --> Total execution time: 0.1256
DEBUG - 2022-09-06 10:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:43:25 --> Total execution time: 0.2908
DEBUG - 2022-09-06 10:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:43:35 --> Total execution time: 0.1309
DEBUG - 2022-09-06 10:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:14:20 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:44:21 --> Total execution time: 0.2707
DEBUG - 2022-09-06 10:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:14:26 --> Total execution time: 0.1020
DEBUG - 2022-09-06 10:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:14:28 --> Total execution time: 0.1074
DEBUG - 2022-09-06 10:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:14:29 --> Total execution time: 0.1169
DEBUG - 2022-09-06 10:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:44:53 --> Total execution time: 2.5841
DEBUG - 2022-09-06 10:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:14:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 10:14:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 10:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:45:35 --> Total execution time: 0.1172
DEBUG - 2022-09-06 10:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:45:39 --> Total execution time: 0.2983
DEBUG - 2022-09-06 10:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:45:56 --> Total execution time: 0.1181
DEBUG - 2022-09-06 10:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:46:07 --> Total execution time: 0.1150
DEBUG - 2022-09-06 10:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:46:33 --> Total execution time: 0.1093
DEBUG - 2022-09-06 10:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:46:43 --> Total execution time: 0.1369
DEBUG - 2022-09-06 10:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:46:54 --> Total execution time: 0.0986
DEBUG - 2022-09-06 10:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:48:25 --> Total execution time: 0.0969
DEBUG - 2022-09-06 10:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:50:54 --> Total execution time: 0.1086
DEBUG - 2022-09-06 10:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:50:58 --> Total execution time: 0.1449
DEBUG - 2022-09-06 10:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:51:01 --> Total execution time: 0.3829
DEBUG - 2022-09-06 10:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:51:03 --> Total execution time: 0.1097
DEBUG - 2022-09-06 10:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:51:12 --> Total execution time: 0.1074
DEBUG - 2022-09-06 10:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:51:47 --> Total execution time: 0.1117
DEBUG - 2022-09-06 10:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:52:21 --> Total execution time: 0.1380
DEBUG - 2022-09-06 10:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:52:40 --> Total execution time: 0.1362
DEBUG - 2022-09-06 10:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:52:41 --> Total execution time: 0.1082
DEBUG - 2022-09-06 10:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:52:46 --> Total execution time: 0.1270
DEBUG - 2022-09-06 10:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:52:48 --> Total execution time: 0.1239
DEBUG - 2022-09-06 10:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:53:10 --> Total execution time: 0.1231
DEBUG - 2022-09-06 10:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:53:11 --> Total execution time: 0.2211
DEBUG - 2022-09-06 10:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:53:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-06 10:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:53:34 --> Total execution time: 0.1591
DEBUG - 2022-09-06 10:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:53:34 --> Total execution time: 0.1321
DEBUG - 2022-09-06 10:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:53:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-06 10:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:53:37 --> Total execution time: 0.1050
DEBUG - 2022-09-06 10:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:53:38 --> Total execution time: 0.1501
DEBUG - 2022-09-06 10:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:53:46 --> Total execution time: 0.1333
DEBUG - 2022-09-06 10:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:53:50 --> Total execution time: 0.1247
DEBUG - 2022-09-06 10:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:53:55 --> Total execution time: 0.1274
DEBUG - 2022-09-06 10:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:25:46 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:55:46 --> Total execution time: 0.0726
DEBUG - 2022-09-06 10:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:02:46 --> Total execution time: 0.3443
DEBUG - 2022-09-06 10:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:02:59 --> Total execution time: 0.0652
DEBUG - 2022-09-06 10:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:34:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 10:34:27 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-06 10:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:35:55 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:05:55 --> Total execution time: 0.0761
DEBUG - 2022-09-06 10:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:36:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 10:36:00 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-06 10:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:06:06 --> Total execution time: 0.0925
DEBUG - 2022-09-06 10:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:06:18 --> Total execution time: 0.0974
DEBUG - 2022-09-06 10:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:07:40 --> Total execution time: 0.0641
DEBUG - 2022-09-06 10:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:07:49 --> Total execution time: 0.0752
DEBUG - 2022-09-06 10:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:37:50 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:07:50 --> Total execution time: 0.0665
DEBUG - 2022-09-06 10:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:08:08 --> Total execution time: 0.1064
DEBUG - 2022-09-06 10:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:08:44 --> Total execution time: 0.1201
DEBUG - 2022-09-06 10:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:08:49 --> Total execution time: 0.1133
DEBUG - 2022-09-06 10:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:08:57 --> Total execution time: 0.1011
DEBUG - 2022-09-06 10:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:10:18 --> Total execution time: 0.1000
DEBUG - 2022-09-06 10:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:10:51 --> Total execution time: 0.0982
DEBUG - 2022-09-06 10:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:40:59 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:10:59 --> Total execution time: 0.0996
DEBUG - 2022-09-06 10:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:12:04 --> Total execution time: 0.1007
DEBUG - 2022-09-06 10:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:12:15 --> Total execution time: 0.1321
DEBUG - 2022-09-06 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:12:20 --> Total execution time: 0.1314
DEBUG - 2022-09-06 10:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 10:42:21 --> 404 Page Not Found: Wp-includes/ID3
DEBUG - 2022-09-06 10:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 10:42:21 --> 404 Page Not Found: Feed/index
DEBUG - 2022-09-06 10:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:13:34 --> Total execution time: 0.1080
DEBUG - 2022-09-06 10:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:14:13 --> Total execution time: 2.6561
DEBUG - 2022-09-06 10:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:14:26 --> Total execution time: 0.1041
DEBUG - 2022-09-06 10:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:14:46 --> Total execution time: 0.1299
DEBUG - 2022-09-06 10:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:15:00 --> Total execution time: 0.1198
DEBUG - 2022-09-06 10:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:15:12 --> Total execution time: 0.1093
DEBUG - 2022-09-06 10:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:15:23 --> Total execution time: 0.1085
DEBUG - 2022-09-06 10:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:15:27 --> Total execution time: 0.1183
DEBUG - 2022-09-06 10:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:15:33 --> Total execution time: 0.0974
DEBUG - 2022-09-06 10:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:48:29 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:18:29 --> Total execution time: 0.0874
DEBUG - 2022-09-06 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:49:54 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:19:54 --> Total execution time: 0.2575
DEBUG - 2022-09-06 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:49:54 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:19:54 --> Total execution time: 0.1143
DEBUG - 2022-09-06 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:50:11 --> Total execution time: 0.1099
DEBUG - 2022-09-06 10:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:50:12 --> Total execution time: 0.0991
DEBUG - 2022-09-06 10:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:50:12 --> Total execution time: 0.1032
DEBUG - 2022-09-06 10:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:20:33 --> Total execution time: 0.1004
DEBUG - 2022-09-06 10:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:20:49 --> Total execution time: 0.1274
DEBUG - 2022-09-06 10:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:20:53 --> Total execution time: 0.0951
DEBUG - 2022-09-06 10:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:20:58 --> Total execution time: 0.1228
DEBUG - 2022-09-06 10:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:51:05 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:21:05 --> Total execution time: 0.1071
DEBUG - 2022-09-06 10:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:51:15 --> Total execution time: 0.0985
DEBUG - 2022-09-06 10:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:51:18 --> Total execution time: 0.1333
DEBUG - 2022-09-06 10:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:51:18 --> Total execution time: 0.1197
DEBUG - 2022-09-06 10:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:51:26 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:21:26 --> Total execution time: 0.1014
DEBUG - 2022-09-06 10:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:21:29 --> Total execution time: 0.1141
DEBUG - 2022-09-06 10:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:21:33 --> Total execution time: 0.1024
DEBUG - 2022-09-06 10:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:51:35 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:21:35 --> Total execution time: 0.1046
DEBUG - 2022-09-06 10:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:21:41 --> Total execution time: 0.1064
DEBUG - 2022-09-06 10:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:21:51 --> Total execution time: 0.0983
DEBUG - 2022-09-06 10:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:22:05 --> Total execution time: 0.1185
DEBUG - 2022-09-06 10:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:22:14 --> Total execution time: 0.1054
DEBUG - 2022-09-06 10:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:22:16 --> Total execution time: 0.1117
DEBUG - 2022-09-06 10:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:22:39 --> Total execution time: 1.8909
DEBUG - 2022-09-06 10:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 10:52:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 10:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:53:02 --> Total execution time: 0.1562
DEBUG - 2022-09-06 10:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:23:12 --> Total execution time: 0.1124
DEBUG - 2022-09-06 10:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:53:12 --> Total execution time: 0.1495
DEBUG - 2022-09-06 10:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:23:14 --> Total execution time: 0.1104
DEBUG - 2022-09-06 10:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:23:14 --> Total execution time: 0.1028
DEBUG - 2022-09-06 10:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:23:29 --> Total execution time: 1.9275
DEBUG - 2022-09-06 10:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:23:40 --> Total execution time: 0.1113
DEBUG - 2022-09-06 10:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:23:41 --> Total execution time: 0.1458
DEBUG - 2022-09-06 10:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:23:52 --> Total execution time: 0.1861
DEBUG - 2022-09-06 10:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:23:52 --> Total execution time: 0.1069
DEBUG - 2022-09-06 10:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:23:59 --> Total execution time: 0.1365
DEBUG - 2022-09-06 10:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:54:26 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:24:26 --> Total execution time: 0.0747
DEBUG - 2022-09-06 10:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:54:29 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:24:29 --> Total execution time: 0.1021
DEBUG - 2022-09-06 10:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:24:41 --> Total execution time: 1.9791
DEBUG - 2022-09-06 10:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 10:54:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 10:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:24:54 --> Total execution time: 0.1287
DEBUG - 2022-09-06 10:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:54:55 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:24:55 --> Total execution time: 0.1070
DEBUG - 2022-09-06 21:24:56 --> Total execution time: 1.7659
DEBUG - 2022-09-06 10:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:25:18 --> Total execution time: 0.1152
DEBUG - 2022-09-06 10:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:26:26 --> Total execution time: 2.0552
DEBUG - 2022-09-06 10:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:57:53 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:27:53 --> Total execution time: 0.0665
DEBUG - 2022-09-06 10:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:57:58 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:27:58 --> Total execution time: 0.0654
DEBUG - 2022-09-06 10:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:28:04 --> Total execution time: 0.0730
DEBUG - 2022-09-06 10:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:28:06 --> Total execution time: 0.0621
DEBUG - 2022-09-06 10:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:28:17 --> Total execution time: 1.8799
DEBUG - 2022-09-06 10:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:28:22 --> Total execution time: 0.1010
DEBUG - 2022-09-06 10:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:28:31 --> Total execution time: 0.1080
DEBUG - 2022-09-06 10:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:28:32 --> Total execution time: 0.0966
DEBUG - 2022-09-06 10:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:28:33 --> Total execution time: 0.1181
DEBUG - 2022-09-06 10:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:28:43 --> Total execution time: 0.1660
DEBUG - 2022-09-06 10:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 10:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:28:58 --> Total execution time: 0.1087
DEBUG - 2022-09-06 10:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:04 --> Total execution time: 0.1440
DEBUG - 2022-09-06 10:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:06 --> Total execution time: 0.1270
DEBUG - 2022-09-06 10:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:59:11 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:11 --> Total execution time: 0.0656
DEBUG - 2022-09-06 10:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:26 --> Total execution time: 0.1007
DEBUG - 2022-09-06 10:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:28 --> Total execution time: 0.1234
DEBUG - 2022-09-06 10:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:32 --> Total execution time: 0.1059
DEBUG - 2022-09-06 10:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:36 --> Total execution time: 0.1261
DEBUG - 2022-09-06 10:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:39 --> Total execution time: 0.1049
DEBUG - 2022-09-06 10:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:46 --> Total execution time: 0.0975
DEBUG - 2022-09-06 10:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:59:48 --> No URI present. Default controller set.
DEBUG - 2022-09-06 10:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:48 --> Total execution time: 0.0973
DEBUG - 2022-09-06 10:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:50 --> Total execution time: 0.1085
DEBUG - 2022-09-06 10:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 10:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 10:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:51 --> Total execution time: 0.1165
DEBUG - 2022-09-06 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:02 --> Total execution time: 0.0663
DEBUG - 2022-09-06 11:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:03 --> Total execution time: 0.0731
DEBUG - 2022-09-06 11:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:06 --> Total execution time: 0.2309
DEBUG - 2022-09-06 11:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:15 --> Total execution time: 0.1317
DEBUG - 2022-09-06 11:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:20 --> Total execution time: 0.1168
DEBUG - 2022-09-06 11:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:22 --> Total execution time: 0.1079
DEBUG - 2022-09-06 11:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:24 --> Total execution time: 1.8072
DEBUG - 2022-09-06 11:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:48 --> Total execution time: 0.1267
DEBUG - 2022-09-06 11:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:54 --> Total execution time: 0.0971
DEBUG - 2022-09-06 11:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:56 --> Total execution time: 0.1083
DEBUG - 2022-09-06 11:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:56 --> Total execution time: 0.1127
DEBUG - 2022-09-06 11:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:00 --> Total execution time: 0.1000
DEBUG - 2022-09-06 11:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:03 --> Total execution time: 0.0987
DEBUG - 2022-09-06 11:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:04 --> Total execution time: 0.1071
DEBUG - 2022-09-06 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:09 --> Total execution time: 0.1289
DEBUG - 2022-09-06 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:01:11 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:11 --> Total execution time: 0.0710
DEBUG - 2022-09-06 11:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:17 --> Total execution time: 0.1100
DEBUG - 2022-09-06 11:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:17 --> Total execution time: 0.0992
DEBUG - 2022-09-06 11:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:20 --> Total execution time: 0.1064
DEBUG - 2022-09-06 11:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:23 --> Total execution time: 0.2851
DEBUG - 2022-09-06 11:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:24 --> Total execution time: 0.1015
DEBUG - 2022-09-06 11:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:24 --> Total execution time: 0.1064
DEBUG - 2022-09-06 11:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:29 --> Total execution time: 0.0972
DEBUG - 2022-09-06 11:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:35 --> Total execution time: 0.1098
DEBUG - 2022-09-06 11:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:04:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 11:04:50 --> 404 Page Not Found: Wp-json/wp
DEBUG - 2022-09-06 11:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:04:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 11:04:51 --> 404 Page Not Found: Wp-json/wp
DEBUG - 2022-09-06 11:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:04:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 11:04:53 --> 404 Page Not Found: Wp-json/wp
DEBUG - 2022-09-06 11:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:35:10 --> Total execution time: 0.3433
DEBUG - 2022-09-06 11:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:35:25 --> Total execution time: 0.0751
DEBUG - 2022-09-06 11:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:07:01 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:37:01 --> Total execution time: 0.1341
DEBUG - 2022-09-06 11:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:07:40 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:37:40 --> Total execution time: 0.1019
DEBUG - 2022-09-06 11:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:38:22 --> Total execution time: 0.0686
DEBUG - 2022-09-06 11:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:38:34 --> Total execution time: 0.1022
DEBUG - 2022-09-06 11:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:08:41 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:38:41 --> Total execution time: 0.2828
DEBUG - 2022-09-06 11:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:38:58 --> Total execution time: 0.0715
DEBUG - 2022-09-06 11:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:39:36 --> Total execution time: 0.1061
DEBUG - 2022-09-06 11:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:10:01 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:40:01 --> Total execution time: 0.1162
DEBUG - 2022-09-06 11:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:40:36 --> Total execution time: 0.1306
DEBUG - 2022-09-06 11:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:10:37 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:40:37 --> Total execution time: 0.0673
DEBUG - 2022-09-06 11:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:40:42 --> Total execution time: 0.1171
DEBUG - 2022-09-06 11:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:41:39 --> Total execution time: 0.1338
DEBUG - 2022-09-06 11:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:41:48 --> Total execution time: 0.1104
DEBUG - 2022-09-06 11:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:41:59 --> Total execution time: 0.1299
DEBUG - 2022-09-06 11:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:42:02 --> Total execution time: 0.1423
DEBUG - 2022-09-06 11:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:42:09 --> Total execution time: 0.2735
DEBUG - 2022-09-06 21:42:09 --> Total execution time: 0.1279
DEBUG - 2022-09-06 11:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:42:11 --> Total execution time: 0.1389
DEBUG - 2022-09-06 11:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:42:16 --> Total execution time: 0.1404
DEBUG - 2022-09-06 11:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:42:19 --> Total execution time: 0.1469
DEBUG - 2022-09-06 11:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:42:20 --> Total execution time: 0.1057
DEBUG - 2022-09-06 11:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:42:23 --> Total execution time: 0.1522
DEBUG - 2022-09-06 11:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:42:52 --> Total execution time: 0.1043
DEBUG - 2022-09-06 11:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:42:57 --> Total execution time: 0.1404
DEBUG - 2022-09-06 11:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:01 --> Total execution time: 0.1321
DEBUG - 2022-09-06 11:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:05 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:05 --> Total execution time: 0.1382
DEBUG - 2022-09-06 11:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:06 --> Total execution time: 0.0807
DEBUG - 2022-09-06 11:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:07 --> Total execution time: 0.3067
DEBUG - 2022-09-06 11:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:12 --> Total execution time: 0.0898
DEBUG - 2022-09-06 11:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:20 --> Total execution time: 0.1035
DEBUG - 2022-09-06 11:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:24 --> Total execution time: 0.1202
DEBUG - 2022-09-06 11:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:27 --> Total execution time: 0.1392
DEBUG - 2022-09-06 11:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:33 --> Total execution time: 0.2768
DEBUG - 2022-09-06 11:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:40 --> Total execution time: 0.0989
DEBUG - 2022-09-06 11:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:43 --> Total execution time: 0.1182
DEBUG - 2022-09-06 11:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:47 --> Total execution time: 0.1017
DEBUG - 2022-09-06 11:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:50 --> Total execution time: 0.2915
DEBUG - 2022-09-06 11:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:55 --> Total execution time: 0.0965
DEBUG - 2022-09-06 11:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:43:58 --> Total execution time: 0.1131
DEBUG - 2022-09-06 11:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:44:01 --> Total execution time: 0.1346
DEBUG - 2022-09-06 11:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:44:10 --> Total execution time: 0.1225
DEBUG - 2022-09-06 11:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:14:11 --> Total execution time: 0.0965
DEBUG - 2022-09-06 11:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:44:12 --> Total execution time: 0.0982
DEBUG - 2022-09-06 11:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:14:13 --> Total execution time: 0.0974
DEBUG - 2022-09-06 11:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:14:13 --> Total execution time: 0.0968
DEBUG - 2022-09-06 11:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:13 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:44:14 --> Total execution time: 0.0674
DEBUG - 2022-09-06 11:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:44:21 --> Total execution time: 0.0915
DEBUG - 2022-09-06 11:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:14:30 --> Total execution time: 0.1002
DEBUG - 2022-09-06 11:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:44:32 --> Total execution time: 0.1140
DEBUG - 2022-09-06 11:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:14:36 --> Total execution time: 0.0922
DEBUG - 2022-09-06 11:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:44:39 --> Total execution time: 0.0983
DEBUG - 2022-09-06 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:14:42 --> Total execution time: 0.0947
DEBUG - 2022-09-06 11:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:44:43 --> Total execution time: 0.0988
DEBUG - 2022-09-06 11:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:14:46 --> Total execution time: 0.1032
DEBUG - 2022-09-06 11:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:44:52 --> Total execution time: 0.0922
DEBUG - 2022-09-06 11:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:15:06 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:45:06 --> Total execution time: 0.1018
DEBUG - 2022-09-06 11:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:45:12 --> Total execution time: 0.1021
DEBUG - 2022-09-06 11:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:15:13 --> Total execution time: 0.1145
DEBUG - 2022-09-06 11:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:15:15 --> Total execution time: 0.1270
DEBUG - 2022-09-06 11:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:15:15 --> Total execution time: 0.1028
DEBUG - 2022-09-06 11:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:45:33 --> Total execution time: 0.1529
DEBUG - 2022-09-06 11:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:15:42 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:45:43 --> Total execution time: 0.2645
DEBUG - 2022-09-06 11:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:45:47 --> Total execution time: 0.1241
DEBUG - 2022-09-06 11:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:46:00 --> Total execution time: 0.1039
DEBUG - 2022-09-06 11:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:47:08 --> Total execution time: 0.1142
DEBUG - 2022-09-06 11:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:47:10 --> Total execution time: 0.2675
DEBUG - 2022-09-06 11:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:47:52 --> Total execution time: 0.1152
DEBUG - 2022-09-06 11:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:18:09 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:48:10 --> Total execution time: 0.2576
DEBUG - 2022-09-06 11:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:48:15 --> Total execution time: 0.0608
DEBUG - 2022-09-06 11:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:48:19 --> Total execution time: 0.0633
DEBUG - 2022-09-06 11:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:48:24 --> Total execution time: 0.0967
DEBUG - 2022-09-06 11:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:48:48 --> Total execution time: 0.1212
DEBUG - 2022-09-06 11:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:49:14 --> Total execution time: 0.1031
DEBUG - 2022-09-06 11:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:49:32 --> Total execution time: 0.1075
DEBUG - 2022-09-06 11:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:49:39 --> Total execution time: 0.1158
DEBUG - 2022-09-06 11:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:49:43 --> Total execution time: 0.1326
DEBUG - 2022-09-06 11:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:49:49 --> Total execution time: 0.1110
DEBUG - 2022-09-06 11:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:49:55 --> Total execution time: 0.3071
DEBUG - 2022-09-06 11:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:52:17 --> Total execution time: 0.1897
DEBUG - 2022-09-06 11:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:22:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:22:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:52:30 --> Total execution time: 0.0741
DEBUG - 2022-09-06 11:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:52:30 --> Total execution time: 0.0758
DEBUG - 2022-09-06 11:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:52:36 --> Total execution time: 0.0652
DEBUG - 2022-09-06 11:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:52:52 --> Total execution time: 0.1208
DEBUG - 2022-09-06 11:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:23:53 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:53:53 --> Total execution time: 0.0693
DEBUG - 2022-09-06 11:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:23:59 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:53:59 --> Total execution time: 0.1148
DEBUG - 2022-09-06 11:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:25:58 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:55:59 --> Total execution time: 0.0663
DEBUG - 2022-09-06 11:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:56:09 --> Total execution time: 0.0718
DEBUG - 2022-09-06 11:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:27:29 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:57:29 --> Total execution time: 0.0727
DEBUG - 2022-09-06 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:27:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:57:30 --> Total execution time: 0.0705
DEBUG - 2022-09-06 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:27:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:27:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:57:30 --> Total execution time: 0.0650
DEBUG - 2022-09-06 11:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:57:30 --> Total execution time: 0.0735
DEBUG - 2022-09-06 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 11:27:30 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-06 11:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 11:27:31 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-06 11:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:27:32 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:27:32 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:57:32 --> Total execution time: 0.0794
DEBUG - 2022-09-06 21:57:32 --> Total execution time: 0.0675
DEBUG - 2022-09-06 11:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:58:21 --> Total execution time: 0.1088
DEBUG - 2022-09-06 11:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:58:25 --> Total execution time: 0.0973
DEBUG - 2022-09-06 11:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:58:30 --> Total execution time: 0.1017
DEBUG - 2022-09-06 11:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:58:36 --> Total execution time: 0.1111
DEBUG - 2022-09-06 11:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:29:36 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:59:36 --> Total execution time: 0.0669
DEBUG - 2022-09-06 11:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:30:26 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:00:27 --> Total execution time: 0.0675
DEBUG - 2022-09-06 11:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:30:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 11:30:59 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-06 11:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:01:16 --> Total execution time: 0.2516
DEBUG - 2022-09-06 11:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 11:31:20 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-06 11:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 11:31:24 --> 404 Page Not Found: Event/september-undergraduate-open-house-2
DEBUG - 2022-09-06 11:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 11:31:27 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-06 11:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:01:36 --> Total execution time: 0.0984
DEBUG - 2022-09-06 11:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:01:42 --> Total execution time: 0.1009
DEBUG - 2022-09-06 11:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:01:46 --> Total execution time: 0.1283
DEBUG - 2022-09-06 11:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:02:04 --> Total execution time: 0.1379
DEBUG - 2022-09-06 11:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:32:05 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:02:06 --> Total execution time: 0.0950
DEBUG - 2022-09-06 11:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:03:03 --> Total execution time: 0.2779
DEBUG - 2022-09-06 11:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:03:27 --> Total execution time: 0.1082
DEBUG - 2022-09-06 11:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:33:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:03:30 --> Total execution time: 0.2992
DEBUG - 2022-09-06 11:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:03:32 --> Total execution time: 0.1137
DEBUG - 2022-09-06 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:09:45 --> Total execution time: 0.3785
DEBUG - 2022-09-06 11:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:09:54 --> Total execution time: 0.1147
DEBUG - 2022-09-06 11:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:40:03 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:10:03 --> Total execution time: 0.1306
DEBUG - 2022-09-06 11:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:40:04 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:10:04 --> Total execution time: 0.0636
DEBUG - 2022-09-06 11:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:10:11 --> Total execution time: 0.0617
DEBUG - 2022-09-06 11:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:10:29 --> Total execution time: 0.1288
DEBUG - 2022-09-06 11:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:10:48 --> Total execution time: 0.1026
DEBUG - 2022-09-06 11:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:10:56 --> Total execution time: 0.1301
DEBUG - 2022-09-06 11:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:11:02 --> Total execution time: 0.2127
DEBUG - 2022-09-06 11:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:11:43 --> Total execution time: 0.0969
DEBUG - 2022-09-06 11:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:12:10 --> Total execution time: 0.0930
DEBUG - 2022-09-06 11:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:12:13 --> Total execution time: 0.2578
DEBUG - 2022-09-06 11:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:12:18 --> Total execution time: 0.1203
DEBUG - 2022-09-06 11:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:12:18 --> Total execution time: 0.0981
DEBUG - 2022-09-06 11:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:12:25 --> Total execution time: 0.1182
DEBUG - 2022-09-06 11:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:43:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 11:43:58 --> 404 Page Not Found: Blog/esalestrix.in
DEBUG - 2022-09-06 11:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:14:02 --> Total execution time: 0.2708
DEBUG - 2022-09-06 11:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:44:13 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:14:13 --> Total execution time: 0.0646
DEBUG - 2022-09-06 11:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:45:26 --> Total execution time: 0.1082
DEBUG - 2022-09-06 11:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:45:29 --> Total execution time: 0.1041
DEBUG - 2022-09-06 11:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 11:45:29 --> Total execution time: 0.0919
DEBUG - 2022-09-06 11:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:21:31 --> Total execution time: 0.1848
DEBUG - 2022-09-06 11:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:56:23 --> No URI present. Default controller set.
DEBUG - 2022-09-06 11:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:26:23 --> Total execution time: 0.1437
DEBUG - 2022-09-06 11:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:27:13 --> Total execution time: 0.0771
DEBUG - 2022-09-06 11:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 11:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 11:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:27:14 --> Total execution time: 0.1003
DEBUG - 2022-09-06 12:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:30:02 --> Total execution time: 0.0895
DEBUG - 2022-09-06 12:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:31:32 --> Total execution time: 0.1206
DEBUG - 2022-09-06 12:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:31:46 --> Total execution time: 0.1152
DEBUG - 2022-09-06 12:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:32:48 --> Total execution time: 0.1014
DEBUG - 2022-09-06 12:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:33:26 --> Total execution time: 0.0813
DEBUG - 2022-09-06 12:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:04:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 12:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:34:30 --> Total execution time: 0.2647
DEBUG - 2022-09-06 12:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:35:48 --> Total execution time: 0.2663
DEBUG - 2022-09-06 12:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:35:56 --> Total execution time: 0.1027
DEBUG - 2022-09-06 12:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:35:59 --> Total execution time: 0.0896
DEBUG - 2022-09-06 12:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:36:41 --> Total execution time: 0.1174
DEBUG - 2022-09-06 12:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:08 --> Total execution time: 0.0983
DEBUG - 2022-09-06 12:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:39:59 --> Total execution time: 0.2101
DEBUG - 2022-09-06 12:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:40:04 --> Total execution time: 0.1136
DEBUG - 2022-09-06 12:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:40:09 --> Total execution time: 0.0635
DEBUG - 2022-09-06 12:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:40:12 --> Total execution time: 0.1140
DEBUG - 2022-09-06 12:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:40:23 --> Total execution time: 0.1029
DEBUG - 2022-09-06 12:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:40:32 --> Total execution time: 0.1047
DEBUG - 2022-09-06 12:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:40:48 --> Total execution time: 0.1010
DEBUG - 2022-09-06 12:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:41:09 --> Total execution time: 0.2760
DEBUG - 2022-09-06 12:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:41:22 --> Total execution time: 0.1010
DEBUG - 2022-09-06 12:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:41:24 --> Total execution time: 0.1084
DEBUG - 2022-09-06 12:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:41:28 --> Total execution time: 0.0963
DEBUG - 2022-09-06 12:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:41:29 --> Total execution time: 0.1189
DEBUG - 2022-09-06 12:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:41:32 --> Total execution time: 0.1021
DEBUG - 2022-09-06 12:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:41:39 --> Total execution time: 0.1088
DEBUG - 2022-09-06 12:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:41:49 --> Total execution time: 0.1361
DEBUG - 2022-09-06 12:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:41:53 --> Total execution time: 0.1093
DEBUG - 2022-09-06 12:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:42:07 --> Total execution time: 0.1663
DEBUG - 2022-09-06 12:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:42:40 --> Total execution time: 0.0961
DEBUG - 2022-09-06 12:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:43:17 --> Total execution time: 0.0726
DEBUG - 2022-09-06 12:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:47:03 --> Total execution time: 0.3597
DEBUG - 2022-09-06 12:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:47:14 --> Total execution time: 0.1077
DEBUG - 2022-09-06 12:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:17:33 --> No URI present. Default controller set.
DEBUG - 2022-09-06 12:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:47:33 --> Total execution time: 0.0689
DEBUG - 2022-09-06 12:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:47:41 --> Total execution time: 0.1009
DEBUG - 2022-09-06 12:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:47:47 --> Total execution time: 0.1023
DEBUG - 2022-09-06 12:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:47:53 --> Total execution time: 0.1099
DEBUG - 2022-09-06 12:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:47:57 --> Total execution time: 0.1108
DEBUG - 2022-09-06 12:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:48:30 --> Total execution time: 0.0964
DEBUG - 2022-09-06 12:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:48:43 --> Total execution time: 0.1134
DEBUG - 2022-09-06 12:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:49:43 --> Total execution time: 0.2698
DEBUG - 2022-09-06 12:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:49:45 --> Total execution time: 0.2639
DEBUG - 2022-09-06 12:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:07 --> Total execution time: 0.1044
DEBUG - 2022-09-06 12:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:11 --> Total execution time: 0.1037
DEBUG - 2022-09-06 12:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:11 --> Total execution time: 0.1026
DEBUG - 2022-09-06 12:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:19 --> Total execution time: 0.0914
DEBUG - 2022-09-06 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:21 --> Total execution time: 0.1060
DEBUG - 2022-09-06 12:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:27 --> Total execution time: 0.0996
DEBUG - 2022-09-06 12:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:31 --> Total execution time: 0.0960
DEBUG - 2022-09-06 12:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:35 --> Total execution time: 0.1258
DEBUG - 2022-09-06 12:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:53:27 --> Total execution time: 0.1029
DEBUG - 2022-09-06 12:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:53:45 --> Total execution time: 0.1002
DEBUG - 2022-09-06 12:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:53:54 --> Total execution time: 0.1321
DEBUG - 2022-09-06 12:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:53:59 --> Total execution time: 0.1045
DEBUG - 2022-09-06 12:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:03 --> Total execution time: 0.1414
DEBUG - 2022-09-06 12:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:24:23 --> No URI present. Default controller set.
DEBUG - 2022-09-06 12:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:23 --> Total execution time: 0.0646
DEBUG - 2022-09-06 12:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:32 --> Total execution time: 0.1191
DEBUG - 2022-09-06 12:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:36 --> Total execution time: 0.0978
DEBUG - 2022-09-06 12:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:52 --> Total execution time: 0.1019
DEBUG - 2022-09-06 12:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:24:56 --> No URI present. Default controller set.
DEBUG - 2022-09-06 12:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:56 --> Total execution time: 0.1064
DEBUG - 2022-09-06 12:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:58 --> Total execution time: 0.0864
DEBUG - 2022-09-06 12:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:25:07 --> No URI present. Default controller set.
DEBUG - 2022-09-06 12:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:55:08 --> Total execution time: 0.2769
DEBUG - 2022-09-06 12:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 12:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:56:32 --> Total execution time: 0.1089
DEBUG - 2022-09-06 12:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:56:47 --> Total execution time: 0.1018
DEBUG - 2022-09-06 12:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:21 --> Total execution time: 0.1318
DEBUG - 2022-09-06 12:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:43 --> Total execution time: 0.1149
DEBUG - 2022-09-06 12:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:56 --> Total execution time: 0.1075
DEBUG - 2022-09-06 12:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:05:27 --> Total execution time: 0.3663
DEBUG - 2022-09-06 12:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:05:35 --> Total execution time: 0.1868
DEBUG - 2022-09-06 12:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:05:35 --> Total execution time: 0.2901
DEBUG - 2022-09-06 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:05:52 --> Total execution time: 0.1055
DEBUG - 2022-09-06 12:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:05:57 --> Total execution time: 0.1066
DEBUG - 2022-09-06 12:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:38:47 --> No URI present. Default controller set.
DEBUG - 2022-09-06 12:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:08:47 --> Total execution time: 0.1471
DEBUG - 2022-09-06 12:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:39:26 --> No URI present. Default controller set.
DEBUG - 2022-09-06 12:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:09:26 --> Total execution time: 0.1151
DEBUG - 2022-09-06 12:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:39:28 --> No URI present. Default controller set.
DEBUG - 2022-09-06 12:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:09:28 --> Total execution time: 0.0775
DEBUG - 2022-09-06 12:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:40:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 12:40:59 --> 404 Page Not Found: Plugins/filemanager
DEBUG - 2022-09-06 12:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:41:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 12:41:00 --> 404 Page Not Found: Assets/plugins
DEBUG - 2022-09-06 12:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:14:23 --> Total execution time: 0.3432
DEBUG - 2022-09-06 12:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:18:13 --> Total execution time: 0.1515
DEBUG - 2022-09-06 12:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:18:26 --> Total execution time: 0.1021
DEBUG - 2022-09-06 12:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:18:35 --> Total execution time: 0.1131
DEBUG - 2022-09-06 12:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:18:44 --> Total execution time: 0.0974
DEBUG - 2022-09-06 12:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:18:54 --> Total execution time: 0.0992
DEBUG - 2022-09-06 12:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:19:13 --> Total execution time: 0.0954
DEBUG - 2022-09-06 12:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:20:10 --> Total execution time: 0.1053
DEBUG - 2022-09-06 12:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:20:20 --> Total execution time: 0.0910
DEBUG - 2022-09-06 12:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:20:32 --> Total execution time: 0.1078
DEBUG - 2022-09-06 12:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:20:41 --> Total execution time: 0.1032
DEBUG - 2022-09-06 12:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:20:50 --> Total execution time: 0.1159
DEBUG - 2022-09-06 12:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:21:46 --> Total execution time: 0.0999
DEBUG - 2022-09-06 12:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:22:14 --> Total execution time: 0.1017
DEBUG - 2022-09-06 12:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:22:24 --> Total execution time: 0.0953
DEBUG - 2022-09-06 12:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:22:34 --> Total execution time: 0.0981
DEBUG - 2022-09-06 12:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:23:22 --> Total execution time: 0.2807
DEBUG - 2022-09-06 12:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 12:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 12:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:29:10 --> Total execution time: 0.3259
DEBUG - 2022-09-06 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:30:02 --> Total execution time: 0.1003
DEBUG - 2022-09-06 13:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:01:12 --> No URI present. Default controller set.
DEBUG - 2022-09-06 13:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:31:12 --> Total execution time: 0.0688
DEBUG - 2022-09-06 13:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:02:07 --> No URI present. Default controller set.
DEBUG - 2022-09-06 13:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:32:07 --> Total execution time: 0.0643
DEBUG - 2022-09-06 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:38:38 --> Total execution time: 0.3432
DEBUG - 2022-09-06 13:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:38:44 --> Total execution time: 0.1204
DEBUG - 2022-09-06 13:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:41:45 --> Total execution time: 0.0997
DEBUG - 2022-09-06 13:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:17:40 --> No URI present. Default controller set.
DEBUG - 2022-09-06 13:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:47:41 --> Total execution time: 0.3450
DEBUG - 2022-09-06 13:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:48:17 --> Total execution time: 0.0980
DEBUG - 2022-09-06 13:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:18:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 13:18:33 --> 404 Page Not Found: Membership-account/membership-checkout
DEBUG - 2022-09-06 13:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:48:33 --> Total execution time: 0.0980
DEBUG - 2022-09-06 13:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:48:38 --> Total execution time: 0.1051
DEBUG - 2022-09-06 13:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:51:32 --> Total execution time: 0.3761
DEBUG - 2022-09-06 13:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:53:46 --> Total execution time: 0.3505
DEBUG - 2022-09-06 13:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:23:59 --> No URI present. Default controller set.
DEBUG - 2022-09-06 13:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:53:59 --> Total execution time: 0.0816
DEBUG - 2022-09-06 13:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:54:49 --> Total execution time: 0.1098
DEBUG - 2022-09-06 13:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:25:36 --> No URI present. Default controller set.
DEBUG - 2022-09-06 13:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:55:36 --> Total execution time: 0.2576
DEBUG - 2022-09-06 13:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:55:42 --> Total execution time: 0.0970
DEBUG - 2022-09-06 13:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:55:46 --> Total execution time: 0.1122
DEBUG - 2022-09-06 13:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:55:47 --> Total execution time: 0.1053
DEBUG - 2022-09-06 13:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:55:50 --> Total execution time: 0.1316
DEBUG - 2022-09-06 13:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:55:51 --> Total execution time: 0.1075
DEBUG - 2022-09-06 13:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:55:55 --> Total execution time: 0.1364
DEBUG - 2022-09-06 13:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:56:03 --> Total execution time: 0.1199
DEBUG - 2022-09-06 13:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:56:12 --> Total execution time: 0.0987
DEBUG - 2022-09-06 13:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:56:29 --> Total execution time: 0.1354
DEBUG - 2022-09-06 13:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:26:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 13:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:56:30 --> Total execution time: 0.0636
DEBUG - 2022-09-06 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:33:55 --> No URI present. Default controller set.
DEBUG - 2022-09-06 13:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 13:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 13:59:51 --> No URI present. Default controller set.
DEBUG - 2022-09-06 13:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 13:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:04:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 14:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 14:07:04 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-09-06 14:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 14:35:51 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-09-06 14:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:35:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 14:35:52 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-09-06 14:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 14:39:18 --> 404 Page Not Found: Wp-content/index
DEBUG - 2022-09-06 14:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:48:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 14:48:42 --> 404 Page Not Found: Teacher/harry-j-bryant
DEBUG - 2022-09-06 14:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:58:05 --> No URI present. Default controller set.
DEBUG - 2022-09-06 14:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 14:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 14:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 14:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:05:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 15:05:53 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-09-06 15:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:06:38 --> No URI present. Default controller set.
DEBUG - 2022-09-06 15:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:14:57 --> No URI present. Default controller set.
DEBUG - 2022-09-06 15:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:15:15 --> No URI present. Default controller set.
DEBUG - 2022-09-06 15:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:15:16 --> No URI present. Default controller set.
DEBUG - 2022-09-06 15:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:15:37 --> No URI present. Default controller set.
DEBUG - 2022-09-06 15:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:38 --> Total execution time: 0.1026
DEBUG - 2022-09-06 15:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:39 --> Total execution time: 0.1045
DEBUG - 2022-09-06 15:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:40 --> Total execution time: 0.0957
DEBUG - 2022-09-06 15:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:53 --> Total execution time: 0.1113
DEBUG - 2022-09-06 15:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:15:59 --> Total execution time: 0.0981
DEBUG - 2022-09-06 15:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:16:10 --> No URI present. Default controller set.
DEBUG - 2022-09-06 15:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:52:54 --> No URI present. Default controller set.
DEBUG - 2022-09-06 15:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 15:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 15:52:57 --> No URI present. Default controller set.
DEBUG - 2022-09-06 15:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 15:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 16:06:35 --> No URI present. Default controller set.
DEBUG - 2022-09-06 16:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 16:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 16:18:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 16:18:34 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-09-06 16:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 16:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 16:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 16:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 16:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 16:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 16:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 16:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 16:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 16:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 16:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 16:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 16:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 16:40:49 --> No URI present. Default controller set.
DEBUG - 2022-09-06 16:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 16:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 16:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 16:43:11 --> No URI present. Default controller set.
DEBUG - 2022-09-06 16:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 16:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 17:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 17:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 17:10:55 --> No URI present. Default controller set.
DEBUG - 2022-09-06 17:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 17:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 17:12:55 --> No URI present. Default controller set.
DEBUG - 2022-09-06 17:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 17:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 17:13:42 --> No URI present. Default controller set.
DEBUG - 2022-09-06 17:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 17:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 17:29:01 --> No URI present. Default controller set.
DEBUG - 2022-09-06 17:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 17:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 17:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 17:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 17:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 17:50:25 --> No URI present. Default controller set.
DEBUG - 2022-09-06 17:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 17:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 18:01:06 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-09-06 18:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:19:16 --> No URI present. Default controller set.
DEBUG - 2022-09-06 18:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 18:26:56 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-09-06 18:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:59:28 --> No URI present. Default controller set.
DEBUG - 2022-09-06 18:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:59:29 --> No URI present. Default controller set.
DEBUG - 2022-09-06 18:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 18:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 18:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 18:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 19:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 19:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 19:02:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 19:02:39 --> 404 Page Not Found: Refund/index
DEBUG - 2022-09-06 19:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 19:07:17 --> No URI present. Default controller set.
DEBUG - 2022-09-06 19:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 19:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 19:08:05 --> No URI present. Default controller set.
DEBUG - 2022-09-06 19:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 19:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 19:09:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 19:09:43 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-06 19:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 19:09:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 19:09:43 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-09-06 19:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 19:12:41 --> No URI present. Default controller set.
DEBUG - 2022-09-06 19:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 19:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 19:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 19:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 19:20:41 --> No URI present. Default controller set.
DEBUG - 2022-09-06 19:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 19:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 19:24:37 --> No URI present. Default controller set.
DEBUG - 2022-09-06 19:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 19:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 19:36:32 --> No URI present. Default controller set.
DEBUG - 2022-09-06 19:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 19:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 19:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 19:50:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 19:50:15 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-09-06 20:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:08:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 20:08:33 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-06 20:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:08:34 --> No URI present. Default controller set.
DEBUG - 2022-09-06 20:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:12:56 --> No URI present. Default controller set.
DEBUG - 2022-09-06 20:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:15:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 20:15:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-06 20:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:15:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 20:15:35 --> 404 Page Not Found: Contact/index
DEBUG - 2022-09-06 20:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:18:19 --> No URI present. Default controller set.
DEBUG - 2022-09-06 20:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:19:26 --> Total execution time: 0.0990
DEBUG - 2022-09-06 20:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:19:35 --> Total execution time: 0.1014
DEBUG - 2022-09-06 20:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:19:36 --> Total execution time: 0.2401
DEBUG - 2022-09-06 20:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:23:44 --> Total execution time: 0.1096
DEBUG - 2022-09-06 20:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:23:50 --> Total execution time: 0.1476
DEBUG - 2022-09-06 20:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:26:09 --> Total execution time: 0.1151
DEBUG - 2022-09-06 20:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:26:18 --> Total execution time: 0.0981
DEBUG - 2022-09-06 20:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:26:27 --> Total execution time: 0.1208
DEBUG - 2022-09-06 20:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 20:36:15 --> 404 Page Not Found: Assets/images
DEBUG - 2022-09-06 20:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:41:57 --> No URI present. Default controller set.
DEBUG - 2022-09-06 20:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:41:59 --> No URI present. Default controller set.
DEBUG - 2022-09-06 20:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:43:00 --> Total execution time: 0.0732
DEBUG - 2022-09-06 20:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:43:03 --> Total execution time: 0.1005
DEBUG - 2022-09-06 20:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:43:03 --> Total execution time: 0.2230
DEBUG - 2022-09-06 20:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:43:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 20:43:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 20:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:47:22 --> No URI present. Default controller set.
DEBUG - 2022-09-06 20:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:54:45 --> Total execution time: 0.0961
DEBUG - 2022-09-06 20:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 20:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 20:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 20:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 21:02:46 --> 404 Page Not Found: Category/programming-languages
DEBUG - 2022-09-06 21:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:09:56 --> No URI present. Default controller set.
DEBUG - 2022-09-06 21:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 21:11:16 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-09-06 21:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:22:22 --> No URI present. Default controller set.
DEBUG - 2022-09-06 21:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:23:06 --> Total execution time: 0.0699
DEBUG - 2022-09-06 21:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:23:09 --> Total execution time: 0.1441
DEBUG - 2022-09-06 21:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:23:09 --> Total execution time: 0.1245
DEBUG - 2022-09-06 21:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:24:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 21:24:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 21:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:28:59 --> Total execution time: 0.3555
DEBUG - 2022-09-06 21:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:07 --> Total execution time: 0.1061
DEBUG - 2022-09-06 21:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:14 --> Total execution time: 0.1053
DEBUG - 2022-09-06 21:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:30 --> Total execution time: 0.1003
DEBUG - 2022-09-06 21:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:31 --> Total execution time: 0.1100
DEBUG - 2022-09-06 21:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:50 --> Total execution time: 0.1140
DEBUG - 2022-09-06 21:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:54 --> Total execution time: 0.0980
DEBUG - 2022-09-06 21:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:29:55 --> Total execution time: 0.1046
DEBUG - 2022-09-06 21:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:01 --> Total execution time: 0.2142
DEBUG - 2022-09-06 21:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:02 --> Total execution time: 0.1205
DEBUG - 2022-09-06 21:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:02 --> Total execution time: 0.1476
DEBUG - 2022-09-06 21:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:31:11 --> No URI present. Default controller set.
DEBUG - 2022-09-06 21:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:32:41 --> No URI present. Default controller set.
DEBUG - 2022-09-06 21:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:35:24 --> Total execution time: 0.1074
DEBUG - 2022-09-06 21:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:35:34 --> Total execution time: 0.1507
DEBUG - 2022-09-06 21:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:35:52 --> No URI present. Default controller set.
DEBUG - 2022-09-06 21:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:39:06 --> Total execution time: 0.1075
DEBUG - 2022-09-06 21:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:39:08 --> Total execution time: 0.1021
DEBUG - 2022-09-06 21:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:39:09 --> Total execution time: 0.0964
DEBUG - 2022-09-06 21:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:39:16 --> Total execution time: 0.1086
DEBUG - 2022-09-06 21:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:39:28 --> Total execution time: 0.1007
DEBUG - 2022-09-06 21:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:39:40 --> Total execution time: 0.1198
DEBUG - 2022-09-06 21:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 21:54:06 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-09-06 21:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:07 --> No URI present. Default controller set.
DEBUG - 2022-09-06 21:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:56:02 --> Total execution time: 0.1108
DEBUG - 2022-09-06 21:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:56:09 --> Total execution time: 0.1586
DEBUG - 2022-09-06 21:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:59:19 --> Total execution time: 0.1269
DEBUG - 2022-09-06 21:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:59:47 --> No URI present. Default controller set.
DEBUG - 2022-09-06 21:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 21:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 21:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 21:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:00:13 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:00:25 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:10:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 22:10:13 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-09-06 22:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:11:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 22:11:12 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-09-06 22:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 22:12:15 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-09-06 22:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:14:09 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:15:16 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:30:10 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:35:37 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:35:38 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:36:43 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:36:55 --> Total execution time: 0.0973
DEBUG - 2022-09-06 22:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:36:57 --> Total execution time: 0.1290
DEBUG - 2022-09-06 22:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:36:58 --> Total execution time: 0.1050
DEBUG - 2022-09-06 22:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:24 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:37 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:38 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:38 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:38 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:39 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:39 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:39:03 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:46:01 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:52:01 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:52:25 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:52:32 --> Total execution time: 0.1129
DEBUG - 2022-09-06 22:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:52:39 --> Total execution time: 0.1468
DEBUG - 2022-09-06 22:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:52:47 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:52:47 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:52:48 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:52:48 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:52:49 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:52:49 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:56:25 --> Total execution time: 0.0984
DEBUG - 2022-09-06 22:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:56:26 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:56:34 --> Total execution time: 0.1256
DEBUG - 2022-09-06 22:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:56:41 --> Total execution time: 0.1084
DEBUG - 2022-09-06 22:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:56:43 --> Total execution time: 0.1166
DEBUG - 2022-09-06 22:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:56:44 --> Total execution time: 0.0992
DEBUG - 2022-09-06 22:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:56:55 --> Total execution time: 0.1016
DEBUG - 2022-09-06 22:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:33 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:57:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 22:57:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 22:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:58:31 --> No URI present. Default controller set.
DEBUG - 2022-09-06 22:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 22:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 22:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 22:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:02:37 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:08:04 --> Total execution time: 0.1076
DEBUG - 2022-09-06 23:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:09:25 --> Total execution time: 0.1535
DEBUG - 2022-09-06 23:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:19:04 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:19:05 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:19:12 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:19:56 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:22:39 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:23:51 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:29:44 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:31:08 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:33:50 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:33:58 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:33:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 23:33:59 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-06 23:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:35:15 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:35:16 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:36:49 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:36:49 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:36:49 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:37:36 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:37:37 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:39:57 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:39:59 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:40:07 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:40:42 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:44:01 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:44:27 --> Total execution time: 0.1017
DEBUG - 2022-09-06 23:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:44:29 --> Total execution time: 0.0944
DEBUG - 2022-09-06 23:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:44:29 --> Total execution time: 0.1081
DEBUG - 2022-09-06 23:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:45:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 23:45:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 23:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:45:14 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:45:30 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:45:59 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:51:57 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:52:21 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:52:27 --> Total execution time: 0.1064
DEBUG - 2022-09-06 23:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:52:28 --> Total execution time: 0.0970
DEBUG - 2022-09-06 23:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:52:29 --> Total execution time: 0.0967
DEBUG - 2022-09-06 23:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:52:29 --> Total execution time: 0.2358
DEBUG - 2022-09-06 23:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-06 23:53:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-06 23:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:54:32 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:54:43 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:55:44 --> Total execution time: 0.1224
DEBUG - 2022-09-06 23:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:55:53 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:56:09 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:57:41 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:57:54 --> No URI present. Default controller set.
DEBUG - 2022-09-06 23:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-06 23:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-06 23:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-06 23:59:05 --> Encryption: Auto-configured driver 'openssl'.
