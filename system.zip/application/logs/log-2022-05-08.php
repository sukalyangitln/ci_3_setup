<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-08 01:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:07:09 --> No URI present. Default controller set.
DEBUG - 2022-05-08 01:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 01:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 06:37:10 --> Total execution time: 1.0720
DEBUG - 2022-05-08 01:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 01:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 01:07:19 --> Total execution time: 0.1877
DEBUG - 2022-05-08 01:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 01:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 01:07:20 --> Total execution time: 0.0282
DEBUG - 2022-05-08 01:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 01:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 01:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 01:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 06:37:44 --> Total execution time: 0.0795
DEBUG - 2022-05-08 01:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 01:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 06:37:50 --> Total execution time: 0.0685
DEBUG - 2022-05-08 01:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 01:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 06:37:58 --> Total execution time: 0.0799
DEBUG - 2022-05-08 01:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 01:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 06:47:26 --> Total execution time: 0.8625
DEBUG - 2022-05-08 01:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 01:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 06:55:51 --> Total execution time: 0.8586
DEBUG - 2022-05-08 01:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 01:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 06:57:43 --> Total execution time: 0.0301
DEBUG - 2022-05-08 01:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 01:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 06:59:52 --> Total execution time: 0.8236
DEBUG - 2022-05-08 01:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 01:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 07:00:30 --> Total execution time: 0.0320
DEBUG - 2022-05-08 01:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:30:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:31:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:31:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:31:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:31:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:31:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:31:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:31:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:31:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:31:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:31:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:31:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:31:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:31:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:31:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:31:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:31:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 01:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 07:02:49 --> Total execution time: 0.0340
DEBUG - 2022-05-08 01:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:32:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:32:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:32:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:32:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:32:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:32:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:32:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:32:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:32:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 01:32:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:32:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 01:32:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 01:32:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 02:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 07:39:03 --> Total execution time: 0.8905
DEBUG - 2022-05-08 02:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 07:45:57 --> Total execution time: 0.7537
DEBUG - 2022-05-08 02:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 02:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 07:46:29 --> Total execution time: 0.0346
DEBUG - 2022-05-08 02:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 02:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 02:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 07:50:29 --> Total execution time: 0.0833
DEBUG - 2022-05-08 02:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 07:53:04 --> Total execution time: 0.0351
DEBUG - 2022-05-08 02:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:03:32 --> Total execution time: 0.8637
DEBUG - 2022-05-08 02:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:03:53 --> Total execution time: 0.0310
DEBUG - 2022-05-08 02:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 02:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:43:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 02:43:42 --> Severity: error --> Exception: syntax error, unexpected '=' /home/gvprods/public_html/v1/gvv3/application/controllers/Admin/Course_crud_controller.php 117
DEBUG - 2022-05-08 02:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:44:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-08 08:14:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/gvprods/public_html/v1/gvv3/application/controllers/Admin/Course_crud_controller.php 128
ERROR - 2022-05-08 08:14:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/helpers/url_helper.php 564
DEBUG - 2022-05-08 02:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 02:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:15:07 --> Total execution time: 0.1810
DEBUG - 2022-05-08 02:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:24:39 --> Total execution time: 1.1911
DEBUG - 2022-05-08 02:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 02:55:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 02:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 02:55:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 02:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 02:55:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 02:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:55:03 --> UTF-8 Support Enabled
ERROR - 2022-05-08 02:55:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 02:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 02:55:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 02:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 02:55:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 02:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 02:55:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 02:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 02:55:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-08 02:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:26:43 --> Total execution time: 0.8507
DEBUG - 2022-05-08 02:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:26:44 --> Total execution time: 0.0290
DEBUG - 2022-05-08 02:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:28:01 --> Total execution time: 0.8815
DEBUG - 2022-05-08 02:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 02:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:29:32 --> Total execution time: 0.0989
DEBUG - 2022-05-08 02:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 02:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 02:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:29:36 --> Total execution time: 0.8153
DEBUG - 2022-05-08 03:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 03:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 03:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 03:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 03:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 03:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:30:41 --> Total execution time: 0.0879
DEBUG - 2022-05-08 03:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 03:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 03:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:33:33 --> Total execution time: 0.8507
DEBUG - 2022-05-08 03:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 03:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 03:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 03:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 03:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 03:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:34:09 --> Total execution time: 0.0330
DEBUG - 2022-05-08 03:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 03:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 03:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:35:41 --> Total execution time: 1.1007
DEBUG - 2022-05-08 03:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 03:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 03:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 03:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 03:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 03:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 03:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 03:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:36:30 --> Total execution time: 0.0621
DEBUG - 2022-05-08 03:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 03:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 03:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 03:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:36:31 --> Total execution time: 0.0324
DEBUG - 2022-05-08 03:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 03:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 03:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:38:33 --> Total execution time: 0.9408
DEBUG - 2022-05-08 03:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 03:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 03:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:38:51 --> Total execution time: 0.8587
DEBUG - 2022-05-08 03:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 03:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 03:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 08:39:06 --> Total execution time: 0.0321
DEBUG - 2022-05-08 04:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 04:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 04:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 04:08:06 --> Total execution time: 0.9931
DEBUG - 2022-05-08 04:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 04:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 04:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 04:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 04:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 04:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 09:38:22 --> Total execution time: 0.0947
DEBUG - 2022-05-08 04:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 04:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 04:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 09:38:31 --> Total execution time: 0.0723
DEBUG - 2022-05-08 04:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 04:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 04:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 09:38:44 --> Total execution time: 0.0872
DEBUG - 2022-05-08 04:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 04:11:37 --> No URI present. Default controller set.
DEBUG - 2022-05-08 04:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 04:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-08 09:41:37 --> Total execution time: 0.1137
