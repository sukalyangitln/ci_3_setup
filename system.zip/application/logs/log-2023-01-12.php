<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-12 08:15:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:15:04 --> No URI present. Default controller set.
DEBUG - 2023-01-12 08:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:45:04 --> Total execution time: 0.0779
DEBUG - 2023-01-12 08:15:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:45:33 --> Total execution time: 0.0529
DEBUG - 2023-01-12 08:15:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:45:37 --> Total execution time: 0.0441
DEBUG - 2023-01-12 08:15:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 08:15:49 --> Total execution time: 0.0447
DEBUG - 2023-01-12 08:15:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 08:15:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:45:54 --> Total execution time: 0.0470
DEBUG - 2023-01-12 08:16:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:46:04 --> Total execution time: 0.0968
DEBUG - 2023-01-12 08:16:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:46:06 --> Total execution time: 0.0748
DEBUG - 2023-01-12 08:16:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:46:06 --> Total execution time: 0.0585
DEBUG - 2023-01-12 08:18:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:48:15 --> Total execution time: 0.0692
DEBUG - 2023-01-12 08:18:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:48:18 --> Total execution time: 0.0624
DEBUG - 2023-01-12 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:48:20 --> Total execution time: 0.0885
DEBUG - 2023-01-12 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:48:20 --> Total execution time: 0.0594
DEBUG - 2023-01-12 08:23:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:53:03 --> Total execution time: 0.0445
DEBUG - 2023-01-12 08:23:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:53:03 --> Total execution time: 0.0568
DEBUG - 2023-01-12 08:23:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:53:27 --> Total execution time: 0.0536
DEBUG - 2023-01-12 08:23:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:53:27 --> Total execution time: 0.0593
DEBUG - 2023-01-12 08:25:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:55:53 --> Total execution time: 0.0773
DEBUG - 2023-01-12 08:25:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:55:53 --> Total execution time: 0.0544
DEBUG - 2023-01-12 08:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:56:15 --> Total execution time: 0.0589
DEBUG - 2023-01-12 08:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 12:56:15 --> Total execution time: 0.0586
DEBUG - 2023-01-12 08:30:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:00:05 --> Total execution time: 0.0762
DEBUG - 2023-01-12 08:30:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:00:06 --> Total execution time: 0.0573
DEBUG - 2023-01-12 08:30:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:00:37 --> Total execution time: 0.0628
DEBUG - 2023-01-12 08:30:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:00:37 --> Total execution time: 0.0713
DEBUG - 2023-01-12 08:30:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:00:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-12 13:00:47 --> You did not select a file to upload.
DEBUG - 2023-01-12 13:00:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-12 13:00:47 --> You did not select a file to upload.
DEBUG - 2023-01-12 08:30:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:00:47 --> Total execution time: 0.0479
DEBUG - 2023-01-12 08:30:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:00:47 --> Total execution time: 0.0745
DEBUG - 2023-01-12 08:31:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:01:55 --> Total execution time: 0.0427
DEBUG - 2023-01-12 08:31:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:01:55 --> Total execution time: 0.0522
DEBUG - 2023-01-12 08:32:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:02:06 --> Total execution time: 0.0748
DEBUG - 2023-01-12 08:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:02:07 --> Total execution time: 0.0568
DEBUG - 2023-01-12 08:32:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:02:29 --> Total execution time: 0.0428
DEBUG - 2023-01-12 08:32:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:02:30 --> Total execution time: 0.0589
DEBUG - 2023-01-12 08:32:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:02:55 --> Total execution time: 0.0464
DEBUG - 2023-01-12 08:32:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:02:58 --> Total execution time: 0.1365
DEBUG - 2023-01-12 08:34:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:04:45 --> Total execution time: 0.0645
DEBUG - 2023-01-12 08:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:04:46 --> Total execution time: 0.0499
DEBUG - 2023-01-12 08:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:04:46 --> Total execution time: 0.0566
DEBUG - 2023-01-12 08:37:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:07:04 --> Total execution time: 0.0684
DEBUG - 2023-01-12 08:37:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:07:04 --> Total execution time: 0.0566
DEBUG - 2023-01-12 08:37:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:07:11 --> Total execution time: 0.0647
DEBUG - 2023-01-12 08:37:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:07:13 --> Total execution time: 0.0456
DEBUG - 2023-01-12 08:37:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:07:13 --> Total execution time: 0.0521
DEBUG - 2023-01-12 08:37:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:07:15 --> Total execution time: 0.0468
DEBUG - 2023-01-12 08:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:07:18 --> Total execution time: 0.0463
DEBUG - 2023-01-12 08:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:07:18 --> Total execution time: 0.0538
DEBUG - 2023-01-12 08:37:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:07:19 --> Total execution time: 0.0664
DEBUG - 2023-01-12 08:37:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:07:21 --> Total execution time: 0.0699
DEBUG - 2023-01-12 08:38:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:08:59 --> Total execution time: 0.0599
DEBUG - 2023-01-12 08:41:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:11:50 --> Total execution time: 0.0695
DEBUG - 2023-01-12 08:42:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:12:50 --> Total execution time: 0.0484
DEBUG - 2023-01-12 08:42:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:12:51 --> Total execution time: 0.0464
DEBUG - 2023-01-12 08:42:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:12:51 --> Total execution time: 0.0567
DEBUG - 2023-01-12 08:44:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:14:45 --> Total execution time: 0.0620
DEBUG - 2023-01-12 08:44:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:14:45 --> Total execution time: 0.0781
DEBUG - 2023-01-12 08:45:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:15:34 --> Total execution time: 0.0558
DEBUG - 2023-01-12 08:45:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:15:34 --> Total execution time: 0.0568
DEBUG - 2023-01-12 08:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:15:42 --> Total execution time: 0.0655
DEBUG - 2023-01-12 08:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:15:42 --> Total execution time: 0.0582
DEBUG - 2023-01-12 08:46:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:16:35 --> Total execution time: 0.0415
DEBUG - 2023-01-12 08:46:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:16:35 --> Total execution time: 0.0755
DEBUG - 2023-01-12 08:48:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:18:44 --> Total execution time: 0.0645
DEBUG - 2023-01-12 08:48:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:18:45 --> Total execution time: 0.0523
DEBUG - 2023-01-12 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:48:52 --> UTF-8 Support Enabled
ERROR - 2023-01-12 08:48:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:48:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:48:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-12 08:48:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:48:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:48:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:48:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:48:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:20:21 --> Total execution time: 0.0695
DEBUG - 2023-01-12 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:50:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:50:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:50:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:50:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:50:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:50:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-12 08:50:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-12 08:50:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:50:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:50:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:20:21 --> Total execution time: 0.0493
DEBUG - 2023-01-12 08:50:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:50:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:50:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:50:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:50:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:50:33 --> UTF-8 Support Enabled
ERROR - 2023-01-12 08:50:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:50:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:50:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:50:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:50:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:50:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:50:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:50:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:50:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:50:33 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-12 08:50:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:21:13 --> Total execution time: 0.0661
DEBUG - 2023-01-12 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:51:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:51:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:51:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:51:13 --> UTF-8 Support Enabled
ERROR - 2023-01-12 08:51:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-12 08:51:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:51:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-12 08:51:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2023-01-12 08:51:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-12 08:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:21:13 --> Total execution time: 0.0668
DEBUG - 2023-01-12 08:52:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:22:59 --> Total execution time: 0.0695
DEBUG - 2023-01-12 08:53:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:23:00 --> Total execution time: 0.0583
DEBUG - 2023-01-12 08:56:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:26:08 --> Total execution time: 0.0688
DEBUG - 2023-01-12 08:56:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 08:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 08:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 08:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 13:26:09 --> Total execution time: 0.0640
DEBUG - 2023-01-12 09:44:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:14:36 --> Total execution time: 0.0690
DEBUG - 2023-01-12 09:44:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:14:37 --> Total execution time: 0.0602
DEBUG - 2023-01-12 09:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:14:40 --> Total execution time: 0.0435
DEBUG - 2023-01-12 09:44:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:14:42 --> Total execution time: 0.0473
DEBUG - 2023-01-12 09:44:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:14:42 --> Total execution time: 0.0537
DEBUG - 2023-01-12 09:46:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:16:00 --> Total execution time: 0.0563
DEBUG - 2023-01-12 09:46:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:16:01 --> Total execution time: 0.0723
DEBUG - 2023-01-12 09:46:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:16:11 --> Total execution time: 0.0526
DEBUG - 2023-01-12 09:46:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:16:13 --> Total execution time: 0.0475
DEBUG - 2023-01-12 09:46:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:16:13 --> Total execution time: 0.0546
DEBUG - 2023-01-12 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:18:23 --> Total execution time: 0.0441
DEBUG - 2023-01-12 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:18:23 --> Total execution time: 0.0444
DEBUG - 2023-01-12 09:49:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:19:01 --> Total execution time: 0.0414
DEBUG - 2023-01-12 09:49:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:49:01 --> No URI present. Default controller set.
DEBUG - 2023-01-12 09:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:49:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 09:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 14:19:01 --> Total execution time: 0.0564
DEBUG - 2023-01-12 09:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:19:01 --> Total execution time: 0.0496
DEBUG - 2023-01-12 09:49:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:19:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-12 14:19:11 --> You did not select a file to upload.
DEBUG - 2023-01-12 14:19:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-12 14:19:11 --> You did not select a file to upload.
DEBUG - 2023-01-12 14:19:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-12 09:49:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:19:11 --> Total execution time: 0.0465
DEBUG - 2023-01-12 09:49:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:19:11 --> Total execution time: 0.0429
DEBUG - 2023-01-12 09:49:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:19:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-12 14:19:20 --> You did not select a file to upload.
DEBUG - 2023-01-12 14:19:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-12 14:19:20 --> You did not select a file to upload.
DEBUG - 2023-01-12 14:19:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-12 09:49:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:19:20 --> Total execution time: 0.0449
DEBUG - 2023-01-12 09:49:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:19:20 --> Total execution time: 0.0468
DEBUG - 2023-01-12 09:49:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:19:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-12 14:19:31 --> You did not select a file to upload.
DEBUG - 2023-01-12 14:19:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-12 14:19:31 --> You did not select a file to upload.
DEBUG - 2023-01-12 14:19:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-12 09:49:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:19:31 --> Total execution time: 0.0475
DEBUG - 2023-01-12 09:49:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-12 09:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-12 14:19:31 --> Total execution time: 0.0495
