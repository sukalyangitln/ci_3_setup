<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-11-29 12:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-29 12:52:04 --> No URI present. Default controller set.
DEBUG - 2022-11-29 12:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-29 12:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-29 17:22:04 --> Total execution time: 0.6447
DEBUG - 2022-11-29 12:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-29 12:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-29 12:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-29 12:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-29 12:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-29 12:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-29 12:52:19 --> Total execution time: 0.0434
DEBUG - 2022-11-29 12:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-29 12:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-29 12:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-29 12:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-29 12:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-29 12:52:20 --> Total execution time: 0.0496
DEBUG - 2022-11-29 12:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-29 12:52:20 --> Total execution time: 0.0712
