<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-19 17:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 17:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 17:40:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-19 17:40:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\personal\jaal\application\core\DB_Controller.php 28
DEBUG - 2022-03-19 17:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 17:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 17:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 17:40:31 --> Total execution time: 0.0792
DEBUG - 2022-03-19 17:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 17:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 17:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 17:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 17:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 17:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:10:33 --> Total execution time: 0.0926
DEBUG - 2022-03-19 17:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 17:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 17:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:10:40 --> Total execution time: 0.1023
DEBUG - 2022-03-19 17:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 17:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 17:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:10:46 --> Total execution time: 0.0707
DEBUG - 2022-03-19 17:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 17:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 17:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:10:50 --> Total execution time: 0.0461
DEBUG - 2022-03-19 17:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 17:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 17:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:10:51 --> Total execution time: 0.0582
DEBUG - 2022-03-19 17:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 17:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 17:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:14:19 --> Total execution time: 0.1005
DEBUG - 2022-03-19 17:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 17:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 17:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:14:54 --> Total execution time: 0.0667
DEBUG - 2022-03-19 17:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 17:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 17:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:14:59 --> Total execution time: 0.0444
DEBUG - 2022-03-19 17:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 17:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 17:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:15:03 --> Total execution time: 0.0483
DEBUG - 2022-03-19 17:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 17:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 17:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:15:05 --> Total execution time: 0.0483
DEBUG - 2022-03-19 18:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:44:19 --> Total execution time: 0.0663
DEBUG - 2022-03-19 18:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:46:40 --> Total execution time: 0.0474
DEBUG - 2022-03-19 18:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:46:53 --> Total execution time: 0.0452
DEBUG - 2022-03-19 18:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:47:24 --> Total execution time: 0.0647
DEBUG - 2022-03-19 18:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:17:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-19 18:17:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:27 --> UTF-8 Support Enabled
ERROR - 2022-03-19 18:17:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:17:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:17:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:17:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-19 18:17:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:17:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:47:43 --> Total execution time: 0.0593
DEBUG - 2022-03-19 18:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:17:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-19 18:17:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:17:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:17:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:17:44 --> UTF-8 Support Enabled
ERROR - 2022-03-19 18:17:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:17:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-19 18:17:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:17:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:48:05 --> Total execution time: 0.0871
DEBUG - 2022-03-19 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:52:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:52:41 --> Total execution time: 0.0513
DEBUG - 2022-03-19 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:22:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-19 18:22:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:22:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:22:41 --> UTF-8 Support Enabled
ERROR - 2022-03-19 18:22:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:22:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:22:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:22:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-19 18:22:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:53:44 --> Total execution time: 0.0685
DEBUG - 2022-03-19 18:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:58:24 --> Total execution time: 0.0700
DEBUG - 2022-03-19 18:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 22:59:24 --> Total execution time: 0.0477
DEBUG - 2022-03-19 18:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:00:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 18:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:00:03 --> Total execution time: 0.0429
DEBUG - 2022-03-19 18:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:00:49 --> Total execution time: 0.0682
DEBUG - 2022-03-19 18:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:01:31 --> Total execution time: 0.0531
DEBUG - 2022-03-19 18:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:04:07 --> Total execution time: 0.0757
DEBUG - 2022-03-19 18:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:04:11 --> Total execution time: 0.0742
DEBUG - 2022-03-19 18:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:04:12 --> Total execution time: 0.0592
DEBUG - 2022-03-19 18:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:04:32 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 18:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:04:32 --> Total execution time: 0.0473
DEBUG - 2022-03-19 18:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:22:40 --> Total execution time: 0.0715
DEBUG - 2022-03-19 18:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:52:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:52:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:52:43 --> UTF-8 Support Enabled
ERROR - 2022-03-19 18:52:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:52:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:52:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-19 18:52:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-19 18:52:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:52:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:52:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-19 18:52:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:52:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:52:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:22:46 --> Total execution time: 0.0688
DEBUG - 2022-03-19 18:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:27:06 --> Total execution time: 0.0626
DEBUG - 2022-03-19 18:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:57:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-19 18:57:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:57:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:57:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-19 18:57:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:57:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-19 18:57:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-19 18:57:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:27:10 --> Total execution time: 0.0656
DEBUG - 2022-03-19 18:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:27:34 --> Total execution time: 0.0707
DEBUG - 2022-03-19 18:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:57:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:57:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:57:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:57:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:57:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:57:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:57:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-03-19 18:57:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:57:35 --> UTF-8 Support Enabled
ERROR - 2022-03-19 18:57:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:57:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:57:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-19 18:57:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-03-19 18:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:27:39 --> Total execution time: 0.0434
DEBUG - 2022-03-19 18:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:27:41 --> Total execution time: 0.0480
DEBUG - 2022-03-19 18:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:27:57 --> Total execution time: 0.0688
DEBUG - 2022-03-19 18:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:28:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 23:28:58 --> You did not select a file to upload.
DEBUG - 2022-03-19 18:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:28:58 --> Total execution time: 0.0614
DEBUG - 2022-03-19 18:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:29:01 --> Total execution time: 0.0426
DEBUG - 2022-03-19 18:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:29:05 --> Total execution time: 0.0464
DEBUG - 2022-03-19 18:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:29:40 --> Total execution time: 0.0620
DEBUG - 2022-03-19 18:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:29:41 --> Total execution time: 0.0547
DEBUG - 2022-03-19 19:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 19:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 19:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:30:33 --> Total execution time: 0.1356
DEBUG - 2022-03-19 19:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 19:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 19:04:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-19 23:34:52 --> Severity: Notice --> Undefined variable: clients C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 75
ERROR - 2022-03-19 23:34:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 75
DEBUG - 2022-03-19 23:34:52 --> Total execution time: 0.0686
DEBUG - 2022-03-19 19:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 19:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 19:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 19:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 19:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 19:05:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-19 23:35:26 --> Severity: Notice --> Undefined variable: clients C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 75
ERROR - 2022-03-19 23:35:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 75
DEBUG - 2022-03-19 23:35:26 --> Total execution time: 0.0600
DEBUG - 2022-03-19 19:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 19:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 19:05:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-19 23:35:51 --> Severity: Notice --> Undefined variable: clients C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 75
ERROR - 2022-03-19 23:35:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 75
DEBUG - 2022-03-19 23:35:51 --> Total execution time: 0.0496
DEBUG - 2022-03-19 19:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 19:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 19:06:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-03-19 23:36:11 --> Severity: Notice --> Undefined variable: clients C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 73
ERROR - 2022-03-19 23:36:11 --> Severity: Notice --> Undefined variable: clients C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 78
ERROR - 2022-03-19 23:36:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal\jaal\application\views\Admin\collection\admin-rent-list.php 78
DEBUG - 2022-03-19 23:36:11 --> Total execution time: 0.0976
DEBUG - 2022-03-19 19:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 19:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 19:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-03-19 23:36:26 --> Total execution time: 0.0522
