<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-04 02:24:09 --> UTF-8 Support Enabled
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-04 02:24:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:24:09 --> No URI present. Default controller set.
DEBUG - 2021-11-04 02:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 02:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 07:54:10 --> Total execution time: 1.3712
DEBUG - 2021-11-04 02:24:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 07:54:15 --> Total execution time: 3.1095
DEBUG - 2021-11-04 02:24:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 02:24:38 --> Total execution time: 0.1474
DEBUG - 2021-11-04 02:24:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 02:24:39 --> Total execution time: 0.0294
DEBUG - 2021-11-04 02:24:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:24:43 --> No URI present. Default controller set.
DEBUG - 2021-11-04 02:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 07:54:43 --> Total execution time: 0.0298
DEBUG - 2021-11-04 02:24:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:24:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:24:44 --> No URI present. Default controller set.
DEBUG - 2021-11-04 02:24:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 02:24:44 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-04 02:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 07:54:44 --> Total execution time: 0.0362
DEBUG - 2021-11-04 02:24:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 02:24:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 07:54:51 --> Total execution time: 0.1381
DEBUG - 2021-11-04 02:24:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 07:54:54 --> Total execution time: 0.4082
DEBUG - 2021-11-04 02:25:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 02:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 07:55:15 --> Total execution time: 0.2131
DEBUG - 2021-11-04 02:29:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 07:59:10 --> Total execution time: 0.1091
DEBUG - 2021-11-04 02:29:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 07:59:12 --> Total execution time: 0.0416
DEBUG - 2021-11-04 02:29:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 07:59:14 --> Total execution time: 0.0706
DEBUG - 2021-11-04 02:29:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 07:59:36 --> Total execution time: 0.0961
DEBUG - 2021-11-04 02:29:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 07:59:40 --> Total execution time: 0.0562
DEBUG - 2021-11-04 02:29:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 07:59:42 --> Total execution time: 0.0356
DEBUG - 2021-11-04 02:29:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 07:59:43 --> Total execution time: 0.0378
DEBUG - 2021-11-04 02:34:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:04:35 --> Total execution time: 0.0440
DEBUG - 2021-11-04 02:38:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:08:58 --> Total execution time: 0.0519
DEBUG - 2021-11-04 02:39:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:09:00 --> Total execution time: 0.0300
DEBUG - 2021-11-04 02:39:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:09:17 --> Total execution time: 3.4666
DEBUG - 2021-11-04 02:40:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:10:10 --> Total execution time: 0.0563
DEBUG - 2021-11-04 02:40:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:10:12 --> Total execution time: 0.0531
DEBUG - 2021-11-04 02:40:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:10:22 --> Total execution time: 0.0320
DEBUG - 2021-11-04 02:40:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:10:26 --> Total execution time: 3.0060
DEBUG - 2021-11-04 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:11:24 --> Total execution time: 0.0352
DEBUG - 2021-11-04 02:41:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 02:41:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:11:28 --> Total execution time: 0.0447
DEBUG - 2021-11-04 02:46:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:16:16 --> Total execution time: 0.2655
DEBUG - 2021-11-04 02:46:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:16:20 --> Total execution time: 0.0454
DEBUG - 2021-11-04 02:47:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:17:58 --> Total execution time: 0.0607
DEBUG - 2021-11-04 02:50:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:50:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 08:20:20 --> Severity: Compile Error --> Cannot redeclare SendFile_GET_Method() (previously declared in /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php:47) /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 132
DEBUG - 2021-11-04 02:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:20:38 --> Total execution time: 1.6461
DEBUG - 2021-11-04 02:51:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:21:01 --> Total execution time: 0.0383
DEBUG - 2021-11-04 02:51:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 02:51:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:21:05 --> Total execution time: 0.0360
DEBUG - 2021-11-04 02:53:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:23:27 --> Total execution time: 0.0358
DEBUG - 2021-11-04 02:59:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 02:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 02:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:29:31 --> Total execution time: 0.0689
DEBUG - 2021-11-04 03:00:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:30:03 --> Total execution time: 0.0665
DEBUG - 2021-11-04 03:01:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:31:40 --> Total execution time: 0.0413
DEBUG - 2021-11-04 03:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:31:52 --> Total execution time: 0.0424
DEBUG - 2021-11-04 03:01:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:31:58 --> Total execution time: 0.0394
DEBUG - 2021-11-04 03:02:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:32:00 --> Total execution time: 0.0442
DEBUG - 2021-11-04 03:02:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:32:31 --> Total execution time: 0.0386
DEBUG - 2021-11-04 03:02:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:32:32 --> Total execution time: 0.0722
DEBUG - 2021-11-04 03:04:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:34:39 --> Total execution time: 0.0562
DEBUG - 2021-11-04 03:06:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:06:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 08:36:18 --> Severity: Notice --> Undefined index: message /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 153
ERROR - 2021-11-04 08:36:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 158
DEBUG - 2021-11-04 08:36:20 --> Total execution time: 1.7508
DEBUG - 2021-11-04 03:06:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:06:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 08:36:41 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 157
DEBUG - 2021-11-04 08:36:41 --> Total execution time: 1.2185
DEBUG - 2021-11-04 03:07:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:37:40 --> Total execution time: 2.3784
DEBUG - 2021-11-04 03:08:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:38:22 --> Total execution time: 2.1475
DEBUG - 2021-11-04 03:08:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:38:39 --> Total execution time: 0.0336
DEBUG - 2021-11-04 03:08:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 03:08:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:38:45 --> Total execution time: 0.0518
DEBUG - 2021-11-04 03:09:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:39:59 --> Total execution time: 0.0476
DEBUG - 2021-11-04 03:10:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:40:57 --> Total execution time: 0.0376
DEBUG - 2021-11-04 03:10:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:40:59 --> Total execution time: 0.0421
DEBUG - 2021-11-04 03:11:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:41:32 --> Total execution time: 0.0443
DEBUG - 2021-11-04 03:16:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:46:31 --> Total execution time: 0.0816
DEBUG - 2021-11-04 03:16:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:46:36 --> Total execution time: 0.0357
DEBUG - 2021-11-04 03:16:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:46:41 --> Total execution time: 2.5996
DEBUG - 2021-11-04 03:17:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:47:07 --> Total execution time: 0.0788
DEBUG - 2021-11-04 03:17:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 03:17:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:47:10 --> Total execution time: 0.0373
DEBUG - 2021-11-04 03:17:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:47:13 --> Total execution time: 0.0363
DEBUG - 2021-11-04 03:17:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 03:17:16 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 03:17:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:17:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 03:17:21 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-04 03:17:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 03:17:48 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-04 03:18:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:48:09 --> Total execution time: 0.0400
DEBUG - 2021-11-04 03:19:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:49:36 --> Total execution time: 0.0989
DEBUG - 2021-11-04 03:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:55:20 --> Total execution time: 0.1018
DEBUG - 2021-11-04 03:25:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:55:23 --> Total execution time: 0.0446
DEBUG - 2021-11-04 03:25:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:55:37 --> Total execution time: 11.7994
DEBUG - 2021-11-04 03:26:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:56:15 --> Total execution time: 0.0422
DEBUG - 2021-11-04 03:26:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 03:26:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:56:24 --> Total execution time: 0.0500
DEBUG - 2021-11-04 03:26:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 08:56:33 --> Total execution time: 0.0533
DEBUG - 2021-11-04 03:29:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:29:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 08:59:07 --> Severity: Compile Error --> Cannot redeclare SendPDF() (previously declared in /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php:231) /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 319
DEBUG - 2021-11-04 03:30:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:00:17 --> Total execution time: 4.6558
DEBUG - 2021-11-04 03:30:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:00:31 --> Total execution time: 0.0509
DEBUG - 2021-11-04 03:30:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:00:36 --> Total execution time: 0.0424
DEBUG - 2021-11-04 03:30:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:00:43 --> Total execution time: 5.9499
DEBUG - 2021-11-04 03:31:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:01:44 --> Total execution time: 4.9625
DEBUG - 2021-11-04 03:32:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:02:21 --> Total execution time: 0.0401
DEBUG - 2021-11-04 03:33:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:03:33 --> Total execution time: 6.2834
DEBUG - 2021-11-04 03:34:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:04:03 --> Total execution time: 2.3147
DEBUG - 2021-11-04 03:34:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:04:46 --> Total execution time: 0.0399
DEBUG - 2021-11-04 03:34:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 03:34:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:04:50 --> Total execution time: 0.0396
DEBUG - 2021-11-04 03:34:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:04:55 --> Total execution time: 0.0419
DEBUG - 2021-11-04 03:36:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:06:15 --> Total execution time: 0.0513
DEBUG - 2021-11-04 03:40:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:10:33 --> Total execution time: 0.1066
DEBUG - 2021-11-04 03:40:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:10:39 --> Total execution time: 0.0401
DEBUG - 2021-11-04 03:40:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:10:41 --> Total execution time: 0.3465
DEBUG - 2021-11-04 03:41:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:11:20 --> Total execution time: 6.1019
DEBUG - 2021-11-04 03:42:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:12:40 --> Total execution time: 0.6681
DEBUG - 2021-11-04 03:44:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:14:05 --> Total execution time: 0.1102
DEBUG - 2021-11-04 03:44:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 03:44:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:14:07 --> Total execution time: 0.0583
DEBUG - 2021-11-04 03:44:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:14:10 --> Total execution time: 0.0385
DEBUG - 2021-11-04 03:47:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:17:56 --> Total execution time: 0.0471
DEBUG - 2021-11-04 03:55:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:55:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 09:25:06 --> Severity: error --> Exception: syntax error, unexpected '$api_list_id' (T_VARIABLE) /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 359
DEBUG - 2021-11-04 03:55:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:25:30 --> Total execution time: 0.0596
DEBUG - 2021-11-04 03:55:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:25:36 --> Total execution time: 0.0365
DEBUG - 2021-11-04 03:55:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:25:40 --> Total execution time: 0.9692
DEBUG - 2021-11-04 03:56:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:26:39 --> Total execution time: 0.8204
DEBUG - 2021-11-04 03:56:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:26:49 --> Total execution time: 0.9006
DEBUG - 2021-11-04 03:58:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:28:02 --> Total execution time: 0.0888
DEBUG - 2021-11-04 03:58:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 03:58:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:28:05 --> Total execution time: 0.0493
DEBUG - 2021-11-04 03:58:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:28:59 --> Total execution time: 0.0467
DEBUG - 2021-11-04 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 03:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 03:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:29:39 --> Total execution time: 0.0438
DEBUG - 2021-11-04 04:01:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:31:22 --> Total execution time: 0.0360
DEBUG - 2021-11-04 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:01:51 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF) /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/API/API_Controller.php 118
DEBUG - 2021-11-04 04:02:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:32:02 --> Total execution time: 0.0544
DEBUG - 2021-11-04 04:07:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:37:58 --> Total execution time: 0.2364
DEBUG - 2021-11-04 04:08:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:38:02 --> Total execution time: 0.0809
DEBUG - 2021-11-04 04:08:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:38:04 --> Total execution time: 0.5180
DEBUG - 2021-11-04 04:08:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:38:59 --> Total execution time: 0.5208
DEBUG - 2021-11-04 04:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:39:19 --> Total execution time: 0.5261
DEBUG - 2021-11-04 04:09:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:39:37 --> Total execution time: 0.5182
DEBUG - 2021-11-04 04:10:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:40:48 --> Total execution time: 2.1321
DEBUG - 2021-11-04 04:11:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:41:27 --> Total execution time: 0.0393
DEBUG - 2021-11-04 04:11:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 04:11:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:41:29 --> Total execution time: 0.0395
DEBUG - 2021-11-04 04:11:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:41:53 --> Total execution time: 1.7117
DEBUG - 2021-11-04 04:12:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:42:27 --> Total execution time: 0.0384
DEBUG - 2021-11-04 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:42:30 --> Total execution time: 0.0506
DEBUG - 2021-11-04 04:12:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:42:38 --> Total execution time: 0.0371
DEBUG - 2021-11-04 04:12:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:12:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:12:43 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:43:40 --> Total execution time: 0.0540
DEBUG - 2021-11-04 04:13:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:43:48 --> Total execution time: 0.0510
DEBUG - 2021-11-04 04:13:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:13:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:13:49 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 04:14:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:44:24 --> Total execution time: 0.0768
DEBUG - 2021-11-04 04:14:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:14:25 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 04:14:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:44:53 --> Total execution time: 0.0544
DEBUG - 2021-11-04 04:15:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:15:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:15:05 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-04 04:16:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:46:16 --> Total execution time: 0.0386
DEBUG - 2021-11-04 04:16:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:16:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:16:17 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-04 04:16:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:16:18 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 04:17:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:47:02 --> Total execution time: 0.0493
DEBUG - 2021-11-04 04:17:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:47:16 --> Total execution time: 0.0545
DEBUG - 2021-11-04 04:18:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:48:11 --> Total execution time: 0.0417
DEBUG - 2021-11-04 04:18:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:18:16 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-04 04:20:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:50:05 --> Total execution time: 0.0626
DEBUG - 2021-11-04 04:20:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:20:12 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-04 04:21:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:51:32 --> Total execution time: 0.0523
DEBUG - 2021-11-04 04:21:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:21:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:21:41 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-04 04:21:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:21:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:21:47 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 04:22:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:52:48 --> Total execution time: 0.0562
DEBUG - 2021-11-04 04:22:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:22:48 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-04 04:22:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:22:49 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 04:23:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:53:52 --> Total execution time: 0.0375
DEBUG - 2021-11-04 04:23:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:23:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:23:53 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-04 04:23:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:23:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:23:55 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 04:25:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:55:14 --> Total execution time: 0.0723
DEBUG - 2021-11-04 04:25:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:25:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:25:21 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 04:26:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:56:50 --> Total execution time: 0.0391
DEBUG - 2021-11-04 04:27:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 04:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 09:57:39 --> Total execution time: 0.0427
DEBUG - 2021-11-04 04:38:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 04:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 04:38:57 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 10:41:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 10:41:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:11:53 --> Total execution time: 2.3241
DEBUG - 2021-11-04 10:42:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 10:42:15 --> Total execution time: 0.1734
DEBUG - 2021-11-04 10:42:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 10:42:16 --> Total execution time: 0.0320
DEBUG - 2021-11-04 10:42:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 10:42:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:12:22 --> Total execution time: 0.1619
DEBUG - 2021-11-04 10:43:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:43:00 --> No URI present. Default controller set.
DEBUG - 2021-11-04 10:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:13:01 --> Total execution time: 0.0817
DEBUG - 2021-11-04 10:43:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:43:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:43:01 --> No URI present. Default controller set.
DEBUG - 2021-11-04 10:43:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 10:43:01 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-04 10:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:13:01 --> Total execution time: 0.0704
DEBUG - 2021-11-04 10:43:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:13:06 --> Total execution time: 0.1318
DEBUG - 2021-11-04 10:43:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 10:43:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:13:15 --> Total execution time: 0.2011
DEBUG - 2021-11-04 10:43:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:13:18 --> Total execution time: 0.2936
DEBUG - 2021-11-04 10:43:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:13:21 --> Total execution time: 0.0969
DEBUG - 2021-11-04 10:43:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:43:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 10:43:29 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 10:44:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:14:03 --> Total execution time: 0.2460
DEBUG - 2021-11-04 10:47:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:17:15 --> Total execution time: 0.0629
DEBUG - 2021-11-04 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:19:53 --> Total execution time: 0.0440
DEBUG - 2021-11-04 10:53:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:23:32 --> Total execution time: 0.0401
DEBUG - 2021-11-04 10:58:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:28:02 --> Total execution time: 0.0654
DEBUG - 2021-11-04 10:58:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:28:09 --> Total execution time: 0.0351
DEBUG - 2021-11-04 10:58:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:28:13 --> Total execution time: 1.6687
DEBUG - 2021-11-04 10:59:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:29:19 --> Total execution time: 0.0371
DEBUG - 2021-11-04 10:59:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 10:59:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 10:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 10:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:29:22 --> Total execution time: 0.0358
DEBUG - 2021-11-04 11:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:31:00 --> Total execution time: 0.0408
DEBUG - 2021-11-04 11:02:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:32:23 --> Total execution time: 0.0374
DEBUG - 2021-11-04 11:04:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:34:26 --> Total execution time: 0.0448
DEBUG - 2021-11-04 11:04:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:34:31 --> Total execution time: 0.0316
DEBUG - 2021-11-04 11:04:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:34:36 --> Total execution time: 1.6273
DEBUG - 2021-11-04 11:04:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:34:46 --> Total execution time: 1.8283
DEBUG - 2021-11-04 11:04:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:34:54 --> Total execution time: 1.5481
DEBUG - 2021-11-04 11:05:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:35:26 --> Total execution time: 0.0550
DEBUG - 2021-11-04 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:35:29 --> Total execution time: 0.0359
DEBUG - 2021-11-04 11:05:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:35:34 --> Total execution time: 0.0462
DEBUG - 2021-11-04 11:07:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:37:49 --> Total execution time: 0.0904
DEBUG - 2021-11-04 11:10:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:10:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 16:40:19 --> Severity: Notice --> Undefined index: mobile /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 546
ERROR - 2021-11-04 16:40:19 --> Severity: Notice --> Undefined index: limit /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 547
DEBUG - 2021-11-04 16:40:19 --> Total execution time: 0.6404
DEBUG - 2021-11-04 11:11:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:41:17 --> Total execution time: 0.5919
DEBUG - 2021-11-04 11:11:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:41:46 --> Total execution time: 0.0453
DEBUG - 2021-11-04 11:11:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:41:52 --> Total execution time: 0.0323
DEBUG - 2021-11-04 11:11:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:41:55 --> Total execution time: 0.6573
DEBUG - 2021-11-04 11:14:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:44:34 --> Total execution time: 0.0392
DEBUG - 2021-11-04 11:14:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 11:14:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:44:37 --> Total execution time: 0.0437
DEBUG - 2021-11-04 11:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:44:52 --> Total execution time: 0.0475
DEBUG - 2021-11-04 11:15:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:45:36 --> Total execution time: 0.0375
DEBUG - 2021-11-04 11:15:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:15:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 11:15:37 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 11:16:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:46:38 --> Total execution time: 0.0466
DEBUG - 2021-11-04 11:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:48:45 --> Total execution time: 0.0479
DEBUG - 2021-11-04 11:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:48:50 --> Total execution time: 0.0429
DEBUG - 2021-11-04 11:18:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:48:54 --> Total execution time: 0.6454
DEBUG - 2021-11-04 11:20:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:50:32 --> Total execution time: 0.0449
DEBUG - 2021-11-04 11:20:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 11:20:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:50:35 --> Total execution time: 0.0631
DEBUG - 2021-11-04 11:20:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:50:47 --> Total execution time: 0.0433
DEBUG - 2021-11-04 11:20:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 11:20:48 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 11:22:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:52:11 --> Total execution time: 0.0567
DEBUG - 2021-11-04 11:25:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:55:41 --> Total execution time: 0.0438
DEBUG - 2021-11-04 11:25:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:55:44 --> Total execution time: 0.0415
DEBUG - 2021-11-04 11:25:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:55:47 --> Total execution time: 0.7722
DEBUG - 2021-11-04 11:26:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:56:12 --> Total execution time: 0.0329
DEBUG - 2021-11-04 11:26:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 11:26:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:56:28 --> Total execution time: 0.0414
DEBUG - 2021-11-04 11:27:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:57:13 --> Total execution time: 0.0469
DEBUG - 2021-11-04 11:27:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:57:31 --> Total execution time: 0.0400
DEBUG - 2021-11-04 11:29:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:59:56 --> Total execution time: 0.6072
DEBUG - 2021-11-04 11:31:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:01:54 --> {"session_id":"20211103201914850897","body":{"id":"3EB07FDABB20F708F9BE","serialized":"false_917501561206-1636025511@g.us_3EB07FDABB20F708F9BE","numberRegistered":"917501561206","numberFrom":"917501561206-1636025511","photoProfile":"","name":"Test api","pushName":"","isGroup":true,"participantsGroup":2,"unreadCount":0,"hasMedia":false,"mediaKey":"","url_file":"","type":"e2e_notification","body":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636025512,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":false,"isWAContact":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-04 17:01:54 --> Total execution time: 0.0982
DEBUG - 2021-11-04 11:32:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:02:13 --> Total execution time: 0.8000
DEBUG - 2021-11-04 11:32:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:02:44 --> Total execution time: 0.0390
DEBUG - 2021-11-04 11:32:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 11:32:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:02:47 --> Total execution time: 0.0351
DEBUG - 2021-11-04 11:33:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:03:06 --> Total execution time: 0.0361
DEBUG - 2021-11-04 11:33:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:03:26 --> Total execution time: 0.0525
DEBUG - 2021-11-04 11:33:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:03:46 --> Total execution time: 0.0451
DEBUG - 2021-11-04 11:33:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:03:48 --> Total execution time: 0.0338
DEBUG - 2021-11-04 11:33:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:03:51 --> Total execution time: 0.7675
DEBUG - 2021-11-04 11:34:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:04:47 --> Total execution time: 0.0456
DEBUG - 2021-11-04 11:36:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:06:30 --> Total execution time: 0.0371
DEBUG - 2021-11-04 11:39:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:09:11 --> Total execution time: 1.2786
DEBUG - 2021-11-04 11:40:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:10:01 --> Total execution time: 0.0377
DEBUG - 2021-11-04 11:40:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:10:04 --> Total execution time: 0.0570
DEBUG - 2021-11-04 11:46:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:16:29 --> Total execution time: 0.0361
DEBUG - 2021-11-04 11:52:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:22:07 --> Total execution time: 0.0377
DEBUG - 2021-11-04 11:55:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:25:07 --> Total execution time: 0.1301
DEBUG - 2021-11-04 11:55:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:25:12 --> Total execution time: 0.0443
DEBUG - 2021-11-04 11:55:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:25:16 --> Total execution time: 2.3690
DEBUG - 2021-11-04 11:56:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:26:12 --> Total execution time: 2.2371
DEBUG - 2021-11-04 11:56:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:26:57 --> Total execution time: 0.0528
DEBUG - 2021-11-04 11:57:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 11:57:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:27:02 --> Total execution time: 0.0483
DEBUG - 2021-11-04 11:57:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 11:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 11:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:27:08 --> Total execution time: 0.0340
DEBUG - 2021-11-04 12:04:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:34:39 --> Total execution time: 0.0502
DEBUG - 2021-11-04 12:04:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:34:43 --> Total execution time: 0.0337
DEBUG - 2021-11-04 12:04:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:04:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 17:34:45 --> Severity: Notice --> Undefined index: url /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 784
ERROR - 2021-11-04 17:34:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 791
DEBUG - 2021-11-04 17:34:46 --> Total execution time: 0.9532
DEBUG - 2021-11-04 12:05:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:05:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 17:35:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 791
DEBUG - 2021-11-04 17:35:02 --> Total execution time: 1.5214
DEBUG - 2021-11-04 12:05:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:35:51 --> Total execution time: 0.0514
DEBUG - 2021-11-04 12:05:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:05:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 12:05:52 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 12:06:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:06:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 17:36:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 655
DEBUG - 2021-11-04 17:36:37 --> Total execution time: 1.2109
DEBUG - 2021-11-04 12:07:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:37:54 --> Total execution time: 1.4653
DEBUG - 2021-11-04 12:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:38:19 --> Total execution time: 0.8425
DEBUG - 2021-11-04 12:08:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:38:50 --> Total execution time: 1.2818
DEBUG - 2021-11-04 12:09:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:39:36 --> Total execution time: 1.2296
DEBUG - 2021-11-04 12:11:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:41:10 --> Total execution time: 1.3602
DEBUG - 2021-11-04 12:11:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:41:37 --> Total execution time: 1.4090
DEBUG - 2021-11-04 12:12:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:42:16 --> {"session_id":"20211103201914850897","body":{"id":"3EB00907091861F499F0","serialized":"false_917501561206-1636025511@g.us_3EB00907091861F499F0","numberRegistered":"917501561206","numberFrom":"917501561206-1636025511","photoProfile":"","name":"Test api","pushName":"","isGroup":true,"participantsGroup":3,"unreadCount":0,"hasMedia":false,"mediaKey":"","url_file":"","type":"chat","body":"HEllo","sendBy":"919091982795@c.us","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636027934,"broadcast":false,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":false,"isWAContact":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-04 17:42:16 --> Total execution time: 0.0399
DEBUG - 2021-11-04 12:12:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:42:24 --> Total execution time: 1.4629
DEBUG - 2021-11-04 12:13:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:43:43 --> Total execution time: 2.7259
DEBUG - 2021-11-04 12:14:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:14:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 17:44:45 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 792
DEBUG - 2021-11-04 17:44:45 --> Total execution time: 1.7129
DEBUG - 2021-11-04 12:15:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:15:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 17:45:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 792
DEBUG - 2021-11-04 17:45:18 --> Total execution time: 1.4197
DEBUG - 2021-11-04 12:16:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:16:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 17:46:03 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 792
DEBUG - 2021-11-04 17:46:03 --> Total execution time: 1.6530
DEBUG - 2021-11-04 12:16:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:46:42 --> Total execution time: 0.0458
DEBUG - 2021-11-04 12:17:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:47:16 --> Total execution time: 0.0365
DEBUG - 2021-11-04 12:17:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:47:21 --> Total execution time: 0.0338
DEBUG - 2021-11-04 12:17:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:47:31 --> Total execution time: 1.3023
DEBUG - 2021-11-04 12:18:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:48:11 --> Total execution time: 1.4281
DEBUG - 2021-11-04 12:18:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:48:14 --> Total execution time: 1.4206
DEBUG - 2021-11-04 12:18:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:48:18 --> Total execution time: 1.8746
DEBUG - 2021-11-04 12:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:48:45 --> {"session_id":"20211103201914850897","body":{"id":"3EB05A71ED9608FA9651","serialized":"false_917501561206-1636028323@g.us_3EB05A71ED9608FA9651","numberRegistered":"917501561206","numberFrom":"917501561206-1636028323","photoProfile":"","name":"Test123","pushName":"","isGroup":true,"participantsGroup":2,"unreadCount":0,"hasMedia":false,"mediaKey":"","url_file":"","type":"e2e_notification","body":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636028324,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":false,"isWAContact":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-04 17:48:45 --> Total execution time: 0.0317
DEBUG - 2021-11-04 12:18:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:48:48 --> Total execution time: 1.2441
DEBUG - 2021-11-04 12:18:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:48:56 --> Total execution time: 1.3057
DEBUG - 2021-11-04 12:19:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:49:42 --> Total execution time: 0.1238
DEBUG - 2021-11-04 12:19:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:49:44 --> Total execution time: 0.0713
DEBUG - 2021-11-04 12:19:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:49:48 --> Total execution time: 0.0369
DEBUG - 2021-11-04 12:19:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:49:58 --> Total execution time: 0.0410
DEBUG - 2021-11-04 12:20:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:50:00 --> Total execution time: 0.0347
DEBUG - 2021-11-04 12:20:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:50:06 --> Total execution time: 0.0618
DEBUG - 2021-11-04 12:20:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:50:10 --> Total execution time: 1.4719
DEBUG - 2021-11-04 12:20:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:50:22 --> Total execution time: 0.0414
DEBUG - 2021-11-04 12:20:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:50:23 --> Total execution time: 0.0353
DEBUG - 2021-11-04 12:20:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:50:35 --> Total execution time: 1.4264
DEBUG - 2021-11-04 12:21:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:51:37 --> {"session_id":"20211103201914850897","body":{"id":"5638DE4E4062A6B66EB5490AC6297D16","serialized":"false_917501561206-1636025511@g.us_5638DE4E4062A6B66EB5490AC6297D16","numberRegistered":"917501561206","numberFrom":"917501561206-1636025511","photoProfile":"","name":"Test api","pushName":"","isGroup":true,"participantsGroup":2,"unreadCount":2,"hasMedia":false,"mediaKey":"","url_file":"","type":"chat","body":"Sehi he to","sendBy":"918328978378@c.us","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636028495,"broadcast":false,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":false,"isWAContact":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-04 17:51:37 --> Total execution time: 0.0309
DEBUG - 2021-11-04 12:21:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:51:37 --> {"session_id":"20211103201914850897","body":{"id":"65E547736231DF83D5C645A1156B7FDD","serialized":"false_917501561206-1636025511@g.us_65E547736231DF83D5C645A1156B7FDD","numberRegistered":"917501561206","numberFrom":"917501561206-1636025511","photoProfile":"","name":"Test api","pushName":"","isGroup":true,"participantsGroup":2,"unreadCount":2,"hasMedia":false,"mediaKey":"","url_file":"","type":"chat","body":"Test","sendBy":"918328978378@c.us","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636028496,"broadcast":false,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":false,"isWAContact":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-04 17:51:37 --> Total execution time: 0.0286
DEBUG - 2021-11-04 12:26:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 17:56:25 --> Total execution time: 1.3397
DEBUG - 2021-11-04 12:35:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:35:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 12:35:18 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 12:36:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:06:59 --> Total execution time: 0.0531
DEBUG - 2021-11-04 12:38:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:08:43 --> Total execution time: 0.3177
DEBUG - 2021-11-04 12:39:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:09:02 --> Total execution time: 0.0645
DEBUG - 2021-11-04 12:39:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:09:13 --> Total execution time: 0.0311
DEBUG - 2021-11-04 12:41:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:11:10 --> Total execution time: 0.0415
DEBUG - 2021-11-04 12:44:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:14:17 --> Total execution time: 0.0368
DEBUG - 2021-11-04 12:45:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:15:35 --> Total execution time: 0.0424
DEBUG - 2021-11-04 12:45:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:15:40 --> Total execution time: 0.0351
DEBUG - 2021-11-04 12:45:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:15:42 --> Total execution time: 0.0316
DEBUG - 2021-11-04 12:45:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:15:45 --> Total execution time: 0.0334
DEBUG - 2021-11-04 12:46:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:16:02 --> Total execution time: 2.4120
DEBUG - 2021-11-04 12:46:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:16:20 --> Total execution time: 0.0364
DEBUG - 2021-11-04 12:46:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 12:46:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 12:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 12:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:16:24 --> Total execution time: 0.0393
DEBUG - 2021-11-04 13:02:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:32:59 --> {"session_id":"20211103201914850897","body":{"id":"3EB057090D6FC0CC84FA","serialized":"false_918240387254@c.us_3EB057090D6FC0CC84FA","numberRegistered":"917501561206","numberFrom":"918240387254","photoProfile":"https:\/\/pps.whatsapp.net\/v\/t61.24694-24\/151624660_3666444486802768_5593525242725756113_n.jpg?ccb=11-4&oh=233c8d68919a67534b4436462ca8a2ca&oe=61888F65","name":"Bapi Jio Friend","pushName":"Axis Bank Uluberia","isGroup":false,"participantsGroup":"","unreadCount":0,"hasMedia":false,"mediaKey":"","url_file":"","type":"e2e_notification","body":"","sendBy":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636030978,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":true,"isWAContact":true,"isBusiness":true,"isEnterprise":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-04 18:32:59 --> Total execution time: 0.0420
DEBUG - 2021-11-04 13:17:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:47:22 --> Total execution time: 0.0392
DEBUG - 2021-11-04 13:17:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:47:50 --> Total execution time: 0.0431
DEBUG - 2021-11-04 13:17:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:47:55 --> Total execution time: 0.0369
DEBUG - 2021-11-04 13:17:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:47:59 --> Total execution time: 2.3597
DEBUG - 2021-11-04 13:18:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:48:16 --> Total execution time: 0.0437
DEBUG - 2021-11-04 13:18:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 13:18:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:48:18 --> Total execution time: 0.0354
DEBUG - 2021-11-04 13:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:49:47 --> Total execution time: 0.0349
DEBUG - 2021-11-04 13:20:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:50:19 --> Total execution time: 0.0348
DEBUG - 2021-11-04 13:20:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:50:57 --> Total execution time: 1.7863
DEBUG - 2021-11-04 13:21:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:51:15 --> Total execution time: 0.0422
DEBUG - 2021-11-04 13:21:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:51:25 --> Total execution time: 0.0321
DEBUG - 2021-11-04 13:21:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:51:28 --> Total execution time: 1.6645
DEBUG - 2021-11-04 13:21:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:51:42 --> Total execution time: 0.0462
DEBUG - 2021-11-04 13:21:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 13:21:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:51:44 --> Total execution time: 0.0421
DEBUG - 2021-11-04 13:21:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:51:48 --> Total execution time: 0.0492
DEBUG - 2021-11-04 13:21:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 13:21:49 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-04 13:23:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:53:05 --> Total execution time: 0.0619
DEBUG - 2021-11-04 13:24:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 18:54:57 --> Total execution time: 0.0530
DEBUG - 2021-11-04 13:32:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 19:02:19 --> Total execution time: 0.0569
DEBUG - 2021-11-04 13:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:34:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 19:04:24 --> Severity: Notice --> Undefined property: InstanceCheckLogout::$Instances /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/cron/InstanceCheckLogout.php 10
ERROR - 2021-11-04 19:04:24 --> Severity: error --> Exception: Call to a member function get() on null /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/cron/InstanceCheckLogout.php 10
DEBUG - 2021-11-04 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 19:04:33 --> Total execution time: 0.0456
DEBUG - 2021-11-04 13:53:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 19:23:12 --> Total execution time: 0.0394
DEBUG - 2021-11-04 13:53:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 13:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 13:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 19:23:22 --> Total execution time: 1.1254
DEBUG - 2021-11-04 14:04:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 14:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 14:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 19:34:59 --> Total execution time: 0.6236
DEBUG - 2021-11-04 14:07:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 14:07:00 --> No URI present. Default controller set.
DEBUG - 2021-11-04 14:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 14:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 14:07:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 14:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 14:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 19:37:00 --> Total execution time: 0.0585
DEBUG - 2021-11-04 14:18:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 14:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 14:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 19:48:19 --> Total execution time: 0.0523
DEBUG - 2021-11-04 14:18:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 14:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 14:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 19:48:24 --> Total execution time: 0.0405
DEBUG - 2021-11-04 14:18:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 14:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 14:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 19:48:58 --> Total execution time: 0.1190
DEBUG - 2021-11-04 14:19:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 14:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 14:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 19:49:04 --> Total execution time: 0.0317
DEBUG - 2021-11-04 14:19:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 14:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 14:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 19:49:09 --> Total execution time: 0.0338
DEBUG - 2021-11-04 14:19:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 14:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 14:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 19:49:27 --> Total execution time: 0.0329
DEBUG - 2021-11-04 14:19:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 14:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 14:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 19:49:35 --> Total execution time: 0.0324
DEBUG - 2021-11-04 14:20:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 14:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 14:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 14:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 14:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 19:50:07 --> Total execution time: 1.5822
DEBUG - 2021-11-04 16:01:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:31:11 --> Total execution time: 0.1880
DEBUG - 2021-11-04 16:01:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 16:01:13 --> 404 Page Not Found: Admin/settings/Settings_Template_Controller/index
DEBUG - 2021-11-04 16:03:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:33:22 --> Total execution time: 0.0444
DEBUG - 2021-11-04 16:04:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:34:21 --> Total execution time: 0.0625
DEBUG - 2021-11-04 16:07:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:37:36 --> Total execution time: 0.0846
DEBUG - 2021-11-04 16:09:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:39:39 --> Total execution time: 0.0521
DEBUG - 2021-11-04 16:10:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:40:09 --> Total execution time: 0.0609
DEBUG - 2021-11-04 16:10:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:40:27 --> Total execution time: 0.0518
DEBUG - 2021-11-04 16:12:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:42:07 --> Total execution time: 0.1735
DEBUG - 2021-11-04 16:12:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:12:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 16:12:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-04 16:12:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:12:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 16:12:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-04 16:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 16:12:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-04 16:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 16:12:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-04 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:43:01 --> Total execution time: 0.0402
DEBUG - 2021-11-04 16:13:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:43:16 --> Total execution time: 0.0488
DEBUG - 2021-11-04 16:13:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:43:35 --> Total execution time: 0.0399
DEBUG - 2021-11-04 16:13:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:43:57 --> Total execution time: 0.0484
DEBUG - 2021-11-04 16:14:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:44:15 --> Total execution time: 0.0345
DEBUG - 2021-11-04 16:16:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:46:06 --> Total execution time: 0.0980
DEBUG - 2021-11-04 16:16:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:16:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 16:16:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-04 16:16:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:16:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:16:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:16:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 16:16:10 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-04 16:16:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-04 16:16:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-04 16:16:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-04 16:17:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:47:03 --> Total execution time: 0.0529
DEBUG - 2021-11-04 16:17:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:47:23 --> Total execution time: 0.0514
DEBUG - 2021-11-04 16:17:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:47:50 --> Total execution time: 0.0445
DEBUG - 2021-11-04 16:18:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:48:40 --> Total execution time: 0.0544
DEBUG - 2021-11-04 16:19:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:19:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 21:49:30 --> Severity: Notice --> Trying to get property 's_tmp_disconnect' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-settings-whatsapp-template.php 72
ERROR - 2021-11-04 21:49:30 --> Severity: Notice --> Trying to get property 's_tmp_expire' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-settings-whatsapp-template.php 76
ERROR - 2021-11-04 21:49:30 --> Severity: Notice --> Trying to get property 's_tmp_reg_otp' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-settings-whatsapp-template.php 80
ERROR - 2021-11-04 21:49:30 --> Severity: Notice --> Trying to get property 's_tmp_reg_successful' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-settings-whatsapp-template.php 84
DEBUG - 2021-11-04 21:49:30 --> Total execution time: 0.0804
DEBUG - 2021-11-04 16:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:19:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-04 21:49:51 --> Severity: Notice --> Trying to get property 's_tmp_disconnect' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-settings-whatsapp-template.php 72
ERROR - 2021-11-04 21:49:51 --> Severity: Notice --> Trying to get property 's_tmp_expire' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-settings-whatsapp-template.php 76
ERROR - 2021-11-04 21:49:51 --> Severity: Notice --> Trying to get property 's_tmp_reg_otp' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-settings-whatsapp-template.php 80
ERROR - 2021-11-04 21:49:51 --> Severity: Notice --> Trying to get property 's_tmp_reg_successful' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-settings-whatsapp-template.php 84
DEBUG - 2021-11-04 21:49:51 --> Total execution time: 0.0463
DEBUG - 2021-11-04 16:20:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:20:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:50:36 --> Total execution time: 0.0549
DEBUG - 2021-11-04 16:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:55:19 --> Total execution time: 0.0418
DEBUG - 2021-11-04 16:26:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:26:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:26:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:26:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:56:57 --> Total execution time: 0.0381
DEBUG - 2021-11-04 16:28:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:28:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:58:13 --> Total execution time: 0.0329
DEBUG - 2021-11-04 16:29:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 21:59:25 --> Total execution time: 0.0389
DEBUG - 2021-11-04 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 22:03:25 --> Total execution time: 0.0337
DEBUG - 2021-11-04 16:36:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 16:36:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 22:06:48 --> Total execution time: 0.3360
DEBUG - 2021-11-04 16:37:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 22:07:14 --> Total execution time: 0.0369
DEBUG - 2021-11-04 16:37:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 22:07:50 --> Total execution time: 0.0511
DEBUG - 2021-11-04 16:38:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 22:08:12 --> Total execution time: 0.0578
DEBUG - 2021-11-04 16:43:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 22:13:53 --> Total execution time: 0.0514
DEBUG - 2021-11-04 16:43:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 22:13:54 --> Total execution time: 0.0533
DEBUG - 2021-11-04 16:44:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 22:14:19 --> Total execution time: 0.0464
DEBUG - 2021-11-04 16:47:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 22:17:10 --> Total execution time: 0.0785
DEBUG - 2021-11-04 16:47:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 22:17:28 --> Total execution time: 0.0339
DEBUG - 2021-11-04 16:49:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 22:19:25 --> Total execution time: 0.0552
DEBUG - 2021-11-04 16:54:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 22:24:01 --> Total execution time: 0.1455
DEBUG - 2021-11-04 16:55:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-04 16:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-04 16:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-04 22:25:26 --> Total execution time: 0.0499
