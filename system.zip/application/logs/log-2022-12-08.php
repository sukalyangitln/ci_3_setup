<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-08 14:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:17:48 --> No URI present. Default controller set.
DEBUG - 2022-12-08 14:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 18:47:48 --> Total execution time: 0.9035
DEBUG - 2022-12-08 14:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 14:17:58 --> Total execution time: 0.0617
DEBUG - 2022-12-08 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 14:17:58 --> Total execution time: 0.0583
DEBUG - 2022-12-08 14:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 14:17:58 --> Total execution time: 0.0709
DEBUG - 2022-12-08 14:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 14:18:01 --> Total execution time: 0.0422
DEBUG - 2022-12-08 14:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 18:51:11 --> Total execution time: 0.0946
DEBUG - 2022-12-08 14:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 14:21:21 --> Total execution time: 0.0688
DEBUG - 2022-12-08 14:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-08 14:21:21 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-08 14:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 14:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 18:51:23 --> Total execution time: 0.1299
DEBUG - 2022-12-08 14:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-08 14:21:24 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-08 14:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-08 14:21:24 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-08 14:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 18:51:27 --> Total execution time: 0.1292
DEBUG - 2022-12-08 14:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:21:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-08 14:21:27 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-08 14:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 14:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 14:36:21 --> Total execution time: 0.0436
DEBUG - 2022-12-08 14:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:36:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-08 14:36:21 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-08 14:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 14:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 19:06:23 --> Total execution time: 0.0447
DEBUG - 2022-12-08 14:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:36:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-08 14:36:23 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-08 14:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-08 14:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-08 14:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-08 19:07:07 --> Total execution time: 0.0664
