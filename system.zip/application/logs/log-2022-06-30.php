<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-06-30 00:07:02 --> Total execution time: 0.1004
DEBUG - 2022-06-30 00:09:10 --> Total execution time: 0.1052
DEBUG - 2022-06-30 00:25:07 --> Total execution time: 0.2215
DEBUG - 2022-06-30 00:29:07 --> Total execution time: 0.0293
DEBUG - 2022-06-30 00:29:09 --> Total execution time: 0.0629
DEBUG - 2022-06-30 00:29:16 --> Total execution time: 0.0442
DEBUG - 2022-06-30 00:29:25 --> Total execution time: 0.0502
DEBUG - 2022-06-30 00:30:02 --> Total execution time: 0.1680
DEBUG - 2022-06-30 00:30:17 --> Total execution time: 0.0388
DEBUG - 2022-06-30 00:30:18 --> Total execution time: 0.0409
DEBUG - 2022-06-30 00:36:18 --> Total execution time: 0.1062
DEBUG - 2022-06-30 00:36:38 --> Total execution time: 0.1094
DEBUG - 2022-06-30 00:36:44 --> Total execution time: 0.0481
DEBUG - 2022-06-30 00:36:48 --> Total execution time: 0.0538
DEBUG - 2022-06-30 00:36:53 --> Total execution time: 0.0523
DEBUG - 2022-06-30 00:36:55 --> Total execution time: 0.0607
DEBUG - 2022-06-30 00:37:23 --> Total execution time: 0.0481
DEBUG - 2022-06-30 00:39:22 --> Total execution time: 0.0469
DEBUG - 2022-06-30 00:56:21 --> Total execution time: 0.1139
DEBUG - 2022-06-30 00:57:08 --> Total execution time: 0.0473
DEBUG - 2022-06-30 00:58:18 --> Total execution time: 0.0364
DEBUG - 2022-06-30 01:07:36 --> Total execution time: 0.0874
DEBUG - 2022-06-30 01:08:10 --> Total execution time: 0.0499
DEBUG - 2022-06-30 01:09:01 --> Total execution time: 0.0541
DEBUG - 2022-06-30 01:10:18 --> Total execution time: 0.0704
DEBUG - 2022-06-30 01:10:52 --> Total execution time: 0.0600
DEBUG - 2022-06-30 01:10:57 --> Total execution time: 0.0521
DEBUG - 2022-06-30 01:11:00 --> Total execution time: 0.0556
DEBUG - 2022-06-30 01:11:12 --> Total execution time: 0.0550
DEBUG - 2022-06-30 01:13:31 --> Total execution time: 0.0993
DEBUG - 2022-06-30 01:13:54 --> Total execution time: 0.0351
DEBUG - 2022-06-30 01:14:00 --> Total execution time: 0.0340
DEBUG - 2022-06-30 01:17:02 --> Total execution time: 0.1207
DEBUG - 2022-06-30 01:23:27 --> Total execution time: 0.1804
DEBUG - 2022-06-30 01:23:50 --> Total execution time: 0.0463
DEBUG - 2022-06-30 01:24:28 --> Total execution time: 0.0577
DEBUG - 2022-06-30 01:27:54 --> Total execution time: 0.0436
DEBUG - 2022-06-30 01:30:03 --> Total execution time: 0.1246
DEBUG - 2022-06-30 01:33:41 --> Total execution time: 0.0791
DEBUG - 2022-06-30 01:39:04 --> Total execution time: 0.2024
DEBUG - 2022-06-30 01:39:10 --> Total execution time: 0.0647
DEBUG - 2022-06-30 01:39:13 --> Total execution time: 0.0615
DEBUG - 2022-06-30 01:39:17 --> Total execution time: 0.0413
DEBUG - 2022-06-30 01:39:32 --> Total execution time: 0.0576
DEBUG - 2022-06-30 01:39:41 --> Total execution time: 0.0811
DEBUG - 2022-06-30 01:39:44 --> Total execution time: 0.0525
DEBUG - 2022-06-30 01:39:49 --> Total execution time: 0.0779
DEBUG - 2022-06-30 01:43:01 --> Total execution time: 0.0690
DEBUG - 2022-06-30 01:43:04 --> Total execution time: 0.0685
DEBUG - 2022-06-30 01:43:08 --> Total execution time: 0.0798
DEBUG - 2022-06-30 01:44:06 --> Total execution time: 0.1277
DEBUG - 2022-06-30 01:44:13 --> Total execution time: 0.0478
DEBUG - 2022-06-30 01:52:20 --> Total execution time: 0.0964
DEBUG - 2022-06-30 01:55:24 --> Total execution time: 0.1054
DEBUG - 2022-06-30 01:55:34 --> Total execution time: 0.1188
DEBUG - 2022-06-30 01:55:40 --> Total execution time: 0.0510
DEBUG - 2022-06-30 01:55:43 --> Total execution time: 0.0860
DEBUG - 2022-06-30 01:55:46 --> Total execution time: 0.0554
DEBUG - 2022-06-30 01:55:55 --> Total execution time: 0.0570
DEBUG - 2022-06-30 02:08:04 --> Total execution time: 0.1274
DEBUG - 2022-06-30 02:09:02 --> Total execution time: 0.1420
DEBUG - 2022-06-30 02:09:11 --> Total execution time: 0.0479
DEBUG - 2022-06-30 02:19:58 --> Total execution time: 0.0924
DEBUG - 2022-06-30 02:20:42 --> Total execution time: 0.0333
DEBUG - 2022-06-30 02:21:49 --> Total execution time: 0.0498
DEBUG - 2022-06-30 02:30:03 --> Total execution time: 0.1111
DEBUG - 2022-06-30 02:33:10 --> Total execution time: 0.0848
DEBUG - 2022-06-30 02:33:13 --> Total execution time: 0.0549
DEBUG - 2022-06-30 02:33:30 --> Total execution time: 0.0614
DEBUG - 2022-06-30 02:33:34 --> Total execution time: 0.0764
DEBUG - 2022-06-30 02:33:59 --> Total execution time: 0.0701
DEBUG - 2022-06-30 02:35:15 --> Total execution time: 0.0592
DEBUG - 2022-06-30 02:35:19 --> Total execution time: 0.0642
DEBUG - 2022-06-30 02:35:38 --> Total execution time: 0.0617
DEBUG - 2022-06-30 02:39:42 --> Total execution time: 0.0524
DEBUG - 2022-06-30 02:39:57 --> Total execution time: 0.0564
DEBUG - 2022-06-30 02:40:05 --> Total execution time: 0.0580
DEBUG - 2022-06-30 02:40:08 --> Total execution time: 0.0515
DEBUG - 2022-06-30 02:40:16 --> Total execution time: 0.0457
DEBUG - 2022-06-30 02:40:18 --> Total execution time: 0.0460
DEBUG - 2022-06-30 02:40:20 --> Total execution time: 0.0862
DEBUG - 2022-06-30 02:40:29 --> Total execution time: 0.0550
DEBUG - 2022-06-30 02:40:32 --> Total execution time: 0.0432
DEBUG - 2022-06-30 02:56:08 --> Total execution time: 0.1085
DEBUG - 2022-06-30 02:56:08 --> Total execution time: 0.0293
DEBUG - 2022-06-30 03:14:54 --> Total execution time: 0.0592
DEBUG - 2022-06-30 03:14:58 --> Total execution time: 0.0448
DEBUG - 2022-06-30 03:15:10 --> Total execution time: 0.0756
DEBUG - 2022-06-30 03:15:15 --> Total execution time: 0.0695
DEBUG - 2022-06-30 03:15:20 --> Total execution time: 0.0676
DEBUG - 2022-06-30 03:15:45 --> Total execution time: 0.0475
DEBUG - 2022-06-30 03:22:31 --> Total execution time: 0.1323
DEBUG - 2022-06-30 03:29:52 --> Total execution time: 0.1668
DEBUG - 2022-06-30 03:29:56 --> Total execution time: 0.0597
DEBUG - 2022-06-30 03:30:04 --> Total execution time: 0.1085
DEBUG - 2022-06-30 03:30:16 --> Total execution time: 0.0468
DEBUG - 2022-06-30 03:36:21 --> Total execution time: 0.0978
DEBUG - 2022-06-30 03:38:17 --> Total execution time: 0.0463
DEBUG - 2022-06-30 03:38:32 --> Total execution time: 0.1277
DEBUG - 2022-06-30 03:38:38 --> Total execution time: 0.0582
DEBUG - 2022-06-30 03:38:50 --> Total execution time: 0.0450
DEBUG - 2022-06-30 03:39:06 --> Total execution time: 0.0558
DEBUG - 2022-06-30 03:39:12 --> Total execution time: 0.0589
DEBUG - 2022-06-30 03:39:30 --> Total execution time: 0.0465
DEBUG - 2022-06-30 03:40:10 --> Total execution time: 0.0615
DEBUG - 2022-06-30 03:40:19 --> Total execution time: 0.0583
DEBUG - 2022-06-30 03:40:24 --> Total execution time: 0.0588
DEBUG - 2022-06-30 03:40:27 --> Total execution time: 0.0553
DEBUG - 2022-06-30 03:54:49 --> Total execution time: 0.1003
DEBUG - 2022-06-30 04:02:01 --> Total execution time: 0.1551
DEBUG - 2022-06-30 04:15:40 --> Total execution time: 0.2328
DEBUG - 2022-06-30 04:15:47 --> Total execution time: 0.0547
DEBUG - 2022-06-30 04:16:12 --> Total execution time: 0.0475
DEBUG - 2022-06-30 04:16:12 --> Total execution time: 0.0867
DEBUG - 2022-06-30 04:16:12 --> Total execution time: 0.0510
DEBUG - 2022-06-30 04:16:14 --> Total execution time: 0.0527
DEBUG - 2022-06-30 04:16:19 --> Total execution time: 0.0501
DEBUG - 2022-06-30 04:16:28 --> Total execution time: 0.0683
DEBUG - 2022-06-30 04:16:38 --> Total execution time: 0.0492
DEBUG - 2022-06-30 04:16:44 --> Total execution time: 0.1040
DEBUG - 2022-06-30 04:18:04 --> Total execution time: 0.0540
DEBUG - 2022-06-30 04:18:12 --> Total execution time: 0.0501
DEBUG - 2022-06-30 04:30:02 --> Total execution time: 0.1085
DEBUG - 2022-06-30 05:25:08 --> Total execution time: 0.2578
DEBUG - 2022-06-30 05:25:09 --> Total execution time: 0.0382
DEBUG - 2022-06-30 05:30:03 --> Total execution time: 0.1241
DEBUG - 2022-06-30 05:37:29 --> Total execution time: 0.1185
DEBUG - 2022-06-30 05:37:42 --> Total execution time: 0.0397
DEBUG - 2022-06-30 05:37:52 --> Total execution time: 0.0673
DEBUG - 2022-06-30 05:37:59 --> Total execution time: 0.0695
DEBUG - 2022-06-30 05:38:03 --> Total execution time: 0.0651
DEBUG - 2022-06-30 05:38:08 --> Total execution time: 0.0584
DEBUG - 2022-06-30 05:38:15 --> Total execution time: 0.0430
DEBUG - 2022-06-30 05:38:17 --> Total execution time: 0.0554
DEBUG - 2022-06-30 05:39:27 --> Total execution time: 0.0533
DEBUG - 2022-06-30 06:04:52 --> Total execution time: 0.1332
DEBUG - 2022-06-30 06:06:17 --> Total execution time: 0.0313
DEBUG - 2022-06-30 06:24:00 --> Total execution time: 0.1275
DEBUG - 2022-06-30 06:25:41 --> Total execution time: 0.0471
DEBUG - 2022-06-30 06:30:03 --> Total execution time: 0.1449
DEBUG - 2022-06-30 06:31:45 --> Total execution time: 0.0529
DEBUG - 2022-06-30 06:31:49 --> Total execution time: 0.0476
DEBUG - 2022-06-30 06:31:56 --> Total execution time: 0.0801
DEBUG - 2022-06-30 06:32:00 --> Total execution time: 0.0547
DEBUG - 2022-06-30 06:32:06 --> Total execution time: 0.0479
DEBUG - 2022-06-30 06:32:25 --> Total execution time: 0.0737
DEBUG - 2022-06-30 06:34:43 --> Total execution time: 0.1193
DEBUG - 2022-06-30 06:34:49 --> Total execution time: 0.0561
DEBUG - 2022-06-30 06:34:52 --> Total execution time: 0.0577
DEBUG - 2022-06-30 06:35:06 --> Total execution time: 0.0729
DEBUG - 2022-06-30 06:36:45 --> Total execution time: 0.0583
DEBUG - 2022-06-30 06:36:48 --> Total execution time: 0.0442
DEBUG - 2022-06-30 06:36:56 --> Total execution time: 0.0446
DEBUG - 2022-06-30 06:37:03 --> Total execution time: 0.0481
DEBUG - 2022-06-30 06:37:08 --> Total execution time: 0.0769
DEBUG - 2022-06-30 06:37:16 --> Total execution time: 0.0472
DEBUG - 2022-06-30 06:37:20 --> Total execution time: 0.0434
DEBUG - 2022-06-30 06:37:24 --> Total execution time: 0.0436
DEBUG - 2022-06-30 06:37:43 --> Total execution time: 0.0601
DEBUG - 2022-06-30 06:37:46 --> Total execution time: 0.0468
DEBUG - 2022-06-30 06:38:26 --> Total execution time: 0.0306
DEBUG - 2022-06-30 06:46:50 --> Total execution time: 0.0895
DEBUG - 2022-06-30 06:50:09 --> Total execution time: 0.1081
DEBUG - 2022-06-30 06:50:37 --> Total execution time: 0.0403
DEBUG - 2022-06-30 07:12:21 --> Total execution time: 0.1064
DEBUG - 2022-06-30 07:21:30 --> Total execution time: 0.0583
DEBUG - 2022-06-30 07:24:53 --> Total execution time: 0.1938
DEBUG - 2022-06-30 07:25:01 --> Total execution time: 0.0920
DEBUG - 2022-06-30 07:25:30 --> Total execution time: 0.0722
DEBUG - 2022-06-30 07:25:32 --> Total execution time: 0.0451
DEBUG - 2022-06-30 07:25:36 --> Total execution time: 0.0446
DEBUG - 2022-06-30 07:25:40 --> Total execution time: 0.0561
DEBUG - 2022-06-30 07:25:53 --> Total execution time: 0.0498
DEBUG - 2022-06-30 07:25:56 --> Total execution time: 0.0492
DEBUG - 2022-06-30 07:29:28 --> Total execution time: 0.0878
DEBUG - 2022-06-30 07:30:03 --> Total execution time: 0.0919
DEBUG - 2022-06-30 07:30:09 --> Total execution time: 0.0632
DEBUG - 2022-06-30 07:30:16 --> Total execution time: 0.0486
DEBUG - 2022-06-30 07:30:41 --> Total execution time: 0.0588
DEBUG - 2022-06-30 07:30:48 --> Total execution time: 0.0743
DEBUG - 2022-06-30 07:31:00 --> Total execution time: 0.0540
DEBUG - 2022-06-30 07:36:36 --> Total execution time: 0.0709
DEBUG - 2022-06-30 07:37:37 --> Total execution time: 0.0568
DEBUG - 2022-06-30 07:39:31 --> Total execution time: 0.0386
DEBUG - 2022-06-30 07:39:32 --> Total execution time: 0.0328
DEBUG - 2022-06-30 07:41:54 --> Total execution time: 0.1750
DEBUG - 2022-06-30 07:41:58 --> Total execution time: 0.0520
DEBUG - 2022-06-30 07:42:13 --> Total execution time: 0.0551
DEBUG - 2022-06-30 07:42:15 --> Total execution time: 0.0754
DEBUG - 2022-06-30 07:42:24 --> Total execution time: 0.0867
DEBUG - 2022-06-30 07:43:19 --> Total execution time: 0.0459
DEBUG - 2022-06-30 07:43:27 --> Total execution time: 0.0477
DEBUG - 2022-06-30 07:43:35 --> Total execution time: 0.0662
DEBUG - 2022-06-30 07:43:39 --> Total execution time: 0.0710
DEBUG - 2022-06-30 07:43:50 --> Total execution time: 0.0711
DEBUG - 2022-06-30 07:43:53 --> Total execution time: 0.0659
DEBUG - 2022-06-30 07:52:01 --> Total execution time: 0.1720
DEBUG - 2022-06-30 07:52:06 --> Total execution time: 0.0411
DEBUG - 2022-06-30 07:52:14 --> Total execution time: 0.0456
DEBUG - 2022-06-30 07:52:17 --> Total execution time: 0.0309
DEBUG - 2022-06-30 07:52:21 --> Total execution time: 0.0882
DEBUG - 2022-06-30 07:52:25 --> Total execution time: 0.0447
DEBUG - 2022-06-30 07:52:34 --> Total execution time: 0.0550
DEBUG - 2022-06-30 07:52:40 --> Total execution time: 0.0556
DEBUG - 2022-06-30 07:52:44 --> Total execution time: 0.0793
DEBUG - 2022-06-30 07:52:54 --> Total execution time: 0.0730
DEBUG - 2022-06-30 07:53:03 --> Total execution time: 0.0551
DEBUG - 2022-06-30 07:53:17 --> Total execution time: 0.0822
DEBUG - 2022-06-30 07:53:35 --> Total execution time: 0.0800
DEBUG - 2022-06-30 07:55:15 --> Total execution time: 0.0314
DEBUG - 2022-06-30 08:06:33 --> Total execution time: 0.1164
DEBUG - 2022-06-30 08:06:38 --> Total execution time: 0.0596
DEBUG - 2022-06-30 08:07:19 --> Total execution time: 0.0413
DEBUG - 2022-06-30 08:07:28 --> Total execution time: 0.0527
DEBUG - 2022-06-30 08:07:34 --> Total execution time: 0.0496
DEBUG - 2022-06-30 08:07:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 08:07:35 --> Total execution time: 0.0407
DEBUG - 2022-06-30 08:12:42 --> Total execution time: 0.0460
DEBUG - 2022-06-30 08:13:03 --> Total execution time: 0.0469
DEBUG - 2022-06-30 08:13:08 --> Total execution time: 0.0725
DEBUG - 2022-06-30 08:13:13 --> Total execution time: 0.0648
DEBUG - 2022-06-30 08:13:18 --> Total execution time: 0.0561
DEBUG - 2022-06-30 08:13:58 --> Total execution time: 0.0665
DEBUG - 2022-06-30 08:14:03 --> Total execution time: 0.0369
DEBUG - 2022-06-30 08:14:03 --> Total execution time: 0.0587
DEBUG - 2022-06-30 08:14:16 --> Total execution time: 0.0505
DEBUG - 2022-06-30 08:14:17 --> Total execution time: 0.0487
DEBUG - 2022-06-30 08:14:27 --> Total execution time: 0.0513
DEBUG - 2022-06-30 08:14:30 --> Total execution time: 0.0693
DEBUG - 2022-06-30 08:14:32 --> Total execution time: 0.0338
DEBUG - 2022-06-30 08:14:36 --> Total execution time: 0.0315
DEBUG - 2022-06-30 08:14:40 --> Total execution time: 0.0550
DEBUG - 2022-06-30 08:14:44 --> Total execution time: 0.0530
DEBUG - 2022-06-30 08:14:48 --> Total execution time: 0.0688
DEBUG - 2022-06-30 08:14:51 --> Total execution time: 0.0538
DEBUG - 2022-06-30 08:15:06 --> Total execution time: 0.0518
DEBUG - 2022-06-30 08:15:12 --> Total execution time: 0.0503
DEBUG - 2022-06-30 08:15:26 --> Total execution time: 0.0624
DEBUG - 2022-06-30 08:15:29 --> Total execution time: 0.1281
DEBUG - 2022-06-30 08:15:30 --> Total execution time: 0.0598
DEBUG - 2022-06-30 08:15:33 --> Total execution time: 0.0871
DEBUG - 2022-06-30 08:15:46 --> Total execution time: 0.0591
DEBUG - 2022-06-30 08:16:04 --> Total execution time: 0.0574
DEBUG - 2022-06-30 08:16:04 --> Total execution time: 0.0542
DEBUG - 2022-06-30 08:16:07 --> Total execution time: 0.0782
DEBUG - 2022-06-30 08:16:10 --> Total execution time: 0.0702
DEBUG - 2022-06-30 08:16:15 --> Total execution time: 0.0978
DEBUG - 2022-06-30 08:16:25 --> Total execution time: 0.1396
DEBUG - 2022-06-30 08:16:37 --> Total execution time: 0.0781
DEBUG - 2022-06-30 08:16:41 --> Total execution time: 0.0794
DEBUG - 2022-06-30 08:16:45 --> Total execution time: 0.0797
DEBUG - 2022-06-30 08:18:36 --> Total execution time: 0.0594
DEBUG - 2022-06-30 08:21:32 --> Total execution time: 0.1407
DEBUG - 2022-06-30 08:21:51 --> Total execution time: 0.0458
DEBUG - 2022-06-30 08:23:04 --> Total execution time: 0.1214
DEBUG - 2022-06-30 08:23:07 --> Total execution time: 0.0704
DEBUG - 2022-06-30 08:23:39 --> Total execution time: 1.9289
DEBUG - 2022-06-30 08:23:41 --> Total execution time: 0.0484
DEBUG - 2022-06-30 08:23:42 --> Total execution time: 0.0484
DEBUG - 2022-06-30 08:23:57 --> Total execution time: 0.0558
DEBUG - 2022-06-30 08:24:04 --> Total execution time: 0.0558
DEBUG - 2022-06-30 08:24:05 --> Total execution time: 0.0496
DEBUG - 2022-06-30 08:24:17 --> Total execution time: 0.0494
DEBUG - 2022-06-30 08:24:19 --> Total execution time: 0.0567
DEBUG - 2022-06-30 08:24:26 --> Total execution time: 0.0462
DEBUG - 2022-06-30 08:24:26 --> Total execution time: 0.0532
DEBUG - 2022-06-30 08:24:29 --> Total execution time: 0.0630
DEBUG - 2022-06-30 08:24:38 --> Total execution time: 0.0500
DEBUG - 2022-06-30 08:24:53 --> Total execution time: 0.0505
DEBUG - 2022-06-30 08:24:55 --> Total execution time: 0.0905
DEBUG - 2022-06-30 08:25:09 --> Total execution time: 0.0504
DEBUG - 2022-06-30 08:26:05 --> Total execution time: 0.0411
DEBUG - 2022-06-30 08:26:16 --> Total execution time: 0.0504
DEBUG - 2022-06-30 08:26:38 --> Total execution time: 0.0444
DEBUG - 2022-06-30 08:26:56 --> Total execution time: 0.0475
DEBUG - 2022-06-30 08:26:57 --> Total execution time: 0.0280
DEBUG - 2022-06-30 08:27:19 --> Total execution time: 0.0534
DEBUG - 2022-06-30 08:27:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 08:27:20 --> Total execution time: 0.0533
DEBUG - 2022-06-30 08:28:25 --> Total execution time: 0.0617
DEBUG - 2022-06-30 08:28:28 --> Total execution time: 0.0543
DEBUG - 2022-06-30 08:28:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 08:28:30 --> Total execution time: 0.0495
DEBUG - 2022-06-30 08:29:14 --> Total execution time: 0.0525
DEBUG - 2022-06-30 08:29:49 --> Total execution time: 0.0497
DEBUG - 2022-06-30 08:29:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 08:29:50 --> Total execution time: 0.0503
DEBUG - 2022-06-30 08:30:02 --> Total execution time: 0.0742
DEBUG - 2022-06-30 08:30:21 --> Total execution time: 0.0523
DEBUG - 2022-06-30 08:30:23 --> Total execution time: 0.0480
DEBUG - 2022-06-30 08:30:37 --> Total execution time: 0.0487
DEBUG - 2022-06-30 08:30:46 --> Total execution time: 0.0460
DEBUG - 2022-06-30 08:30:59 --> Total execution time: 0.0492
DEBUG - 2022-06-30 08:31:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 08:31:00 --> Total execution time: 0.0584
DEBUG - 2022-06-30 08:31:25 --> Total execution time: 0.1118
DEBUG - 2022-06-30 08:31:25 --> Total execution time: 0.0462
DEBUG - 2022-06-30 08:31:27 --> Total execution time: 0.0568
DEBUG - 2022-06-30 08:31:41 --> Total execution time: 0.0485
DEBUG - 2022-06-30 08:31:50 --> Total execution time: 0.0497
DEBUG - 2022-06-30 08:31:53 --> Total execution time: 0.0705
DEBUG - 2022-06-30 08:31:53 --> Total execution time: 0.0484
DEBUG - 2022-06-30 08:31:57 --> Total execution time: 0.0554
DEBUG - 2022-06-30 08:32:06 --> Total execution time: 0.0522
DEBUG - 2022-06-30 08:32:21 --> Total execution time: 0.0511
DEBUG - 2022-06-30 08:32:22 --> Total execution time: 0.0422
DEBUG - 2022-06-30 08:32:27 --> Total execution time: 0.0484
DEBUG - 2022-06-30 08:32:42 --> Total execution time: 0.0444
DEBUG - 2022-06-30 08:32:55 --> Total execution time: 0.0773
DEBUG - 2022-06-30 08:32:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 08:32:56 --> Total execution time: 0.0379
DEBUG - 2022-06-30 08:33:20 --> Total execution time: 0.0966
DEBUG - 2022-06-30 08:33:21 --> Total execution time: 0.1842
DEBUG - 2022-06-30 08:33:25 --> Total execution time: 0.0740
DEBUG - 2022-06-30 08:33:25 --> Total execution time: 0.0584
DEBUG - 2022-06-30 08:33:26 --> Total execution time: 0.0561
DEBUG - 2022-06-30 08:35:03 --> Total execution time: 0.0456
DEBUG - 2022-06-30 08:39:15 --> Total execution time: 0.0875
DEBUG - 2022-06-30 08:39:16 --> Total execution time: 0.0331
DEBUG - 2022-06-30 08:39:23 --> Total execution time: 0.0367
DEBUG - 2022-06-30 08:39:32 --> Total execution time: 0.0538
DEBUG - 2022-06-30 08:39:48 --> Total execution time: 0.0776
DEBUG - 2022-06-30 08:40:02 --> Total execution time: 0.0565
DEBUG - 2022-06-30 08:40:07 --> Total execution time: 0.0491
DEBUG - 2022-06-30 08:40:14 --> Total execution time: 0.0669
DEBUG - 2022-06-30 08:40:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 08:40:15 --> Total execution time: 0.0461
DEBUG - 2022-06-30 08:41:17 --> Total execution time: 0.0585
DEBUG - 2022-06-30 08:52:34 --> Total execution time: 0.1123
DEBUG - 2022-06-30 08:52:34 --> Total execution time: 0.0544
DEBUG - 2022-06-30 08:53:48 --> Total execution time: 0.0384
DEBUG - 2022-06-30 08:53:52 --> Total execution time: 0.0352
DEBUG - 2022-06-30 08:54:10 --> Total execution time: 0.0775
DEBUG - 2022-06-30 08:54:13 --> Total execution time: 0.0874
DEBUG - 2022-06-30 08:54:20 --> Total execution time: 0.0615
DEBUG - 2022-06-30 08:54:54 --> Total execution time: 0.1184
DEBUG - 2022-06-30 08:54:58 --> Total execution time: 0.0436
DEBUG - 2022-06-30 08:55:09 --> Total execution time: 0.0496
DEBUG - 2022-06-30 08:55:12 --> Total execution time: 0.0546
DEBUG - 2022-06-30 08:56:51 --> Total execution time: 0.0555
DEBUG - 2022-06-30 08:56:57 --> Total execution time: 0.0514
DEBUG - 2022-06-30 08:57:03 --> Total execution time: 0.0487
DEBUG - 2022-06-30 08:57:11 --> Total execution time: 0.0485
DEBUG - 2022-06-30 09:03:46 --> Total execution time: 0.1023
DEBUG - 2022-06-30 09:03:49 --> Total execution time: 0.0368
DEBUG - 2022-06-30 09:03:59 --> Total execution time: 0.0619
DEBUG - 2022-06-30 09:06:25 --> Total execution time: 0.0456
DEBUG - 2022-06-30 09:06:40 --> Total execution time: 0.0638
DEBUG - 2022-06-30 09:06:50 --> Total execution time: 0.0543
DEBUG - 2022-06-30 09:07:00 --> Total execution time: 0.1252
DEBUG - 2022-06-30 09:07:05 --> Total execution time: 0.0514
DEBUG - 2022-06-30 09:07:13 --> Total execution time: 0.0914
DEBUG - 2022-06-30 09:07:20 --> Total execution time: 0.0831
DEBUG - 2022-06-30 09:08:07 --> Total execution time: 0.0724
DEBUG - 2022-06-30 09:08:10 --> Total execution time: 0.0779
DEBUG - 2022-06-30 09:08:11 --> Total execution time: 0.0825
DEBUG - 2022-06-30 09:08:13 --> Total execution time: 0.0795
DEBUG - 2022-06-30 09:08:18 --> Total execution time: 0.0603
DEBUG - 2022-06-30 09:17:06 --> Total execution time: 0.0571
DEBUG - 2022-06-30 09:17:11 --> Total execution time: 0.0967
DEBUG - 2022-06-30 09:18:16 --> Total execution time: 1.8680
DEBUG - 2022-06-30 09:19:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 09:19:18 --> Total execution time: 0.0491
DEBUG - 2022-06-30 09:19:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 09:19:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 09:19:19 --> Total execution time: 0.1907
DEBUG - 2022-06-30 09:21:24 --> Total execution time: 0.1034
DEBUG - 2022-06-30 09:21:28 --> Total execution time: 0.0414
DEBUG - 2022-06-30 09:21:33 --> Total execution time: 0.0890
DEBUG - 2022-06-30 09:21:38 --> Total execution time: 0.0583
DEBUG - 2022-06-30 09:21:49 --> Total execution time: 0.0617
DEBUG - 2022-06-30 09:21:54 --> Total execution time: 0.0600
DEBUG - 2022-06-30 09:21:58 --> Total execution time: 0.0554
DEBUG - 2022-06-30 09:22:48 --> Total execution time: 0.0572
DEBUG - 2022-06-30 09:22:52 --> Total execution time: 0.0721
DEBUG - 2022-06-30 09:22:55 --> Total execution time: 0.1382
DEBUG - 2022-06-30 09:23:02 --> Total execution time: 0.0568
DEBUG - 2022-06-30 09:23:05 --> Total execution time: 0.0676
DEBUG - 2022-06-30 09:23:06 --> Total execution time: 0.0352
DEBUG - 2022-06-30 09:23:07 --> Total execution time: 0.0484
DEBUG - 2022-06-30 09:23:12 --> Total execution time: 0.0797
DEBUG - 2022-06-30 09:23:18 --> Total execution time: 0.1228
DEBUG - 2022-06-30 09:23:18 --> Total execution time: 0.0398
DEBUG - 2022-06-30 09:23:42 --> Total execution time: 0.0570
DEBUG - 2022-06-30 09:23:44 --> Total execution time: 0.0572
DEBUG - 2022-06-30 09:23:51 --> Total execution time: 0.0885
DEBUG - 2022-06-30 09:23:56 --> Total execution time: 0.1569
DEBUG - 2022-06-30 09:30:02 --> Total execution time: 0.1062
DEBUG - 2022-06-30 09:30:18 --> Total execution time: 0.1349
DEBUG - 2022-06-30 09:30:48 --> Total execution time: 0.0389
DEBUG - 2022-06-30 09:34:10 --> Total execution time: 0.1335
DEBUG - 2022-06-30 09:34:13 --> Total execution time: 0.0343
DEBUG - 2022-06-30 09:34:26 --> Total execution time: 0.0835
DEBUG - 2022-06-30 09:34:32 --> Total execution time: 0.1178
DEBUG - 2022-06-30 09:35:04 --> Total execution time: 0.1622
DEBUG - 2022-06-30 09:35:13 --> Total execution time: 0.0664
DEBUG - 2022-06-30 09:35:16 --> Total execution time: 0.0667
DEBUG - 2022-06-30 09:35:22 --> Total execution time: 0.1038
DEBUG - 2022-06-30 09:37:45 --> Total execution time: 0.1587
DEBUG - 2022-06-30 09:38:17 --> Total execution time: 0.0420
DEBUG - 2022-06-30 09:39:18 --> Total execution time: 0.0519
DEBUG - 2022-06-30 09:40:05 --> Total execution time: 0.0466
DEBUG - 2022-06-30 09:40:26 --> Total execution time: 0.0501
DEBUG - 2022-06-30 09:40:33 --> Total execution time: 0.0720
DEBUG - 2022-06-30 09:40:40 --> Total execution time: 0.0728
DEBUG - 2022-06-30 09:44:37 --> Total execution time: 0.1264
DEBUG - 2022-06-30 09:47:33 --> Total execution time: 0.0617
DEBUG - 2022-06-30 09:47:44 --> Total execution time: 0.0478
DEBUG - 2022-06-30 09:47:52 --> Total execution time: 0.1121
DEBUG - 2022-06-30 09:47:59 --> Total execution time: 0.0715
DEBUG - 2022-06-30 09:48:47 --> Total execution time: 0.0739
DEBUG - 2022-06-30 09:48:50 --> Total execution time: 0.0640
DEBUG - 2022-06-30 09:48:50 --> Total execution time: 0.0612
DEBUG - 2022-06-30 09:51:18 --> Total execution time: 0.1383
DEBUG - 2022-06-30 09:51:18 --> Total execution time: 0.0530
DEBUG - 2022-06-30 09:51:29 --> Total execution time: 0.0607
DEBUG - 2022-06-30 09:51:35 --> Total execution time: 0.0889
DEBUG - 2022-06-30 09:52:04 --> Total execution time: 0.0553
DEBUG - 2022-06-30 09:52:26 --> Total execution time: 0.0632
DEBUG - 2022-06-30 09:52:27 --> Total execution time: 0.0562
DEBUG - 2022-06-30 09:52:50 --> Total execution time: 0.0346
DEBUG - 2022-06-30 09:52:52 --> Total execution time: 0.0552
DEBUG - 2022-06-30 09:52:59 --> Total execution time: 0.0436
DEBUG - 2022-06-30 09:53:01 --> Total execution time: 0.0746
DEBUG - 2022-06-30 09:53:11 --> Total execution time: 0.1342
DEBUG - 2022-06-30 09:53:19 --> Total execution time: 0.0565
DEBUG - 2022-06-30 09:53:20 --> Total execution time: 0.0525
DEBUG - 2022-06-30 09:53:22 --> Total execution time: 0.0797
DEBUG - 2022-06-30 09:53:27 --> Total execution time: 0.0558
DEBUG - 2022-06-30 09:53:35 --> Total execution time: 0.1341
DEBUG - 2022-06-30 09:53:42 --> Total execution time: 0.0570
DEBUG - 2022-06-30 09:53:46 --> Total execution time: 0.0553
DEBUG - 2022-06-30 09:53:54 --> Total execution time: 0.0527
DEBUG - 2022-06-30 09:54:00 --> Total execution time: 0.0622
DEBUG - 2022-06-30 09:54:01 --> Total execution time: 0.0634
DEBUG - 2022-06-30 09:54:24 --> Total execution time: 0.0501
DEBUG - 2022-06-30 09:54:27 --> Total execution time: 0.0607
DEBUG - 2022-06-30 09:54:39 --> Total execution time: 0.0668
DEBUG - 2022-06-30 09:54:43 --> Total execution time: 0.1021
DEBUG - 2022-06-30 09:54:46 --> Total execution time: 0.0568
DEBUG - 2022-06-30 09:54:51 --> Total execution time: 0.0524
DEBUG - 2022-06-30 09:57:41 --> Total execution time: 0.1383
DEBUG - 2022-06-30 09:58:49 --> Total execution time: 0.0817
DEBUG - 2022-06-30 09:58:57 --> Total execution time: 0.0525
DEBUG - 2022-06-30 09:59:07 --> Total execution time: 0.0570
DEBUG - 2022-06-30 09:59:17 --> Total execution time: 0.0311
DEBUG - 2022-06-30 09:59:27 --> Total execution time: 0.0513
DEBUG - 2022-06-30 09:59:28 --> Total execution time: 0.0707
DEBUG - 2022-06-30 09:59:30 --> Total execution time: 0.0914
DEBUG - 2022-06-30 09:59:45 --> Total execution time: 0.0490
DEBUG - 2022-06-30 10:02:29 --> Total execution time: 0.1052
DEBUG - 2022-06-30 10:03:00 --> Total execution time: 0.0701
DEBUG - 2022-06-30 10:03:08 --> Total execution time: 0.0485
DEBUG - 2022-06-30 10:03:13 --> Total execution time: 0.0529
DEBUG - 2022-06-30 10:03:14 --> Total execution time: 0.0426
DEBUG - 2022-06-30 10:03:17 --> Total execution time: 0.0576
DEBUG - 2022-06-30 10:04:25 --> Total execution time: 0.0542
DEBUG - 2022-06-30 10:04:36 --> Total execution time: 0.0537
DEBUG - 2022-06-30 10:04:54 --> Total execution time: 0.0452
DEBUG - 2022-06-30 10:05:19 --> Total execution time: 0.0517
DEBUG - 2022-06-30 10:05:47 --> Total execution time: 0.0683
DEBUG - 2022-06-30 10:15:05 --> Total execution time: 0.1275
DEBUG - 2022-06-30 10:16:13 --> Total execution time: 0.1848
DEBUG - 2022-06-30 10:17:11 --> Total execution time: 0.0477
DEBUG - 2022-06-30 10:17:28 --> Total execution time: 0.0409
DEBUG - 2022-06-30 10:17:31 --> Total execution time: 0.0465
DEBUG - 2022-06-30 10:17:56 --> Total execution time: 0.0621
DEBUG - 2022-06-30 10:18:05 --> Total execution time: 0.0651
DEBUG - 2022-06-30 10:18:06 --> Total execution time: 0.0637
DEBUG - 2022-06-30 10:18:11 --> Total execution time: 0.0638
DEBUG - 2022-06-30 10:18:15 --> Total execution time: 0.0925
DEBUG - 2022-06-30 10:18:25 --> Total execution time: 0.0681
DEBUG - 2022-06-30 10:18:27 --> Total execution time: 0.0582
DEBUG - 2022-06-30 10:18:36 --> Total execution time: 0.1056
DEBUG - 2022-06-30 10:18:40 --> Total execution time: 0.0505
DEBUG - 2022-06-30 10:19:23 --> Total execution time: 0.0312
DEBUG - 2022-06-30 10:20:32 --> Total execution time: 0.0467
DEBUG - 2022-06-30 10:20:43 --> Total execution time: 0.0555
DEBUG - 2022-06-30 10:21:24 --> Total execution time: 0.0454
DEBUG - 2022-06-30 10:21:24 --> Total execution time: 0.0509
DEBUG - 2022-06-30 10:21:28 --> Total execution time: 0.0596
DEBUG - 2022-06-30 10:21:33 --> Total execution time: 0.0502
DEBUG - 2022-06-30 10:22:05 --> Total execution time: 0.0487
DEBUG - 2022-06-30 10:22:06 --> Total execution time: 0.0587
DEBUG - 2022-06-30 10:26:56 --> Total execution time: 0.0546
DEBUG - 2022-06-30 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:30:02 --> Total execution time: 0.2494
DEBUG - 2022-06-30 00:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:00:19 --> No URI present. Default controller set.
DEBUG - 2022-06-30 00:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:30:19 --> Total execution time: 0.0738
DEBUG - 2022-06-30 00:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 00:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:39:38 --> Total execution time: 0.0712
DEBUG - 2022-06-30 00:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:39:42 --> Total execution time: 0.0583
DEBUG - 2022-06-30 00:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:15:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 00:15:38 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 00:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:21:10 --> No URI present. Default controller set.
DEBUG - 2022-06-30 00:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:51:10 --> Total execution time: 0.2232
DEBUG - 2022-06-30 00:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:24:42 --> No URI present. Default controller set.
DEBUG - 2022-06-30 00:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:54:42 --> Total execution time: 0.1660
DEBUG - 2022-06-30 00:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:24:48 --> No URI present. Default controller set.
DEBUG - 2022-06-30 00:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:54:48 --> Total execution time: 0.0778
DEBUG - 2022-06-30 00:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:55:00 --> Total execution time: 0.0370
DEBUG - 2022-06-30 00:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 00:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:55:08 --> Total execution time: 0.0944
DEBUG - 2022-06-30 00:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:55:36 --> Total execution time: 0.0896
DEBUG - 2022-06-30 00:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:00:56 --> Total execution time: 0.1217
DEBUG - 2022-06-30 00:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:01:13 --> Total execution time: 0.0344
DEBUG - 2022-06-30 00:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:01:13 --> Total execution time: 0.0316
DEBUG - 2022-06-30 00:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:31:52 --> No URI present. Default controller set.
DEBUG - 2022-06-30 00:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:01:52 --> Total execution time: 0.0512
DEBUG - 2022-06-30 00:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:01:58 --> Total execution time: 0.0551
DEBUG - 2022-06-30 00:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:02:05 --> Total execution time: 0.0517
DEBUG - 2022-06-30 00:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:02:06 --> Total execution time: 0.0780
DEBUG - 2022-06-30 00:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 00:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:02:09 --> Total execution time: 0.0672
DEBUG - 2022-06-30 00:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:02:14 --> Total execution time: 0.0624
DEBUG - 2022-06-30 00:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:02:19 --> Total execution time: 0.0671
DEBUG - 2022-06-30 00:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:02:41 --> Total execution time: 0.0644
DEBUG - 2022-06-30 00:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:03:31 --> Total execution time: 0.0581
DEBUG - 2022-06-30 00:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:03:43 --> Total execution time: 0.0522
DEBUG - 2022-06-30 00:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:04:46 --> Total execution time: 0.1215
DEBUG - 2022-06-30 00:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:04:46 --> Total execution time: 0.0568
DEBUG - 2022-06-30 00:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:05:03 --> Total execution time: 0.0935
DEBUG - 2022-06-30 00:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:05:23 --> Total execution time: 0.0687
DEBUG - 2022-06-30 00:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:05:28 --> Total execution time: 0.0548
DEBUG - 2022-06-30 00:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:05:52 --> Total execution time: 0.0452
DEBUG - 2022-06-30 00:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:06:33 --> Total execution time: 0.1236
DEBUG - 2022-06-30 00:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:06:37 --> Total execution time: 0.0524
DEBUG - 2022-06-30 00:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:06:45 --> Total execution time: 0.0664
DEBUG - 2022-06-30 00:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:06:58 --> Total execution time: 0.0688
DEBUG - 2022-06-30 00:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:07:07 --> Total execution time: 0.0579
DEBUG - 2022-06-30 00:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:38:04 --> No URI present. Default controller set.
DEBUG - 2022-06-30 00:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:08:04 --> Total execution time: 0.0447
DEBUG - 2022-06-30 00:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:38:05 --> No URI present. Default controller set.
DEBUG - 2022-06-30 00:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:08:05 --> Total execution time: 0.0655
DEBUG - 2022-06-30 00:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:08:17 --> Total execution time: 0.0335
DEBUG - 2022-06-30 00:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:08:24 --> Total execution time: 0.0787
DEBUG - 2022-06-30 00:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:08:31 --> Total execution time: 0.0802
DEBUG - 2022-06-30 00:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:08:33 --> Total execution time: 0.0663
DEBUG - 2022-06-30 00:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:08:37 --> Total execution time: 0.0492
DEBUG - 2022-06-30 00:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:08:41 --> Total execution time: 0.0458
DEBUG - 2022-06-30 00:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 00:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:08:43 --> Total execution time: 0.0532
DEBUG - 2022-06-30 00:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:08:51 --> Total execution time: 0.0491
DEBUG - 2022-06-30 00:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:08:57 --> Total execution time: 0.0787
DEBUG - 2022-06-30 00:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:09:05 --> Total execution time: 0.0559
DEBUG - 2022-06-30 00:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:09:16 --> Total execution time: 0.0907
DEBUG - 2022-06-30 00:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:39:17 --> No URI present. Default controller set.
DEBUG - 2022-06-30 00:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:09:17 --> Total execution time: 0.0427
DEBUG - 2022-06-30 00:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:39:18 --> No URI present. Default controller set.
DEBUG - 2022-06-30 00:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:09:18 --> Total execution time: 0.1614
DEBUG - 2022-06-30 00:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:09:29 --> Total execution time: 0.0640
DEBUG - 2022-06-30 00:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:09:35 --> Total execution time: 0.0580
DEBUG - 2022-06-30 00:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:09:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 00:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:09:36 --> Total execution time: 0.0484
DEBUG - 2022-06-30 00:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:39:41 --> No URI present. Default controller set.
DEBUG - 2022-06-30 00:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:09:41 --> Total execution time: 0.0594
DEBUG - 2022-06-30 00:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:10:29 --> Total execution time: 0.0639
DEBUG - 2022-06-30 00:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:10:30 --> Total execution time: 0.0551
DEBUG - 2022-06-30 00:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:44:51 --> No URI present. Default controller set.
DEBUG - 2022-06-30 00:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:14:51 --> Total execution time: 0.1256
DEBUG - 2022-06-30 00:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:44:52 --> No URI present. Default controller set.
DEBUG - 2022-06-30 00:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:14:53 --> Total execution time: 0.0976
DEBUG - 2022-06-30 00:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:15:16 --> Total execution time: 0.0417
DEBUG - 2022-06-30 00:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 00:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:16:03 --> Total execution time: 0.0911
DEBUG - 2022-06-30 00:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:16:17 --> Total execution time: 0.0840
DEBUG - 2022-06-30 00:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:17:06 --> Total execution time: 0.1340
DEBUG - 2022-06-30 00:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:17:35 --> Total execution time: 0.0692
DEBUG - 2022-06-30 00:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:18:19 --> Total execution time: 0.0978
DEBUG - 2022-06-30 00:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 00:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:18:30 --> Total execution time: 0.0672
DEBUG - 2022-06-30 00:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:56:50 --> No URI present. Default controller set.
DEBUG - 2022-06-30 00:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:26:51 --> Total execution time: 0.2291
DEBUG - 2022-06-30 00:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:27:07 --> Total execution time: 0.0393
DEBUG - 2022-06-30 00:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:29:29 --> Total execution time: 0.1418
DEBUG - 2022-06-30 00:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:29:34 --> Total execution time: 0.0666
DEBUG - 2022-06-30 00:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:59:45 --> No URI present. Default controller set.
DEBUG - 2022-06-30 00:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:29:45 --> Total execution time: 0.0480
DEBUG - 2022-06-30 00:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 00:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 00:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 00:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:29:50 --> Total execution time: 0.0724
DEBUG - 2022-06-30 01:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:30:01 --> Total execution time: 0.0700
DEBUG - 2022-06-30 01:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:30:03 --> Total execution time: 0.0769
DEBUG - 2022-06-30 01:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:30:11 --> Total execution time: 0.1577
DEBUG - 2022-06-30 01:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:30:33 --> Total execution time: 0.0499
DEBUG - 2022-06-30 01:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:00:49 --> Total execution time: 0.0384
DEBUG - 2022-06-30 01:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:30:53 --> Total execution time: 0.0846
DEBUG - 2022-06-30 01:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:00:55 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:30:55 --> Total execution time: 0.0729
DEBUG - 2022-06-30 01:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:01:00 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:31:00 --> Total execution time: 0.0605
DEBUG - 2022-06-30 01:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:32:45 --> Total execution time: 0.0705
DEBUG - 2022-06-30 01:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:33:07 --> Total execution time: 0.0494
DEBUG - 2022-06-30 01:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:34:53 --> Total execution time: 0.1344
DEBUG - 2022-06-30 01:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:12:43 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:42:43 --> Total execution time: 0.1547
DEBUG - 2022-06-30 01:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:42:46 --> Total execution time: 0.0328
DEBUG - 2022-06-30 01:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:42:54 --> Total execution time: 0.0619
DEBUG - 2022-06-30 01:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:42:59 --> Total execution time: 0.0769
DEBUG - 2022-06-30 01:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:43:01 --> Total execution time: 0.0695
DEBUG - 2022-06-30 01:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:15:22 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:45:22 --> Total execution time: 0.1090
DEBUG - 2022-06-30 01:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:15:25 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:45:25 --> Total execution time: 0.0530
DEBUG - 2022-06-30 01:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:15:39 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:45:39 --> Total execution time: 0.0442
DEBUG - 2022-06-30 01:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:45:41 --> Total execution time: 0.0543
DEBUG - 2022-06-30 01:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:15:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:45:57 --> Total execution time: 0.0459
DEBUG - 2022-06-30 01:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:16:33 --> Total execution time: 0.0495
DEBUG - 2022-06-30 01:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:16:34 --> Total execution time: 0.1026
DEBUG - 2022-06-30 01:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:16:34 --> Total execution time: 0.1494
DEBUG - 2022-06-30 01:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:16:37 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:46:37 --> Total execution time: 0.0542
DEBUG - 2022-06-30 01:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:17:59 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:47:59 --> Total execution time: 0.1169
DEBUG - 2022-06-30 01:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:48:03 --> Total execution time: 0.0551
DEBUG - 2022-06-30 01:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:48:05 --> Total execution time: 0.0574
DEBUG - 2022-06-30 01:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:48:20 --> Total execution time: 0.0555
DEBUG - 2022-06-30 01:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:48:30 --> Total execution time: 0.0704
DEBUG - 2022-06-30 01:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:48:35 --> Total execution time: 0.0606
DEBUG - 2022-06-30 01:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:48:53 --> Total execution time: 0.0684
DEBUG - 2022-06-30 01:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:18:59 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:48:59 --> Total execution time: 0.0568
DEBUG - 2022-06-30 01:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:19:00 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:49:00 --> Total execution time: 0.0506
DEBUG - 2022-06-30 01:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:49:14 --> Total execution time: 0.0840
DEBUG - 2022-06-30 01:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:49:35 --> Total execution time: 0.0428
DEBUG - 2022-06-30 01:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:19:36 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:49:36 --> Total execution time: 0.0463
DEBUG - 2022-06-30 01:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:19:38 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:49:38 --> Total execution time: 0.0580
DEBUG - 2022-06-30 01:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:20:59 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:50:59 --> Total execution time: 0.2194
DEBUG - 2022-06-30 01:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:25:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 01:25:32 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-30 01:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 01:28:01 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-30 01:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:29:35 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:59:35 --> Total execution time: 0.3145
DEBUG - 2022-06-30 01:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 01:30:05 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-30 01:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:34:54 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:04:54 --> Total execution time: 0.3123
DEBUG - 2022-06-30 01:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:04:58 --> Total execution time: 0.1081
DEBUG - 2022-06-30 01:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:05:05 --> Total execution time: 0.0858
DEBUG - 2022-06-30 01:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:05:17 --> Total execution time: 0.0507
DEBUG - 2022-06-30 01:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:36:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 01:36:07 --> 404 Page Not Found: Assets/images
DEBUG - 2022-06-30 01:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:07:11 --> Total execution time: 0.0722
DEBUG - 2022-06-30 01:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:39:06 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:09:06 --> Total execution time: 0.1289
DEBUG - 2022-06-30 01:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:39:07 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:09:07 --> Total execution time: 0.0664
DEBUG - 2022-06-30 01:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:09:30 --> Total execution time: 0.0509
DEBUG - 2022-06-30 01:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:09:50 --> Total execution time: 0.0531
DEBUG - 2022-06-30 01:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:09:58 --> Total execution time: 0.0857
DEBUG - 2022-06-30 01:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 01:40:01 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-30 01:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:10:03 --> Total execution time: 0.0846
DEBUG - 2022-06-30 01:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:10:11 --> Total execution time: 0.0536
DEBUG - 2022-06-30 01:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:10:15 --> Total execution time: 0.0575
DEBUG - 2022-06-30 01:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 01:40:15 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-30 01:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:40:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 01:40:31 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-30 01:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:10:53 --> Total execution time: 0.0473
DEBUG - 2022-06-30 01:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:40:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 01:40:58 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-30 01:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:41:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 01:41:21 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-30 01:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:11:35 --> Total execution time: 0.0453
DEBUG - 2022-06-30 01:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:13:20 --> Total execution time: 0.0332
DEBUG - 2022-06-30 01:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:16:00 --> Total execution time: 0.1169
DEBUG - 2022-06-30 01:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:17:28 --> Total execution time: 0.0568
DEBUG - 2022-06-30 01:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:17:53 --> Total execution time: 0.0549
DEBUG - 2022-06-30 01:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:18:00 --> Total execution time: 0.0735
DEBUG - 2022-06-30 01:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:18:04 --> Total execution time: 0.1032
DEBUG - 2022-06-30 01:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:19:33 --> Total execution time: 0.0497
DEBUG - 2022-06-30 01:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:20:08 --> Total execution time: 0.0521
DEBUG - 2022-06-30 01:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:20:54 --> Total execution time: 0.0615
DEBUG - 2022-06-30 01:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 01:52:46 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 01:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:53:39 --> Total execution time: 0.0502
DEBUG - 2022-06-30 01:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:23:45 --> Total execution time: 0.0560
DEBUG - 2022-06-30 01:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:24:03 --> Total execution time: 0.0823
DEBUG - 2022-06-30 01:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:24:04 --> Total execution time: 0.0829
DEBUG - 2022-06-30 01:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:24:09 --> Total execution time: 0.0483
DEBUG - 2022-06-30 01:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:25:05 --> Total execution time: 0.0651
DEBUG - 2022-06-30 01:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:25:19 --> Total execution time: 0.2341
DEBUG - 2022-06-30 01:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:55:45 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:25:45 --> Total execution time: 0.1360
DEBUG - 2022-06-30 01:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:27:02 --> Total execution time: 0.0479
DEBUG - 2022-06-30 01:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:04 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:27:04 --> Total execution time: 0.1137
DEBUG - 2022-06-30 01:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:27:05 --> Total execution time: 0.0457
DEBUG - 2022-06-30 01:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:27:26 --> Total execution time: 0.1140
DEBUG - 2022-06-30 01:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:30 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:27:30 --> Total execution time: 0.0588
DEBUG - 2022-06-30 01:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:27:37 --> Total execution time: 0.0710
DEBUG - 2022-06-30 01:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:27:42 --> Total execution time: 0.0514
DEBUG - 2022-06-30 01:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:27:45 --> Total execution time: 0.0484
DEBUG - 2022-06-30 01:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:27:47 --> Total execution time: 0.0832
DEBUG - 2022-06-30 01:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 01:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:27:48 --> Total execution time: 0.0500
DEBUG - 2022-06-30 01:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 01:57:54 --> No URI present. Default controller set.
DEBUG - 2022-06-30 01:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 01:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:27:54 --> Total execution time: 0.0545
DEBUG - 2022-06-30 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:30:04 --> Total execution time: 0.0969
DEBUG - 2022-06-30 02:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:30:39 --> Total execution time: 0.0571
DEBUG - 2022-06-30 02:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:31:10 --> Total execution time: 0.3153
DEBUG - 2022-06-30 02:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:33:52 --> Total execution time: 0.1449
DEBUG - 2022-06-30 02:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:34:33 --> Total execution time: 0.1760
DEBUG - 2022-06-30 02:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:34:35 --> Total execution time: 0.0848
DEBUG - 2022-06-30 02:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:34:40 --> Total execution time: 0.0977
DEBUG - 2022-06-30 02:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:34:41 --> Total execution time: 0.0799
DEBUG - 2022-06-30 02:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:34:46 --> Total execution time: 0.2565
DEBUG - 2022-06-30 02:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:35:43 --> Total execution time: 0.0804
DEBUG - 2022-06-30 02:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:35:45 --> Total execution time: 0.0960
DEBUG - 2022-06-30 02:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:35:47 --> Total execution time: 0.0868
DEBUG - 2022-06-30 02:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:35:47 --> Total execution time: 0.0996
DEBUG - 2022-06-30 02:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:35:47 --> Total execution time: 0.1022
DEBUG - 2022-06-30 02:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:35:52 --> Total execution time: 0.1489
DEBUG - 2022-06-30 02:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:37:27 --> Total execution time: 0.0596
DEBUG - 2022-06-30 02:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:44:00 --> Total execution time: 0.0526
DEBUG - 2022-06-30 02:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:44:06 --> Total execution time: 0.0741
DEBUG - 2022-06-30 02:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:44:26 --> Total execution time: 0.0573
DEBUG - 2022-06-30 02:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:44:30 --> Total execution time: 0.0613
DEBUG - 2022-06-30 02:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:44:54 --> Total execution time: 0.0693
DEBUG - 2022-06-30 02:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:44:55 --> Total execution time: 0.0428
DEBUG - 2022-06-30 02:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:45:00 --> Total execution time: 0.0399
DEBUG - 2022-06-30 02:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:45:03 --> Total execution time: 0.0575
DEBUG - 2022-06-30 02:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:46:13 --> Total execution time: 0.0322
DEBUG - 2022-06-30 02:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:46:42 --> Total execution time: 0.0625
DEBUG - 2022-06-30 02:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:47:32 --> Total execution time: 0.0508
DEBUG - 2022-06-30 02:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:49:02 --> Total execution time: 0.0505
DEBUG - 2022-06-30 02:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:49:15 --> Total execution time: 0.0569
DEBUG - 2022-06-30 02:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:49:27 --> Total execution time: 0.0656
DEBUG - 2022-06-30 02:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:49:47 --> Total execution time: 0.0924
DEBUG - 2022-06-30 02:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:52:51 --> Total execution time: 0.2180
DEBUG - 2022-06-30 02:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:53:07 --> Total execution time: 0.0588
DEBUG - 2022-06-30 02:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:53:48 --> Total execution time: 0.1310
DEBUG - 2022-06-30 02:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:53:54 --> Total execution time: 0.0525
DEBUG - 2022-06-30 02:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:54:05 --> Total execution time: 0.0584
DEBUG - 2022-06-30 02:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:54:14 --> Total execution time: 0.0517
DEBUG - 2022-06-30 02:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:54:17 --> Total execution time: 0.0485
DEBUG - 2022-06-30 02:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:54:19 --> Total execution time: 0.0499
DEBUG - 2022-06-30 02:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:54:23 --> Total execution time: 0.0530
DEBUG - 2022-06-30 02:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:54:26 --> Total execution time: 0.0897
DEBUG - 2022-06-30 02:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:24:34 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:54:34 --> Total execution time: 0.0417
DEBUG - 2022-06-30 02:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:54:35 --> Total execution time: 0.0490
DEBUG - 2022-06-30 02:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:54:35 --> Total execution time: 0.0561
DEBUG - 2022-06-30 02:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:54:40 --> Total execution time: 0.0678
DEBUG - 2022-06-30 02:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:54:44 --> Total execution time: 0.0558
DEBUG - 2022-06-30 02:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:08 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:56:08 --> Total execution time: 0.0697
DEBUG - 2022-06-30 02:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:26:11 --> Total execution time: 0.0456
DEBUG - 2022-06-30 02:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:26:13 --> Total execution time: 0.0793
DEBUG - 2022-06-30 02:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:26:13 --> Total execution time: 0.1573
DEBUG - 2022-06-30 02:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:27 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:56:27 --> Total execution time: 0.0692
DEBUG - 2022-06-30 02:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:27 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:56:27 --> Total execution time: 0.0513
DEBUG - 2022-06-30 02:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:28 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:56:28 --> Total execution time: 0.0574
DEBUG - 2022-06-30 02:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:28 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:56:28 --> Total execution time: 0.0575
DEBUG - 2022-06-30 02:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:28 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:56:28 --> Total execution time: 0.0604
DEBUG - 2022-06-30 02:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:29 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:56:29 --> Total execution time: 0.0744
DEBUG - 2022-06-30 02:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:29 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:56:29 --> Total execution time: 0.0484
DEBUG - 2022-06-30 02:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:29 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:56:29 --> Total execution time: 0.0472
DEBUG - 2022-06-30 02:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:29 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:56:29 --> Total execution time: 0.0604
DEBUG - 2022-06-30 02:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:29 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:56:29 --> Total execution time: 0.0632
DEBUG - 2022-06-30 02:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:26:31 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:56:31 --> Total execution time: 0.0677
DEBUG - 2022-06-30 02:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:27:09 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:57:09 --> Total execution time: 0.0517
DEBUG - 2022-06-30 02:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:27:47 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:57:47 --> Total execution time: 0.1286
DEBUG - 2022-06-30 02:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:57:51 --> Total execution time: 0.0621
DEBUG - 2022-06-30 02:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:57:56 --> Total execution time: 0.0563
DEBUG - 2022-06-30 02:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:58:05 --> Total execution time: 0.0745
DEBUG - 2022-06-30 02:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:58:19 --> Total execution time: 0.0594
DEBUG - 2022-06-30 02:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:58:36 --> Total execution time: 0.0502
DEBUG - 2022-06-30 02:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:28:37 --> Total execution time: 0.0451
DEBUG - 2022-06-30 02:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:58:41 --> Total execution time: 0.0650
DEBUG - 2022-06-30 02:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:58:51 --> Total execution time: 0.0667
DEBUG - 2022-06-30 02:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:58:53 --> Total execution time: 0.0512
DEBUG - 2022-06-30 02:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:59:10 --> Total execution time: 0.0681
DEBUG - 2022-06-30 02:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:00:39 --> Total execution time: 0.0496
DEBUG - 2022-06-30 02:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:30:44 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:00:44 --> Total execution time: 0.0441
DEBUG - 2022-06-30 02:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:30:45 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:00:45 --> Total execution time: 0.0526
DEBUG - 2022-06-30 02:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:00:52 --> Total execution time: 0.0319
DEBUG - 2022-06-30 02:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:01:00 --> Total execution time: 0.0637
DEBUG - 2022-06-30 02:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:01:04 --> Total execution time: 0.0489
DEBUG - 2022-06-30 02:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:01:07 --> Total execution time: 0.0765
DEBUG - 2022-06-30 02:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:01:08 --> Total execution time: 0.0882
DEBUG - 2022-06-30 02:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:01:09 --> Total execution time: 0.0969
DEBUG - 2022-06-30 02:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:01:11 --> Total execution time: 0.0812
DEBUG - 2022-06-30 02:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:01:12 --> Total execution time: 0.0609
DEBUG - 2022-06-30 02:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:01:12 --> Total execution time: 0.0702
DEBUG - 2022-06-30 02:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:01:15 --> Total execution time: 0.0548
DEBUG - 2022-06-30 02:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:01:23 --> Total execution time: 0.0473
DEBUG - 2022-06-30 02:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:01:34 --> Total execution time: 0.0457
DEBUG - 2022-06-30 02:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:03:13 --> Total execution time: 0.0611
DEBUG - 2022-06-30 02:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:03:22 --> Total execution time: 0.0550
DEBUG - 2022-06-30 02:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:03:52 --> Total execution time: 0.0477
DEBUG - 2022-06-30 02:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:04:12 --> Total execution time: 0.0409
DEBUG - 2022-06-30 02:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:04:21 --> Total execution time: 0.0491
DEBUG - 2022-06-30 02:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:04:29 --> Total execution time: 0.0550
DEBUG - 2022-06-30 02:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:04:32 --> Total execution time: 0.0966
DEBUG - 2022-06-30 02:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:04:46 --> Total execution time: 0.0792
DEBUG - 2022-06-30 02:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:37:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 02:37:22 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-30 02:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:08:13 --> Total execution time: 0.3983
DEBUG - 2022-06-30 02:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:09:11 --> Total execution time: 0.1196
DEBUG - 2022-06-30 02:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:09:26 --> Total execution time: 0.1197
DEBUG - 2022-06-30 02:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:09:30 --> Total execution time: 0.0597
DEBUG - 2022-06-30 02:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:09:36 --> Total execution time: 0.0654
DEBUG - 2022-06-30 02:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:09:38 --> Total execution time: 0.0991
DEBUG - 2022-06-30 02:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:09:42 --> Total execution time: 0.0581
DEBUG - 2022-06-30 02:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:09:47 --> Total execution time: 0.0866
DEBUG - 2022-06-30 02:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:10:41 --> Total execution time: 0.0550
DEBUG - 2022-06-30 02:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:10:50 --> Total execution time: 0.0958
DEBUG - 2022-06-30 02:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:10:55 --> Total execution time: 0.0746
DEBUG - 2022-06-30 02:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:11:07 --> Total execution time: 0.0576
DEBUG - 2022-06-30 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:41:19 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:11:19 --> Total execution time: 0.0566
DEBUG - 2022-06-30 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:41:24 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:11:24 --> Total execution time: 0.0551
DEBUG - 2022-06-30 02:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:11:58 --> Total execution time: 1.9904
DEBUG - 2022-06-30 02:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 02:42:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 02:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:12:34 --> Total execution time: 0.0512
DEBUG - 2022-06-30 02:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:42:35 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:12:35 --> Total execution time: 0.0508
DEBUG - 2022-06-30 02:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:12:38 --> Total execution time: 0.1055
DEBUG - 2022-06-30 02:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:12:54 --> Total execution time: 0.0842
DEBUG - 2022-06-30 02:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:13:11 --> Total execution time: 0.0547
DEBUG - 2022-06-30 02:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:13:17 --> Total execution time: 0.1134
DEBUG - 2022-06-30 02:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:13:21 --> Total execution time: 0.0466
DEBUG - 2022-06-30 02:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:43:45 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:13:45 --> Total execution time: 0.0556
DEBUG - 2022-06-30 02:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:43:45 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:13:45 --> Total execution time: 0.0346
DEBUG - 2022-06-30 02:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:44:23 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:14:23 --> Total execution time: 0.0425
DEBUG - 2022-06-30 02:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:44:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:14:57 --> Total execution time: 0.0538
DEBUG - 2022-06-30 02:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:45:03 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:15:03 --> Total execution time: 0.0706
DEBUG - 2022-06-30 02:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:15:06 --> Total execution time: 0.1213
DEBUG - 2022-06-30 02:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:15:10 --> Total execution time: 0.0481
DEBUG - 2022-06-30 02:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:15:24 --> Total execution time: 0.0726
DEBUG - 2022-06-30 02:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:15:30 --> Total execution time: 0.0561
DEBUG - 2022-06-30 02:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:15:47 --> Total execution time: 0.0660
DEBUG - 2022-06-30 02:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:46:01 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:16:01 --> Total execution time: 0.1855
DEBUG - 2022-06-30 02:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:16:04 --> Total execution time: 0.1248
DEBUG - 2022-06-30 02:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:16:16 --> Total execution time: 0.0504
DEBUG - 2022-06-30 02:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:16:20 --> Total execution time: 0.0545
DEBUG - 2022-06-30 02:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:17:04 --> Total execution time: 0.0512
DEBUG - 2022-06-30 02:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:17:12 --> Total execution time: 0.0542
DEBUG - 2022-06-30 02:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:17:14 --> Total execution time: 0.0389
DEBUG - 2022-06-30 02:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:17:20 --> Total execution time: 0.0431
DEBUG - 2022-06-30 02:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:17:21 --> Total execution time: 0.0644
DEBUG - 2022-06-30 02:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:17:26 --> Total execution time: 0.0500
DEBUG - 2022-06-30 02:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:17:34 --> Total execution time: 0.0567
DEBUG - 2022-06-30 02:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:17:39 --> Total execution time: 0.0759
DEBUG - 2022-06-30 02:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:18:30 --> Total execution time: 0.0851
DEBUG - 2022-06-30 02:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:19:32 --> Total execution time: 0.0876
DEBUG - 2022-06-30 02:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:23:02 --> Total execution time: 0.0645
DEBUG - 2022-06-30 02:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:00 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:24:00 --> Total execution time: 0.0391
DEBUG - 2022-06-30 02:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:24:09 --> Total execution time: 0.0416
DEBUG - 2022-06-30 02:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:24:11 --> Total execution time: 0.0342
DEBUG - 2022-06-30 02:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:24:11 --> Total execution time: 0.0318
DEBUG - 2022-06-30 02:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:24:12 --> Total execution time: 0.0328
DEBUG - 2022-06-30 02:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:24:26 --> Total execution time: 0.0576
DEBUG - 2022-06-30 02:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:24:28 --> Total execution time: 0.0379
DEBUG - 2022-06-30 02:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:24:35 --> Total execution time: 0.0817
DEBUG - 2022-06-30 02:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:24:38 --> Total execution time: 0.0337
DEBUG - 2022-06-30 02:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:24:40 --> Total execution time: 0.0367
DEBUG - 2022-06-30 02:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:24:54 --> Total execution time: 0.0560
DEBUG - 2022-06-30 02:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:24:57 --> Total execution time: 0.0504
DEBUG - 2022-06-30 02:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:25:02 --> Total execution time: 0.0681
DEBUG - 2022-06-30 02:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:25:05 --> Total execution time: 0.0699
DEBUG - 2022-06-30 02:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:25:07 --> Total execution time: 0.0302
DEBUG - 2022-06-30 02:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:25:10 --> Total execution time: 0.0465
DEBUG - 2022-06-30 02:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:25:19 --> Total execution time: 0.0584
DEBUG - 2022-06-30 02:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:25:43 --> Total execution time: 0.0610
DEBUG - 2022-06-30 02:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:26:07 --> Total execution time: 0.0852
DEBUG - 2022-06-30 02:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:27:04 --> Total execution time: 0.0524
DEBUG - 2022-06-30 02:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:57:49 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:27:49 --> Total execution time: 0.0497
DEBUG - 2022-06-30 02:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:27:52 --> Total execution time: 0.0515
DEBUG - 2022-06-30 02:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:28:00 --> Total execution time: 0.0878
DEBUG - 2022-06-30 02:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:28:03 --> Total execution time: 0.0308
DEBUG - 2022-06-30 02:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:28:25 --> Total execution time: 0.0716
DEBUG - 2022-06-30 02:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:28:41 --> Total execution time: 0.0612
DEBUG - 2022-06-30 02:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:58:42 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:28:42 --> Total execution time: 0.0525
DEBUG - 2022-06-30 02:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:28:45 --> Total execution time: 0.0530
DEBUG - 2022-06-30 02:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:28:47 --> Total execution time: 0.0434
DEBUG - 2022-06-30 02:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:28:52 --> Total execution time: 0.0741
DEBUG - 2022-06-30 02:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:29:22 --> Total execution time: 0.1286
DEBUG - 2022-06-30 02:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 02:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:29:24 --> Total execution time: 0.0318
DEBUG - 2022-06-30 02:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:29:26 --> Total execution time: 0.1691
DEBUG - 2022-06-30 02:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:29:30 --> Total execution time: 0.0554
DEBUG - 2022-06-30 02:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 02:59:30 --> No URI present. Default controller set.
DEBUG - 2022-06-30 02:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 02:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:29:31 --> Total execution time: 0.1261
DEBUG - 2022-06-30 03:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:30:03 --> Total execution time: 0.1425
DEBUG - 2022-06-30 03:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:32:06 --> Total execution time: 0.0608
DEBUG - 2022-06-30 03:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:32:33 --> Total execution time: 0.0669
DEBUG - 2022-06-30 03:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:02:48 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:32:48 --> Total execution time: 0.0494
DEBUG - 2022-06-30 03:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:32:51 --> Total execution time: 0.0808
DEBUG - 2022-06-30 03:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:32:56 --> Total execution time: 0.0851
DEBUG - 2022-06-30 03:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:33:01 --> Total execution time: 0.0651
DEBUG - 2022-06-30 03:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 03:03:04 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-30 03:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:33:25 --> Total execution time: 0.0474
DEBUG - 2022-06-30 03:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:03:27 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:33:27 --> Total execution time: 0.0422
DEBUG - 2022-06-30 03:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:33:31 --> Total execution time: 0.0572
DEBUG - 2022-06-30 03:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:33:49 --> Total execution time: 0.0574
DEBUG - 2022-06-30 03:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:34:00 --> Total execution time: 0.0906
DEBUG - 2022-06-30 03:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:04:09 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:34:09 --> Total execution time: 0.0540
DEBUG - 2022-06-30 03:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:04:21 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:34:22 --> Total execution time: 0.0720
DEBUG - 2022-06-30 03:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:34:39 --> Total execution time: 0.0615
DEBUG - 2022-06-30 03:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:04:51 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:34:51 --> Total execution time: 0.0548
DEBUG - 2022-06-30 03:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:04:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:34:57 --> Total execution time: 0.0422
DEBUG - 2022-06-30 03:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:35:02 --> Total execution time: 0.0523
DEBUG - 2022-06-30 03:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:35:13 --> Total execution time: 0.0658
DEBUG - 2022-06-30 03:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:35:20 --> Total execution time: 0.0787
DEBUG - 2022-06-30 03:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:35:33 --> Total execution time: 0.0933
DEBUG - 2022-06-30 03:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 03:05:36 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-30 03:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:36:24 --> Total execution time: 0.1505
DEBUG - 2022-06-30 03:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:36:37 --> Total execution time: 0.0689
DEBUG - 2022-06-30 03:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:36:48 --> Total execution time: 0.0591
DEBUG - 2022-06-30 03:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:37:02 --> Total execution time: 0.0851
DEBUG - 2022-06-30 03:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:37:15 --> Total execution time: 0.0510
DEBUG - 2022-06-30 03:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:07:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 03:07:44 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-30 03:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:38:10 --> Total execution time: 0.1331
DEBUG - 2022-06-30 03:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:09:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 03:09:59 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-30 03:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:41:38 --> Total execution time: 0.2848
DEBUG - 2022-06-30 03:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:43:04 --> Total execution time: 0.2099
DEBUG - 2022-06-30 03:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:43:12 --> Total execution time: 0.1587
DEBUG - 2022-06-30 03:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:14:54 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:44:54 --> Total execution time: 0.1431
DEBUG - 2022-06-30 03:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:44:59 --> Total execution time: 0.0493
DEBUG - 2022-06-30 03:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:45:02 --> Total execution time: 0.1276
DEBUG - 2022-06-30 03:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:15:06 --> Total execution time: 0.0721
DEBUG - 2022-06-30 03:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:15:10 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:45:10 --> Total execution time: 0.0738
DEBUG - 2022-06-30 03:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:45:15 --> Total execution time: 0.0486
DEBUG - 2022-06-30 03:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:45:19 --> Total execution time: 0.0510
DEBUG - 2022-06-30 03:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:45:27 --> Total execution time: 0.0597
DEBUG - 2022-06-30 03:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:45:35 --> Total execution time: 0.0512
DEBUG - 2022-06-30 03:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 03:17:44 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-30 03:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:50:47 --> Total execution time: 0.0441
DEBUG - 2022-06-30 03:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 03:21:57 --> 404 Page Not Found: Assets/images
DEBUG - 2022-06-30 03:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:25:09 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:55:09 --> Total execution time: 0.1262
DEBUG - 2022-06-30 03:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:58:17 --> Total execution time: 0.4788
DEBUG - 2022-06-30 03:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:30:34 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:00:35 --> Total execution time: 0.0956
DEBUG - 2022-06-30 03:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:30:35 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:00:35 --> Total execution time: 0.0473
DEBUG - 2022-06-30 03:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:00:39 --> Total execution time: 0.0339
DEBUG - 2022-06-30 03:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:30:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 03:30:58 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 03:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:01:03 --> Total execution time: 0.0600
DEBUG - 2022-06-30 03:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:01:07 --> Total execution time: 0.0447
DEBUG - 2022-06-30 03:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:01:21 --> Total execution time: 0.0546
DEBUG - 2022-06-30 03:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:01:33 --> Total execution time: 0.0373
DEBUG - 2022-06-30 03:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:01:46 --> Total execution time: 0.0506
DEBUG - 2022-06-30 03:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:02:16 --> Total execution time: 0.0936
DEBUG - 2022-06-30 03:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:02:41 --> Total execution time: 0.1158
DEBUG - 2022-06-30 03:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:03:34 --> Total execution time: 0.1006
DEBUG - 2022-06-30 03:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:03:40 --> Total execution time: 0.0803
DEBUG - 2022-06-30 03:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:39:08 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:09:08 --> Total execution time: 0.2188
DEBUG - 2022-06-30 03:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:09:15 --> Total execution time: 0.0844
DEBUG - 2022-06-30 03:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:09:27 --> Total execution time: 0.0708
DEBUG - 2022-06-30 03:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 03:39:38 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-30 03:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:39:39 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:09:39 --> Total execution time: 0.0660
DEBUG - 2022-06-30 03:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:09:39 --> Total execution time: 0.0608
DEBUG - 2022-06-30 03:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:09:46 --> Total execution time: 0.0480
DEBUG - 2022-06-30 03:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:39:47 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:09:47 --> Total execution time: 0.0683
DEBUG - 2022-06-30 03:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:39:48 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:09:48 --> Total execution time: 0.0476
DEBUG - 2022-06-30 03:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:39:52 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:09:52 --> Total execution time: 0.0560
DEBUG - 2022-06-30 03:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:40:30 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:10:30 --> Total execution time: 0.0502
DEBUG - 2022-06-30 03:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:10:34 --> Total execution time: 0.0481
DEBUG - 2022-06-30 03:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:10:45 --> Total execution time: 0.0588
DEBUG - 2022-06-30 03:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:10:53 --> Total execution time: 0.0533
DEBUG - 2022-06-30 03:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:11:00 --> Total execution time: 0.0574
DEBUG - 2022-06-30 03:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:11:58 --> Total execution time: 0.0495
DEBUG - 2022-06-30 03:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:12:11 --> Total execution time: 0.0546
DEBUG - 2022-06-30 03:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:12:15 --> Total execution time: 0.0589
DEBUG - 2022-06-30 03:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:12:18 --> Total execution time: 0.0596
DEBUG - 2022-06-30 03:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 03:45:41 --> 404 Page Not Found: Lp-profile/courses
DEBUG - 2022-06-30 03:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 03:45:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 03:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:47:43 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:17:43 --> Total execution time: 0.1162
DEBUG - 2022-06-30 03:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:48:04 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:18:04 --> Total execution time: 0.0422
DEBUG - 2022-06-30 03:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:48:42 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:18:42 --> Total execution time: 0.1185
DEBUG - 2022-06-30 03:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:02 --> Total execution time: 0.0669
DEBUG - 2022-06-30 03:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:14 --> Total execution time: 0.0536
DEBUG - 2022-06-30 03:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:16 --> Total execution time: 0.0469
DEBUG - 2022-06-30 03:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:19 --> Total execution time: 0.0559
DEBUG - 2022-06-30 03:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:25 --> Total execution time: 0.0529
DEBUG - 2022-06-30 03:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:14 --> Total execution time: 0.0592
DEBUG - 2022-06-30 03:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:17 --> Total execution time: 0.0622
DEBUG - 2022-06-30 03:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:23 --> Total execution time: 0.2943
DEBUG - 2022-06-30 03:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:26 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:26 --> Total execution time: 0.0357
DEBUG - 2022-06-30 03:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:30 --> Total execution time: 0.0484
DEBUG - 2022-06-30 03:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:34 --> Total execution time: 0.0733
DEBUG - 2022-06-30 03:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:35 --> Total execution time: 0.0307
DEBUG - 2022-06-30 03:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:36 --> Total execution time: 0.0805
DEBUG - 2022-06-30 03:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:41 --> Total execution time: 0.0812
DEBUG - 2022-06-30 03:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:41 --> Total execution time: 0.1095
DEBUG - 2022-06-30 03:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:44 --> Total execution time: 0.0452
DEBUG - 2022-06-30 03:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:56 --> Total execution time: 0.0495
DEBUG - 2022-06-30 03:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:21:03 --> Total execution time: 0.0594
DEBUG - 2022-06-30 03:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:21:25 --> Total execution time: 0.0594
DEBUG - 2022-06-30 03:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:21:46 --> Total execution time: 0.0823
DEBUG - 2022-06-30 03:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:21:47 --> Total execution time: 0.0773
DEBUG - 2022-06-30 03:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:21:55 --> Total execution time: 0.0850
DEBUG - 2022-06-30 03:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:21:55 --> Total execution time: 0.1345
DEBUG - 2022-06-30 03:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:21:56 --> Total execution time: 0.0666
DEBUG - 2022-06-30 03:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:22:00 --> Total execution time: 0.0733
DEBUG - 2022-06-30 03:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:22:23 --> Total execution time: 0.0655
DEBUG - 2022-06-30 03:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:22:43 --> Total execution time: 0.1520
DEBUG - 2022-06-30 03:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:22:52 --> Total execution time: 0.0772
DEBUG - 2022-06-30 03:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:22:54 --> Total execution time: 0.0790
DEBUG - 2022-06-30 03:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:23:01 --> Total execution time: 0.0878
DEBUG - 2022-06-30 03:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:23:01 --> Total execution time: 0.1393
DEBUG - 2022-06-30 03:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:23:04 --> Total execution time: 0.0602
DEBUG - 2022-06-30 03:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:23:05 --> Total execution time: 0.0762
DEBUG - 2022-06-30 03:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:23:14 --> Total execution time: 0.0517
DEBUG - 2022-06-30 03:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:23:17 --> Total execution time: 0.0521
DEBUG - 2022-06-30 03:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:23:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 03:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:23:18 --> Total execution time: 0.0635
DEBUG - 2022-06-30 03:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:23:29 --> Total execution time: 0.0858
DEBUG - 2022-06-30 03:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:23:32 --> Total execution time: 0.0536
DEBUG - 2022-06-30 03:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:23:39 --> Total execution time: 0.1636
DEBUG - 2022-06-30 03:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:24:32 --> Total execution time: 0.0505
DEBUG - 2022-06-30 03:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:55:03 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:25:03 --> Total execution time: 0.0365
DEBUG - 2022-06-30 03:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:25:14 --> Total execution time: 0.0513
DEBUG - 2022-06-30 03:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:25:46 --> Total execution time: 0.0975
DEBUG - 2022-06-30 03:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:26:01 --> Total execution time: 0.1181
DEBUG - 2022-06-30 03:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:26:04 --> Total execution time: 0.0647
DEBUG - 2022-06-30 03:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:26:11 --> Total execution time: 0.0545
DEBUG - 2022-06-30 03:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:26:16 --> Total execution time: 0.0618
DEBUG - 2022-06-30 03:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:26:35 --> Total execution time: 0.0472
DEBUG - 2022-06-30 03:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:26:41 --> Total execution time: 0.0635
DEBUG - 2022-06-30 03:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:26:43 --> Total execution time: 0.0891
DEBUG - 2022-06-30 03:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:26:50 --> Total execution time: 0.0860
DEBUG - 2022-06-30 03:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:26:50 --> Total execution time: 0.1152
DEBUG - 2022-06-30 03:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:26:52 --> Total execution time: 0.0519
DEBUG - 2022-06-30 03:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:26:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 03:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:26:53 --> Total execution time: 0.0464
DEBUG - 2022-06-30 03:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:56:57 --> Total execution time: 0.0517
DEBUG - 2022-06-30 03:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:57:02 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:27:02 --> Total execution time: 0.0480
DEBUG - 2022-06-30 03:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:27:10 --> Total execution time: 0.0490
DEBUG - 2022-06-30 03:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:27:18 --> Total execution time: 0.0860
DEBUG - 2022-06-30 03:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:57:23 --> Total execution time: 0.0690
DEBUG - 2022-06-30 03:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:27:26 --> Total execution time: 0.0683
DEBUG - 2022-06-30 03:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:27:38 --> Total execution time: 0.0785
DEBUG - 2022-06-30 03:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:57:42 --> Total execution time: 0.0529
DEBUG - 2022-06-30 03:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:27:45 --> Total execution time: 0.0917
DEBUG - 2022-06-30 03:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:58:08 --> Total execution time: 0.0442
DEBUG - 2022-06-30 03:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:58:14 --> Total execution time: 0.0461
DEBUG - 2022-06-30 03:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:58:16 --> Total execution time: 0.1251
DEBUG - 2022-06-30 03:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:58:19 --> Total execution time: 0.0760
DEBUG - 2022-06-30 03:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:58:20 --> Total execution time: 0.0451
DEBUG - 2022-06-30 03:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:28:21 --> Total execution time: 0.0520
DEBUG - 2022-06-30 03:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:28:22 --> Total execution time: 0.0494
DEBUG - 2022-06-30 03:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:28:22 --> Total execution time: 0.0497
DEBUG - 2022-06-30 03:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 03:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:28:23 --> Total execution time: 0.0585
DEBUG - 2022-06-30 03:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:28:23 --> Total execution time: 0.0480
DEBUG - 2022-06-30 03:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:28:23 --> Total execution time: 0.1461
DEBUG - 2022-06-30 03:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:28:24 --> Total execution time: 0.0666
DEBUG - 2022-06-30 03:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:28:36 --> Total execution time: 0.0602
DEBUG - 2022-06-30 03:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:28:50 --> Total execution time: 0.0502
DEBUG - 2022-06-30 03:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:28:53 --> Total execution time: 0.1284
DEBUG - 2022-06-30 03:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:28:56 --> Total execution time: 0.1383
DEBUG - 2022-06-30 03:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:28:57 --> Total execution time: 0.0491
DEBUG - 2022-06-30 03:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:28:58 --> Total execution time: 0.0833
DEBUG - 2022-06-30 03:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:29:06 --> Total execution time: 0.0593
DEBUG - 2022-06-30 03:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:29:10 --> Total execution time: 0.0688
DEBUG - 2022-06-30 03:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:29:26 --> Total execution time: 0.0694
DEBUG - 2022-06-30 03:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:29:26 --> Total execution time: 0.0923
DEBUG - 2022-06-30 03:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:29:28 --> Total execution time: 0.0780
DEBUG - 2022-06-30 03:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:29:33 --> Total execution time: 0.0776
DEBUG - 2022-06-30 03:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:29:45 --> Total execution time: 0.0745
DEBUG - 2022-06-30 03:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:59:45 --> No URI present. Default controller set.
DEBUG - 2022-06-30 03:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:29:45 --> Total execution time: 0.0589
DEBUG - 2022-06-30 03:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:29:48 --> Total execution time: 0.1327
DEBUG - 2022-06-30 03:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:29:49 --> Total execution time: 0.0937
DEBUG - 2022-06-30 03:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 03:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 03:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:29:49 --> Total execution time: 0.0934
DEBUG - 2022-06-30 04:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:30:03 --> Total execution time: 0.0492
DEBUG - 2022-06-30 04:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:30:06 --> Total execution time: 2.0850
DEBUG - 2022-06-30 04:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:00:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 04:00:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 04:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:00:35 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:30:35 --> Total execution time: 0.0535
DEBUG - 2022-06-30 04:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:30:39 --> Total execution time: 0.0712
DEBUG - 2022-06-30 04:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:00:46 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:30:46 --> Total execution time: 0.0754
DEBUG - 2022-06-30 04:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:30:50 --> Total execution time: 0.0707
DEBUG - 2022-06-30 04:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:31:07 --> Total execution time: 0.0737
DEBUG - 2022-06-30 04:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:31:20 --> Total execution time: 0.0449
DEBUG - 2022-06-30 04:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:31:42 --> Total execution time: 0.1179
DEBUG - 2022-06-30 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:31:50 --> Total execution time: 0.1213
DEBUG - 2022-06-30 04:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:31:50 --> Total execution time: 0.2015
DEBUG - 2022-06-30 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:31:50 --> Total execution time: 0.0813
DEBUG - 2022-06-30 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:31:50 --> Total execution time: 0.0631
DEBUG - 2022-06-30 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:31:51 --> Total execution time: 0.0994
DEBUG - 2022-06-30 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:31:51 --> Total execution time: 0.0894
DEBUG - 2022-06-30 04:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:31:58 --> Total execution time: 0.1130
DEBUG - 2022-06-30 04:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:02:01 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:32:01 --> Total execution time: 0.0949
DEBUG - 2022-06-30 04:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:32:12 --> Total execution time: 0.0727
DEBUG - 2022-06-30 04:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:32:55 --> Total execution time: 0.0609
DEBUG - 2022-06-30 04:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:33:01 --> Total execution time: 0.0600
DEBUG - 2022-06-30 04:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:04:25 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:34:25 --> Total execution time: 0.1308
DEBUG - 2022-06-30 04:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:34:29 --> Total execution time: 0.0673
DEBUG - 2022-06-30 04:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:34:33 --> Total execution time: 0.0514
DEBUG - 2022-06-30 04:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:34:37 --> Total execution time: 0.0506
DEBUG - 2022-06-30 04:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:34:42 --> Total execution time: 0.0637
DEBUG - 2022-06-30 04:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:39:00 --> Total execution time: 0.2181
DEBUG - 2022-06-30 04:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:39:02 --> Total execution time: 0.0851
DEBUG - 2022-06-30 04:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:39:11 --> Total execution time: 0.0911
DEBUG - 2022-06-30 04:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:39:24 --> Total execution time: 0.1320
DEBUG - 2022-06-30 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:10:15 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:40:15 --> Total execution time: 0.1292
DEBUG - 2022-06-30 04:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:40:36 --> Total execution time: 0.1323
DEBUG - 2022-06-30 04:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:40:40 --> Total execution time: 0.1769
DEBUG - 2022-06-30 04:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:40:53 --> Total execution time: 0.0685
DEBUG - 2022-06-30 04:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:11:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 04:11:12 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-30 04:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:41:13 --> Total execution time: 0.0903
DEBUG - 2022-06-30 04:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:41:38 --> Total execution time: 0.0534
DEBUG - 2022-06-30 04:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:42:18 --> Total execution time: 0.0731
DEBUG - 2022-06-30 04:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:42:31 --> Total execution time: 0.0475
DEBUG - 2022-06-30 04:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:42:52 --> Total execution time: 0.0467
DEBUG - 2022-06-30 04:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:43:00 --> Total execution time: 0.0516
DEBUG - 2022-06-30 04:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:13:01 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:43:02 --> Total execution time: 0.1292
DEBUG - 2022-06-30 04:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:43:02 --> Total execution time: 0.0817
DEBUG - 2022-06-30 04:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:43:03 --> Total execution time: 0.0519
DEBUG - 2022-06-30 04:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:43:04 --> Total execution time: 0.1078
DEBUG - 2022-06-30 04:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:43:07 --> Total execution time: 0.0708
DEBUG - 2022-06-30 04:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:43:07 --> Total execution time: 0.0557
DEBUG - 2022-06-30 04:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:43:08 --> Total execution time: 0.0732
DEBUG - 2022-06-30 04:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:43:08 --> Total execution time: 0.0704
DEBUG - 2022-06-30 04:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:43:12 --> Total execution time: 0.0724
DEBUG - 2022-06-30 04:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:43:13 --> Total execution time: 0.0416
DEBUG - 2022-06-30 04:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:43:15 --> Total execution time: 0.0720
DEBUG - 2022-06-30 04:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:43:24 --> Total execution time: 0.0650
DEBUG - 2022-06-30 04:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:43:26 --> Total execution time: 0.0504
DEBUG - 2022-06-30 04:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:44:58 --> Total execution time: 0.1421
DEBUG - 2022-06-30 04:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:45:07 --> Total execution time: 0.1165
DEBUG - 2022-06-30 04:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:45:19 --> Total execution time: 0.0545
DEBUG - 2022-06-30 04:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:45:20 --> Total execution time: 0.0565
DEBUG - 2022-06-30 04:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:45:38 --> Total execution time: 0.0499
DEBUG - 2022-06-30 04:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:45:43 --> Total execution time: 0.0699
DEBUG - 2022-06-30 04:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:45:55 --> Total execution time: 0.0885
DEBUG - 2022-06-30 04:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:46:16 --> Total execution time: 0.0884
DEBUG - 2022-06-30 04:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:46:22 --> Total execution time: 0.0885
DEBUG - 2022-06-30 04:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:16:30 --> Total execution time: 0.0711
DEBUG - 2022-06-30 04:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:46:34 --> Total execution time: 0.0701
DEBUG - 2022-06-30 04:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:16:42 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:46:42 --> Total execution time: 0.0604
DEBUG - 2022-06-30 04:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:46:49 --> Total execution time: 0.0586
DEBUG - 2022-06-30 04:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:17:04 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:47:04 --> Total execution time: 0.1414
DEBUG - 2022-06-30 04:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:47:08 --> Total execution time: 0.0572
DEBUG - 2022-06-30 04:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:47:48 --> Total execution time: 0.0630
DEBUG - 2022-06-30 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:48:00 --> Total execution time: 1.9116
DEBUG - 2022-06-30 04:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:48:12 --> Total execution time: 0.0612
DEBUG - 2022-06-30 04:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:48:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 04:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:48:13 --> Total execution time: 0.0667
DEBUG - 2022-06-30 04:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:19:04 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:49:04 --> Total execution time: 0.1024
DEBUG - 2022-06-30 04:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:49:51 --> Total execution time: 0.0507
DEBUG - 2022-06-30 04:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:49:59 --> Total execution time: 0.0580
DEBUG - 2022-06-30 04:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:50:06 --> Total execution time: 0.0513
DEBUG - 2022-06-30 04:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:20:06 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:50:06 --> Total execution time: 0.0528
DEBUG - 2022-06-30 04:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:50:23 --> Total execution time: 0.0533
DEBUG - 2022-06-30 04:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:50:43 --> Total execution time: 0.1322
DEBUG - 2022-06-30 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:50:59 --> Total execution time: 0.0799
DEBUG - 2022-06-30 04:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:51:21 --> Total execution time: 0.0666
DEBUG - 2022-06-30 04:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:51:21 --> Total execution time: 0.0943
DEBUG - 2022-06-30 04:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:51:24 --> Total execution time: 1.5775
DEBUG - 2022-06-30 04:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:51:24 --> Total execution time: 0.0883
DEBUG - 2022-06-30 04:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:51:39 --> Total execution time: 0.1459
DEBUG - 2022-06-30 04:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:51:40 --> Total execution time: 0.0462
DEBUG - 2022-06-30 04:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:51:41 --> Total execution time: 0.0909
DEBUG - 2022-06-30 04:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:51:44 --> Total execution time: 0.0551
DEBUG - 2022-06-30 04:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:51:45 --> Total execution time: 0.0721
DEBUG - 2022-06-30 04:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:51:48 --> Total execution time: 0.0726
DEBUG - 2022-06-30 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:21:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:51:57 --> Total execution time: 0.0557
DEBUG - 2022-06-30 04:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:51:58 --> Total execution time: 0.0797
DEBUG - 2022-06-30 04:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:52:27 --> Total execution time: 0.0528
DEBUG - 2022-06-30 04:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:52:40 --> Total execution time: 0.0714
DEBUG - 2022-06-30 04:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:52:41 --> Total execution time: 0.0489
DEBUG - 2022-06-30 04:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:52:43 --> Total execution time: 0.0760
DEBUG - 2022-06-30 04:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:52:49 --> Total execution time: 0.0541
DEBUG - 2022-06-30 04:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:52:50 --> Total execution time: 0.0568
DEBUG - 2022-06-30 04:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:52:57 --> Total execution time: 0.0546
DEBUG - 2022-06-30 04:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:53:05 --> Total execution time: 0.0533
DEBUG - 2022-06-30 04:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:53:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 04:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:53:15 --> Total execution time: 0.0475
DEBUG - 2022-06-30 04:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:53:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 14:53:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 14:53:17 --> Total execution time: 0.1899
DEBUG - 2022-06-30 04:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:53:23 --> Total execution time: 0.0637
DEBUG - 2022-06-30 04:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:53:47 --> Total execution time: 0.0463
DEBUG - 2022-06-30 04:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:54:10 --> Total execution time: 0.0469
DEBUG - 2022-06-30 04:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:54:17 --> Total execution time: 0.0501
DEBUG - 2022-06-30 04:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:28:35 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:58:35 --> Total execution time: 0.2438
DEBUG - 2022-06-30 04:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:28:50 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:58:50 --> Total execution time: 0.1484
DEBUG - 2022-06-30 04:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:28:52 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:58:52 --> Total execution time: 0.0443
DEBUG - 2022-06-30 04:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:28:53 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:58:53 --> Total execution time: 0.0564
DEBUG - 2022-06-30 04:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:28:53 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:58:53 --> Total execution time: 0.0438
DEBUG - 2022-06-30 04:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:02 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:59:02 --> Total execution time: 0.0497
DEBUG - 2022-06-30 04:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:59:05 --> Total execution time: 0.1754
DEBUG - 2022-06-30 04:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:59:06 --> Total execution time: 0.1308
DEBUG - 2022-06-30 04:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:59:14 --> Total execution time: 0.1190
DEBUG - 2022-06-30 04:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:59:17 --> Total execution time: 0.1165
DEBUG - 2022-06-30 04:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:59:17 --> Total execution time: 0.0534
DEBUG - 2022-06-30 04:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:59:18 --> Total execution time: 0.0458
DEBUG - 2022-06-30 04:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:59:19 --> Total execution time: 0.0750
DEBUG - 2022-06-30 04:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:59:28 --> Total execution time: 0.0522
DEBUG - 2022-06-30 04:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:59:32 --> Total execution time: 0.1171
DEBUG - 2022-06-30 04:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:59:44 --> Total execution time: 0.0836
DEBUG - 2022-06-30 04:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:59:50 --> Total execution time: 0.0829
DEBUG - 2022-06-30 04:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:00:07 --> Total execution time: 0.0792
DEBUG - 2022-06-30 04:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:00:18 --> Total execution time: 0.0783
DEBUG - 2022-06-30 04:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:00:23 --> Total execution time: 0.0661
DEBUG - 2022-06-30 04:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:00:25 --> Total execution time: 0.1046
DEBUG - 2022-06-30 04:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:00:25 --> Total execution time: 0.0870
DEBUG - 2022-06-30 04:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:01:42 --> Total execution time: 1.5631
DEBUG - 2022-06-30 04:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:36:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 04:36:51 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-30 04:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:36:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 04:36:54 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-30 04:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:36:58 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:06:58 --> Total execution time: 0.1087
DEBUG - 2022-06-30 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:36:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 04:36:59 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-30 04:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:38:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 04:38:06 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-30 04:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:38:09 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:08:09 --> Total execution time: 0.0346
DEBUG - 2022-06-30 04:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:38:12 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:08:12 --> Total execution time: 0.0529
DEBUG - 2022-06-30 04:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:38:27 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:08:27 --> Total execution time: 0.0424
DEBUG - 2022-06-30 04:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:39:15 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:09:15 --> Total execution time: 0.0396
DEBUG - 2022-06-30 04:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:39:28 --> Total execution time: 0.0872
DEBUG - 2022-06-30 04:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:39:39 --> Total execution time: 0.0609
DEBUG - 2022-06-30 04:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:40:01 --> Total execution time: 0.1171
DEBUG - 2022-06-30 04:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:40:02 --> Total execution time: 0.2012
DEBUG - 2022-06-30 04:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:41:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 04:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:11:40 --> Total execution time: 1.9248
DEBUG - 2022-06-30 04:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 04:42:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 04:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:42:14 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:12:14 --> Total execution time: 0.0943
DEBUG - 2022-06-30 04:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:12:14 --> Total execution time: 0.3206
DEBUG - 2022-06-30 04:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:12:19 --> Total execution time: 0.0552
DEBUG - 2022-06-30 04:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:12:20 --> Total execution time: 0.1315
DEBUG - 2022-06-30 04:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:42:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 04:42:28 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-30 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:12:44 --> Total execution time: 0.0535
DEBUG - 2022-06-30 04:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:12:49 --> Total execution time: 0.0586
DEBUG - 2022-06-30 04:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:12:53 --> Total execution time: 0.0658
DEBUG - 2022-06-30 04:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:13:00 --> Total execution time: 0.0552
DEBUG - 2022-06-30 04:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:13:19 --> Total execution time: 0.0780
DEBUG - 2022-06-30 04:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:13:32 --> Total execution time: 0.0622
DEBUG - 2022-06-30 04:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:13:33 --> Total execution time: 0.0612
DEBUG - 2022-06-30 04:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:13:44 --> Total execution time: 0.0548
DEBUG - 2022-06-30 04:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:13:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 04:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:13:46 --> Total execution time: 0.0707
DEBUG - 2022-06-30 04:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:13:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 15:13:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 15:13:48 --> Total execution time: 0.2078
DEBUG - 2022-06-30 04:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:14:08 --> Total execution time: 0.0640
DEBUG - 2022-06-30 04:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:45:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 04:45:01 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-30 04:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:46:34 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:16:34 --> Total execution time: 0.1486
DEBUG - 2022-06-30 04:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:16:52 --> Total execution time: 0.1111
DEBUG - 2022-06-30 04:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:47:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 04:47:10 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-30 04:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:17:15 --> Total execution time: 0.0460
DEBUG - 2022-06-30 04:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:17:47 --> Total execution time: 0.0519
DEBUG - 2022-06-30 04:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:18:19 --> Total execution time: 0.0717
DEBUG - 2022-06-30 04:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:18:19 --> Total execution time: 0.0795
DEBUG - 2022-06-30 04:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:50:51 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:50:51 --> Total execution time: 0.0347
DEBUG - 2022-06-30 04:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:20:51 --> Total execution time: 0.0479
DEBUG - 2022-06-30 04:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:50:54 --> Total execution time: 0.0560
DEBUG - 2022-06-30 04:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:50:54 --> Total execution time: 0.1227
DEBUG - 2022-06-30 04:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:20:55 --> Total execution time: 0.0467
DEBUG - 2022-06-30 04:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:21:03 --> Total execution time: 0.0501
DEBUG - 2022-06-30 04:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:21:11 --> Total execution time: 0.0919
DEBUG - 2022-06-30 04:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:21:15 --> Total execution time: 0.0674
DEBUG - 2022-06-30 04:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:21:34 --> Total execution time: 0.1238
DEBUG - 2022-06-30 04:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:21:45 --> Total execution time: 0.0891
DEBUG - 2022-06-30 04:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:21:50 --> Total execution time: 0.0599
DEBUG - 2022-06-30 04:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:51:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 04:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:21:58 --> Total execution time: 0.0402
DEBUG - 2022-06-30 04:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:22:02 --> Total execution time: 0.0480
DEBUG - 2022-06-30 04:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:22:12 --> Total execution time: 0.1182
DEBUG - 2022-06-30 04:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:22:19 --> Total execution time: 0.0676
DEBUG - 2022-06-30 04:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:22:21 --> Total execution time: 0.0799
DEBUG - 2022-06-30 04:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:22:28 --> Total execution time: 0.0531
DEBUG - 2022-06-30 04:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:22:30 --> Total execution time: 0.0549
DEBUG - 2022-06-30 04:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:22:34 --> Total execution time: 0.0665
DEBUG - 2022-06-30 04:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:22:34 --> Total execution time: 0.1558
DEBUG - 2022-06-30 04:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:22:44 --> Total execution time: 0.0595
DEBUG - 2022-06-30 04:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:22:49 --> Total execution time: 0.0486
DEBUG - 2022-06-30 04:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:22:52 --> Total execution time: 0.0563
DEBUG - 2022-06-30 04:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:22:57 --> Total execution time: 0.0561
DEBUG - 2022-06-30 04:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:22:57 --> Total execution time: 0.0395
DEBUG - 2022-06-30 04:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:23:01 --> Total execution time: 0.0532
DEBUG - 2022-06-30 04:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:23:51 --> Total execution time: 0.0681
DEBUG - 2022-06-30 04:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:24:26 --> Total execution time: 0.0507
DEBUG - 2022-06-30 04:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:25:24 --> Total execution time: 0.1448
DEBUG - 2022-06-30 04:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:25:42 --> Total execution time: 0.0564
DEBUG - 2022-06-30 04:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:26:13 --> Total execution time: 0.2513
DEBUG - 2022-06-30 04:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:26:33 --> Total execution time: 0.0551
DEBUG - 2022-06-30 04:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:26:45 --> Total execution time: 0.0553
DEBUG - 2022-06-30 04:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:27:06 --> Total execution time: 0.0734
DEBUG - 2022-06-30 04:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:28:18 --> Total execution time: 0.0862
DEBUG - 2022-06-30 04:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:28:23 --> Total execution time: 0.0504
DEBUG - 2022-06-30 04:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:28:47 --> Total execution time: 0.0535
DEBUG - 2022-06-30 04:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:28:52 --> Total execution time: 0.0694
DEBUG - 2022-06-30 04:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:29:25 --> Total execution time: 0.0558
DEBUG - 2022-06-30 04:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 04:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 04:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 04:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:29:52 --> Total execution time: 0.0430
DEBUG - 2022-06-30 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:30:02 --> Total execution time: 0.0428
DEBUG - 2022-06-30 05:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:01:06 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:31:06 --> Total execution time: 0.0634
DEBUG - 2022-06-30 05:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:31:15 --> Total execution time: 0.0598
DEBUG - 2022-06-30 05:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:31:33 --> Total execution time: 0.0345
DEBUG - 2022-06-30 05:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:31:43 --> Total execution time: 0.0579
DEBUG - 2022-06-30 05:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:31:48 --> Total execution time: 0.0688
DEBUG - 2022-06-30 05:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:31:55 --> Total execution time: 0.0820
DEBUG - 2022-06-30 05:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:32:09 --> Total execution time: 0.0466
DEBUG - 2022-06-30 05:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:33:08 --> Total execution time: 0.1675
DEBUG - 2022-06-30 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:33:20 --> Total execution time: 0.0628
DEBUG - 2022-06-30 05:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:34:55 --> Total execution time: 0.0798
DEBUG - 2022-06-30 05:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:35:07 --> Total execution time: 0.0712
DEBUG - 2022-06-30 05:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:35:31 --> Total execution time: 0.0752
DEBUG - 2022-06-30 05:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:05:38 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:35:39 --> Total execution time: 0.0582
DEBUG - 2022-06-30 05:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:35:44 --> Total execution time: 0.0519
DEBUG - 2022-06-30 05:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:35:48 --> Total execution time: 0.0646
DEBUG - 2022-06-30 05:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:35:50 --> Total execution time: 0.0695
DEBUG - 2022-06-30 05:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:35:54 --> Total execution time: 0.0620
DEBUG - 2022-06-30 05:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:36:05 --> Total execution time: 0.0535
DEBUG - 2022-06-30 05:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:36:22 --> Total execution time: 0.0588
DEBUG - 2022-06-30 05:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:36:34 --> Total execution time: 0.0535
DEBUG - 2022-06-30 05:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:06:36 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:36:36 --> Total execution time: 0.0337
DEBUG - 2022-06-30 05:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:06:37 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:36:37 --> Total execution time: 0.0294
DEBUG - 2022-06-30 05:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:36:48 --> Total execution time: 0.0313
DEBUG - 2022-06-30 05:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:06:59 --> Total execution time: 0.0451
DEBUG - 2022-06-30 05:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:07:00 --> Total execution time: 0.0518
DEBUG - 2022-06-30 05:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:07:00 --> Total execution time: 0.0649
DEBUG - 2022-06-30 05:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:07:09 --> Total execution time: 0.0715
DEBUG - 2022-06-30 05:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:07:11 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:37:11 --> Total execution time: 0.1225
DEBUG - 2022-06-30 05:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:07:15 --> Total execution time: 0.0524
DEBUG - 2022-06-30 05:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:37:15 --> Total execution time: 0.0664
DEBUG - 2022-06-30 05:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:37:24 --> Total execution time: 0.0694
DEBUG - 2022-06-30 05:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:37:27 --> Total execution time: 0.0725
DEBUG - 2022-06-30 05:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:37:27 --> Total execution time: 0.0584
DEBUG - 2022-06-30 05:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:37:35 --> Total execution time: 0.0512
DEBUG - 2022-06-30 05:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:37:38 --> Total execution time: 0.0501
DEBUG - 2022-06-30 05:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:37:43 --> Total execution time: 0.0632
DEBUG - 2022-06-30 05:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:37:57 --> Total execution time: 0.0535
DEBUG - 2022-06-30 05:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:38:00 --> Total execution time: 0.0625
DEBUG - 2022-06-30 05:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:38:08 --> Total execution time: 0.0545
DEBUG - 2022-06-30 05:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:08:09 --> Total execution time: 0.0372
DEBUG - 2022-06-30 05:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:08:12 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:38:12 --> Total execution time: 0.1344
DEBUG - 2022-06-30 05:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:08:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 05:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:38:24 --> Total execution time: 1.8900
DEBUG - 2022-06-30 05:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:38:26 --> Total execution time: 0.0664
DEBUG - 2022-06-30 05:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:08:27 --> Total execution time: 0.0553
DEBUG - 2022-06-30 05:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:08:27 --> Total execution time: 0.0606
DEBUG - 2022-06-30 05:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:08:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 05:08:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 05:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:38:35 --> Total execution time: 0.0539
DEBUG - 2022-06-30 05:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:38:43 --> Total execution time: 0.0753
DEBUG - 2022-06-30 05:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:39:17 --> Total execution time: 0.1119
DEBUG - 2022-06-30 05:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:39:30 --> Total execution time: 0.0495
DEBUG - 2022-06-30 05:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:39:37 --> Total execution time: 0.0506
DEBUG - 2022-06-30 05:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:09:38 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:39:38 --> Total execution time: 0.0458
DEBUG - 2022-06-30 05:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:09:42 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:39:42 --> Total execution time: 0.0569
DEBUG - 2022-06-30 05:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:39:43 --> Total execution time: 0.0715
DEBUG - 2022-06-30 05:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:39:48 --> Total execution time: 0.0609
DEBUG - 2022-06-30 05:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:39:48 --> Total execution time: 0.0529
DEBUG - 2022-06-30 05:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:39:56 --> Total execution time: 0.0513
DEBUG - 2022-06-30 05:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:40:03 --> Total execution time: 0.0686
DEBUG - 2022-06-30 05:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:40:05 --> Total execution time: 0.0748
DEBUG - 2022-06-30 05:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:40:07 --> Total execution time: 0.0581
DEBUG - 2022-06-30 05:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:40:08 --> Total execution time: 0.0494
DEBUG - 2022-06-30 05:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:40:10 --> Total execution time: 0.0623
DEBUG - 2022-06-30 05:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:40:19 --> Total execution time: 0.0585
DEBUG - 2022-06-30 05:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:40:31 --> Total execution time: 0.0814
DEBUG - 2022-06-30 05:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:40:38 --> Total execution time: 0.0534
DEBUG - 2022-06-30 05:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:10:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 05:10:42 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 05:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:41:04 --> Total execution time: 0.0771
DEBUG - 2022-06-30 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:11:09 --> Total execution time: 0.0493
DEBUG - 2022-06-30 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:41:16 --> Total execution time: 0.0702
DEBUG - 2022-06-30 05:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:41:56 --> Total execution time: 0.0539
DEBUG - 2022-06-30 05:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:42:19 --> Total execution time: 0.0498
DEBUG - 2022-06-30 05:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:22 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:42:22 --> Total execution time: 0.0403
DEBUG - 2022-06-30 05:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:23 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:42:23 --> Total execution time: 0.0436
DEBUG - 2022-06-30 05:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:42:23 --> Total execution time: 0.0703
DEBUG - 2022-06-30 05:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:12:28 --> Total execution time: 0.0535
DEBUG - 2022-06-30 05:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:12:29 --> Total execution time: 0.0607
DEBUG - 2022-06-30 05:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:12:30 --> Total execution time: 0.0495
DEBUG - 2022-06-30 05:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:12:30 --> Total execution time: 0.0785
DEBUG - 2022-06-30 05:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:32 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:42:32 --> Total execution time: 0.0497
DEBUG - 2022-06-30 05:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:42:34 --> Total execution time: 0.0484
DEBUG - 2022-06-30 05:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:42:42 --> Total execution time: 0.0484
DEBUG - 2022-06-30 05:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:42:49 --> Total execution time: 0.0501
DEBUG - 2022-06-30 05:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:12:49 --> Total execution time: 0.1005
DEBUG - 2022-06-30 05:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:42:52 --> Total execution time: 0.0536
DEBUG - 2022-06-30 05:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:43:02 --> Total execution time: 0.0641
DEBUG - 2022-06-30 05:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:13:05 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:43:05 --> Total execution time: 0.0463
DEBUG - 2022-06-30 05:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:43:15 --> Total execution time: 0.0554
DEBUG - 2022-06-30 05:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:43:22 --> Total execution time: 0.0575
DEBUG - 2022-06-30 05:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:43:32 --> Total execution time: 0.0519
DEBUG - 2022-06-30 05:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:43:34 --> Total execution time: 1.7153
DEBUG - 2022-06-30 05:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:13:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 05:13:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 05:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:13:56 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:43:56 --> Total execution time: 0.0545
DEBUG - 2022-06-30 05:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:44:02 --> Total execution time: 0.1112
DEBUG - 2022-06-30 05:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:44:09 --> Total execution time: 0.0725
DEBUG - 2022-06-30 05:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:44:25 --> Total execution time: 0.0659
DEBUG - 2022-06-30 05:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:44:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 05:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:44:40 --> Total execution time: 0.0884
DEBUG - 2022-06-30 05:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:44:57 --> Total execution time: 0.0761
DEBUG - 2022-06-30 05:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:18:24 --> Total execution time: 0.0702
DEBUG - 2022-06-30 05:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:18:44 --> Total execution time: 0.0656
DEBUG - 2022-06-30 05:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:49:35 --> Total execution time: 0.1328
DEBUG - 2022-06-30 05:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:49:43 --> Total execution time: 0.0537
DEBUG - 2022-06-30 05:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:20:21 --> Total execution time: 0.0659
DEBUG - 2022-06-30 05:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:20:24 --> Total execution time: 0.0545
DEBUG - 2022-06-30 05:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:20:24 --> Total execution time: 0.1050
DEBUG - 2022-06-30 05:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:51:18 --> Total execution time: 0.0526
DEBUG - 2022-06-30 05:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:52:50 --> Total execution time: 0.1010
DEBUG - 2022-06-30 05:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:53:03 --> Total execution time: 0.1265
DEBUG - 2022-06-30 05:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:53:20 --> Total execution time: 0.0822
DEBUG - 2022-06-30 05:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:53:33 --> Total execution time: 0.0560
DEBUG - 2022-06-30 05:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:53:48 --> Total execution time: 0.0731
DEBUG - 2022-06-30 05:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:53:54 --> Total execution time: 0.0898
DEBUG - 2022-06-30 05:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:54:24 --> Total execution time: 0.0935
DEBUG - 2022-06-30 05:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:54:29 --> Total execution time: 0.0511
DEBUG - 2022-06-30 05:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:55:13 --> Total execution time: 0.0558
DEBUG - 2022-06-30 05:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:55:46 --> Total execution time: 0.1595
DEBUG - 2022-06-30 05:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:56:05 --> Total execution time: 0.1162
DEBUG - 2022-06-30 05:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:56:11 --> Total execution time: 0.1329
DEBUG - 2022-06-30 05:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:56:48 --> Total execution time: 0.0491
DEBUG - 2022-06-30 05:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:56:57 --> Total execution time: 0.0592
DEBUG - 2022-06-30 05:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:57:46 --> Total execution time: 0.1538
DEBUG - 2022-06-30 05:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:58:18 --> Total execution time: 0.0768
DEBUG - 2022-06-30 05:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:35:37 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:05:37 --> Total execution time: 0.1873
DEBUG - 2022-06-30 05:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:05:45 --> Total execution time: 0.0391
DEBUG - 2022-06-30 05:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:05:54 --> Total execution time: 0.0647
DEBUG - 2022-06-30 05:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:05:58 --> Total execution time: 0.0583
DEBUG - 2022-06-30 05:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:06:02 --> Total execution time: 0.0568
DEBUG - 2022-06-30 05:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:06:19 --> Total execution time: 0.0997
DEBUG - 2022-06-30 05:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:06:23 --> Total execution time: 0.0555
DEBUG - 2022-06-30 05:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:36:23 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:06:23 --> Total execution time: 0.0557
DEBUG - 2022-06-30 05:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:08:18 --> Total execution time: 0.0662
DEBUG - 2022-06-30 05:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:09:09 --> Total execution time: 0.1333
DEBUG - 2022-06-30 05:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:09:14 --> Total execution time: 0.1043
DEBUG - 2022-06-30 05:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:09:30 --> Total execution time: 0.0600
DEBUG - 2022-06-30 05:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:09:42 --> Total execution time: 0.0621
DEBUG - 2022-06-30 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:10:13 --> Total execution time: 0.0603
DEBUG - 2022-06-30 05:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:44:25 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:14:26 --> Total execution time: 0.2128
DEBUG - 2022-06-30 05:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:14:31 --> Total execution time: 0.1145
DEBUG - 2022-06-30 05:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:14:34 --> Total execution time: 0.0677
DEBUG - 2022-06-30 05:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:14:37 --> Total execution time: 0.0828
DEBUG - 2022-06-30 05:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:14:44 --> Total execution time: 0.0514
DEBUG - 2022-06-30 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:14:49 --> Total execution time: 0.1182
DEBUG - 2022-06-30 05:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:44:52 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:14:52 --> Total execution time: 0.0393
DEBUG - 2022-06-30 05:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:14:58 --> Total execution time: 0.0501
DEBUG - 2022-06-30 05:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:15:06 --> Total execution time: 0.0788
DEBUG - 2022-06-30 05:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:15:20 --> Total execution time: 0.0520
DEBUG - 2022-06-30 05:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:15:27 --> Total execution time: 0.0795
DEBUG - 2022-06-30 05:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:15:42 --> Total execution time: 0.0676
DEBUG - 2022-06-30 05:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:15:52 --> Total execution time: 0.0814
DEBUG - 2022-06-30 05:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:45:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:15:57 --> Total execution time: 0.0688
DEBUG - 2022-06-30 05:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:17:41 --> Total execution time: 0.0628
DEBUG - 2022-06-30 05:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:48:07 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:18:07 --> Total execution time: 0.1092
DEBUG - 2022-06-30 05:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:48:20 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:18:20 --> Total execution time: 0.0481
DEBUG - 2022-06-30 05:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:18:35 --> Total execution time: 0.0516
DEBUG - 2022-06-30 05:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:50:02 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:20:03 --> Total execution time: 0.1164
DEBUG - 2022-06-30 05:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 05:50:08 --> 404 Page Not Found: Lessons/linkedin-practicle-work
DEBUG - 2022-06-30 05:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:20:15 --> Total execution time: 1.9963
DEBUG - 2022-06-30 05:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:50:43 --> No URI present. Default controller set.
DEBUG - 2022-06-30 05:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:20:43 --> Total execution time: 0.0481
DEBUG - 2022-06-30 05:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:20:46 --> Total execution time: 0.0456
DEBUG - 2022-06-30 05:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:20:56 --> Total execution time: 0.0739
DEBUG - 2022-06-30 05:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:21:12 --> Total execution time: 0.0488
DEBUG - 2022-06-30 05:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:21:51 --> Total execution time: 0.0659
DEBUG - 2022-06-30 05:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:22:15 --> Total execution time: 0.0514
DEBUG - 2022-06-30 05:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:22:33 --> Total execution time: 0.1656
DEBUG - 2022-06-30 05:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:22:48 --> Total execution time: 0.0907
DEBUG - 2022-06-30 05:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:22:59 --> Total execution time: 0.0745
DEBUG - 2022-06-30 05:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:23:15 --> Total execution time: 0.0579
DEBUG - 2022-06-30 05:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:23:40 --> Total execution time: 0.0874
DEBUG - 2022-06-30 05:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:23:47 --> Total execution time: 0.0560
DEBUG - 2022-06-30 05:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:24:01 --> Total execution time: 0.0669
DEBUG - 2022-06-30 05:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:24:14 --> Total execution time: 0.1121
DEBUG - 2022-06-30 05:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:24:58 --> Total execution time: 0.0515
DEBUG - 2022-06-30 05:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:26:13 --> Total execution time: 0.1733
DEBUG - 2022-06-30 05:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:26:15 --> Total execution time: 0.0570
DEBUG - 2022-06-30 05:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:26:34 --> Total execution time: 0.0747
DEBUG - 2022-06-30 05:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:26:38 --> Total execution time: 0.0602
DEBUG - 2022-06-30 05:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:26:49 --> Total execution time: 0.0320
DEBUG - 2022-06-30 05:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:26:49 --> Total execution time: 0.0498
DEBUG - 2022-06-30 05:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:27:03 --> Total execution time: 0.0542
DEBUG - 2022-06-30 05:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:27:12 --> Total execution time: 0.0673
DEBUG - 2022-06-30 05:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:27:15 --> Total execution time: 0.0722
DEBUG - 2022-06-30 05:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:27:21 --> Total execution time: 0.0486
DEBUG - 2022-06-30 05:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:27:23 --> Total execution time: 0.0505
DEBUG - 2022-06-30 05:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 05:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:27:47 --> Total execution time: 0.0512
DEBUG - 2022-06-30 05:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:27:54 --> Total execution time: 0.0700
DEBUG - 2022-06-30 05:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:28:13 --> Total execution time: 0.0553
DEBUG - 2022-06-30 05:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:28:21 --> Total execution time: 0.0591
DEBUG - 2022-06-30 05:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:29:17 --> Total execution time: 0.0707
DEBUG - 2022-06-30 05:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:29:20 --> Total execution time: 0.0919
DEBUG - 2022-06-30 05:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:29:27 --> Total execution time: 0.0569
DEBUG - 2022-06-30 05:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:29:30 --> Total execution time: 0.0625
DEBUG - 2022-06-30 05:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:29:37 --> Total execution time: 0.0545
DEBUG - 2022-06-30 05:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 05:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 05:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:29:41 --> Total execution time: 0.0593
DEBUG - 2022-06-30 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:30:02 --> Total execution time: 0.0994
DEBUG - 2022-06-30 06:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:31:48 --> Total execution time: 0.1223
DEBUG - 2022-06-30 06:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:31:58 --> Total execution time: 0.0636
DEBUG - 2022-06-30 06:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:34:05 --> Total execution time: 0.1381
DEBUG - 2022-06-30 06:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:37:30 --> Total execution time: 0.0466
DEBUG - 2022-06-30 06:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:37:51 --> Total execution time: 0.0600
DEBUG - 2022-06-30 06:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:37:59 --> Total execution time: 0.0557
DEBUG - 2022-06-30 06:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:38:04 --> Total execution time: 0.0617
DEBUG - 2022-06-30 06:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:38:05 --> Total execution time: 0.0475
DEBUG - 2022-06-30 06:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:38:12 --> Total execution time: 0.0594
DEBUG - 2022-06-30 06:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:38:20 --> Total execution time: 0.0558
DEBUG - 2022-06-30 06:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:38:52 --> Total execution time: 0.0470
DEBUG - 2022-06-30 06:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:38:57 --> Total execution time: 0.0492
DEBUG - 2022-06-30 06:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:09:28 --> No URI present. Default controller set.
DEBUG - 2022-06-30 06:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:39:28 --> Total execution time: 0.0415
DEBUG - 2022-06-30 06:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:11:29 --> No URI present. Default controller set.
DEBUG - 2022-06-30 06:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:41:29 --> Total execution time: 0.1231
DEBUG - 2022-06-30 06:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:11:50 --> Total execution time: 0.0518
DEBUG - 2022-06-30 06:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:11:52 --> Total execution time: 0.0515
DEBUG - 2022-06-30 06:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:11:52 --> Total execution time: 0.1361
DEBUG - 2022-06-30 06:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:42:02 --> Total execution time: 0.0537
DEBUG - 2022-06-30 06:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:42:03 --> Total execution time: 0.0674
DEBUG - 2022-06-30 06:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:42:44 --> Total execution time: 0.0641
DEBUG - 2022-06-30 06:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:43:49 --> Total execution time: 0.0745
DEBUG - 2022-06-30 06:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:14:16 --> Total execution time: 0.0327
DEBUG - 2022-06-30 06:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:44:25 --> Total execution time: 0.0463
DEBUG - 2022-06-30 06:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:44:28 --> Total execution time: 0.0507
DEBUG - 2022-06-30 06:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:44:29 --> Total execution time: 0.0580
DEBUG - 2022-06-30 06:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:44:43 --> Total execution time: 0.0768
DEBUG - 2022-06-30 06:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:44:45 --> Total execution time: 0.0789
DEBUG - 2022-06-30 06:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:44:58 --> Total execution time: 0.0494
DEBUG - 2022-06-30 06:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:45:06 --> Total execution time: 0.0562
DEBUG - 2022-06-30 06:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:45:18 --> Total execution time: 0.0471
DEBUG - 2022-06-30 06:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:45:36 --> Total execution time: 0.0658
DEBUG - 2022-06-30 06:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:46:51 --> Total execution time: 0.1540
DEBUG - 2022-06-30 06:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:48:00 --> Total execution time: 0.0551
DEBUG - 2022-06-30 06:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:20:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 06:20:59 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-30 06:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:51:22 --> Total execution time: 0.0950
DEBUG - 2022-06-30 06:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:21:30 --> Total execution time: 0.0550
DEBUG - 2022-06-30 06:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:21:31 --> Total execution time: 0.0515
DEBUG - 2022-06-30 06:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:21:32 --> Total execution time: 0.1126
DEBUG - 2022-06-30 06:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:22:10 --> Total execution time: 0.0610
DEBUG - 2022-06-30 06:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:22:12 --> Total execution time: 0.0491
DEBUG - 2022-06-30 06:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:22:12 --> Total execution time: 0.0448
DEBUG - 2022-06-30 06:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:22:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 06:22:27 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-30 06:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:25:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 06:25:02 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-30 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:55:16 --> Total execution time: 0.0592
DEBUG - 2022-06-30 06:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:25:19 --> No URI present. Default controller set.
DEBUG - 2022-06-30 06:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:55:19 --> Total execution time: 0.0484
DEBUG - 2022-06-30 06:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 06:27:14 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-30 06:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:01:55 --> Total execution time: 0.1361
DEBUG - 2022-06-30 06:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:04:16 --> Total execution time: 0.1031
DEBUG - 2022-06-30 06:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:04:27 --> Total execution time: 0.0535
DEBUG - 2022-06-30 06:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:05:20 --> Total execution time: 0.0528
DEBUG - 2022-06-30 06:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:05:30 --> Total execution time: 0.0703
DEBUG - 2022-06-30 06:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:05:33 --> Total execution time: 0.0635
DEBUG - 2022-06-30 06:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:05:40 --> Total execution time: 0.0849
DEBUG - 2022-06-30 06:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:05:49 --> Total execution time: 0.0498
DEBUG - 2022-06-30 06:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:07:57 --> Total execution time: 0.1060
DEBUG - 2022-06-30 06:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:09:18 --> Total execution time: 0.0385
DEBUG - 2022-06-30 06:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:14:57 --> Total execution time: 0.3323
DEBUG - 2022-06-30 06:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:15:11 --> Total execution time: 0.0598
DEBUG - 2022-06-30 06:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:15:12 --> Total execution time: 0.0695
DEBUG - 2022-06-30 06:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:15:17 --> Total execution time: 0.0692
DEBUG - 2022-06-30 06:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:15:21 --> Total execution time: 0.0803
DEBUG - 2022-06-30 06:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:15:29 --> Total execution time: 0.0477
DEBUG - 2022-06-30 06:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:48:33 --> No URI present. Default controller set.
DEBUG - 2022-06-30 06:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:18:33 --> Total execution time: 0.1140
DEBUG - 2022-06-30 06:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:18:36 --> Total execution time: 0.0502
DEBUG - 2022-06-30 06:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:18:36 --> Total execution time: 0.0616
DEBUG - 2022-06-30 06:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:18:39 --> Total execution time: 0.0627
DEBUG - 2022-06-30 06:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:18:49 --> Total execution time: 0.0488
DEBUG - 2022-06-30 06:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:18:51 --> Total execution time: 0.0641
DEBUG - 2022-06-30 06:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:18:58 --> Total execution time: 0.0506
DEBUG - 2022-06-30 06:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:19:00 --> Total execution time: 0.0633
DEBUG - 2022-06-30 06:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:19:05 --> Total execution time: 0.0527
DEBUG - 2022-06-30 06:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:19:11 --> Total execution time: 0.0535
DEBUG - 2022-06-30 06:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:19:19 --> Total execution time: 0.0502
DEBUG - 2022-06-30 06:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:20 --> No URI present. Default controller set.
DEBUG - 2022-06-30 06:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:19:20 --> Total execution time: 0.0480
DEBUG - 2022-06-30 06:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:19:25 --> Total execution time: 0.0530
DEBUG - 2022-06-30 06:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:31 --> No URI present. Default controller set.
DEBUG - 2022-06-30 06:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:19:31 --> Total execution time: 0.0518
DEBUG - 2022-06-30 06:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:32 --> No URI present. Default controller set.
DEBUG - 2022-06-30 06:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:19:32 --> Total execution time: 0.0389
DEBUG - 2022-06-30 06:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:19:33 --> Total execution time: 0.1508
DEBUG - 2022-06-30 06:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:19:38 --> Total execution time: 0.0422
DEBUG - 2022-06-30 06:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:19:41 --> Total execution time: 0.0755
DEBUG - 2022-06-30 06:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:19:43 --> Total execution time: 0.0859
DEBUG - 2022-06-30 06:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:19:56 --> Total execution time: 0.0518
DEBUG - 2022-06-30 06:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:20:37 --> Total execution time: 0.1294
DEBUG - 2022-06-30 06:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:20:41 --> Total execution time: 0.0518
DEBUG - 2022-06-30 06:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:20:57 --> Total execution time: 0.1247
DEBUG - 2022-06-30 06:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:20:57 --> Total execution time: 0.1100
DEBUG - 2022-06-30 06:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 06:51:06 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 06:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:51:26 --> Total execution time: 0.0372
DEBUG - 2022-06-30 06:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:51:29 --> Total execution time: 0.1055
DEBUG - 2022-06-30 06:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 06:51:29 --> Total execution time: 0.1550
DEBUG - 2022-06-30 06:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:21:30 --> Total execution time: 0.0957
DEBUG - 2022-06-30 06:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:21:35 --> Total execution time: 0.0756
DEBUG - 2022-06-30 06:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:21:38 --> Total execution time: 0.0342
DEBUG - 2022-06-30 06:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:21:56 --> Total execution time: 0.0514
DEBUG - 2022-06-30 06:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:22:09 --> Total execution time: 0.0603
DEBUG - 2022-06-30 06:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:23:04 --> Total execution time: 0.0543
DEBUG - 2022-06-30 06:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:23:13 --> Total execution time: 0.0526
DEBUG - 2022-06-30 06:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:23:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 06:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:23:14 --> Total execution time: 0.0484
DEBUG - 2022-06-30 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:24:49 --> Total execution time: 0.0545
DEBUG - 2022-06-30 06:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:24:55 --> Total execution time: 0.0526
DEBUG - 2022-06-30 06:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:24:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 06:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:24:56 --> Total execution time: 0.0470
DEBUG - 2022-06-30 06:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:26:38 --> Total execution time: 0.0481
DEBUG - 2022-06-30 06:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 06:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 06:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:26:42 --> Total execution time: 0.1289
DEBUG - 2022-06-30 07:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:30:04 --> Total execution time: 0.2104
DEBUG - 2022-06-30 07:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:32:21 --> Total execution time: 0.1041
DEBUG - 2022-06-30 07:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:32:29 --> Total execution time: 0.0449
DEBUG - 2022-06-30 07:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:04:31 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:34:31 --> Total execution time: 0.1330
DEBUG - 2022-06-30 07:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:11:01 --> Total execution time: 0.1928
DEBUG - 2022-06-30 07:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:13:19 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:43:20 --> Total execution time: 0.1088
DEBUG - 2022-06-30 07:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:13:54 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:43:54 --> Total execution time: 0.0413
DEBUG - 2022-06-30 07:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:44:00 --> Total execution time: 0.0328
DEBUG - 2022-06-30 07:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:44:07 --> Total execution time: 0.0717
DEBUG - 2022-06-30 07:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:16:43 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:46:43 --> Total execution time: 0.1206
DEBUG - 2022-06-30 07:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:47:16 --> Total execution time: 0.0576
DEBUG - 2022-06-30 07:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:17:40 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:47:40 --> Total execution time: 0.0333
DEBUG - 2022-06-30 07:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:47:45 --> Total execution time: 0.0470
DEBUG - 2022-06-30 07:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:47:51 --> Total execution time: 0.0688
DEBUG - 2022-06-30 07:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:48:01 --> Total execution time: 0.0616
DEBUG - 2022-06-30 07:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:48:04 --> Total execution time: 0.1218
DEBUG - 2022-06-30 07:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:48:21 --> Total execution time: 0.0500
DEBUG - 2022-06-30 07:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:48:36 --> Total execution time: 0.1036
DEBUG - 2022-06-30 07:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:48:40 --> Total execution time: 0.0881
DEBUG - 2022-06-30 07:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:48:49 --> Total execution time: 0.0529
DEBUG - 2022-06-30 07:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 07:19:10 --> 404 Page Not Found: User/www.instagram.com
DEBUG - 2022-06-30 07:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 07:19:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 07:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:20:48 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:50:48 --> Total execution time: 0.0356
DEBUG - 2022-06-30 07:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:20:59 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:50:59 --> Total execution time: 0.1267
DEBUG - 2022-06-30 07:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:51:03 --> Total execution time: 0.0553
DEBUG - 2022-06-30 07:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:51:22 --> Total execution time: 0.0692
DEBUG - 2022-06-30 07:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:51:46 --> Total execution time: 0.0645
DEBUG - 2022-06-30 07:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:51:50 --> Total execution time: 0.0690
DEBUG - 2022-06-30 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:52:52 --> Total execution time: 0.0446
DEBUG - 2022-06-30 07:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:53:27 --> Total execution time: 0.0712
DEBUG - 2022-06-30 07:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:53:32 --> Total execution time: 0.0523
DEBUG - 2022-06-30 07:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:53:34 --> Total execution time: 0.0566
DEBUG - 2022-06-30 07:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:53:52 --> Total execution time: 0.0478
DEBUG - 2022-06-30 07:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:25:45 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:55:45 --> Total execution time: 0.0342
DEBUG - 2022-06-30 07:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:55:50 --> Total execution time: 0.0309
DEBUG - 2022-06-30 07:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:57:05 --> Total execution time: 0.0487
DEBUG - 2022-06-30 07:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:27:06 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:57:06 --> Total execution time: 0.0346
DEBUG - 2022-06-30 07:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:57:12 --> Total execution time: 0.0732
DEBUG - 2022-06-30 07:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:58:12 --> Total execution time: 0.0313
DEBUG - 2022-06-30 07:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:58:18 --> Total execution time: 0.1369
DEBUG - 2022-06-30 07:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:58:31 --> Total execution time: 0.0516
DEBUG - 2022-06-30 07:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:58:32 --> Total execution time: 0.0684
DEBUG - 2022-06-30 07:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:58:34 --> Total execution time: 0.0703
DEBUG - 2022-06-30 07:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:58:41 --> Total execution time: 0.1302
DEBUG - 2022-06-30 07:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:58:44 --> Total execution time: 0.0460
DEBUG - 2022-06-30 07:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:58:44 --> Total execution time: 0.0484
DEBUG - 2022-06-30 07:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:58:55 --> Total execution time: 0.0570
DEBUG - 2022-06-30 07:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:58:58 --> Total execution time: 0.0478
DEBUG - 2022-06-30 07:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:59:05 --> Total execution time: 0.0795
DEBUG - 2022-06-30 07:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:59:10 --> Total execution time: 0.0705
DEBUG - 2022-06-30 07:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:59:12 --> Total execution time: 0.0553
DEBUG - 2022-06-30 07:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:59:20 --> Total execution time: 0.0856
DEBUG - 2022-06-30 07:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:59:21 --> Total execution time: 0.0593
DEBUG - 2022-06-30 07:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:59:58 --> Total execution time: 0.0695
DEBUG - 2022-06-30 07:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:59:59 --> Total execution time: 0.0773
DEBUG - 2022-06-30 07:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:59:59 --> Total execution time: 0.0823
DEBUG - 2022-06-30 07:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:59:59 --> Total execution time: 0.0898
DEBUG - 2022-06-30 07:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:00:03 --> Total execution time: 0.1227
DEBUG - 2022-06-30 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:00:40 --> Total execution time: 0.0617
DEBUG - 2022-06-30 07:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:01:37 --> Total execution time: 0.0413
DEBUG - 2022-06-30 07:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:01:40 --> Total execution time: 0.0299
DEBUG - 2022-06-30 07:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:01:52 --> Total execution time: 0.0445
DEBUG - 2022-06-30 07:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:01:58 --> Total execution time: 0.0738
DEBUG - 2022-06-30 07:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:02:07 --> Total execution time: 0.0580
DEBUG - 2022-06-30 07:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:02:12 --> Total execution time: 0.0461
DEBUG - 2022-06-30 07:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:02:27 --> Total execution time: 0.0612
DEBUG - 2022-06-30 07:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:02:32 --> Total execution time: 0.0705
DEBUG - 2022-06-30 07:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:02:34 --> Total execution time: 0.0494
DEBUG - 2022-06-30 07:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:02:44 --> Total execution time: 0.1051
DEBUG - 2022-06-30 07:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:02:57 --> Total execution time: 0.0456
DEBUG - 2022-06-30 07:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:03:03 --> Total execution time: 0.0459
DEBUG - 2022-06-30 07:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:03:12 --> Total execution time: 0.0518
DEBUG - 2022-06-30 07:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:03:17 --> Total execution time: 0.1114
DEBUG - 2022-06-30 07:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:03:22 --> Total execution time: 0.0667
DEBUG - 2022-06-30 07:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:03:26 --> Total execution time: 0.0527
DEBUG - 2022-06-30 07:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:03:27 --> Total execution time: 0.0553
DEBUG - 2022-06-30 07:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:03:35 --> Total execution time: 0.0619
DEBUG - 2022-06-30 07:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:03:42 --> Total execution time: 0.0705
DEBUG - 2022-06-30 07:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:03:48 --> Total execution time: 0.0690
DEBUG - 2022-06-30 07:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:33:59 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:03:59 --> Total execution time: 0.0371
DEBUG - 2022-06-30 07:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:04:04 --> Total execution time: 0.0393
DEBUG - 2022-06-30 07:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:04:30 --> Total execution time: 0.0574
DEBUG - 2022-06-30 07:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:04:30 --> Total execution time: 0.0690
DEBUG - 2022-06-30 07:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:05:04 --> Total execution time: 0.0523
DEBUG - 2022-06-30 07:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:05:05 --> Total execution time: 0.0643
DEBUG - 2022-06-30 07:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:35:05 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:05:05 --> Total execution time: 0.0633
DEBUG - 2022-06-30 07:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:35:16 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:05:16 --> Total execution time: 0.0510
DEBUG - 2022-06-30 07:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:05:20 --> Total execution time: 0.0488
DEBUG - 2022-06-30 07:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:05:21 --> Total execution time: 0.0567
DEBUG - 2022-06-30 07:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:05:24 --> Total execution time: 0.0536
DEBUG - 2022-06-30 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:05:28 --> Total execution time: 0.0554
DEBUG - 2022-06-30 07:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:05:38 --> Total execution time: 0.0716
DEBUG - 2022-06-30 07:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:05:46 --> Total execution time: 0.0303
DEBUG - 2022-06-30 07:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:05:59 --> Total execution time: 0.0792
DEBUG - 2022-06-30 07:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:06:04 --> Total execution time: 0.0506
DEBUG - 2022-06-30 07:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:06:11 --> Total execution time: 0.0690
DEBUG - 2022-06-30 07:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:06:19 --> Total execution time: 0.0686
DEBUG - 2022-06-30 07:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:06:27 --> Total execution time: 0.0599
DEBUG - 2022-06-30 07:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:06:35 --> Total execution time: 0.0508
DEBUG - 2022-06-30 07:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:06:36 --> Total execution time: 0.1113
DEBUG - 2022-06-30 07:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:06:52 --> Total execution time: 0.0530
DEBUG - 2022-06-30 07:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:38:46 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:08:46 --> Total execution time: 0.0556
DEBUG - 2022-06-30 07:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:38:50 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:08:50 --> Total execution time: 0.0354
DEBUG - 2022-06-30 07:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:39:28 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:09:28 --> Total execution time: 0.0419
DEBUG - 2022-06-30 07:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:39:29 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:09:29 --> Total execution time: 0.0667
DEBUG - 2022-06-30 07:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:41:02 --> Total execution time: 0.0397
DEBUG - 2022-06-30 07:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:41:04 --> Total execution time: 0.0529
DEBUG - 2022-06-30 07:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:41:04 --> Total execution time: 0.0561
DEBUG - 2022-06-30 07:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:41:07 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:11:07 --> Total execution time: 0.0517
DEBUG - 2022-06-30 07:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:41:15 --> Total execution time: 0.0500
DEBUG - 2022-06-30 07:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:41:16 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:11:16 --> Total execution time: 0.0462
DEBUG - 2022-06-30 07:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:14:32 --> Total execution time: 0.1263
DEBUG - 2022-06-30 07:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:45:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:15:57 --> Total execution time: 0.0597
DEBUG - 2022-06-30 07:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:45:58 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:15:58 --> Total execution time: 0.0506
DEBUG - 2022-06-30 07:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:16:06 --> Total execution time: 0.0345
DEBUG - 2022-06-30 07:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:16:27 --> Total execution time: 0.0629
DEBUG - 2022-06-30 07:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:46:29 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:16:29 --> Total execution time: 0.0437
DEBUG - 2022-06-30 07:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:16:41 --> Total execution time: 0.0754
DEBUG - 2022-06-30 07:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:50:23 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:20:23 --> Total execution time: 0.1124
DEBUG - 2022-06-30 07:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:20:31 --> Total execution time: 0.0336
DEBUG - 2022-06-30 07:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:20:42 --> Total execution time: 0.0750
DEBUG - 2022-06-30 07:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:20:42 --> Total execution time: 0.0654
DEBUG - 2022-06-30 07:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:20:46 --> Total execution time: 0.0658
DEBUG - 2022-06-30 07:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:20:52 --> Total execution time: 0.0528
DEBUG - 2022-06-30 07:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:20:59 --> Total execution time: 0.0664
DEBUG - 2022-06-30 07:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:21:01 --> Total execution time: 0.2003
DEBUG - 2022-06-30 07:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:21:07 --> Total execution time: 0.0596
DEBUG - 2022-06-30 07:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:21:10 --> Total execution time: 0.0509
DEBUG - 2022-06-30 07:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:51:14 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:21:14 --> Total execution time: 0.0579
DEBUG - 2022-06-30 07:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:21:26 --> Total execution time: 0.0511
DEBUG - 2022-06-30 07:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:21:39 --> Total execution time: 0.0577
DEBUG - 2022-06-30 07:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:52:34 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:22:35 --> Total execution time: 0.0519
DEBUG - 2022-06-30 07:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:53:02 --> No URI present. Default controller set.
DEBUG - 2022-06-30 07:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:23:02 --> Total execution time: 0.0537
DEBUG - 2022-06-30 07:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:23:07 --> Total execution time: 0.0513
DEBUG - 2022-06-30 07:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:23:21 --> Total execution time: 0.0538
DEBUG - 2022-06-30 07:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:23:37 --> Total execution time: 0.0533
DEBUG - 2022-06-30 07:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:24:29 --> Total execution time: 0.0464
DEBUG - 2022-06-30 07:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:24:49 --> Total execution time: 0.0479
DEBUG - 2022-06-30 07:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:25:32 --> Total execution time: 0.0485
DEBUG - 2022-06-30 07:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:25:38 --> Total execution time: 0.0550
DEBUG - 2022-06-30 07:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:25:43 --> Total execution time: 0.0582
DEBUG - 2022-06-30 07:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:25:59 --> Total execution time: 0.0632
DEBUG - 2022-06-30 07:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 07:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:26:03 --> Total execution time: 0.0702
DEBUG - 2022-06-30 07:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:26:08 --> Total execution time: 0.0519
DEBUG - 2022-06-30 07:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:26:16 --> Total execution time: 0.0535
DEBUG - 2022-06-30 07:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:26:18 --> Total execution time: 0.0722
DEBUG - 2022-06-30 07:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:26:26 --> Total execution time: 0.0670
DEBUG - 2022-06-30 07:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 07:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 07:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:26:28 --> Total execution time: 0.0466
DEBUG - 2022-06-30 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:30:03 --> Total execution time: 0.2063
DEBUG - 2022-06-30 08:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:00:22 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:30:22 --> Total execution time: 0.0519
DEBUG - 2022-06-30 08:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:00:22 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:30:22 --> Total execution time: 0.0524
DEBUG - 2022-06-30 08:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:30:26 --> Total execution time: 0.0333
DEBUG - 2022-06-30 08:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:00:30 --> Total execution time: 0.0741
DEBUG - 2022-06-30 08:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:30:43 --> Total execution time: 0.0488
DEBUG - 2022-06-30 08:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:00:46 --> Total execution time: 0.1222
DEBUG - 2022-06-30 08:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:30:53 --> Total execution time: 0.0604
DEBUG - 2022-06-30 08:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:31:11 --> Total execution time: 0.0631
DEBUG - 2022-06-30 08:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:31:16 --> Total execution time: 0.0670
DEBUG - 2022-06-30 08:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:31:17 --> Total execution time: 0.0825
DEBUG - 2022-06-30 08:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:31:19 --> Total execution time: 0.1386
DEBUG - 2022-06-30 08:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:31:32 --> Total execution time: 0.0489
DEBUG - 2022-06-30 08:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 08:02:33 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-30 08:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:02:39 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:32:39 --> Total execution time: 0.0364
DEBUG - 2022-06-30 08:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 08:05:07 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-30 08:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:35:15 --> Total execution time: 0.0948
DEBUG - 2022-06-30 08:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:36:15 --> Total execution time: 0.1235
DEBUG - 2022-06-30 08:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:36:18 --> Total execution time: 0.0593
DEBUG - 2022-06-30 08:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:36:23 --> Total execution time: 0.0716
DEBUG - 2022-06-30 08:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:36:32 --> Total execution time: 0.0455
DEBUG - 2022-06-30 08:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 08:07:15 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-30 08:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:11:54 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:41:54 --> Total execution time: 0.1028
DEBUG - 2022-06-30 08:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:43:00 --> Total execution time: 0.0482
DEBUG - 2022-06-30 08:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:43:11 --> Total execution time: 0.0467
DEBUG - 2022-06-30 08:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:43:43 --> Total execution time: 0.1298
DEBUG - 2022-06-30 08:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:43:49 --> Total execution time: 0.0472
DEBUG - 2022-06-30 08:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:43:51 --> Total execution time: 0.0507
DEBUG - 2022-06-30 08:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:46:38 --> Total execution time: 0.0466
DEBUG - 2022-06-30 08:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:18:17 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:48:17 --> Total execution time: 0.0358
DEBUG - 2022-06-30 08:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:48:21 --> Total execution time: 0.0525
DEBUG - 2022-06-30 08:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:48:31 --> Total execution time: 0.0537
DEBUG - 2022-06-30 08:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:48:35 --> Total execution time: 0.0573
DEBUG - 2022-06-30 08:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:18:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:48:57 --> Total execution time: 0.0518
DEBUG - 2022-06-30 08:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:49:02 --> Total execution time: 0.0837
DEBUG - 2022-06-30 08:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:49:11 --> Total execution time: 0.0597
DEBUG - 2022-06-30 08:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:51:19 --> Total execution time: 0.1092
DEBUG - 2022-06-30 08:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:51:24 --> Total execution time: 0.0852
DEBUG - 2022-06-30 08:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:51:35 --> Total execution time: 0.0531
DEBUG - 2022-06-30 08:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:21:56 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:51:56 --> Total execution time: 0.0406
DEBUG - 2022-06-30 08:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:52:30 --> Total execution time: 0.1187
DEBUG - 2022-06-30 08:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:52:41 --> Total execution time: 0.0619
DEBUG - 2022-06-30 08:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:53:11 --> Total execution time: 0.0507
DEBUG - 2022-06-30 08:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:53:16 --> Total execution time: 0.0644
DEBUG - 2022-06-30 08:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:53:25 --> Total execution time: 0.0532
DEBUG - 2022-06-30 08:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:53:32 --> Total execution time: 0.0595
DEBUG - 2022-06-30 08:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:53:39 --> Total execution time: 0.0489
DEBUG - 2022-06-30 08:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:53:43 --> Total execution time: 0.0678
DEBUG - 2022-06-30 08:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:53:53 --> Total execution time: 0.0504
DEBUG - 2022-06-30 08:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:53:54 --> Total execution time: 0.0606
DEBUG - 2022-06-30 08:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:54:02 --> Total execution time: 0.0551
DEBUG - 2022-06-30 08:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:54:05 --> Total execution time: 0.0666
DEBUG - 2022-06-30 08:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:54:22 --> Total execution time: 0.0676
DEBUG - 2022-06-30 08:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:54:27 --> Total execution time: 0.0691
DEBUG - 2022-06-30 08:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:54:29 --> Total execution time: 0.0555
DEBUG - 2022-06-30 08:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:54:31 --> Total execution time: 0.0733
DEBUG - 2022-06-30 08:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:58:25 --> Total execution time: 0.0982
DEBUG - 2022-06-30 08:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 08:28:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-30 08:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:00:13 --> Total execution time: 0.1653
DEBUG - 2022-06-30 08:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:00:19 --> Total execution time: 0.1176
DEBUG - 2022-06-30 08:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:00:46 --> Total execution time: 0.0743
DEBUG - 2022-06-30 08:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 08:30:49 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 08:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:30:56 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:00:56 --> Total execution time: 0.0368
DEBUG - 2022-06-30 08:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:31:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 08:31:23 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-30 08:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:31:25 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:01:25 --> Total execution time: 0.0346
DEBUG - 2022-06-30 08:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:32:07 --> Total execution time: 0.0508
DEBUG - 2022-06-30 08:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:32:08 --> Total execution time: 0.0645
DEBUG - 2022-06-30 08:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:32:08 --> Total execution time: 0.1228
DEBUG - 2022-06-30 08:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:02:42 --> Total execution time: 0.0735
DEBUG - 2022-06-30 08:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:02:49 --> Total execution time: 0.0774
DEBUG - 2022-06-30 08:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:02:58 --> Total execution time: 0.0561
DEBUG - 2022-06-30 08:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:12 --> Total execution time: 0.0819
DEBUG - 2022-06-30 08:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:21 --> Total execution time: 0.0525
DEBUG - 2022-06-30 08:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:26 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:26 --> Total execution time: 0.0344
DEBUG - 2022-06-30 08:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:28 --> Total execution time: 0.0449
DEBUG - 2022-06-30 08:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:29 --> Total execution time: 0.0568
DEBUG - 2022-06-30 08:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:30 --> Total execution time: 0.0461
DEBUG - 2022-06-30 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:40 --> Total execution time: 0.0578
DEBUG - 2022-06-30 08:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:46 --> Total execution time: 0.0517
DEBUG - 2022-06-30 08:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:48 --> Total execution time: 0.0441
DEBUG - 2022-06-30 08:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:49 --> Total execution time: 0.0576
DEBUG - 2022-06-30 08:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:53 --> Total execution time: 0.0694
DEBUG - 2022-06-30 08:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:55 --> Total execution time: 0.0525
DEBUG - 2022-06-30 08:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:56 --> Total execution time: 0.0540
DEBUG - 2022-06-30 08:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:58 --> Total execution time: 0.0511
DEBUG - 2022-06-30 08:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:03:59 --> Total execution time: 0.0929
DEBUG - 2022-06-30 08:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:04:01 --> Total execution time: 0.0538
DEBUG - 2022-06-30 08:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:04:04 --> Total execution time: 0.0492
DEBUG - 2022-06-30 08:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:04:06 --> Total execution time: 0.0513
DEBUG - 2022-06-30 08:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:04:09 --> Total execution time: 0.0901
DEBUG - 2022-06-30 08:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:04:09 --> Total execution time: 0.0760
DEBUG - 2022-06-30 08:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:04:11 --> Total execution time: 0.0478
DEBUG - 2022-06-30 08:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:04:13 --> Total execution time: 0.0704
DEBUG - 2022-06-30 08:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:06:32 --> Total execution time: 0.0461
DEBUG - 2022-06-30 08:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:06:38 --> Total execution time: 0.0469
DEBUG - 2022-06-30 08:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:06:41 --> Total execution time: 0.0529
DEBUG - 2022-06-30 08:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:06:41 --> Total execution time: 0.0608
DEBUG - 2022-06-30 08:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:06:43 --> Total execution time: 0.0385
DEBUG - 2022-06-30 08:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:45:05 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:15:05 --> Total execution time: 0.1338
DEBUG - 2022-06-30 08:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:45:12 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:15:13 --> Total execution time: 0.1191
DEBUG - 2022-06-30 08:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:18:36 --> Total execution time: 0.3366
DEBUG - 2022-06-30 08:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:50:30 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:20:30 --> Total execution time: 0.0573
DEBUG - 2022-06-30 08:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:50:36 --> Total execution time: 0.0783
DEBUG - 2022-06-30 08:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:50:38 --> Total execution time: 0.0621
DEBUG - 2022-06-30 08:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:50:38 --> Total execution time: 0.0543
DEBUG - 2022-06-30 08:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:21:46 --> Total execution time: 0.0617
DEBUG - 2022-06-30 08:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:22:47 --> Total execution time: 0.1237
DEBUG - 2022-06-30 08:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:53:23 --> Total execution time: 0.0349
DEBUG - 2022-06-30 08:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:53:26 --> Total execution time: 0.0821
DEBUG - 2022-06-30 08:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:53:26 --> Total execution time: 0.1151
DEBUG - 2022-06-30 08:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:23:32 --> Total execution time: 0.0555
DEBUG - 2022-06-30 08:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:54:00 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:24:00 --> Total execution time: 0.0446
DEBUG - 2022-06-30 08:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:54:06 --> Total execution time: 0.0478
DEBUG - 2022-06-30 08:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:54:08 --> Total execution time: 0.0779
DEBUG - 2022-06-30 08:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:54:08 --> Total execution time: 0.1344
DEBUG - 2022-06-30 08:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:54:28 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:24:28 --> Total execution time: 0.0327
DEBUG - 2022-06-30 08:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:54:29 --> No URI present. Default controller set.
DEBUG - 2022-06-30 08:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:24:29 --> Total execution time: 0.0315
DEBUG - 2022-06-30 08:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:24:33 --> Total execution time: 0.0613
DEBUG - 2022-06-30 08:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 08:55:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 08:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 08:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:25:12 --> Total execution time: 1.8918
DEBUG - 2022-06-30 08:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:55:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 08:55:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 08:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 08:55:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 08:55:58 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-30 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:30:02 --> Total execution time: 0.0627
DEBUG - 2022-06-30 09:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:31:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 09:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:31:57 --> Total execution time: 0.0594
DEBUG - 2022-06-30 09:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:31:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 19:31:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 19:31:58 --> Total execution time: 0.1807
DEBUG - 2022-06-30 09:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:32:10 --> Total execution time: 0.0723
DEBUG - 2022-06-30 09:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:32:15 --> Total execution time: 0.1015
DEBUG - 2022-06-30 09:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:02:23 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:32:23 --> Total execution time: 0.0552
DEBUG - 2022-06-30 09:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:32:36 --> Total execution time: 0.0641
DEBUG - 2022-06-30 09:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:33:24 --> Total execution time: 0.0498
DEBUG - 2022-06-30 09:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:34:19 --> Total execution time: 0.0604
DEBUG - 2022-06-30 09:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:34:54 --> Total execution time: 0.0608
DEBUG - 2022-06-30 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:35:21 --> Total execution time: 0.0833
DEBUG - 2022-06-30 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:35:29 --> Total execution time: 0.0394
DEBUG - 2022-06-30 09:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:36:09 --> Total execution time: 0.0596
DEBUG - 2022-06-30 09:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:36:15 --> Total execution time: 0.0523
DEBUG - 2022-06-30 09:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:36:25 --> Total execution time: 0.0673
DEBUG - 2022-06-30 09:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:36:30 --> Total execution time: 0.0814
DEBUG - 2022-06-30 09:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:36:33 --> Total execution time: 0.0521
DEBUG - 2022-06-30 09:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:36:40 --> Total execution time: 0.0773
DEBUG - 2022-06-30 09:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:06:50 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:36:50 --> Total execution time: 0.0356
DEBUG - 2022-06-30 09:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:36:51 --> Total execution time: 0.0599
DEBUG - 2022-06-30 09:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:36:59 --> Total execution time: 0.0584
DEBUG - 2022-06-30 09:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:37:05 --> Total execution time: 0.0646
DEBUG - 2022-06-30 09:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:37:16 --> Total execution time: 0.0465
DEBUG - 2022-06-30 09:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:37:22 --> Total execution time: 0.0501
DEBUG - 2022-06-30 09:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:37:22 --> Total execution time: 0.0517
DEBUG - 2022-06-30 09:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:37:27 --> Total execution time: 0.0527
DEBUG - 2022-06-30 09:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:37:30 --> Total execution time: 0.0700
DEBUG - 2022-06-30 09:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:37:36 --> Total execution time: 0.0472
DEBUG - 2022-06-30 09:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:41:12 --> Total execution time: 0.0497
DEBUG - 2022-06-30 09:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:43:41 --> Total execution time: 0.1298
DEBUG - 2022-06-30 09:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:44:08 --> Total execution time: 0.0495
DEBUG - 2022-06-30 09:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:44:16 --> Total execution time: 0.0401
DEBUG - 2022-06-30 09:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:15:27 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:45:27 --> Total execution time: 0.0390
DEBUG - 2022-06-30 09:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:15:27 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:45:27 --> Total execution time: 0.0416
DEBUG - 2022-06-30 09:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:15:35 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:45:35 --> Total execution time: 0.0497
DEBUG - 2022-06-30 09:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:45:47 --> Total execution time: 0.0545
DEBUG - 2022-06-30 09:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:45:53 --> Total execution time: 0.0513
DEBUG - 2022-06-30 09:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:45:55 --> Total execution time: 0.0459
DEBUG - 2022-06-30 09:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:15:59 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:45:59 --> Total execution time: 0.1096
DEBUG - 2022-06-30 09:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:46:02 --> Total execution time: 0.0557
DEBUG - 2022-06-30 09:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:46:07 --> Total execution time: 0.0417
DEBUG - 2022-06-30 09:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:46:08 --> Total execution time: 0.0388
DEBUG - 2022-06-30 09:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:46:21 --> Total execution time: 0.0481
DEBUG - 2022-06-30 09:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:46:27 --> Total execution time: 0.0725
DEBUG - 2022-06-30 09:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:47:12 --> Total execution time: 0.0486
DEBUG - 2022-06-30 09:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:47:18 --> Total execution time: 0.0509
DEBUG - 2022-06-30 09:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:47:18 --> Total execution time: 0.0487
DEBUG - 2022-06-30 09:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:47:37 --> Total execution time: 0.1184
DEBUG - 2022-06-30 09:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:47:46 --> Total execution time: 0.0749
DEBUG - 2022-06-30 09:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:47:47 --> Total execution time: 0.0546
DEBUG - 2022-06-30 09:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:47:52 --> Total execution time: 0.0452
DEBUG - 2022-06-30 09:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:48:04 --> Total execution time: 0.0305
DEBUG - 2022-06-30 09:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:48:26 --> Total execution time: 0.0322
DEBUG - 2022-06-30 09:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:19:05 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:49:05 --> Total execution time: 0.1236
DEBUG - 2022-06-30 09:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:19:34 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:49:34 --> Total execution time: 0.0362
DEBUG - 2022-06-30 09:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:49:38 --> Total execution time: 0.0310
DEBUG - 2022-06-30 09:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:49:44 --> Total execution time: 0.0474
DEBUG - 2022-06-30 09:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:49:48 --> Total execution time: 0.0801
DEBUG - 2022-06-30 09:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:50:16 --> Total execution time: 0.0490
DEBUG - 2022-06-30 09:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:10 --> Total execution time: 0.1461
DEBUG - 2022-06-30 09:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:23 --> Total execution time: 0.0489
DEBUG - 2022-06-30 09:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:24 --> Total execution time: 0.0438
DEBUG - 2022-06-30 09:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:55:44 --> Total execution time: 0.1247
DEBUG - 2022-06-30 09:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:57:13 --> Total execution time: 0.0497
DEBUG - 2022-06-30 09:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:57:36 --> Total execution time: 0.0589
DEBUG - 2022-06-30 09:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:27:48 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:57:48 --> Total execution time: 0.0389
DEBUG - 2022-06-30 09:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 09:27:48 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-06-30 09:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:59:31 --> Total execution time: 0.0647
DEBUG - 2022-06-30 09:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:59:40 --> Total execution time: 0.0524
DEBUG - 2022-06-30 09:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:29:45 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:59:45 --> Total execution time: 0.0363
DEBUG - 2022-06-30 09:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:59:54 --> Total execution time: 0.0454
DEBUG - 2022-06-30 09:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:59:55 --> Total execution time: 0.1189
DEBUG - 2022-06-30 09:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:00:06 --> Total execution time: 0.0521
DEBUG - 2022-06-30 09:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:00:08 --> Total execution time: 0.0622
DEBUG - 2022-06-30 09:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:02:25 --> Total execution time: 0.0463
DEBUG - 2022-06-30 09:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:03:30 --> Total execution time: 0.0482
DEBUG - 2022-06-30 09:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:33:41 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:03:42 --> Total execution time: 0.0562
DEBUG - 2022-06-30 09:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:03:45 --> Total execution time: 0.0351
DEBUG - 2022-06-30 09:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:04:13 --> Total execution time: 0.0512
DEBUG - 2022-06-30 09:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:04:18 --> Total execution time: 0.0524
DEBUG - 2022-06-30 09:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:04:35 --> Total execution time: 0.0593
DEBUG - 2022-06-30 09:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:04:40 --> Total execution time: 0.0910
DEBUG - 2022-06-30 09:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:04:42 --> Total execution time: 0.0801
DEBUG - 2022-06-30 09:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:05:05 --> Total execution time: 0.0581
DEBUG - 2022-06-30 09:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:05:34 --> Total execution time: 0.1001
DEBUG - 2022-06-30 09:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:07:16 --> Total execution time: 0.0477
DEBUG - 2022-06-30 09:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:07:44 --> Total execution time: 0.0470
DEBUG - 2022-06-30 09:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:37:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:07:57 --> Total execution time: 0.1241
DEBUG - 2022-06-30 09:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:08:09 --> Total execution time: 0.0487
DEBUG - 2022-06-30 09:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:38:11 --> Total execution time: 0.0522
DEBUG - 2022-06-30 09:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:38:12 --> Total execution time: 0.0498
DEBUG - 2022-06-30 09:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:38:12 --> Total execution time: 0.0611
DEBUG - 2022-06-30 09:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:08:37 --> Total execution time: 0.0526
DEBUG - 2022-06-30 09:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:10:02 --> Total execution time: 0.0505
DEBUG - 2022-06-30 09:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:10:36 --> Total execution time: 0.0496
DEBUG - 2022-06-30 09:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:10:44 --> Total execution time: 0.0606
DEBUG - 2022-06-30 09:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:10:55 --> Total execution time: 0.1581
DEBUG - 2022-06-30 09:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:12:07 --> Total execution time: 0.0559
DEBUG - 2022-06-30 09:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:12:08 --> Total execution time: 0.0654
DEBUG - 2022-06-30 09:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:12:11 --> Total execution time: 0.0499
DEBUG - 2022-06-30 09:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:12:14 --> Total execution time: 0.0631
DEBUG - 2022-06-30 09:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 09:42:29 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-30 09:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:12:32 --> Total execution time: 0.0651
DEBUG - 2022-06-30 09:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:12:58 --> Total execution time: 0.0514
DEBUG - 2022-06-30 09:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:43:43 --> Total execution time: 0.0480
DEBUG - 2022-06-30 09:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:44:05 --> Total execution time: 0.0606
DEBUG - 2022-06-30 09:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:45:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 09:45:06 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-30 09:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:46:20 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:16:20 --> Total execution time: 0.0644
DEBUG - 2022-06-30 09:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:46:20 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:16:20 --> Total execution time: 0.0341
DEBUG - 2022-06-30 09:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:16:36 --> Total execution time: 0.0803
DEBUG - 2022-06-30 09:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:47:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 09:47:13 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-30 09:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:18:30 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 09:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:18:30 --> Total execution time: 0.0736
DEBUG - 2022-06-30 09:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:18:59 --> Total execution time: 0.1064
DEBUG - 2022-06-30 09:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:19:16 --> Total execution time: 0.0746
DEBUG - 2022-06-30 09:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:19:46 --> Total execution time: 0.0790
DEBUG - 2022-06-30 09:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:49:56 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:19:56 --> Total execution time: 0.1249
DEBUG - 2022-06-30 09:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:50:07 --> Total execution time: 0.0566
DEBUG - 2022-06-30 09:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:50:12 --> Total execution time: 0.0670
DEBUG - 2022-06-30 09:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:50:58 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:20:58 --> Total execution time: 0.0387
DEBUG - 2022-06-30 09:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:21:06 --> Total execution time: 0.0434
DEBUG - 2022-06-30 09:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:21:09 --> Total execution time: 0.0925
DEBUG - 2022-06-30 09:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:21:29 --> Total execution time: 0.0352
DEBUG - 2022-06-30 09:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:31 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:21:31 --> Total execution time: 0.0517
DEBUG - 2022-06-30 09:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:21:33 --> Total execution time: 0.0449
DEBUG - 2022-06-30 09:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:21:36 --> Total execution time: 0.0414
DEBUG - 2022-06-30 09:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:21:37 --> Total execution time: 0.0451
DEBUG - 2022-06-30 09:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:21:41 --> Total execution time: 0.0394
DEBUG - 2022-06-30 09:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:21:48 --> Total execution time: 0.0567
DEBUG - 2022-06-30 09:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:21:51 --> Total execution time: 0.0401
DEBUG - 2022-06-30 09:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:21:56 --> Total execution time: 0.0450
DEBUG - 2022-06-30 09:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:21:58 --> Total execution time: 0.0643
DEBUG - 2022-06-30 09:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:22:12 --> Total execution time: 0.0497
DEBUG - 2022-06-30 09:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:22:26 --> Total execution time: 0.0581
DEBUG - 2022-06-30 09:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:22:31 --> Total execution time: 0.0514
DEBUG - 2022-06-30 09:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:22:37 --> Total execution time: 0.0438
DEBUG - 2022-06-30 09:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:22:40 --> Total execution time: 0.0583
DEBUG - 2022-06-30 09:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:22:45 --> Total execution time: 0.0544
DEBUG - 2022-06-30 09:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:22:52 --> Total execution time: 0.0768
DEBUG - 2022-06-30 09:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:22:52 --> Total execution time: 0.0386
DEBUG - 2022-06-30 09:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:22:55 --> Total execution time: 0.0487
DEBUG - 2022-06-30 09:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:01 --> Total execution time: 0.0904
DEBUG - 2022-06-30 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:05 --> Total execution time: 0.1116
DEBUG - 2022-06-30 09:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:06 --> Total execution time: 0.0467
DEBUG - 2022-06-30 09:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:13 --> Total execution time: 0.0633
DEBUG - 2022-06-30 09:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:21 --> Total execution time: 0.0593
DEBUG - 2022-06-30 09:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:28 --> Total execution time: 0.0514
DEBUG - 2022-06-30 09:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:28 --> Total execution time: 0.0999
DEBUG - 2022-06-30 09:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:32 --> Total execution time: 0.0883
DEBUG - 2022-06-30 09:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:32 --> Total execution time: 0.0703
DEBUG - 2022-06-30 09:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:34 --> Total execution time: 0.0869
DEBUG - 2022-06-30 09:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:41 --> Total execution time: 0.0505
DEBUG - 2022-06-30 09:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:42 --> Total execution time: 0.1077
DEBUG - 2022-06-30 09:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:45 --> Total execution time: 0.1063
DEBUG - 2022-06-30 20:23:45 --> Total execution time: 0.0948
DEBUG - 2022-06-30 09:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:46 --> Total execution time: 0.0927
DEBUG - 2022-06-30 09:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:50 --> Total execution time: 0.0746
DEBUG - 2022-06-30 09:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:54 --> Total execution time: 0.0489
DEBUG - 2022-06-30 09:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:23:58 --> Total execution time: 0.0521
DEBUG - 2022-06-30 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:24:00 --> Total execution time: 0.0543
DEBUG - 2022-06-30 09:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:24:02 --> Total execution time: 0.0477
DEBUG - 2022-06-30 09:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:24:04 --> Total execution time: 0.0660
DEBUG - 2022-06-30 09:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:24:05 --> Total execution time: 0.0503
DEBUG - 2022-06-30 09:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:24:08 --> Total execution time: 0.0513
DEBUG - 2022-06-30 09:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:24:08 --> Total execution time: 0.0494
DEBUG - 2022-06-30 09:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:24:13 --> Total execution time: 0.0835
DEBUG - 2022-06-30 09:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:24:13 --> Total execution time: 0.0564
DEBUG - 2022-06-30 09:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:24:15 --> Total execution time: 0.0540
DEBUG - 2022-06-30 09:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:24:18 --> Total execution time: 0.0719
DEBUG - 2022-06-30 09:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:24:34 --> Total execution time: 0.0802
DEBUG - 2022-06-30 09:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:24:41 --> Total execution time: 0.0791
DEBUG - 2022-06-30 09:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:24:44 --> Total execution time: 0.0527
DEBUG - 2022-06-30 09:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:24:55 --> Total execution time: 0.0535
DEBUG - 2022-06-30 09:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:25:04 --> Total execution time: 0.0535
DEBUG - 2022-06-30 09:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:25:08 --> Total execution time: 0.0478
DEBUG - 2022-06-30 09:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:26:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 09:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:26:21 --> Total execution time: 0.0789
DEBUG - 2022-06-30 09:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:57:30 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:27:30 --> Total execution time: 0.0368
DEBUG - 2022-06-30 09:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:57:52 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:27:52 --> Total execution time: 0.0521
DEBUG - 2022-06-30 09:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:28:03 --> Total execution time: 0.0332
DEBUG - 2022-06-30 09:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:58:30 --> No URI present. Default controller set.
DEBUG - 2022-06-30 09:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:28:30 --> Total execution time: 0.0512
DEBUG - 2022-06-30 09:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:29:10 --> Total execution time: 0.0626
DEBUG - 2022-06-30 09:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 09:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:29:28 --> Total execution time: 0.0673
DEBUG - 2022-06-30 09:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:29:33 --> Total execution time: 0.0729
DEBUG - 2022-06-30 09:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:29:40 --> Total execution time: 0.0988
DEBUG - 2022-06-30 09:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:29:43 --> Total execution time: 0.0777
DEBUG - 2022-06-30 09:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:29:46 --> Total execution time: 0.0773
DEBUG - 2022-06-30 09:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 09:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 09:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:29:49 --> Total execution time: 0.0684
DEBUG - 2022-06-30 10:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:30:01 --> Total execution time: 0.0568
DEBUG - 2022-06-30 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:30:02 --> Total execution time: 0.0648
DEBUG - 2022-06-30 10:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:30:04 --> Total execution time: 0.0923
DEBUG - 2022-06-30 10:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:30:10 --> Total execution time: 0.0839
DEBUG - 2022-06-30 10:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:23 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:30:23 --> Total execution time: 0.0572
DEBUG - 2022-06-30 10:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:30:29 --> Total execution time: 0.0558
DEBUG - 2022-06-30 10:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:30:31 --> Total execution time: 0.0552
DEBUG - 2022-06-30 10:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:30:34 --> Total execution time: 0.0519
DEBUG - 2022-06-30 10:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:30:37 --> Total execution time: 0.0653
DEBUG - 2022-06-30 10:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:30:37 --> Total execution time: 0.0803
DEBUG - 2022-06-30 10:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:30:41 --> Total execution time: 0.0534
DEBUG - 2022-06-30 10:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:41 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:30:41 --> Total execution time: 0.0526
DEBUG - 2022-06-30 10:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:30:42 --> Total execution time: 0.0783
DEBUG - 2022-06-30 10:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:30:49 --> Total execution time: 0.0475
DEBUG - 2022-06-30 10:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:32:03 --> Total execution time: 0.1362
DEBUG - 2022-06-30 10:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:32:12 --> Total execution time: 0.0450
DEBUG - 2022-06-30 10:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:32:19 --> Total execution time: 0.1265
DEBUG - 2022-06-30 10:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:32:21 --> Total execution time: 0.0633
DEBUG - 2022-06-30 10:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:32:21 --> Total execution time: 0.0397
DEBUG - 2022-06-30 10:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:32:22 --> Total execution time: 0.0407
DEBUG - 2022-06-30 10:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:32:31 --> Total execution time: 0.0552
DEBUG - 2022-06-30 10:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:32:35 --> Total execution time: 0.0600
DEBUG - 2022-06-30 10:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:32:41 --> Total execution time: 0.0513
DEBUG - 2022-06-30 10:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:33:01 --> Total execution time: 0.0405
DEBUG - 2022-06-30 10:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:33:45 --> Total execution time: 0.0520
DEBUG - 2022-06-30 10:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:33:49 --> Total execution time: 0.0533
DEBUG - 2022-06-30 10:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:35:41 --> Total execution time: 0.0558
DEBUG - 2022-06-30 10:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:36:10 --> Total execution time: 0.0721
DEBUG - 2022-06-30 10:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:36:13 --> Total execution time: 0.0489
DEBUG - 2022-06-30 10:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:36:17 --> Total execution time: 0.1554
DEBUG - 2022-06-30 10:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:36:28 --> Total execution time: 0.0584
DEBUG - 2022-06-30 10:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:37:01 --> Total execution time: 0.0662
DEBUG - 2022-06-30 10:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:08:48 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:38:48 --> Total execution time: 0.0389
DEBUG - 2022-06-30 10:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:09:03 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:39:03 --> Total execution time: 0.0728
DEBUG - 2022-06-30 10:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:39:12 --> Total execution time: 0.0303
DEBUG - 2022-06-30 10:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:39:48 --> Total execution time: 0.0629
DEBUG - 2022-06-30 10:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:40:14 --> Total execution time: 0.0534
DEBUG - 2022-06-30 10:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:40:32 --> Total execution time: 0.0547
DEBUG - 2022-06-30 10:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:10:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:10:42 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 10:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:40:43 --> Total execution time: 0.0684
DEBUG - 2022-06-30 10:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:12:24 --> Total execution time: 0.0741
DEBUG - 2022-06-30 10:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:12:28 --> Total execution time: 0.0776
DEBUG - 2022-06-30 10:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:44:02 --> Total execution time: 0.0865
DEBUG - 2022-06-30 10:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:44:20 --> Total execution time: 0.1352
DEBUG - 2022-06-30 10:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:44:30 --> Total execution time: 0.0503
DEBUG - 2022-06-30 10:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:14:59 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:14:59 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:14:59 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:44:59 --> Total execution time: 0.0389
DEBUG - 2022-06-30 20:44:59 --> Total execution time: 0.0340
DEBUG - 2022-06-30 20:44:59 --> Total execution time: 0.0356
DEBUG - 2022-06-30 10:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:14:59 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:44:59 --> Total execution time: 0.0355
DEBUG - 2022-06-30 10:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:49:18 --> Total execution time: 0.0665
DEBUG - 2022-06-30 10:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:49:31 --> Total execution time: 0.1663
DEBUG - 2022-06-30 10:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:49:35 --> Total execution time: 0.0514
DEBUG - 2022-06-30 10:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:50:23 --> Total execution time: 0.0513
DEBUG - 2022-06-30 10:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:50:35 --> Total execution time: 0.0508
DEBUG - 2022-06-30 10:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:50:38 --> Total execution time: 0.0627
DEBUG - 2022-06-30 10:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:50:40 --> Total execution time: 0.0476
DEBUG - 2022-06-30 10:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:50:43 --> Total execution time: 0.0571
DEBUG - 2022-06-30 10:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:50:47 --> Total execution time: 0.0752
DEBUG - 2022-06-30 10:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:50:51 --> Total execution time: 0.0761
DEBUG - 2022-06-30 10:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:50:54 --> Total execution time: 0.0597
DEBUG - 2022-06-30 10:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:51:00 --> Total execution time: 0.0575
DEBUG - 2022-06-30 10:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:51:12 --> Total execution time: 0.0551
DEBUG - 2022-06-30 10:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:21:30 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:51:30 --> Total execution time: 0.0489
DEBUG - 2022-06-30 10:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:51:34 --> Total execution time: 0.0327
DEBUG - 2022-06-30 10:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:51:42 --> Total execution time: 0.0681
DEBUG - 2022-06-30 10:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:51:48 --> Total execution time: 0.0531
DEBUG - 2022-06-30 10:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:51:57 --> Total execution time: 0.0532
DEBUG - 2022-06-30 10:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:52:04 --> Total execution time: 0.0619
DEBUG - 2022-06-30 10:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:52:07 --> Total execution time: 0.0619
DEBUG - 2022-06-30 10:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:52:08 --> Total execution time: 0.0633
DEBUG - 2022-06-30 10:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:52:31 --> Total execution time: 0.0557
DEBUG - 2022-06-30 10:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:52:45 --> Total execution time: 0.0754
DEBUG - 2022-06-30 10:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:52:59 --> Total execution time: 0.0522
DEBUG - 2022-06-30 10:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:53:03 --> Total execution time: 0.0723
DEBUG - 2022-06-30 10:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:53:46 --> Total execution time: 0.0867
DEBUG - 2022-06-30 10:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:54:26 --> Total execution time: 0.0759
DEBUG - 2022-06-30 10:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:24:44 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:54:44 --> Total execution time: 0.1579
DEBUG - 2022-06-30 10:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:57:58 --> Total execution time: 0.2380
DEBUG - 2022-06-30 10:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:58:02 --> Total execution time: 0.0614
DEBUG - 2022-06-30 10:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:58:07 --> Total execution time: 0.0766
DEBUG - 2022-06-30 10:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:58:09 --> Total execution time: 0.0679
DEBUG - 2022-06-30 10:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:58:15 --> Total execution time: 0.0525
DEBUG - 2022-06-30 10:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:58:18 --> Total execution time: 0.0556
DEBUG - 2022-06-30 10:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:58:55 --> Total execution time: 0.0446
DEBUG - 2022-06-30 10:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:28:55 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:58:55 --> Total execution time: 0.0427
DEBUG - 2022-06-30 10:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:59:01 --> Total execution time: 0.0565
DEBUG - 2022-06-30 10:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:59:05 --> Total execution time: 0.0517
DEBUG - 2022-06-30 10:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:59:08 --> Total execution time: 0.0599
DEBUG - 2022-06-30 10:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:59:13 --> Total execution time: 0.0738
DEBUG - 2022-06-30 10:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:29:20 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:59:20 --> Total execution time: 0.0489
DEBUG - 2022-06-30 10:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:59:26 --> Total execution time: 0.0702
DEBUG - 2022-06-30 10:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:59:46 --> Total execution time: 0.0594
DEBUG - 2022-06-30 10:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:30:33 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:00:33 --> Total execution time: 0.0496
DEBUG - 2022-06-30 10:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:00:40 --> Total execution time: 0.0447
DEBUG - 2022-06-30 10:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:00:53 --> Total execution time: 0.0496
DEBUG - 2022-06-30 10:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:01:17 --> Total execution time: 0.0621
DEBUG - 2022-06-30 10:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:01:29 --> Total execution time: 0.0512
DEBUG - 2022-06-30 10:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:01:57 --> Total execution time: 0.0576
DEBUG - 2022-06-30 10:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:32:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:02:57 --> Total execution time: 0.0339
DEBUG - 2022-06-30 10:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:03:03 --> Total execution time: 0.0720
DEBUG - 2022-06-30 10:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:03:22 --> Total execution time: 0.0565
DEBUG - 2022-06-30 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:03:29 --> Total execution time: 0.0861
DEBUG - 2022-06-30 10:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:03:41 --> Total execution time: 0.0955
DEBUG - 2022-06-30 10:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:03:57 --> Total execution time: 0.0566
DEBUG - 2022-06-30 10:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:04:09 --> Total execution time: 0.0452
DEBUG - 2022-06-30 10:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:34:19 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:04:19 --> Total execution time: 0.0349
DEBUG - 2022-06-30 10:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:04:40 --> Total execution time: 0.1556
DEBUG - 2022-06-30 10:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:35:22 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:05:22 --> Total execution time: 0.0379
DEBUG - 2022-06-30 10:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:35:44 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:05:44 --> Total execution time: 0.0344
DEBUG - 2022-06-30 10:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:05:47 --> Total execution time: 0.0417
DEBUG - 2022-06-30 10:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:05:53 --> Total execution time: 0.0446
DEBUG - 2022-06-30 10:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:06:12 --> Total execution time: 0.0532
DEBUG - 2022-06-30 10:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:06:19 --> Total execution time: 0.0672
DEBUG - 2022-06-30 10:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:06:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 10:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:06:20 --> Total execution time: 0.0665
DEBUG - 2022-06-30 10:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:06:26 --> Total execution time: 0.0589
DEBUG - 2022-06-30 10:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:06:33 --> Total execution time: 0.0458
DEBUG - 2022-06-30 10:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:06:37 --> Total execution time: 0.0477
DEBUG - 2022-06-30 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:08:33 --> Total execution time: 0.0457
DEBUG - 2022-06-30 10:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:09:07 --> Total execution time: 0.0510
DEBUG - 2022-06-30 10:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:09:12 --> Total execution time: 0.0530
DEBUG - 2022-06-30 10:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:09:18 --> Total execution time: 0.0495
DEBUG - 2022-06-30 10:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:09:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 10:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:09:19 --> Total execution time: 0.0455
DEBUG - 2022-06-30 10:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:09:24 --> Total execution time: 0.0583
DEBUG - 2022-06-30 10:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:09:39 --> Total execution time: 0.0530
DEBUG - 2022-06-30 10:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:10:10 --> Total execution time: 0.0898
DEBUG - 2022-06-30 10:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:10:18 --> Total execution time: 0.0521
DEBUG - 2022-06-30 10:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:10:28 --> Total execution time: 0.0538
DEBUG - 2022-06-30 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:18 --> 404 Page Not Found: Shell4php/index
DEBUG - 2022-06-30 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:19 --> 404 Page Not Found: Upsphp/index
DEBUG - 2022-06-30 10:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:20 --> 404 Page Not Found: Ruphp/index
DEBUG - 2022-06-30 10:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:21 --> 404 Page Not Found: Ifphp/index
DEBUG - 2022-06-30 10:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:22 --> 404 Page Not Found: Vulnphp/index
DEBUG - 2022-06-30 10:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:23 --> 404 Page Not Found: Fwphp/index
DEBUG - 2022-06-30 10:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:24 --> 404 Page Not Found: Skipperphp/index
DEBUG - 2022-06-30 10:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:25 --> 404 Page Not Found: Skippershellphp/index
DEBUG - 2022-06-30 10:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:26 --> 404 Page Not Found: Ttttphp/index
DEBUG - 2022-06-30 10:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:27 --> 404 Page Not Found: Tshopphp/index
DEBUG - 2022-06-30 10:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:28 --> 404 Page Not Found: Alfaphp/index
DEBUG - 2022-06-30 10:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:29 --> 404 Page Not Found: Shellphp/index
DEBUG - 2022-06-30 10:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:30 --> 404 Page Not Found: Inje3ctorphp/index
DEBUG - 2022-06-30 10:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:31 --> 404 Page Not Found: Saudiphp/index
DEBUG - 2022-06-30 10:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:32 --> 404 Page Not Found: Wsophp/index
DEBUG - 2022-06-30 10:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:33 --> 404 Page Not Found: Alfashellphp/index
DEBUG - 2022-06-30 10:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:34 --> 404 Page Not Found: My_alfaphp/index
DEBUG - 2022-06-30 10:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:35 --> 404 Page Not Found: Uploaderphp/index
DEBUG - 2022-06-30 10:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:36 --> 404 Page Not Found: Upphp/index
DEBUG - 2022-06-30 10:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:37 --> 404 Page Not Found: Hackedphp/index
DEBUG - 2022-06-30 10:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:39 --> 404 Page Not Found: Priv8php/index
DEBUG - 2022-06-30 10:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:40 --> 404 Page Not Found: Navirphp/index
DEBUG - 2022-06-30 10:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:40 --> 404 Page Not Found: Cmd13php/index
DEBUG - 2022-06-30 10:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:41 --> 404 Page Not Found: Inc20k1php/index
DEBUG - 2022-06-30 10:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:42 --> 404 Page Not Found: 1indexphp/index
DEBUG - 2022-06-30 10:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:43 --> 404 Page Not Found: 404php/index
DEBUG - 2022-06-30 10:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:44 --> 404 Page Not Found: Swmphp/index
DEBUG - 2022-06-30 10:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:45 --> 404 Page Not Found: Wpphp/index
DEBUG - 2022-06-30 10:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:46 --> 404 Page Not Found: Docphp/index
DEBUG - 2022-06-30 10:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:47 --> 404 Page Not Found: Shxphp/index
DEBUG - 2022-06-30 10:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:48 --> 404 Page Not Found: Wsphp/index
DEBUG - 2022-06-30 10:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:49 --> 404 Page Not Found: Mphp/index
DEBUG - 2022-06-30 10:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:50 --> 404 Page Not Found: Edit-formphp/index
DEBUG - 2022-06-30 10:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:51 --> 404 Page Not Found: LEAFphp/index
DEBUG - 2022-06-30 10:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:52 --> 404 Page Not Found: Leafmailerphp/index
DEBUG - 2022-06-30 10:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:53 --> 404 Page Not Found: Mailerphp/index
DEBUG - 2022-06-30 10:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:54 --> 404 Page Not Found: Leafmailer28php/index
DEBUG - 2022-06-30 10:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:55 --> 404 Page Not Found: Leafphp/index
DEBUG - 2022-06-30 10:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:56 --> 404 Page Not Found: Leafphp/index
DEBUG - 2022-06-30 10:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:57 --> 404 Page Not Found: Xphp/index
DEBUG - 2022-06-30 10:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:58 --> 404 Page Not Found: Srxphp/index
DEBUG - 2022-06-30 10:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:42:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:42:59 --> 404 Page Not Found: 1337php/index
DEBUG - 2022-06-30 10:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:00 --> 404 Page Not Found: Xxphp/index
DEBUG - 2022-06-30 10:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:01 --> 404 Page Not Found: XxXphp/index
DEBUG - 2022-06-30 10:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:02 --> 404 Page Not Found: Lfphp/index
DEBUG - 2022-06-30 10:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:03 --> 404 Page Not Found: Alexphp/index
DEBUG - 2022-06-30 10:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:04 --> 404 Page Not Found: Newphp/index
DEBUG - 2022-06-30 10:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:05 --> 404 Page Not Found: Marijuanaphp/index
DEBUG - 2022-06-30 10:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:07 --> 404 Page Not Found: Gazaphp/index
DEBUG - 2022-06-30 10:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:07 --> 404 Page Not Found: Wp-adminphp/index
DEBUG - 2022-06-30 10:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:09 --> 404 Page Not Found: 3indexphp/index
DEBUG - 2022-06-30 10:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:10 --> 404 Page Not Found: Wikindexphp/index
DEBUG - 2022-06-30 10:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:11 --> 404 Page Not Found: Wso1php/index
DEBUG - 2022-06-30 10:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:12 --> 404 Page Not Found: Bbphp/index
DEBUG - 2022-06-30 10:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:13 --> 404 Page Not Found: Luxphp/index
DEBUG - 2022-06-30 10:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:14 --> 404 Page Not Found: Haxorphp/index
DEBUG - 2022-06-30 10:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:15 --> 404 Page Not Found: Aphp/index
DEBUG - 2022-06-30 10:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:16 --> 404 Page Not Found: Zphp/index
DEBUG - 2022-06-30 10:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:17 --> 404 Page Not Found: Ephp/index
DEBUG - 2022-06-30 10:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:18 --> 404 Page Not Found: Rphp/index
DEBUG - 2022-06-30 10:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:19 --> 404 Page Not Found: Tphp/index
DEBUG - 2022-06-30 10:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:20 --> 404 Page Not Found: Yphp/index
DEBUG - 2022-06-30 10:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:21 --> 404 Page Not Found: Uphp/index
DEBUG - 2022-06-30 10:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:22 --> 404 Page Not Found: Iphp/index
DEBUG - 2022-06-30 10:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:23 --> 404 Page Not Found: Ophp/index
DEBUG - 2022-06-30 10:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:24 --> 404 Page Not Found: Pphp/index
DEBUG - 2022-06-30 10:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:25 --> 404 Page Not Found: Qphp/index
DEBUG - 2022-06-30 10:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:26 --> 404 Page Not Found: Sphp/index
DEBUG - 2022-06-30 10:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:27 --> 404 Page Not Found: Dphp/index
DEBUG - 2022-06-30 10:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:28 --> 404 Page Not Found: Fphp/index
DEBUG - 2022-06-30 10:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:29 --> 404 Page Not Found: Gphp/index
DEBUG - 2022-06-30 10:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:30 --> 404 Page Not Found: Hphp/index
DEBUG - 2022-06-30 10:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:31 --> 404 Page Not Found: Jphp/index
DEBUG - 2022-06-30 10:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:32 --> 404 Page Not Found: Kphp/index
DEBUG - 2022-06-30 10:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:33 --> 404 Page Not Found: Lphp/index
DEBUG - 2022-06-30 10:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:34 --> 404 Page Not Found: Mphp/index
DEBUG - 2022-06-30 10:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:35 --> 404 Page Not Found: Wphp/index
DEBUG - 2022-06-30 10:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:36 --> 404 Page Not Found: Xphp/index
DEBUG - 2022-06-30 10:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:37 --> 404 Page Not Found: Cphp/index
DEBUG - 2022-06-30 10:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:38 --> 404 Page Not Found: Vphp/index
DEBUG - 2022-06-30 10:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:39 --> 404 Page Not Found: Bphp/index
DEBUG - 2022-06-30 10:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:40 --> 404 Page Not Found: Nphp/index
DEBUG - 2022-06-30 10:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:41 --> 404 Page Not Found: New-indexphp/index
DEBUG - 2022-06-30 10:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:42 --> 404 Page Not Found: Old-indexphp/index
DEBUG - 2022-06-30 10:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:43 --> 404 Page Not Found: Sendemailphp/index
DEBUG - 2022-06-30 10:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:44 --> 404 Page Not Found: Shellphp/index
DEBUG - 2022-06-30 10:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:45 --> 404 Page Not Found: 3indexphp/index
DEBUG - 2022-06-30 10:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:46 --> 404 Page Not Found: 2indexphp/index
DEBUG - 2022-06-30 10:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:47 --> 404 Page Not Found: Kindexphp/index
DEBUG - 2022-06-30 10:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:48 --> 404 Page Not Found: Cpanelphp/index
DEBUG - 2022-06-30 10:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:49 --> 404 Page Not Found: Cpphp/index
DEBUG - 2022-06-30 10:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:50 --> 404 Page Not Found: Cpanelphp/index
DEBUG - 2022-06-30 10:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:51 --> 404 Page Not Found: Marphp/index
DEBUG - 2022-06-30 10:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:52 --> 404 Page Not Found: Sym403php/index
DEBUG - 2022-06-30 10:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:53 --> 404 Page Not Found: Contentphp/index
DEBUG - 2022-06-30 10:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:54 --> 404 Page Not Found: 1indexphp/index
DEBUG - 2022-06-30 10:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:55 --> 404 Page Not Found: Wikindexphp/index
DEBUG - 2022-06-30 10:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:56 --> 404 Page Not Found: FoxWSOv1php/index
DEBUG - 2022-06-30 10:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:57 --> 404 Page Not Found: Alfaphp/index
DEBUG - 2022-06-30 10:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:58 --> 404 Page Not Found: Alfphp/index
DEBUG - 2022-06-30 10:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:43:59 --> 404 Page Not Found: Wsphp/index
DEBUG - 2022-06-30 10:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:01 --> 404 Page Not Found: 1php/index
DEBUG - 2022-06-30 10:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:02 --> 404 Page Not Found: 2php/index
DEBUG - 2022-06-30 10:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:03 --> 404 Page Not Found: 3php/index
DEBUG - 2022-06-30 10:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:04 --> 404 Page Not Found: Leafphp/index
DEBUG - 2022-06-30 10:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:05 --> 404 Page Not Found: Bbphp/index
DEBUG - 2022-06-30 10:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:06 --> 404 Page Not Found: Leafmailer28php/index
DEBUG - 2022-06-30 10:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:07 --> 404 Page Not Found: Mailerphp/index
DEBUG - 2022-06-30 10:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:08 --> 404 Page Not Found: 1php/index
DEBUG - 2022-06-30 10:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:09 --> 404 Page Not Found: Kphp/index
DEBUG - 2022-06-30 10:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:10 --> 404 Page Not Found: Alexphp/index
DEBUG - 2022-06-30 10:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:11 --> 404 Page Not Found: Lfphp/index
DEBUG - 2022-06-30 10:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:12 --> 404 Page Not Found: Alfaphp/index
DEBUG - 2022-06-30 10:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:13 --> 404 Page Not Found: Alfphp/index
DEBUG - 2022-06-30 10:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:14 --> 404 Page Not Found: 2php/index
DEBUG - 2022-06-30 10:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:15 --> 404 Page Not Found: Xoxphp/index
DEBUG - 2022-06-30 10:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:16 --> 404 Page Not Found: Xophp/index
DEBUG - 2022-06-30 10:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:17 --> 404 Page Not Found: Miphp/index
DEBUG - 2022-06-30 10:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:18 --> 404 Page Not Found: Sphp/index
DEBUG - 2022-06-30 10:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:20 --> 404 Page Not Found: Alexusmailer%2020php/index
DEBUG - 2022-06-30 10:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:21 --> 404 Page Not Found: Rssphp/index
DEBUG - 2022-06-30 10:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:22 --> 404 Page Not Found: Priv8php/index
DEBUG - 2022-06-30 10:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:23 --> 404 Page Not Found: WSOphp/index
DEBUG - 2022-06-30 10:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:24 --> 404 Page Not Found: Alwsophp/index
DEBUG - 2022-06-30 10:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:25 --> 404 Page Not Found: Wp-content/includes
DEBUG - 2022-06-30 10:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:26 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-30 10:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:27 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-30 10:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:28 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-06-30 10:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:29 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-06-30 10:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:30 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-06-30 10:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:31 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-06-30 10:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:32 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-06-30 10:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:33 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-06-30 10:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:34 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-06-30 10:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:34 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-06-30 10:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:35 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-06-30 10:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:36 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-06-30 10:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:37 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-30 10:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:39 --> 404 Page Not Found: Wp-includes/sys.php
DEBUG - 2022-06-30 10:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:40 --> 404 Page Not Found: Xxxphp/index
DEBUG - 2022-06-30 10:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:41 --> 404 Page Not Found: 11indexphp/index
DEBUG - 2022-06-30 10:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:42 --> 404 Page Not Found: Hellophp/index
DEBUG - 2022-06-30 10:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:43 --> 404 Page Not Found: Faphp/index
DEBUG - 2022-06-30 10:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:44 --> 404 Page Not Found: 3php/index
DEBUG - 2022-06-30 10:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:44 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:14:44 --> Total execution time: 0.1158
DEBUG - 2022-06-30 10:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:45 --> 404 Page Not Found: Alexus-mailerphp/index
DEBUG - 2022-06-30 10:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:46 --> 404 Page Not Found: Wsophp/index
DEBUG - 2022-06-30 10:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:47 --> 404 Page Not Found: Shellphp/index
DEBUG - 2022-06-30 10:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:14:47 --> Total execution time: 0.0483
DEBUG - 2022-06-30 10:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:48 --> 404 Page Not Found: Docphp/index
DEBUG - 2022-06-30 10:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:49 --> 404 Page Not Found: Miniphp/index
DEBUG - 2022-06-30 10:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:50 --> 404 Page Not Found: Wp-adphp/index
DEBUG - 2022-06-30 10:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:51 --> 404 Page Not Found: Wp-filephp/index
DEBUG - 2022-06-30 10:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:52 --> 404 Page Not Found: Okphp/index
DEBUG - 2022-06-30 10:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:53 --> 404 Page Not Found: Wso2php/index
DEBUG - 2022-06-30 10:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:54 --> 404 Page Not Found: Wso1php/index
DEBUG - 2022-06-30 10:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:55 --> 404 Page Not Found: Ifphp/index
DEBUG - 2022-06-30 10:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:56 --> 404 Page Not Found: Kkphp/index
DEBUG - 2022-06-30 10:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:57 --> 404 Page Not Found: Aphp/index
DEBUG - 2022-06-30 10:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:58 --> 404 Page Not Found: Zphp/index
DEBUG - 2022-06-30 10:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:44:59 --> 404 Page Not Found: Ephp/index
DEBUG - 2022-06-30 10:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:14:59 --> Total execution time: 0.0563
DEBUG - 2022-06-30 10:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:00 --> 404 Page Not Found: Rphp/index
DEBUG - 2022-06-30 10:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:01 --> 404 Page Not Found: Tphp/index
DEBUG - 2022-06-30 10:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:02 --> 404 Page Not Found: Yphp/index
DEBUG - 2022-06-30 10:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:03 --> 404 Page Not Found: Uphp/index
DEBUG - 2022-06-30 10:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:04 --> 404 Page Not Found: Iphp/index
DEBUG - 2022-06-30 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:05 --> 404 Page Not Found: Ophp/index
DEBUG - 2022-06-30 10:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:06 --> 404 Page Not Found: Mailerphp/index
DEBUG - 2022-06-30 10:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:07 --> 404 Page Not Found: Anonephp/index
DEBUG - 2022-06-30 10:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:08 --> 404 Page Not Found: Wp-configerphp/index
DEBUG - 2022-06-30 10:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:09 --> 404 Page Not Found: Alfaphp/index
DEBUG - 2022-06-30 10:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:10 --> 404 Page Not Found: Wsophp/index
DEBUG - 2022-06-30 10:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:11 --> 404 Page Not Found: Cphp/index
DEBUG - 2022-06-30 10:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:15:12 --> Total execution time: 0.0527
DEBUG - 2022-06-30 10:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:12 --> 404 Page Not Found: 1php/index
DEBUG - 2022-06-30 10:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:13 --> 404 Page Not Found: Sendphp/index
DEBUG - 2022-06-30 10:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:14 --> 404 Page Not Found: 3php/index
DEBUG - 2022-06-30 10:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:15 --> 404 Page Not Found: Wp-rssphp/index
DEBUG - 2022-06-30 10:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:16 --> 404 Page Not Found: Wp-cachephp/index
DEBUG - 2022-06-30 10:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:17 --> 404 Page Not Found: Sendmailphp/index
DEBUG - 2022-06-30 10:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:18 --> 404 Page Not Found: Wp/rahma.php
DEBUG - 2022-06-30 10:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:19 --> 404 Page Not Found: Rahmaphp/index
DEBUG - 2022-06-30 10:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:20 --> 404 Page Not Found: Nasgorphp/index
DEBUG - 2022-06-30 10:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:21 --> 404 Page Not Found: 404php/index
DEBUG - 2022-06-30 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:22 --> 404 Page Not Found: Symphp/index
DEBUG - 2022-06-30 10:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:23 --> 404 Page Not Found: Wp-confirmphp/index
DEBUG - 2022-06-30 10:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:24 --> 404 Page Not Found: Alfa123php/index
DEBUG - 2022-06-30 10:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:25 --> 404 Page Not Found: Drphp/index
DEBUG - 2022-06-30 10:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:26 --> 404 Page Not Found: Bypassphp/index
DEBUG - 2022-06-30 10:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:27 --> 404 Page Not Found: Wp-blogphp/index
DEBUG - 2022-06-30 10:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:28 --> 404 Page Not Found: Sym403php/index
DEBUG - 2022-06-30 10:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:29 --> 404 Page Not Found: Priv8php/index
DEBUG - 2022-06-30 10:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:30 --> 404 Page Not Found: Dataphp/index
DEBUG - 2022-06-30 10:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:31 --> 404 Page Not Found: Wp-onephp/index
DEBUG - 2022-06-30 10:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:32 --> 404 Page Not Found: Alexusphp/index
DEBUG - 2022-06-30 10:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:33 --> 404 Page Not Found: Edit-formphp/index
DEBUG - 2022-06-30 10:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:34 --> 404 Page Not Found: Wso1337php/index
DEBUG - 2022-06-30 10:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:35 --> 404 Page Not Found: Wwwphp/index
DEBUG - 2022-06-30 10:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:15:36 --> Total execution time: 0.1280
DEBUG - 2022-06-30 10:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:36 --> 404 Page Not Found: Uploads/contexmini.php
DEBUG - 2022-06-30 10:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:37 --> 404 Page Not Found: Blogphp/index
DEBUG - 2022-06-30 10:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:38 --> 404 Page Not Found: Itphp/index
DEBUG - 2022-06-30 10:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:39 --> 404 Page Not Found: Kissphp/index
DEBUG - 2022-06-30 10:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:40 --> 404 Page Not Found: 0php/index
DEBUG - 2022-06-30 10:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:41 --> 404 Page Not Found: Wp2php/index
DEBUG - 2022-06-30 10:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:42 --> 404 Page Not Found: Owlphp/index
DEBUG - 2022-06-30 10:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:43 --> 404 Page Not Found: Symlinkphp/index
DEBUG - 2022-06-30 10:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:44 --> 404 Page Not Found: Ohayophp/index
DEBUG - 2022-06-30 10:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:45 --> 404 Page Not Found: 100php/index
DEBUG - 2022-06-30 10:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:46 --> 404 Page Not Found: 777php/index
DEBUG - 2022-06-30 10:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:47 --> 404 Page Not Found: Wp-content/wp-logins.php
DEBUG - 2022-06-30 10:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:48 --> 404 Page Not Found: 1indexphp/index
DEBUG - 2022-06-30 10:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:49 --> 404 Page Not Found: 2indexphp/index
DEBUG - 2022-06-30 10:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:50 --> 404 Page Not Found: Wp-content/wp-admin.php
DEBUG - 2022-06-30 10:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:51 --> 404 Page Not Found: Wp-adminphp/index
DEBUG - 2022-06-30 10:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:52 --> 404 Page Not Found: Miniphp/index
DEBUG - 2022-06-30 10:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:53 --> 404 Page Not Found: Old-indexphp/index
DEBUG - 2022-06-30 10:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:54 --> 404 Page Not Found: Docphp/index
DEBUG - 2022-06-30 10:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:55 --> 404 Page Not Found: Shxphp/index
DEBUG - 2022-06-30 10:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:56 --> 404 Page Not Found: FoxWSOphp/index
DEBUG - 2022-06-30 10:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:57 --> 404 Page Not Found: Xphp/index
DEBUG - 2022-06-30 10:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:58 --> 404 Page Not Found: Cmsphp/index
DEBUG - 2022-06-30 10:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:15:58 --> Total execution time: 0.0580
DEBUG - 2022-06-30 10:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:45:59 --> 404 Page Not Found: Stindexphp/index
DEBUG - 2022-06-30 10:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:00 --> 404 Page Not Found: Wp-uploadsphp/index
DEBUG - 2022-06-30 10:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:01 --> 404 Page Not Found: Autoload_classmapphp/index
DEBUG - 2022-06-30 10:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:02 --> 404 Page Not Found: Gelphp/index
DEBUG - 2022-06-30 10:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:03 --> 404 Page Not Found: Defau1tphp/index
DEBUG - 2022-06-30 10:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:04 --> 404 Page Not Found: 0bytephp/index
DEBUG - 2022-06-30 10:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:05 --> 404 Page Not Found: Wpphp/index
DEBUG - 2022-06-30 10:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:06 --> 404 Page Not Found: 41php/index
DEBUG - 2022-06-30 10:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:07 --> 404 Page Not Found: 4pricephp/index
DEBUG - 2022-06-30 10:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:08 --> 404 Page Not Found: MARIJUANAphp/index
DEBUG - 2022-06-30 10:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:09 --> 404 Page Not Found: Fphp/index
DEBUG - 2022-06-30 10:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:10 --> 404 Page Not Found: Fkphp/index
DEBUG - 2022-06-30 10:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:16:10 --> Total execution time: 0.0515
DEBUG - 2022-06-30 10:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:11 --> 404 Page Not Found: Wikindexphp/index
DEBUG - 2022-06-30 10:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:12 --> 404 Page Not Found: Xoxphp/index
DEBUG - 2022-06-30 10:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:13 --> 404 Page Not Found: Newphp/index
DEBUG - 2022-06-30 10:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:16:13 --> Total execution time: 0.0484
DEBUG - 2022-06-30 10:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:14 --> 404 Page Not Found: 3indexphp/index
DEBUG - 2022-06-30 10:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:15 --> 404 Page Not Found: Sindexphp/index
DEBUG - 2022-06-30 10:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:16 --> 404 Page Not Found: Baindexphp/index
DEBUG - 2022-06-30 10:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:17 --> 404 Page Not Found: New-indexphp/index
DEBUG - 2022-06-30 10:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:18 --> 404 Page Not Found: Wiphp/index
DEBUG - 2022-06-30 10:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:16:18 --> Total execution time: 0.1075
DEBUG - 2022-06-30 10:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:19 --> 404 Page Not Found: XxXphp/index
DEBUG - 2022-06-30 10:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 10:46:20 --> 404 Page Not Found: Marphp/index
DEBUG - 2022-06-30 10:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:16:24 --> Total execution time: 0.0827
DEBUG - 2022-06-30 10:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:16:26 --> Total execution time: 0.0562
DEBUG - 2022-06-30 10:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:16:27 --> Total execution time: 0.0482
DEBUG - 2022-06-30 10:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:16:29 --> Total execution time: 0.0550
DEBUG - 2022-06-30 10:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:16:37 --> Total execution time: 0.0612
DEBUG - 2022-06-30 10:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:16:42 --> Total execution time: 0.0515
DEBUG - 2022-06-30 10:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:16:57 --> Total execution time: 0.0506
DEBUG - 2022-06-30 10:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:17:09 --> Total execution time: 0.0522
DEBUG - 2022-06-30 10:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:17:12 --> Total execution time: 0.0446
DEBUG - 2022-06-30 10:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:17:17 --> Total execution time: 0.0830
DEBUG - 2022-06-30 10:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:17:23 --> Total execution time: 0.0686
DEBUG - 2022-06-30 10:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:17:33 --> Total execution time: 0.0740
DEBUG - 2022-06-30 10:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:17:37 --> Total execution time: 0.0609
DEBUG - 2022-06-30 10:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:17:49 --> Total execution time: 0.0766
DEBUG - 2022-06-30 10:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:17:51 --> Total execution time: 0.0422
DEBUG - 2022-06-30 10:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:17:52 --> Total execution time: 0.0532
DEBUG - 2022-06-30 10:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:17:52 --> Total execution time: 0.0549
DEBUG - 2022-06-30 10:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:17:54 --> Total execution time: 0.0478
DEBUG - 2022-06-30 10:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:17:54 --> Total execution time: 0.0536
DEBUG - 2022-06-30 10:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:47:56 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:17:56 --> Total execution time: 0.0464
DEBUG - 2022-06-30 10:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:18:08 --> Total execution time: 0.0676
DEBUG - 2022-06-30 10:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:48:42 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:18:42 --> Total execution time: 0.0370
DEBUG - 2022-06-30 10:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:48:44 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:18:44 --> Total execution time: 0.0546
DEBUG - 2022-06-30 10:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:18:46 --> Total execution time: 0.0444
DEBUG - 2022-06-30 10:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:49:00 --> Total execution time: 0.0504
DEBUG - 2022-06-30 10:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:49:02 --> Total execution time: 0.0688
DEBUG - 2022-06-30 10:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:49:02 --> Total execution time: 0.1170
DEBUG - 2022-06-30 10:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:50:30 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:20:30 --> Total execution time: 0.1955
DEBUG - 2022-06-30 10:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:22:30 --> Total execution time: 0.1325
DEBUG - 2022-06-30 10:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:22:35 --> Total execution time: 0.0586
DEBUG - 2022-06-30 10:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:53:25 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:23:25 --> Total execution time: 0.1195
DEBUG - 2022-06-30 10:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:23:56 --> Total execution time: 0.0556
DEBUG - 2022-06-30 10:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:23:59 --> Total execution time: 0.0850
DEBUG - 2022-06-30 10:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:24:04 --> Total execution time: 0.0516
DEBUG - 2022-06-30 10:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:24:08 --> Total execution time: 0.0539
DEBUG - 2022-06-30 10:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:24:11 --> Total execution time: 0.0549
DEBUG - 2022-06-30 10:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:24:14 --> Total execution time: 0.0487
DEBUG - 2022-06-30 10:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:24:23 --> Total execution time: 0.0745
DEBUG - 2022-06-30 10:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:24:31 --> Total execution time: 0.0758
DEBUG - 2022-06-30 10:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:54:32 --> Total execution time: 0.0604
DEBUG - 2022-06-30 10:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:54:33 --> Total execution time: 0.0567
DEBUG - 2022-06-30 10:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:54:33 --> Total execution time: 0.1079
DEBUG - 2022-06-30 10:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:24:46 --> Total execution time: 0.0517
DEBUG - 2022-06-30 10:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:25:07 --> Total execution time: 0.0516
DEBUG - 2022-06-30 10:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:25:11 --> Total execution time: 0.0533
DEBUG - 2022-06-30 10:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:25:21 --> Total execution time: 0.0473
DEBUG - 2022-06-30 10:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:25:41 --> Total execution time: 0.0476
DEBUG - 2022-06-30 10:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:25:46 --> Total execution time: 0.0551
DEBUG - 2022-06-30 10:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:25:49 --> Total execution time: 0.0482
DEBUG - 2022-06-30 10:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:25:50 --> Total execution time: 0.0382
DEBUG - 2022-06-30 10:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:25:52 --> Total execution time: 0.0515
DEBUG - 2022-06-30 10:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:55:53 --> Total execution time: 0.0435
DEBUG - 2022-06-30 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:55:54 --> Total execution time: 0.0498
DEBUG - 2022-06-30 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:55:54 --> Total execution time: 0.0838
DEBUG - 2022-06-30 10:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:25:54 --> Total execution time: 0.0664
DEBUG - 2022-06-30 10:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:25:56 --> Total execution time: 0.0868
DEBUG - 2022-06-30 10:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:25:58 --> Total execution time: 0.0457
DEBUG - 2022-06-30 10:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:26:00 --> Total execution time: 0.0576
DEBUG - 2022-06-30 10:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:26:01 --> Total execution time: 0.0444
DEBUG - 2022-06-30 10:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:26:04 --> Total execution time: 0.0452
DEBUG - 2022-06-30 10:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:26:07 --> Total execution time: 0.0477
DEBUG - 2022-06-30 10:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:26:10 --> Total execution time: 0.0470
DEBUG - 2022-06-30 10:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:26:12 --> Total execution time: 0.0478
DEBUG - 2022-06-30 10:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:26:17 --> Total execution time: 0.0670
DEBUG - 2022-06-30 10:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:26:18 --> Total execution time: 0.0455
DEBUG - 2022-06-30 10:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:26:20 --> Total execution time: 0.0395
DEBUG - 2022-06-30 10:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:26:21 --> Total execution time: 0.0437
DEBUG - 2022-06-30 10:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 10:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:26:22 --> Total execution time: 0.0390
DEBUG - 2022-06-30 10:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:26:25 --> Total execution time: 0.0493
DEBUG - 2022-06-30 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:26:27 --> Total execution time: 0.0446
DEBUG - 2022-06-30 10:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:56:30 --> No URI present. Default controller set.
DEBUG - 2022-06-30 10:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:26:30 --> Total execution time: 0.0379
DEBUG - 2022-06-30 10:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:28:27 --> Total execution time: 0.1304
DEBUG - 2022-06-30 10:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 10:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 10:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:28:52 --> Total execution time: 0.0551
DEBUG - 2022-06-30 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:30:02 --> Total execution time: 0.0588
DEBUG - 2022-06-30 11:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:30:35 --> Total execution time: 0.0617
DEBUG - 2022-06-30 11:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:30:44 --> Total execution time: 0.0712
DEBUG - 2022-06-30 11:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:31:38 --> Total execution time: 0.0515
DEBUG - 2022-06-30 11:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:31:48 --> Total execution time: 0.0560
DEBUG - 2022-06-30 11:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:03:52 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:33:52 --> Total execution time: 0.1342
DEBUG - 2022-06-30 11:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:33:56 --> Total execution time: 0.1347
DEBUG - 2022-06-30 11:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:04:00 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:34:00 --> Total execution time: 0.0401
DEBUG - 2022-06-30 11:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:34:04 --> Total execution time: 0.0545
DEBUG - 2022-06-30 11:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:34:07 --> Total execution time: 0.0550
DEBUG - 2022-06-30 11:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:34:10 --> Total execution time: 0.0512
DEBUG - 2022-06-30 11:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:34:13 --> Total execution time: 0.0600
DEBUG - 2022-06-30 11:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:34:17 --> Total execution time: 0.0521
DEBUG - 2022-06-30 11:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:34:20 --> Total execution time: 0.0330
DEBUG - 2022-06-30 11:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:34:26 --> Total execution time: 0.0593
DEBUG - 2022-06-30 11:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:34:32 --> Total execution time: 0.0552
DEBUG - 2022-06-30 11:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:34:45 --> Total execution time: 0.0490
DEBUG - 2022-06-30 11:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:34:52 --> Total execution time: 0.0622
DEBUG - 2022-06-30 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:35:29 --> Total execution time: 0.0819
DEBUG - 2022-06-30 11:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:35:57 --> Total execution time: 0.0464
DEBUG - 2022-06-30 11:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:36:21 --> Total execution time: 0.0444
DEBUG - 2022-06-30 11:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:07:32 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:37:32 --> Total execution time: 0.0510
DEBUG - 2022-06-30 11:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:37:36 --> Total execution time: 0.0476
DEBUG - 2022-06-30 11:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:38:18 --> Total execution time: 0.1666
DEBUG - 2022-06-30 11:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:39:12 --> Total execution time: 0.0512
DEBUG - 2022-06-30 11:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:39:38 --> Total execution time: 0.0818
DEBUG - 2022-06-30 11:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:09:40 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:39:40 --> Total execution time: 0.0335
DEBUG - 2022-06-30 11:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:09:40 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:39:40 --> Total execution time: 0.0338
DEBUG - 2022-06-30 11:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:09:45 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:39:45 --> Total execution time: 0.0360
DEBUG - 2022-06-30 11:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:09:46 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:39:46 --> Total execution time: 0.1177
DEBUG - 2022-06-30 11:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:09:47 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:39:47 --> Total execution time: 0.0510
DEBUG - 2022-06-30 11:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:09:49 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:39:49 --> Total execution time: 0.0615
DEBUG - 2022-06-30 11:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:11:33 --> Total execution time: 0.0596
DEBUG - 2022-06-30 11:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:41:55 --> Total execution time: 0.0495
DEBUG - 2022-06-30 11:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:42:21 --> Total execution time: 0.0542
DEBUG - 2022-06-30 11:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:42:46 --> Total execution time: 0.0753
DEBUG - 2022-06-30 11:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:42:47 --> Total execution time: 0.1050
DEBUG - 2022-06-30 11:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:42:54 --> Total execution time: 0.0711
DEBUG - 2022-06-30 11:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:42:58 --> Total execution time: 0.1639
DEBUG - 2022-06-30 11:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:42:59 --> Total execution time: 0.0523
DEBUG - 2022-06-30 11:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:43:15 --> Total execution time: 0.0684
DEBUG - 2022-06-30 11:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:43:24 --> Total execution time: 0.0569
DEBUG - 2022-06-30 11:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:43:47 --> Total execution time: 0.0547
DEBUG - 2022-06-30 11:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:43:55 --> Total execution time: 0.1500
DEBUG - 2022-06-30 11:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:14:28 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:44:28 --> Total execution time: 0.0361
DEBUG - 2022-06-30 11:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:45:49 --> Total execution time: 0.0495
DEBUG - 2022-06-30 11:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:46:09 --> Total execution time: 0.0508
DEBUG - 2022-06-30 11:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:46:14 --> Total execution time: 0.0406
DEBUG - 2022-06-30 11:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:46:35 --> Total execution time: 0.0550
DEBUG - 2022-06-30 11:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:48:35 --> Total execution time: 0.0527
DEBUG - 2022-06-30 11:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:48:45 --> Total execution time: 0.0533
DEBUG - 2022-06-30 11:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:48:54 --> Total execution time: 0.0524
DEBUG - 2022-06-30 11:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:49:08 --> Total execution time: 0.0579
DEBUG - 2022-06-30 11:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:49:10 --> Total execution time: 0.0311
DEBUG - 2022-06-30 11:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:49:13 --> Total execution time: 0.0526
DEBUG - 2022-06-30 11:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:49:20 --> Total execution time: 0.1235
DEBUG - 2022-06-30 11:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:49:54 --> Total execution time: 0.0369
DEBUG - 2022-06-30 11:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:51:24 --> Total execution time: 0.0552
DEBUG - 2022-06-30 11:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:17 --> Total execution time: 0.1616
DEBUG - 2022-06-30 11:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:18 --> Total execution time: 0.0744
DEBUG - 2022-06-30 11:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:21 --> Total execution time: 0.0735
DEBUG - 2022-06-30 11:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:22 --> Total execution time: 0.0840
DEBUG - 2022-06-30 11:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:22 --> Total execution time: 0.0530
DEBUG - 2022-06-30 11:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:22 --> Total execution time: 0.1105
DEBUG - 2022-06-30 11:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:23 --> Total execution time: 0.0660
DEBUG - 2022-06-30 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:24 --> Total execution time: 0.0551
DEBUG - 2022-06-30 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:24 --> Total execution time: 0.0569
DEBUG - 2022-06-30 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:24 --> Total execution time: 0.0562
DEBUG - 2022-06-30 11:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:28 --> Total execution time: 0.0534
DEBUG - 2022-06-30 11:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:28 --> Total execution time: 0.0702
DEBUG - 2022-06-30 11:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:29 --> Total execution time: 0.0971
DEBUG - 2022-06-30 11:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:30 --> Total execution time: 0.1093
DEBUG - 2022-06-30 11:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:31 --> Total execution time: 0.1010
DEBUG - 2022-06-30 11:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:31 --> Total execution time: 0.1773
DEBUG - 2022-06-30 11:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:32 --> Total execution time: 0.0690
DEBUG - 2022-06-30 11:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:42 --> Total execution time: 0.0946
DEBUG - 2022-06-30 11:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:44 --> Total execution time: 0.0914
DEBUG - 2022-06-30 11:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:47 --> Total execution time: 0.0914
DEBUG - 2022-06-30 11:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:48 --> Total execution time: 0.0843
DEBUG - 2022-06-30 11:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:48 --> Total execution time: 0.0836
DEBUG - 2022-06-30 11:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:49 --> Total execution time: 0.0840
DEBUG - 2022-06-30 11:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:49 --> Total execution time: 0.0906
DEBUG - 2022-06-30 11:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:52:53 --> Total execution time: 0.1186
DEBUG - 2022-06-30 11:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:23:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 11:23:02 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-30 11:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:53:23 --> Total execution time: 0.0358
DEBUG - 2022-06-30 11:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:54:08 --> Total execution time: 0.0537
DEBUG - 2022-06-30 11:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:54:35 --> Total execution time: 0.0528
DEBUG - 2022-06-30 11:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:55:10 --> Total execution time: 0.0519
DEBUG - 2022-06-30 11:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:55:16 --> Total execution time: 0.0741
DEBUG - 2022-06-30 11:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:55:26 --> Total execution time: 0.0585
DEBUG - 2022-06-30 11:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:25:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 11:25:35 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-30 11:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:57:11 --> Total execution time: 0.0479
DEBUG - 2022-06-30 11:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:57:37 --> Total execution time: 0.0429
DEBUG - 2022-06-30 11:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:27:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 11:27:44 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-30 11:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:58:19 --> Total execution time: 0.0497
DEBUG - 2022-06-30 11:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:58:24 --> Total execution time: 0.0436
DEBUG - 2022-06-30 11:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:59:12 --> Total execution time: 0.0519
DEBUG - 2022-06-30 11:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:01:27 --> Total execution time: 0.2190
DEBUG - 2022-06-30 11:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:01:35 --> Total execution time: 0.0502
DEBUG - 2022-06-30 11:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:03:33 --> Total execution time: 0.1687
DEBUG - 2022-06-30 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:05:46 --> Total execution time: 0.0501
DEBUG - 2022-06-30 11:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:05:50 --> Total execution time: 0.0454
DEBUG - 2022-06-30 11:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:05:55 --> Total execution time: 0.0517
DEBUG - 2022-06-30 11:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:06:09 --> Total execution time: 0.0542
DEBUG - 2022-06-30 11:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:06:18 --> Total execution time: 0.1574
DEBUG - 2022-06-30 11:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:10:14 --> Total execution time: 0.1053
DEBUG - 2022-06-30 11:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:10:35 --> Total execution time: 0.0485
DEBUG - 2022-06-30 11:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:10:48 --> Total execution time: 0.0477
DEBUG - 2022-06-30 11:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:40:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 11:40:55 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-30 11:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:11:29 --> Total execution time: 0.1372
DEBUG - 2022-06-30 11:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:11:30 --> Total execution time: 0.1523
DEBUG - 2022-06-30 11:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:11:38 --> Total execution time: 0.0621
DEBUG - 2022-06-30 11:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:11:43 --> Total execution time: 0.0475
DEBUG - 2022-06-30 11:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:11:59 --> Total execution time: 0.0542
DEBUG - 2022-06-30 11:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:42:02 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:12:02 --> Total execution time: 0.2133
DEBUG - 2022-06-30 11:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:12:02 --> Total execution time: 0.1490
DEBUG - 2022-06-30 11:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:42:04 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:12:04 --> Total execution time: 0.0374
DEBUG - 2022-06-30 11:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:12:14 --> Total execution time: 0.0484
DEBUG - 2022-06-30 11:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:12:27 --> Total execution time: 0.0545
DEBUG - 2022-06-30 11:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:12:27 --> Total execution time: 0.0500
DEBUG - 2022-06-30 11:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:12:40 --> Total execution time: 0.0477
DEBUG - 2022-06-30 11:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:12:44 --> Total execution time: 0.0653
DEBUG - 2022-06-30 11:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:12:55 --> Total execution time: 0.0800
DEBUG - 2022-06-30 11:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:13:06 --> Total execution time: 0.0675
DEBUG - 2022-06-30 11:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:13:14 --> Total execution time: 0.0754
DEBUG - 2022-06-30 11:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:43:29 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:13:29 --> Total execution time: 0.0635
DEBUG - 2022-06-30 11:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:44:52 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:14:52 --> Total execution time: 0.0418
DEBUG - 2022-06-30 11:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:44:53 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:14:53 --> Total execution time: 0.0433
DEBUG - 2022-06-30 11:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:15:23 --> Total execution time: 0.0323
DEBUG - 2022-06-30 11:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:15:47 --> Total execution time: 0.0448
DEBUG - 2022-06-30 11:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:16:24 --> Total execution time: 0.0511
DEBUG - 2022-06-30 11:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:16:29 --> Total execution time: 0.0539
DEBUG - 2022-06-30 11:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:46:37 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:16:37 --> Total execution time: 0.0325
DEBUG - 2022-06-30 11:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:16:42 --> Total execution time: 0.0628
DEBUG - 2022-06-30 11:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:16:49 --> Total execution time: 0.0882
DEBUG - 2022-06-30 11:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:17:09 --> Total execution time: 0.0539
DEBUG - 2022-06-30 11:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:17:22 --> Total execution time: 0.0527
DEBUG - 2022-06-30 11:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:48:07 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:18:07 --> Total execution time: 0.0352
DEBUG - 2022-06-30 11:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:18:22 --> Total execution time: 0.0401
DEBUG - 2022-06-30 11:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:20:57 --> Total execution time: 0.0699
DEBUG - 2022-06-30 11:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 11:51:02 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:21:09 --> Total execution time: 0.0752
DEBUG - 2022-06-30 11:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:21:23 --> Total execution time: 0.0588
DEBUG - 2022-06-30 11:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:21:26 --> Total execution time: 0.0612
DEBUG - 2022-06-30 11:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:51:34 --> No URI present. Default controller set.
DEBUG - 2022-06-30 11:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:21:34 --> Total execution time: 0.1215
DEBUG - 2022-06-30 11:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:21:51 --> Total execution time: 0.0489
DEBUG - 2022-06-30 11:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:21:53 --> Total execution time: 0.0498
DEBUG - 2022-06-30 11:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:21:55 --> Total execution time: 0.0535
DEBUG - 2022-06-30 11:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:21:58 --> Total execution time: 0.0468
DEBUG - 2022-06-30 11:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:21:59 --> Total execution time: 0.0517
DEBUG - 2022-06-30 11:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:22:00 --> Total execution time: 0.0637
DEBUG - 2022-06-30 11:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 11:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:22:03 --> Total execution time: 0.0549
DEBUG - 2022-06-30 11:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 11:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 11:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:24:22 --> Total execution time: 0.0318
DEBUG - 2022-06-30 12:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:30:04 --> Total execution time: 0.2222
DEBUG - 2022-06-30 12:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:35:18 --> Total execution time: 0.0542
DEBUG - 2022-06-30 12:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:39:01 --> Total execution time: 0.1144
DEBUG - 2022-06-30 12:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:12:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 12:12:57 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-30 12:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:12:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 12:12:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 12:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:44:18 --> Total execution time: 0.0491
DEBUG - 2022-06-30 12:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:45:31 --> Total execution time: 0.0499
DEBUG - 2022-06-30 12:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:45:42 --> Total execution time: 0.0735
DEBUG - 2022-06-30 12:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:45:45 --> Total execution time: 0.0631
DEBUG - 2022-06-30 12:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:45:48 --> Total execution time: 0.1013
DEBUG - 2022-06-30 12:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:45:58 --> Total execution time: 0.0488
DEBUG - 2022-06-30 12:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:49:18 --> Total execution time: 0.1934
DEBUG - 2022-06-30 12:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:49:34 --> Total execution time: 0.0540
DEBUG - 2022-06-30 12:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:49:44 --> Total execution time: 0.0811
DEBUG - 2022-06-30 12:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:50:01 --> Total execution time: 0.0737
DEBUG - 2022-06-30 12:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:50:25 --> Total execution time: 0.0618
DEBUG - 2022-06-30 12:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:50:28 --> Total execution time: 0.0571
DEBUG - 2022-06-30 12:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:20:44 --> No URI present. Default controller set.
DEBUG - 2022-06-30 12:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:50:44 --> Total execution time: 0.0550
DEBUG - 2022-06-30 12:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:53:18 --> Total execution time: 0.0603
DEBUG - 2022-06-30 12:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:23:34 --> No URI present. Default controller set.
DEBUG - 2022-06-30 12:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:53:34 --> Total execution time: 0.0519
DEBUG - 2022-06-30 12:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:23:43 --> No URI present. Default controller set.
DEBUG - 2022-06-30 12:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:53:43 --> Total execution time: 0.0324
DEBUG - 2022-06-30 12:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:53:46 --> Total execution time: 0.0458
DEBUG - 2022-06-30 12:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:59:06 --> Total execution time: 0.0824
DEBUG - 2022-06-30 12:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:01:32 --> Total execution time: 0.0478
DEBUG - 2022-06-30 12:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:02:36 --> Total execution time: 0.0447
DEBUG - 2022-06-30 12:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:04:27 --> Total execution time: 0.1392
DEBUG - 2022-06-30 12:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:04:39 --> Total execution time: 0.0623
DEBUG - 2022-06-30 12:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:12 --> Total execution time: 0.0546
DEBUG - 2022-06-30 12:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:35:34 --> No URI present. Default controller set.
DEBUG - 2022-06-30 12:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:34 --> Total execution time: 0.0372
DEBUG - 2022-06-30 12:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:35:35 --> No URI present. Default controller set.
DEBUG - 2022-06-30 12:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:35 --> Total execution time: 0.0277
DEBUG - 2022-06-30 12:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 12:35:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 12:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:06:12 --> Total execution time: 0.0335
DEBUG - 2022-06-30 12:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:06:26 --> Total execution time: 0.0673
DEBUG - 2022-06-30 12:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:06:46 --> Total execution time: 0.0543
DEBUG - 2022-06-30 12:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:43:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 12:43:08 --> 404 Page Not Found: Login/index
DEBUG - 2022-06-30 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:16:53 --> Total execution time: 0.2209
DEBUG - 2022-06-30 12:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:16:55 --> Total execution time: 0.0852
DEBUG - 2022-06-30 12:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 12:46:59 --> 404 Page Not Found: Courses/index
DEBUG - 2022-06-30 12:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:49:58 --> No URI present. Default controller set.
DEBUG - 2022-06-30 12:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:19:58 --> Total execution time: 0.1035
DEBUG - 2022-06-30 12:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 12:50:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 12:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:24:43 --> Total execution time: 0.0470
DEBUG - 2022-06-30 12:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:25:02 --> Total execution time: 0.0591
DEBUG - 2022-06-30 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:25:05 --> Total execution time: 0.0655
DEBUG - 2022-06-30 12:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:25:08 --> Total execution time: 0.0526
DEBUG - 2022-06-30 12:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:26:00 --> Total execution time: 0.0339
DEBUG - 2022-06-30 12:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:58:00 --> No URI present. Default controller set.
DEBUG - 2022-06-30 12:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:28:00 --> Total execution time: 0.0505
DEBUG - 2022-06-30 12:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:58:12 --> No URI present. Default controller set.
DEBUG - 2022-06-30 12:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:28:12 --> Total execution time: 0.0350
DEBUG - 2022-06-30 12:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:59:17 --> Total execution time: 0.0511
DEBUG - 2022-06-30 12:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:59:24 --> No URI present. Default controller set.
DEBUG - 2022-06-30 12:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:29:24 --> Total execution time: 0.0341
DEBUG - 2022-06-30 12:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 12:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 12:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:59:28 --> Total execution time: 0.0494
DEBUG - 2022-06-30 12:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 12:59:28 --> Total execution time: 0.0902
DEBUG - 2022-06-30 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:30:02 --> Total execution time: 0.0566
DEBUG - 2022-06-30 13:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:01:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-30 13:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:32:01 --> Total execution time: 1.9739
DEBUG - 2022-06-30 13:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:02:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 13:02:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 13:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 13:02:17 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-30 13:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:32:40 --> Total execution time: 0.0498
DEBUG - 2022-06-30 13:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:02:56 --> No URI present. Default controller set.
DEBUG - 2022-06-30 13:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:32:56 --> Total execution time: 0.0340
DEBUG - 2022-06-30 13:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:02:56 --> No URI present. Default controller set.
DEBUG - 2022-06-30 13:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:02:56 --> No URI present. Default controller set.
DEBUG - 2022-06-30 13:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:32:56 --> Total execution time: 0.0460
DEBUG - 2022-06-30 13:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:32:56 --> Total execution time: 0.0496
DEBUG - 2022-06-30 13:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:04:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 13:04:47 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-30 13:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:06:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 13:06:54 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-30 13:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:41:18 --> Total execution time: 0.1820
DEBUG - 2022-06-30 13:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:44:31 --> Total execution time: 0.0490
DEBUG - 2022-06-30 13:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:44:34 --> Total execution time: 0.0550
DEBUG - 2022-06-30 13:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:44:45 --> Total execution time: 0.0866
DEBUG - 2022-06-30 13:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:44:50 --> Total execution time: 0.0633
DEBUG - 2022-06-30 13:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:14:52 --> No URI present. Default controller set.
DEBUG - 2022-06-30 13:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:44:52 --> Total execution time: 0.0429
DEBUG - 2022-06-30 13:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:44:53 --> Total execution time: 0.0785
DEBUG - 2022-06-30 13:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:45:03 --> Total execution time: 0.0962
DEBUG - 2022-06-30 13:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:45:18 --> Total execution time: 0.0551
DEBUG - 2022-06-30 13:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:45:37 --> Total execution time: 0.0545
DEBUG - 2022-06-30 13:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:46:52 --> Total execution time: 0.0539
DEBUG - 2022-06-30 13:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:46:59 --> Total execution time: 0.0514
DEBUG - 2022-06-30 13:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:48:28 --> Total execution time: 0.0699
DEBUG - 2022-06-30 13:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:48:44 --> Total execution time: 0.0383
DEBUG - 2022-06-30 13:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:48:58 --> Total execution time: 0.0516
DEBUG - 2022-06-30 13:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:49:10 --> Total execution time: 0.0532
DEBUG - 2022-06-30 13:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:20:49 --> No URI present. Default controller set.
DEBUG - 2022-06-30 13:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:50:49 --> Total execution time: 0.1181
DEBUG - 2022-06-30 13:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:52:17 --> Total execution time: 0.0406
DEBUG - 2022-06-30 13:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:52:20 --> Total execution time: 0.0436
DEBUG - 2022-06-30 13:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:22:51 --> Total execution time: 0.0464
DEBUG - 2022-06-30 13:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:52:56 --> Total execution time: 0.0660
DEBUG - 2022-06-30 13:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:00 --> Total execution time: 0.0768
DEBUG - 2022-06-30 13:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:03 --> Total execution time: 0.0799
DEBUG - 2022-06-30 13:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:07 --> Total execution time: 0.0920
DEBUG - 2022-06-30 13:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:10 --> Total execution time: 0.0499
DEBUG - 2022-06-30 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:16 --> Total execution time: 0.0509
DEBUG - 2022-06-30 13:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:21 --> Total execution time: 0.0602
DEBUG - 2022-06-30 13:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:43 --> Total execution time: 0.0501
DEBUG - 2022-06-30 13:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:55 --> Total execution time: 0.0548
DEBUG - 2022-06-30 13:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:55:09 --> Total execution time: 0.0763
DEBUG - 2022-06-30 13:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:55:32 --> Total execution time: 0.0516
DEBUG - 2022-06-30 13:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:56:16 --> Total execution time: 0.0499
DEBUG - 2022-06-30 13:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:56:30 --> Total execution time: 0.0460
DEBUG - 2022-06-30 13:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:56:34 --> Total execution time: 0.0798
DEBUG - 2022-06-30 13:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:56:41 --> Total execution time: 0.0504
DEBUG - 2022-06-30 13:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 13:30:14 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 13:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:33:50 --> No URI present. Default controller set.
DEBUG - 2022-06-30 13:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:33:52 --> No URI present. Default controller set.
DEBUG - 2022-06-30 13:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:35:00 --> No URI present. Default controller set.
DEBUG - 2022-06-30 13:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:35:51 --> No URI present. Default controller set.
DEBUG - 2022-06-30 13:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 13:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 13:59:33 --> No URI present. Default controller set.
DEBUG - 2022-06-30 13:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 13:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:13:15 --> No URI present. Default controller set.
DEBUG - 2022-06-30 14:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:13:24 --> No URI present. Default controller set.
DEBUG - 2022-06-30 14:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:13:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 14:13:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 14:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:13:52 --> No URI present. Default controller set.
DEBUG - 2022-06-30 14:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:15:04 --> No URI present. Default controller set.
DEBUG - 2022-06-30 14:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:17:18 --> Total execution time: 0.0696
DEBUG - 2022-06-30 14:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:17:31 --> No URI present. Default controller set.
DEBUG - 2022-06-30 14:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:15 --> No URI present. Default controller set.
DEBUG - 2022-06-30 14:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:21:07 --> No URI present. Default controller set.
DEBUG - 2022-06-30 14:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 14:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 14:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:41:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 14:41:14 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-30 14:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 14:43:46 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-30 14:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 14:45:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 14:45:52 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-30 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:06:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:06:40 --> 404 Page Not Found: App-adstxt/index
ERROR - 2022-06-30 15:06:40 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-30 15:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:06:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:06:41 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-30 15:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:06:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:06:41 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-30 15:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:06:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:06:42 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-30 15:06:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:06:42 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-30 15:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:06:43 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-30 15:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:06:43 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-30 15:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:09:04 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 15:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:16:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 15:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:19:03 --> No URI present. Default controller set.
DEBUG - 2022-06-30 15:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:20:05 --> No URI present. Default controller set.
DEBUG - 2022-06-30 15:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:21:53 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-30 15:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:27:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:27:40 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-06-30 15:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:42:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 15:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:53:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:53:51 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-30 15:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:53:52 --> No URI present. Default controller set.
DEBUG - 2022-06-30 15:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:53:53 --> No URI present. Default controller set.
DEBUG - 2022-06-30 15:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 15:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 15:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:54:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:54:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 15:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:56:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:56:11 --> 404 Page Not Found: Courses/index
DEBUG - 2022-06-30 15:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:58:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:58:56 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-30 15:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 15:59:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 15:59:00 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-30 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:00:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 16:00:18 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-30 16:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:11:43 --> No URI present. Default controller set.
DEBUG - 2022-06-30 16:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:11:47 --> No URI present. Default controller set.
DEBUG - 2022-06-30 16:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:13:38 --> No URI present. Default controller set.
DEBUG - 2022-06-30 16:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:16:38 --> No URI present. Default controller set.
DEBUG - 2022-06-30 16:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:19:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 16:19:43 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-30 16:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 16:22:09 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-30 16:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:24:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 16:24:12 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-30 16:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:30:35 --> No URI present. Default controller set.
DEBUG - 2022-06-30 16:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:30:37 --> No URI present. Default controller set.
DEBUG - 2022-06-30 16:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:30:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 16:30:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 16:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:47:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 16:47:14 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 16:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 16:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 16:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 16:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:11:26 --> No URI present. Default controller set.
DEBUG - 2022-06-30 17:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:21:23 --> No URI present. Default controller set.
DEBUG - 2022-06-30 17:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:22:27 --> No URI present. Default controller set.
DEBUG - 2022-06-30 17:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 17:28:26 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-30 17:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 17:28:26 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-06-30 17:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 17:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 17:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:41:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 17:41:16 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-30 17:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 17:56:52 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-30 17:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 17:59:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 17:59:17 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-30 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 18:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 18:01:27 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-30 18:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 18:07:42 --> No URI present. Default controller set.
DEBUG - 2022-06-30 18:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 18:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 18:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 18:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 18:11:00 --> No URI present. Default controller set.
DEBUG - 2022-06-30 18:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 18:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 18:11:02 --> No URI present. Default controller set.
DEBUG - 2022-06-30 18:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 18:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 18:11:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 18:11:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 18:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 18:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 18:22:01 --> 404 Page Not Found: Contact/index
DEBUG - 2022-06-30 18:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 18:22:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 18:22:02 --> 404 Page Not Found: Contact/index
DEBUG - 2022-06-30 18:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 18:22:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 18:22:03 --> 404 Page Not Found: Contact/index
DEBUG - 2022-06-30 18:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 18:22:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 18:22:04 --> 404 Page Not Found: Contact/index
DEBUG - 2022-06-30 18:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 18:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 18:24:16 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 18:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 18:24:52 --> No URI present. Default controller set.
DEBUG - 2022-06-30 18:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 18:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 18:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 18:24:54 --> No URI present. Default controller set.
DEBUG - 2022-06-30 18:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 18:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:13:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 19:13:37 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-30 19:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:15:05 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:19:25 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 19:24:25 --> 404 Page Not Found: Cart/index
DEBUG - 2022-06-30 19:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 19:24:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 19:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:29:33 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:29:43 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:29:44 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 19:29:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 19:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:29:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:29:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 19:30:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 19:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:30:17 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 19:30:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 19:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:30:31 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:35:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 19:35:04 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-30 19:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:37:36 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 19:37:36 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-06-30 19:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 19:37:36 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-30 19:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 19:39:46 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-30 19:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:49:04 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:51:42 --> Total execution time: 0.0471
DEBUG - 2022-06-30 19:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:51:53 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:52:23 --> Total execution time: 0.0479
DEBUG - 2022-06-30 19:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:52:24 --> Total execution time: 0.0452
DEBUG - 2022-06-30 19:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:53:11 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:18 --> Total execution time: 0.1250
DEBUG - 2022-06-30 19:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:23 --> Total execution time: 0.0454
DEBUG - 2022-06-30 19:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:39 --> Total execution time: 0.0664
DEBUG - 2022-06-30 19:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:54:46 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:56:23 --> Total execution time: 0.0486
DEBUG - 2022-06-30 19:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:56:27 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:56:53 --> Total execution time: 0.0497
DEBUG - 2022-06-30 19:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:56:53 --> Total execution time: 0.0613
DEBUG - 2022-06-30 19:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:58:15 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:58:18 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 19:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 19:58:32 --> No URI present. Default controller set.
DEBUG - 2022-06-30 19:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 19:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:02:54 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:03:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:03:13 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 20:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:08:31 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-30 20:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:09:02 --> 404 Page Not Found: Lp-profile/index
DEBUG - 2022-06-30 20:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:09:39 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:11:43 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:16:40 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:16:56 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:17:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-06-30 20:17:33 --> Unable to connect to the database
ERROR - 2022-06-30 20:17:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-06-30 20:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:17:39 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:17:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-06-30 20:17:39 --> Unable to connect to the database
ERROR - 2022-06-30 20:17:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-06-30 20:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:17:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 20:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:17:47 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:17:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:17:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-06-30 20:17:47 --> Unable to connect to the database
ERROR - 2022-06-30 20:17:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-06-30 20:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:03 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:18:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:18:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-06-30 20:18:03 --> Unable to connect to the database
ERROR - 2022-06-30 20:18:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-06-30 20:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:04 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:18:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:18:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-06-30 20:18:04 --> Unable to connect to the database
ERROR - 2022-06-30 20:18:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-06-30 20:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:18:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 20:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:18:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-06-30 20:18:05 --> Unable to connect to the database
ERROR - 2022-06-30 20:18:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-06-30 20:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:18:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 20:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:18:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-06-30 20:18:06 --> Unable to connect to the database
ERROR - 2022-06-30 20:18:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-06-30 20:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:18:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 20:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:18:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-06-30 20:18:07 --> Unable to connect to the database
ERROR - 2022-06-30 20:18:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-06-30 20:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:08 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:18:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:18:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-06-30 20:18:08 --> Unable to connect to the database
ERROR - 2022-06-30 20:18:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-06-30 20:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:10 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:18:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-06-30 20:18:10 --> Unable to connect to the database
ERROR - 2022-06-30 20:18:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-06-30 20:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 20:18:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-06-30 20:18:10 --> Unable to connect to the database
ERROR - 2022-06-30 20:18:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-06-30 20:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:22:33 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:32:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:34:28 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:47:19 --> No URI present. Default controller set.
DEBUG - 2022-06-30 20:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 20:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 20:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 20:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:04:27 --> No URI present. Default controller set.
DEBUG - 2022-06-30 21:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:07:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:07:09 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-06-30 21:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:07:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:07:13 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-06-30 21:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:07:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:07:17 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-06-30 21:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:09:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:09:34 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-30 21:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:09:37 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-30 21:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:09:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:09:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 21:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:11:09 --> No URI present. Default controller set.
DEBUG - 2022-06-30 21:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:12:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:12:37 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-30 21:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:15:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:15:05 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-30 21:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:16:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:16:58 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-30 21:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:17:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:17:09 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-30 21:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:22:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:22:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 21:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:22:44 --> 404 Page Not Found: Category/sports
DEBUG - 2022-06-30 21:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:29:31 --> No URI present. Default controller set.
DEBUG - 2022-06-30 21:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:29:33 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-30 21:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:39:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:39:41 --> 404 Page Not Found: Admin/index.php
DEBUG - 2022-06-30 21:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:39:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:39:47 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 21:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:40:00 --> 404 Page Not Found: Admin/index.php
DEBUG - 2022-06-30 21:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:40:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 21:40:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-30 21:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:51:25 --> No URI present. Default controller set.
DEBUG - 2022-06-30 21:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 21:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 21:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 21:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:01:42 --> No URI present. Default controller set.
DEBUG - 2022-06-30 22:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:10:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 22:10:54 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-30 22:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:10:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 22:10:56 --> 404 Page Not Found: Learning-friendship-and-fun-for-everyone/index
DEBUG - 2022-06-30 22:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 22:16:22 --> 404 Page Not Found: Sports/feed
DEBUG - 2022-06-30 22:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:26:01 --> No URI present. Default controller set.
DEBUG - 2022-06-30 22:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:36:46 --> No URI present. Default controller set.
DEBUG - 2022-06-30 22:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:37:10 --> No URI present. Default controller set.
DEBUG - 2022-06-30 22:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:38:26 --> No URI present. Default controller set.
DEBUG - 2022-06-30 22:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:47:26 --> No URI present. Default controller set.
DEBUG - 2022-06-30 22:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:48:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 22:48:34 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-30 22:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 22:51:00 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-30 22:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:52:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 22:52:59 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-30 22:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:53:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 22:53:29 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-30 22:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:58:19 --> No URI present. Default controller set.
DEBUG - 2022-06-30 22:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:58:20 --> No URI present. Default controller set.
DEBUG - 2022-06-30 22:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 22:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 22:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 22:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:04:09 --> No URI present. Default controller set.
DEBUG - 2022-06-30 23:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:04:35 --> No URI present. Default controller set.
DEBUG - 2022-06-30 23:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:04:43 --> No URI present. Default controller set.
DEBUG - 2022-06-30 23:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:06:43 --> No URI present. Default controller set.
DEBUG - 2022-06-30 23:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:10:34 --> No URI present. Default controller set.
DEBUG - 2022-06-30 23:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:10:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 23:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:11:57 --> No URI present. Default controller set.
DEBUG - 2022-06-30 23:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 23:15:28 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-30 23:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:18:51 --> No URI present. Default controller set.
DEBUG - 2022-06-30 23:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:19:18 --> No URI present. Default controller set.
DEBUG - 2022-06-30 23:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:19:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-30 23:19:19 --> 404 Page Not Found: Wp-coreutilsphp/index
DEBUG - 2022-06-30 23:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:24:08 --> No URI present. Default controller set.
DEBUG - 2022-06-30 23:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:53:24 --> No URI present. Default controller set.
DEBUG - 2022-06-30 23:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:54:25 --> No URI present. Default controller set.
DEBUG - 2022-06-30 23:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:57:11 --> No URI present. Default controller set.
DEBUG - 2022-06-30 23:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-30 23:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-30 23:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-30 23:59:19 --> Encryption: Auto-configured driver 'openssl'.
