<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-04-23 07:30:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 07:30:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 07:30:32 --> Total execution time: 0.0356
DEBUG - 2023-04-23 07:30:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:30:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:30:32 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 07:30:40 --> Total execution time: 0.0349
DEBUG - 2023-04-23 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:30:40 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:30:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 07:30:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:00:47 --> Total execution time: 0.0593
DEBUG - 2023-04-23 07:30:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:30:47 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:30:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:30:47 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:30:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:00:51 --> Total execution time: 0.0461
DEBUG - 2023-04-23 07:30:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:30:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:30:51 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:32:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:02:14 --> Total execution time: 0.0533
DEBUG - 2023-04-23 07:32:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:32:14 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:32:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:02:15 --> Total execution time: 0.0566
DEBUG - 2023-04-23 07:32:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:02:17 --> Total execution time: 0.0548
DEBUG - 2023-04-23 07:43:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:13:04 --> Total execution time: 0.0819
DEBUG - 2023-04-23 07:43:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:43:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:43:04 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:43:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:43:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:43:04 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:43:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:13:07 --> Total execution time: 0.0753
DEBUG - 2023-04-23 07:43:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:43:07 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:43:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:13:09 --> Total execution time: 0.0569
DEBUG - 2023-04-23 07:43:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:43:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:43:09 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:43:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:13:17 --> Total execution time: 0.0695
DEBUG - 2023-04-23 07:43:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:43:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:43:17 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:44:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:14:53 --> Total execution time: 0.0580
DEBUG - 2023-04-23 07:44:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:44:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:44:53 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:44:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:14:54 --> Total execution time: 0.0753
DEBUG - 2023-04-23 07:44:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:44:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:44:54 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:44:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:14:55 --> Total execution time: 0.0566
DEBUG - 2023-04-23 07:44:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:44:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:44:55 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:44:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:14:55 --> Total execution time: 0.0400
DEBUG - 2023-04-23 07:44:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:44:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:44:55 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:45:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:15:19 --> Total execution time: 0.0601
DEBUG - 2023-04-23 07:45:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:45:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:45:19 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:45:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:15:22 --> Total execution time: 0.0418
DEBUG - 2023-04-23 07:45:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:15:22 --> Total execution time: 0.0422
DEBUG - 2023-04-23 07:45:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:45:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:45:22 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:45:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:15:25 --> Total execution time: 0.0672
DEBUG - 2023-04-23 07:45:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:15:25 --> Total execution time: 0.0451
DEBUG - 2023-04-23 07:45:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:45:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:45:25 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:45:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:15:43 --> Total execution time: 0.0753
DEBUG - 2023-04-23 07:45:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:45:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:45:43 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:45:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:15:56 --> Total execution time: 0.0653
DEBUG - 2023-04-23 07:45:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:45:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:45:56 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:46:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:16:04 --> Total execution time: 0.0488
DEBUG - 2023-04-23 07:46:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:46:05 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 07:46:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 07:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:16:23 --> Total execution time: 0.0621
DEBUG - 2023-04-23 07:46:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:46:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 07:46:23 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 08:27:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 08:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:57:17 --> Total execution time: 0.8413
DEBUG - 2023-04-23 08:27:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:27:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 08:27:17 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 08:29:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 08:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:59:35 --> Total execution time: 0.0511
DEBUG - 2023-04-23 08:29:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:29:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 08:29:35 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 08:30:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 08:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:00:13 --> Total execution time: 0.0618
DEBUG - 2023-04-23 08:30:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:30:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 08:30:13 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 08:30:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 08:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:00:24 --> Total execution time: 0.0547
DEBUG - 2023-04-23 08:30:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:30:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 08:30:24 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 08:30:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 08:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:00:31 --> Total execution time: 0.0671
DEBUG - 2023-04-23 08:30:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:30:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 08:30:31 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 08:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 08:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:02:08 --> Total execution time: 0.0415
DEBUG - 2023-04-23 08:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:32:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 08:32:08 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 08:41:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 08:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:11:12 --> Total execution time: 0.0550
DEBUG - 2023-04-23 08:41:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:41:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 08:41:12 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 08:41:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 08:41:13 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 08:51:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 08:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:21:04 --> Total execution time: 0.0659
DEBUG - 2023-04-23 08:51:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 08:51:04 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 08:51:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 08:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:21:05 --> Total execution time: 0.0384
DEBUG - 2023-04-23 08:51:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:51:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 08:51:05 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 08:51:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 08:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:21:40 --> Total execution time: 0.0416
DEBUG - 2023-04-23 08:51:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:51:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 08:51:40 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 08:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 08:51:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 08:51:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 08:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 08:51:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 08:51:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 08:51:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 08:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 08:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:51:43 --> UTF-8 Support Enabled
ERROR - 2023-04-23 08:51:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 08:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 08:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 08:51:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 08:51:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 09:03:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:33:44 --> Total execution time: 0.0527
DEBUG - 2023-04-23 09:03:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:03:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:03:44 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:03:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 09:03:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:33:50 --> Total execution time: 0.0543
DEBUG - 2023-04-23 09:03:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:03:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:03:50 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:04:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:34:00 --> Total execution time: 0.0398
DEBUG - 2023-04-23 09:04:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:04:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:04:00 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:04:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 09:04:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:34:04 --> Total execution time: 0.0585
DEBUG - 2023-04-23 09:04:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:04:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:04:05 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:04:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:34:22 --> Total execution time: 0.0643
DEBUG - 2023-04-23 09:04:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:04:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:04:22 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:04:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:34:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 12:34:27 --> You did not select a file to upload.
DEBUG - 2023-04-23 09:04:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:34:27 --> Total execution time: 0.0375
DEBUG - 2023-04-23 09:04:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:04:27 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:06:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:36:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 12:36:15 --> You did not select a file to upload.
DEBUG - 2023-04-23 09:06:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:36:15 --> Total execution time: 0.0562
DEBUG - 2023-04-23 09:06:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:06:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:06:15 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:06:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:36:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 12:36:28 --> You did not select a file to upload.
DEBUG - 2023-04-23 09:06:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:36:28 --> Total execution time: 0.0397
DEBUG - 2023-04-23 09:06:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:06:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:06:28 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:07:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:37:07 --> Total execution time: 0.1144
DEBUG - 2023-04-23 09:07:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:07:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:07:07 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:07:07 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:07:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:37:14 --> Upload class already loaded. Second attempt ignored.
ERROR - 2023-04-23 12:37:14 --> The upload path does not appear to be valid.
ERROR - 2023-04-23 12:37:14 --> The upload path does not appear to be valid.
DEBUG - 2023-04-23 09:07:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:37:14 --> Total execution time: 0.0549
DEBUG - 2023-04-23 09:07:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:07:14 --> UTF-8 Support Enabled
ERROR - 2023-04-23 09:07:14 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:07:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:07:14 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:37:37 --> Total execution time: 0.0404
DEBUG - 2023-04-23 09:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:07:37 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:07:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:37:40 --> Total execution time: 0.0435
DEBUG - 2023-04-23 09:07:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:07:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:07:40 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:07:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:37:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 12:37:45 --> You did not select a file to upload.
DEBUG - 2023-04-23 09:08:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:38:25 --> Total execution time: 0.0410
DEBUG - 2023-04-23 09:08:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:38:33 --> Total execution time: 0.0402
DEBUG - 2023-04-23 09:08:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:08:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:08:33 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:08:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:38:37 --> Upload class already loaded. Second attempt ignored.
ERROR - 2023-04-23 12:38:37 --> Severity: Warning --> unlink(assets/uploads/user/): Is a directory E:\xampp\htdocs\gopal\railway\application\controllers\Admin\User_Controller.php 106
DEBUG - 2023-04-23 09:08:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:38:37 --> Total execution time: 0.0383
DEBUG - 2023-04-23 09:08:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:08:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:08:37 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:08:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:38:56 --> Total execution time: 0.0535
DEBUG - 2023-04-23 09:08:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:08:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:08:56 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:09:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:39:09 --> Total execution time: 0.0531
DEBUG - 2023-04-23 09:09:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:09:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:09:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:09:09 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:09:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:09:09 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:09:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:39:14 --> Upload class already loaded. Second attempt ignored.
ERROR - 2023-04-23 12:39:14 --> The upload path does not appear to be valid.
ERROR - 2023-04-23 12:39:14 --> The upload path does not appear to be valid.
DEBUG - 2023-04-23 09:09:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:39:14 --> Total execution time: 0.0382
DEBUG - 2023-04-23 09:09:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:09:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:09:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:09:14 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:09:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:09:14 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 09:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:10:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:10:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 09:10:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 09:10:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 09:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:10:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:10:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 09:10:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 09:10:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 09:10:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 09:10:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:10:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 09:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:41:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 09:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:41:02 --> Total execution time: 0.0373
DEBUG - 2023-04-23 09:11:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:41:59 --> Total execution time: 0.0720
DEBUG - 2023-04-23 09:13:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:43:27 --> Total execution time: 0.0392
DEBUG - 2023-04-23 09:13:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:43:33 --> Total execution time: 0.0558
DEBUG - 2023-04-23 09:13:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:43:33 --> Total execution time: 0.0510
DEBUG - 2023-04-23 09:13:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:43:37 --> Total execution time: 0.0516
DEBUG - 2023-04-23 09:13:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:43:37 --> Total execution time: 0.0417
DEBUG - 2023-04-23 09:13:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:43:39 --> Total execution time: 0.0400
DEBUG - 2023-04-23 09:13:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:43:39 --> Total execution time: 0.0380
DEBUG - 2023-04-23 09:13:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:43:44 --> Total execution time: 0.0526
DEBUG - 2023-04-23 09:13:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:13:48 --> No URI present. Default controller set.
DEBUG - 2023-04-23 09:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:13:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 12:43:48 --> Severity: error --> Exception: Unable to locate the model you have specified: Promoitions E:\xampp\htdocs\gopal\railway\system\core\Loader.php 348
DEBUG - 2023-04-23 09:15:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:15:29 --> No URI present. Default controller set.
DEBUG - 2023-04-23 09:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:45:29 --> Total execution time: 0.0375
DEBUG - 2023-04-23 09:16:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:16:50 --> No URI present. Default controller set.
DEBUG - 2023-04-23 09:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:46:50 --> Total execution time: 0.0588
DEBUG - 2023-04-23 09:16:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:16:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:16:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:16:50 --> 404 Page Not Found: Style/style.css
DEBUG - 2023-04-23 09:16:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:16:50 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-04-23 09:16:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:16:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:16:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:16:50 --> 404 Page Not Found: Images/line.png
DEBUG - 2023-04-23 09:16:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:16:50 --> 404 Page Not Found: Images/new.png
DEBUG - 2023-04-23 09:19:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:19:30 --> No URI present. Default controller set.
DEBUG - 2023-04-23 09:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:49:30 --> Total execution time: 0.0728
DEBUG - 2023-04-23 09:19:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:19:30 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-04-23 09:19:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:19:30 --> 404 Page Not Found: Images/new.png
DEBUG - 2023-04-23 09:19:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:19:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:19:30 --> UTF-8 Support Enabled
ERROR - 2023-04-23 09:19:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:19:30 --> 404 Page Not Found: Images/line.png
ERROR - 2023-04-23 09:19:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:19:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:19:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:19:30 --> UTF-8 Support Enabled
ERROR - 2023-04-23 09:19:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:19:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:19:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:19:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:19:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:19:38 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:20:01 --> No URI present. Default controller set.
DEBUG - 2023-04-23 09:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:50:01 --> Total execution time: 0.0524
DEBUG - 2023-04-23 09:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:20:01 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-04-23 09:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:20:01 --> UTF-8 Support Enabled
ERROR - 2023-04-23 09:20:01 --> 404 Page Not Found: Images/new.png
DEBUG - 2023-04-23 09:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:20:01 --> 404 Page Not Found: Images/line.png
ERROR - 2023-04-23 09:20:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:20:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:20:01 --> 404 Page Not Found: Assets/website
ERROR - 2023-04-23 09:20:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:20:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:20:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:20:19 --> No URI present. Default controller set.
DEBUG - 2023-04-23 09:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:50:19 --> Total execution time: 0.0699
DEBUG - 2023-04-23 09:20:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:20:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:20:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:20:19 --> 404 Page Not Found: Images/new.png
DEBUG - 2023-04-23 09:20:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:20:19 --> 404 Page Not Found: Images/line.png
DEBUG - 2023-04-23 09:22:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:22:41 --> No URI present. Default controller set.
DEBUG - 2023-04-23 09:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:52:41 --> Total execution time: 0.0485
DEBUG - 2023-04-23 09:22:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:22:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:23:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:23:48 --> No URI present. Default controller set.
DEBUG - 2023-04-23 09:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:53:48 --> Total execution time: 0.0506
DEBUG - 2023-04-23 09:23:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:23:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:23:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:23:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:23:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:23:48 --> 404 Page Not Found: Assets/website
ERROR - 2023-04-23 09:23:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:23:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:25:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:25:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:25:29 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:26:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:26:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:26:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:26:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 09:26:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 09:28:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:58:00 --> Total execution time: 0.0550
DEBUG - 2023-04-23 09:28:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:58:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 09:28:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:58:10 --> Total execution time: 0.0535
DEBUG - 2023-04-23 09:28:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 09:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:58:16 --> Total execution time: 0.0716
DEBUG - 2023-04-23 10:23:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 10:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 10:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 10:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 10:23:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 10:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 10:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 10:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 13:53:30 --> Total execution time: 0.0390
DEBUG - 2023-04-23 10:23:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 10:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 10:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 10:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 13:53:32 --> Total execution time: 0.0407
DEBUG - 2023-04-23 10:23:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 10:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 10:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 10:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 13:53:34 --> Total execution time: 0.0424
DEBUG - 2023-04-23 11:32:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:32:46 --> No URI present. Default controller set.
DEBUG - 2023-04-23 11:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 11:32:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'railway' C:\xampp\htdocs\dinesh\car_rental\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-04-23 11:32:46 --> Unable to connect to the database
DEBUG - 2023-04-23 11:32:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:32:46 --> No URI present. Default controller set.
DEBUG - 2023-04-23 11:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 11:32:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'railway' C:\xampp\htdocs\dinesh\car_rental\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-04-23 11:32:46 --> Unable to connect to the database
DEBUG - 2023-04-23 11:33:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:33:42 --> No URI present. Default controller set.
DEBUG - 2023-04-23 11:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:03:42 --> Total execution time: 0.0935
DEBUG - 2023-04-23 11:33:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 11:33:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 11:33:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:33:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:33:43 --> UTF-8 Support Enabled
ERROR - 2023-04-23 11:33:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 11:33:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:33:43 --> No URI present. Default controller set.
DEBUG - 2023-04-23 11:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 11:33:43 --> 404 Page Not Found: Assets/website
ERROR - 2023-04-23 11:33:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 11:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:03:43 --> Total execution time: 0.2173
DEBUG - 2023-04-23 11:33:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:33:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 11:33:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-04-23 11:33:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:33:57 --> Total execution time: 0.1066
DEBUG - 2023-04-23 11:33:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:33:58 --> Total execution time: 0.1240
DEBUG - 2023-04-23 11:34:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:34:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:34:01 --> Total execution time: 0.0953
DEBUG - 2023-04-23 11:34:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:34:01 --> Total execution time: 0.1216
DEBUG - 2023-04-23 11:34:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:34:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:34:05 --> Total execution time: 0.0925
DEBUG - 2023-04-23 11:34:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:34:05 --> Total execution time: 0.1282
DEBUG - 2023-04-23 11:34:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:34:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:34:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 11:34:55 --> 404 Page Not Found: Admin-login/index
DEBUG - 2023-04-23 11:35:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:35:36 --> Total execution time: 0.0979
DEBUG - 2023-04-23 11:35:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:35:36 --> Total execution time: 0.1220
DEBUG - 2023-04-23 11:35:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:35:55 --> Total execution time: 0.1074
DEBUG - 2023-04-23 11:35:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:35:56 --> Total execution time: 0.1813
DEBUG - 2023-04-23 11:35:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:35:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:35:57 --> Total execution time: 0.1100
DEBUG - 2023-04-23 11:35:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:35:58 --> Total execution time: 0.1610
DEBUG - 2023-04-23 11:36:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 11:36:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:06:03 --> Total execution time: 0.0980
DEBUG - 2023-04-23 11:36:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:06:04 --> Total execution time: 0.1005
DEBUG - 2023-04-23 11:36:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:06:10 --> Total execution time: 0.1121
DEBUG - 2023-04-23 11:36:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:06:11 --> Total execution time: 0.1371
DEBUG - 2023-04-23 11:36:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:06:14 --> Total execution time: 0.1108
DEBUG - 2023-04-23 11:36:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:06:14 --> Total execution time: 0.1496
DEBUG - 2023-04-23 11:36:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:06:17 --> Total execution time: 0.1052
DEBUG - 2023-04-23 11:36:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:06:17 --> Total execution time: 0.1573
DEBUG - 2023-04-23 11:53:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:23:20 --> Total execution time: 0.1108
DEBUG - 2023-04-23 11:53:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:23:20 --> Total execution time: 0.1367
DEBUG - 2023-04-23 11:54:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:24:03 --> Total execution time: 0.1889
DEBUG - 2023-04-23 11:54:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:24:21 --> Total execution time: 0.1793
DEBUG - 2023-04-23 11:54:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:24:31 --> Total execution time: 0.0935
DEBUG - 2023-04-23 11:54:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:24:32 --> Total execution time: 0.1586
DEBUG - 2023-04-23 11:56:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:26:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 11:56:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:26:27 --> Total execution time: 0.0890
DEBUG - 2023-04-23 11:56:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:26:28 --> Total execution time: 0.1477
DEBUG - 2023-04-23 11:56:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:26:34 --> Total execution time: 0.1006
DEBUG - 2023-04-23 11:56:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:26:34 --> Total execution time: 0.1450
DEBUG - 2023-04-23 11:56:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:26:46 --> Total execution time: 0.1161
DEBUG - 2023-04-23 11:56:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:26:46 --> Total execution time: 0.1433
DEBUG - 2023-04-23 11:57:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:27:16 --> Total execution time: 0.1044
DEBUG - 2023-04-23 11:57:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:27:17 --> Total execution time: 0.1492
DEBUG - 2023-04-23 11:57:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:27:25 --> Total execution time: 0.0943
DEBUG - 2023-04-23 11:57:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 11:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 11:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 11:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:27:26 --> Total execution time: 0.1435
DEBUG - 2023-04-23 12:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:30:15 --> Total execution time: 0.1230
DEBUG - 2023-04-23 12:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:30:15 --> Total execution time: 0.1431
DEBUG - 2023-04-23 12:00:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:30:16 --> Total execution time: 0.0983
DEBUG - 2023-04-23 12:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:30:17 --> Total execution time: 0.1511
DEBUG - 2023-04-23 12:01:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:31:52 --> Total execution time: 0.1012
DEBUG - 2023-04-23 12:01:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:31:53 --> Total execution time: 0.1632
DEBUG - 2023-04-23 12:01:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:31:56 --> Total execution time: 0.0920
DEBUG - 2023-04-23 12:01:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:31:57 --> Total execution time: 0.1732
DEBUG - 2023-04-23 12:01:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:31:58 --> Total execution time: 0.1036
DEBUG - 2023-04-23 12:01:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:31:59 --> Total execution time: 0.1693
DEBUG - 2023-04-23 12:03:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:33:54 --> Total execution time: 0.0957
DEBUG - 2023-04-23 12:03:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:33:54 --> Total execution time: 0.1367
DEBUG - 2023-04-23 12:04:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:34:41 --> Total execution time: 0.1067
DEBUG - 2023-04-23 12:04:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:34:42 --> Total execution time: 0.1474
DEBUG - 2023-04-23 12:08:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:38:43 --> Total execution time: 0.1055
DEBUG - 2023-04-23 12:08:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:38:44 --> Total execution time: 0.1435
DEBUG - 2023-04-23 12:09:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:39:13 --> Total execution time: 0.1080
DEBUG - 2023-04-23 12:09:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:39:14 --> Total execution time: 0.1479
DEBUG - 2023-04-23 12:11:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:41:55 --> Total execution time: 0.0977
DEBUG - 2023-04-23 12:11:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:41:55 --> Total execution time: 0.1463
DEBUG - 2023-04-23 12:11:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:41:56 --> Total execution time: 0.0975
DEBUG - 2023-04-23 12:11:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:41:56 --> Total execution time: 0.1559
DEBUG - 2023-04-23 12:16:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:46:05 --> Total execution time: 0.1214
DEBUG - 2023-04-23 12:16:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:46:05 --> Total execution time: 0.1445
DEBUG - 2023-04-23 12:16:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:46:16 --> Total execution time: 0.0967
DEBUG - 2023-04-23 12:16:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:46:17 --> Total execution time: 0.1292
DEBUG - 2023-04-23 12:17:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:47:00 --> Total execution time: 0.1310
DEBUG - 2023-04-23 12:17:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:47:01 --> Total execution time: 0.1809
DEBUG - 2023-04-23 12:17:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:47:15 --> Total execution time: 0.0941
DEBUG - 2023-04-23 12:17:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:47:15 --> Total execution time: 0.1669
DEBUG - 2023-04-23 12:17:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:47:27 --> Total execution time: 0.1140
DEBUG - 2023-04-23 12:17:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:47:27 --> Total execution time: 0.1333
DEBUG - 2023-04-23 12:17:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:47:32 --> Total execution time: 0.1007
DEBUG - 2023-04-23 12:17:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:47:32 --> Total execution time: 0.1199
DEBUG - 2023-04-23 12:18:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:48:20 --> Total execution time: 0.1015
DEBUG - 2023-04-23 12:18:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:48:21 --> Total execution time: 0.1516
DEBUG - 2023-04-23 12:19:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:49:16 --> Total execution time: 0.0992
DEBUG - 2023-04-23 12:19:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:49:17 --> Total execution time: 0.1425
DEBUG - 2023-04-23 12:20:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:50:06 --> Total execution time: 0.0984
DEBUG - 2023-04-23 12:20:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:50:06 --> Total execution time: 0.1283
DEBUG - 2023-04-23 12:20:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:50:47 --> Total execution time: 0.0989
DEBUG - 2023-04-23 12:20:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:50:48 --> Total execution time: 0.1815
DEBUG - 2023-04-23 12:21:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:51:09 --> Total execution time: 0.1042
DEBUG - 2023-04-23 12:21:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:51:09 --> Total execution time: 0.1438
DEBUG - 2023-04-23 12:21:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:51:46 --> Total execution time: 0.0959
DEBUG - 2023-04-23 12:21:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:51:46 --> Total execution time: 0.1289
DEBUG - 2023-04-23 12:22:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:52:03 --> Total execution time: 0.0933
DEBUG - 2023-04-23 12:22:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:52:03 --> Total execution time: 0.1611
DEBUG - 2023-04-23 12:22:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:52:34 --> Total execution time: 0.0969
DEBUG - 2023-04-23 12:22:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:52:34 --> Total execution time: 0.1254
DEBUG - 2023-04-23 12:22:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:22:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:22:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:22:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:22:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:22:49 --> UTF-8 Support Enabled
ERROR - 2023-04-23 12:22:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:22:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 12:22:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:22:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:22:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:22:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:22:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:22:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:22:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:22:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:23:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:53:27 --> Total execution time: 0.1002
DEBUG - 2023-04-23 12:23:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:23:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:23:28 --> UTF-8 Support Enabled
ERROR - 2023-04-23 12:23:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:23:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:23:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:23:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:23:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:23:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:23:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:23:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:23:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:23:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:23:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:23:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:23:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:23:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:23:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:23:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:23:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:23:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:23:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:23:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:23:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:53:29 --> Total execution time: 0.2263
DEBUG - 2023-04-23 12:23:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:53:43 --> Total execution time: 0.0962
DEBUG - 2023-04-23 12:23:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:53:43 --> Total execution time: 0.1791
DEBUG - 2023-04-23 12:28:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:58:14 --> Total execution time: 0.1299
DEBUG - 2023-04-23 12:28:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:58:15 --> Total execution time: 0.1480
DEBUG - 2023-04-23 12:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:58:27 --> Total execution time: 0.0961
DEBUG - 2023-04-23 12:28:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:58:27 --> Total execution time: 0.1358
DEBUG - 2023-04-23 12:28:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:58:51 --> Total execution time: 0.1063
DEBUG - 2023-04-23 12:28:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 15:58:51 --> Total execution time: 0.1340
DEBUG - 2023-04-23 12:30:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:00:22 --> Total execution time: 0.1039
DEBUG - 2023-04-23 12:30:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:00:23 --> Total execution time: 0.1674
DEBUG - 2023-04-23 12:31:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:01:06 --> Total execution time: 0.0989
DEBUG - 2023-04-23 12:31:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:01:06 --> Total execution time: 0.1596
DEBUG - 2023-04-23 12:33:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:03:56 --> Total execution time: 0.1047
DEBUG - 2023-04-23 12:33:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:03:56 --> Total execution time: 0.1405
DEBUG - 2023-04-23 12:33:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:03:59 --> Total execution time: 0.0966
DEBUG - 2023-04-23 12:33:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:03:59 --> Total execution time: 0.1548
DEBUG - 2023-04-23 12:34:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:04:35 --> Total execution time: 0.0994
DEBUG - 2023-04-23 12:34:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:04:35 --> Total execution time: 0.1575
DEBUG - 2023-04-23 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:04:47 --> Total execution time: 0.0946
DEBUG - 2023-04-23 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:04:47 --> Total execution time: 0.1744
DEBUG - 2023-04-23 12:35:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:05:04 --> Total execution time: 0.0937
DEBUG - 2023-04-23 12:35:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:05:05 --> Total execution time: 0.1588
DEBUG - 2023-04-23 12:35:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:05:37 --> Total execution time: 0.1136
DEBUG - 2023-04-23 12:35:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:05:37 --> Total execution time: 0.1673
DEBUG - 2023-04-23 12:35:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:05:56 --> Total execution time: 0.1164
DEBUG - 2023-04-23 12:35:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:05:57 --> Total execution time: 0.1661
DEBUG - 2023-04-23 12:36:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:06:04 --> Total execution time: 0.0962
DEBUG - 2023-04-23 12:36:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:06:04 --> Total execution time: 0.1473
DEBUG - 2023-04-23 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:06:14 --> Total execution time: 0.0953
DEBUG - 2023-04-23 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:06:14 --> Total execution time: 0.1670
DEBUG - 2023-04-23 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:06:21 --> Total execution time: 0.1034
DEBUG - 2023-04-23 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:06:22 --> Total execution time: 0.1633
DEBUG - 2023-04-23 12:36:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:06:43 --> Total execution time: 0.1849
DEBUG - 2023-04-23 12:36:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:06:44 --> Total execution time: 0.1728
DEBUG - 2023-04-23 12:37:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:07:13 --> Total execution time: 0.0962
DEBUG - 2023-04-23 12:37:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:07:13 --> Total execution time: 0.1686
DEBUG - 2023-04-23 12:37:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:07:54 --> Total execution time: 0.1023
DEBUG - 2023-04-23 12:37:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:07:55 --> Total execution time: 0.1620
DEBUG - 2023-04-23 12:38:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:08:17 --> Total execution time: 0.1017
DEBUG - 2023-04-23 12:38:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:08:17 --> Total execution time: 0.1758
DEBUG - 2023-04-23 12:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:38:35 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 12:38:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:38:35 --> UTF-8 Support Enabled
ERROR - 2023-04-23 12:38:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:38:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:38:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:38:35 --> UTF-8 Support Enabled
ERROR - 2023-04-23 12:38:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:38:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:38:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:39:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:09:37 --> Total execution time: 0.1000
DEBUG - 2023-04-23 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:39:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:39:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 12:39:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:39:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:39:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:39:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:39:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:39:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:09:38 --> Total execution time: 0.1615
DEBUG - 2023-04-23 12:40:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:10:12 --> Total execution time: 0.1046
DEBUG - 2023-04-23 12:40:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:40:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:40:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:40:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:40:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:40:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:40:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:40:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:40:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:40:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 12:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:10:13 --> Total execution time: 0.1848
DEBUG - 2023-04-23 12:40:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:10:18 --> Total execution time: 0.0988
DEBUG - 2023-04-23 12:40:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:10:19 --> Total execution time: 0.1702
DEBUG - 2023-04-23 12:40:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:10:41 --> Total execution time: 0.1014
DEBUG - 2023-04-23 12:40:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:10:42 --> Total execution time: 0.1598
DEBUG - 2023-04-23 12:40:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:10:54 --> Total execution time: 0.1071
DEBUG - 2023-04-23 12:40:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:10:55 --> Total execution time: 0.1643
DEBUG - 2023-04-23 12:41:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:11:17 --> Total execution time: 0.1019
DEBUG - 2023-04-23 12:41:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:11:17 --> Total execution time: 0.1441
DEBUG - 2023-04-23 12:42:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:12:31 --> Total execution time: 0.1043
DEBUG - 2023-04-23 12:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:12:32 --> Total execution time: 0.1823
DEBUG - 2023-04-23 12:42:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:12:54 --> Total execution time: 0.0955
DEBUG - 2023-04-23 12:42:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:12:55 --> Total execution time: 0.1578
DEBUG - 2023-04-23 12:43:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:13:05 --> Total execution time: 0.0953
DEBUG - 2023-04-23 12:43:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:13:06 --> Total execution time: 0.1502
DEBUG - 2023-04-23 12:43:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:13:09 --> Total execution time: 0.0977
DEBUG - 2023-04-23 12:43:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:13:10 --> Total execution time: 0.1495
DEBUG - 2023-04-23 12:43:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:13:26 --> Total execution time: 0.1013
DEBUG - 2023-04-23 12:43:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:13:27 --> Total execution time: 0.1793
DEBUG - 2023-04-23 12:44:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:14:18 --> Total execution time: 0.1676
DEBUG - 2023-04-23 12:44:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:14:18 --> Total execution time: 0.1907
DEBUG - 2023-04-23 12:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:14:40 --> Total execution time: 0.1072
DEBUG - 2023-04-23 12:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:14:41 --> Total execution time: 0.1706
DEBUG - 2023-04-23 12:45:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:15:35 --> Total execution time: 0.1039
DEBUG - 2023-04-23 12:45:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:15:35 --> Total execution time: 0.1583
DEBUG - 2023-04-23 12:46:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:16:30 --> Total execution time: 0.0984
DEBUG - 2023-04-23 12:46:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:16:31 --> Total execution time: 0.1713
DEBUG - 2023-04-23 12:47:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:17:58 --> Total execution time: 0.1427
DEBUG - 2023-04-23 12:47:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:17:59 --> Total execution time: 0.2040
DEBUG - 2023-04-23 12:47:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:48:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 12:48:00 --> 404 Page Not Found: admin/Category/add
DEBUG - 2023-04-23 12:48:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:18:00 --> Total execution time: 0.1692
DEBUG - 2023-04-23 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:48:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:18:41 --> Total execution time: 0.1769
DEBUG - 2023-04-23 12:48:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:18:45 --> Total execution time: 0.0987
DEBUG - 2023-04-23 12:48:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:18:46 --> Total execution time: 0.1636
DEBUG - 2023-04-23 12:48:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:18:46 --> Total execution time: 0.1022
DEBUG - 2023-04-23 12:48:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:18:47 --> Total execution time: 0.1551
DEBUG - 2023-04-23 12:48:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:18:48 --> Total execution time: 0.1140
DEBUG - 2023-04-23 12:48:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:18:48 --> Total execution time: 0.1635
DEBUG - 2023-04-23 12:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:19:22 --> Total execution time: 0.1081
DEBUG - 2023-04-23 12:49:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:19:23 --> Total execution time: 0.1508
DEBUG - 2023-04-23 12:49:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:19:24 --> Total execution time: 0.1092
DEBUG - 2023-04-23 12:49:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:19:25 --> Total execution time: 0.1688
DEBUG - 2023-04-23 12:49:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:19:26 --> Total execution time: 0.1089
DEBUG - 2023-04-23 12:49:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:19:26 --> Total execution time: 0.1881
DEBUG - 2023-04-23 12:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:19:30 --> Total execution time: 0.1156
DEBUG - 2023-04-23 12:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:19:30 --> Total execution time: 0.1588
DEBUG - 2023-04-23 12:49:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:19:32 --> Total execution time: 0.1062
DEBUG - 2023-04-23 12:49:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:19:32 --> Total execution time: 0.1744
DEBUG - 2023-04-23 12:49:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:19:33 --> Total execution time: 0.1085
DEBUG - 2023-04-23 12:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:19:34 --> Total execution time: 0.1536
DEBUG - 2023-04-23 12:49:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:19:36 --> Total execution time: 0.0973
DEBUG - 2023-04-23 12:49:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:19:37 --> Total execution time: 0.1678
DEBUG - 2023-04-23 12:53:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:23:58 --> Total execution time: 0.1377
DEBUG - 2023-04-23 12:53:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:23:58 --> Total execution time: 0.1667
DEBUG - 2023-04-23 12:54:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:54:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:24:29 --> Total execution time: 0.1781
DEBUG - 2023-04-23 12:54:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:24:31 --> Total execution time: 0.1025
DEBUG - 2023-04-23 12:54:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:24:32 --> Total execution time: 0.1388
DEBUG - 2023-04-23 12:54:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:54:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:24:35 --> Total execution time: 0.1726
DEBUG - 2023-04-23 12:54:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:24:37 --> Total execution time: 0.0986
DEBUG - 2023-04-23 12:54:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:24:37 --> Total execution time: 0.1612
DEBUG - 2023-04-23 12:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:24:41 --> Total execution time: 0.1647
DEBUG - 2023-04-23 12:54:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:24:42 --> Total execution time: 0.0984
DEBUG - 2023-04-23 12:54:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:24:43 --> Total execution time: 0.1503
DEBUG - 2023-04-23 12:54:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:24:46 --> Total execution time: 0.0925
DEBUG - 2023-04-23 12:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:24:47 --> Total execution time: 0.1634
DEBUG - 2023-04-23 12:54:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:54:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:24:52 --> Total execution time: 0.1574
DEBUG - 2023-04-23 12:55:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:55:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:25:52 --> Total execution time: 0.1664
DEBUG - 2023-04-23 12:55:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:25:58 --> Total execution time: 0.0971
DEBUG - 2023-04-23 12:55:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:25:58 --> Total execution time: 0.1756
DEBUG - 2023-04-23 12:56:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:26:03 --> Total execution time: 0.0959
DEBUG - 2023-04-23 12:56:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:26:03 --> Total execution time: 0.1549
DEBUG - 2023-04-23 12:56:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:56:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:26:06 --> Total execution time: 0.0890
DEBUG - 2023-04-23 12:56:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:26:06 --> Total execution time: 0.1796
DEBUG - 2023-04-23 12:56:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:26:35 --> Total execution time: 0.1041
DEBUG - 2023-04-23 12:56:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:26:35 --> Total execution time: 0.1425
DEBUG - 2023-04-23 12:56:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:26:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:26:39 --> Total execution time: 0.1807
DEBUG - 2023-04-23 12:56:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:26:39 --> Total execution time: 0.1425
DEBUG - 2023-04-23 12:59:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:59:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:29:03 --> Total execution time: 0.1774
DEBUG - 2023-04-23 12:59:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:29:04 --> Total execution time: 0.1059
DEBUG - 2023-04-23 12:59:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:29:05 --> Total execution time: 0.1508
DEBUG - 2023-04-23 12:59:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:29:54 --> Total execution time: 0.0957
DEBUG - 2023-04-23 12:59:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:29:54 --> Total execution time: 0.1691
DEBUG - 2023-04-23 12:59:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 12:59:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 12:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 12:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 12:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:29:59 --> Total execution time: 0.1650
DEBUG - 2023-04-23 13:00:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:30:01 --> Total execution time: 0.1001
DEBUG - 2023-04-23 13:00:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:30:01 --> Total execution time: 0.1570
DEBUG - 2023-04-23 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:30:03 --> Total execution time: 0.1640
DEBUG - 2023-04-23 13:00:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:30:04 --> Total execution time: 0.1094
DEBUG - 2023-04-23 13:00:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:30:04 --> Total execution time: 0.1590
DEBUG - 2023-04-23 13:02:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:32:12 --> Total execution time: 0.1279
DEBUG - 2023-04-23 13:02:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:32:13 --> Total execution time: 0.1501
DEBUG - 2023-04-23 13:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:32:43 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 16:32:43 --> Total execution time: 0.1278
DEBUG - 2023-04-23 13:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:32:43 --> Total execution time: 0.1660
DEBUG - 2023-04-23 13:03:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:33:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 13:03:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:33:41 --> Total execution time: 0.1006
DEBUG - 2023-04-23 13:03:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:33:42 --> Total execution time: 0.1731
DEBUG - 2023-04-23 13:03:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:33:57 --> Total execution time: 0.1041
DEBUG - 2023-04-23 13:03:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:33:57 --> Total execution time: 0.1547
DEBUG - 2023-04-23 13:06:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:36:56 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 13:06:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:36:56 --> Total execution time: 0.1100
DEBUG - 2023-04-23 13:06:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:36:57 --> Total execution time: 0.1568
DEBUG - 2023-04-23 13:09:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:39:32 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 13:09:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:39:32 --> Total execution time: 0.0977
DEBUG - 2023-04-23 13:09:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:39:32 --> Total execution time: 0.1643
DEBUG - 2023-04-23 13:09:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:39:53 --> Total execution time: 0.1041
DEBUG - 2023-04-23 13:09:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:39:54 --> Total execution time: 0.2018
DEBUG - 2023-04-23 13:11:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:41:13 --> Total execution time: 0.1027
DEBUG - 2023-04-23 13:11:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:41:13 --> Total execution time: 0.1716
DEBUG - 2023-04-23 13:11:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 13:11:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:41:24 --> Total execution time: 0.0932
DEBUG - 2023-04-23 13:11:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:41:25 --> Total execution time: 0.1550
DEBUG - 2023-04-23 13:12:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:42:03 --> Total execution time: 0.1051
DEBUG - 2023-04-23 13:12:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:42:04 --> Total execution time: 0.1958
DEBUG - 2023-04-23 13:12:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:12:08 --> 404 Page Not Found: admin/Category/list
DEBUG - 2023-04-23 13:12:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:12:08 --> 404 Page Not Found: admin/Category/list
DEBUG - 2023-04-23 13:13:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:43:04 --> Total execution time: 0.0931
DEBUG - 2023-04-23 13:13:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:43:05 --> Total execution time: 0.1465
DEBUG - 2023-04-23 13:16:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:46:40 --> Total execution time: 0.0937
DEBUG - 2023-04-23 13:16:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:46:41 --> Total execution time: 0.1423
DEBUG - 2023-04-23 13:18:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:48:34 --> Total execution time: 0.1054
DEBUG - 2023-04-23 13:18:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:48:35 --> Total execution time: 0.1768
DEBUG - 2023-04-23 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:49:51 --> Total execution time: 0.1066
DEBUG - 2023-04-23 13:19:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:49:52 --> Total execution time: 0.1409
DEBUG - 2023-04-23 13:20:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:50:18 --> Total execution time: 0.0992
DEBUG - 2023-04-23 13:20:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:50:19 --> Total execution time: 0.1579
DEBUG - 2023-04-23 13:20:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:50:28 --> Total execution time: 0.0964
DEBUG - 2023-04-23 13:20:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:50:28 --> Total execution time: 0.1292
DEBUG - 2023-04-23 13:20:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:20:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:20:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:20:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:20:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:20:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:20:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:20:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:20:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:20:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:20:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:20:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:20:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:20:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:20:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:20:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:21:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:51:01 --> Total execution time: 0.1120
DEBUG - 2023-04-23 13:21:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:21:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:21:02 --> UTF-8 Support Enabled
ERROR - 2023-04-23 13:21:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:21:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 13:21:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:21:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:21:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:21:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:21:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:21:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:21:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:21:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:21:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:21:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:21:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:21:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:21:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:21:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:51:03 --> Total execution time: 0.1828
DEBUG - 2023-04-23 13:24:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:54:16 --> Total execution time: 0.1041
DEBUG - 2023-04-23 13:24:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:54:16 --> Total execution time: 0.1544
DEBUG - 2023-04-23 13:24:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:54:29 --> Total execution time: 0.1033
DEBUG - 2023-04-23 13:24:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:54:29 --> Total execution time: 0.1771
DEBUG - 2023-04-23 13:24:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:24:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:24:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:24:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:24:59 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 13:24:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:24:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:24:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:24:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:24:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:24:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:24:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:24:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:24:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:24:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:24:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:25:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:55:42 --> Total execution time: 0.1061
DEBUG - 2023-04-23 13:25:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:25:42 --> UTF-8 Support Enabled
ERROR - 2023-04-23 13:25:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:25:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:25:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:25:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:25:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:25:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:25:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:25:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:25:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:25:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:25:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:25:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:25:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:25:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:25:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:25:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:25:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:25:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:25:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:25:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:25:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 13:25:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:55:44 --> Total execution time: 0.2314
DEBUG - 2023-04-23 13:28:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:58:02 --> Total execution time: 0.1033
DEBUG - 2023-04-23 13:28:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:58:03 --> Total execution time: 0.1679
DEBUG - 2023-04-23 13:28:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:28:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:28:06 --> 404 Page Not Found: admin/Category/edit
DEBUG - 2023-04-23 13:28:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:28:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:28:06 --> 404 Page Not Found: admin/Category/edit
DEBUG - 2023-04-23 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 13:31:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:01:12 --> Total execution time: 0.1104
DEBUG - 2023-04-23 13:31:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:01:13 --> Total execution time: 0.1590
DEBUG - 2023-04-23 13:31:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:01:46 --> Total execution time: 0.0972
DEBUG - 2023-04-23 13:31:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:01:46 --> Total execution time: 0.1599
DEBUG - 2023-04-23 13:31:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:02:00 --> Total execution time: 0.1063
DEBUG - 2023-04-23 13:32:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:02:00 --> Total execution time: 0.1734
DEBUG - 2023-04-23 13:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:02:07 --> Total execution time: 0.0995
DEBUG - 2023-04-23 13:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:02:08 --> Total execution time: 0.1542
DEBUG - 2023-04-23 13:32:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:02:50 --> Total execution time: 0.1122
DEBUG - 2023-04-23 13:32:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:02:51 --> Total execution time: 0.1661
DEBUG - 2023-04-23 13:33:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:03:22 --> Total execution time: 0.1039
DEBUG - 2023-04-23 13:33:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:03:22 --> Total execution time: 0.1679
DEBUG - 2023-04-23 13:33:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:03:44 --> Total execution time: 0.1128
DEBUG - 2023-04-23 13:33:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:03:45 --> Total execution time: 0.1826
DEBUG - 2023-04-23 13:35:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:05:03 --> Total execution time: 0.1034
DEBUG - 2023-04-23 13:35:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:05:04 --> Total execution time: 0.1749
DEBUG - 2023-04-23 13:35:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:05:05 --> Total execution time: 0.1023
DEBUG - 2023-04-23 13:35:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:35:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 13:35:05 --> 404 Page Not Found: admin/Category/update
DEBUG - 2023-04-23 13:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:12:26 --> Total execution time: 0.1074
DEBUG - 2023-04-23 13:42:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:12:27 --> Total execution time: 0.1654
DEBUG - 2023-04-23 13:43:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:13:14 --> Total execution time: 0.1010
DEBUG - 2023-04-23 13:43:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:13:14 --> Total execution time: 0.1834
DEBUG - 2023-04-23 13:43:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 13:43:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:13:22 --> Total execution time: 0.1019
DEBUG - 2023-04-23 13:43:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:13:22 --> Total execution time: 0.1569
DEBUG - 2023-04-23 13:43:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 13:43:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:13:31 --> Total execution time: 0.0927
DEBUG - 2023-04-23 13:43:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:13:31 --> Total execution time: 0.1578
DEBUG - 2023-04-23 13:43:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:13:42 --> Total execution time: 0.1157
DEBUG - 2023-04-23 13:43:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:13:42 --> Total execution time: 0.1705
DEBUG - 2023-04-23 13:45:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:15:11 --> Total execution time: 0.1111
DEBUG - 2023-04-23 13:45:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:15:12 --> Total execution time: 0.1761
DEBUG - 2023-04-23 13:45:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:15:21 --> Upload class already loaded. Second attempt ignored.
ERROR - 2023-04-23 17:15:21 --> Severity: Notice --> Undefined variable: cat_image C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Category_Crud.php 129
DEBUG - 2023-04-23 13:45:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:15:21 --> Total execution time: 0.1002
DEBUG - 2023-04-23 13:45:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:15:21 --> Total execution time: 0.1982
DEBUG - 2023-04-23 13:45:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:15:37 --> Upload class already loaded. Second attempt ignored.
ERROR - 2023-04-23 17:15:37 --> Severity: Notice --> Undefined variable: cat_image C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Category_Crud.php 129
DEBUG - 2023-04-23 13:45:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:15:37 --> Total execution time: 0.1009
DEBUG - 2023-04-23 13:45:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:15:37 --> Total execution time: 0.1718
DEBUG - 2023-04-23 13:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:15:44 --> Total execution time: 0.1012
DEBUG - 2023-04-23 13:45:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:15:46 --> Total execution time: 0.1785
DEBUG - 2023-04-23 13:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:15:48 --> Total execution time: 0.1009
DEBUG - 2023-04-23 13:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:15:48 --> Total execution time: 0.1522
DEBUG - 2023-04-23 13:46:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:16:30 --> Total execution time: 0.1096
DEBUG - 2023-04-23 13:46:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:16:30 --> Total execution time: 0.1953
DEBUG - 2023-04-23 13:46:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:16:34 --> Total execution time: 0.1113
DEBUG - 2023-04-23 13:46:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:16:34 --> Total execution time: 0.1779
DEBUG - 2023-04-23 13:46:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 13:46:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:16:38 --> Total execution time: 0.0961
DEBUG - 2023-04-23 13:46:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:16:38 --> Total execution time: 0.1477
DEBUG - 2023-04-23 13:46:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:16:45 --> Upload class already loaded. Second attempt ignored.
ERROR - 2023-04-23 17:16:45 --> Severity: Notice --> Undefined variable: cat_image C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Category_Crud.php 129
DEBUG - 2023-04-23 13:46:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:16:45 --> Total execution time: 0.1041
DEBUG - 2023-04-23 13:46:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:16:46 --> Total execution time: 0.1554
DEBUG - 2023-04-23 13:47:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:17:34 --> Total execution time: 0.1136
DEBUG - 2023-04-23 13:47:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:17:35 --> Total execution time: 0.1569
DEBUG - 2023-04-23 13:47:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:17:50 --> Total execution time: 0.0984
DEBUG - 2023-04-23 13:47:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:17:50 --> Total execution time: 0.1542
DEBUG - 2023-04-23 13:47:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:17:54 --> Total execution time: 0.0982
DEBUG - 2023-04-23 13:47:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:17:54 --> Total execution time: 0.1718
DEBUG - 2023-04-23 13:48:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:18:24 --> Total execution time: 0.1060
DEBUG - 2023-04-23 13:48:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:18:25 --> Total execution time: 0.1806
DEBUG - 2023-04-23 13:49:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:19:07 --> Total execution time: 0.0997
DEBUG - 2023-04-23 13:49:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:19:07 --> Total execution time: 0.1862
DEBUG - 2023-04-23 13:55:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:25:50 --> Total execution time: 0.1149
DEBUG - 2023-04-23 13:55:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:25:51 --> Total execution time: 0.1546
DEBUG - 2023-04-23 13:57:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:27:25 --> Total execution time: 0.1025
DEBUG - 2023-04-23 13:57:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:27:25 --> Total execution time: 0.1695
DEBUG - 2023-04-23 13:57:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:27:27 --> Total execution time: 0.1043
DEBUG - 2023-04-23 13:57:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:27:28 --> Total execution time: 0.1609
DEBUG - 2023-04-23 13:59:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:29:01 --> Total execution time: 0.1032
DEBUG - 2023-04-23 13:59:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 13:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 13:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 13:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:29:02 --> Total execution time: 0.1555
DEBUG - 2023-04-23 14:01:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:31:39 --> Total execution time: 0.1085
DEBUG - 2023-04-23 14:01:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:31:39 --> Total execution time: 0.1697
DEBUG - 2023-04-23 14:01:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:31:47 --> Total execution time: 0.1052
DEBUG - 2023-04-23 14:01:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:31:48 --> Total execution time: 0.1491
DEBUG - 2023-04-23 14:03:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:33:42 --> Total execution time: 0.1098
DEBUG - 2023-04-23 14:03:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:33:43 --> Total execution time: 0.1665
DEBUG - 2023-04-23 14:03:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:33:44 --> Total execution time: 0.0965
DEBUG - 2023-04-23 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:33:45 --> Total execution time: 0.1585
DEBUG - 2023-04-23 14:04:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:34:29 --> Total execution time: 0.1099
DEBUG - 2023-04-23 14:04:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:34:29 --> Total execution time: 0.1487
DEBUG - 2023-04-23 14:04:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:34:41 --> Total execution time: 0.0982
DEBUG - 2023-04-23 14:04:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:34:41 --> Total execution time: 0.2040
DEBUG - 2023-04-23 14:06:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:36:16 --> Total execution time: 0.1095
DEBUG - 2023-04-23 14:06:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:36:17 --> Total execution time: 0.1692
DEBUG - 2023-04-23 14:06:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:36:39 --> Total execution time: 0.1023
DEBUG - 2023-04-23 14:06:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:36:40 --> Total execution time: 0.1605
DEBUG - 2023-04-23 14:07:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:37:30 --> Total execution time: 0.1008
DEBUG - 2023-04-23 14:07:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:37:30 --> Total execution time: 0.1637
DEBUG - 2023-04-23 14:07:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:37:50 --> Total execution time: 0.0951
DEBUG - 2023-04-23 14:07:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:37:51 --> Total execution time: 0.1474
DEBUG - 2023-04-23 14:08:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:38:26 --> Total execution time: 0.1050
DEBUG - 2023-04-23 14:08:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:38:26 --> Total execution time: 0.1486
DEBUG - 2023-04-23 14:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:38:51 --> Total execution time: 0.1085
DEBUG - 2023-04-23 14:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:38:51 --> Total execution time: 0.1899
DEBUG - 2023-04-23 14:09:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:39:33 --> Total execution time: 0.1010
DEBUG - 2023-04-23 14:09:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:39:34 --> Total execution time: 0.1626
DEBUG - 2023-04-23 14:11:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:41:04 --> Total execution time: 0.1033
DEBUG - 2023-04-23 14:11:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:41:05 --> Total execution time: 0.1661
DEBUG - 2023-04-23 14:11:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:41:18 --> Total execution time: 0.0957
DEBUG - 2023-04-23 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:41:19 --> Total execution time: 0.1730
DEBUG - 2023-04-23 14:11:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:41:55 --> Total execution time: 0.1030
DEBUG - 2023-04-23 14:11:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:41:56 --> Total execution time: 0.1541
DEBUG - 2023-04-23 14:12:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:42:06 --> Total execution time: 0.0959
DEBUG - 2023-04-23 14:12:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:42:06 --> Total execution time: 0.1721
DEBUG - 2023-04-23 14:13:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:43:32 --> Total execution time: 0.0974
DEBUG - 2023-04-23 14:13:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:43:33 --> Total execution time: 0.1830
DEBUG - 2023-04-23 14:15:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:45:11 --> Total execution time: 0.2074
DEBUG - 2023-04-23 14:15:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:45:12 --> Total execution time: 0.2272
DEBUG - 2023-04-23 14:16:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:46:20 --> Total execution time: 0.0962
DEBUG - 2023-04-23 14:16:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:46:20 --> Total execution time: 0.1573
DEBUG - 2023-04-23 14:16:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:46:55 --> Total execution time: 0.1047
DEBUG - 2023-04-23 14:16:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:46:55 --> Total execution time: 0.2106
DEBUG - 2023-04-23 14:18:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:48:49 --> Total execution time: 0.1147
DEBUG - 2023-04-23 14:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:48:49 --> Total execution time: 0.1966
DEBUG - 2023-04-23 14:19:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:19:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:19:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:19:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:19:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:19:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:19:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 14:19:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:19:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:49:23 --> Total execution time: 0.1094
DEBUG - 2023-04-23 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:19:24 --> UTF-8 Support Enabled
ERROR - 2023-04-23 14:19:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:19:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:19:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:19:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:19:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:19:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:19:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:19:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:19:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:19:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:49:25 --> Total execution time: 0.2195
DEBUG - 2023-04-23 14:20:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:50:46 --> Total execution time: 0.1006
DEBUG - 2023-04-23 14:20:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:50:46 --> Total execution time: 0.1558
DEBUG - 2023-04-23 14:21:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:21:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:21:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:21:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:21:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:21:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:21:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:21:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:21:29 --> UTF-8 Support Enabled
ERROR - 2023-04-23 14:21:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:21:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:21:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:21:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:21:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:21:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:21:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:21:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:21:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:21:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:21:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:21:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:21:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:21:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:22:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:52:06 --> Total execution time: 0.1320
DEBUG - 2023-04-23 14:22:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:22:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:22:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:22:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:22:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:22:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:22:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:22:06 --> UTF-8 Support Enabled
ERROR - 2023-04-23 14:22:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:22:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:22:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:22:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:22:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:22:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:22:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:22:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:22:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:22:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:22:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:22:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:22:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:22:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:22:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:22:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 14:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:52:07 --> Total execution time: 0.3295
DEBUG - 2023-04-23 14:22:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:52:20 --> Total execution time: 0.1056
DEBUG - 2023-04-23 14:22:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:52:21 --> Total execution time: 0.2302
DEBUG - 2023-04-23 14:23:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:53:20 --> Total execution time: 0.1043
DEBUG - 2023-04-23 14:23:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:53:21 --> Total execution time: 0.1889
DEBUG - 2023-04-23 14:26:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:56:57 --> Total execution time: 0.1313
DEBUG - 2023-04-23 14:26:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:56:57 --> Total execution time: 0.1653
DEBUG - 2023-04-23 14:28:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:58:09 --> Total execution time: 0.1017
DEBUG - 2023-04-23 14:28:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:58:09 --> Total execution time: 0.1810
DEBUG - 2023-04-23 14:29:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:59:15 --> Total execution time: 0.1032
DEBUG - 2023-04-23 14:29:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:59:16 --> Total execution time: 0.1593
DEBUG - 2023-04-23 14:29:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 14:29:17 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 14:30:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:00:15 --> Total execution time: 0.1074
DEBUG - 2023-04-23 14:30:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:00:16 --> Total execution time: 0.1798
DEBUG - 2023-04-23 14:31:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:01:39 --> Total execution time: 0.1055
DEBUG - 2023-04-23 14:31:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:01:39 --> Total execution time: 0.1747
DEBUG - 2023-04-23 14:33:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:03:08 --> Total execution time: 0.1045
DEBUG - 2023-04-23 14:33:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:03:09 --> Total execution time: 0.1663
DEBUG - 2023-04-23 14:33:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:03:25 --> Total execution time: 0.1024
DEBUG - 2023-04-23 14:33:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:03:25 --> Total execution time: 0.1646
DEBUG - 2023-04-23 14:33:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:03:59 --> Total execution time: 0.1065
DEBUG - 2023-04-23 14:33:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:03:59 --> Total execution time: 0.1720
DEBUG - 2023-04-23 14:36:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:06:00 --> Total execution time: 0.1009
DEBUG - 2023-04-23 14:36:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:06:01 --> Total execution time: 0.1682
DEBUG - 2023-04-23 14:36:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:06:14 --> Total execution time: 0.1041
DEBUG - 2023-04-23 14:36:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:06:14 --> Total execution time: 0.1692
DEBUG - 2023-04-23 14:42:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:12:06 --> Total execution time: 1.4626
DEBUG - 2023-04-23 14:42:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:12:07 --> Total execution time: 0.1582
DEBUG - 2023-04-23 14:42:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:12:13 --> Total execution time: 0.1096
DEBUG - 2023-04-23 14:42:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:12:14 --> Total execution time: 0.1736
DEBUG - 2023-04-23 14:42:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:12:22 --> Total execution time: 0.1145
DEBUG - 2023-04-23 14:42:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:12:23 --> Total execution time: 0.1805
DEBUG - 2023-04-23 14:42:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:12:33 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 14:42:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:12:33 --> Total execution time: 0.1644
DEBUG - 2023-04-23 14:42:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:12:41 --> Total execution time: 0.1138
DEBUG - 2023-04-23 14:42:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:12:42 --> Total execution time: 0.1923
DEBUG - 2023-04-23 14:42:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:12:43 --> Total execution time: 0.1245
DEBUG - 2023-04-23 14:42:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:12:43 --> Total execution time: 0.1670
DEBUG - 2023-04-23 14:43:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:13:54 --> Total execution time: 0.1105
DEBUG - 2023-04-23 14:43:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:13:54 --> Total execution time: 0.1733
DEBUG - 2023-04-23 14:44:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:14:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 18:14:05 --> You did not select a file to upload.
DEBUG - 2023-04-23 18:14:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 18:14:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 18:14:05 --> Total execution time: 0.1736
DEBUG - 2023-04-23 14:44:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:14:05 --> Total execution time: 0.1770
DEBUG - 2023-04-23 14:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:15:47 --> Total execution time: 0.1382
DEBUG - 2023-04-23 14:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:15:48 --> Total execution time: 0.1692
DEBUG - 2023-04-23 14:45:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:15:49 --> Total execution time: 0.1048
DEBUG - 2023-04-23 14:45:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:15:50 --> Total execution time: 0.1512
DEBUG - 2023-04-23 14:48:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 14:48:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 14:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 14:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 14:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:18:15 --> Total execution time: 0.1558
DEBUG - 2023-04-23 15:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:37:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 18:37:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 18:37:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 18:37:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 18:37:37 --> Total execution time: 0.2287
DEBUG - 2023-04-23 15:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:37:38 --> Total execution time: 0.1572
DEBUG - 2023-04-23 15:11:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:41:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 18:41:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 18:41:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 18:41:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:11:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:41:29 --> Total execution time: 0.1005
DEBUG - 2023-04-23 15:11:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:41:30 --> Total execution time: 0.2054
DEBUG - 2023-04-23 15:12:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:42:16 --> Total execution time: 0.1021
DEBUG - 2023-04-23 15:12:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:42:16 --> Total execution time: 0.1703
DEBUG - 2023-04-23 15:14:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:44:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 15:14:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:44:10 --> Total execution time: 0.0996
DEBUG - 2023-04-23 15:14:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:44:11 --> Total execution time: 0.1557
DEBUG - 2023-04-23 15:52:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:22:30 --> Total execution time: 0.1229
DEBUG - 2023-04-23 15:52:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:22:31 --> Total execution time: 0.1864
DEBUG - 2023-04-23 15:53:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:23:08 --> Total execution time: 0.1034
DEBUG - 2023-04-23 15:53:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:23:09 --> Total execution time: 0.1531
DEBUG - 2023-04-23 15:53:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:23:13 --> Total execution time: 0.0939
DEBUG - 2023-04-23 15:53:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:23:13 --> Total execution time: 0.1471
DEBUG - 2023-04-23 15:53:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:23:42 --> Total execution time: 0.1044
DEBUG - 2023-04-23 15:53:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:23:42 --> Total execution time: 0.1507
DEBUG - 2023-04-23 15:53:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:23:46 --> Total execution time: 0.1012
DEBUG - 2023-04-23 15:53:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:23:47 --> Total execution time: 0.1699
DEBUG - 2023-04-23 15:55:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:25:17 --> Total execution time: 0.1004
DEBUG - 2023-04-23 15:55:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:25:18 --> Total execution time: 0.1660
DEBUG - 2023-04-23 15:55:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:25:22 --> Total execution time: 0.0959
DEBUG - 2023-04-23 15:55:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:25:23 --> Total execution time: 0.1638
DEBUG - 2023-04-23 15:56:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:26:32 --> Total execution time: 0.1049
DEBUG - 2023-04-23 15:56:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:26:33 --> Total execution time: 0.2078
DEBUG - 2023-04-23 15:56:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:26:50 --> Total execution time: 0.0984
DEBUG - 2023-04-23 15:56:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:26:51 --> Total execution time: 0.1836
DEBUG - 2023-04-23 15:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:27:35 --> Total execution time: 0.1172
DEBUG - 2023-04-23 15:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:27:35 --> Total execution time: 0.2285
DEBUG - 2023-04-23 15:58:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:58:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 15:58:17 --> 404 Page Not Found: admin/Car/list
DEBUG - 2023-04-23 15:58:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:58:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 15:58:17 --> 404 Page Not Found: admin/Car/list
DEBUG - 2023-04-23 15:58:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:28:19 --> Total execution time: 0.1033
DEBUG - 2023-04-23 15:58:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:28:19 --> Total execution time: 0.1600
DEBUG - 2023-04-23 15:59:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:29:19 --> Total execution time: 0.1038
DEBUG - 2023-04-23 15:59:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 15:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 15:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 15:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:29:20 --> Total execution time: 0.1741
DEBUG - 2023-04-23 16:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:30:17 --> Total execution time: 0.0983
DEBUG - 2023-04-23 16:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:30:17 --> Total execution time: 0.1571
DEBUG - 2023-04-23 16:01:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:01:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:31:08 --> Total execution time: 0.1066
DEBUG - 2023-04-23 16:01:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:31:08 --> Total execution time: 0.1554
DEBUG - 2023-04-23 16:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:01:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 16:01:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:01:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 16:01:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:01:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:01:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:01:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:01:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:02:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:32:07 --> Total execution time: 0.1006
DEBUG - 2023-04-23 16:02:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:02:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:02:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:02:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:02:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:02:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:02:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:02:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:02:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:02:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:02:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:02:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:02:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:02:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:02:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:02:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:02:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:02:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:02:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:02:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:02:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:02:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:02:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:02:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:02:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:32:09 --> Total execution time: 0.2149
DEBUG - 2023-04-23 16:05:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:35:33 --> Total execution time: 0.1011
DEBUG - 2023-04-23 16:05:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:35:33 --> Total execution time: 0.1873
DEBUG - 2023-04-23 16:06:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:36:33 --> Total execution time: 0.1002
DEBUG - 2023-04-23 16:06:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:36:33 --> Total execution time: 0.1910
DEBUG - 2023-04-23 16:07:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:37:43 --> Total execution time: 0.1026
DEBUG - 2023-04-23 16:07:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:37:44 --> Total execution time: 0.2451
DEBUG - 2023-04-23 16:07:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:37:51 --> Total execution time: 0.1085
DEBUG - 2023-04-23 16:07:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:37:52 --> Total execution time: 0.1937
DEBUG - 2023-04-23 16:08:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:38:14 --> Total execution time: 0.0952
DEBUG - 2023-04-23 16:08:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:38:14 --> Total execution time: 0.1989
DEBUG - 2023-04-23 16:08:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:38:39 --> Total execution time: 0.1013
DEBUG - 2023-04-23 16:08:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:38:40 --> Total execution time: 0.1936
DEBUG - 2023-04-23 16:10:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:10:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:10:23 --> 404 Page Not Found: admin/Car/list
DEBUG - 2023-04-23 16:10:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:10:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:10:23 --> 404 Page Not Found: admin/Car/list
DEBUG - 2023-04-23 16:14:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:44:01 --> Total execution time: 0.1086
DEBUG - 2023-04-23 16:14:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:44:02 --> Total execution time: 0.1740
DEBUG - 2023-04-23 16:14:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:44:39 --> Total execution time: 0.1137
DEBUG - 2023-04-23 16:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:44:40 --> Total execution time: 0.1651
DEBUG - 2023-04-23 16:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:50:01 --> Total execution time: 0.1311
DEBUG - 2023-04-23 16:20:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:50:02 --> Total execution time: 0.1606
DEBUG - 2023-04-23 16:20:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:20:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 19:50:12 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 19:50:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 19:50:12 --> Total execution time: 0.1457
DEBUG - 2023-04-23 16:20:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:20:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 19:50:13 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 19:50:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 19:50:13 --> Total execution time: 0.1678
DEBUG - 2023-04-23 16:20:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:50:14 --> Total execution time: 0.0999
DEBUG - 2023-04-23 16:20:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:50:15 --> Total execution time: 0.1614
DEBUG - 2023-04-23 16:20:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:20:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 19:50:32 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 19:50:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 19:50:32 --> Total execution time: 0.1159
DEBUG - 2023-04-23 16:20:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:20:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 19:50:32 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 19:50:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 19:50:32 --> Total execution time: 0.2069
DEBUG - 2023-04-23 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:50:35 --> Total execution time: 0.1011
DEBUG - 2023-04-23 16:20:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:50:36 --> Total execution time: 0.1613
DEBUG - 2023-04-23 16:23:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:53:47 --> Total execution time: 0.0939
DEBUG - 2023-04-23 16:23:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:53:48 --> Total execution time: 0.1795
DEBUG - 2023-04-23 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:23:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:23:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:23:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:23:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 16:23:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 16:23:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:23:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:23:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:23:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:23:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 16:23:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:23:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:23:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:25:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:25:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:26:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:56:52 --> Total execution time: 0.1243
DEBUG - 2023-04-23 16:26:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:26:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:26:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:26:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:26:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:26:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:26:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:26:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:26:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:26:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:26:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:26:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:26:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:26:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:26:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:26:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:26:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:56:54 --> Total execution time: 0.2043
DEBUG - 2023-04-23 16:27:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:57:35 --> Total execution time: 0.1172
DEBUG - 2023-04-23 16:27:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:57:36 --> Total execution time: 0.1943
DEBUG - 2023-04-23 16:27:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:27:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:27:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:27:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:27:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:27:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:27:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:27:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:27:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 16:27:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:27:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:27:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 16:27:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:27:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:27:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:27:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:27:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:27:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:27:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:27:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:27:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:27:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:28:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:58:24 --> Total execution time: 0.1304
DEBUG - 2023-04-23 16:28:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 19:58:25 --> Total execution time: 0.2131
DEBUG - 2023-04-23 16:28:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:28:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 19:58:47 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 19:58:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 19:58:47 --> Total execution time: 0.1239
DEBUG - 2023-04-23 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:28:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 19:58:47 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 19:58:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 19:58:47 --> Total execution time: 0.2231
DEBUG - 2023-04-23 16:30:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:30:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:00:26 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 20:00:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 20:00:26 --> Total execution time: 0.1175
DEBUG - 2023-04-23 16:30:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:30:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:00:27 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 20:00:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 20:00:27 --> Total execution time: 0.1816
DEBUG - 2023-04-23 16:30:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:30:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:00:49 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 20:00:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 20:00:49 --> Total execution time: 0.1100
DEBUG - 2023-04-23 16:30:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:30:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:00:49 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 20:00:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 20:00:49 --> Total execution time: 0.1737
DEBUG - 2023-04-23 16:32:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:32:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:02:20 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 20:02:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 20:02:20 --> Total execution time: 0.1212
DEBUG - 2023-04-23 16:32:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:32:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:02:21 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 20:02:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 20:02:21 --> Total execution time: 0.2438
DEBUG - 2023-04-23 16:32:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:32:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:02:42 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 20:02:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 20:02:42 --> Total execution time: 0.1141
DEBUG - 2023-04-23 16:32:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:32:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:02:43 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 20:02:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 20:02:43 --> Total execution time: 0.2676
DEBUG - 2023-04-23 16:32:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:32:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:02:49 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 20:02:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 20:02:49 --> Total execution time: 0.1209
DEBUG - 2023-04-23 16:32:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:32:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:02:49 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 20:02:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 20:02:50 --> Total execution time: 0.2518
DEBUG - 2023-04-23 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:34:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:04:13 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 20:04:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 20:04:13 --> Total execution time: 0.1296
DEBUG - 2023-04-23 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:34:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:04:13 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
ERROR - 2023-04-23 20:04:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 137
DEBUG - 2023-04-23 20:04:13 --> Total execution time: 0.1765
DEBUG - 2023-04-23 16:36:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:36:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:06:07 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 136
ERROR - 2023-04-23 20:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 136
DEBUG - 2023-04-23 20:06:07 --> Total execution time: 0.1405
DEBUG - 2023-04-23 16:36:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:36:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:06:07 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 136
ERROR - 2023-04-23 20:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 136
DEBUG - 2023-04-23 20:06:07 --> Total execution time: 0.1975
DEBUG - 2023-04-23 16:36:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:06:33 --> Total execution time: 0.1301
DEBUG - 2023-04-23 16:36:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:06:34 --> Total execution time: 0.1995
DEBUG - 2023-04-23 16:37:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:07:43 --> Total execution time: 0.1284
DEBUG - 2023-04-23 16:37:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:07:43 --> Total execution time: 0.1743
DEBUG - 2023-04-23 16:39:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:39:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:09:56 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 166
ERROR - 2023-04-23 20:09:56 --> Severity: Notice --> Trying to get property 'p_gallery_image' of non-object C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 166
DEBUG - 2023-04-23 20:09:56 --> Total execution time: 0.1273
DEBUG - 2023-04-23 16:39:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:39:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 20:09:57 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 166
ERROR - 2023-04-23 20:09:57 --> Severity: Notice --> Trying to get property 'p_gallery_image' of non-object C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\car\car_edit.php 166
DEBUG - 2023-04-23 20:09:57 --> Total execution time: 0.2389
DEBUG - 2023-04-23 16:40:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:10:55 --> Total execution time: 0.1346
DEBUG - 2023-04-23 16:40:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:10:56 --> Total execution time: 0.1971
DEBUG - 2023-04-23 16:41:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:11:58 --> Total execution time: 0.1300
DEBUG - 2023-04-23 16:41:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:11:58 --> Total execution time: 0.1930
DEBUG - 2023-04-23 16:43:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:13:31 --> Total execution time: 0.1391
DEBUG - 2023-04-23 16:43:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:13:32 --> Total execution time: 0.2116
DEBUG - 2023-04-23 16:43:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:13:35 --> Total execution time: 0.1199
DEBUG - 2023-04-23 16:43:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:13:37 --> Total execution time: 0.1514
DEBUG - 2023-04-23 16:43:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:43:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:43:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:43:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:43:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:39 --> UTF-8 Support Enabled
ERROR - 2023-04-23 16:43:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:43:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:43:39 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 16:43:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:43:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:43:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:43:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:43:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:43:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:43:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:13:46 --> Total execution time: 0.1576
DEBUG - 2023-04-23 16:43:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:43:47 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 16:43:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:43:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:43:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:43:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:43:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:43:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:43:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:43:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:43:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:43:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:43:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:43:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:43:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:43:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:13:48 --> Total execution time: 0.2486
DEBUG - 2023-04-23 16:43:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:13:55 --> Total execution time: 0.1272
DEBUG - 2023-04-23 16:43:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:13:56 --> Total execution time: 0.1955
DEBUG - 2023-04-23 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:14:45 --> Total execution time: 0.1309
DEBUG - 2023-04-23 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:14:45 --> Total execution time: 0.1917
DEBUG - 2023-04-23 16:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:14:50 --> Total execution time: 0.1212
DEBUG - 2023-04-23 16:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:14:51 --> Total execution time: 0.1871
DEBUG - 2023-04-23 16:46:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:16:18 --> Total execution time: 0.1284
DEBUG - 2023-04-23 16:46:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:16:18 --> Total execution time: 0.1869
DEBUG - 2023-04-23 16:48:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:18:25 --> Total execution time: 0.1346
DEBUG - 2023-04-23 16:48:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:18:26 --> Total execution time: 0.1975
DEBUG - 2023-04-23 16:48:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:48:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:48:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:48:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:48:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:48:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:48:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:48:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:48:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:48:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:48:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:48:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:48:30 --> UTF-8 Support Enabled
ERROR - 2023-04-23 16:48:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:48:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:48:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:49:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:19:00 --> Total execution time: 0.1242
DEBUG - 2023-04-23 16:49:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:19:01 --> Total execution time: 0.1762
DEBUG - 2023-04-23 16:49:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:19:03 --> Total execution time: 0.1382
DEBUG - 2023-04-23 16:49:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:19:04 --> Total execution time: 0.1788
DEBUG - 2023-04-23 16:49:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:49:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:49:18 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 16:49:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:19:19 --> Total execution time: 0.1263
DEBUG - 2023-04-23 16:49:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:19:20 --> Total execution time: 0.2090
DEBUG - 2023-04-23 16:49:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:19:58 --> Total execution time: 0.1281
DEBUG - 2023-04-23 16:49:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:19:59 --> Total execution time: 0.2337
DEBUG - 2023-04-23 16:50:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:20:01 --> Total execution time: 0.1383
DEBUG - 2023-04-23 16:50:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:20:02 --> Total execution time: 0.1881
DEBUG - 2023-04-23 16:50:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:50:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 16:50:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:50:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:50:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:50:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:50:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:50:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:50:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 16:50:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 16:50:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:50:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:20:37 --> Total execution time: 0.1299
DEBUG - 2023-04-23 16:50:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:50:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:50:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:50:37 --> UTF-8 Support Enabled
ERROR - 2023-04-23 16:50:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:50:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:50:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:50:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:50:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:50:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:50:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:50:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:50:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:50:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:50:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:50:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:50:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:50:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 16:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:20:38 --> Total execution time: 0.2269
DEBUG - 2023-04-23 16:52:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:22:25 --> Total execution time: 0.1302
DEBUG - 2023-04-23 16:52:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:22:26 --> Total execution time: 0.2343
DEBUG - 2023-04-23 16:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:53:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:23:29 --> Total execution time: 0.1306
DEBUG - 2023-04-23 16:53:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:23:29 --> Total execution time: 0.2083
DEBUG - 2023-04-23 16:54:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:24:54 --> Total execution time: 0.1320
DEBUG - 2023-04-23 16:54:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:24:55 --> Total execution time: 0.3074
DEBUG - 2023-04-23 16:54:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:54:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:54:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:54:56 --> 404 Page Not Found: admin/Car/update
DEBUG - 2023-04-23 16:54:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:24:57 --> Total execution time: 0.1519
DEBUG - 2023-04-23 16:54:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:24:58 --> Total execution time: 0.2849
DEBUG - 2023-04-23 16:55:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:25:28 --> Total execution time: 0.1583
DEBUG - 2023-04-23 16:55:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:25:29 --> Total execution time: 0.2093
DEBUG - 2023-04-23 16:55:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:55:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:55:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:55:31 --> 404 Page Not Found: admin/Car/update
DEBUG - 2023-04-23 16:56:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 16:56:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:26:41 --> Total execution time: 0.1250
DEBUG - 2023-04-23 16:56:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:26:42 --> Total execution time: 0.1819
DEBUG - 2023-04-23 16:56:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:26:56 --> Total execution time: 0.1309
DEBUG - 2023-04-23 16:56:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:26:56 --> Total execution time: 0.2587
DEBUG - 2023-04-23 16:56:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:26:58 --> Total execution time: 0.1212
DEBUG - 2023-04-23 16:56:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:56:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 16:56:58 --> 404 Page Not Found: admin/Car/update
DEBUG - 2023-04-23 16:57:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:27:00 --> Total execution time: 0.1536
DEBUG - 2023-04-23 16:57:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 16:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 16:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 16:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:27:01 --> Total execution time: 0.3487
DEBUG - 2023-04-23 17:08:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:38:51 --> Total execution time: 0.1278
DEBUG - 2023-04-23 17:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:38:52 --> Total execution time: 0.2472
DEBUG - 2023-04-23 17:08:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:38:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:38:54 --> You did not select a file to upload.
ERROR - 2023-04-23 20:38:54 --> Severity: Notice --> Undefined variable: exist C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 164
ERROR - 2023-04-23 20:38:54 --> Severity: Notice --> Trying to get property 'car_thmb_image' of non-object C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 164
DEBUG - 2023-04-23 20:38:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:38:54 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:38:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:38:54 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:38:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:38:54 --> You did not select a file to upload.
ERROR - 2023-04-23 20:38:54 --> Severity: Notice --> Undefined variable: exist C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 190
ERROR - 2023-04-23 20:38:54 --> Severity: Notice --> Trying to get property 'car_gallery_image' of non-object C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 190
ERROR - 2023-04-23 20:38:54 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:08:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:38:54 --> Total execution time: 0.1192
DEBUG - 2023-04-23 17:08:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:38:54 --> Total execution time: 0.1967
DEBUG - 2023-04-23 17:10:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:40:41 --> Upload class already loaded. Second attempt ignored.
ERROR - 2023-04-23 20:40:41 --> Severity: Notice --> Undefined variable: exist C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 160
ERROR - 2023-04-23 20:40:41 --> Severity: Notice --> Trying to get property 'car_thmb_image_path' of non-object C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 160
ERROR - 2023-04-23 20:40:41 --> Severity: Notice --> Undefined variable: exist C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 160
ERROR - 2023-04-23 20:40:41 --> Severity: Notice --> Trying to get property 'car_thmb_image' of non-object C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 160
DEBUG - 2023-04-23 20:40:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:40:41 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:40:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:40:41 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:40:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:40:41 --> You did not select a file to upload.
ERROR - 2023-04-23 20:40:41 --> Severity: Notice --> Undefined variable: exist C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 190
ERROR - 2023-04-23 20:40:41 --> Severity: Notice --> Trying to get property 'car_gallery_image' of non-object C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 190
ERROR - 2023-04-23 20:40:41 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
ERROR - 2023-04-23 20:40:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\dinesh\car_rental\system\core\Exceptions.php:271) C:\xampp\htdocs\dinesh\car_rental\system\helpers\url_helper.php 564
DEBUG - 2023-04-23 17:10:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:10:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:10:41 --> 404 Page Not Found: admin/Car/update
DEBUG - 2023-04-23 17:11:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:41:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:41:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:41:49 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:41:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:41:49 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:41:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:41:49 --> You did not select a file to upload.
ERROR - 2023-04-23 20:41:49 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:11:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:41:49 --> Total execution time: 0.1345
DEBUG - 2023-04-23 17:11:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:41:50 --> Total execution time: 0.2573
DEBUG - 2023-04-23 17:11:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:41:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:41:55 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:41:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:41:55 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:41:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:41:55 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:41:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:41:55 --> You did not select a file to upload.
ERROR - 2023-04-23 20:41:55 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:11:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:41:55 --> Total execution time: 0.1234
DEBUG - 2023-04-23 17:11:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:41:55 --> Total execution time: 0.1716
DEBUG - 2023-04-23 17:11:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:41:57 --> Total execution time: 0.1312
DEBUG - 2023-04-23 17:11:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:41:58 --> Total execution time: 0.2122
DEBUG - 2023-04-23 17:12:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:02 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:42:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:02 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:42:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:02 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:42:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:02 --> You did not select a file to upload.
ERROR - 2023-04-23 20:42:02 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:12:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:02 --> Total execution time: 0.1154
DEBUG - 2023-04-23 17:12:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:03 --> Total execution time: 0.1767
DEBUG - 2023-04-23 17:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:15 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:42:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:15 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:42:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:15 --> You did not select a file to upload.
ERROR - 2023-04-23 20:42:15 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:15 --> Total execution time: 0.1139
DEBUG - 2023-04-23 17:12:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:16 --> Total execution time: 0.1781
DEBUG - 2023-04-23 17:12:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:22 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:42:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:22 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:42:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:22 --> You did not select a file to upload.
ERROR - 2023-04-23 20:42:22 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:12:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:22 --> Total execution time: 0.1234
DEBUG - 2023-04-23 17:12:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:23 --> Total execution time: 0.1742
DEBUG - 2023-04-23 17:12:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:45 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:42:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:45 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:42:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:45 --> You did not select a file to upload.
ERROR - 2023-04-23 20:42:45 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:12:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:45 --> Total execution time: 0.1218
DEBUG - 2023-04-23 17:12:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:45 --> Total execution time: 0.1794
DEBUG - 2023-04-23 17:12:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:51 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:42:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:51 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:42:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:42:51 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:42:51 --> Upload class already loaded. Second attempt ignored.
ERROR - 2023-04-23 20:42:51 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:12:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:51 --> Total execution time: 0.1287
DEBUG - 2023-04-23 17:12:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:42:52 --> Total execution time: 0.1725
DEBUG - 2023-04-23 17:13:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:21 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:21 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:21 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:21 --> You did not select a file to upload.
ERROR - 2023-04-23 20:43:21 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:13:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:21 --> Total execution time: 0.1183
DEBUG - 2023-04-23 17:13:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:22 --> Total execution time: 0.1814
DEBUG - 2023-04-23 17:13:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:27 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:27 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:27 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:27 --> You did not select a file to upload.
ERROR - 2023-04-23 20:43:27 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:13:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:27 --> Total execution time: 0.1088
DEBUG - 2023-04-23 17:13:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:27 --> Total execution time: 0.1719
DEBUG - 2023-04-23 17:13:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:32 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:32 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:32 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:32 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:32 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:32 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:32 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:32 --> You did not select a file to upload.
ERROR - 2023-04-23 20:43:32 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:13:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:33 --> Total execution time: 0.1249
DEBUG - 2023-04-23 17:13:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:33 --> Total execution time: 0.1767
DEBUG - 2023-04-23 17:13:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:38 --> Total execution time: 0.1356
DEBUG - 2023-04-23 17:13:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:39 --> Total execution time: 0.1955
DEBUG - 2023-04-23 17:13:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:44 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:44 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:44 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:44 --> You did not select a file to upload.
ERROR - 2023-04-23 20:43:44 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:13:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:44 --> Total execution time: 0.1159
DEBUG - 2023-04-23 17:13:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:45 --> Total execution time: 0.1799
DEBUG - 2023-04-23 17:13:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:49 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:49 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:49 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:49 --> You did not select a file to upload.
ERROR - 2023-04-23 20:43:49 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:13:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:49 --> Total execution time: 0.1162
DEBUG - 2023-04-23 17:13:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:50 --> Total execution time: 0.1800
DEBUG - 2023-04-23 17:13:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:54 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:54 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:54 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:54 --> You did not select a file to upload.
ERROR - 2023-04-23 20:43:54 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:54 --> Total execution time: 0.1255
DEBUG - 2023-04-23 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:54 --> Total execution time: 0.1747
DEBUG - 2023-04-23 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:57 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:57 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:57 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:57 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:57 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:57 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:43:57 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:43:57 --> You did not select a file to upload.
ERROR - 2023-04-23 20:43:57 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:57 --> Total execution time: 0.1304
DEBUG - 2023-04-23 17:13:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:43:58 --> Total execution time: 0.1865
DEBUG - 2023-04-23 17:14:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:44:01 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:44:01 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:44:01 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:44:01 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:44:01 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:44:01 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:44:01 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:44:01 --> You did not select a file to upload.
ERROR - 2023-04-23 20:44:01 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:14:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:44:01 --> Total execution time: 0.1211
DEBUG - 2023-04-23 17:14:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:44:02 --> Total execution time: 0.1806
DEBUG - 2023-04-23 17:14:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:44:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:44:59 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:44:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:44:59 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:44:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:44:59 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:44:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:44:59 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:44:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:44:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:44:59 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:44:59 --> Upload class already loaded. Second attempt ignored.
ERROR - 2023-04-23 20:44:59 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:14:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:45:00 --> Total execution time: 0.1208
DEBUG - 2023-04-23 17:15:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:45:01 --> Total execution time: 0.2092
DEBUG - 2023-04-23 17:15:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:45:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:09 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:09 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:09 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:09 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:09 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:09 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:09 --> Upload class already loaded. Second attempt ignored.
ERROR - 2023-04-23 20:45:09 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:15:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:45:09 --> Total execution time: 0.1449
DEBUG - 2023-04-23 17:15:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:45:11 --> Total execution time: 0.1921
DEBUG - 2023-04-23 17:15:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:45:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:25 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:25 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:25 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:25 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:25 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:25 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:25 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:25 --> Upload class already loaded. Second attempt ignored.
ERROR - 2023-04-23 20:45:26 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:15:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:45:26 --> Total execution time: 0.1145
DEBUG - 2023-04-23 17:15:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:45:28 --> Total execution time: 0.1914
DEBUG - 2023-04-23 17:15:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:45:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:40 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:40 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:40 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:40 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:40 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:40 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:40 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:40 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:45:40 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:45:40 --> Upload class already loaded. Second attempt ignored.
ERROR - 2023-04-23 20:45:40 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 231
DEBUG - 2023-04-23 17:15:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:45:41 --> Total execution time: 0.1191
DEBUG - 2023-04-23 17:15:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:45:43 --> Total execution time: 0.2036
DEBUG - 2023-04-23 17:16:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:46:18 --> Total execution time: 0.1269
DEBUG - 2023-04-23 17:16:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:46:21 --> Total execution time: 0.2358
DEBUG - 2023-04-23 17:16:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:16:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:46:27 --> Total execution time: 0.1091
DEBUG - 2023-04-23 17:16:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:46:29 --> Total execution time: 0.2048
DEBUG - 2023-04-23 17:17:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:47:40 --> Total execution time: 0.1330
DEBUG - 2023-04-23 17:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:47:43 --> Total execution time: 0.1952
DEBUG - 2023-04-23 17:17:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:17:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:47:46 --> Total execution time: 0.1200
DEBUG - 2023-04-23 17:17:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:47:49 --> Total execution time: 0.1970
DEBUG - 2023-04-23 17:17:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:47:51 --> Total execution time: 0.1218
DEBUG - 2023-04-23 17:17:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:47:54 --> Total execution time: 0.2040
DEBUG - 2023-04-23 17:17:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:17:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 17:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:17:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 17:17:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 17:17:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:17:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 17:17:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 17:17:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:17:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 17:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:17:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 17:17:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 17:18:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:48:08 --> Total execution time: 0.1258
DEBUG - 2023-04-23 17:18:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:48:11 --> Total execution time: 0.3859
DEBUG - 2023-04-23 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:48:49 --> Total execution time: 0.1121
DEBUG - 2023-04-23 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:48:50 --> Total execution time: 0.1824
DEBUG - 2023-04-23 17:18:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:48:51 --> Total execution time: 0.1057
DEBUG - 2023-04-23 17:18:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:48:52 --> Total execution time: 0.1541
DEBUG - 2023-04-23 17:19:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:49:01 --> Total execution time: 0.1271
DEBUG - 2023-04-23 17:19:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:49:02 --> Total execution time: 0.1873
DEBUG - 2023-04-23 17:23:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:53:25 --> Total execution time: 0.1221
DEBUG - 2023-04-23 17:23:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:53:26 --> Total execution time: 0.1874
DEBUG - 2023-04-23 17:24:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:54:01 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:54:01 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2023-04-23 17:24:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:54:01 --> Total execution time: 0.1639
DEBUG - 2023-04-23 17:24:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:54:39 --> Total execution time: 0.1245
DEBUG - 2023-04-23 17:24:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:54:40 --> Total execution time: 0.2109
DEBUG - 2023-04-23 17:26:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:56:45 --> Total execution time: 0.1203
DEBUG - 2023-04-23 17:26:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:56:46 --> Total execution time: 0.1708
DEBUG - 2023-04-23 17:26:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:56:50 --> Total execution time: 0.1290
DEBUG - 2023-04-23 17:26:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:56:51 --> Total execution time: 0.1800
DEBUG - 2023-04-23 17:26:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:56:54 --> Total execution time: 0.1285
DEBUG - 2023-04-23 17:26:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:56:57 --> Total execution time: 0.1990
DEBUG - 2023-04-23 17:26:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:56:58 --> Total execution time: 0.1310
DEBUG - 2023-04-23 17:26:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:56:58 --> Total execution time: 0.1747
DEBUG - 2023-04-23 17:27:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:57:01 --> Total execution time: 0.1377
DEBUG - 2023-04-23 17:27:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:57:03 --> Total execution time: 0.2094
DEBUG - 2023-04-23 17:27:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:57:04 --> Total execution time: 0.1220
DEBUG - 2023-04-23 17:27:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:57:04 --> Total execution time: 0.1664
DEBUG - 2023-04-23 17:27:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:57:08 --> Total execution time: 0.1355
DEBUG - 2023-04-23 17:27:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:57:10 --> Total execution time: 0.1781
DEBUG - 2023-04-23 17:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:57:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:57:15 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:57:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:57:15 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:57:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:57:15 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:57:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:57:15 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:57:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:57:15 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:57:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:57:15 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:57:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:57:15 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:57:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:57:15 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:57:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:57:15 --> You did not select a file to upload.
ERROR - 2023-04-23 20:57:15 --> Severity: Notice --> Undefined variable: updateCond C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 249
DEBUG - 2023-04-23 17:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:57:15 --> Total execution time: 0.1299
DEBUG - 2023-04-23 17:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:27:15 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 17:27:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:57:17 --> Total execution time: 0.2220
DEBUG - 2023-04-23 17:27:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:57:25 --> Total execution time: 0.1252
DEBUG - 2023-04-23 17:27:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:27:25 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 17:27:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:57:25 --> Total execution time: 0.2534
DEBUG - 2023-04-23 17:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:57:57 --> Total execution time: 0.1295
DEBUG - 2023-04-23 17:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:27:57 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 17:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:57:57 --> Total execution time: 0.1803
DEBUG - 2023-04-23 17:27:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:57:59 --> Total execution time: 0.1481
DEBUG - 2023-04-23 17:27:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:27:59 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 17:28:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:58:00 --> Total execution time: 0.1567
DEBUG - 2023-04-23 17:28:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:58:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:17 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:58:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:17 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:58:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:17 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:58:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:17 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:58:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:17 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:58:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:17 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:58:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:17 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:58:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:17 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:58:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:17 --> You did not select a file to upload.
DEBUG - 2023-04-23 17:28:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:58:17 --> Total execution time: 0.1339
DEBUG - 2023-04-23 17:28:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:58:19 --> Total execution time: 0.2159
DEBUG - 2023-04-23 17:28:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:58:22 --> Total execution time: 0.1132
DEBUG - 2023-04-23 17:28:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:58:22 --> Total execution time: 0.2147
DEBUG - 2023-04-23 17:28:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:58:23 --> Total execution time: 0.1277
DEBUG - 2023-04-23 17:28:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:28:23 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 17:28:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:58:24 --> Total execution time: 0.2799
DEBUG - 2023-04-23 17:28:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:58:27 --> Total execution time: 0.1334
DEBUG - 2023-04-23 17:28:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:28:28 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 17:28:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:58:30 --> Total execution time: 0.1823
DEBUG - 2023-04-23 17:28:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:58:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:45 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:58:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:45 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:58:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:45 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:58:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:58:45 --> You did not select a file to upload.
DEBUG - 2023-04-23 17:28:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:58:45 --> Total execution time: 0.1180
DEBUG - 2023-04-23 17:28:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:58:46 --> Total execution time: 0.1826
DEBUG - 2023-04-23 17:29:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:29:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:59:06 --> Total execution time: 0.1200
DEBUG - 2023-04-23 17:29:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:29:06 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 17:29:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:59:07 --> Total execution time: 0.1830
DEBUG - 2023-04-23 17:29:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:59:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 17:29:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:59:20 --> Total execution time: 0.1376
DEBUG - 2023-04-23 17:29:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:59:21 --> Total execution time: 0.2055
DEBUG - 2023-04-23 17:29:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:59:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:59:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 17:29:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:59:31 --> Total execution time: 0.1254
DEBUG - 2023-04-23 17:29:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:29:31 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 17:29:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:59:32 --> Total execution time: 0.2237
DEBUG - 2023-04-23 17:29:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:59:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:59:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:59:44 --> You did not select a file to upload.
DEBUG - 2023-04-23 20:59:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 20:59:44 --> You did not select a file to upload.
DEBUG - 2023-04-23 17:29:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:59:44 --> Total execution time: 0.1155
DEBUG - 2023-04-23 17:29:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:59:45 --> Total execution time: 0.1592
DEBUG - 2023-04-23 17:29:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:59:47 --> Total execution time: 0.1187
DEBUG - 2023-04-23 17:29:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 20:59:48 --> Total execution time: 0.1979
DEBUG - 2023-04-23 17:31:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:12 --> Total execution time: 0.1309
DEBUG - 2023-04-23 17:31:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:12 --> Total execution time: 0.1997
DEBUG - 2023-04-23 17:31:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:01:17 --> You did not select a file to upload.
DEBUG - 2023-04-23 21:01:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:01:17 --> You did not select a file to upload.
DEBUG - 2023-04-23 17:31:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:17 --> Total execution time: 0.1085
DEBUG - 2023-04-23 17:31:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:18 --> Total execution time: 0.2164
DEBUG - 2023-04-23 17:31:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:01:20 --> You did not select a file to upload.
DEBUG - 2023-04-23 21:01:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:01:20 --> You did not select a file to upload.
DEBUG - 2023-04-23 17:31:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:20 --> Total execution time: 0.1159
DEBUG - 2023-04-23 17:31:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:21 --> Total execution time: 0.1651
DEBUG - 2023-04-23 17:31:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:01:24 --> You did not select a file to upload.
DEBUG - 2023-04-23 17:31:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:24 --> Total execution time: 0.1196
DEBUG - 2023-04-23 17:31:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:25 --> Total execution time: 0.1911
DEBUG - 2023-04-23 17:31:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:01:35 --> You did not select a file to upload.
DEBUG - 2023-04-23 21:01:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:01:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 17:31:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:35 --> Total execution time: 0.1183
DEBUG - 2023-04-23 17:31:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:35 --> Total execution time: 0.1559
DEBUG - 2023-04-23 17:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:01:41 --> You did not select a file to upload.
DEBUG - 2023-04-23 17:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:41 --> Total execution time: 0.1166
DEBUG - 2023-04-23 17:31:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:42 --> Total execution time: 0.1900
DEBUG - 2023-04-23 17:31:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:45 --> Total execution time: 0.1695
DEBUG - 2023-04-23 17:31:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:46 --> Total execution time: 0.1806
DEBUG - 2023-04-23 17:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:48 --> Total execution time: 0.1509
DEBUG - 2023-04-23 17:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:31:48 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 17:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:31:48 --> 404 Page Not Found: Assets/uploads
ERROR - 2023-04-23 17:31:48 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 17:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:31:48 --> 404 Page Not Found: Assets/uploads
ERROR - 2023-04-23 17:31:48 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 17:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:31:48 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 17:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:48 --> UTF-8 Support Enabled
ERROR - 2023-04-23 17:31:48 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 17:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:31:49 --> 404 Page Not Found: Assets/uploads
ERROR - 2023-04-23 17:31:49 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-04-23 17:31:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:01:49 --> Total execution time: 0.2094
DEBUG - 2023-04-23 17:32:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:32:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:02:06 --> Total execution time: 0.1156
DEBUG - 2023-04-23 17:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:02:07 --> Total execution time: 0.2071
DEBUG - 2023-04-23 17:32:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:02:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:02:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:02:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 17:32:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:02:22 --> Total execution time: 0.1224
DEBUG - 2023-04-23 17:32:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:02:23 --> Total execution time: 0.2390
DEBUG - 2023-04-23 17:32:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:02:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:02:27 --> You did not select a file to upload.
DEBUG - 2023-04-23 21:02:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:02:27 --> You did not select a file to upload.
DEBUG - 2023-04-23 17:32:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:02:28 --> Total execution time: 0.1120
DEBUG - 2023-04-23 17:32:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:02:28 --> Total execution time: 0.1963
DEBUG - 2023-04-23 17:32:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:02:33 --> Total execution time: 0.1179
DEBUG - 2023-04-23 17:32:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:02:33 --> Total execution time: 0.1914
DEBUG - 2023-04-23 17:32:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:02:36 --> Total execution time: 0.1311
DEBUG - 2023-04-23 17:32:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:02:36 --> Total execution time: 0.1962
DEBUG - 2023-04-23 17:32:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:02:43 --> Total execution time: 0.0969
DEBUG - 2023-04-23 17:32:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:02:43 --> Total execution time: 0.2065
DEBUG - 2023-04-23 17:33:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:33:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:03:38 --> Total execution time: 0.0972
DEBUG - 2023-04-23 17:33:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:03:38 --> Total execution time: 0.1689
DEBUG - 2023-04-23 17:33:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:03:40 --> Total execution time: 0.1264
DEBUG - 2023-04-23 17:33:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:03:41 --> Total execution time: 0.2093
DEBUG - 2023-04-23 17:33:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:03:43 --> Total execution time: 0.1428
DEBUG - 2023-04-23 17:33:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:03:44 --> Total execution time: 0.1972
DEBUG - 2023-04-23 17:33:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:03:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 17:33:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:03:51 --> Total execution time: 0.1156
DEBUG - 2023-04-23 17:33:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:03:51 --> Total execution time: 0.2042
DEBUG - 2023-04-23 17:34:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:04:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:04:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 17:34:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:04:05 --> Total execution time: 0.1284
DEBUG - 2023-04-23 17:34:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:04:06 --> Total execution time: 0.2549
DEBUG - 2023-04-23 17:34:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:04:15 --> Total execution time: 0.1244
DEBUG - 2023-04-23 17:34:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:04:16 --> Total execution time: 0.1865
DEBUG - 2023-04-23 17:34:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:04:20 --> Total execution time: 0.1511
DEBUG - 2023-04-23 17:34:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:04:20 --> Total execution time: 0.1935
DEBUG - 2023-04-23 17:34:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:04:31 --> Total execution time: 0.1236
DEBUG - 2023-04-23 17:34:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:04:32 --> Total execution time: 0.2212
DEBUG - 2023-04-23 17:37:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:07:39 --> Total execution time: 0.1490
DEBUG - 2023-04-23 17:37:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:07:40 --> Total execution time: 0.2104
DEBUG - 2023-04-23 17:37:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:37:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:37:41 --> 404 Page Not Found: admin/Car/delete
DEBUG - 2023-04-23 17:37:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:37:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:37:41 --> 404 Page Not Found: admin/Car/delete
DEBUG - 2023-04-23 17:37:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:07:43 --> Total execution time: 0.1574
DEBUG - 2023-04-23 17:37:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:07:43 --> Total execution time: 0.2125
DEBUG - 2023-04-23 17:38:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:08:25 --> Total execution time: 0.1506
DEBUG - 2023-04-23 17:38:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:08:25 --> Total execution time: 0.2343
DEBUG - 2023-04-23 17:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:38:30 --> 404 Page Not Found: admin/Car/delete
DEBUG - 2023-04-23 17:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 17:38:30 --> 404 Page Not Found: admin/Car/delete
DEBUG - 2023-04-23 17:43:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:13:25 --> Total execution time: 0.1197
DEBUG - 2023-04-23 17:43:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:13:25 --> Total execution time: 0.1771
DEBUG - 2023-04-23 17:49:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:49:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 21:19:41 --> Severity: Notice --> Undefined variable: car_gallery_image C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 272
ERROR - 2023-04-23 21:19:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 272
ERROR - 2023-04-23 21:19:41 --> Severity: Notice --> Undefined variable: car_gallery_image C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 272
ERROR - 2023-04-23 21:19:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 272
DEBUG - 2023-04-23 17:49:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:19:41 --> Total execution time: 0.1332
DEBUG - 2023-04-23 17:49:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:19:42 --> Total execution time: 0.1936
DEBUG - 2023-04-23 17:49:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:49:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 21:19:45 --> Severity: Notice --> Undefined variable: car_gallery_image C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 272
ERROR - 2023-04-23 21:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 272
ERROR - 2023-04-23 21:19:45 --> Severity: Notice --> Undefined variable: car_gallery_image C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 272
ERROR - 2023-04-23 21:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 272
DEBUG - 2023-04-23 17:49:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:19:45 --> Total execution time: 0.1607
DEBUG - 2023-04-23 17:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:19:46 --> Total execution time: 0.1774
DEBUG - 2023-04-23 17:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:49:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 21:19:48 --> Severity: Notice --> Undefined variable: car_gallery_image C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 272
ERROR - 2023-04-23 21:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 272
DEBUG - 2023-04-23 17:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:19:48 --> Total execution time: 0.1100
DEBUG - 2023-04-23 17:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:19:48 --> Total execution time: 0.1683
DEBUG - 2023-04-23 17:50:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:20:32 --> Total execution time: 0.1028
DEBUG - 2023-04-23 17:50:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:20:33 --> Total execution time: 0.2059
DEBUG - 2023-04-23 17:51:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:21:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:21:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:21:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 17:51:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:21:19 --> Total execution time: 0.1074
DEBUG - 2023-04-23 17:51:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:21:19 --> Total execution time: 0.2133
DEBUG - 2023-04-23 17:51:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:21:21 --> Total execution time: 0.1074
DEBUG - 2023-04-23 17:51:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:21:22 --> Total execution time: 0.2246
DEBUG - 2023-04-23 17:51:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:51:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 21:21:27 --> Severity: Notice --> Undefined variable: car_gallery_image C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 272
ERROR - 2023-04-23 21:21:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 272
ERROR - 2023-04-23 21:21:27 --> Severity: Notice --> Undefined variable: car_gallery_image C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 272
ERROR - 2023-04-23 21:21:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Car_Crud.php 272
DEBUG - 2023-04-23 17:51:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:21:28 --> Total execution time: 0.0994
DEBUG - 2023-04-23 17:51:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:21:28 --> Total execution time: 0.1779
DEBUG - 2023-04-23 17:51:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:21:46 --> Total execution time: 0.1027
DEBUG - 2023-04-23 17:51:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:21:46 --> Total execution time: 0.1947
DEBUG - 2023-04-23 17:51:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:21:48 --> Total execution time: 0.1192
DEBUG - 2023-04-23 17:51:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:21:49 --> Total execution time: 0.2137
DEBUG - 2023-04-23 17:51:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:21:54 --> Total execution time: 0.1138
DEBUG - 2023-04-23 17:51:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:21:55 --> Total execution time: 0.1663
DEBUG - 2023-04-23 17:55:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:25:39 --> Total execution time: 0.1176
DEBUG - 2023-04-23 17:55:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:25:39 --> Total execution time: 0.1650
DEBUG - 2023-04-23 17:55:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:55:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 21:25:42 --> Severity: Notice --> Undefined property: Category_Crud::$Cars C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Category_Crud.php 161
ERROR - 2023-04-23 21:25:42 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Category_Crud.php 161
DEBUG - 2023-04-23 17:55:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:55:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 21:25:42 --> Severity: Notice --> Undefined property: Category_Crud::$Cars C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Category_Crud.php 161
ERROR - 2023-04-23 21:25:42 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\dinesh\car_rental\application\controllers\Admin\Category_Crud.php 161
DEBUG - 2023-04-23 17:55:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:55:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:25:52 --> Total execution time: 0.1029
DEBUG - 2023-04-23 17:55:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:25:53 --> Total execution time: 0.1764
DEBUG - 2023-04-23 17:55:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:55:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:25:59 --> Total execution time: 0.1007
DEBUG - 2023-04-23 17:55:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:25:59 --> Total execution time: 0.1634
DEBUG - 2023-04-23 17:56:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 17:56:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:26:01 --> Total execution time: 0.1074
DEBUG - 2023-04-23 17:56:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:26:01 --> Total execution time: 0.1567
DEBUG - 2023-04-23 17:56:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:26:12 --> Total execution time: 0.1614
DEBUG - 2023-04-23 17:56:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:26:13 --> Total execution time: 0.1773
DEBUG - 2023-04-23 17:58:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:28:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 17:58:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:28:23 --> Total execution time: 0.1035
DEBUG - 2023-04-23 17:58:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:28:24 --> Total execution time: 0.1608
DEBUG - 2023-04-23 17:59:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:29:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 17:59:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:29:24 --> Total execution time: 0.0986
DEBUG - 2023-04-23 17:59:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:29:24 --> Total execution time: 0.1607
DEBUG - 2023-04-23 17:59:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:29:26 --> Total execution time: 0.1106
DEBUG - 2023-04-23 17:59:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:29:26 --> Total execution time: 0.2254
DEBUG - 2023-04-23 17:59:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:29:30 --> Total execution time: 0.1056
DEBUG - 2023-04-23 17:59:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:29:30 --> Total execution time: 0.1869
DEBUG - 2023-04-23 17:59:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:29:41 --> Total execution time: 0.0984
DEBUG - 2023-04-23 17:59:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:29:41 --> Total execution time: 0.1925
DEBUG - 2023-04-23 17:59:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:29:45 --> Total execution time: 0.0956
DEBUG - 2023-04-23 17:59:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:29:46 --> Total execution time: 0.1988
DEBUG - 2023-04-23 17:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:29:47 --> Total execution time: 0.1194
DEBUG - 2023-04-23 17:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 17:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 17:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 17:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:29:48 --> Total execution time: 0.1927
DEBUG - 2023-04-23 18:03:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:33:13 --> Total execution time: 0.1419
DEBUG - 2023-04-23 18:03:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:33:14 --> Total execution time: 0.2292
DEBUG - 2023-04-23 18:03:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 18:03:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:33:18 --> Total execution time: 0.0960
DEBUG - 2023-04-23 18:03:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:33:18 --> Total execution time: 0.1549
DEBUG - 2023-04-23 18:03:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:33:21 --> Total execution time: 0.1033
DEBUG - 2023-04-23 18:03:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:33:21 --> Total execution time: 0.1802
DEBUG - 2023-04-23 18:06:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:36:36 --> Total execution time: 0.1049
DEBUG - 2023-04-23 18:06:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:36:37 --> Total execution time: 0.1828
DEBUG - 2023-04-23 18:06:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:36:39 --> Total execution time: 0.1256
DEBUG - 2023-04-23 18:06:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:36:39 --> Total execution time: 0.1764
DEBUG - 2023-04-23 18:06:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:36:48 --> Total execution time: 0.0994
DEBUG - 2023-04-23 18:06:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:36:48 --> Total execution time: 0.1724
DEBUG - 2023-04-23 18:07:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:37:07 --> Total execution time: 0.1533
DEBUG - 2023-04-23 18:07:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:37:08 --> Total execution time: 0.1468
DEBUG - 2023-04-23 18:07:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:07:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:07:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:07:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:07:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:07:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:07:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:07:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:07:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:07:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:07:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:07:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:07:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:07:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:07:11 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 18:07:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:07:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:37:21 --> Total execution time: 0.1053
DEBUG - 2023-04-23 18:07:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:37:21 --> Total execution time: 0.1482
DEBUG - 2023-04-23 18:08:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:38:00 --> Total execution time: 0.1231
DEBUG - 2023-04-23 18:08:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:38:00 --> Total execution time: 0.1836
DEBUG - 2023-04-23 18:08:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:38:08 --> Total execution time: 0.1060
DEBUG - 2023-04-23 18:08:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:38:08 --> Total execution time: 0.1446
DEBUG - 2023-04-23 18:10:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:40:01 --> Total execution time: 0.1099
DEBUG - 2023-04-23 18:10:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:40:02 --> Total execution time: 0.1542
DEBUG - 2023-04-23 18:10:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:40:57 --> Total execution time: 0.1553
DEBUG - 2023-04-23 18:10:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:40:58 --> Total execution time: 0.1208
DEBUG - 2023-04-23 18:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:11:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:11:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:11:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:11:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:11:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:11:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:11:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:11:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:11:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:41:12 --> Total execution time: 0.1055
DEBUG - 2023-04-23 18:11:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:41:12 --> Total execution time: 0.1540
DEBUG - 2023-04-23 18:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:41:38 --> Total execution time: 0.1031
DEBUG - 2023-04-23 18:11:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:41:38 --> Total execution time: 0.1705
DEBUG - 2023-04-23 18:12:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:42:07 --> Total execution time: 0.1167
DEBUG - 2023-04-23 18:12:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:12:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:12:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:12:08 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 18:12:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:12:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:12:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:12:08 --> UTF-8 Support Enabled
ERROR - 2023-04-23 18:12:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:12:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:12:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:12:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:12:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:12:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:12:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:12:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:12:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:42:09 --> Total execution time: 0.2067
DEBUG - 2023-04-23 18:12:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:42:10 --> Total execution time: 0.1330
DEBUG - 2023-04-23 18:12:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:42:10 --> Total execution time: 0.1995
DEBUG - 2023-04-23 18:13:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:43:02 --> Total execution time: 0.1090
DEBUG - 2023-04-23 18:13:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:43:02 --> Total execution time: 0.1517
DEBUG - 2023-04-23 18:13:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:43:11 --> Total execution time: 0.1034
DEBUG - 2023-04-23 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:43:11 --> Total execution time: 0.1501
DEBUG - 2023-04-23 18:13:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:43:34 --> Total execution time: 0.1073
DEBUG - 2023-04-23 18:13:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:43:34 --> Total execution time: 0.1550
DEBUG - 2023-04-23 18:15:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:45:07 --> Total execution time: 0.1422
DEBUG - 2023-04-23 18:15:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:45:08 --> Total execution time: 0.1805
DEBUG - 2023-04-23 18:15:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:15:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 18:15:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:45:39 --> Total execution time: 0.1135
DEBUG - 2023-04-23 18:15:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 18:15:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:15:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:45:41 --> Total execution time: 0.3140
DEBUG - 2023-04-23 18:15:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:15:52 --> UTF-8 Support Enabled
ERROR - 2023-04-23 18:15:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 18:15:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:15:52 --> UTF-8 Support Enabled
ERROR - 2023-04-23 18:15:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:15:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:15:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:15:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 18:15:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:16:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:46:12 --> Total execution time: 0.1037
DEBUG - 2023-04-23 18:16:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:46:12 --> Total execution time: 0.1627
DEBUG - 2023-04-23 18:16:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:46:14 --> Total execution time: 0.1107
DEBUG - 2023-04-23 18:16:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:46:14 --> Total execution time: 0.1390
DEBUG - 2023-04-23 18:16:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:46:28 --> Total execution time: 0.1043
DEBUG - 2023-04-23 18:16:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:46:29 --> Total execution time: 0.1390
DEBUG - 2023-04-23 18:16:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:46:42 --> Total execution time: 0.1189
DEBUG - 2023-04-23 18:16:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:46:43 --> Total execution time: 0.1638
DEBUG - 2023-04-23 18:17:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:47:44 --> Total execution time: 0.1030
DEBUG - 2023-04-23 18:17:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:47:45 --> Total execution time: 0.1906
DEBUG - 2023-04-23 18:17:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:47:55 --> Total execution time: 0.1605
DEBUG - 2023-04-23 18:17:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:47:56 --> Total execution time: 0.2272
DEBUG - 2023-04-23 18:18:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:18:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:18:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 18:18:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:18:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:18:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:18:01 --> UTF-8 Support Enabled
ERROR - 2023-04-23 18:18:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:18:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:18:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:18:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:18:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:18:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:18:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 18:18:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:18:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:48:40 --> Total execution time: 0.1119
DEBUG - 2023-04-23 18:18:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:18:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:18:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:18:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:18:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:18:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:18:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:18:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:18:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:18:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:18:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:18:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:18:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:18:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:18:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:18:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:18:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:48:41 --> Total execution time: 0.1757
DEBUG - 2023-04-23 18:18:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:48:42 --> Total execution time: 0.1530
DEBUG - 2023-04-23 18:18:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:48:42 --> Total execution time: 0.1809
DEBUG - 2023-04-23 18:19:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:49:11 --> Total execution time: 0.1064
DEBUG - 2023-04-23 18:19:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:49:11 --> Total execution time: 0.1710
DEBUG - 2023-04-23 18:20:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:50:04 --> Total execution time: 0.1320
DEBUG - 2023-04-23 18:20:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:50:04 --> Total execution time: 0.1917
DEBUG - 2023-04-23 18:20:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:50:31 --> Total execution time: 0.1094
DEBUG - 2023-04-23 18:20:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:50:32 --> Total execution time: 0.1953
DEBUG - 2023-04-23 18:21:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:51:04 --> Total execution time: 0.1022
DEBUG - 2023-04-23 18:21:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:51:05 --> Total execution time: 0.1804
DEBUG - 2023-04-23 18:21:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:21:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:21:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:21:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:21:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:21:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:21:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 18:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:21:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:21:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:21:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:21:18 --> UTF-8 Support Enabled
ERROR - 2023-04-23 18:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:22:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:52:02 --> Total execution time: 0.1118
DEBUG - 2023-04-23 18:22:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:22:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:22:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:22:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 18:22:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:22:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:22:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:22:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:22:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:22:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:22:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:22:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:22:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:22:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:22:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:22:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 18:22:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 18:22:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:52:04 --> Total execution time: 0.1890
DEBUG - 2023-04-23 18:22:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:52:39 --> Total execution time: 0.1093
DEBUG - 2023-04-23 18:22:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:52:40 --> Total execution time: 0.2108
DEBUG - 2023-04-23 18:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:52:43 --> Total execution time: 0.1048
DEBUG - 2023-04-23 18:22:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:52:44 --> Total execution time: 0.2190
DEBUG - 2023-04-23 18:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:52:47 --> Total execution time: 0.1228
DEBUG - 2023-04-23 18:22:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:52:48 --> Total execution time: 0.2092
DEBUG - 2023-04-23 18:24:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:54:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:54:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:54:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 21:54:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-04-23 18:24:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:54:06 --> Total execution time: 0.1059
DEBUG - 2023-04-23 18:24:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:54:06 --> Total execution time: 0.1666
DEBUG - 2023-04-23 18:24:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:54:12 --> Total execution time: 0.1131
DEBUG - 2023-04-23 18:24:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:54:12 --> Total execution time: 0.1749
DEBUG - 2023-04-23 18:24:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:54:18 --> Total execution time: 0.1027
DEBUG - 2023-04-23 18:24:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:54:18 --> Total execution time: 0.1701
DEBUG - 2023-04-23 18:24:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 21:54:21 --> Severity: Notice --> Undefined property: stdClass::$cat_name C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\category\category_details.php 99
DEBUG - 2023-04-23 21:54:21 --> Total execution time: 0.1144
DEBUG - 2023-04-23 18:24:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-04-23 21:54:21 --> Severity: Notice --> Undefined property: stdClass::$cat_name C:\xampp\htdocs\dinesh\car_rental\application\views\Admin\category\category_details.php 99
DEBUG - 2023-04-23 21:54:21 --> Total execution time: 0.1804
DEBUG - 2023-04-23 18:24:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:54:41 --> Total execution time: 0.1051
DEBUG - 2023-04-23 18:24:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:54:41 --> Total execution time: 0.2007
DEBUG - 2023-04-23 18:24:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:54:48 --> Total execution time: 0.1155
DEBUG - 2023-04-23 18:24:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:54:48 --> Total execution time: 0.1805
DEBUG - 2023-04-23 18:24:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:54:52 --> Total execution time: 0.1044
DEBUG - 2023-04-23 18:24:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:54:52 --> Total execution time: 0.1853
DEBUG - 2023-04-23 18:26:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:56:03 --> Total execution time: 0.1172
DEBUG - 2023-04-23 18:26:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:56:03 --> Total execution time: 0.1750
DEBUG - 2023-04-23 18:26:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:56:20 --> Total execution time: 0.1129
DEBUG - 2023-04-23 18:26:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:56:21 --> Total execution time: 0.1712
DEBUG - 2023-04-23 18:26:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:56:30 --> Total execution time: 0.1044
DEBUG - 2023-04-23 18:26:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 21:56:30 --> Total execution time: 0.1926
DEBUG - 2023-04-23 18:56:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:26:59 --> Total execution time: 0.1362
DEBUG - 2023-04-23 18:57:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:27:00 --> Total execution time: 0.1947
DEBUG - 2023-04-23 18:57:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:27:36 --> Total execution time: 0.1005
DEBUG - 2023-04-23 18:57:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:27:36 --> Total execution time: 0.1593
DEBUG - 2023-04-23 18:57:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:27:56 --> Total execution time: 0.1036
DEBUG - 2023-04-23 18:57:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:27:56 --> Total execution time: 0.1918
DEBUG - 2023-04-23 18:58:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:28:15 --> Total execution time: 0.1067
DEBUG - 2023-04-23 18:58:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:28:15 --> Total execution time: 0.1860
DEBUG - 2023-04-23 18:58:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:28:38 --> Total execution time: 0.1047
DEBUG - 2023-04-23 18:58:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:28:38 --> Total execution time: 0.1749
DEBUG - 2023-04-23 18:59:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:29:11 --> Total execution time: 0.1110
DEBUG - 2023-04-23 18:59:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:29:11 --> Total execution time: 0.1821
DEBUG - 2023-04-23 18:59:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:29:18 --> Total execution time: 0.0983
DEBUG - 2023-04-23 18:59:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:29:18 --> Total execution time: 0.1816
DEBUG - 2023-04-23 18:59:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:29:35 --> Total execution time: 0.1069
DEBUG - 2023-04-23 18:59:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:29:35 --> Total execution time: 0.1795
DEBUG - 2023-04-23 18:59:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:29:41 --> Total execution time: 0.1013
DEBUG - 2023-04-23 18:59:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 18:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 18:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 18:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:29:41 --> Total execution time: 0.1700
DEBUG - 2023-04-23 19:01:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 19:01:23 --> 404 Page Not Found: Assets/backend
ERROR - 2023-04-23 19:01:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 19:01:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 19:01:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 19:01:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:01:23 --> UTF-8 Support Enabled
ERROR - 2023-04-23 19:01:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 19:01:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 19:01:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:31:39 --> Total execution time: 0.1021
DEBUG - 2023-04-23 19:01:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 19:01:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 19:01:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 19:01:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 19:01:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 19:01:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 19:01:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 19:01:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-04-23 19:01:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-04-23 19:01:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:31:41 --> Total execution time: 0.2387
DEBUG - 2023-04-23 19:01:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:31:50 --> Total execution time: 0.1004
DEBUG - 2023-04-23 19:01:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:31:50 --> Total execution time: 0.1544
DEBUG - 2023-04-23 19:02:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:04 --> Total execution time: 0.1624
DEBUG - 2023-04-23 19:02:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:05 --> Total execution time: 0.1693
DEBUG - 2023-04-23 19:02:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:07 --> Total execution time: 0.1049
DEBUG - 2023-04-23 19:02:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:07 --> Total execution time: 0.1669
DEBUG - 2023-04-23 19:02:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:11 --> Total execution time: 0.1131
DEBUG - 2023-04-23 19:02:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:12 --> Total execution time: 0.2117
DEBUG - 2023-04-23 19:02:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:13 --> Total execution time: 0.1073
DEBUG - 2023-04-23 19:02:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:13 --> Total execution time: 0.1985
DEBUG - 2023-04-23 19:02:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:14 --> Total execution time: 0.0975
DEBUG - 2023-04-23 19:02:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:15 --> Total execution time: 0.1733
DEBUG - 2023-04-23 19:02:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:16 --> Total execution time: 0.1047
DEBUG - 2023-04-23 19:02:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:16 --> Total execution time: 0.1896
DEBUG - 2023-04-23 19:02:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:20 --> Total execution time: 0.1035
DEBUG - 2023-04-23 19:02:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:20 --> Total execution time: 0.1557
DEBUG - 2023-04-23 19:02:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:21 --> Total execution time: 0.1109
DEBUG - 2023-04-23 19:02:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 19:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 19:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-04-23 19:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-04-23 22:32:22 --> Total execution time: 0.1774
