<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-21 03:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 03:54:29 --> Total execution time: 0.7660
DEBUG - 2022-04-21 03:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 03:55:58 --> Total execution time: 0.0914
DEBUG - 2022-04-21 03:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 03:56:17 --> Total execution time: 0.0498
DEBUG - 2022-04-21 03:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 03:56:23 --> Total execution time: 0.0920
DEBUG - 2022-04-21 03:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:56:31 --> UTF-8 Support Enabled
ERROR - 2022-04-21 03:56:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 03:56:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:56:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 03:56:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:56:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:56:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:56:31 --> UTF-8 Support Enabled
ERROR - 2022-04-21 03:56:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:56:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 03:57:47 --> Total execution time: 0.6036
DEBUG - 2022-04-21 03:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:57:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 03:57:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 03:57:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:57:48 --> UTF-8 Support Enabled
ERROR - 2022-04-21 03:57:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:57:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:57:48 --> UTF-8 Support Enabled
ERROR - 2022-04-21 03:57:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:57:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:57:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 03:59:29 --> Total execution time: 0.0708
DEBUG - 2022-04-21 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:59:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 03:59:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 03:59:38 --> Total execution time: 0.0553
DEBUG - 2022-04-21 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 03:59:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:59:39 --> UTF-8 Support Enabled
ERROR - 2022-04-21 03:59:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 03:59:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 03:59:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 03:59:57 --> Total execution time: 0.0811
DEBUG - 2022-04-21 03:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:59:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:57 --> UTF-8 Support Enabled
ERROR - 2022-04-21 03:59:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:57 --> UTF-8 Support Enabled
ERROR - 2022-04-21 03:59:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 03:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:59:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:00:09 --> Total execution time: 0.0752
DEBUG - 2022-04-21 04:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:00:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:00:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:00:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 04:00:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:00:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:00:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:00:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:00:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:00:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:00:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:00:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:01:36 --> Total execution time: 0.0654
DEBUG - 2022-04-21 04:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:02:40 --> Total execution time: 0.0509
DEBUG - 2022-04-21 04:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:02:48 --> Total execution time: 0.0557
DEBUG - 2022-04-21 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:03:32 --> Total execution time: 0.0590
DEBUG - 2022-04-21 04:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:03:51 --> Total execution time: 0.0572
DEBUG - 2022-04-21 04:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:05:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:05:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:05:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:05:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:05:31 --> UTF-8 Support Enabled
ERROR - 2022-04-21 04:05:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:05:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:05:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:05:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:05:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:05:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:05:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:05:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:05:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:05:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:05:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:06:20 --> Total execution time: 0.0773
DEBUG - 2022-04-21 04:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:06:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:06:21 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 04:06:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:06:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:06:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:06:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:06:21 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 04:06:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:06:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:06:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:06:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:06:37 --> Total execution time: 0.0567
DEBUG - 2022-04-21 04:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:06:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:06:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 04:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:06:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:06:45 --> UTF-8 Support Enabled
ERROR - 2022-04-21 04:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:06:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:06:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:06:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 04:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:06:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:07:19 --> Total execution time: 0.0931
DEBUG - 2022-04-21 04:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:07:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:07:19 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 04:07:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:07:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:07:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:07:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:07:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:07:19 --> UTF-8 Support Enabled
ERROR - 2022-04-21 04:07:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:07:19 --> UTF-8 Support Enabled
ERROR - 2022-04-21 04:07:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:07:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:07:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:07:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:07:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:07:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:07:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:07:36 --> UTF-8 Support Enabled
ERROR - 2022-04-21 04:07:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:07:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:07:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:07:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 04:07:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:07:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:08:10 --> Total execution time: 0.0556
DEBUG - 2022-04-21 04:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:08:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:08:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 04:08:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:08:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 04:08:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:08:10 --> UTF-8 Support Enabled
ERROR - 2022-04-21 04:08:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:08:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:08:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:09:51 --> Total execution time: 0.0479
DEBUG - 2022-04-21 04:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:10:12 --> Total execution time: 0.0642
DEBUG - 2022-04-21 04:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:17:51 --> Total execution time: 0.0544
DEBUG - 2022-04-21 04:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:17:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:17:53 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp\htdocs\gopal\leadrsark\system\core\CodeIgniter.php 413
ERROR - 2022-04-21 04:17:53 --> 404 Page Not Found: User/Courses_Controller/
DEBUG - 2022-04-21 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:17:58 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp\htdocs\gopal\leadrsark\system\core\CodeIgniter.php 413
ERROR - 2022-04-21 04:17:58 --> 404 Page Not Found: User/Courses_Controller/
DEBUG - 2022-04-21 04:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:18:00 --> Total execution time: 0.0717
DEBUG - 2022-04-21 04:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:18:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:18:04 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp\htdocs\gopal\leadrsark\system\core\CodeIgniter.php 413
ERROR - 2022-04-21 04:18:04 --> 404 Page Not Found: User/Courses_Controller/
DEBUG - 2022-04-21 04:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:18:31 --> Total execution time: 0.0576
DEBUG - 2022-04-21 04:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:19:09 --> Total execution time: 0.0486
DEBUG - 2022-04-21 04:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:19:10 --> Total execution time: 0.0479
DEBUG - 2022-04-21 04:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:19:10 --> Total execution time: 0.0703
DEBUG - 2022-04-21 04:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:20:41 --> Total execution time: 0.0461
DEBUG - 2022-04-21 04:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:20:53 --> Total execution time: 0.0791
DEBUG - 2022-04-21 04:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:21:06 --> Total execution time: 0.0682
DEBUG - 2022-04-21 04:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:21:15 --> Total execution time: 0.0848
DEBUG - 2022-04-21 04:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:21:18 --> UTF-8 Support Enabled
ERROR - 2022-04-21 04:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:21:18 --> UTF-8 Support Enabled
ERROR - 2022-04-21 04:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 04:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 04:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:21:24 --> Total execution time: 0.0732
DEBUG - 2022-04-21 04:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 04:21:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:21:57 --> Total execution time: 0.0731
DEBUG - 2022-04-21 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 04:21:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:21:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 04:21:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 04:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:22:24 --> Total execution time: 0.0464
DEBUG - 2022-04-21 04:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 04:22:36 --> Total execution time: 0.0581
DEBUG - 2022-04-21 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:11:37 --> Total execution time: 0.0958
DEBUG - 2022-04-21 06:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:11:50 --> Total execution time: 0.0512
DEBUG - 2022-04-21 06:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:11:54 --> Total execution time: 0.0637
DEBUG - 2022-04-21 06:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:12:02 --> Total execution time: 0.0605
DEBUG - 2022-04-21 06:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:12:15 --> Total execution time: 0.0499
DEBUG - 2022-04-21 06:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:12:18 --> Total execution time: 0.0507
DEBUG - 2022-04-21 06:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:12:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:21 --> UTF-8 Support Enabled
ERROR - 2022-04-21 06:12:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:12:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:12:21 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 06:12:21 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 06:12:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:12:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:12:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:12:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:12:29 --> Total execution time: 0.0581
DEBUG - 2022-04-21 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:12:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:12:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 06:12:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:12:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 06:12:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:12:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:12:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:12:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:14:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:14:11 --> 404 Page Not Found: user/Affiliate-earnings/index
DEBUG - 2022-04-21 06:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:14:15 --> Total execution time: 0.0520
DEBUG - 2022-04-21 06:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:14:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:14:39 --> 404 Page Not Found: user/Affiliate-account/index
DEBUG - 2022-04-21 06:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:16:25 --> Total execution time: 0.0544
DEBUG - 2022-04-21 06:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:17:41 --> Total execution time: 0.0746
DEBUG - 2022-04-21 06:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:19:34 --> Total execution time: 0.0620
DEBUG - 2022-04-21 06:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:20:52 --> Total execution time: 0.0527
DEBUG - 2022-04-21 06:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:22:02 --> Total execution time: 0.0483
DEBUG - 2022-04-21 06:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:24:12 --> Total execution time: 0.0691
DEBUG - 2022-04-21 06:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:24:37 --> Total execution time: 0.0524
DEBUG - 2022-04-21 06:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:25:03 --> Total execution time: 0.0677
DEBUG - 2022-04-21 06:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:25:35 --> Total execution time: 0.0902
DEBUG - 2022-04-21 06:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:25:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:25:44 --> UTF-8 Support Enabled
ERROR - 2022-04-21 06:25:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:25:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:25:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 06:25:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:25:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:25:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:25:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:26:11 --> Total execution time: 0.0509
DEBUG - 2022-04-21 06:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:26:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:26:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 06:26:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:26:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:26:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:26:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:26:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:26:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:26:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 06:26:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:26:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:26:16 --> UTF-8 Support Enabled
ERROR - 2022-04-21 06:26:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:26:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:26:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:26:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 06:26:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 06:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:27:28 --> Total execution time: 0.0488
DEBUG - 2022-04-21 06:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:59:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-21 06:59:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\leadrsark\application\core\DB_Controller.php 28
DEBUG - 2022-04-21 06:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 06:59:15 --> Total execution time: 0.0807
DEBUG - 2022-04-21 07:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:00:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-21 10:30:04 --> Query error: Table 'leadsark.rents' doesn't exist - Invalid query: SELECT SUM(`rent_amount_paid`) AS `rent_amount_paid`
FROM `rents`
WHERE YEAR(rent_date) = '2022'
DEBUG - 2022-04-21 07:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:00:13 --> 404 Page Not Found: Company-profile/index
DEBUG - 2022-04-21 07:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:01:11 --> Total execution time: 0.0688
DEBUG - 2022-04-21 07:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:01:14 --> Total execution time: 0.0552
DEBUG - 2022-04-21 07:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:01:17 --> Total execution time: 0.0503
DEBUG - 2022-04-21 07:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:01:50 --> UTF-8 Support Enabled
ERROR - 2022-04-21 07:01:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:01:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:01:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:01:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:01:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:01:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:01:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:01:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:02:01 --> Total execution time: 0.0702
DEBUG - 2022-04-21 07:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:02:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:02:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:02:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:02:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:02:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:02:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:02:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:02:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:02:18 --> Total execution time: 0.0577
DEBUG - 2022-04-21 07:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:02:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:02:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:02:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:02:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:02:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:02:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:02:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:02:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:04:11 --> UTF-8 Support Enabled
ERROR - 2022-04-21 07:04:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:04:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:04:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:04:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:04:27 --> Total execution time: 0.0585
DEBUG - 2022-04-21 07:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:04:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:04:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:04:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:04:43 --> Total execution time: 0.1008
DEBUG - 2022-04-21 07:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:04:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:04:43 --> UTF-8 Support Enabled
ERROR - 2022-04-21 07:04:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:04:43 --> UTF-8 Support Enabled
ERROR - 2022-04-21 07:04:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:04:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:05:35 --> Total execution time: 0.0847
DEBUG - 2022-04-21 07:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:06:54 --> Total execution time: 0.0534
DEBUG - 2022-04-21 07:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:07:09 --> Total execution time: 0.0652
DEBUG - 2022-04-21 07:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:07:47 --> Total execution time: 0.0655
DEBUG - 2022-04-21 07:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:08:06 --> Total execution time: 0.0708
DEBUG - 2022-04-21 07:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:10:07 --> Total execution time: 0.0597
DEBUG - 2022-04-21 07:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:10:20 --> Total execution time: 0.0563
DEBUG - 2022-04-21 07:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:12:18 --> Total execution time: 0.0591
DEBUG - 2022-04-21 07:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:12:26 --> Total execution time: 0.0756
DEBUG - 2022-04-21 07:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:12:40 --> Total execution time: 0.0591
DEBUG - 2022-04-21 07:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:13:08 --> Total execution time: 0.0732
DEBUG - 2022-04-21 07:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:13:36 --> Total execution time: 0.0546
DEBUG - 2022-04-21 07:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:14:40 --> Total execution time: 0.0671
DEBUG - 2022-04-21 07:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:21:02 --> UTF-8 Support Enabled
ERROR - 2022-04-21 07:21:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:21:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:21:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:21:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:21:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:21:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:21:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:21:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:21:34 --> Total execution time: 0.0902
DEBUG - 2022-04-21 07:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:21:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:21:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:21:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:21:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:21:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:21:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:21:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:21:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:22:18 --> Total execution time: 0.0501
DEBUG - 2022-04-21 07:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:22:44 --> Total execution time: 0.0726
DEBUG - 2022-04-21 07:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:23:57 --> Total execution time: 0.0503
DEBUG - 2022-04-21 07:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:24:21 --> Total execution time: 0.0509
DEBUG - 2022-04-21 07:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:24:35 --> Total execution time: 0.0775
DEBUG - 2022-04-21 07:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:24:40 --> Total execution time: 0.0515
DEBUG - 2022-04-21 07:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:24:45 --> Total execution time: 0.0628
DEBUG - 2022-04-21 07:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:25:06 --> Total execution time: 0.0500
DEBUG - 2022-04-21 07:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:25:24 --> Total execution time: 0.0713
DEBUG - 2022-04-21 07:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:26:08 --> Total execution time: 0.0670
DEBUG - 2022-04-21 07:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:26:16 --> Total execution time: 0.0554
DEBUG - 2022-04-21 07:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:26:33 --> Total execution time: 0.0548
DEBUG - 2022-04-21 07:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:26:43 --> Total execution time: 0.0577
DEBUG - 2022-04-21 07:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:26:44 --> Total execution time: 0.0683
DEBUG - 2022-04-21 07:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:26:45 --> Total execution time: 0.0522
DEBUG - 2022-04-21 07:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:26:59 --> Total execution time: 0.0508
DEBUG - 2022-04-21 07:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:28:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:28:00 --> 404 Page Not Found: user/Affiliate-earnings/index
DEBUG - 2022-04-21 07:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:28:56 --> Total execution time: 0.0567
DEBUG - 2022-04-21 07:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:29:36 --> Total execution time: 0.0638
DEBUG - 2022-04-21 07:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:29:40 --> Total execution time: 0.0538
DEBUG - 2022-04-21 07:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:29:42 --> Total execution time: 0.0530
DEBUG - 2022-04-21 07:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:32:03 --> Total execution time: 0.0518
DEBUG - 2022-04-21 07:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:32:09 --> Total execution time: 0.0677
DEBUG - 2022-04-21 07:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:32:17 --> Total execution time: 0.0510
DEBUG - 2022-04-21 07:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:33:29 --> Total execution time: 0.0684
DEBUG - 2022-04-21 07:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:33:45 --> Total execution time: 0.0699
DEBUG - 2022-04-21 07:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:36:29 --> Total execution time: 0.0490
DEBUG - 2022-04-21 07:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:36:42 --> Total execution time: 0.0832
DEBUG - 2022-04-21 07:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:36:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:36:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:36:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:36:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:36:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:36:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:36:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:36:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:36:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:36:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:36:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:36:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:36:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:36:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:36:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:37:00 --> Total execution time: 0.0484
DEBUG - 2022-04-21 07:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:37:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:37:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:37:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:37:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:37:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:37:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:37:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:37:01 --> UTF-8 Support Enabled
ERROR - 2022-04-21 07:37:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:37:01 --> UTF-8 Support Enabled
ERROR - 2022-04-21 07:37:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:37:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:37:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:37:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:38:46 --> Total execution time: 0.0767
DEBUG - 2022-04-21 07:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:39:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:39:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:39:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:39:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:39:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:39:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:39:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:39:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:39:32 --> Total execution time: 0.0512
DEBUG - 2022-04-21 07:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:39:33 --> UTF-8 Support Enabled
ERROR - 2022-04-21 07:39:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:39:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:39:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:39:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:39:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:39:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:39:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:39:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:40:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 07:40:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 07:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:40:29 --> Total execution time: 0.0497
DEBUG - 2022-04-21 07:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:41:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:41:45 --> 404 Page Not Found: Admin-rent-list/index
DEBUG - 2022-04-21 07:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:41:48 --> Total execution time: 0.0500
DEBUG - 2022-04-21 07:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:45:15 --> Total execution time: 0.0733
DEBUG - 2022-04-21 07:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:47:49 --> Total execution time: 0.0713
DEBUG - 2022-04-21 07:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:47:51 --> Total execution time: 0.0513
DEBUG - 2022-04-21 07:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:49:26 --> Total execution time: 0.0730
DEBUG - 2022-04-21 07:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:49:43 --> Total execution time: 0.0486
DEBUG - 2022-04-21 07:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:50:37 --> Total execution time: 0.0626
DEBUG - 2022-04-21 07:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:50:48 --> Total execution time: 0.0788
DEBUG - 2022-04-21 07:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:51:05 --> Total execution time: 0.0525
DEBUG - 2022-04-21 07:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:52:13 --> Total execution time: 0.0651
DEBUG - 2022-04-21 07:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:53:25 --> Total execution time: 0.0556
DEBUG - 2022-04-21 07:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:53:27 --> Total execution time: 0.0521
DEBUG - 2022-04-21 07:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:53:29 --> Total execution time: 0.0528
DEBUG - 2022-04-21 07:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:53:31 --> Total execution time: 0.0520
DEBUG - 2022-04-21 07:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:53:33 --> Total execution time: 0.0512
DEBUG - 2022-04-21 07:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:53:35 --> Total execution time: 0.0499
DEBUG - 2022-04-21 07:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:53:42 --> Total execution time: 0.0515
DEBUG - 2022-04-21 07:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:53:58 --> Total execution time: 0.0585
DEBUG - 2022-04-21 07:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:54:37 --> Total execution time: 0.0561
DEBUG - 2022-04-21 07:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:54:51 --> Total execution time: 0.0616
DEBUG - 2022-04-21 07:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:55:10 --> Total execution time: 0.1000
DEBUG - 2022-04-21 07:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:56:01 --> Total execution time: 0.0527
DEBUG - 2022-04-21 07:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:56:09 --> Total execution time: 0.0666
DEBUG - 2022-04-21 07:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:56:37 --> Total execution time: 0.0476
DEBUG - 2022-04-21 07:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:56:43 --> Total execution time: 0.0511
DEBUG - 2022-04-21 07:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 07:56:58 --> Total execution time: 0.0470
DEBUG - 2022-04-21 08:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:01:51 --> Total execution time: 0.0850
DEBUG - 2022-04-21 08:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:04:00 --> Total execution time: 0.0470
DEBUG - 2022-04-21 08:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:05:00 --> Total execution time: 0.0570
DEBUG - 2022-04-21 08:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:06:20 --> Total execution time: 0.0594
DEBUG - 2022-04-21 08:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:06:29 --> Total execution time: 0.0692
DEBUG - 2022-04-21 08:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:06:56 --> Total execution time: 0.0944
DEBUG - 2022-04-21 08:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:08:04 --> Total execution time: 0.0510
DEBUG - 2022-04-21 08:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:08:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 08:08:07 --> 404 Page Not Found: user/Edit-bank-details/index
DEBUG - 2022-04-21 08:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:08:10 --> Total execution time: 0.0519
DEBUG - 2022-04-21 08:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:08:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 08:08:19 --> 404 Page Not Found: user/Edit-bank-details/index
DEBUG - 2022-04-21 08:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 08:08:38 --> 404 Page Not Found: user/Edit-bank-details/index
DEBUG - 2022-04-21 08:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:08:59 --> Total execution time: 0.0470
DEBUG - 2022-04-21 08:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:09:01 --> Total execution time: 0.0516
DEBUG - 2022-04-21 08:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:09:03 --> Total execution time: 0.0708
DEBUG - 2022-04-21 08:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:09:05 --> Total execution time: 0.0532
DEBUG - 2022-04-21 08:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:09:07 --> Total execution time: 0.0516
DEBUG - 2022-04-21 08:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:09:08 --> Total execution time: 0.0492
DEBUG - 2022-04-21 08:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:09:09 --> Total execution time: 0.0511
DEBUG - 2022-04-21 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:09:10 --> Total execution time: 0.0494
DEBUG - 2022-04-21 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:09:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 08:09:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 08:09:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 08:09:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 08:09:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 08:09:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:09:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 08:09:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 08:09:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 08:09:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 08:09:55 --> Total execution time: 0.0969
DEBUG - 2022-04-21 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:09:55 --> UTF-8 Support Enabled
ERROR - 2022-04-21 08:09:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 08:09:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 08:09:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 08:09:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:09:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 08:09:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 08:09:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 08:09:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 08:09:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:09:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 08:09:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 08:09:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 08:09:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 15:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:52:01 --> No URI present. Default controller set.
DEBUG - 2022-04-21 15:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 15:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 15:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 15:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 15:52:13 --> Total execution time: 0.1015
DEBUG - 2022-04-21 15:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 15:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 15:56:35 --> Total execution time: 0.0808
DEBUG - 2022-04-21 15:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 15:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 15:57:02 --> Total execution time: 0.0712
DEBUG - 2022-04-21 15:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 15:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 15:57:31 --> Total execution time: 0.0655
DEBUG - 2022-04-21 15:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 15:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 15:58:49 --> Total execution time: 0.1092
DEBUG - 2022-04-21 15:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 15:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 15:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 15:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 15:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 15:58:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 15:58:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 15:58:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 15:58:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 15:58:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 15:58:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 15:58:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 15:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 15:58:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 15:58:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 15:58:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 15:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 15:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 15:59:35 --> Total execution time: 0.3677
DEBUG - 2022-04-21 15:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 15:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 15:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 15:59:45 --> Total execution time: 0.0590
DEBUG - 2022-04-21 16:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:00:08 --> Total execution time: 0.0524
DEBUG - 2022-04-21 16:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:00:25 --> Total execution time: 0.0587
DEBUG - 2022-04-21 16:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:02:38 --> Total execution time: 0.0532
DEBUG - 2022-04-21 16:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:02:39 --> Total execution time: 0.0491
DEBUG - 2022-04-21 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:04:08 --> Total execution time: 0.0851
DEBUG - 2022-04-21 16:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:04:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:04:21 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 16:04:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:04:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:04:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:04:21 --> UTF-8 Support Enabled
ERROR - 2022-04-21 16:04:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:04:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:04:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:04:31 --> Total execution time: 0.0882
DEBUG - 2022-04-21 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:04:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:04:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:04:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:04:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:04:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 16:04:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:04:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:04:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:05:00 --> Total execution time: 0.0568
DEBUG - 2022-04-21 16:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:05:34 --> Total execution time: 0.0681
DEBUG - 2022-04-21 16:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:05:36 --> Total execution time: 0.0519
DEBUG - 2022-04-21 16:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:06:40 --> Total execution time: 0.0501
DEBUG - 2022-04-21 16:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:06:50 --> Total execution time: 0.0567
DEBUG - 2022-04-21 16:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:06:51 --> Total execution time: 0.0484
DEBUG - 2022-04-21 16:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:07:10 --> Total execution time: 0.0478
DEBUG - 2022-04-21 16:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:08:18 --> Total execution time: 0.0532
DEBUG - 2022-04-21 16:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:09:41 --> Total execution time: 0.0624
DEBUG - 2022-04-21 16:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:10:48 --> Total execution time: 0.0692
DEBUG - 2022-04-21 16:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:27:32 --> Total execution time: 0.0805
DEBUG - 2022-04-21 16:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:27:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:27:32 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-04-21 16:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:27:44 --> Total execution time: 0.0495
DEBUG - 2022-04-21 16:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:27:49 --> UTF-8 Support Enabled
ERROR - 2022-04-21 16:27:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:27:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:27:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 16:27:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 16:27:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:27:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:27:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:27:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:27:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:27:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:27:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 16:27:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:28:53 --> Total execution time: 0.0685
DEBUG - 2022-04-21 16:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:28:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:28:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 16:28:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:28:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:28:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:28:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:28:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:28:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:28:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:28:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:28:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 16:28:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:28:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:28:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:29:03 --> Total execution time: 0.0501
DEBUG - 2022-04-21 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:29:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 16:29:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:29:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:29:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:29:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 16:29:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 16:29:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-21 16:29:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-21 16:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:29:39 --> Total execution time: 0.0514
DEBUG - 2022-04-21 16:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:29:56 --> Total execution time: 0.0627
DEBUG - 2022-04-21 16:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:30:28 --> Total execution time: 0.0590
DEBUG - 2022-04-21 16:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:30:51 --> Total execution time: 0.0536
DEBUG - 2022-04-21 16:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:30:59 --> Total execution time: 0.0623
DEBUG - 2022-04-21 16:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:31:05 --> Total execution time: 0.0527
DEBUG - 2022-04-21 16:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:33:39 --> Total execution time: 0.0530
DEBUG - 2022-04-21 16:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:34:29 --> Total execution time: 0.0823
DEBUG - 2022-04-21 16:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:35:25 --> Total execution time: 0.0479
DEBUG - 2022-04-21 16:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:54:06 --> Total execution time: 0.0559
DEBUG - 2022-04-21 16:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:54:29 --> Total execution time: 0.0541
DEBUG - 2022-04-21 16:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:54:50 --> Total execution time: 0.0481
DEBUG - 2022-04-21 16:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:56:09 --> Total execution time: 0.0503
DEBUG - 2022-04-21 16:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:56:15 --> Total execution time: 0.0762
DEBUG - 2022-04-21 16:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:58:55 --> Total execution time: 0.0640
DEBUG - 2022-04-21 16:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 16:59:47 --> Total execution time: 0.0503
DEBUG - 2022-04-21 17:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 17:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 17:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 17:00:10 --> Total execution time: 0.0832
DEBUG - 2022-04-21 17:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 17:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 17:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 17:04:12 --> Total execution time: 0.0678
DEBUG - 2022-04-21 18:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 18:21:17 --> Total execution time: 0.0739
DEBUG - 2022-04-21 18:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:21:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 18:21:19 --> 404 Page Not Found: user/Profile/index
DEBUG - 2022-04-21 18:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 18:21:24 --> Total execution time: 0.0508
DEBUG - 2022-04-21 18:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 18:23:03 --> Total execution time: 0.0764
DEBUG - 2022-04-21 18:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 18:23:34 --> 404 Page Not Found: user/My-referrals/index
DEBUG - 2022-04-21 18:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 18:23:35 --> Total execution time: 0.0523
DEBUG - 2022-04-21 18:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:23:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 18:23:41 --> 404 Page Not Found: user/My-referrals/index
DEBUG - 2022-04-21 18:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 18:24:26 --> Total execution time: 0.0684
DEBUG - 2022-04-21 18:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:24:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 18:24:35 --> 404 Page Not Found: User/Referrals_Controller/index
DEBUG - 2022-04-21 18:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 18:24:36 --> Total execution time: 0.0675
DEBUG - 2022-04-21 18:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:27:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 18:27:37 --> 404 Page Not Found: User/Referrals_Controller/index
DEBUG - 2022-04-21 18:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 18:27:46 --> Total execution time: 0.0604
DEBUG - 2022-04-21 18:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:29:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-21 18:29:12 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 14
ERROR - 2022-04-21 18:29:12 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-21 18:29:12 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-21 18:29:12 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 6
ERROR - 2022-04-21 18:29:12 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 8
DEBUG - 2022-04-21 18:29:12 --> Total execution time: 0.1436
DEBUG - 2022-04-21 18:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:29:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-21 18:29:25 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 14
ERROR - 2022-04-21 18:29:25 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-21 18:29:25 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-21 18:29:25 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 6
ERROR - 2022-04-21 18:29:25 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 8
DEBUG - 2022-04-21 18:29:25 --> Total execution time: 0.0713
DEBUG - 2022-04-21 18:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:29:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-21 18:29:34 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 14
ERROR - 2022-04-21 18:29:34 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-21 18:29:34 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-21 18:29:34 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 6
ERROR - 2022-04-21 18:29:34 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 8
DEBUG - 2022-04-21 18:29:34 --> Total execution time: 0.0633
DEBUG - 2022-04-21 18:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 18:30:00 --> Total execution time: 0.0881
DEBUG - 2022-04-21 18:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 18:30:02 --> Total execution time: 0.0522
DEBUG - 2022-04-21 18:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 18:31:59 --> Total execution time: 0.0481
DEBUG - 2022-04-21 18:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 18:32:33 --> Total execution time: 0.0531
DEBUG - 2022-04-21 18:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 18:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 18:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-21 18:33:00 --> Total execution time: 0.1256
